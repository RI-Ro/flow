import React, { useEffect, useState } from "react";
import { api } from "../lib/api.js";

// Картинка и скачивание с авторизацией.
//
// Вся выдача файлов закрыта токеном, а браузер не добавляет заголовок
// Authorization ни к <img src>, ни к <a href>, ни к <iframe src>. Из-за
// этого прямые ссылки на вложения отвечали 401: миниатюры не
// показывались, а «скачать» иногда молча ничего не делало.
//
// Поэтому файл забирается обычным запросом (с токеном) и превращается в
// blob-ссылку. Ссылка освобождается при размонтировании: иначе вложения
// висят в памяти до перезагрузки страницы, а они бывают на десятки
// мегабайт.

export default function AuthImage({ path, alt, className, style, theme }) {
  const [url, setUrl] = useState(null);

  useEffect(() => {
    let dead = false;
    let made = null;
    api.fileBlob(path)
      .then((blob) => {
        if (dead) return;
        made = URL.createObjectURL(blob);
        setUrl(made);
      })
      .catch(() => {
        /* не загрузилось — покажем заглушку, ошибку сюда выводить
           некуда: это миниатюра в списке */
      });
    return () => {
      dead = true;
      if (made) URL.revokeObjectURL(made);
    };
  }, [path]);

  if (!url) {
    return (
      <span
        style={{ background: theme?.surface, border: `1px solid ${theme?.border || "transparent"}`, ...style }}
        className={`${className || ""} animate-pulse block`} />
    );
  }
  return <img src={url} alt={alt} className={className}
    style={{ border: `1px solid ${theme?.border || "transparent"}`, ...style }} />;
}

// Скачивание файла программно: тот же запрос с токеном, затем
// сохранение через временную ссылку.
export async function downloadFile(path, filename) {
  try {
    const blob = await api.fileBlob(path);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || "файл";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch {
    /* причина та же, что и у неудавшегося предпросмотра, и она уже
       видна человеку в окне файла */
  }
}
