import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowUpDown, CheckCircle2, UserCheck, Globe, FileSpreadsheet, Printer, MessageSquare, Paperclip } from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { PRIORITIES, fmtDate, fmtDateTime, isOverdue, isUnseen, resolveUser } from "../lib/theme.js";
import { dayEndISO, dayStartISO, localDay } from "../lib/filters.js";
import { exportTasksToExcel } from "../lib/excel.js";
import { printTasksReport } from "../lib/taskPdf.js";
import { Avatar, Spinner } from "../lib/ui.jsx";

// Вкладка «Все задачи» (п.5): единый список всех доступных задач из всех
// проектов с фильтрами и сортировкой. Каждая строка показывает проект и
// колонку задачи; клик открывает подробный просмотр.
const SHOW_ALL_KEY = "kanban.allTasks.showAll";

export default function AllTasks({ theme, directory, boards, currentUser, hideCompleted, filters, search, onTags, readyOnly = false, onError, onInfo, onOpenTask, onOpenBoard }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState({ key: "updated", dir: "desc" });
  // По умолчанию показываются только свои задачи: поставленные мной и
  // порученные мне (п.4). Всё, что доступно по ролям в проектах, —
  // по отдельной кнопке, и её состояние переживает перезагрузку
  // страницы: это настройка рабочего места, а не разовый фильтр.
  const [showAll, setShowAll] = useState(
    () => localStorage.getItem(SHOW_ALL_KEY) === "true");
  useEffect(() => { localStorage.setItem(SHOW_ALL_KEY, String(showAll)); }, [showAll]);

  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const PAGE = 50;

  // Запрос собирается из тех же условий, что раньше применялись на
  // клиенте. Теперь они уходят на сервер: тянуть в браузер все задачи
  // организации ради того, чтобы показать пятьдесят, — расточительство,
  // которое перестаёт работать где-то на первой тысяче.
  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (search.trim()) p.set("q", search.trim());
    if (filters?.boardId) p.set("boardId", filters.boardId);
    if (filters?.priority?.size) p.set("priority", [...filters.priority].join(","));
    if (filters?.assignee?.size) p.set("assignee", [...filters.assignee].join(","));
    if (filters?.tag?.size) p.set("tag", [...filters.tag].join(","));
    if (filters?.dueFrom) p.set("dueFrom", filters.dueFrom);
    if (filters?.dueTo) p.set("dueTo", filters.dueTo);
    // Диапазон дат завершения уходит моментами — местными полуночами
    // (см. dayStartISO/dayEndISO): сервер не знает часового пояса
    // пользователя, а день завершения должен считаться по нему.
    if (filters?.doneFrom) p.set("completedFrom", dayStartISO(filters.doneFrom));
    if (filters?.doneTo) p.set("completedTo", dayEndISO(filters.doneTo));
    const byDoneDate = Boolean(filters?.doneFrom || filters?.doneTo);
    // Раздел «Готовы к сдаче» — это тот же список с иным условием
    // статуса, поэтому отдельного запроса ему не нужно.
    p.set("status", readyOnly ? "ready" : (filters?.status || "all"));
    // «Скрыть завершённые» не действует, когда задан диапазон дат
    // завершения: человек прямо просит завершённые, и молча отдать ему
    // пустой список было бы хуже, чем нарушить общую настройку.
    if (hideCompleted && !readyOnly && !byDoneDate && (filters?.status || "all") === "all") {
      p.set("status", "active");
    }
    p.set("scope", showAll ? "all" : "mine");
    p.set("sort", sort.key);
    p.set("dir", sort.dir);
    p.set("limit", String(PAGE));
    p.set("offset", String(page * PAGE));
    return p.toString();
  }, [search, filters, showAll, sort, page, readyOnly, hideCompleted]);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.allTasks(query);
      setTasks(res.items || []);
      setTotal(res.total || 0);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [query]);

  // Смена условий возвращает на первую страницу: оставаться на
  // седьмой странице выборки, которой больше нет, бессмысленно.
  useEffect(() => { setPage(0); }, [search, filters, showAll, readyOnly, sort]);

  // Тихое обновление — без полосы загрузки: вызывается по событиям,
  // когда человек ничего не нажимал и мигание списка выглядело бы
  // сбоем.
  const reload = useCallback(async () => {
    try {
      const res = await api.allTasks(query);
      setTasks(res.items || []);
      setTotal(res.total || 0);
      return;
    } catch {
      /* временная ошибка сети: список останется прежним до следующего
         события или перехода в раздел */
    }
  }, [query]);

  // Кандидаты для фильтра по исполнителю — все, кто встречается в
  // загруженных задачах.
  // Список здесь свой, поэтому события задач нужно слушать
  // самостоятельно. Главное — удаление: когда человека снимают с
  // задачи, сервер шлёт ему именно такое событие, и без обработки
  // задача висела бы в списке до перезагрузки страницы.
  useEffect(() => {
    const off = onRealtimeMessage("task", (e) => {
      const id = e.payload?.id;
      if (!id) return;
      if (e.action === "deleted") {
        setTasks((prev) => prev.filter((t) => t.id !== id));
        return;
      }
      // Задача, которой в списке ещё нет, — это обычно новое
      // назначение: человека только что сделали исполнителем, и задача
      // должна появиться сразу, а не после перезагрузки. Одной строкой
      // из события её не собрать (нет access, отметок просмотра и
      // прочего), поэтому перечитываем список целиком.
      // Изменившаяся задача может больше не подходить разделу:
      // завершённая уходит из «активных», а снятая с приёмки — из
      // «готовых к сдаче». Раньше она оставалась в списке до
      // перезагрузки, потому что обновлялась на месте без проверки
      // условий.
      //
      // Проверяем только те условия, которые видны из самого события;
      // остальное (поиск, теги, исполнители) пересчитывать на клиенте
      // не будем — для них достаточно, что строка обновилась.
      const fitsView = () => {
        const t = e.payload;
        if (readyOnly) return Boolean(t.readyAt) && !t.completedAt;
        const status = filters?.status || "all";
        if (status === "active" && t.completedAt) return false;
        if (status === "done" && !t.completedAt) return false;
        const byDoneDate = Boolean(filters?.doneFrom || filters?.doneTo);
        if (hideCompleted && !byDoneDate && status === "all" && t.completedAt) return false;
        if (byDoneDate) {
          const day = localDay(t.completedAt);
          if (!day) return false;
          if (filters.doneFrom && day < filters.doneFrom) return false;
          if (filters.doneTo && day > filters.doneTo) return false;
        }
        return true;
      };

      setTasks((prev) => {
        const known = prev.some((t) => t.id === id);
        if (!fitsView()) {
          // Убираем сразу, а следом перечитываем страницу: на её место
          // должна подняться следующая задача, а общий счётчик —
          // уменьшиться.
          if (known) reload();
          return known ? prev.filter((t) => t.id !== id) : prev;
        }
        if (!known) {
          reload();
          return prev;
        }
        // Знакомая задача обновляется на месте: перезапрашивать весь
        // список на каждое чужое изменение — лишняя нагрузка.
        return prev.map((t) => (t.id === id ? { ...t, ...e.payload, seenAt: t.seenAt } : t));
      });
    });
    return off;
  }, [reload, readyOnly, filters, hideCompleted]);

  // Теги этой вкладки уходят наверх, в общую панель отбора: задачи
  // грузятся здесь, а панель живёт в App.
  useEffect(() => {
    onTags?.([...new Set(tasks.flatMap((t) => t.tags || []))].sort());
  }, [tasks, onTags]);

  // Список приходит уже отобранным и отсортированным — показываем как
  // есть. Сортировка по столбцам таблицы теперь тоже серверная:
  // сортировать страницу из пятидесяти строк, когда всего их тысячи,
  // значит показывать «самое срочное» в пределах случайной полусотни.
  const filtered = tasks;

  const toggleSort = (key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));


  const th = (key, label) => (
    <button onClick={() => toggleSort(key)}
      style={{ color: sort.key === key ? theme.text : theme.textMuted }}
      className="flex items-center gap-1 text-[11px] uppercase tracking-wide font-semibold">
      {label}
      <ArrowUpDown size={11} style={{ opacity: sort.key === key ? 1 : 0.3 }} />
    </button>
  );

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="rounded-2xl p-3 mb-3 flex flex-wrap items-center gap-2.5">
        {/* Поиск и отбор — общие, в шапке приложения. Здесь остаётся
            только то, чего нет больше нигде: переключатель «мои /
            все» и счётчик показанного. */}

        {/* Выгрузка и печать работают по отфильтрованному списку — по
            тому, что человек видит на экране. Иначе отчёт расходился
            бы с картинкой, а верят как раз отчёту. */}
        <button
          onClick={() => {
            const n = exportTasksToExcel(filtered, {
              directory, boardTitle: showAll ? "Все задачи" : "Мои задачи",
            });
            onInfo?.(`Выгружено задач: ${n}`);
          }}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium shrink-0"
          title="Выгрузить показанные задачи в Excel">
          <FileSpreadsheet size={13} /> Excel
        </button>

        <button
          onClick={() => printTasksReport(filtered, directory, {
            title: showAll ? "Все задачи" : "Мои задачи",
          })}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium shrink-0"
          title="Печать отчёта по показанным задачам (сгруппирован по проектам)">
          <Printer size={13} /> Печать
        </button>

        <button onClick={() => setShowAll((v) => !v)}
          style={{
            background: showAll ? theme.accent : theme.surfaceAlt,
            color: showAll ? theme.accentText : theme.text,
            border: `1px solid ${theme.border}`,
          }}
          // Ширина фиксирована: подписи «Только мои» и «Все задачи»
          // разной длины, и без этого кнопка при переключении меняла
          // размер, а вместе с ней разъезжалась вся строка фильтров и
          // прыгало поле поиска.
          className="flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium w-[124px] shrink-0"
          title={showAll
            ? "Сейчас показаны все доступные задачи. Нажмите, чтобы оставить только свои"
            : "Сейчас показаны только мои задачи (поставленные мной и порученные мне). Нажмите, чтобы показать все доступные"}>
          {showAll ? <Globe size={13} /> : <UserCheck size={13} />}
          {showAll ? "Все задачи" : "Только мои"}
        </button>

        <span className="mono text-[10.5px] ml-auto" style={{ color: theme.textMuted }}>
          {loading ? "// загрузка…" : `// показано ${filtered.length} из ${total}`}
        </span>
      </div>

      {loading ? (
        <Spinner theme={theme} label="Загружаем задачи…" />
      ) : (
        <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }} className="rounded-2xl overflow-hidden">
          {/* Ширины столбцов заданы в пикселях, а не долями: доля
              зависит от содержимого, и длинное название задачи
              раздвигало соседние столбцы — в соседних строках те же
              поля оказывались на других местах, и таблица выглядела
              рассыпанной. Тянется только первый столбец, с названием. */}
          <div style={{ background: theme.surfaceAlt, borderColor: theme.border }}
            className="grid grid-cols-[minmax(0,1fr)_200px_170px_110px_150px_96px_96px] gap-3 px-4 py-2.5 border-b">
            {th("title", "Задача")}
            {th("board", "Проект / колонка")}
            {th("author", "Автор")}
            {th("priority", "Приоритет")}
            <div className="text-[11px] uppercase tracking-wide font-semibold" style={{ color: theme.textMuted }}>Исполнители</div>
            {th("due", "Срок")}
            {th("completed", "Завершена")}
          </div>

          {filtered.length === 0 && (
            <div style={{ color: theme.textMuted }} className="px-4 py-10 text-center text-[13px]">
              Задач по заданным условиям не найдено.
              {!showAll && (
                <>
                  {" "}
                  <button onClick={() => setShowAll(true)} style={{ color: theme.accent }}
                    className="font-medium underline">
                    Показать все доступные
                  </button>
                </>
              )}
            </div>
          )}

          {filtered.map((t) => {
            const pr = PRIORITIES[t.priority] || PRIORITIES.medium;
            const overdue = isOverdue(t.dueDate, Boolean(t.completedAt));
            const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
            const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
            const unseen = isUnseen(t);
            return (
              <div key={t.id}
                onClick={() => {
                  // Гасим выделение сразу: сама отметка о просмотре
                  // уходит на сервер при открытии карточки, но список
                  // здесь свой и о ней не узнает.
                  setTasks((prev) => prev.map((x) =>
                    (x.id === t.id ? { ...x, seenAt: new Date().toISOString() } : x)));
                  onOpenTask(t.id);
                }}
                role="button" tabIndex={0}
                style={{
                  borderColor: theme.border,
                  background: unseen
                    ? (theme.dark ? "rgba(255,255,255,0.055)" : "rgba(0,0,0,0.045)")
                    : "transparent",
                  boxShadow: unseen ? `inset 3px 0 0 0 ${theme.accent}` : undefined,
                }}
                className="w-full grid grid-cols-[minmax(0,1fr)_200px_170px_110px_150px_96px_96px] gap-3 px-4 py-2.5 border-b text-left hover:opacity-90 items-center cursor-pointer">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {t.completedAt && <CheckCircle2 size={13} style={{ color: theme.success }} className="shrink-0" />}
                    <span style={{
                        color: theme.text,
                        textDecoration: t.completedAt ? "line-through" : "none",
                        fontWeight: unseen ? 700 : 500,
                      }} className="text-[13px] truncate"
                      title={unseen ? "Изменилось с вашего последнего просмотра" : undefined}>
                      {t.title}
                    </span>
                    {unseen && (
                      <span style={{ background: theme.accent }}
                        className="w-1.5 h-1.5 rounded-full shrink-0" />
                    )}
                    {/* Готовность к сдаче — рядом с названием, самым
                        заметным элементом строки. */}
                    {t.readyAt && !t.completedAt && (
                      <span style={{ background: theme.success, color: "#fff" }}
                        className="text-[9.5px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded shrink-0">
                        готова к сдаче
                      </span>
                    )}
                    {/* Обсуждение и вложения — теми же приметами, что
                        на карточке в проекте: видно, есть ли в задаче
                        разговор, не открывая её. */}
                    {t.commentCount > 0 && (
                      <span style={{ color: theme.textMuted }}
                        className="text-[10.5px] flex items-center gap-0.5 shrink-0"
                        title={`Комментариев: ${t.commentCount}`}>
                        <MessageSquare size={10} />{t.commentCount}
                      </span>
                    )}
                    {t.attachmentCount > 0 && (
                      <span style={{ color: theme.textMuted }}
                        className="text-[10.5px] flex items-center gap-0.5 shrink-0"
                        title={`Файлов: ${t.attachmentCount}`}>
                        <Paperclip size={10} />{t.attachmentCount}
                      </span>
                    )}
                  </div>
                  {t.incomingNumber && (
                    <div style={{ color: theme.textMuted }} className="text-[10.5px] mono truncate"
                      title="Входящий номер">
                      вх. {t.incomingNumber}{t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}
                    </div>
                  )}
                </div>

                <div className="min-w-0" onClick={(e) => { e.stopPropagation(); onOpenBoard(t.boardId); }} title="Перейти в проект">
                  <div style={{ color: theme.accent }} className="text-[12px] truncate hover:underline">{t.boardTitle}</div>
                  <div style={{ color: theme.textMuted }} className="text-[10.5px] truncate">{t.columnTitle}</div>
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  {author && !author.deleted ? (
                    <>
                      <Avatar user={author} size={20} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{author.fullName}</span>
                    </>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  <span style={{ background: theme[pr.color] }} className="w-2 h-2 rounded-full shrink-0" />
                  <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{pr.label}</span>
                </div>

                <div className="flex items-center -space-x-1.5">
                  {assignees.slice(0, 4).map((u, i) => (
                    <Avatar key={i} user={u} size={20} theme={theme} />
                  ))}
                  {assignees.length > 4 && (
                    <span style={{ color: theme.textMuted }} className="text-[11px] pl-2.5">+{assignees.length - 4}</span>
                  )}
                  {assignees.length === 0 && <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>}
                </div>

                <div style={{ color: overdue ? theme.danger : theme.textMuted }} className="text-[11.5px] whitespace-nowrap">
                  {t.dueDate ? fmtDate(t.dueDate) : "—"}
                </div>

                <div style={{ color: t.completedAt ? theme.success : theme.textMuted }}
                  className="text-[11.5px] whitespace-nowrap"
                  title={t.completedAt ? `Завершена ${fmtDateTime(t.completedAt)}` : "Не завершена"}>
                  {t.completedAt ? fmtDate(t.completedAt) : "—"}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {/* Постраничная навигация. Кнопками, а не бесконечной
          прокруткой: в рабочем списке нужно уметь вернуться на ту же
          страницу и понимать, сколько всего осталось. */}
      {total > PAGE && (
        <div className="flex items-center justify-center gap-3 py-3">
          <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 py-1.5 text-[12.5px] font-medium disabled:opacity-40">
            Назад
          </button>
          <span style={{ color: theme.textMuted }} className="text-[12px]">
            {page * PAGE + 1}–{Math.min(total, (page + 1) * PAGE)} из {total}
          </span>
          <button onClick={() => setPage((p) => p + 1)}
            disabled={(page + 1) * PAGE >= total}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 py-1.5 text-[12.5px] font-medium disabled:opacity-40">
            Вперёд
          </button>
        </div>
      )}

    </div>
  );
}
