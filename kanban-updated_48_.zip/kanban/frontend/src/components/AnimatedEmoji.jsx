import React from "react";

// Анимированные смайлы в духе ICQ.
//
// Честно о том, что здесь происходит. Оригинальные смайлы ICQ — это
// чужие GIF-файлы, и взять их я не могу: во-первых, у сборки нет
// доступа в сеть, во-вторых, это чужая графика с неясными правами, и
// тащить её в рабочую систему — плохая идея. Поэтому знаменитые смайлы
// нарисованы заново: SVG плюс CSS-анимация, по мотивам оригиналов.
//
// Что это даёт, кроме законности: файл весит килобайты вместо сотен,
// картинка резкая на любом экране, цвета подстраиваются под тему, а
// анимация останавливается, если человек в системе попросил
// «уменьшить движение» (prefers-reduced-motion) — иначе десяток
// прыгающих рожиц в переписке превращается в мигающую гирлянду.
//
// Вставляются в текст как короткие коды — :bang:, :facepalm: и так
// далее. Код остаётся в сообщении обычным текстом: он читается и в
// уведомлении, и в поиске, и в выгрузке, где картинку показать негде.

// Главный по заявке: человек бьётся головой об стену.
//
// Анимация склеена из двух: корпус наклоняется вперёд-назад, а в
// момент удара у стены вспыхивают «звёздочки». Смещения подобраны
// так, чтобы удар приходился на крайнюю точку наклона — иначе
// получается не удар, а поклон.
const KEYFRAMES = `
@keyframes icq-bang-body {
  0%, 100% { transform: rotate(-14deg); }
  45%      { transform: rotate(6deg); }
  55%      { transform: rotate(8deg); }
}
@keyframes icq-bang-spark {
  0%, 40%  { opacity: 0; transform: scale(.6); }
  55%      { opacity: 1; transform: scale(1.15); }
  75%, 100% { opacity: 0; transform: scale(.8); }
}
@keyframes icq-laugh {
  0%, 100% { transform: translateY(0) scale(1); }
  30%      { transform: translateY(-2px) scale(1.06); }
  60%      { transform: translateY(1px) scale(.97); }
}
@keyframes icq-wink {
  0%, 70%, 100% { transform: scaleY(1); }
  80%, 90%      { transform: scaleY(.1); }
}
@keyframes icq-angry {
  0%, 100% { transform: translateX(0); }
  25%      { transform: translateX(-1.5px); }
  75%      { transform: translateX(1.5px); }
}
@keyframes icq-cry {
  0%   { opacity: 0; transform: translateY(0); }
  20%  { opacity: 1; }
  100% { opacity: 0; transform: translateY(9px); }
}
@keyframes icq-spin {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}
@keyframes icq-beat {
  0%, 100% { transform: scale(1); }
  35%      { transform: scale(1.18); }
  70%      { transform: scale(.95); }
}
@keyframes icq-nod {
  0%, 100% { transform: rotate(0deg); }
  30%      { transform: rotate(-12deg); }
  60%      { transform: rotate(10deg); }
}
@media (prefers-reduced-motion: reduce) {
  .icq-anim * { animation: none !important; }
}
`;

let injected = false;
function useKeyframes() {
  React.useEffect(() => {
    // Один тег стилей на всё приложение: смайлов в переписке десятки,
    // и вставлять правила на каждый — лишняя работа для браузера.
    if (injected) return;
    const tag = document.createElement("style");
    tag.dataset.icqAnim = "1";
    tag.textContent = KEYFRAMES;
    document.head.appendChild(tag);
    injected = true;
  }, []);
}

const FACE = "#F2C24B";       // корпус смайла
const FACE_DARK = "#D9A21C";  // обводка
const INK = "#3A2E0B";        // черты лица

function Face({ children, style }) {
  return (
    <g style={style}>
      <circle cx="26" cy="26" r="20" fill={FACE} stroke={FACE_DARK} strokeWidth="2" />
      {children}
    </g>
  );
}

const Eye = ({ x, style }) => (
  <ellipse cx={x} cy="21" rx="2.6" ry="3.4" fill={INK} style={style} />
);

// ── сами смайлы ──────────────────────────────────────────────────────

function BangHead({ size }) {
  return (
    <svg viewBox="0 0 64 56" width={size} height={size} className="icq-anim" aria-hidden>
      {/* Стена справа — то, обо что бьются. Без неё анимация читается
          как «кланяется». */}
      <rect x="52" y="2" width="10" height="52" rx="2" fill="#9AA3AE" />
      <path d="M52 16 h10 M52 30 h10 M52 44 h10" stroke="#7D8794" strokeWidth="1.5" />

      <g style={{ transformOrigin: "22px 46px", animation: "icq-bang-body .62s ease-in-out infinite" }}>
        {/* тело и рука */}
        <path d="M20 46 L20 34" stroke={INK} strokeWidth="3" strokeLinecap="round" />
        <path d="M20 38 L34 40" stroke={INK} strokeWidth="2.5" strokeLinecap="round" />
        <Face>
          <Eye x="20" />
          <Eye x="30" />
          <path d="M20 33 Q26 29 32 33" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        </Face>
      </g>

      <g style={{ transformOrigin: "50px 24px", animation: "icq-bang-spark .62s ease-in-out infinite" }}>
        <path d="M46 14 l4 4 M52 22 l-5 1 M46 32 l4 -4"
          stroke="#E4573D" strokeWidth="2.5" strokeLinecap="round" />
      </g>
    </svg>
  );
}

// Рукопожатие — «договорились». Вместо «руки-лица»: в рабочей
// переписке чаще нужно подтвердить согласие, чем изобразить досаду на
// собеседника.
function Handshake({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <g style={{ transformOrigin: "26px 30px", animation: "icq-nod 1.2s ease-in-out infinite" }}>
        <path d="M6 26 l10 -6 l10 6 l-10 6 z" fill="#F2C24B" stroke={FACE_DARK} strokeWidth="1.6" />
        <path d="M46 26 l-10 -6 l-10 6 l10 6 z" fill="#E8B437" stroke={FACE_DARK} strokeWidth="1.6" />
        <rect x="20" y="24" width="12" height="5" rx="2.5" fill={INK} />
      </g>
    </svg>
  );
}

function Laugh({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <Face style={{ transformOrigin: "26px 26px", animation: "icq-laugh .8s ease-in-out infinite" }}>
        <path d="M15 19 q4 -3 8 0" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M29 19 q4 -3 8 0" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M16 28 q10 12 20 0 z" fill={INK} />
      </Face>
    </svg>
  );
}

function Wink({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <Face>
        <Eye x="19" />
        <ellipse cx="33" cy="21" rx="2.6" ry="3.4" fill={INK}
          style={{ transformOrigin: "33px 21px", animation: "icq-wink 2.4s ease-in-out infinite" }} />
        <path d="M17 30 q9 8 18 0" stroke={INK} strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </Face>
    </svg>
  );
}

function Angry({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <g style={{ animation: "icq-angry .18s linear infinite" }}>
        <circle cx="26" cy="26" r="20" fill="#E4573D" stroke="#B93A24" strokeWidth="2" />
        <path d="M14 15 l9 5 M38 15 l-9 5" stroke="#3B140C" strokeWidth="2.6" strokeLinecap="round" />
        <Eye x="19" />
        <Eye x="33" />
        <path d="M17 34 q9 -6 18 0" stroke="#3B140C" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </g>
    </svg>
  );
}

function Cry({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <Face>
        <Eye x="19" />
        <Eye x="33" />
        <path d="M18 34 q8 -6 16 0" stroke={INK} strokeWidth="2.2" fill="none" strokeLinecap="round" />
      </Face>
      <circle cx="19" cy="26" r="2.2" fill="#4FA8E8"
        style={{ animation: "icq-cry 1.1s ease-in infinite" }} />
      <circle cx="33" cy="26" r="2.2" fill="#4FA8E8"
        style={{ animation: "icq-cry 1.1s ease-in .35s infinite" }} />
    </svg>
  );
}

function Dizzy({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <Face>
        <g style={{ transformOrigin: "19px 21px", animation: "icq-spin 1.4s linear infinite" }}>
          <path d="M15 21 h8 M19 17 v8" stroke={INK} strokeWidth="2" strokeLinecap="round" />
        </g>
        <g style={{ transformOrigin: "33px 21px", animation: "icq-spin 1.4s linear infinite reverse" }}>
          <path d="M29 21 h8 M33 17 v8" stroke={INK} strokeWidth="2" strokeLinecap="round" />
        </g>
        <ellipse cx="26" cy="33" rx="4" ry="3" fill={INK} />
      </Face>
    </svg>
  );
}

// Часы со бегущей стрелкой — «срок горит». Вместо сердца: в рабочей
// переписке напоминание о времени востребовано, а признание в чувствах
// коллеге — не очень.
function Deadline({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <circle cx="26" cy="28" r="18" fill="#FFFFFF" stroke="#5C6672" strokeWidth="2.5" />
      <path d="M14 10 l6 5 M38 10 l-6 5" stroke="#5C6672" strokeWidth="2.5" strokeLinecap="round" />
      <rect x="25" y="16" width="2" height="12" rx="1" fill="#3A4149" />
      <g style={{ transformOrigin: "26px 28px", animation: "icq-spin 1.1s linear infinite" }}>
        <rect x="25.2" y="15" width="1.6" height="14" rx="0.8" fill="#E4573D" />
      </g>
      <circle cx="26" cy="28" r="2" fill="#3A4149" />
    </svg>
  );
}

function ThumbUp({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <g style={{ transformOrigin: "26px 40px", animation: "icq-nod 1.6s ease-in-out infinite" }}>
        <path d="M18 24 h6 l6 -12 q5 0 4 6 l-2 6 h8 q4 0 3 4 l-3 12 q-1 4 -5 4 H18 z"
          fill="#F2C24B" stroke={FACE_DARK} strokeWidth="1.8" />
        <rect x="10" y="24" width="8" height="20" rx="2" fill="#E8B437" stroke={FACE_DARK} strokeWidth="1.8" />
      </g>
    </svg>
  );
}

function Sleep({ size }) {
  return (
    <svg viewBox="0 0 52 52" width={size} height={size} className="icq-anim" aria-hidden>
      <Face>
        <path d="M15 21 q4 3 8 0" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M29 21 q4 3 8 0" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        <ellipse cx="26" cy="33" rx="3.5" ry="2.6" fill={INK} />
      </Face>
      <text x="38" y="14" fill="#6C7A89" fontSize="11" fontWeight="700"
        style={{ animation: "icq-beat 1.8s ease-in-out infinite" }}>Z</text>
    </svg>
  );
}

// Каталог: код → картинка и подпись. Подпись видна в подсказке при
// выборе — по одной картинке размером 24 пикселя не всегда понятно,
// что именно изображено.
export const ANIMATED = [
  { code: ":bang:", title: "Бьётся головой об стену", render: BangHead },
  { code: ":deal:", title: "Договорились", render: Handshake },
  { code: ":time:", title: "Срок горит", render: Deadline },
  { code: ":lol:", title: "Смеётся", render: Laugh },
  { code: ":wink:", title: "Подмигивает", render: Wink },
  { code: ":angry:", title: "Злится", render: Angry },
  { code: ":cry:", title: "Плачет", render: Cry },
  { code: ":dizzy:", title: "Голова кругом", render: Dizzy },
  { code: ":up:", title: "Одобряю", render: ThumbUp },
  { code: ":sleep:", title: "Спит", render: Sleep },
];

const BY_CODE = new Map(ANIMATED.map((e) => [e.code, e]));

// Регулярное выражение под все коды сразу: разбирать текст десятью
// проходами незачем.
export const ANIMATED_RE = new RegExp(
  `(${ANIMATED.map((e) => e.code.replace(/:/g, ":")).join("|")})`, "g");

export default function AnimatedEmoji({ code, size = 36 }) {
  useKeyframes();
  const entry = BY_CODE.get(code);
  if (!entry) return code;
  const Render = entry.render;
  return (
    <span title={entry.title} style={{ display: "inline-block", verticalAlign: "middle" }}>
      <Render size={size} />
    </span>
  );
}
