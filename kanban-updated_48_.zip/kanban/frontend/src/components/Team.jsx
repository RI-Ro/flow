import React, { useState } from "react";
import { Check, Video, Search, Plus, Trash2, Users, Pencil } from "lucide-react";
import { videoCallLink } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

export default function Team({ theme, directory, team, groups: initialGroups = [], currentUser, onClose, onSave, onOpenUser }) {
  const [selected, setSelected] = useState(new Set(team));
  // Две вкладки окна: весь состав команды и раскладка по группам.
  // Раскладка отдельно, потому что это другое действие: состав
  // отвечает на «кому я вообще могу поручать», группы — на «как мне
  // быстрее найти нужных людей».
  const [tab, setTab] = useState("members");
  const [groups, setGroups] = useState(() =>
    initialGroups.map((g) => ({ ...g, members: [...g.members] })));
  const [activeGroup, setActiveGroup] = useState(initialGroups[0]?.id || null);
  const [query, setQuery] = useState("");
  const [saving, setSaving] = useState(false);
  // Подтверждение вызова: в длинном списке промахнуться по соседней
  // строке особенно легко.
  const [confirmCall, setConfirmCall] = useState(null);

  // Себя в собственную команду добавлять незачем — исполнителем своей
  // задачи человек может быть и так.
  const pool = directory.filter((u) => u.id !== currentUser?.id);

  const q = query.trim().toLowerCase();
  const matched = q
    ? pool.filter((u) => `${u.fullName} ${u.position} ${u.phone}`.toLowerCase().includes(q))
    : pool;

  // При большом справочнике рисовать несколько сотен строк разом
  // бессмысленно: список невозможно просмотреть глазами, а браузер
  // заметно тормозит. До ввода запроса показываем уже выбранных
  // и небольшую выборку остальных — этого хватает, чтобы понять, что
  // список не пуст, а дальше человек ищет.
  const LIMIT = 60;
  const preselected = matched.filter((u) => selected.has(u.id));
  const rest = matched.filter((u) => !selected.has(u.id));
  const list = q
    ? matched.slice(0, LIMIT)
    : [...preselected, ...rest.slice(0, Math.max(0, LIMIT - preselected.length))];
  const hidden = matched.length - list.length;

  const toggle = (id) => setSelected((prev) => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const save = async () => {
    setSaving(true);
    // Новые группы уходят без id — сервер выдаст его сам. Временные
    // идентификаторы с префиксом нужны только для работы в окне.
    const payload = groups.map((g) => ({
      id: String(g.id).startsWith("new-") ? undefined : g.id,
      title: g.title,
      members: g.members,
    }));
    await onSave([...selected], payload);
    setSaving(false);
  };

  const addGroup = () => {
    const id = `new-${Date.now()}`;
    setGroups((prev) => [...prev, { id, title: "Новая группа", members: [] }]);
    setActiveGroup(id);
  };
  const renameGroup = (id, title) =>
    setGroups((prev) => prev.map((g) => (g.id === id ? { ...g, title } : g)));
  const removeGroup = (id) => {
    setGroups((prev) => prev.filter((g) => g.id !== id));
    setActiveGroup((cur) => (cur === id ? null : cur));
  };
  const toggleInGroup = (groupId, userId) => {
    setGroups((prev) => prev.map((g) => {
      if (g.id !== groupId) return g;
      const has = g.members.includes(userId);
      return { ...g, members: has ? g.members.filter((x) => x !== userId) : [...g.members, userId] };
    }));
    // В группу можно включить только участника команды — отмечаем его
    // в составе сразу, чтобы человек не гадал, почему группа не
    // сохранилась.
    setSelected((prev) => new Set(prev).add(userId));
  };

  const current = groups.find((g) => g.id === activeGroup) || null;
  const teamList = [...selected].map((id) => directory.find((u) => u.id === id)).filter(Boolean)
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  return (
    // Шире прежнего: раскладке по группам нужны две колонки — список
    // групп и участники выбранной.
    <Modal theme={theme} onClose={onClose} padded={false} width="max-w-2xl" geometryKey="team">
      <div className="p-5 pb-3">
        <ModalHeader theme={theme} title="Моя команда" subtitle="Отмеченных сотрудников можно назначать исполнителями задач" onClose={onClose} />
        <div className="flex gap-1.5 mb-3">
          {[["members", `Состав · ${selected.size}`], ["groups", `Группы · ${groups.length}`]].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)}
              style={{
                background: tab === id ? theme.accent : theme.surfaceAlt,
                color: tab === id ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="rounded-lg px-3 py-1.5 text-[12.5px] font-medium">{label}</button>
          ))}
        </div>
        {tab === "members" && (
        <div className="relative">
          <Search size={14} style={{ color: theme.textMuted }} className="absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Имя, должность или телефон" style={inputStyle(theme)} className="w-full pl-8 pr-3 py-2 rounded-lg text-[13px] outline-none" />
        </div>
        )}
      </div>

      {tab === "groups" && (
        <GroupsEditor theme={theme} groups={groups} current={current} teamList={teamList}
          onSelect={setActiveGroup} onAdd={addGroup} onRename={renameGroup}
          onRemove={removeGroup} onToggle={toggleInGroup} />
      )}

      {tab === "members" && (
      <div style={{ borderColor: theme.border }} className="border-t max-h-[50vh] overflow-y-auto px-3 py-2">
        {list.map((u) => (
          <div key={u.id} style={{ background: selected.has(u.id) ? theme.surfaceAlt : "transparent" }} className="flex items-center gap-2.5 p-2 rounded-xl mb-1">
            <button onClick={() => onOpenUser(u)} className="shrink-0" title="Карточка сотрудника"><Avatar user={u} size={32} theme={theme} /></button>
            <button onClick={() => onOpenUser(u)} className="flex-1 min-w-0 text-left">
              <div style={{ color: theme.text, textDecoration: u.deleted ? "line-through" : "none", opacity: u.deleted ? 0.6 : 1 }} className="text-[13px] font-medium truncate">{u.fullName}</div>
              <div style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{u.deleted ? "Учётная запись удалена" : u.position || "Должность не указана"}</div>
            </button>
            {u.phone && !u.deleted && (
              <button onClick={() => setConfirmCall(u)}
                style={{ color: theme.accent, border: `1px solid ${theme.border}` }}
                className="flex items-center gap-1 text-[11.5px] px-2 py-1 rounded-lg shrink-0"
                title={`Видеозвонок: ${u.phone}`}>
                <Video size={12} /> Видео
              </button>
            )}
            {!u.deleted && (
              <button onClick={() => toggle(u.id)} style={{ background: selected.has(u.id) ? theme.accent : "transparent", border: `1.5px solid ${selected.has(u.id) ? theme.accent : theme.border}` }} className="w-[18px] h-[18px] rounded-md flex items-center justify-center shrink-0" title={selected.has(u.id) ? "Убрать из команды" : "Добавить в команду"}>
                {selected.has(u.id) && <Check size={12} color={theme.accentText} />}
              </button>
            )}
          </div>
        ))}
        {list.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-6">Никого не найдено.</p>}

        {hidden > 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12px] text-center py-3 leading-relaxed">
            Показаны первые {list.length} из {matched.length}.<br />
            Уточните запрос, чтобы найти нужного сотрудника.
          </p>
        )}
      </div>
      )}

      <div style={{ borderColor: theme.border }} className="border-t p-4 flex items-center gap-2">
        <span style={{ color: theme.textMuted }} className="text-[12px] flex-1">Выбрано: {selected.size}</span>
        <button onClick={onClose} style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }} className="rounded-lg px-4 py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={save} disabled={saving} style={{ background: theme.accent, color: theme.accentText }} className="rounded-lg px-4 py-2.5 text-[13px] font-semibold disabled:opacity-50">{saving ? "Сохраняем…" : "Сохранить"}</button>
      </div>

      {confirmCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеозвонок?"
          message={`Вызов будет отправлен: ${confirmCall.fullName} (${confirmCall.phone}).`}
          confirmLabel="Позвонить"
          danger={false}
          onCancel={() => setConfirmCall(null)}
          onConfirm={() => {
            const href = videoCallLink(confirmCall);
            setConfirmCall(null);
            if (href) window.location.href = href;
          }} />
      )}
    </Modal>
  );
}

// Раскладка команды по группам.
//
// Слева — список групп, справа — участники команды с отметками для
// выбранной группы. Один человек может стоять в нескольких группах:
// рядом с именем подписано, где ещё он состоит, чтобы раскладка была
// видна целиком, не перебирая группы по одной.
function GroupsEditor({ theme, groups, current, teamList, onSelect, onAdd, onRename, onRemove, onToggle }) {
  const [editing, setEditing] = useState(null);

  return (
    <div style={{ borderColor: theme.border }} className="border-t flex min-h-[320px] max-h-[55vh]">
      <div style={{ borderColor: theme.border }} className="w-[200px] shrink-0 border-r overflow-y-auto p-2">
        {groups.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12px] px-1 py-3 leading-relaxed">
            Групп пока нет. Они помогают быстро выбирать исполнителей: раскрыл группу — отметил нужных.
          </p>
        )}
        {groups.map((g) => (
          <div key={g.id}
            style={{ background: current?.id === g.id ? theme.surfaceAlt : "transparent" }}
            className="rounded-lg mb-0.5 group">
            {editing === g.id ? (
              <input autoFocus value={g.title}
                onChange={(e) => onRename(g.id, e.target.value)}
                onBlur={() => setEditing(null)}
                onKeyDown={(e) => { if (e.key === "Enter") setEditing(null); }}
                style={inputStyle(theme)}
                className="w-full rounded-md px-2 py-1 text-[12.5px] outline-none" />
            ) : (
              <div className="flex items-center gap-1 px-2 py-1.5">
                <button onClick={() => onSelect(g.id)} className="flex-1 min-w-0 text-left flex items-center gap-1.5">
                  <Users size={12} style={{ color: theme.accent }} />
                  <span style={{ color: theme.text }} className="text-[12.5px] truncate">{g.title || "Без названия"}</span>
                  <span style={{ color: theme.textMuted }} className="text-[10.5px] shrink-0">{g.members.length}</span>
                </button>
                <button onClick={() => setEditing(g.id)} style={{ color: theme.textMuted }}
                  className="opacity-0 group-hover:opacity-100" title="Переименовать"><Pencil size={11} /></button>
                <button onClick={() => onRemove(g.id)} style={{ color: theme.danger }}
                  className="opacity-0 group-hover:opacity-100" title="Удалить группу"><Trash2 size={11} /></button>
              </div>
            )}
          </div>
        ))}
        <button onClick={onAdd} style={{ color: theme.accent }}
          className="flex items-center gap-1 text-[12px] font-medium px-2 py-1.5 mt-1">
          <Plus size={13} /> Группа
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {!current && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-8 text-center">
            Выберите группу слева или создайте новую.
          </p>
        )}
        {current && teamList.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-8 text-center">
            В команде пока никого нет. Добавьте людей на вкладке «Состав».
          </p>
        )}
        {current && teamList.map((u) => {
          const on = current.members.includes(u.id);
          const elsewhere = groups.filter((g) => g.id !== current.id && g.members.includes(u.id));
          return (
            <button key={u.id} onClick={() => onToggle(current.id, u.id)}
              style={{ background: on ? theme.surfaceAlt : "transparent" }}
              className="w-full flex items-center gap-2 rounded-lg px-2 py-1.5 text-left mb-0.5">
              <span style={{
                  background: on ? theme.accent : "transparent",
                  borderColor: on ? theme.accent : theme.border,
                }}
                className="w-4 h-4 rounded border flex items-center justify-center shrink-0">
                {on && <Check size={11} color={theme.accentText} strokeWidth={3} />}
              </span>
              <Avatar user={u} size={24} theme={theme} />
              <span className="flex-1 min-w-0">
                <span style={{ color: theme.text }} className="text-[12.5px] block truncate">{u.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[10.5px] block truncate">
                  {u.position || "Должность не указана"}
                  {elsewhere.length > 0 && (
                    <span style={{ color: theme.accent }}> · также в: {elsewhere.map((g) => g.title).join(", ")}</span>
                  )}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
