import React from "react";
import { PRIORITIES, orderedBoards, resolveUser } from "../lib/theme.js";
import { countFilters, emptyFilters } from "../lib/filters.js";
import { Chip, inputStyle } from "../lib/ui.jsx";

// Панель отбора задач — одна на все вкладки.
//
// За образец взят фильтр проекта: он появился первым и оказался
// удачным. Раньше он же был и единственным: во «Всех задачах» стоял
// свой набор полей, а в календаре и «Входящих» фильтровать было нечем.
// Человеку приходилось заново разбираться, что и где можно отобрать.
//
// Сортировка сюда не входит: она нужна там, где есть порядок
// (доска, список), и не имеет смысла в календаре, где порядок задан
// датами. Поэтому её группа передаётся снаружи через extra.

const STATUSES = [
  ["all", "Любой"],
  ["active", "В работе"],
  ["done", "Завершённые"],
  ["overdue", "Просроченные"],
];

export default function TaskFilters({
  theme, filters, setFilters, directory, people = [], tags = [], boards = null, extra = null,
}) {
  const toggle = (kind, value) => setFilters((f) => {
    const next = new Set(f[kind]);
    if (next.has(value)) next.delete(value);
    else next.add(value);
    return { ...f, [kind]: next };
  });

  const active = countFilters(filters);

  return (
    <div style={{ borderColor: theme.border, background: theme.surface }}
      className="border-b px-4 py-3 flex flex-wrap gap-4 relative z-30">

      {/* Проект — только там, где в списке задачи из разных проектов.
          На доске выбирать проект бессмысленно: он уже выбран. */}
      {boards && (
        <FilterGroup theme={theme} label="Проект">
          <select value={filters.boardId}
            onChange={(e) => setFilters((f) => ({ ...f, boardId: e.target.value }))}
            style={inputStyle(theme)}
            className="rounded-lg px-2 py-1 text-[11.5px] outline-none min-w-[160px]">
            <option value="">Все проекты</option>
            {orderedBoards(boards).map((b) => (
              <option key={b.id} value={b.id}>
                {"\u00A0\u00A0".repeat(b.depth) + b.title}
              </option>
            ))}
          </select>
        </FilterGroup>
      )}

      <FilterGroup theme={theme} label="Статус">
        {STATUSES.map(([id, label]) => (
          <Chip key={id} theme={theme} active={(filters.status || "all") === id}
            onClick={() => setFilters((f) => ({ ...f, status: id }))}>{label}</Chip>
        ))}
      </FilterGroup>

      <FilterGroup theme={theme} label="Приоритет">
        {Object.entries(PRIORITIES).map(([k, v]) => (
          <Chip key={k} theme={theme} active={filters.priority.has(k)}
            onClick={() => toggle("priority", k)}>{v.label}</Chip>
        ))}
      </FilterGroup>

      {people.length > 0 && (
        <FilterGroup theme={theme} label="Исполнитель">
          {people.map((id) => {
            const u = resolveUser(directory, id);
            return (
              <Chip key={id} theme={theme} active={filters.assignee.has(id)}
                title={u.fullName} onClick={() => toggle("assignee", id)}>
                {u.fullName.split(" ")[0]}
              </Chip>
            );
          })}
        </FilterGroup>
      )}

      {tags.length > 0 && (
        <FilterGroup theme={theme} label="Теги">
          {tags.map((t) => (
            <Chip key={t} theme={theme} active={filters.tag.has(t)}
              onClick={() => toggle("tag", t)}>#{t}</Chip>
          ))}
        </FilterGroup>
      )}

      <FilterGroup theme={theme} label="Срок исполнения">
        <div className="flex items-center gap-1.5">
          <input type="date" value={filters.dueFrom}
            onChange={(e) => setFilters((f) => ({ ...f, dueFrom: e.target.value }))}
            style={inputStyle(theme)} className="rounded-lg px-2 py-1 text-[11.5px] outline-none"
            title="Срок не раньше" />
          <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>
          <input type="date" value={filters.dueTo}
            onChange={(e) => setFilters((f) => ({ ...f, dueTo: e.target.value }))}
            style={inputStyle(theme)} className="rounded-lg px-2 py-1 text-[11.5px] outline-none"
            title="Срок не позже" />
        </div>
      </FilterGroup>

      {/* Дата завершения — тем же видом, что срок: два поля «с — по».
          Выбор диапазона сам по себе оставляет только завершённые —
          у незавершённых этой даты нет. */}
      <FilterGroup theme={theme} label="Дата завершения">
        <div className="flex items-center gap-1.5">
          <input type="date" value={filters.doneFrom || ""}
            onChange={(e) => setFilters((f) => ({ ...f, doneFrom: e.target.value }))}
            style={inputStyle(theme)} className="rounded-lg px-2 py-1 text-[11.5px] outline-none"
            title="Завершена не раньше" />
          <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>
          <input type="date" value={filters.doneTo || ""}
            onChange={(e) => setFilters((f) => ({ ...f, doneTo: e.target.value }))}
            style={inputStyle(theme)} className="rounded-lg px-2 py-1 text-[11.5px] outline-none"
            title="Завершена не позже" />
        </div>
      </FilterGroup>

      {extra}

      {active > 0 && (
        <button onClick={() => setFilters(emptyFilters())}
          style={{ color: theme.danger }} className="text-[12px] font-medium self-center">
          Сбросить всё
        </button>
      )}
    </div>
  );
}

export function FilterGroup({ theme, label, children }) {
  return (
    <div>
      <div style={{ color: theme.textMuted }} className="text-[11px] font-medium uppercase tracking-wide mb-1">{label}</div>
      <div className="flex flex-wrap gap-1.5 max-w-sm">{children}</div>
    </div>
  );
}
