import React, { useMemo, useState } from "react";
import { ChevronDown, ChevronRight, Check, Users } from "lucide-react";
import { resolveUser } from "../lib/theme.js";
import { Avatar, inputStyle } from "../lib/ui.jsx";

// Выбор исполнителей с группами команды.
//
// Один компонент на все места, где назначают исполнителей: форма
// задачи (создание и правка) и окно «Поручить». Раньше в каждом месте
// был свой список, и правила расходились.
//
// Устройство:
//
//   • сверху — группы, каждую можно раскрыть; в группе есть кнопка
//     «выбрать всех» — ради неё группы в основном и заводят;
//   • последним — «Моя команда»: вся команда одним раскрывающимся
//     списком, тоже с «выбрать всех». Люди из групп в нём повторяются —
//     и так и нужно: это способ поручить задачу всем разом и место, где
//     найдутся те, кто ни в одну группу не входит;
//   • выбор общий. Человек, отмеченный в одной группе, отмечен и во
//     всех остальных, где он есть, — и там дополнительно подписано,
//     через какую группу его выбрали. Иначе, раскрыв вторую группу,
//     легко решить, что человек не выбран, и «выбрать» его ещё раз —
//     на деле сняв.
//
// Поиск ищет по всем сразу и показывает плоский список: когда имя
// известно, группы только мешают.

// onChange получает новый список выбранных целиком. Именно он
// используется для «выбрать всех»: массовый выбор через серию onToggle
// ломался в форме задачи — каждый вызов видел один и тот же старый
// список, и в итоге применялся только последний. onToggle оставлен для
// поштучного выбора там, где удобнее он.
export default function AssigneePicker({
  theme, directory, candidates, groups = [], selected, onToggle, onChange, outside = new Set(),
}) {
  const [open, setOpen] = useState(() => new Set());
  const [q, setQ] = useState("");

  const candidateSet = useMemo(() => new Set(candidates), [candidates]);

  // Группы в пределах кандидатов: человек мог выпасть из команды, а
  // группа осталась с его идентификатором в клиентском кэше.
  const visibleGroups = useMemo(
    () => groups
      .map((g) => ({ ...g, members: g.members.filter((id) => candidateSet.has(id)) }))
      .filter((g) => g.members.length > 0),
    [groups, candidateSet]);

  // «Моя команда» — все кандидаты одним раскрывающимся списком, с тем
  // же «выбрать всех», что и у групп. Отдельной секцией, а не хвостом
  // «без группы»: люди из групп в ней тоже есть, и именно так удобно
  // поручить задачу всей команде разом.
  const TEAM_ID = "__team__";
  const sections = [...visibleGroups, { id: TEAM_ID, title: "Моя команда", members: candidates }];

  // В каких группах состоит человек — для подписи «выбран в группе …».
  const groupsOf = useMemo(() => {
    const map = new Map();
    for (const g of visibleGroups) {
      for (const id of g.members) {
        if (!map.has(id)) map.set(id, []);
        map.get(id).push(g.title);
      }
    }
    return map;
  }, [visibleGroups]);

  // Одиночный выбор — через onChange, если он есть: так же надёжно, как
  // массовый, и не зависит от того, как вызывающая сторона хранит
  // состояние.
  const toggleOne = (id) => {
    if (onChange) {
      onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
    } else {
      onToggle?.(id);
    }
  };

  // Массовый выбор и снятие — одним изменением списка.
  const setMany = (ids, on) => {
    if (onChange) {
      const cur = new Set(selected);
      ids.forEach((id) => (on ? cur.add(id) : cur.delete(id)));
      onChange([...cur]);
      return;
    }
    // Запасной путь для старых вызовов без onChange.
    ids.forEach((id) => {
      if (selected.includes(id) !== on) onToggle?.(id);
    });
  };

  const toggleOpen = (id) => setOpen((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });

  const needle = q.trim().toLowerCase();

  const row = (id, currentGroup) => {
    const u = resolveUser(directory, id);
    const active = selected.includes(id);
    // Подпись о других группах — только у выбранного и только если
    // групп у него больше одной: иначе это шум на каждой строке.
    const elsewhere = active
      ? (groupsOf.get(id) || []).filter((t) => t !== currentGroup)
      : [];
    return (
      <button key={`${currentGroup || "-"}-${id}`} type="button"
        onClick={() => !u.deleted && toggleOne(id)} disabled={u.deleted}
        style={{
          background: active ? theme.surfaceAlt : "transparent",
          borderColor: active ? theme.accent : "transparent",
          opacity: u.deleted ? 0.45 : 1,
        }}
        className="w-full flex items-center gap-2 rounded-lg px-2 py-1.5 text-left border mb-0.5">
        <span style={{
            background: active ? theme.accent : "transparent",
            borderColor: active ? theme.accent : theme.border,
          }}
          className="w-4 h-4 rounded border flex items-center justify-center shrink-0">
          {active && <Check size={11} color={theme.accentText} strokeWidth={3} />}
        </span>
        <Avatar user={u} size={22} theme={theme} />
        <span className="flex-1 min-w-0">
          <span style={{ color: theme.text }} className="text-[12.5px] block truncate">
            {u.fullName}
            {outside.has(id) && (
              <span title="Назначен не из вашей команды"
                style={{ background: theme.warning }}
                className="inline-block w-1.5 h-1.5 rounded-full ml-1.5 align-middle" />
            )}
          </span>
          <span style={{ color: theme.textMuted }} className="text-[10.5px] block truncate">
            {u.position || "Должность не указана"}
            {elsewhere.length > 0 && (
              <span style={{ color: theme.accent }}> · выбран также в: {elsewhere.join(", ")}</span>
            )}
          </span>
        </span>
      </button>
    );
  };

  // Поиск — плоский список по всем кандидатам.
  if (needle) {
    const found = candidates.filter((id) => {
      const u = resolveUser(directory, id);
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    });
    return (
      <div>
        <Search theme={theme} q={q} setQ={setQ} />
        {found.length === 0
          ? <p style={{ color: theme.textMuted }} className="text-[12px] py-3 text-center">Никого не нашлось.</p>
          : found.map((id) => row(id, null))}
      </div>
    );
  }

  return (
    <div>
      <Search theme={theme} q={q} setQ={setQ} />

      {sections.map((g) => {
        const isOpen = open.has(g.id);
        const pickable = g.members.filter((id) => !resolveUser(directory, id).deleted);
        const chosen = g.members.filter((id) => selected.includes(id)).length;
        const allChosen = pickable.length > 0 && pickable.every((id) => selected.includes(id));
        const isTeam = g.id === TEAM_ID;
        return (
          <div key={g.id} style={{ borderColor: theme.border }}
            className={`border rounded-lg mb-1.5 ${isTeam && visibleGroups.length > 0 ? "mt-2" : ""}`}>
            <div className="flex items-center gap-2 px-2 py-1.5">
              <button type="button" onClick={() => toggleOpen(g.id)}
                className="flex items-center gap-1.5 flex-1 min-w-0 text-left">
                {isOpen
                  ? <ChevronDown size={14} style={{ color: theme.textMuted }} />
                  : <ChevronRight size={14} style={{ color: theme.textMuted }} />}
                <Users size={13} style={{ color: isTeam ? theme.textMuted : theme.accent }} />
                <span style={{ color: theme.text }} className="text-[12.5px] font-semibold truncate">{g.title}</span>
                <span style={{ color: theme.textMuted }} className="text-[11px] shrink-0">
                  {chosen > 0 ? `${chosen} из ${g.members.length}` : g.members.length}
                </span>
              </button>
              {/* «Выбрать всех» — ради этого группы и заводят. Снятие
                  касается только участников этого списка: выбранных
                  через другие группы оно не трогает. Удалённые учётные
                  записи в массовый выбор не попадают — назначать их
                  нельзя. */}
              {pickable.length > 0 && (
                <button type="button"
                  onClick={() => setMany(allChosen ? g.members : pickable, !allChosen)}
                  style={{ color: theme.accent }} className="text-[11px] font-medium shrink-0">
                  {allChosen ? "снять всех" : "выбрать всех"}
                </button>
              )}
            </div>
            {isOpen && (
              <div style={{ borderColor: theme.border }} className="border-t px-1 py-1">
                {g.members.length === 0
                  ? <p style={{ color: theme.textMuted }} className="text-[12px] px-2 py-2">Список пуст.</p>
                  : g.members.map((id) => row(id, isTeam ? null : g.title))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Search({ theme, q, setQ }) {
  return (
    <input value={q} onChange={(e) => setQ(e.target.value)}
      placeholder="Имя или должность"
      style={inputStyle(theme)}
      className="w-full rounded-lg px-3 py-1.5 text-[12.5px] outline-none mb-2" />
  );
}
