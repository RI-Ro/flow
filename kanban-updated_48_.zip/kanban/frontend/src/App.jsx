import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutGrid, Search, Filter, Bell, Plus, ChevronDown, Palette, Settings, Eye, EyeOff,
  Inbox, UserPlus, LogOut, Check, Link2, ShieldCheck, FileSpreadsheet, UserCheck, Volume2, VolumeX, Zap, Menu, UsersRound,
} from "lucide-react";

import { api, hasSession, onAuthLost } from "./lib/api.js";
import { realtimeConnect, realtimeDisconnect, onRealtimeMessage, onRealtimeStatus } from "./lib/realtime.js";
import { subscribePresence } from "./lib/presence.js";
import { playEventSound, primeAudio, loadSoundSettings, saveSoundSettings, SOUND_EVENT_LABELS } from "./lib/sound.js";
import { exportTasksToExcel } from "./lib/excel.js";
import { THEMES, THEME_ORDER, ALL_BACKGROUNDS, bgById, PRIORITIES, ROLE_LABEL, isOverdue, resolveUser, bgImageUrl, bgThumbUrl, fmtDate } from "./lib/theme.js";
import { Avatar, ChatToast, Chip, ConfirmDialog, Field, Modal, ModalHeader, Toggle, Toast, Spinner, UserCard, RealtimeDot, inputStyle } from "./lib/ui.jsx";
import { countFilters, loadFilters, matchesFilters, saveFilters } from "./lib/filters.js";

import Login from "./components/Login.jsx";
import { BoardView, InboxView } from "./components/Board.jsx";
import TaskModal from "./components/TaskModal.jsx";
import TaskDetail from "./components/TaskDetail.jsx";
import BoardSettings from "./components/BoardSettings.jsx";
import Team from "./components/Team.jsx";
import Notifications from "./components/Notifications.jsx";
import Admin from "./components/Admin.jsx";
import Delegation from "./components/Delegation.jsx";
import Dashboard from "./components/Dashboard.jsx";
import Calendar from "./components/Calendar.jsx";
import Templates from "./components/Templates.jsx";
import ProjectTree from "./components/ProjectTree.jsx";
import ColumnView from "./components/ColumnView.jsx";
import CopyTaskModal from "./components/CopyTaskModal.jsx";
import TaskFilters, { FilterGroup } from "./components/TaskFilters.jsx";
import TaskReminderModal from "./components/TaskReminderModal.jsx";
import Chats from "./components/Chats.jsx";
import AllTasks from "./components/AllTasks.jsx";
import Reminders from "./components/Reminders.jsx";
import AlarmModal from "./components/AlarmModal.jsx";

const INBOX = "inbox";
const DASHBOARD = "dashboard";
const CALENDAR = "calendar";
const ALLTASKS = "alltasks";
const REMINDERS = "reminders";
const CHATS = "chats";
const READY = "ready";
const THEME_KEY = "kanban.theme";
const HIDE_DONE_KEY = "kanban.hideCompleted";
const FILTERS_KEY = "kanban.filters";
const SORT_KEY = "kanban.boardSort";

// Ссылка на задачу: /tasks/<id>. Раздел из неё не следует — задача
// может лежать в любом проекте, а человек, которому её прислали, мог
// вообще не иметь доступа к доске. Поэтому идентификатор запоминается
// отдельно и открывается карточкой поверх того раздела, где человек
// оказался.
export function readTaskLink() {
  const m = window.location.pathname.match(/^\/tasks\/([0-9a-f-]{36})/i);
  return m ? m[1] : null;
}

function readRoute() {
  const match = window.location.pathname.match(/^\/b\/([0-9a-f-]{36})/i);
  if (match) return { view: "board", boardId: match[1] };
  if (window.location.pathname.startsWith("/inbox")) return { view: INBOX, boardId: null };
  if (window.location.pathname.startsWith("/dashboard")) return { view: DASHBOARD, boardId: null };
  if (window.location.pathname.startsWith("/calendar")) return { view: CALENDAR, boardId: null };
  if (window.location.pathname.startsWith("/all-tasks")) return { view: ALLTASKS, boardId: null };
  if (window.location.pathname.startsWith("/reminders")) return { view: REMINDERS, boardId: null };
  if (window.location.pathname.startsWith("/chats")) return { view: CHATS, boardId: null };
  if (window.location.pathname.startsWith("/ready")) return { view: READY, boardId: null };
  return { view: "none", boardId: null };
}

function pushRoute(route, replace = false) {
  const path = route.view === INBOX ? "/inbox"
    : route.view === DASHBOARD ? "/dashboard"
    : route.view === CALENDAR ? "/calendar"
    : route.view === ALLTASKS ? "/all-tasks"
    : route.view === REMINDERS ? "/reminders"
    : route.view === CHATS ? "/chats"
    : route.view === READY ? "/ready"
    : route.view === "board" ? `/b/${route.boardId}` : "/";
  if (window.location.pathname === path) return;
  window.history[replace ? "replaceState" : "pushState"]({}, "", path);
}

export default function App() {
  const [themeId, setThemeId] = useState(() => localStorage.getItem(THEME_KEY) || "balun");
  const theme = THEMES[themeId] || THEMES.balun;

  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);

  const [directory, setDirectory] = useState([]);
  const [team, setTeam] = useState([]);
  const [boards, setBoards] = useState([]);

  const [route, setRoute] = useState(readRoute);
  const [board, setBoard] = useState(null);
  const [columns, setColumns] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loadingBoard, setLoadingBoard] = useState(false);

  const [search, setSearch] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  // Фильтры переживают перезагрузку: человек настроил вид доски под
  // себя, и терять эту настройку при каждом обновлении страницы
  // раздражает. Set в JSON не сериализуется — храним массивами.
  const [filters, setFilters] = useState(() => loadFilters(FILTERS_KEY));

  // Порядок сортировки внутри проекта. Хранится отдельно от фильтров:
  // это настройка вида, а не отбора, и сбрасывать её вместе с фильтрами
  // было бы неожиданно.
  const [boardSort, setBoardSort] = useState(() => localStorage.getItem(SORT_KEY) || "position");
  useEffect(() => { localStorage.setItem(SORT_KEY, boardSort); }, [boardSort]);

  useEffect(() => { saveFilters(FILTERS_KEY, filters); }, [filters]);
  const [hideCompleted, setHideCompleted] = useState(() => localStorage.getItem(HIDE_DONE_KEY) === "true");

  const [menu, setMenu] = useState(null);
  // Левое меню проектов сворачивается в «гамбургер» и запоминает
  // состояние между сессиями (п.3).
  const [sidebarCollapsed, setSidebarCollapsed] = useState(
    () => localStorage.getItem("kanban.sidebarCollapsed") === "true");
  useEffect(() => {
    localStorage.setItem("kanban.sidebarCollapsed", String(sidebarCollapsed));
  }, [sidebarCollapsed]);
  // Ширина левого меню тянется мышью и сохраняется локально (п.7).
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const v = parseInt(localStorage.getItem("kanban.sidebarWidth") || "", 10);
    return Number.isFinite(v) && v >= 200 && v <= 560 ? v : 264;
  });
  useEffect(() => {
    localStorage.setItem("kanban.sidebarWidth", String(sidebarWidth));
  }, [sidebarWidth]);
  // Активное перетаскивание границы сайдбара.
  const sidebarResizing = useRef(false);
  useEffect(() => {
    const onMove = (e) => {
      if (!sidebarResizing.current) return;
      const w = Math.min(560, Math.max(200, e.clientX));
      setSidebarWidth(w);
    };
    const onUp = () => {
      if (sidebarResizing.current) {
        sidebarResizing.current = false;
        document.body.style.userSelect = "";
        document.body.style.cursor = "";
      }
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, []);
  const [unread, setUnread] = useState(0);
  const [wsStatus, setWsStatus] = useState("disconnected");
  const [toast, setToast] = useState(null);

  const [taskModal, setTaskModal] = useState(null);
  const [detailId, setDetailId] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [newBoardOpen, setNewBoardOpen] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [delegationOpen, setDelegationOpen] = useState(false);
  const [soundOpen, setSoundOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [openColumn, setOpenColumn] = useState(null);
  // Задача, для которой открыта модалка копирования (п.4).
  // Копирование и перенос задачи — одно окно в двух режимах:
  // { task, mode: "copy" | "move" }.
  const [transfer, setTransfer] = useState(null);
  // Задача, для которой заводят напоминание из карточки.
  const [reminderFor, setReminderFor] = useState(null);
  // Очередь сработавших напоминаний. Именно очередь, а не одно:
  // вернувшись к столу после перерыва, человек должен разобрать все
  // прозвонившие будильники, а не только последний.
  const [alarms, setAlarms] = useState([]);
  // Непрочитанные сообщения — числом рядом с разделом «Сообщения».
  // Значение приходит из самой вкладки, когда она загружает список
  // чатов, и уточняется по событиям переписки.
  const [chatUnread, setChatUnread] = useState(0);
  // Кто в сети: список общий на приложение, здесь он нужен карточке
  // сотрудника и шапке.
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  // Группы личной команды — для выбора исполнителей задачи.
  const [teamGroups, setTeamGroups] = useState([]);
  // Сколько задач ждёт приёмки — число рядом с разделом. Считает
  // сервер: спрашиваем страницу в одну запись и берём total, чтобы не
  // тащить в браузер сам список ради счётчика.
  const [readyCount, setReadyCount] = useState(0);
  // Всплывающее сообщение о задаче, которую сдали.
  const [readyToast, setReadyToast] = useState(null);
  useEffect(() => subscribePresence(setOnlineUsers), []);
  // Всплывающее сообщение о новом сообщении в переписке: { chatId,
  // author, chatTitle }. Живёт в App, а не во вкладке чатов, — именно
  // потому, что нужно, когда вкладка закрыта.
  const [chatToast, setChatToast] = useState(null);
  // Чат, который нужно открыть при переходе во вкладку переписки.
  const [openChatId, setOpenChatId] = useState(null);
  // Задача, форму которой нужно открыть, как только загрузится её
  // проект: { boardId, taskId }. Используется после копирования —
  // см. onCopied ниже.
  const [pendingEdit, setPendingEdit] = useState(null);
  // Задача для подробного вида, догруженная отдельно: в дашборде и
  // календаре список задач доски не загружен, и без этого нажатие на
  // задачу не открывало ничего.
  const [fetchedTask, setFetchedTask] = useState(null);
  // Действующие замещения по всем сотрудникам — для карточки человека.
  const [activeDelegations, setActiveDelegations] = useState([]);
  // Настройки звука держим в состоянии, а не читаем из localStorage на
  // каждое событие: обработчики срабатывают часто, а чтение и разбор
  // JSON на каждый чужой комментарий — лишняя работа.
  const [sound, setSound] = useState(loadSoundSettings);

  // Подсветка изменившихся карточек: id → { color }. Гаснет сама через
  // несколько секунд, а также при открытии задачи — если человек уже
  // посмотрел, помечать её как «новую» незачем.
  const [highlights, setHighlights] = useState({});
  const highlightTimers = React.useRef({});

  // Ссылка на flashTask: upsertTask объявлена выше по файлу и не может
  // сослаться на неё напрямую, а менять порядок объявлений ради этого
  // значило бы тянуть за собой половину компонента.
  const flashTaskRef = React.useRef(null);

  const flashTask = useCallback((taskId, color) => {
    setHighlights((prev) => ({ ...prev, [taskId]: { color } }));
    clearTimeout(highlightTimers.current[taskId]);
    highlightTimers.current[taskId] = setTimeout(() => {
      setHighlights((prev) => {
        const next = { ...prev };
        delete next[taskId];
        return next;
      });
      delete highlightTimers.current[taskId];
    }, 6000);
  }, []);

  useEffect(() => { flashTaskRef.current = flashTask; }, [flashTask]);

  // Таймеры переживают размонтирование, если их не убрать: обновление
  // состояния после ухода со страницы бессмысленно и шумит в консоли.
  useEffect(() => () => {
    Object.values(highlightTimers.current).forEach(clearTimeout);
  }, []);

  // Недавно изменившиеся задачи. Подсветка спокойная — тонкая полоса
  // слева у карточки, гаснущая сама. Мигание на доске из полусотни
  // карточек превращается в гирлянду, и его начинают игнорировать
  // вместе с важными событиями.
  const [recent, setRecent] = useState({});   // taskId -> тип изменения

  // Каждая отметка живёт 12 секунд: этого хватает, чтобы заметить
  // изменение, вернувшись к экрану, но не настолько долго, чтобы к
  // концу дня подсвеченной оказалась вся доска.
  const markRecent = useCallback((taskId, kind) => {
    if (!taskId) return;
    setRecent((prev) => ({ ...prev, [taskId]: kind }));
    setTimeout(() => {
      setRecent((prev) => {
        if (prev[taskId] !== kind) return prev;   // успело смениться на другое
        const next = { ...prev };
        delete next[taskId];
        return next;
      });
    }, 12000);
  }, []);

  useEffect(() => { saveSoundSettings(sound); }, [sound]);

  // Разблокировать звук на первом жесте: события приходят по сети, а
  // не из клика, и без этого браузер держит аудио выключенным.
  useEffect(() => { primeAudio(); }, []);
  const [userCard, setUserCard] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [bgStamp, setBgStamp] = useState(Date.now());

  const showError = useCallback((message) => setToast({ message, kind: "error" }), []);
  const showInfo = useCallback((message) => setToast({ message, kind: "ok" }), []);

  /* ------------------------------------------------------------ сессия */

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!hasSession()) { setBooting(false); return; }
      try {
        const restored = await api.restore();
        if (alive) setUser(restored);
      } catch {
        // сессия истекла — покажем экран входа
      } finally {
        if (alive) setBooting(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => onAuthLost(() => setUser(null)), []);
  useEffect(() => { localStorage.setItem(THEME_KEY, themeId); }, [themeId]);
  useEffect(() => { localStorage.setItem(HIDE_DONE_KEY, String(hideCompleted)); }, [hideCompleted]);

  useEffect(() => {
    const onPop = () => setRoute(readRoute());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  // WebSocket живёт весь сеанс, пока пользователь вошёл — не привязан
  // к конкретной открытой доске, потому что уведомления и события
  // «Входящих» нужны независимо от того, какой проект сейчас открыт.
  useEffect(() => {
    if (!user) { realtimeDisconnect(); return; }
    realtimeConnect();
    return () => realtimeDisconnect();
  }, [user]);

  useEffect(() => onRealtimeStatus(setWsStatus), []);

  /* ------------------------------------------------- справочники и доски */

  const reloadBoards = useCallback(async () => {
    const list = await api.boards();
    setBoards(list);
    return list;
  }, []);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    (async () => {
      try {
        const [dir, teamIds, boardList] = await Promise.all([api.directory(), api.team(), api.boards()]);
        if (!alive) return;
        setDirectory(dir);
        setTeam(teamIds);
        // Группы грузятся отдельно и не мешают входу: без них выбор
        // исполнителей всё равно работает — плоским списком.
        api.teamGroups().then(setTeamGroups).catch(() => {});
        setBoards(boardList);

        const current = readRoute();
        // Прямая ссылка на раздел (или существующий проект) должна
        // открыться именно на нём, а не «сваливаться» на первый проект.
        // Раньше сохранялись только board и inbox — из-за этого
        // скопированный адрес /dashboard, /calendar или /all-tasks
        // после загрузки перебрасывал на доску.
        const keepAsIs =
          (current.view === "board" && boardList.some((b) => b.id === current.boardId)) ||
          current.view === INBOX ||
          current.view === DASHBOARD ||
          current.view === CALENDAR ||
          current.view === ALLTASKS ||
          current.view === REMINDERS ||
          // Раздел «Сообщения» забыли в этом списке, и скопированная
          // ссылка /chats после загрузки перебрасывала на первый
          // проект — в отличие от всех остальных разделов.
          current.view === CHATS;
        if (keepAsIs) {
          setRoute(current);
        } else if (boardList.length > 0) {
          const next = { view: "board", boardId: boardList[0].id };
          setRoute(next);
          pushRoute(next, true);
        } else {
          setRoute({ view: INBOX, boardId: null });
          pushRoute({ view: INBOX }, true);
        }
      } catch (e) {
        showError(e.message);
      }
    })();
    return () => { alive = false; };
  }, [user, showError]);

  // Счётчик непрочитанных подгружается один раз при входе, дальше живёт
  // от WebSocket-событий — это то самое «в фоне», не только при открытии
  // колокольчика.
  useEffect(() => {
    if (!user) return;
    api.notifications({ limit: 1, includeRead: false }).then((d) => setUnread(d.unread)).catch(() => {});
    api.activeDelegations().then(setActiveDelegations).catch(() => {});
  }, [user]);

  /* ------------------------------------------------ загрузка содержимого */

  const loadBoardData = useCallback(async () => {
    if (!user) return;

    if (route.view === INBOX) {
      setLoadingBoard(true);
      try {
        const list = await api.inbox();
        setBoard(null);
        setColumns([]);
        setTasks(list);
      } catch (e) {
        showError(e.message);
      } finally {
        setLoadingBoard(false);
      }
      return;
    }
    if (route.view === DASHBOARD || route.view === CALENDAR || route.view === ALLTASKS
        || route.view === REMINDERS || route.view === CHATS || route.view === READY) {
      // Сводка, календарь и «Все задачи» грузят данные сами: им нужны
      // агрегаты/списки по всем проектам, а не задачи одной доски.
      setBoard(null);
      setColumns([]);
      setTasks([]);
      setLoadingBoard(false);
      return;
    }
    if (route.view !== "board" || !route.boardId) return;

    setLoadingBoard(true);
    try {
      const [b, cols, list] = await Promise.all([api.board(route.boardId), api.columns(route.boardId), api.tasks(route.boardId)]);
      setBoard(b);
      setColumns(cols);
      setTasks(list);
    } catch (e) {
      if (e.status === 404 || e.status === 403) {
        // Сервер объясняет отказ точнее, чем общая формулировка:
        // «не допущены к проекту» и «проект удалён» — разные случаи,
        // и человеку важно понимать, какой именно.
        showError(e.message || "Проект недоступен или удалён");
        const list = await reloadBoards();
        const next = list.length ? { view: "board", boardId: list[0].id } : { view: INBOX, boardId: null };
        setRoute(next);
        pushRoute(next, true);
      } else {
        showError(e.message);
      }
    } finally {
      setLoadingBoard(false);
    }
  }, [user, route, showError, reloadBoards]);

  useEffect(() => { loadBoardData(); }, [loadBoardData]);

  // Задача из ссылки открывается один раз, после входа. Дальше адрес
  // не трогаем: человек уже внутри приложения, и подменять ему адресную
  // строку на каждое открытие карточки — значит ломать кнопку «назад».
  const taskLinkDone = React.useRef(false);
  const refreshReady = useCallback(() => {
    api.allTasks("status=ready&scope=all&limit=1")
      .then((res) => setReadyCount(res.total || 0))
      .catch(() => {});
  }, []);
  // Возвращение к вкладке браузера — повод перечитать то, что могло
  // измениться, пока её не было видно. Соединение могло рваться
  // (сон ноутбука, смена сети), и тогда события просто не дошли:
  // тихая сверка при возврате дешевле, чем объяснять человеку, почему
  // у него старые данные.
  useEffect(() => {
    if (!user) return undefined;
    const onFocus = () => {
      reloadBoards();
      refreshReady();
      api.notifications({ limit: 1 })
        .then((data) => setUnread(data.unread))
        .catch(() => {});
      api.chats()
        .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
        .catch(() => {});
    };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [user, reloadBoards, refreshReady]);

  useEffect(() => { if (user) refreshReady(); }, [user, refreshReady]);

  // Счётчик пересчитывается и при переходе между разделами: отметку
  // могли снять в карточке задачи, и число рядом с разделом должно
  // сойтись с тем, что человек только что видел.
  useEffect(() => { if (user) refreshReady(); }, [user, route.view, refreshReady]);

  // Счётчик непрочитанных при входе: раздел «Сообщения» должен
  // показывать число сразу, не дожидаясь, пока в него зайдут.
  useEffect(() => {
    if (!user) return;
    api.chats()
      .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
      .catch(() => {});
  }, [user]);

  useEffect(() => {
    if (!user || taskLinkDone.current) return;
    const id = readTaskLink();
    if (!id) return;
    taskLinkDone.current = true;
    setDetailId(id);
    window.history.replaceState({}, "", "/");
  }, [user]);

  // Просмотр проекта (п.5): открытая доска считается просмотренной со
  // всем, что в ней успело измениться. Отметка ставится один раз на
  // переход в проект — сыпать запросами на каждое событие внутри
  // открытой доски незачем, в списке слева активный проект и так не
  // выделяется как непросмотренный.
  useEffect(() => {
    if (!user || route.view !== "board" || !route.boardId) return;
    const boardId = route.boardId;
    const seenAt = new Date().toISOString();
    setBoards((prev) => prev.map((b) => (b.id === boardId ? { ...b, seenAt } : b)));
    api.markSeen("board", boardId).catch(() => {});
  }, [user, route.view, route.boardId]);

  const goto = (next) => { setRoute(next); pushRoute(next); setMenu(null); };

  // Панель отбора закрывается, когда уходим туда, где она не нужна:
  // открытая панель над напоминаниями или сводкой занимает половину
  // экрана и относится к другим данным.
  useEffect(() => {
    if (route.view === REMINDERS || route.view === DASHBOARD || route.view === CHATS) {
      setFiltersOpen(false);
    }
  }, [route.view]);

  // Переход в проект по ссылке из списка задач, календаря или
  // уведомления.
  //
  // Список boards содержит только проекты, где человек состоит
  // участником. Если проекта там нет, значит доступ у него точечный —
  // к отдельным задачам, а не к доске. Раньше переход всё равно
  // выполнялся: доска открывалась, показывала подмножество задач и
  // позволяла таскать их по колонкам. Теперь вместо перехода —
  // объяснение, почему проект не открывается. Проверка дублируется на
  // сервере (GET /boards/:id отвечает 403 участнику-«постороннему»),
  // здесь она нужна, чтобы не мигать пустой доской и не терять
  // текущий раздел.
  const openBoard = useCallback((boardId) => {
    if (!boardId) return;
    if (!boards.some((b) => b.id === boardId)) {
      showError("Вы не допущены к этому проекту — доступны только отдельные задачи, открытые вам лично");
      return;
    }
    goto({ view: "board", boardId });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boards, showError]);

  /* --------------------------------------------- события реального времени
     Единая точка входа: любое изменение — своё или чужое — приходит сюда
     и патчит уже загруженное состояние точечно, без похода за всем
     проектом заново. Именно это убирает дёргание экрана при каждом
     комментарии или отметке чек-листа и держит все открытые у всех
     участников вкладки в одном состоянии. */

  // task.access — уровень доступа для конкретного зрителя (edit / contribute
  // / read), а не свойство самой задачи. Сервер вычисляет его на основе
  // того, кто прислал REST-запрос, вызвавший рассылку, — то есть в событии
  // приходит access ОТПРАВИТЕЛЯ действия, не получателя. Если довериться
  // этому полю напрямую, читатель после чужого редактирования увидит в
  // своём интерфейсе чужой уровень доступа (например, кнопки правки,
  // которые при нажатии получат 403 от RLS). Поэтому для уже известных
  // задач access сохраняется локальным, а для по-настоящему новых —
  // выясняется отдельным запросом от своего имени.
  // Что именно изменилось в задаче — по сравнению с тем, что мы о ней
  // знали. Возвращает цвет подсветки или null.
  //
  // Сравнение вынесено сюда, а не привязано к типам WebSocket-событий:
  // так подсветка одинаково работает и для чужих изменений, пришедших
  // по сети, и для своих, применённых прямо из карточки. Раньше она
  // зависела только от событий, и любое изменение, применённое
  // локально, проходило незамеченным.
  // Изменилось ли в задаче что-то, что стоит подсветить.
  //
  // Сравниваются только содержательные поля. Позиция в колонке в этот
  // список не входит намеренно: при перетаскивании одной карточки
  // сервер пересылает всех её соседей по обеим колонкам с новыми
  // позициями, и подсветка «по факту события» зажигала всю колонку
  // разом, хотя изменилась ровно одна задача.
  //
  // Возвращается признак, а не цвет: подсветка у всех изменений одна.
  // Разные цвета на одно и то же по смыслу событие («в задаче что-то
  // произошло») читались как разные состояния и сбивали с толку —
  // особенно когда одна правка меняла сразу два поля и цвет зависел от
  // порядка проверок.
  const hasVisibleChange = useCallback((prev, next) => {
    if (!prev) return false;
    if (Boolean(prev.completedAt) !== Boolean(next.completedAt)) return true;
    if ((prev.assigneesDone || []).length !== (next.assigneesDone || []).length) return true;
    if (prev.commentCount !== next.commentCount) return true;
    if (prev.attachmentCount !== next.attachmentCount) return true;
    if (prev.columnId !== next.columnId) return true;
    if ((prev.assignees || []).join() !== (next.assignees || []).join()) return true;
    const steps = (x) => (x.steps || []).filter((s) => s.done).length;
    if (steps(prev) !== steps(next)) return true;
    return prev.title !== next.title || prev.dueDate !== next.dueDate
        || prev.priority !== next.priority || prev.description !== next.description;
  }, []);

  // Пометить проект изменившимся с точки зрения списка слева (п.5).
  // Событие приходит по WebSocket и не содержит пересчитанных отметок
  // проекта — обновляем их локально, чтобы жирный заголовок появился
  // сразу, а не после следующей загрузки списка проектов. Открытый
  // сейчас проект не трогаем: человек его как раз и смотрит.
  const touchBoard = useCallback((boardId) => {
    if (!boardId || (route.view === "board" && boardId === route.boardId)) return;
    const at = new Date().toISOString();
    setBoards((prev) => prev.map((b) => (b.id === boardId ? { ...b, lastActivityAt: at } : b)));
  }, [route]);

  // То же для задачи: комментарий, файл или отметка в чек-листе не
  // меняют строку задачи и приходят отдельными событиями, но для
  // человека это ровно то самое «в задаче что-то новое».
  const touchTask = useCallback((taskId) => {
    const at = new Date().toISOString();
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, lastActivityAt: at } : t)));
  }, []);

  const upsertTask = useCallback((t) => {
    // Догруженная карточка (дашборд, календарь) живёт вне списка задач
    // доски — её надо обновлять отдельно, иначе правки в открытом окне
    // не видны до его закрытия.
    setFetchedTask((prev) => (prev && prev.id === t.id
      ? { ...t, access: prev.access, seenAt: prev.seenAt }
      : prev));
    setTasks((prev) => {
      const i = prev.findIndex((x) => x.id === t.id);
      if (i === -1) {
        if (route.view === "board" && t.boardId !== route.boardId) return prev;
        return [...prev, t];
      }
      if (hasVisibleChange(prev[i], t)) flashTaskRef.current?.(t.id, theme.accent);
      const next = [...prev];
      // seenAt, как и access, вычислен для ТОГО, чьё действие вызвало
      // рассылку. Взять его из события — значит погасить у получателя
      // отметку «не просмотрено» чужим просмотром, поэтому своё
      // значение сохраняем (п.5).
      next[i] = { ...t, access: prev[i].access, seenAt: prev[i].seenAt };
      return next;
    });
  }, [route, hasVisibleChange, theme]);


  // Вызывается только для задач, которых раньше не было в локальном
  // состоянии вообще (см. обработчик события "task" ниже) — там
  // подставить старый access неоткуда, поэтому переспрашиваем сервер
  // от имени текущей сессии.
  const fetchOwnTaskView = useCallback(async (taskId) => {
    try {
      const t = await api.task(taskId);
      setTasks((prev) => (prev.some((x) => x.id === t.id) ? prev : [...prev, t]));
    } catch {
      // Задача уже могла стать недоступной или удалиться — не страшно,
      // просто не появится в списке.
    }
  }, []);

  // Актуальный список задач в ref: обработчик события ниже должен знать,
  // видели ли мы уже эту задачу, но включать `tasks` в зависимости самого
  // useEffect означало бы пересоздавать подписку на каждое изменение
  // хотя бы одной задачи — а меняются они как раз событиями из этой же
  // подписки.
  const tasksRef = React.useRef(tasks);
  useEffect(() => { tasksRef.current = tasks; }, [tasks]);

  // Список проектов в ref — по той же причине, что и задачи:
  // обработчик событий должен знать, состоит ли пользователь в
  // проекте, но включать boards в зависимости подписки означало бы
  // пересоздавать её при каждом обновлении списка.
  const boardsRef = React.useRef(boards);
  useEffect(() => { boardsRef.current = boards; }, [boards]);

  useEffect(() => {
    if (!user) return;

    const offTask = onRealtimeMessage("task", (e) => {
      if (e.action === "deleted") {
        setTasks((prev) => prev.filter((t) => t.id !== e.payload.id));
        if (detailId === e.payload.id) setDetailId(null);
        return;
      }
      // Звук зависит от того, что именно произошло: появление новой
      // задачи, её переезд между колонками и закрытие — три разных
      // события, и различать их на слух полезнее, чем слышать один
      // и тот же сигнал на любое изменение.
      // Во «Входящих» показываются только задачи ЧУЖИХ проектов —
      // тех, где пользователь не состоит участником. Событие о задаче
      // из собственного проекта сюда попасть не должно: иначе только
      // что скопированная в свой проект задача оседала в списке
      // «Входящих» и исчезала оттуда лишь после перезагрузки, когда
      // список приходил с сервера уже без неё.
      if (route.view === INBOX && e.payload.boardId
          && boardsRef.current.some((b) => b.id === e.payload.boardId)) {
        setTasks((prev) => prev.filter((t) => t.id !== e.payload.id));
        return;
      }

      // Звук по-прежнему зависит от того, что случилось: различать
      // события на слух полезно. А вот подсветка одна на все случаи —
      // и зажигается она не здесь, а в upsertTask, по сравнению старой
      // и новой версии задачи. Иначе перетаскивание одной карточки
      // подсвечивало всю колонку: сервер рассылает соседей, чьи
      // позиции сдвинулись, и каждое такое событие считалось
      // изменением.
      // Счётчик «готовы к сдаче» пересчитываем на любое изменение
      // задачи.
      //
      // Сравнивать со старым состоянием здесь нельзя: список задач в
      // памяти относится к открытой доске, а в разделах «Готовы к
      // сдаче» или «Все задачи» он пуст — и снятие отметки или
      // завершение задачи проходили мимо счётчика. Запрос дешёвый
      // (одно число), поэтому надёжность важнее экономии.
      refreshReady();

      // Задача, которую только что сдали: отдельный сигнал и
      // отдельное окошко. Сравнение со старым состоянием нужно, чтобы
      // не звонить на каждое изменение уже сданной задачи.
      const prevTask = tasksRef.current.find((t) => t.id === e.payload.id);
      if (e.payload.readyAt && !e.payload.completedAt
          && (!prevTask || !prevTask.readyAt)
          && e.payload.readyBy !== user.id) {
        playEventSound("ready", sound);
        setReadyToast({
          taskId: e.payload.id,
          title: e.payload.title,
          author: e.payload.readyBy
            ? resolveUser(directory, e.payload.readyBy).fullName
            : "Исполнитель",
        });
        refreshReady();
      } else if (prevTask && prevTask.readyAt && !e.payload.readyAt) {
        refreshReady();
      }

      const known = tasksRef.current.find((t) => t.id === e.payload.id);
      if (e.action === "created" && !known) {
        playEventSound("taskCreated", sound);
        flashTask(e.payload.id, theme.accent);
      } else if (e.action === "moved" && known && known.columnId !== e.payload.columnId) {
        playEventSound("taskMoved", sound);
      } else if (known && !known.completedAt && e.payload.completedAt) {
        playEventSound("taskDone", sound);
      } else if (known && (known.assigneesDone || []).length <
                 (e.payload.assigneesDone || []).length) {
        // Исполнитель сдал свою часть — то же по смыслу «готово».
        playEventSound("taskDone", sound);
      }

      // Проект помечаем изменившимся только при содержательной правке.
      // Перетаскивание одной карточки рассылает её соседей с новыми
      // позициями — считать это «изменением в проекте» значило бы
      // подсвечивать проект от простой перестановки.
      if (!known || hasVisibleChange(known, e.payload)) {
        touchBoard(e.payload.boardId);
      }

      const isNew = !tasksRef.current.some((t) => t.id === e.payload.id);
      const belongsHere = route.view === INBOX || e.payload.boardId === route.boardId;
      // Во «Входящих» карточки сгруппированы по названию проекта. Если
      // в событии его нет, задача попала бы в группу «Без проекта» и
      // оставалась там до перезагрузки — в таком случае запрашиваем
      // задачу целиком от своего имени.
      if (route.view === INBOX && !e.payload.boardTitle) {
        fetchOwnTaskView(e.payload.id);
        return;
      }
      if (isNew && belongsHere) {
        fetchOwnTaskView(e.payload.id);
      } else {
        upsertTask(e.payload);
      }
    });

    const offStep = onRealtimeMessage("step", (e) => {
      const { taskId, step } = e.payload;
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "deleted") return { ...t, steps: t.steps.filter((s) => s.id !== step.id) };
        const i = t.steps.findIndex((s) => s.id === step.id);
        const steps = i === -1 ? [...t.steps, step] : t.steps.map((s) => (s.id === step.id ? step : s));
        return { ...t, steps };
      }));
    });

    const offComment = onRealtimeMessage("comment", (e) => {
      const taskId = e.payload.taskId;
      // Только на чужие: звук на собственное сообщение бессмыслен.
      if (e.action === "created" && e.payload.authorId !== user.id) {
        playEventSound("comment", sound);
        flashTask(taskId, theme.accent);
        // Своё же сообщение непрочитанным помечать нельзя — отсюда
        // проверка автора.
        touchTask(taskId);
        touchBoard(tasksRef.current.find((t) => t.id === taskId)?.boardId);
      }
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "created") return { ...t, commentCount: t.commentCount + 1 };
        if (e.action === "deleted") return { ...t, commentCount: Math.max(0, t.commentCount - 1) };
        return t;
      }));
    });

    const offAttachment = onRealtimeMessage("attachment", (e) => {
      const taskId = e.payload.taskId;
      if (e.action === "created" && e.payload.authorId !== user.id) {
        flashTask(taskId, theme.accent);
        touchTask(taskId);
        touchBoard(tasksRef.current.find((t) => t.id === taskId)?.boardId);
      }
      setTasks((prev) => prev.map((t) => {
        if (t.id !== taskId) return t;
        if (e.action === "created") return { ...t, attachmentCount: t.attachmentCount + 1 };
        if (e.action === "deleted") return { ...t, attachmentCount: Math.max(0, t.attachmentCount - 1) };
        return t;
      }));
    });

    const offColumns = onRealtimeMessage("columns", (e) => {
      if (route.view === "board" && e.payload.boardId === route.boardId) setColumns(e.payload.columns);
    });

    const offBoard = onRealtimeMessage("board", (e) => {
      if (e.action === "deleted") {
        setBoards((prev) => prev.filter((b) => b.id !== e.payload.id));
        if (route.view === "board" && route.boardId === e.payload.id) {
          showError("Проект удалён владельцем");
          goto({ view: INBOX, boardId: null });
        }
        return;
      }
      if (e.action === "member_added") {
        reloadBoards();
        return;
      }
      reloadBoards();
      if (route.view === "board" && route.boardId === e.payload.id) {
        // myRole в payload вычислен на сервере для того пользователя, чьё
        // действие вызвало рассылку, а не для текущего получателя — так
        // читатель, увидевший чужое редактирование, не должен получить
        // в интерфейсе чужую роль «владелец». Берём из события только
        // содержимое доски, а роль оставляем ту, что знаем по себе.
        setBoard((prev) => (prev ? { ...e.payload, myRole: prev.myRole } : e.payload));
        setBgStamp(Date.now());
      }
    });

    // Новое уведомление обновляет бейдж и проигрывает звук независимо от
    // того, открыта ли панель — раньше это происходило только при клике
    // на колокольчик, когда список подгружался заново.
    // Отзыв доступа к проекту. Событие адресное — приходит только тому,
    // кого сняли. Обрабатывать обязательно: RLS не даст ему изменить
    // данные, но без этого обработчика интерфейс продолжал бы показывать
    // чужой проект со всем содержимым до перезагрузки страницы, а любое
    // действие молча упиралось бы в отказ сервера.
    const offAccess = onRealtimeMessage("access", (e) => {
      // Отозвали точечный доступ к одной задаче: сам проект человеку
      // и так не принадлежит, закрывать нужно только эту карточку.
      if (e.action === "task_revoked") {
        const lostTaskId = e.payload.taskId;
        setTasks((prev) => prev.filter((t) => t.id !== lostTaskId));
        if (detailId === lostTaskId) setDetailId(null);
        setTaskModal((m) => (m?.task?.id === lostTaskId ? null : m));
        showError(e.payload.reason || "Доступ к задаче отозван");
        return;
      }

      if (e.action !== "revoked") return;
      const lostBoardId = e.payload.boardId;

      // Убираем проект из списка и выбрасываем его задачи из памяти —
      // иначе они остались бы видны в текущем представлении.
      setBoards((prev) => prev.filter((b) => b.id !== lostBoardId));
      setTasks((prev) => prev.filter((t) => t.boardId !== lostBoardId));

      const lookingAtIt = route.view === "board" && route.boardId === lostBoardId;
      const detailFromIt = detailId && tasksRef.current.some(
        (t) => t.id === detailId && t.boardId === lostBoardId
      );

      if (lookingAtIt || detailFromIt) {
        // Закрываем всё, что могло остаться открытым поверх проекта:
        // карточку задачи, форму, настройки. Иначе пользователь остался
        // бы в модальном окне задачи, к которой уже нет доступа.
        setDetailId(null);
        setTaskModal(null);
        setSettingsOpen(false);
        setConfirm(null);
      }

      if (lookingAtIt) {
        setBoard(null);
        setColumns([]);
        goto({ view: INBOX, boardId: null });
      }

      showError(e.payload.reason || "Доступ к проекту закрыт");
    });

    // Сработавшее напоминание поднимает окно будильника поверх всего.
    // Дубли отсеиваем по идентификатору: переподключение WebSocket
    // не должно приводить к двум одинаковым окнам подряд.
    const offReminder = onRealtimeMessage("reminder", (e) => {
      const { id, title, taskId } = e.payload || {};
      if (!id) return;
      setAlarms((prev) => (prev.some((a) => a.id === id) ? prev : [...prev, { id, title, taskId }]));
    });

    // Сообщение могло прийти, когда вкладка переписки закрыта — тогда
    // пересчитать счётчик больше некому, и мы просто спрашиваем
    // сервер. Список чатов короткий, а событие редкое.
    const offChatMsg = onRealtimeMessage("message", (e) => {
      // Своё же сообщение озвучивать не надо: человек только что его
      // отправил и прекрасно об этом знает.
      if (e.payload?.authorId === user.id) return;
      // Правки и удаления чужих сообщений звуком не сопровождаем —
      // сигнал означает «вам написали», а не «в переписке что-то
      // поменялось».
      if (e.action === "created") playEventSound("message", sound);

      // Пересчёт счётчика нужен, только когда вкладка переписки
      // закрыта: открытая считает сама, при загрузке списка чатов.
      if (route.view === CHATS) return;

      if (e.action === "created") {
        const who = e.payload?.authorId
          ? resolveUser(directory, e.payload.authorId).fullName
          : "Сотрудник";
        // Текст сообщения показываем — по одному имени непонятно,
        // требует ли разговор немедленного ответа. Длинное обрезаем:
        // окошко в углу не место для простыни.
        const body = e.payload?.body
          ? (e.payload.body.length > 120 ? `${e.payload.body.slice(0, 120)}…` : e.payload.body)
          : (e.payload?.fileId ? "Файл: " + (e.payload.filename || "вложение") : "");
        setChatToast({ chatId: e.payload?.chatId, author: who, body });
      }
      api.chats()
        .then((list) => setChatUnread(list.reduce((n, c) => n + (c.unread || 0), 0)))
        .catch(() => {});
    });

    const offNotif = onRealtimeMessage("notification", () => {
      setUnread((n) => n + 1);
      playEventSound("notification", sound);
    });

    return () => {
      offTask(); offStep(); offComment(); offAttachment();
      offColumns(); offBoard(); offAccess(); offNotif(); offReminder(); offChatMsg();
    };
  }, [user, route, detailId, upsertTask, fetchOwnTaskView, reloadBoards, showError, showInfo,
      sound, flashTask, theme, touchBoard, touchTask, hasVisibleChange, directory]);

  /* ---------------------------------------------------------- фильтрация */

  const allTags = useMemo(() => [...new Set(tasks.flatMap((t) => t.tags || []))].sort(), [tasks]);

  // Набор тегов для панели отбора. На доске и во «Входящих» задачи
  // лежат здесь, а «Все задачи» и календарь грузят свои списки сами —
  // они и присылают оттуда список тегов. Иначе на этих вкладках группа
  // «Теги» была бы пустой, хотя теги у задач есть.
  const [viewTags, setViewTags] = useState([]);
  const filterTags = (route.view === "board" || route.view === INBOX) ? allTags : viewTags;

  const visibleTasks = useMemo(
    () => tasks.filter((t) => matchesFilters(t, filters, search)),
    [tasks, search, filters]);

  // Отбор по дате завершения — это прямая просьба показать
  // завершённые. Если при этом включено «скрыть завершённые», выборка
  // всегда пуста, и человек не понимает почему. Поэтому, пока задан
  // такой диапазон, скрытие не действует; сама настройка не меняется
  // и вернётся, как только диапазон сбросят.
  const hideDone = hideCompleted && !(filters.doneFrom || filters.doneTo);

  // Отсортированный список отдаётся доске: сама доска раскладывает
  // задачи по колонкам, но порядок внутри колонки задаётся здесь —
  // чтобы он был общим и для доски, и для разворота колонки.
  const sortedTasks = useMemo(() => {
    const list = [...visibleTasks];
    switch (boardSort) {
      case "due":
        return list.sort((a, b) => {
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;   // без срока — в конец
          if (!b.dueDate) return -1;
          return a.dueDate.localeCompare(b.dueDate);
        });
      case "created":
        return list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
      case "priority":
        return list.sort((a, b) =>
          (PRIORITIES[b.priority]?.order || 0) - (PRIORITIES[a.priority]?.order || 0));
      case "title":
        return list.sort((a, b) => a.title.localeCompare(b.title, "ru"));
      default:
        return list.sort((a, b) => a.position - b.position);
    }
  }, [visibleTasks, boardSort]);

  const activeSortLabel = {
    position: "как на доске", due: "по сроку",
    created: "по дате", priority: "по приоритету", title: "по названию",
  }[boardSort];

  const toggleFilter = (kind, value) => setFilters((f) => {
    const next = new Set(f[kind]);
    next.has(value) ? next.delete(value) : next.add(value);
    return { ...f, [kind]: next };
  });

  const activeFilters = countFilters(filters);

  /* ------------------------------------------------- операции с задачами */

  const myRole = board?.myRole || "";
  const canEdit = ["owner", "editor"].includes(myRole);
  // Настройки проекта — состав участников, колонки, оформление —
  // доступны и редактору. За владельцем остаётся только удаление
  // проекта и его собственная роль: их редактор не увидит.
  const canManage = canEdit;
  const isOwner = myRole === "owner";
  // Создавать задачи может любой участник проекта, включая наблюдателя
  // (reader). Перемещать задачу вправе автор задачи, редактор,
  // владелец, а также назначенный исполнитель (п.3) — исполнителю
  // сервер запретит только перенос в колонку закрытия.
  const canCreate = Boolean(myRole);
  const canMoveTask = useCallback(
    (t) => t && (t.createdBy === user?.id || canEdit || (t.assignees || []).includes(user?.id)),
    [canEdit, user],
  );
  const isInbox = route.view === INBOX;

  // Перетаскивание отрисовывается сразу (оптимистично), а окончательное
  // состояние — и своё, и соседей по колонке — приходит events'ом "task"
  // следом за REST-ответом: бэкенд рассылает всех, чья позиция сдвинулась
  // при уплотнении нумерации, не только перетащенную карточку.
  const moveTask = async (taskId, columnId, position) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, columnId, position } : t)));
    try {
      await api.moveTask(taskId, columnId, position);
    } catch (e) {
      showError(e.message);
      loadBoardData();
    }
  };

  const saveTask = async (form) => {
    try {
      const payload = {
        title: form.title, description: form.description, priority: form.priority,
        // color обязателен в списке: форма его выставляла, но сюда он не
        // попадал — выбор цвета молча терялся при сохранении.
        color: form.color || "none",
        // Реквизиты документа передавались в форму, но не отправлялись
        // обратно — правка входящего номера молча терялась.
        incomingNumber: form.incomingNumber || "",
        // Та же логика, что и со сроком: при правке пустая дата значит
        // «убрать реквизит», при создании — «его нет».
        incomingDate: form.id ? (form.incomingDate || "") : (form.incomingDate || null),
        columnId: form.columnId,
        // При создании пустой срок — это «поля нет» (null), при правке
        // — «снять срок» (пустая строка). Разные значения для разных
        // смыслов: сервер иначе не отличит «не трогай» от «убери».
        dueDate: form.id ? (form.dueDate || "") : (form.dueDate || null),
        tags: form.tags, assignees: form.assignees,
        // Цикличность (п.6). При «Без повторения» на редактировании явно
        // просим сбросить правило (clearRecur), иначе бэкенд «не менять».
        recurFreq: form.recurFreq || "none",
        recurInterval: form.recurInterval || 1,
        recurWeekdays: form.recurWeekdays || [],
        recurMonthday: form.recurMonthday ?? null,
        recurUntil: form.recurUntil || null,
        clearRecur: form.id ? (form.recurFreq === "none" || !form.recurFreq) : false,
      };
      // Чек-лист принимается только при создании (п.1): у готовой
      // задачи пункты живут своей жизнью — со своими правами и
      // историей — и правятся в карточке.
      if (!form.id) {
        payload.steps = (form.steps || [])
          .filter((s) => (s.body || "").trim())
          .map((s) => ({
            body: s.body.trim(),
            assigneeId: s.assigneeId || null,
            dueDate: s.dueDate || null,
          }));
      }
      const saved = form.id ? await api.updateTask(form.id, payload) : await api.createTask(route.boardId, payload);
      upsertTask(saved);
      setTaskModal(null);

      // Напоминание из формы задачи — отдельным запросом и только
      // после того, как задача сохранена: привязывать будильник не к
      // чему, пока задачи не существует. Неудача здесь не отменяет
      // сохранённую задачу, поэтому сообщение отдельное и мягкое.
      if (form.reminderAt) {
        try {
          await api.createReminder({
            title: saved.title,
            remindAt: new Date(form.reminderAt).toISOString(),
            recurFreq: "none",
            recurInterval: 1,
            recurWeekdays: [],
            taskId: saved.id,
          });
          showInfo("Задача сохранена, напоминание создано");
        } catch {
          showError("Задача сохранена, но напоминание создать не удалось");
        }
      }
    } catch (e) {
      showError(e.message);
    }
  };

  const requestDeleteTask = (taskId) => {
    const t = tasks.find((x) => x.id === taskId);
    setConfirm({
      title: "Удалить задачу?",
      message: `Задача «${t?.title}» будет удалена вместе с комментариями, файлами и историей. Отменить это действие нельзя.`,
      confirmLabel: "Удалить задачу",
      onConfirm: async () => {
        setConfirm(null);
        setTaskModal(null);
        setDetailId(null);
        try {
          await api.deleteTask(taskId);
          setTasks((prev) => prev.filter((x) => x.id !== taskId));
        } catch (e) {
          showError(e.message);
        }
      },
    });
  };

  const requestDeleteBoard = () => {
    setConfirm({
      title: "Удалить проект?",
      message: `Проект «${board.title}» будет удалён вместе с колонками, задачами, файлами и историей. Участники потеряют доступ. Действие необратимо.`,
      confirmLabel: "Удалить проект",
      onConfirm: async () => {
        setConfirm(null);
        setSettingsOpen(false);
        try {
          await api.deleteBoard(board.id);
          const list = await reloadBoards();
          const next = list.length ? { view: "board", boardId: list[0].id } : { view: INBOX, boardId: null };
          setRoute(next);
          pushRoute(next, true);
        } catch (e) {
          showError(e.message);
        }
      },
    });
  };

  // Перетаскивание проекта: и вложение, и порядок внутри уровня.
  // parentId передаётся всегда, в том числе null — на сервере это
  // различается двойным указателем и означает «вынести в корень».
  const moveBoard = async (boardId, target) => {
    try {
      await api.updateBoard(boardId, {
        parentId: target.parentId ?? null,
        ...(target.position !== undefined ? { position: target.position } : {}),
      });
      await reloadBoards();
    } catch (e) {
      showError(e.message);
    }
  };

  const createBoard = async (payload) => {
    try {
      const { id } = await api.createBoard(payload);
      await reloadBoards();
      setNewBoardOpen(false);
      goto({ view: "board", boardId: id });
    } catch (e) {
      showError(e.message);
    }
  };

  const copyLink = async () => {
    // Ссылка на текущее представление: проект, входящие, сводка,
    // календарь или «все задачи». Раньше копировался только адрес
    // проекта, а для остальных разделов кнопки не было вовсе.
    const viewPath =
      route.view === "board" && board?.id ? `/b/${board.id}` :
      route.view === INBOX ? "/inbox" :
      route.view === DASHBOARD ? "/dashboard" :
      route.view === CALENDAR ? "/calendar" :
      route.view === ALLTASKS ? "/all-tasks" : "/";
    const url = `${window.location.origin}${viewPath}`;
    try {
      // navigator.clipboard доступен только в защищённом контексте
      // (HTTPS или localhost). При работе по http во внутренней сети
      // его нет — тогда используем запасной путь через скрытое поле,
      // иначе копирование молча не срабатывало.
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(url);
      } else {
        const ta = document.createElement("textarea");
        ta.value = url;
        ta.style.position = "fixed";
        ta.style.top = "-1000px";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(ta);
        if (!ok) throw new Error("copy_unsupported");
      }
      showInfo("Ссылка скопирована");
    } catch {
      showError("Не удалось скопировать ссылку");
    }
  };

  // Открыл — значит просмотрел (п.5). Карточка, догруженная запросом
  // api.task, отмечается на сервере сама; здесь закрывается второй
  // случай — задача была в уже загруженном списке, и запроса за ней
  // не было. Локально гасим выделение сразу, не дожидаясь ответа:
  // ждать сеть, чтобы убрать жирный шрифт с того, что человек прямо
  // сейчас читает, незачем.
  useEffect(() => {
    if (!detailId) return;
    const seenAt = new Date().toISOString();
    setTasks((prev) => prev.map((t) => (t.id === detailId ? { ...t, seenAt } : t)));
    setFetchedTask((prev) => (prev && prev.id === detailId ? { ...prev, seenAt } : prev));
    api.markSeen("task", detailId).catch(() => {});
  }, [detailId]);

  // Открыл — значит увидел: держать подсветку дальше незачем.
  useEffect(() => {
    if (!detailId) return;
    setHighlights((prev) => {
      if (!prev[detailId]) return prev;
      const next = { ...prev };
      delete next[detailId];
      return next;
    });
  }, [detailId]);

  useEffect(() => {
    if (!detailId) { setFetchedTask(null); return; }
    if (tasksRef.current.some((t) => t.id === detailId)) return;
    let alive = true;
    api.task(detailId)
      .then((t) => alive && setFetchedTask(t))
      .catch((e) => { showError(e.message); setDetailId(null); });
    return () => { alive = false; };
  }, [detailId, showError]);

  // Отложенное открытие формы задачи после перехода в другой проект
  // (копирование). Ждём и колонки, и саму задачу в списке: форма без
  // колонок целевого проекта неполноценна.
  useEffect(() => {
    if (!pendingEdit) return;
    if (route.view !== "board" || route.boardId !== pendingEdit.boardId) return;
    if (loadingBoard || columns.length === 0) return;
    const t = tasks.find((x) => x.id === pendingEdit.taskId);
    if (!t) return;
    setTaskModal({ mode: "edit", task: t });
    setPendingEdit(null);
  }, [pendingEdit, route, loadingBoard, columns, tasks]);

  // Если переход не состоялся (проект закрыли, задача исчезла),
  // отложенное открытие не должно висеть вечно.
  useEffect(() => {
    if (!pendingEdit) return;
    const t = setTimeout(() => setPendingEdit(null), 15000);
    return () => clearTimeout(t);
  }, [pendingEdit]);

  const detailTask = tasks.find((t) => t.id === detailId)
    || (fetchedTask?.id === detailId ? fetchedTask : null);

  /* ------------------------------------------------------------- рендер */

  if (booting) {
    return <div style={{ background: theme.bg, minHeight: "100vh" }} className="flex items-center justify-center"><Spinner theme={theme} label="Загружаем…" /></div>;
  }
  if (!user) {
    return <Login theme={theme} onSuccess={setUser} />;
  }

  const preset = bgById(board?.bgPreset);
  const isCustom = board?.bgPreset === "custom" && board?.bgFileId;
  // Готовые изображения лежат в статике сервера и одинаковы у всех —
  // в отличие от «custom», который загружает каждый владелец сам.
  const readyImage = bgImageUrl(board?.bgPreset);
  const bgImage = isCustom
    ? `url(${api.backgroundUrl(board.id, bgStamp)})`
    : readyImage
    ? `url(${readyImage})`
    : preset?.css || null;
  // Узорные фоны мостятся плиткой: растянуть плитку на весь экран
  // означало бы показать один её гигантский фрагмент. Градиенты и
  // загруженные фотографии, наоборот, должны заполнять область целиком.
  const bgSize = isCustom || readyImage ? "cover" : preset?.size || "cover";

  return (
    <div style={{ background: theme.bg, height: "100vh" }} className="flex flex-col overflow-hidden">
      <header style={{ borderColor: theme.border, background: theme.surface }} className="border-b px-4 py-2.5 flex items-center gap-2.5 flex-wrap relative z-40">
        {/* Клик вне открытого меню (уведомления, оформление, профиль)
            закрывает его. Прозрачная подложка перехватывает клик; она
            ниже самих меню (z-30) по стеку, поэтому по пунктам меню
            по-прежнему можно попасть. */}
        {menu && (
          <div onClick={() => setMenu(null)} className="fixed inset-0 z-20" style={{ background: menu === "notif" ? "rgba(0,0,0,0.4)" : "transparent" }} aria-hidden />
        )}
        <button onClick={() => goto({ view: ALLTASKS, boardId: null })}
          style={{ color: theme.text, fontFamily: "var(--font-ui)" }}
          className="flex items-center gap-1.5 font-bold text-[15px] hover:opacity-80"
          title="Все задачи">
          <LayoutGrid size={18} style={{ color: theme.accent }} />
          Команда
          <span className="mono text-[10px] font-normal ml-0.5 hidden sm:inline"
            style={{ color: theme.textMuted }}>// задачи</span>
        </button>

        <button onClick={() => setSidebarCollapsed((v) => !v)}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="p-1.5 rounded-lg shrink-0"
          title={sidebarCollapsed ? "Показать список проектов" : "Скрыть список проектов"}>
          <Menu size={16} />
        </button>

        <div style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-medium max-w-[240px]">
          {isInbox && <Inbox size={14} />}
          <span className="truncate">{route.view === CALENDAR ? "Календарь" : route.view === DASHBOARD ? "Сводка" : route.view === ALLTASKS ? "Все задачи" : route.view === REMINDERS ? "Напоминания" : route.view === CHATS ? "Сообщения" :
            route.view === READY ? "Готовы к сдаче" : isInbox ? "Входящие" : board?.title || "Проект"}</span>
        </div>

        {route.view !== "none" && (
          <button onClick={copyLink} style={{ color: theme.textMuted }} className="p-1.5"
            title="Скопировать ссылку на текущий раздел"><Link2 size={16} /></button>
        )}

        {!isInbox && board && (
          <>
            <button
              onClick={() => {
                // Выгружается отфильтрованный список — то, что человек
                // видит на экране, а не вся доска целиком.
                const n = exportTasksToExcel(sortedTasks, {
                  directory, columns, boardTitle: board?.title,
                });
                showInfo(`Выгружено задач: ${n}`);
              }}
              style={{ color: theme.textMuted }} className="p-1.5"
              title="Выгрузить задачи в Excel (с учётом фильтров)">
              <FileSpreadsheet size={16} />
            </button>
            {canEdit && (
              <button onClick={() => setTemplatesOpen(true)} style={{ color: theme.textMuted }}
                className="p-1.5" title="Шаблоны задач">
                <Zap size={16} />
              </button>
            )}
            {canManage && <button onClick={() => setSettingsOpen(true)} style={{ color: theme.textMuted }} className="p-1.5" title="Настройки проекта"><Settings size={17} /></button>}
            {!canEdit && myRole === "reader" && (
              <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="flex items-center gap-1 text-[11.5px] px-2 py-1 rounded-lg"
                title="Исполнитель: можно создавать задачи и двигать свои; чужие задачи перемещает автор или редактор">
                <Eye size={12} /> Исполнитель
              </span>
            )}
          </>
        )}

        {/* Поиск по задачам показывается только там, где он что-то
            делает. В сводке и «Всех задачах» свой поиск, а в календаре
            и напоминаниях искать нечего: календарь строится по срокам,
            а напоминания вообще не задачи. Поле, которое ничего не
            меняет, обещает действие, которого не произойдёт.

            Пустой блок оставляем ради разметки — иначе соседние кнопки
            в шапке разъезжаются при переходе между вкладками. */}
        <div className="relative flex-1 min-w-[150px] max-w-xs"
          style={{
            // Поиск есть на всех вкладках со списками задач — он общий,
            // как и панель отбора. Прячем только там, где искать
            // нечего: в сводке со своими разрезами и в напоминаниях.
            visibility: (route.view === DASHBOARD || route.view === REMINDERS
              || route.view === CHATS) ? "hidden" : "visible",
          }}>
          <Search size={14} style={{ color: theme.textMuted }} className="absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Поиск: название, описание, вх. номер, тег" style={inputStyle(theme)} className="w-full pl-8 pr-2.5 py-1.5 rounded-lg text-[13px] outline-none" />
        </div>

        {/* Кнопка отбора есть на всех вкладках со списками задач:
            доска, «Входящие», «Все задачи», календарь. Нет её только в
            сводке, где свои разрезы по периодам, и в напоминаниях,
            которые задачами не являются. */}
        {route.view !== DASHBOARD && route.view !== REMINDERS && (
        <button onClick={() => setFiltersOpen((v) => !v)} style={{ background: activeFilters ? theme.accent : theme.surfaceAlt, color: activeFilters ? theme.accentText : theme.text, border: `1px solid ${theme.border}` }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-medium">
          <Filter size={13} /> Фильтры{activeFilters > 0 && ` (${activeFilters})`}
        </button>
        )}

        {/* Скрытие завершённых — только там, где есть задачи. В сводке
            свой фильтр по статусу, а в напоминаниях завершённых не
            бывает вовсе: кнопка там ничего не делала. */}
        {route.view !== "none" && route.view !== DASHBOARD && route.view !== REMINDERS
          && route.view !== CHATS && (
          <button onClick={() => setHideCompleted((v) => !v)} style={{ background: hideCompleted ? theme.accent : theme.surfaceAlt, color: hideCompleted ? theme.accentText : theme.text, border: `1px solid ${theme.border}` }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-medium" title={hideCompleted ? "Показать завершённые" : "Скрыть завершённые"}>
            {hideCompleted ? <EyeOff size={13} /> : <Eye size={13} />}<span className="hidden sm:inline">Завершённые</span>
          </button>
        )}

        {canCreate && !isInbox && route.view !== DASHBOARD && route.view !== CALENDAR
          && route.view !== ALLTASKS && route.view !== REMINDERS && route.view !== CHATS && (
          // Кнопка нейтральная, без заливки акцентом.
          //
          // В этой же строке живут переключатели — «Фильтры» и
          // «Завершённые», — которые окрашиваются акцентом, когда
          // включены. Постоянно акцентная кнопка действия читалась
          // как ещё один включённый переключатель. Акцент оставлен
          // только значку: кнопку по-прежнему видно, но она не
          // притворяется включённым состоянием.
          <button onClick={() => setTaskModal({ mode: "create", columnId: columns[0]?.id })}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-semibold ml-auto">
            <Plus size={14} style={{ color: theme.accent }} /> Новая задача
          </button>
        )}

        <div className={`relative ${canCreate && !isInbox ? "" : "ml-auto"}`}>
          <button onClick={() => setMenu(menu === "notif" ? null : "notif")} style={{ color: theme.textMuted }} className="relative p-1.5" title="Уведомления">
            <Bell size={18} />
            {unread > 0 && (
              <span style={{ background: theme.danger }} className="absolute top-0 right-0 min-w-[16px] h-4 px-1 rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                {unread}
              </span>
            )}
          </button>
          {menu === "notif" && (
            <Notifications theme={theme} onCountChange={setUnread} onOpenTask={async (n) => {
              setMenu(null);

              // Уведомление об открытии доступа к проекту приходит
              // раньше, чем список проектов успевает обновиться, — и
              // проверка «состою ли я в проекте» давала отрицательный
              // ответ на проект, к которому доступ только что и дали.
              // Поэтому список сначала перечитываем, и решение
              // принимаем уже по свежему.
              let known = n.boardId ? boards.some((b) => b.id === n.boardId) : false;
              if (n.boardId && !known) {
                const list = await reloadBoards();
                known = (list || []).some((b) => b.id === n.boardId);
              }

              if (known) {
                goto({ view: "board", boardId: n.boardId });
              } else if (n.taskId) {
                // Доступ точечный: проекта в дереве нет, задача лежит
                // во «Входящих».
                goto({ view: INBOX, boardId: null });
              }
              if (n.taskId) setDetailId(n.taskId);
            }} />
          )}
        </div>

        <div className="flex items-center gap-1 px-1" title={wsStatus === "connected" ? "Обновления в реальном времени включены" : "Переподключение к серверу…"}>
          <RealtimeDot theme={theme} status={wsStatus} />
        </div>

        <div className="relative">
          <button onClick={() => setMenu(menu === "theme" ? null : "theme")} style={{ color: theme.textMuted }} className="p-1.5" title="Оформление"><Palette size={18} /></button>
          {menu === "theme" && (
            <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
              className="absolute top-full mt-1 right-0 rounded-xl shadow-xl p-1.5 z-30 w-56 max-h-[70vh] overflow-y-auto">
              <div className="mono px-2.5 pt-1 pb-2 text-[10px] uppercase tracking-wider"
                style={{ color: theme.textMuted }}>
                // 5 dark · 5 light
              </div>
              {THEME_ORDER.map((id) => {
                const t = THEMES[id];
                if (!t) return null;
                return (
                  <button key={id} onClick={() => { setThemeId(id); setMenu(null); }}
                    style={{ color: theme.text, background: id === themeId ? theme.surfaceAlt : "transparent" }}
                    className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-[12.5px]">
                    {/* Свотч показывает саму тему: фон и оба акцента —
                        по названию «Graphite» или «Frost» угадать
                        палитру невозможно. */}
                    <span style={{ background: t.bg, border: `1px solid ${theme.border}` }}
                      className="w-7 h-5 rounded flex items-center justify-center gap-0.5 shrink-0">
                      <span style={{ background: t.accent }} className="w-1.5 h-2.5 rounded-sm" />
                      <span style={{ background: t.accent2 }} className="w-1.5 h-2.5 rounded-sm" />
                    </span>
                    <span className="flex-1 text-left">{t.name}</span>
                    <span className="mono text-[9.5px] uppercase" style={{ color: theme.textMuted }}>
                      {t.dark ? "dark" : "light"}
                    </span>
                    {id === themeId && <Check size={12} style={{ color: theme.accent }} />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="relative">
          <button onClick={() => setMenu(menu === "user" ? null : "user")}><Avatar user={user} size={28} theme={theme} /></button>
          {menu === "user" && (
            <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }} className="absolute top-full mt-1 right-0 rounded-xl shadow-xl p-1.5 z-30 w-56">
              <div className="px-2.5 py-2">
                <div style={{ color: theme.text }} className="text-[13px] font-semibold truncate">{user.fullName}</div>
                <div style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{user.position || user.email}</div>
              </div>
              <button onClick={() => { setSoundOpen(true); setMenu(null); }} style={{ color: theme.text }}
                className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px]">
                {sound.enabled
                  ? <Volume2 size={14} style={{ color: theme.accent }} />
                  : <VolumeX size={14} style={{ color: theme.textMuted }} />}
                Звуковые уведомления
              </button>
              <button onClick={() => { setDelegationOpen(true); setMenu(null); }} style={{ color: theme.text }}
                className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px]">
                <UserCheck size={14} style={{ color: theme.accent }} /> Замещение
              </button>
              {user.role === "admin" && (
                <button onClick={() => { setAdminOpen(true); setMenu(null); }} style={{ color: theme.text }}
                  className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px]">
                  <ShieldCheck size={14} style={{ color: theme.accent }} /> Пользователи
                </button>
              )}
              <button onClick={async () => { await api.logout(); setUser(null); setMenu(null); }} style={{ color: theme.danger }} className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px] font-medium">
                <LogOut size={14} /> Выйти
              </button>
            </div>
          )}
        </div>
      </header>

      <div className="flex flex-1 min-h-0 relative">
        {/* Левый список проектов (п.3): постоянный, древовидный,
            сворачивается гамбургером в шапке. На узких экранах в
            развёрнутом виде ложится поверх контента оверлеем. */}
        {!sidebarCollapsed && (
          <>
            <aside
              style={{ background: theme.surface, borderColor: theme.border, width: sidebarWidth }}
              className="shrink-0 border-r overflow-y-auto z-30 absolute inset-y-0 left-0 lg:relative lg:inset-auto shadow-xl lg:shadow-none">
              <ProjectTree
                theme={theme} boards={boards} directory={directory}
                activeId={route.boardId}
                isInbox={isInbox} isDashboard={route.view === DASHBOARD}
                isCalendar={route.view === CALENDAR} isAllTasks={route.view === ALLTASKS}
                isReminders={route.view === REMINDERS}
                isChats={route.view === CHATS} chatUnread={chatUnread}
                isReady={route.view === READY} readyCount={readyCount}
                onSelectReady={() => goto({ view: READY, boardId: null })}
                onSelect={(id) => goto({ view: "board", boardId: id })}
                onSelectInbox={() => goto({ view: INBOX, boardId: null })}
                onSelectDashboard={() => goto({ view: DASHBOARD, boardId: null })}
                onSelectCalendar={() => goto({ view: CALENDAR, boardId: null })}
                onSelectAllTasks={() => goto({ view: ALLTASKS, boardId: null })}
                onSelectReminders={() => goto({ view: REMINDERS, boardId: null })}
                onSelectChats={() => goto({ view: CHATS, boardId: null })}
                onCreate={() => { setNewBoardOpen(true); }}
                onMove={moveBoard}
                canReorder />
              <div style={{ borderColor: theme.border }} className="border-t p-1.5">
                <button onClick={() => { setTeamOpen(true); }} style={{ color: theme.text }}
                  className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px]"
                  title="Редактировать состав команды">
                  <UsersRound size={14} /> Команда ({team.length})
                </button>
              </div>
            </aside>
            {/* Маркер для изменения ширины сайдбара мышью (п.7). Виден
                на десктопе; ширина сохраняется в localStorage. */}
            <div
              onMouseDown={() => {
                sidebarResizing.current = true;
                document.body.style.userSelect = "none";
                document.body.style.cursor = "col-resize";
              }}
              onDoubleClick={() => setSidebarWidth(264)}
              title="Потяните, чтобы изменить ширину (двойной клик — сброс)"
              style={{ background: "transparent" }}
              className="hidden lg:block w-1.5 shrink-0 cursor-col-resize hover:bg-black/10 active:bg-black/20 z-30" />
            {/* Подложка для закрытия сайдбара тапом вне его на мобильном. */}
            <div onClick={() => setSidebarCollapsed(true)}
              className="fixed inset-0 z-20 lg:hidden" style={{ background: "rgba(0,0,0,0.35)" }} />
          </>
        )}

        <div className="flex-1 min-w-0 flex flex-col">

      {/* Панель отбора одна на все вкладки со списками задач: доска,
          «Входящие», «Все задачи», календарь. В сводке её нет — там
          свои разрезы по периодам и проектам, и смешивать два разных
          отбора в одном экране только запутывает.

          Сортировка добавляется отдельной группой и только на доске:
          в календаре порядок задан датами, а во «Всех задачах» своя
          сортировка по столбцам таблицы. */}
      {filtersOpen && route.view !== DASHBOARD && route.view !== CHATS && (
        <TaskFilters theme={theme} filters={filters} setFilters={setFilters}
          directory={directory} people={team} tags={filterTags}
          boards={route.view === "board" ? null : boards}
          extra={route.view === "board" ? (
            <FilterGroup theme={theme} label={`Сортировка · ${activeSortLabel}`}>
              {[["position", "Как на доске"], ["due", "По сроку"], ["priority", "По приоритету"],
                ["created", "По дате"], ["title", "По названию"]].map(([id, label]) => (
                <Chip key={id} theme={theme} active={boardSort === id} onClick={() => setBoardSort(id)}>
                  {label}
                </Chip>
              ))}
            </FilterGroup>
          ) : null} />
      )}

      <main className="flex-1 relative overflow-hidden">
        {bgImage && (
          <div aria-hidden style={{
            backgroundImage: bgImage, backgroundSize: bgSize, backgroundPosition: "center",
            filter: board?.bgBlur ? "blur(22px)" : "none", transform: board?.bgBlur ? "scale(1.12)" : "none",
            opacity: theme.dark ? 0.42 : 0.6,
          }} className="absolute inset-0 pointer-events-none" />
        )}

        <div className="relative h-full overflow-auto p-4">
          {loadingBoard ? (
            <Spinner theme={theme} label="Загружаем данные…" />
          ) : route.view === CALENDAR ? (
            <Calendar theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} filters={filters} search={search} onTags={setViewTags}
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onTaskCreated={upsertTask} />
          ) : route.view === DASHBOARD ? (
            <Dashboard theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone}
              onError={showError} onOpenTask={setDetailId} />
          ) : route.view === ALLTASKS ? (
            <AllTasks theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} filters={filters} search={search} onTags={setViewTags}
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onOpenBoard={openBoard} />
          ) : route.view === READY ? (
            // Тот же список задач, отобранный по готовности к сдаче:
            // отдельный компонент здесь был бы копией «Всех задач» со
            // всеми их фильтрами, сортировкой и выгрузкой.
            <AllTasks theme={theme} directory={directory} boards={boards} currentUser={user}
              hideCompleted={hideDone} filters={filters} search={search} onTags={setViewTags}
              readyOnly
              onError={showError} onInfo={showInfo} onOpenTask={setDetailId}
              onOpenBoard={openBoard} />
          ) : route.view === CHATS ? (
            <Chats theme={theme} directory={directory} currentUser={user}
              onError={showError} onUnread={setChatUnread}
              openChatId={openChatId} onOpened={() => setOpenChatId(null)} />
          ) : route.view === REMINDERS ? (
            <Reminders theme={theme} onError={showError} onOpenTask={(id) => setDetailId(id)} />
          ) : isInbox ? (
            <InboxView tasks={sortedTasks} theme={theme} directory={directory}
              hideCompleted={hideDone} onOpenTask={setDetailId}
              highlights={highlights} currentUserId={user.id} onOpenUser={setUserCard} />
          ) : board ? (
            <BoardView columns={columns} tasks={sortedTasks} theme={theme} directory={directory} canEdit={canEdit} canManage={canManage}
              canCreate={canCreate} canMoveTask={canMoveTask}
              hideCompleted={hideDone} onOpenTask={setDetailId} onMove={moveTask}
              onQuickAdd={(columnId) => setTaskModal({ mode: "create", columnId })} onSettings={() => setSettingsOpen(true)}
              onExpandColumn={(col) => setOpenColumn(col)}
              currentUserId={user.id} onOpenUser={setUserCard}
              highlights={highlights}
              onShowCompleted={() => setHideCompleted(false)} />
          ) : (
            <div className="max-w-md mx-auto text-center py-16">
              <LayoutGrid size={30} style={{ color: theme.textMuted }} className="mx-auto mb-3" />
              <h3 style={{ color: theme.text, fontFamily: "var(--font-ui)" }} className="font-semibold text-[16px] mb-1.5">Проектов пока нет</h3>
              <p style={{ color: theme.textMuted }} className="text-[13px] mb-4">Создайте первый проект — колонки и доска появятся сразу.</p>
              <button onClick={() => setNewBoardOpen(true)} style={{ background: theme.accent, color: theme.accentText }} className="rounded-lg px-4 py-2.5 text-[13px] font-semibold">Создать проект</button>
            </div>
          )}
        </div>
      </main>
        </div>
      </div>

      {taskModal && (
        <TaskModal theme={theme} directory={directory} team={team} teamGroups={teamGroups}
          boardMemberIds={(board?.members || []).map((m) => m.userId)} currentUser={user} columns={columns}
          initial={taskModal.mode === "edit" ? taskModal.task : { columnId: taskModal.columnId }}
          onClose={() => setTaskModal(null)} onSave={saveTask} onRequestDelete={requestDeleteTask} />
      )}

      {detailTask && (
        <TaskDetail theme={theme} task={detailTask} directory={directory} team={team} currentUser={user}
          teamGroups={teamGroups}
          onClose={() => setDetailId(null)}
          onEdit={(t) => { setDetailId(null); setTaskModal({ mode: "edit", task: t }); }}
          onTaskPatched={upsertTask}
          onRequestDelete={requestDeleteTask}
          onRequestCopy={(t) => setTransfer({ task: t, mode: "copy" })}
          onRequestMove={(t) => setTransfer({ task: t, mode: "move" })}
          onRequestReminder={(t) => setReminderFor(t)}
          onOpenBoard={(id) => { setDetailId(null); openBoard(id); }}
          onError={showError} onOpenUser={setUserCard}
          onOpenTask={setDetailId} />
      )}

      {settingsOpen && board && (
        <BoardSettings theme={theme} board={board} columns={columns} tasks={tasks} directory={directory} isOwner={isOwner}
          team={team} currentUser={user}
          onClose={() => setSettingsOpen(false)}
          onSaved={() => { setBgStamp(Date.now()); reloadBoards(); loadBoardData(); }}
          onRequestDeleteBoard={requestDeleteBoard} onError={showError} />
      )}

      {newBoardOpen && <NewBoardModal theme={theme} onClose={() => setNewBoardOpen(false)} onCreate={createBoard} />}

      {teamOpen && (
        <Team theme={theme} directory={directory} team={team} groups={teamGroups} currentUser={user} onClose={() => setTeamOpen(false)} onOpenUser={setUserCard}
          onSave={async (ids, groups) => {
            try {
              // Сначала состав, потом группы: группа ссылается на
              // участников команды, и сохранять её раньше состава
              // значило бы получать отказ по ключу.
              await api.saveTeam(ids);
              setTeam(ids);
              if (groups) {
                // Из групп выкидываем тех, кого только что убрали из
                // команды: сервер сделает то же самое каскадом, но
                // иначе он добавил бы их в команду обратно.
                const keep = new Set(ids);
                const cleaned = groups.map((g) => ({
                  ...g, members: g.members.filter((id) => keep.has(id)),
                }));
                setTeamGroups(await api.saveTeamGroups(cleaned));
              }
              setTeamOpen(false);
            } catch (e) { showError(e.message); }
          }} />
      )}

      {adminOpen && (
        <Admin theme={theme} currentUser={user} onClose={() => setAdminOpen(false)}
          onError={showError} onInfo={showInfo}
          onDirectoryChanged={() => api.directory().then(setDirectory).catch(() => {})} />
      )}

      {delegationOpen && (
        <Delegation theme={theme} directory={directory} currentUser={user}
          onClose={() => setDelegationOpen(false)}
          onError={showError} onInfo={showInfo} />
      )}

      {openColumn && (
        <ColumnView theme={theme} column={openColumn} directory={directory}
          tasks={sortedTasks.filter((t) => t.columnId === openColumn.id)}
          onClose={() => setOpenColumn(null)}
          onOpenTask={(id) => { setOpenColumn(null); setDetailId(id); }} />
      )}

      {reminderFor && (
        <TaskReminderModal theme={theme} task={reminderFor}
          onClose={() => setReminderFor(null)}
          onSaved={() => { setReminderFor(null); showInfo("Напоминание создано"); }}
          onError={showError} />
      )}

      {transfer && (
        // boards содержит только проекты, где пользователь состоит
        // участником, — а значит может создавать в них задачи (п.7),
        // поэтому список подходит как есть.
        <CopyTaskModal theme={theme} task={transfer.task} mode={transfer.mode} boards={boards}
          onClose={() => setTransfer(null)}
          onError={showError}
          onCopied={(copy, targetBoardId, mode) => {
            setTransfer(null);

            if (mode === "move") {
              // Перенос: задача та же самая, форму открывать незачем —
              // ничего не изменилось, кроме проекта. Показываем её на
              // новом месте.
              showInfo("Задача перенесена");
              setTasks((prev) => prev.filter((t) => t.id !== copy.id));
              setFetchedTask(copy);
              openBoard(targetBoardId);
              setDetailId(copy.id);
              return;
            }

            showInfo("Задача скопирована");
            // Закрываем всё, что относилось к исходной задаче: работа
            // продолжается в копии, и оставлять поверх неё карточку
            // оригинала (тем более из чужого проекта) незачем.
            setDetailId(null);
            setFetchedTask(null);

            if (route.view === "board" && targetBoardId === route.boardId) {
              // Копия в открытом проекте — показываем сразу и
              // открываем её форму.
              upsertTask(copy);
              setTaskModal({ mode: "edit", task: copy });
              return;
            }

            // Копия в другом проекте: переходим туда и открываем форму
            // редактирования, когда доска догрузится. Сразу открыть
            // нельзя — списка колонок целевого проекта ещё нет, и
            // выпадающий список «Колонка» оказался бы пустым.
            openBoard(targetBoardId);
            setPendingEdit({ boardId: targetBoardId, taskId: copy.id });
          }} />
      )}

      {templatesOpen && (
        <Templates theme={theme} directory={directory} team={team}
          boardId={route.boardId} boardTitle={board?.title} columns={columns}
          onClose={() => setTemplatesOpen(false)}
          onError={showError} onInfo={showInfo}
          onCreated={(task) => upsertTask(task)} />
      )}

      {soundOpen && (
        <Modal theme={theme} onClose={() => setSoundOpen(false)} width="max-w-sm" geometryKey="sound-settings">
          <ModalHeader theme={theme} title="Звуковые уведомления"
            subtitle="Разные события звучат по-разному, чтобы понимать их не глядя на экран"
            onClose={() => setSoundOpen(false)} />

          <button onClick={() => setSound((s) => ({ ...s, enabled: !s.enabled }))}
            style={{
              background: sound.enabled ? theme.accent : theme.surfaceAlt,
              color: sound.enabled ? theme.accentText : theme.text,
              border: `1px solid ${theme.border}`,
            }}
            className="w-full rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-2 mb-3">
            {sound.enabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            {sound.enabled ? "Звук включён" : "Звук выключен"}
          </button>

          <div style={{ opacity: sound.enabled ? 1 : 0.45 }}>
            <div className="mono text-[10px] uppercase tracking-wider mb-1.5"
              style={{ color: theme.textMuted }}>// громкость</div>
            <input type="range" min="0.02" max="0.5" step="0.02" value={sound.volume}
              disabled={!sound.enabled}
              onChange={(e) => {
                const v = Number(e.target.value);
                setSound((s) => ({ ...s, volume: v }));
                // Проигрываем сразу: подбирать громкость вслепую,
                // ползунком без отклика, неудобно.
                playEventSound("notification", { ...sound, volume: v, enabled: true });
              }}
              className="w-full mb-4" style={{ accentColor: theme.accent }} />

            <div className="mono text-[10px] uppercase tracking-wider mb-1.5"
              style={{ color: theme.textMuted }}>// какие события</div>
            {Object.entries(SOUND_EVENT_LABELS).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between gap-2 mb-1.5">
                <Toggle theme={theme} checked={sound.events[key] !== false}
                  label={label}
                  onChange={(next) => setSound((s) => ({
                    ...s, events: { ...s.events, [key]: next },
                  }))} />
                <button
                  onClick={() => playEventSound(key, { ...sound, enabled: true, events: { [key]: true } })}
                  style={{ color: theme.accent }} className="mono text-[10px] shrink-0"
                  title="Прослушать">
                  play
                </button>
              </div>
            ))}

            <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-3 leading-relaxed">
              Перемещение задач выключено по умолчанию: на активной доске карточки
              двигаются постоянно, и звук на каждое перетаскивание быстро надоедает.
            </p>
          </div>
        </Modal>
      )}

      {userCard && (
        <UserCard theme={theme} user={userCard} directory={directory}
          online={onlineUsers.has(userCard.id)}
          onWriteChat={async (u) => {
            // Закрываем всё, что было открыто поверх: карточку
            // сотрудника и окна, из которых её открыли (состав команды,
            // замещения, администрирование). Иначе переписка
            // открывается под чужим окном, и человек видит на экране
            // список сотрудников вместо чата.
            setUserCard(null);
            setTeamOpen(false);
            setDelegationOpen(false);
            setMenu(null);
            try {
              // Сервер сам находит существующую переписку с этим
              // человеком и создаёт новую только если её нет: два
              // нажатия подряд не должны плодить пустые чаты.
              const res = await api.createChat({ kind: "direct", userId: u.id });
              setOpenChatId(res.id);
              goto({ view: CHATS, boardId: null });
            } catch (e) {
              showError(e.message);
            }
          }}
          onClose={() => setUserCard(null)}
          delegation={(() => {
            const d = activeDelegations.find((x) => x.grantorId === userCard.id);
            if (!d) return null;
            return {
              deputyName: resolveUser(directory, d.deputyId).fullName,
              note: d.note,
              endsAtLabel: fmtDate(d.endsAt),
            };
          })()} />
      )}
      {alarms.length > 0 && (
        <AlarmModal theme={theme} alarms={alarms} onError={showError}
          onOpenTask={(taskId) => setDetailId(taskId)}
          onDismiss={(id, info) => {
            setAlarms((prev) => prev.filter((a) => a.id !== id));
            if (info) showInfo(info);
          }} />
      )}

      {/* Задача сдана — то же окошко в углу, что и у сообщений, но со
          своим цветом и своим звуком: событие другое, и путать их на
          слух и на глаз не нужно. */}
      <ChatToast theme={theme} toast={readyToast && {
          author: readyToast.author,
          body: `Готова к сдаче: ${readyToast.title}`,
        }}
        accent={theme.success}
        label="задача готова к сдаче"
        action="Открыть задачу →"
        onDismiss={() => setReadyToast(null)}
        onOpen={() => {
          const id = readyToast?.taskId;
          setReadyToast(null);
          if (id) setDetailId(id);
        }} />

      <ChatToast theme={theme} toast={chatToast}
        onDismiss={() => setChatToast(null)}
        onOpen={() => {
          const id = chatToast?.chatId;
          setChatToast(null);
          if (id) setOpenChatId(id);
          goto({ view: CHATS, boardId: null });
        }} />

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
      {toast && <Toast theme={theme} message={toast.message} kind={toast.kind} onDismiss={() => setToast(null)} />}
    </div>
  );
}

function NewBoardModal({ theme, onClose, onCreate }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [bgPreset, setBgPreset] = useState("none");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim()) return;
    setBusy(true);
    await onCreate({ title: title.trim(), description, bgPreset, bgBlur: true });
    setBusy(false);
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="board-new">
      <ModalHeader theme={theme} title="Новый проект" onClose={onClose} />
      <Field label="Название" theme={theme}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} autoFocus
          placeholder="Например, «Инфраструктура API»" style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13.5px] outline-none" />
      </Field>
      <Field label="Описание" theme={theme}>
        <input value={description} onChange={(e) => setDescription(e.target.value)} style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>
      <Field label="Фон" theme={theme} hint="Своё изображение можно загрузить в настройках проекта">
        <div className="grid grid-cols-6 gap-2">
          {ALL_BACKGROUNDS.map((p) => {
            // Пресеты-изображения (города, природа) не имеют css-градиента —
            // для них подставляем миниатюру из /backgrounds, иначе плитка
            // оставалась пустой и фотографии «не загружались».
            const thumb = bgThumbUrl(p.id);
            return (
              <button key={p.id} onClick={() => setBgPreset(p.id)}
                style={{
                  background: thumb ? `url(${thumb}) center/cover` : (p.css || theme.surfaceAlt),
                  backgroundSize: thumb ? "cover" : (p.size || "cover"),
                  border: `2px solid ${bgPreset === p.id ? theme.accent : theme.border}`,
                }}
                className="h-11 rounded-lg" title={p.label} />
            );
          })}
        </div>
      </Field>
      <button onClick={submit} disabled={!title.trim() || busy} style={{ background: theme.accent, color: theme.accentText }} className="w-full rounded-lg py-2.5 text-[13.5px] font-semibold disabled:opacity-40 mt-2">
        {busy ? "Создаём…" : "Создать проект"}
      </button>
      <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-2.5">Проект создаётся со стандартным набором колонок — их можно изменить в настройках.</p>
    </Modal>
  );
}
