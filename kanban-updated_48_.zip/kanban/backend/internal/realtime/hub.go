// Package realtime держит активные WebSocket-соединения и рассылает по
// ним события. Кому рассылать — решает не этот пакет: список
// получателей вычисляется в базе теми же правилами, что и политики RLS
// (app.board_watchers / app.task_watchers в 0003_rls.sql) и передаётся
// сюда готовым. Хаб отвечает только за доставку.
package realtime

import (
	"encoding/json"
	"log/slog"
	"sync"
	"time"

	"github.com/gofiber/websocket/v2"
	"github.com/google/uuid"
)

const (
	pingInterval = 25 * time.Second
	writeWait    = 10 * time.Second
	// Размер очереди на соединение. События мелкие, а всплески бывают
	// при массовых операциях: сохранение колонок шлёт событие на каждую
	// затронутую задачу.
	sendBuffer = 64
)

type Hub struct {
	mu    sync.RWMutex
	conns map[uuid.UUID]map[*Conn]struct{}

	// Общая шина между экземплярами приложения. nil — работаем одни,
	// как раньше: событие видят только соединения этого процесса.
	bus *Bus

	// Присутствие, рассказанное соседними экземплярами: экземпляр →
	// его список подключённых и время сообщения. Своя блокировка,
	// чтобы рассылка событий (самая частая операция) не ждала
	// обновления присутствия.
	peerMu sync.Mutex
	peers  map[string]peerPresence
}

// Conn — соединение с собственной очередью отправки.
//
// Почему очередь, а не прямая запись под мьютексом (как было раньше):
// WriteMessage блокируется, когда TCP-буфер получателя переполнен —
// например, у клиента с плохой сетью или у вкладки, усыплённой
// браузером. Рассылка идёт по получателям последовательно, поэтому
// один такой клиент задерживал ВСЮ рассылку, и остальные участники
// получали события с задержкой или не получали вовсе, если запись
// зависала до разрыва по таймауту.
//
// Теперь запись выполняет отдельная горутина на соединение, а SendTo
// только кладёт готовый кадр в очередь и никогда не блокируется. Если
// очередь переполнена — клиент безнадёжно отстал, и его соединение
// закрывается: он переподключится и получит состояние заново, что
// заведомо лучше, чем тормозить рассылку всем остальным.
type Conn struct {
	ws     *websocket.Conn
	send   chan []byte
	closeC chan struct{}
	once   sync.Once
}

func NewHub() *Hub {
	return &Hub{
		conns: make(map[uuid.UUID]map[*Conn]struct{}),
		peers: make(map[string]peerPresence),
	}
}

// Register регистрирует соединение и запускает его писателя.
// Возвращённый *Conn нужно передать в Unregister при закрытии.
func (h *Hub) Register(userID uuid.UUID, ws *websocket.Conn) *Conn {
	c := &Conn{
		ws:     ws,
		send:   make(chan []byte, sendBuffer),
		closeC: make(chan struct{}),
	}

	h.mu.Lock()
	if h.conns[userID] == nil {
		h.conns[userID] = make(map[*Conn]struct{})
	}
	h.conns[userID][c] = struct{}{}
	// Соседям — сразу: десять секунд задержки на «вошёл» слишком
	// заметны, а сообщение маленькое.
	go h.announcePresence()
	h.mu.Unlock()

	go c.writeLoop()
	return c
}

func (h *Hub) Unregister(userID uuid.UUID, c *Conn) {
	defer func() { go h.announcePresence() }()
	c.close()

	h.mu.Lock()
	defer h.mu.Unlock()
	if set, ok := h.conns[userID]; ok {
		delete(set, c)
		if len(set) == 0 {
			delete(h.conns, userID)
		}
	}
}

// Disconnect обрывает все соединения пользователя: при блокировке или
// удалении учётной записи. Сам WebSocket проверяет права только на
// рукопожатии, поэтому уже открытое соединение продолжало бы получать
// события.
func (h *Hub) Disconnect(userID uuid.UUID) {
	h.mu.RLock()
	targets := make([]*Conn, 0, len(h.conns[userID]))
	for c := range h.conns[userID] {
		targets = append(targets, c)
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.close()
	}
}

// ConnectedUsers — число пользователей с хотя бы одним живым
// соединением. Используется в /healthz.
func (h *Hub) ConnectedUsers() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.conns)
}

// Connections — общее число соединений: у одного человека их столько,
// сколько открытых вкладок.
func (h *Hub) Connections() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	n := 0
	for _, set := range h.conns {
		n += len(set)
	}
	return n
}

type Event struct {
	Type    string `json:"type"`
	Action  string `json:"action,omitempty"`
	Payload any    `json:"payload,omitempty"`
}

// SendTo рассылает событие указанным пользователям. Не блокируется
// никогда: сериализация выполняется один раз на всю рассылку, а
// доставка идёт через очереди соединений.
func (h *Hub) SendTo(userIDs []uuid.UUID, event Event) {
	if len(userIDs) == 0 {
		return
	}
	data, err := json.Marshal(event)
	if err != nil {
		slog.Error("не удалось сериализовать событие", "error", err, "type", event.Type)
		return
	}

	// Событие уходит и в общую шину — соседним экземплярам приложения.
	// Получатели передаются вместе с ним: список вычислен по правам
	// доступа здесь, и пересчитывать его на каждом экземпляре значило
	// бы повторять ту же работу и рисковать расхождением.
	h.publish(userIDs, data)


	// Снимок получателей под чтением, отправка — уже вне блокировки:
	// держать RLock во время доставки незачем, а мешать регистрации
	// новых соединений — вредно.
	h.mu.RLock()
	targets := make([]*Conn, 0, len(userIDs))
	for _, uid := range userIDs {
		for c := range h.conns[uid] {
			targets = append(targets, c)
		}
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.enqueue(data)
	}
}

// enqueue кладёт кадр в очередь соединения. Переполнение означает, что
// клиент не успевает читать; такое соединение закрывается — клиент
// переподключится и загрузит состояние заново.
func (c *Conn) enqueue(data []byte) {
	select {
	case <-c.closeC:
		return
	default:
	}

	select {
	case c.send <- data:
	default:
		slog.Warn("очередь соединения переполнена, закрываем — клиент не успевает читать")
		c.close()
	}
}

// writeLoop — единственное место, где выполняется запись в сокет.
// Библиотека не допускает конкурентную запись, и одна горутина на
// соединение снимает этот вопрос полностью: мьютекс вокруг записи
// больше не нужен.
func (c *Conn) writeLoop() {
	ticker := time.NewTicker(pingInterval)
	defer func() {
		ticker.Stop()
		_ = c.ws.Close()
	}()

	for {
		select {
		case <-c.closeC:
			// Прощальный кадр по возможности, но без ожидания.
			_ = c.ws.SetWriteDeadline(time.Now().Add(time.Second))
			_ = c.ws.WriteMessage(websocket.CloseMessage,
				websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
			return

		case data := <-c.send:
			// Крайний срок обязателен: без него запись в мёртвое
			// соединение висит до таймаута операционной системы —
			// десятки минут, всё это время занимая горутину.
			if err := c.ws.SetWriteDeadline(time.Now().Add(writeWait)); err != nil {
				return
			}
			if err := c.ws.WriteMessage(websocket.TextMessage, data); err != nil {
				slog.Debug("запись в сокет не удалась, закрываем", "error", err)
				return
			}

		case <-ticker.C:
			if err := c.ws.SetWriteDeadline(time.Now().Add(writeWait)); err != nil {
				return
			}
			if err := c.ws.WriteMessage(websocket.PingMessage, nil); err != nil {
				// Соединение мертво: закрываем, чтобы блокирующий
				// ReadMessage в обработчике вернул ошибку и освободил
				// свою горутину через defer Unregister.
				return
			}
		}
	}
}

func (c *Conn) close() {
	c.once.Do(func() { close(c.closeC) })
}

// Online — идентификаторы пользователей, у которых сейчас есть живое
// соединение.
//
// Присутствие берётся именно из соединений, а не из «последней
// активности» в базе: WebSocket и есть самый точный признак того, что
// человек за рабочим местом, а хранить и обновлять отдельную метку
// означало бы писать в базу на каждое движение.
//
// Список, а не проверка по одному: карточка чата или списка сотрудников
// спрашивает состояние сразу у десятков людей.
func (h *Hub) Online() []uuid.UUID {
	h.mu.RLock()
	seen := make(map[uuid.UUID]bool, len(h.conns))
	for id, set := range h.conns {
		if len(set) > 0 {
			seen[id] = true
		}
	}
	h.mu.RUnlock()

	// К своим соединениям добавляем тех, о ком рассказали соседние
	// экземпляры. Без этого при prefork и нескольких серверах
	// присутствие показывалось бы по одному процессу из нескольких:
	// человек, подключённый к соседнему, выглядел бы офлайн у всех,
	// кроме тех, кто попал на тот же процесс.
	h.peerMu.Lock()
	now := time.Now()
	for inst, p := range h.peers {
		// Молчащий дольше двух с половиной периодов экземпляр считаем
		// выбывшим: он мог упасть, и его список устарел. Запас в
		// половину периода — на случай задержки в сети.
		if now.Sub(p.at) > presenceTTL {
			delete(h.peers, inst)
			continue
		}
		for _, id := range p.users {
			seen[id] = true
		}
	}
	h.peerMu.Unlock()

	out := make([]uuid.UUID, 0, len(seen))
	for id := range seen {
		out = append(out, id)
	}
	return out
}

// --- присутствие между экземплярами ---

const (
	// Как часто экземпляр рассказывает о своих подключённых.
	presenceEvery = 10 * time.Second
	// Сколько живёт чужой список без обновления.
	presenceTTL = 25 * time.Second
)

type peerPresence struct {
	users []uuid.UUID
	at    time.Time
}

// announcePresence публикует список своих подключённых.
//
// Периодически, а не только по событиям «подключился/отключился».
// Периодическая рассылка самовосстанавливается: экземпляр, поднявшийся
// после сбоя шины, узнает обо всех за десять секунд, тогда как
// пропущенное событие «подключился» потерялось бы навсегда. Плата —
// одно небольшое сообщение в десять секунд на экземпляр.
func (h *Hub) announcePresence() {
	if h.bus == nil {
		return
	}
	payload, err := json.Marshal(presenceMessage{
		Kind:  "presence",
		Users: h.localOnline(),
	})
	if err != nil {
		return
	}
	h.bus.Publish(payload)
}

func (h *Hub) localOnline() []uuid.UUID {
	h.mu.RLock()
	defer h.mu.RUnlock()
	out := make([]uuid.UUID, 0, len(h.conns))
	for id, set := range h.conns {
		if len(set) > 0 {
			out = append(out, id)
		}
	}
	return out
}

type presenceMessage struct {
	Kind  string      `json:"kind"`
	Users []uuid.UUID `json:"users"`
}

// --- общая шина между экземплярами приложения ---

// busEnvelope — то, что уходит в Redis: кому доставить и что именно.
type busEnvelope struct {
	Users []uuid.UUID     `json:"users"`
	Event json.RawMessage `json:"event"`
}

// AttachBus подключает хаб к общей шине.
//
// Без неё хаб работает как раньше: событие видят только соединения
// этого процесса. С ней — каждый экземпляр публикует свои события и
// доставляет чужие, поэтому prefork и несколько серверов за
// балансировщиком перестают терять уведомления.
func (h *Hub) AttachBus(bus *Bus) {
	h.bus = bus
	bus.Start(func(instance string, payload []byte) {
		// В канале два вида сообщений: события для доставки и списки
		// присутствия. Различаются по полю kind — заводить второй
		// канал ради этого не стоит, подписка и переподключение
		// удвоились бы.
		var probe struct {
			Kind string `json:"kind"`
		}
		if err := json.Unmarshal(payload, &probe); err == nil && probe.Kind == "presence" {
			var pm presenceMessage
			if err := json.Unmarshal(payload, &pm); err != nil {
				return
			}
			h.peerMu.Lock()
			h.peers[instance] = peerPresence{users: pm.Users, at: time.Now()}
			h.peerMu.Unlock()
			return
		}

		var env busEnvelope
		if err := json.Unmarshal(payload, &env); err != nil {
			slog.Warn("шина событий: непонятное сообщение", "error", err)
			return
		}
		// Доставка без повторной публикации: событие уже в шине.
		h.deliverLocal(env.Users, env.Event)
	})

	// Первое объявление — сразу, чтобы соседи узнали о нас не через
	// десять секунд, а тут же.
	h.announcePresence()
	go func() {
		t := time.NewTicker(presenceEvery)
		defer t.Stop()
		for range t.C {
			h.announcePresence()
		}
	}()
}

func (h *Hub) publish(userIDs []uuid.UUID, data []byte) {
	if h.bus == nil {
		return
	}
	payload, err := json.Marshal(busEnvelope{Users: userIDs, Event: data})
	if err != nil {
		return
	}
	h.bus.Publish(payload)
}

// deliverLocal рассылает готовое событие только своим соединениям.
func (h *Hub) deliverLocal(userIDs []uuid.UUID, data []byte) {
	h.mu.RLock()
	targets := make([]*Conn, 0, len(userIDs))
	for _, uid := range userIDs {
		for c := range h.conns[uid] {
			targets = append(targets, c)
		}
	}
	h.mu.RUnlock()

	for _, c := range targets {
		c.enqueue(data)
	}
}
