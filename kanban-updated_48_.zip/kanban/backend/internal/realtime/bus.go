package realtime

import (
	"bufio"
	"fmt"
	"log/slog"
	"net"
	"strconv"
	"sync"
	"time"
)

// Общая шина событий на Redis.
//
// Зачем. Список соединений WebSocket живёт в памяти процесса. Пока
// процесс один, этого достаточно. Как только их становится несколько —
// prefork, несколько контейнеров за HAProxy, — событие, рождённое в
// одном процессе, видят только подключённые к нему, и уведомления
// начинают приходить через раз. Redis здесь — переносчик: каждый
// экземпляр публикует свои события в общий канал и слушает его,
// доставляя пришедшее своим соединениям.
//
// Почему клиент написан руками, а не взята готовая библиотека.
// Используются ровно две команды — PUBLISH и SUBSCRIBE — плюс AUTH и
// SELECT при подключении. Это сотня строк на разбор простого
// текстового протокола. Ради этого тянуть в проект зависимость с её
// собственными зависимостями, обновлениями и уязвимостями не стоит:
// чем меньше чужого кода в основании, тем меньше поводов для
// внеплановых обновлений.
//
// Если Redis не настроен, шина не создаётся вовсе и всё работает как
// раньше — одним экземпляром.

type Bus struct {
	addr     string
	password string
	db       int
	channel  string

	// Идентификатор экземпляра. Свои же сообщения, вернувшиеся из
	// канала, нужно отбрасывать: они уже доставлены локально, и вторая
	// доставка означала бы дубли на экране.
	instance string

	mu      sync.Mutex
	pubConn net.Conn
	pubW    *bufio.Writer
	pubR    *bufio.Reader

	onMessage func(instance string, payload []byte)
	closed    chan struct{}
}

func NewBus(addr, password string, db int, channel, instance string) *Bus {
	if channel == "" {
		channel = "kanban:events"
	}
	return &Bus{
		addr: addr, password: password, db: db,
		channel: channel, instance: instance,
		closed: make(chan struct{}),
	}
}

// Start запускает слушателя. Подписка живёт в своём соединении:
// соединение в режиме подписки не принимает обычных команд, поэтому
// для публикации держится второе.
//
// Переподключение бесконечное, с паузой: Redis может перезапуститься,
// и приложение должно это пережить, а не замолчать навсегда.
func (b *Bus) Start(onMessage func(instance string, payload []byte)) {
	b.onMessage = onMessage
	go func() {
		for {
			select {
			case <-b.closed:
				return
			default:
			}
			if err := b.listen(); err != nil {
				slog.Warn("шина событий: подписка оборвалась", "error", err)
			}
			select {
			case <-b.closed:
				return
			case <-time.After(2 * time.Second):
			}
		}
	}()
}

func (b *Bus) Close() {
	close(b.closed)
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.pubConn != nil {
		_ = b.pubConn.Close()
		b.pubConn = nil
	}
}

// Publish отправляет событие в общий канал.
//
// Сообщение — это идентификатор экземпляра, перевод строки и сам
// payload. Так получатель сразу видит отправителя и отбрасывает свои
// собственные сообщения, не разбирая тело.
//
// Ошибка публикации не считается фатальной: событие уже доставлено
// своим соединениям, а остальные получат данные при следующем
// обновлении экрана. Ронять запрос пользователя из-за недоступного
// Redis было бы хуже.
func (b *Bus) Publish(payload []byte) {
	b.mu.Lock()
	defer b.mu.Unlock()

	if err := b.ensurePub(); err != nil {
		slog.Warn("шина событий: нет соединения для публикации", "error", err)
		return
	}
	msg := append([]byte(b.instance+"\n"), payload...)
	if err := writeCommand(b.pubW, "PUBLISH", b.channel, string(msg)); err != nil {
		// Соединение испорчено — закрываем, следующая попытка
		// поднимет новое.
		_ = b.pubConn.Close()
		b.pubConn = nil
		slog.Warn("шина событий: не удалось опубликовать", "error", err)
		return
	}
	// Ответ (число подписчиков) читать не обязательно, но его нужно
	// вычитать из буфера, иначе он накопится и собьёт следующий обмен.
	_ = b.drainReply()
}

func (b *Bus) ensurePub() error {
	if b.pubConn != nil {
		return nil
	}
	conn, r, err := b.dial()
	if err != nil {
		return err
	}
	b.pubConn = conn
	b.pubW = bufio.NewWriter(conn)
	b.pubR = r
	return nil
}

func (b *Bus) drainReply() error {
	if b.pubR == nil {
		return nil
	}
	_ = b.pubConn.SetReadDeadline(time.Now().Add(2 * time.Second))
	defer b.pubConn.SetReadDeadline(time.Time{})
	_, err := readReply(b.pubR)
	return err
}

func (b *Bus) listen() error {
	conn, r, err := b.dial()
	if err != nil {
		return err
	}
	defer conn.Close()

	w := bufio.NewWriter(conn)
	if err := writeCommand(w, "SUBSCRIBE", b.channel); err != nil {
		return err
	}

	for {
		select {
		case <-b.closed:
			return nil
		default:
		}
		// Без ограничения по времени: подписка может молчать часами,
		// и это нормально.
		parts, err := readMessage(r)
		if err != nil {
			return err
		}
		if len(parts) != 3 || parts[0] != "message" {
			continue // подтверждение подписки и прочая служебная переписка
		}
		raw := parts[2]
		nl := indexByte(raw, '\n')
		if nl < 0 {
			continue
		}
		from, payload := raw[:nl], raw[nl+1:]
		if from == b.instance {
			continue // своё уже доставлено
		}
		if b.onMessage != nil {
			b.onMessage(from, []byte(payload))
		}
	}
}

func (b *Bus) dial() (net.Conn, *bufio.Reader, error) {
	conn, err := net.DialTimeout("tcp", b.addr, 5*time.Second)
	if err != nil {
		return nil, nil, err
	}
	r := bufio.NewReader(conn)
	w := bufio.NewWriter(conn)

	if b.password != "" {
		if err := writeCommand(w, "AUTH", b.password); err != nil {
			conn.Close()
			return nil, nil, err
		}
		if _, err := readReply(r); err != nil {
			conn.Close()
			return nil, nil, fmt.Errorf("AUTH: %w", err)
		}
	}
	if b.db != 0 {
		if err := writeCommand(w, "SELECT", strconv.Itoa(b.db)); err != nil {
			conn.Close()
			return nil, nil, err
		}
		if _, err := readReply(r); err != nil {
			conn.Close()
			return nil, nil, fmt.Errorf("SELECT: %w", err)
		}
	}
	return conn, r, nil
}

// --- разбор протокола RESP ---
//
// Команды отправляются массивом строк (inline-формат Redis не
// поддерживает двоичные данные), ответы читаются ровно настолько,
// насколько нужно: тип, длина, тело.

func writeCommand(w *bufio.Writer, args ...string) error {
	fmt.Fprintf(w, "*%d\r\n", len(args))
	for _, a := range args {
		fmt.Fprintf(w, "$%d\r\n%s\r\n", len(a), a)
	}
	return w.Flush()
}

func readReply(r *bufio.Reader) (string, error) {
	line, err := r.ReadString('\n')
	if err != nil {
		return "", err
	}
	if len(line) < 1 {
		return "", fmt.Errorf("пустой ответ")
	}
	switch line[0] {
	case '+', ':', '-':
		return trimCRLF(line[1:]), nil
	case '$':
		n, err := strconv.Atoi(trimCRLF(line[1:]))
		if err != nil {
			return "", err
		}
		if n < 0 {
			return "", nil
		}
		buf := make([]byte, n+2) // тело плюс \r\n
		if _, err := ioReadFull(r, buf); err != nil {
			return "", err
		}
		return string(buf[:n]), nil
	case '*':
		// Массив читается вызывающей стороной (readMessage).
		return "", fmt.Errorf("неожиданный массив")
	}
	return "", fmt.Errorf("неизвестный тип ответа: %q", line[0])
}

// readMessage читает элемент подписки: массив из трёх строк
// (message, канал, тело).
func readMessage(r *bufio.Reader) ([]string, error) {
	line, err := r.ReadString('\n')
	if err != nil {
		return nil, err
	}
	if line[0] != '*' {
		return nil, fmt.Errorf("ожидался массив, получено %q", line[0])
	}
	n, err := strconv.Atoi(trimCRLF(line[1:]))
	if err != nil {
		return nil, err
	}
	out := make([]string, 0, n)
	for i := 0; i < n; i++ {
		v, err := readReply(r)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}

func trimCRLF(s string) string {
	for len(s) > 0 && (s[len(s)-1] == '\n' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}

func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}

func ioReadFull(r *bufio.Reader, buf []byte) (int, error) {
	total := 0
	for total < len(buf) {
		n, err := r.Read(buf[total:])
		total += n
		if err != nil {
			return total, err
		}
	}
	return total, nil
}
