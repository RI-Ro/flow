package handlers

import (
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Группы внутри личной команды.
//
// Команда из тридцати человек плоским списком неудобна: поручить задачу
// отделу снабжения значит выискивать пятерых по одному. Группы
// («Снабжение», «Сметчики», «Бригада Петрова») решают это: при
// назначении исполнителей группу раскрывают и выбирают внутри.
//
// Человек может состоять в нескольких группах или ни в одной — группа
// это ярлык, а не подразделение. Входить в группу может только
// участник команды: это обеспечивает внешний ключ в базе, так что
// убранный из команды человек сам исчезает из всех её групп.

type teamGroup struct {
	ID      uuid.UUID   `json:"id"`
	Title   string      `json:"title"`
	Members []uuid.UUID `json:"members"`
}

// ListTeamGroups — группы текущего пользователя в заданном им порядке.
func (s *Server) ListTeamGroups(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []teamGroup{}

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT g.id, g.title,
			       COALESCE(array_agg(m.member_id) FILTER (WHERE m.member_id IS NOT NULL), '{}')
			  FROM app.team_groups g
			  LEFT JOIN app.team_group_members m ON m.group_id = g.id
			 WHERE g.owner_id = $1
			 GROUP BY g.id, g.title, g.position, g.created_at
			 ORDER BY g.position, g.created_at`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var g teamGroup
			if e := rows.Scan(&g.ID, &g.Title, &g.Members); e != nil {
				return e
			}
			out = append(out, g)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type teamGroupInput struct {
	ID      *uuid.UUID  `json:"id"`
	Title   string      `json:"title"`
	Members []uuid.UUID `json:"members"`
}

// SaveTeamGroups заменяет набор групп целиком.
//
// Целиком, а не по одной группе: в окне команды человек переименовывает,
// переставляет и раскладывает людей за один заход, и сохранять это
// кусками значило бы получать промежуточные состояния — например,
// группу, из которой человека уже убрали, а в соседнюю ещё не добавили.
//
// Идентификаторы существующих групп сохраняются: так ссылки на группу
// не рвутся между сохранениями. Новые группы получают свой id здесь.
//
// Участники группы, которых нет в команде, добавляются в команду
// автоматически: выбрать человека в группу и получить ошибку «сначала
// добавьте его в команду» — лишний шаг, смысл которого очевиден.
func (s *Server) SaveTeamGroups(c *fiber.Ctx) error {
	var in []teamGroupInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Сохраняемые id — чтобы удалить только исчезнувшие группы.
		keep := []uuid.UUID{}
		for _, g := range in {
			if g.ID != nil {
				keep = append(keep, *g.ID)
			}
		}
		if _, e := tx.Exec(c.Context(), `
			DELETE FROM app.team_groups
			 WHERE owner_id = $1 AND NOT (id = ANY ($2::uuid[]))`, uid, keep); e != nil {
			return e
		}

		for pos, g := range in {
			title := strings.TrimSpace(g.Title)
			if title == "" {
				return httpx.Err(fiber.StatusBadRequest, "no_title",
					"У каждой группы должно быть название")
			}

			id := uuid.New()
			if g.ID != nil {
				id = *g.ID
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.team_groups (id, owner_id, title, position)
				VALUES ($1, $2, $3, $4)
				ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, position = EXCLUDED.position`,
				id, uid, title, pos); e != nil {
				return e
			}

			// Себя в группу не включаем: в команду себя добавить
			// нельзя (ограничение в базе), и группа — про тех, кому
			// поручают.
			members := make([]uuid.UUID, 0, len(g.Members))
			for _, m := range g.Members {
				if m != uid && m != uuid.Nil {
					members = append(members, m)
				}
			}

			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.team_members (owner_id, member_id)
				SELECT $1, m FROM unnest($2::uuid[]) AS m
				ON CONFLICT DO NOTHING`, uid, members); e != nil {
				return e
			}
			if _, e := tx.Exec(c.Context(),
				`DELETE FROM app.team_group_members WHERE group_id = $1`, id); e != nil {
				return e
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.team_group_members (group_id, owner_id, member_id)
				SELECT $1, $2, m FROM unnest($3::uuid[]) AS m
				ON CONFLICT DO NOTHING`, id, uid, members); e != nil {
				return e
			}
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.ListTeamGroups(c)
}
