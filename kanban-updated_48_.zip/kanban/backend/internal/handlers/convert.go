package handlers

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
)

// Конвертация офисных документов в PDF для предпросмотра.
//
// Разбор docx на клиенте давал текст без вёрстки, а .doc, .odt и .rtf
// браузером не разбираются вовсе. Поэтому документ превращает в PDF
// сервер — тем же LibreOffice, которым его открыли бы вручную, — и в
// браузер уходит PDF.
//
// Устройство рабочей папки.
//
// Папка одна на всех и задаётся в конфигурации (convert.dir). Никаких
// временных каталогов на каждый запуск: результат LibreOffice кладёт
// прямо в неё, файл отдаётся пользователю и сразу удаляется. Хранить
// переконвертированные копии нельзя — это второй экземпляр рабочего
// документа, который никто не учитывает и не чистит.
//
// Профиль LibreOffice тоже живёт в этой папке, в подкаталоге profile, и
// создаётся один раз. Два процесса с одним профилем мешают друг другу
// (второй зависает или падает), поэтому запуски идут строго по одному —
// это обеспечивает convertMu. Для предпросмотра так даже правильнее:
// конвертация тяжёлая, и десяток параллельных копий LibreOffice
// заняли бы всю память сервера.
//
// ВАЖНО: нужен установленный LibreOffice. Проверить: `soffice --version`.

var convertible = map[string]bool{
	".doc": true, ".docx": true, ".odt": true, ".rtf": true,
	".xls": true, ".xlsx": true, ".ods": true, ".csv": true,
	".ppt": true, ".pptx": true, ".odp": true,
}

func convertibleName(filename string) bool {
	return convertible[strings.ToLower(filepath.Ext(filename))]
}

var convertMu sync.Mutex

// convertToPDF возвращает содержимое PDF-версии файла.
//
// Файл результата удаляется до возврата — в любом случае, в том числе
// при ошибке чтения: после выхода из функции в рабочей папке от этого
// запуска не остаётся ничего.
func (s *Server) convertToPDF(ctx context.Context, key, filename string) ([]byte, error) {
	if !convertibleName(filename) {
		return nil, errors.New("формат не конвертируется")
	}

	srcPath, err := s.files.Path(key)
	if err != nil {
		return nil, err
	}

	dir := s.cfg.ConvertDir
	if err := os.MkdirAll(dir, 0o750); err != nil {
		return nil, fmt.Errorf("рабочая папка конвертации недоступна: %w", err)
	}
	absDir, err := filepath.Abs(dir)
	if err != nil {
		return nil, err
	}
	profile := filepath.Join(absDir, "profile")

	convertMu.Lock()
	defer convertMu.Unlock()

	// Имя результата LibreOffice выбирает сам — имя исходника с
	// расширением .pdf. Ключи хранилища уникальны, поэтому и имена
	// результатов не пересекаются; а одновременные запуски исключает
	// замок выше.
	outPath := filepath.Join(absDir,
		strings.TrimSuffix(filepath.Base(srcPath), filepath.Ext(srcPath))+".pdf")

	// Удаление — первым делом в defer, до запуска: даже если процесс
	// упадёт на полпути и оставит недописанный файл, он не
	// переживёт этот запрос.
	defer func() {
		if e := os.Remove(outPath); e != nil && !errors.Is(e, os.ErrNotExist) {
			slog.Warn("не удалось удалить переконвертированный файл",
				"error", e, "path", outPath)
		}
	}()

	// Минута с запасом: первый запуск поднимает профиль, дальше
	// конвертация укладывается в секунды. Без предела зависший процесс
	// держал бы запрос — и замок — бесконечно.
	runCtx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	cmd := exec.CommandContext(runCtx, "soffice",
		"--headless", "--norestore", "--nolockcheck",
		"-env:UserInstallation=file://"+profile,
		"--convert-to", "pdf", "--outdir", absDir, srcPath)

	out, err := cmd.CombinedOutput()
	if err != nil {
		slog.Error("конвертация документа не удалась",
			"error", err, "file", filename, "output", string(out))
		if errors.Is(runCtx.Err(), context.DeadlineExceeded) {
			return nil, errors.New("конвертация заняла слишком много времени")
		}
		if errors.Is(err, exec.ErrNotFound) {
			return nil, errors.New("на сервере не установлен LibreOffice — предпросмотр этого формата недоступен")
		}
		return nil, errors.New("не удалось подготовить предпросмотр")
	}

	data, err := os.ReadFile(outPath)
	if err != nil {
		return nil, errors.New("конвертер не создал файл")
	}
	return data, nil
}

// sendConvertedPDF отдаёт PDF из памяти.
//
// Именно из памяти, а не с диска: к моменту отправки файл уже удалён
// (см. convertToPDF), и в рабочей папке после запроса ничего не
// остаётся. PDF предпросмотра — единицы мегабайт, держать его в памяти
// на время одного ответа безопасно.
func sendConvertedPDF(c *fiber.Ctx, data []byte, filename string) error {
	c.Set(fiber.HeaderContentType, "application/pdf")
	c.Set(fiber.HeaderContentDisposition,
		`inline; filename="preview.pdf"; filename*=UTF-8''`+urlPathEscape(filename+".pdf"))
	// Кэшировать не даём: это копия документа, и оседать в кэше браузера
	// или промежуточного прокси она не должна.
	c.Set(fiber.HeaderCacheControl, "no-store")
	return c.Send(data)
}

func urlPathEscape(s string) string {
	var b strings.Builder
	for _, r := range []byte(s) {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9',
			r == '.', r == '-', r == '_':
			b.WriteByte(r)
		default:
			fmt.Fprintf(&b, "%%%02X", r)
		}
	}
	return b.String()
}
