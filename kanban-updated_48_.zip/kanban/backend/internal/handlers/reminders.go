package handlers

import (
	"log/slog"
	"context"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// =====================================================================
// Напоминания («будильники») и настройки категорий уведомлений.
// =====================================================================

type reminder struct {
	ID            uuid.UUID `json:"id"`
	Title         string    `json:"title"`
	RemindAt      string    `json:"remindAt"` // ISO datetime
	RecurFreq     string    `json:"recurFreq"`
	RecurInterval int       `json:"recurInterval"`
	RecurWeekdays []int     `json:"recurWeekdays"`
	Active        bool      `json:"active"`
	// Необязательная привязка к задаче: напоминание «сдать отчёт по
	// задаче N» должно уметь открыть эту задачу, а не заставлять
	// искать её руками в момент, когда будильник уже звонит.
	TaskID    *uuid.UUID `json:"taskId"`
	TaskTitle string     `json:"taskTitle"`
}

// Время отдаётся в UTC с явным суффиксом Z.
//
// Раньше здесь был to_char без указания зоны: результат зависел от
// часового пояса сессии базы и уходил клиенту строкой без смещения, а
// браузер разбирал такую строку как ЛОКАЛЬНОЕ время. На сервере в UTC
// и пользователе в UTC+3 напоминание показывалось на три часа раньше,
// чем было заведено. С явным Z однозначность восстановлена: в базе
// timestamptz, по проводу — UTC, на экране — местное время браузера.
const reminderTimeExpr = `to_char(remind_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`

// task_title подтягивается через app.task_title_visible: название
// показывается, только если задача пользователю доступна. Задачу могли
// перенести в чужой проект или закрыть от него доступ — напоминание
// при этом остаётся, но раскрывать чужой заголовок оно не должно.
const reminderCols = `id, title, ` + reminderTimeExpr + `,
	       recur_freq, recur_interval, recur_weekdays, active,
	       task_id, COALESCE(app.task_title_visible(task_id, user_id), '')`

const reminderSelect = `SELECT ` + reminderCols + ` FROM app.reminders`

func scanReminder(row pgx.Row) (reminder, error) {
	var r reminder
	err := row.Scan(&r.ID, &r.Title, &r.RemindAt, &r.RecurFreq, &r.RecurInterval,
		&r.RecurWeekdays, &r.Active, &r.TaskID, &r.TaskTitle)
	return r, err
}

func (s *Server) ListReminders(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []reminder{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), reminderSelect+` WHERE user_id = $1 ORDER BY remind_at`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			r, e := scanReminder(rows)
			if e != nil {
				return e
			}
			out = append(out, r)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type reminderInput struct {
	Title         string  `json:"title"`
	RemindAt      string  `json:"remindAt"`
	RecurFreq     string  `json:"recurFreq"`
	RecurInterval int     `json:"recurInterval"`
	RecurWeekdays []int   `json:"recurWeekdays"`
	Active        *bool   `json:"active"`
	// Привязка к задаче. Отсутствие поля и явный null означают одно и
	// то же — «без задачи»: форма напоминания всегда присылает состав
	// целиком, поэтому различать «не менять» здесь не требуется.
	TaskID *uuid.UUID `json:"taskId"`
}

func (s *Server) CreateReminder(c *fiber.Ctx) error {
	var in reminderInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Title == "" || in.RemindAt == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Укажите название и время напоминания"))
	}
	freq, interval, week := normalizeReminderRecur(in.RecurFreq, in.RecurInterval, in.RecurWeekdays)
	uid := s.uid(c)
	var r reminder
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			INSERT INTO app.reminders (user_id, title, remind_at, recur_freq, recur_interval,
			                           recur_weekdays, task_id)
			VALUES ($1, $2, $3::timestamptz, $4, $5, $6,
			        -- Привязать можно только видимую задачу: иначе по
			        -- ошибке или намеренно в напоминание попал бы чужой
			        -- идентификатор, а вместе с ним и название задачи.
			        (SELECT $7::uuid WHERE $7::uuid IS NULL
			              OR app.can_see_task($7::uuid, $1)))
			RETURNING ` + reminderCols,
			uid, in.Title, in.RemindAt, freq, interval, week, in.TaskID)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusCreated, r)
}

func (s *Server) UpdateReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in reminderInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	freq, interval, week := normalizeReminderRecur(in.RecurFreq, in.RecurInterval, in.RecurWeekdays)
	active := true
	if in.Active != nil {
		active = *in.Active
	}
	uid := s.uid(c)
	var r reminder
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			UPDATE app.reminders
			   SET title = COALESCE(NULLIF($2,''), title),
			       remind_at = COALESCE(NULLIF($3,'')::timestamptz, remind_at),
			       recur_freq = $4, recur_interval = $5, recur_weekdays = $6, active = $7,
			       last_fired = CASE WHEN $3 <> '' THEN NULL ELSE last_fired END,
			       task_id = (SELECT $9::uuid WHERE $9::uuid IS NULL
			                       OR app.can_see_task($9::uuid, $8))
			 WHERE id = $1 AND user_id = $8
			 RETURNING ` + reminderCols,
			id, in.Title, in.RemindAt, freq, interval, week, active, uid, in.TaskID)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, r)
}

type snoozeInput struct {
	Minutes int `json:"minutes"`
}

// SnoozeReminder переносит напоминание на несколько минут вперёд.
//
// Отдельный маршрут, а не обычный PATCH: окно будильника знает о
// напоминании только идентификатор и название, а PATCH переписывает и
// правило повторения — отправив его пустым, клиент незаметно превратил
// бы ежедневное напоминание в разовое.
//
// Однократное напоминание при срабатывании отключается (advance_reminder),
// поэтому перенос заодно включает его обратно и сбрасывает отметку о
// срабатывании — иначе оно бы не прозвонило снова.
//
// У повторяющегося напоминания перенос сдвигает и точку отсчёта
// следующего раза: отложив ежедневное на пять минут, вы получите его
// завтра на пять минут позже. Это осознанный размен на простоту —
// хранить «отложено до» отдельным полем ради этого случая не стоит.
func (s *Server) SnoozeReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in snoozeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Minutes < 1 || in.Minutes > 24*60 {
		in.Minutes = 5
	}
	uid := s.uid(c)

	var r reminder
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			UPDATE app.reminders
			   SET remind_at  = now() + ($2::int * interval '1 minute'),
			       active     = true,
			       last_fired = NULL
			 WHERE id = $1 AND user_id = $3
			 RETURNING id, title, `+reminderTimeExpr+`,
			           recur_freq, recur_interval, recur_weekdays, active`,
			id, in.Minutes, uid)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, r)
}

func (s *Server) DeleteReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `DELETE FROM app.reminders WHERE id = $1 AND user_id = $2`, id, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.NoContent(c)
}

func normalizeReminderRecur(freq string, interval int, week []int) (string, int, []int) {
	switch freq {
	case "daily", "weekly", "monthly":
	default:
		return "none", 1, []int{}
	}
	if interval < 1 {
		interval = 1
	}
	if week == nil || freq != "weekly" {
		week = []int{}
	}
	return freq, interval, week
}

// ── настройки категорий уведомлений ──────────────────────────────────

func (s *Server) GetNotificationPrefs(c *fiber.Ctx) error {
	uid := s.uid(c)
	prefs := map[string]bool{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT category, enabled FROM app.notification_prefs WHERE user_id = $1`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var cat string
			var en bool
			if e := rows.Scan(&cat, &en); e != nil {
				return e
			}
			prefs[cat] = en
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, prefs)
}

type prefInput struct {
	Category string `json:"category"`
	Enabled  bool   `json:"enabled"`
}

func (s *Server) SetNotificationPref(c *fiber.Ctx) error {
	var in prefInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Category == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Не указана категория"))
	}
	uid := s.uid(c)
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.notification_prefs (user_id, category, enabled)
			VALUES ($1, $2, $3)
			ON CONFLICT (user_id, category) DO UPDATE SET enabled = EXCLUDED.enabled`,
			uid, in.Category, in.Enabled)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"category": in.Category, "enabled": in.Enabled})
}

// ── фоновый опрос напоминаний ────────────────────────────────────────

// StartReminderPoller запускает фоновый цикл, который раз в минуту
// находит сработавшие напоминания, создаёт по ним уведомления и
// переносит повторяющиеся на следующий раз. Работает от системного
// пула (без RLS), поэтому пишет через app.notify_cat напрямую.
func (s *Server) StartReminderPoller(ctx context.Context, pool *pgxpool.Pool) {
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				// Опрос ведёт только один экземпляр приложения.
				//
				// При нескольких процессах (prefork) или нескольких
				// серверах за балансировщиком каждый поднимал бы свой
				// таймер, и человек получал бы столько будильников,
				// сколько запущено экземпляров. Договариваться между
				// собой им негде, зато есть общая база: рекомендательная
				// блокировка Postgres выдаётся ровно одному
				// соединению, остальные получают отказ и пропускают
				// оборот.
				//
				// Блокировка берётся и отпускается на каждом обороте, а
				// не удерживается постоянно: если экземпляр, взявший
				// её, умрёт, следующий подхватит работу через минуту, а
				// не будет ждать освобождения.
				if s.tryReminderLock(ctx, pool) {
					s.fireDueReminders(ctx, pool)
					s.releaseReminderLock(ctx, pool)
				}
			}
		}
	}()
}

func (s *Server) fireDueReminders(ctx context.Context, pool *pgxpool.Pool) {
	// due_reminders — SECURITY DEFINER, поэтому обходит RLS: фоновый
	// процесс не выставляет app.user_id и иначе не увидел бы строк.
	rows, err := pool.Query(ctx, `SELECT * FROM app.due_reminders()`)
	if err != nil {
		return
	}
	type due struct {
		id, user    uuid.UUID
		title, freq string
		interval    int
		weekdays    []int
		task        *uuid.UUID
	}
	var list []due
	for rows.Next() {
		var d due
		if e := rows.Scan(&d.id, &d.user, &d.title, &d.freq, &d.interval, &d.weekdays, &d.task); e != nil {
			continue
		}
		list = append(list, d)
	}
	rows.Close()

	for _, d := range list {
		var nid uuid.UUID
		var createdAt time.Time
		body := "Напоминание: " + d.title
		// notify_cat уважает настройку категории «reminder»; при
		// отключённой категории вернёт 0 строк — уведомление не шлём,
		// но расписание всё равно двигаем.
		// Привязанная задача попадает и в уведомление: из списка
		// уведомлений по нему можно будет сразу открыть карточку.
		err := pool.QueryRow(ctx,
			`SELECT id, created_at FROM app.notify_cat($1, $2, 'reminder', NULL, $3)`,
			d.user, body, d.task).Scan(&nid, &createdAt)
		if err == nil {
			n := notifModel(nid, createdAt, body)
			n.TaskID = d.task
			s.publishNotification(d.user, n)
			s.pingNotifications([]uuid.UUID{d.user})
		}
		// Окно будильника на экране показывается по этому событию, а не
		// по уведомлению: ему нужен идентификатор напоминания для
		// переноса на пять минут.
		s.publishReminder(d.user, d.id, d.title, d.task)
		_, _ = pool.Exec(ctx, `SELECT app.advance_reminder($1)`, d.id)
	}
}

// notifModel собирает модель уведомления для WS-публикации.
func notifModel(id uuid.UUID, createdAt time.Time, body string) models.Notification {
	return models.Notification{ID: id, Body: body, CreatedAt: createdAt}
}

// Ключ рекомендательной блокировки. Произвольное, но постоянное число:
// важно лишь, чтобы никакая другая часть системы не использовала то
// же самое.
const reminderLockKey = 776_120_001

func (s *Server) tryReminderLock(ctx context.Context, pool *pgxpool.Pool) bool {
	var ok bool
	if err := pool.QueryRow(ctx,
		`SELECT pg_try_advisory_lock($1)`, reminderLockKey).Scan(&ok); err != nil {
		slog.Warn("напоминания: не удалось взять блокировку", "error", err)
		return false
	}
	return ok
}

func (s *Server) releaseReminderLock(ctx context.Context, pool *pgxpool.Pool) {
	if _, err := pool.Exec(ctx,
		`SELECT pg_advisory_unlock($1)`, reminderLockKey); err != nil {
		slog.Warn("напоминания: не удалось отпустить блокировку", "error", err)
	}
}
