package main

import (
	"fmt"
	"runtime"
	"context"
	"flag"
	"errors"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/database"
	"github.com/example/kanban/internal/handlers"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/realtime"
	"github.com/example/kanban/internal/storage"
)

func main() {
	if err := run(); err != nil {
		slog.Error("запуск не удался", "error", err)
		os.Exit(1)
	}
}

func run() error {
	// Путь к конфигурации задаётся флагом либо переменной окружения.
	// Флаг важнее: в systemd-юните удобно передать его прямо в
	// ExecStart, не заводя ради этого файл окружения.
	configPath := flag.String("config", os.Getenv("CONFIG_FILE"),
		"путь к config.yaml (по умолчанию ищется ./config.yaml)")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		return err
	}

	level := slog.LevelDebug
	if cfg.IsProduction() {
		level = slog.LevelInfo
	}
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: level})))

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	db, err := database.New(ctx, cfg.DatabaseURL, cfg.DBPoolSize, cfg.DBMinIdle)
	if err != nil {
		return err
	}
	defer db.Close()

	files, err := storage.NewLocal(cfg.UploadDir, cfg.MaxUploadBytes)
	if err != nil {
		return err
	}

	// Вне production подробности ошибок БД возвращаются клиенту —
	// иначе «500» невозможно диагностировать, не имея доступа к логам.
	httpx.SetProduction(cfg.IsProduction())

	// Число процессов при prefork Fiber берёт из GOMAXPROCS, поэтому
	// отдельный параметр «сколько воркеров» задаётся именно так.
	// Ноль означает «по числу ядер» — трогать ничего не нужно.
	if cfg.Prefork && cfg.PreforkWorkers > 0 {
		runtime.GOMAXPROCS(cfg.PreforkWorkers)
	}

	hub := realtime.NewHub()

	// Общая шина событий. Нужна, когда экземпляров приложения больше
	// одного: prefork или несколько серверов за балансировщиком. Без
	// адреса Redis не создаётся вовсе, и всё работает как раньше.
	if cfg.RedisAddr != "" {
		// Идентификатор экземпляра — чтобы отличать свои сообщения,
		// вернувшиеся из канала, от чужих. Имя хоста плюс номер
		// процесса: при prefork хост один, а процессы разные.
		host, _ := os.Hostname()
		instance := fmt.Sprintf("%s-%d", host, os.Getpid())

		bus := realtime.NewBus(cfg.RedisAddr, cfg.RedisPassword, cfg.RedisDB,
			cfg.RedisChannel, instance)
		hub.AttachBus(bus)
		defer bus.Close()
		slog.Info("общая шина событий включена",
			"redis", cfg.RedisAddr, "channel", cfg.RedisChannel, "instance", instance)
	}
	am := auth.NewManager(cfg.JWTSecret, cfg.AccessTTL, cfg.RefreshTTL)
	srv := handlers.New(cfg, db, am, files, hub)
	// Фоновый опрос напоминаний («будильники»): раз в минуту.
	srv.StartReminderPoller(ctx, db.Pool)
	app := srv.App()

	errCh := make(chan error, 1)
	go func() {
		slog.Info("сервер запущен",
			"addr", cfg.Addr, "env", cfg.Env, "dbPool", cfg.DBPoolSize)
		if err := app.Listen(cfg.Addr); err != nil {
			errCh <- err
		}
	}()

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		slog.Info("получен сигнал завершения, останавливаемся")
	}

	shutdownCtx, stop := context.WithTimeout(context.Background(), 20*time.Second)
	defer stop()
	if err := app.ShutdownWithContext(shutdownCtx); err != nil && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	return nil
}
