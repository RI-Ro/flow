-- =====================================================================
-- 0017_recurrence_column.sql — повтор задачи появляется в той же
-- колонке, где шла работа.
--
-- Было: следующий экземпляр цикличной задачи всегда создавался в
-- первой рабочей колонке доски. Для «Очередь → В работе → Проверка»
-- это ещё терпимо, а для досок, где первая колонка — «Входящие» или
-- «Идеи», каждый повтор уезжал не туда, и его переставляли руками.
--
-- Стало: берётся колонка, в которой задача находилась до завершения.
-- Порядок поиска:
--
--   1. prev_column_id — колонка, из которой задачу закрыли (её
--      запоминает завершение задачи, см. 0010);
--   2. текущая колонка, если она рабочая — на случай, когда повтор
--      порождён не через завершение;
--   3. первая рабочая колонка — как раньше, если первых двух нет
--      (колонку могли удалить).
--
-- Проверка `NOT is_done` обязательна на каждом шаге: новый экземпляр
-- не должен родиться сразу в «Готово».
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0017_recurrence_column.sql
--
-- Запускать от app_owner, после 0016_ready_for_review.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE OR REPLACE FUNCTION app.spawn_recurrence(p_task uuid, p_actor uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r       app.tasks%ROWTYPE;
    v_base  date;
    v_next  date;
    v_col   uuid;
    v_new   uuid := gen_random_uuid();
    v_guard int := 0;
    v_dow   int;
BEGIN
    SELECT * INTO r FROM app.tasks WHERE id = p_task;
    IF NOT FOUND OR r.recur_freq = 'none' THEN RETURN NULL; END IF;

    v_base := COALESCE(r.due_date, current_date);

    IF r.recur_freq = 'daily' THEN
        v_next := v_base + (r.recur_interval || ' days')::interval;
    ELSIF r.recur_freq = 'monthly' THEN
        v_next := (v_base + (r.recur_interval || ' months')::interval)::date;
        IF r.recur_monthday IS NOT NULL THEN
            v_next := LEAST(
                date_trunc('month', v_next)::date + (r.recur_monthday - 1),
                (date_trunc('month', v_next) + interval '1 month - 1 day')::date);
        END IF;
    ELSIF r.recur_freq = 'weekly' THEN
        IF array_length(r.recur_weekdays, 1) IS NULL THEN
            -- Дни не выбраны: отсчёт с понедельника — следующий
            -- понедельник через (interval-1) полных недель.
            -- ISODOW: 1=Пн..7=Вс.
            v_next := (v_base + ((r.recur_interval - 1) * 7 || ' days')::interval)::date;
            v_next := v_next + ((8 - EXTRACT(isodow FROM v_next)::int) % 7);
            IF v_next <= v_base THEN
                v_next := v_next + 7;
            END IF;
        ELSE
            v_next := v_base;
            LOOP
                v_next := v_next + 1;
                v_guard := v_guard + 1;
                v_dow := EXTRACT(dow FROM v_next)::int; -- 0=Вс..6=Сб
                EXIT WHEN v_dow = ANY (r.recur_weekdays) OR v_guard > 370;
            END LOOP;
        END IF;
    END IF;

    IF v_next IS NULL THEN RETURN NULL; END IF;
    IF r.recur_until IS NOT NULL AND v_next > r.recur_until THEN RETURN NULL; END IF;

    -- Колонка для нового экземпляра: та, где шла работа.
    --
    -- Завершение переносит задачу в «Готово» и запоминает прежнюю
    -- колонку в prev_column_id — именно её и берём. Если её нет
    -- (повтор создан не через завершение) — текущую, если она рабочая.
    -- В крайнем случае первую рабочую, как было раньше.
    SELECT c.id INTO v_col
      FROM app.columns c
     WHERE c.id = r.prev_column_id AND c.board_id = r.board_id AND NOT c.is_done;

    IF v_col IS NULL THEN
        SELECT c.id INTO v_col
          FROM app.columns c
         WHERE c.id = r.column_id AND c.board_id = r.board_id AND NOT c.is_done;
    END IF;

    IF v_col IS NULL THEN
        SELECT id INTO v_col FROM app.columns
         WHERE board_id = r.board_id AND NOT is_done ORDER BY position LIMIT 1;
    END IF;

    IF v_col IS NULL THEN RETURN NULL; END IF;

    INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
                           due_date, tags, incoming_number, incoming_date, position, created_by,
                           recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
    VALUES (v_new, r.board_id, v_col, r.title, r.description, r.priority, r.color,
            v_next, r.tags, r.incoming_number, r.incoming_date,
            COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = v_col), 0), r.created_by,
            r.recur_freq, r.recur_interval, r.recur_weekdays, r.recur_monthday, r.recur_until);

    INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
    SELECT v_new, body, false, position, assignee_id, due_date, created_by
      FROM app.task_steps WHERE task_id = p_task;

    INSERT INTO app.task_assignees (task_id, user_id)
    SELECT v_new, user_id FROM app.task_assignees WHERE task_id = p_task
    ON CONFLICT DO NOTHING;

    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (v_new, p_actor, 'Создана по расписанию (повторение задачи)');
    RETURN v_new;
END $$;

-- Готово.
