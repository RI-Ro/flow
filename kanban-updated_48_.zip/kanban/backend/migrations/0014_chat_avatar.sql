-- =====================================================================
-- 0014_chat_avatar.sql — изображение группового чата.
--
-- У группового чата, кроме названия, должна быть картинка: в списке из
-- десятка чатов глаз находит её быстрее, чем читает названия. Личному
-- чату картинка не нужна — его «лицо» это аватар собеседника.
--
-- Ссылка на app.files, а не отдельное хранилище: файлы уже лежат там,
-- с владельцем, размером и контрольной суммой. ON DELETE SET NULL —
-- если файл почему-то удалён, чат остаётся без картинки, а не
-- ломается.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0014_chat_avatar.sql
--
-- Запускать от app_owner, после 0013_watchers_visibility.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

ALTER TABLE app.chats
    ADD COLUMN IF NOT EXISTS avatar_file_id uuid REFERENCES app.files(id) ON DELETE SET NULL;

-- Картинка чата видна его участникам. Отдельная политика на app.files:
-- в Postgres несколько разрешающих политик складываются по ИЛИ, и эта
-- дополняет уже существующие (вложения задач, файлы из переписки).
DROP POLICY IF EXISTS files_select_chat_avatar ON app.files;
CREATE POLICY files_select_chat_avatar ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chats c
                    WHERE c.avatar_file_id = app.files.id
                      AND app.in_chat(c.id, app.current_user_id())));

-- Установка и снятие картинки — через функцию с проверкой прав:
-- распоряжается ею владелец группового чата, как и названием.
CREATE OR REPLACE FUNCTION app.set_chat_avatar(p_chat uuid, p_user uuid, p_file uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;
    IF v_kind IS DISTINCT FROM 'group' OR v_owner IS DISTINCT FROM p_user THEN
        RETURN false;
    END IF;
    UPDATE app.chats SET avatar_file_id = p_file, updated_at = now() WHERE id = p_chat;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_chat_avatar(uuid, uuid, uuid) TO app_user;

-- Готово.
