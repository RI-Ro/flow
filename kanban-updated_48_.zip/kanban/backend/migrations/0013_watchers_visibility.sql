-- =====================================================================
-- 0013_watchers_visibility.sql — уведомления только по видимым задачам.
--
-- После 0011 участник проекта в роли исполнителя видит не все задачи
-- проекта, а только свои. Но список получателей уведомлений остался
-- прежним — «все участники доски», — и человеку приходили сообщения о
-- задачах, которых он не видит. Переход по такому уведомлению
-- заканчивался отказом в доступе.
--
-- Правится там же, где и видимость: app.task_watchers теперь
-- отфильтрован по app.task_access. Одна функция отвечает и за рассылку
-- событий, и за уведомления, поэтому чинится сразу всё — комментарии,
-- чек-лист, смена срока, вложения.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0013_watchers_visibility.sql
--
-- Запускать от app_owner, после 0012_chat_personal.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
    ),
    everyone AS (
        SELECT user_id FROM base
        UNION
        -- Замещающий получает то же, что и замещаемый: иначе на время
        -- отпуска задача остаётся без присмотра.
        SELECT d.deputy_id FROM base b
          JOIN app.delegations d ON d.grantor_id = b.user_id
         WHERE current_date BETWEEN d.starts_at AND d.ends_at
    )
    -- Последний рубеж: уведомление о задаче получает только тот, кто
    -- эту задачу может открыть. Проверка идёт через ту же функцию, что
    -- и политики RLS, поэтому список получателей не может разойтись с
    -- правами доступа.
    SELECT e.user_id FROM everyone e
     WHERE app.task_access(p_task, e.user_id) IS NOT NULL
$$;

-- ─────────────────────────────────────────────────────────────────────
-- ОТМЕТКИ О ПРОЧТЕНИИ В ПЕРЕПИСКЕ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Одна галочка — сообщение доставлено (оно в базе), две — прочитано
-- всеми остальными участниками чата. Второе определяется по отметкам
-- last_read_at: если самая ранняя из чужих отметок позже времени
-- сообщения, значит его прочитали все.
--
-- Минимум, а не «хоть кто-то»: в групповом чате две галочки должны
-- означать, что сообщение дошло до всех, иначе они ничего не сообщают.
CREATE OR REPLACE FUNCTION app.chat_read_through(p_chat uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT min(m.last_read_at)
      FROM app.chat_members m
     WHERE m.chat_id = p_chat AND m.user_id <> p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_read_through(uuid, uuid) TO app_user;

-- Готово.
