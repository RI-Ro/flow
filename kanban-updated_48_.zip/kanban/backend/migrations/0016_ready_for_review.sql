-- =====================================================================
-- 0016_ready_for_review.sql
--
--   1. Отметка «задача готова к сдаче».
--   2. Окно правки сообщений в переписке — как у комментариев.
--   3. Настройка «уведомления по чужим задачам» перестала работать —
--      починка.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0016_ready_for_review.sql
--
-- Запускать от app_owner, после 0015_attachment_rules.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ГОТОВНОСТЬ К СДАЧЕ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Между «работаю» и «завершено» есть состояние, которого не хватало:
-- исполнитель закончил и ждёт приёмки. Завершать задачу он не вправе —
-- это решение автора, — а сказать «готово» кроме комментария было
-- негде, и такие сообщения тонули в переписке.
--
-- Хранится время, а не признак: видно, сколько задача ждёт приёмки, и
-- кто именно её сдал.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS ready_at timestamptz,
    ADD COLUMN IF NOT EXISTS ready_by uuid REFERENCES app.users(id) ON DELETE SET NULL;

-- Отметку ставит и снимает исполнитель задачи. Автор и редактор
-- проекта тоже могут снять её — если приёмка не состоялась, задача
-- возвращается в работу, и ждать этого от исполнителя неправильно.
CREATE OR REPLACE FUNCTION app.set_task_ready(p_task uuid, p_user uuid, p_ready boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_assignee boolean;
    v_manage boolean;
BEGIN
    SELECT EXISTS (SELECT 1 FROM app.task_assignees a
                    WHERE a.task_id = p_task
                      AND a.user_id IN (SELECT app.effective_users(p_user)))
      INTO v_assignee;
    SELECT app.task_access(p_task, p_user) = 'edit' INTO v_manage;

    IF p_ready AND NOT v_assignee THEN
        RETURN false;
    END IF;
    IF NOT p_ready AND NOT (v_assignee OR v_manage) THEN
        RETURN false;
    END IF;

    UPDATE app.tasks
       SET ready_at = CASE WHEN p_ready THEN now() ELSE NULL END,
           ready_by = CASE WHEN p_ready THEN p_user ELSE NULL END
     WHERE id = p_task;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_task_ready(uuid, uuid, boolean) TO app_user;

-- Завершение задачи снимает готовность: она уже не «ждёт приёмки», а
-- принята. Возврат в работу отметку не восстанавливает — сдавать
-- заново придётся осознанно.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();

CREATE INDEX IF NOT EXISTS tasks_ready_idx ON app.tasks (ready_at)
    WHERE ready_at IS NOT NULL;

-- ─────────────────────────────────────────────────────────────────────
-- 2. ОКНО ПРАВКИ СООБЩЕНИЙ.
-- ─────────────────────────────────────────────────────────────────────
--
-- У комментариев к задаче правка и удаление разрешены автору в течение
-- часа: сказанное час назад уже могло повлиять на решения, и менять
-- его задним числом — переписывать историю. В переписке правило было
-- бессрочным, хотя причина та же.
--
-- Час — тот же порог, что у комментариев: разные сроки в двух местах
-- пришлось бы запоминать.
DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

-- ─────────────────────────────────────────────────────────────────────
-- 3. УВЕДОМЛЕНИЯ ПО ЧУЖИМ ЗАДАЧАМ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Настройка проверялась только в одном из двух путей рассылки — в том,
-- что на Go (изменения задачи). Комментарии, чек-лист и вложения идут
-- через SQL-функцию app.notify_task_watchers, и там проверки не было:
-- редактор проекта продолжал получать уведомления, сколько бы раз он
-- ни выключал настройку.
--
-- Теперь условие стоит внутри самой функции — то есть в общем для всех
-- путей месте.
CREATE OR REPLACE FUNCTION app.notify_task_watchers(
    p_task uuid, p_actor uuid, p_body text)
RETURNS SETOF uuid
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    SELECT DISTINCT w.user_id, p_body, t.board_id, t.id
      FROM app.tasks t
      CROSS JOIN LATERAL app.task_watchers(t.id) AS w(user_id)
      JOIN app.users u ON u.id = w.user_id
     WHERE t.id = p_task
       -- Инициатор не уведомляется о собственном действии. Проверка
       -- идёт по всей его действующей личности: замещая коллегу,
       -- человек не должен получать уведомление о том, что сделал сам.
       AND w.user_id <> ALL (SELECT app.effective_users(p_actor))
       -- Отключённым и удалённым уведомления не нужны: они всё равно
       -- не войдут, а строки копятся.
       AND u.deleted_at IS NULL AND u.is_active
       -- Настройка «уведомления по задачам, где я не исполнитель».
       -- Своё человек получает всегда: как исполнитель, как автор и как
       -- тот, кому задачу открыли лично. Настройка касается только
       -- чужих задач, видных по роли в проекте.
       AND (
         EXISTS (SELECT 1 FROM app.task_assignees a
                  WHERE a.task_id = t.id AND a.user_id = w.user_id)
         OR EXISTS (SELECT 1 FROM app.task_grants g
                     WHERE g.task_id = t.id AND g.user_id = w.user_id)
         OR t.created_by = w.user_id
         OR app.wants_foreign_task_notifs(w.user_id)
       )
    RETURNING notifications.user_id
$$;

GRANT EXECUTE ON FUNCTION app.notify_task_watchers(uuid, uuid, text) TO app_user;

-- Готово.
