-- =====================================================================
-- 0018_team_groups.sql — группы внутри личной команды.
--
-- Команда из тридцати человек плоским списком неудобна: чтобы поручить
-- задачу отделу снабжения, приходится выискивать пятерых по одному.
-- Группы решают это — «Снабжение», «Сметчики», «Бригада Петрова», — и
-- при назначении исполнителей группу можно раскрыть и выбрать внутри.
--
-- Устройство:
--
--   • группы принадлежат владельцу команды, как и сама команда: у
--     каждого руководителя свой взгляд на то, как делить людей;
--   • человек может состоять в нескольких группах или ни в одной —
--     группа это ярлык, а не подразделение;
--   • в группу можно включить только того, кто уже в команде. Это
--     обеспечивает составной внешний ключ на team_members: убрали
--     человека из команды — он сам исчезает из всех её групп, и
--     «висящих» участников не бывает.
--
-- Проекты группами не пользуются: там по-прежнему плоский список всей
-- команды без повторов. Группы нужны именно при поручении задачи.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0018_team_groups.sql
--
-- Запускать от app_owner, после 0017_recurrence_column.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE TABLE IF NOT EXISTS app.team_groups (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    title      text NOT NULL CHECK (btrim(title) <> ''),
    -- Порядок групп задаёт владелец: самые нужные — наверху списка.
    position   int  NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS team_groups_owner_idx ON app.team_groups (owner_id, position);

CREATE TABLE IF NOT EXISTS app.team_group_members (
    group_id  uuid NOT NULL REFERENCES app.team_groups(id) ON DELETE CASCADE,
    -- owner_id дублируется намеренно: без него составной ключ на
    -- team_members не построить, а именно он гарантирует, что в
    -- группе только участники команды.
    owner_id  uuid NOT NULL,
    member_id uuid NOT NULL,
    PRIMARY KEY (group_id, member_id),
    FOREIGN KEY (owner_id, member_id)
        REFERENCES app.team_members (owner_id, member_id) ON DELETE CASCADE
);

ALTER TABLE app.team_groups        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.team_group_members ENABLE ROW LEVEL SECURITY;

-- Группы видит и правит только их владелец, как и саму команду.
DROP POLICY IF EXISTS team_groups_own ON app.team_groups;
CREATE POLICY team_groups_own ON app.team_groups FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

DROP POLICY IF EXISTS team_group_members_own ON app.team_group_members;
CREATE POLICY team_group_members_own ON app.team_group_members FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_groups        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_group_members TO app_user;

-- Готово.
