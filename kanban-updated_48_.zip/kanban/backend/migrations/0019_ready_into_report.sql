-- =====================================================================
-- 0019_ready_into_report.sql — отметка «готова к сдаче» переходит в
-- отчёт при завершении задачи.
--
-- Было: исполнитель нажимал «Задача готова к сдаче», сверху карточки
-- появлялась плашка с ФИО и временем. Автор завершал задачу — и
-- триггер из 0016 стирал отметку: задача уже принята, ждать нечего.
-- Вместе с отметкой пропадал и единственный след того, кто и когда
-- сдал работу, — в отчёте его не было, в печати и выгрузке тоже.
--
-- Стало: перед тем как стереть отметку, тот же триггер дописывает её
-- в отчёт отдельной строкой:
--
--     Отчёт направлен в адрес.
--     Отметка о готовности к сдаче: Иванов Иван 22.09.2026, 21:29
--
-- Почему в триггере, а не в обработчике: завершить задачу можно двумя
-- путями — кнопкой «Пометить завершённой» и переносом карточки в
-- колонку «Готово» (app.move_task). Триггер срабатывает при любом из
-- них, в том числе при тех, что появятся позже.
--
-- Часовой пояс. Время в плашке клиент показывает по поясу браузера, и
-- в отчёте оно должно быть тем же — иначе в карточке «21:29», а в
-- отчёте «18:29». Сервер кладёт пояс клиента (заголовок X-Timezone) в
-- транзакционную настройку app.tz. Если её нет или имя пояса неверно,
-- берётся пояс сессии: лучше время в поясе сервера, чем сорванное
-- завершение задачи.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0019_ready_into_report.sql
--
-- Запускать от app_owner, после 0018_team_groups.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- SECURITY DEFINER: имя сдавшего читается из app.users, и политика на
-- users не должна решать, попадёт ли строка в отчёт. Функция ничего не
-- возвращает наружу и меняет только строку, которую и так обновляют.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_tz    text;
    v_local timestamp;
    v_name  text;
    v_line  text;
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        IF OLD.ready_at IS NOT NULL THEN
            v_tz := nullif(current_setting('app.tz', true), '');
            BEGIN
                v_local := OLD.ready_at AT TIME ZONE COALESCE(v_tz, current_setting('TimeZone'));
            EXCEPTION WHEN invalid_parameter_value THEN
                v_local := OLD.ready_at AT TIME ZONE current_setting('TimeZone');
            END;

            SELECT u.full_name INTO v_name FROM app.users u WHERE u.id = OLD.ready_by;

            v_line := 'Отметка о готовности к сдаче: '
                   || COALESCE(nullif(btrim(v_name), ''), 'исполнитель')
                   || ' ' || to_char(v_local, 'DD.MM.YYYY, HH24:MI');

            -- Отчёт берётся из NEW: если в том же UPDATE его поменяли,
            -- дописываем к новому тексту, а не к старому. Хвостовые
            -- переводы строк срезаются, чтобы не получалось пустых
            -- строк между отчётом и отметкой.
            --
            -- Повторно одну и ту же строку не дописываем: задачу могли
            -- вернуть в работу и завершить снова без новой сдачи — тогда
            -- отметки нет вовсе (сюда не попадём), но при ручной правке
            -- отчёта строка могла остаться, и дубль был бы лишним.
            IF position(v_line IN COALESCE(NEW.report, '')) = 0 THEN
                NEW.report := CASE
                    WHEN btrim(COALESCE(NEW.report, '')) = '' THEN v_line
                    ELSE rtrim(NEW.report, E' \n\r\t') || E'\n' || v_line
                END;
            END IF;
        END IF;

        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();

-- Готово.
