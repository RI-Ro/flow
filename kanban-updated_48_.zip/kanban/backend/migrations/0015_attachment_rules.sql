-- =====================================================================
-- 0015_attachment_rules.sql — одинаковые правила для всех вложений.
--
-- Выглядело так, будто права зависят от формата файла: у одного файла
-- есть «переименовать» и «удалить», у другого нет. На самом деле
-- зависели они от времени и от того, кто загрузил:
--
--   переименование — только автор и только в первый час после
--                    загрузки (attachments_update);
--   удаление       — автор в первый час ИЛИ тот, кто вправе править
--                    задачу (attachments_delete).
--
-- Отсюда и путаница: свежий файл, загруженный тобой, полностью
-- послушен, а такой же, но вчерашний или чужой — нет.
--
-- Час имел смысл для комментариев — там правка задним числом меняет
-- смысл переписки. У вложения правится только подпись, сам файл
-- остаётся тем же, и запрещать это через час незачем.
--
-- Новое правило одно для обеих операций и для любого формата: автор
-- вложения или тот, кто вправе править задачу. Второе обязательно:
-- иначе файл, выложенный ушедшим сотрудником, остаётся в задаче
-- навсегда.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0015_attachment_rules.sql
--
-- Запускать от app_owner, после 0014_chat_avatar.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

DROP POLICY IF EXISTS attachments_update ON app.attachments;
CREATE POLICY attachments_update ON app.attachments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    )
    WITH CHECK (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

DROP POLICY IF EXISTS attachments_delete ON app.attachments;
CREATE POLICY attachments_delete ON app.attachments FOR DELETE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

-- Готово.
