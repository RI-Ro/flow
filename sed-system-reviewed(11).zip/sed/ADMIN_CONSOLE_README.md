# Консоль администрирования СЭД (admin-console.html)

Отдельное самодостаточное приложение (один HTML-файл, без сборки) для
администрирования оргструктуры и пользователей с drag-and-drop.

## Возможности
- Дерево подразделений; **перетаскивание**:
  - пользователя на подразделение — переместить в него;
  - подразделения на другое — сделать вложенным (со всем поддеревом);
  - подразделения в верхнюю зону — сделать корневым.
- Редактирование: название и префиксы подразделения (outgoing_prefix,
  numbering_prefix), ФИО, должность, логин, подразделение и активность
  пользователя; смена пароля; роли (в т.ч. глобальный admin).
- Создание/удаление подразделений и пользователей.
- Корректное сопровождение таблицы транзитивного замыкания
  department_closure при создании и переносе (алгоритм closure-table move,
  с защитой от циклов).

## Запуск
1. Поднимите бэкенд СЭД (он отдаёт admin-API под `/api/admin/*`, доступно
   только пользователям с ролью admin).
2. Откройте `admin-console.html` любым способом:
   - просто открыть файл в браузере, **или**
   - отдать любым статик-сервером: `python3 -m http.server 5500`.
3. В форме входа укажите адрес API (напр. `http://localhost:8080`) и войдите
   под администратором.

## CORS
Если консоль открыта не с того же origin, что бэкенд, добавьте её адрес в
`ALLOWED_ORIGINS` бэкенда (env или `http.allowed_origins` в конфиге), напр.:
`ALLOWED_ORIGINS=http://localhost:5173,http://localhost:5500`.
Файл, открытый как `file://`, имеет origin `null` — в этом случае удобнее
отдавать его статик-сервером и добавить его origin в ALLOWED_ORIGINS.

## Admin-API (для справки)
- GET    /api/admin/departments
- POST   /api/admin/departments               {name, outgoing_prefix, numbering_prefix, parent_id}
- PATCH  /api/admin/departments/:id            {name, outgoing_prefix, numbering_prefix, is_active}
- PATCH  /api/admin/departments/:id/parent     {parent_id}   (перенос/drag-drop)
- DELETE /api/admin/departments/:id            (нельзя, если есть дети или пользователи)
- GET    /api/admin/users
- POST   /api/admin/users                      {login, password, full_name, position, department_id}
- PATCH  /api/admin/users/:id                  {login, full_name, position, department_id, is_active}
- PATCH  /api/admin/users/:id/department       {department_id}  (перенос/drag-drop)
- PATCH  /api/admin/users/:id/password         {password}
- PATCH  /api/admin/users/:id/roles            {department_id, roles[]}  (department_id=0 → глобально)

Все /api/admin/* требуют роль admin (проверка в хендлерах).
