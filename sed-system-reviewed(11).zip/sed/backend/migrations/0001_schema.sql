-- +goose Up
-- ============================================================================
-- СХЕМА СЭД — единый, консолидированный файл (проект разворачивается с нуля).
-- Здесь СРАЗУ финальное состояние всех таблиц/типов/индексов/функций. Никаких
-- отдельных «чинящих» миграций: каждый объект определён один раз и правильно.
-- RLS-политики вынесены в 0002_rls.sql, демо-данные — в 0003_seed_demo.sql.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------- оргструктура
CREATE TABLE departments (
    id BIGSERIAL PRIMARY KEY,
    parent_id BIGINT REFERENCES departments(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    outgoing_prefix TEXT NOT NULL UNIQUE,     -- краткий код (напр. "ГУ")
    numbering_prefix TEXT,                     -- иерархический префикс (напр. "9/8/7")
    is_active BOOL NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE department_closure (
    ancestor_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    descendant_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    depth INT NOT NULL,
    PRIMARY KEY (ancestor_id, descendant_id)
);
CREATE INDEX idx_dept_closure_desc ON department_closure(descendant_id);
CREATE INDEX idx_dept_closure_anc ON department_closure(ancestor_id);

CREATE TABLE duty_hierarchy (
    id BIGSERIAL PRIMARY KEY,
    parent_id BIGINT REFERENCES duty_hierarchy(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    is_active BOOL NOT NULL DEFAULT TRUE
);
CREATE TABLE duty_closure (
    ancestor_id BIGINT NOT NULL REFERENCES duty_hierarchy(id) ON DELETE CASCADE,
    descendant_id BIGINT NOT NULL REFERENCES duty_hierarchy(id) ON DELETE CASCADE,
    depth INT NOT NULL,
    PRIMARY KEY (ancestor_id, descendant_id)
);
CREATE INDEX idx_duty_closure_desc ON duty_closure(descendant_id);

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    login TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    position TEXT,                              -- должность (для штампа подписи)
    primary_department_id BIGINT REFERENCES departments(id),
    numbering_department_id BIGINT REFERENCES departments(id),
    duty_node_id BIGINT REFERENCES duty_hierarchy(id),
    is_active BOOL NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_dept ON users(primary_department_id);

CREATE TYPE role_code AS ENUM (
    'author','approver_hierarchy','approver_cross_dept','signer','executor',
    'clerk','duty_officer','chief','controller','admin'
);

CREATE TABLE user_roles (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT REFERENCES departments(id) ON DELETE CASCADE, -- NULL = глобальная роль (admin)
    role role_code NOT NULL,
    PRIMARY KEY (user_id, department_id, role)
);
CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_user_roles_dept_role ON user_roles(department_id, role);

-- Доп. подразделения (вне основной иерархии пользователя):
--   видимость исходящих, ознакомление, поручения.
CREATE TABLE user_visible_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX idx_user_visible_dept ON user_visible_departments(department_id);

CREATE TABLE user_acquaint_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);

CREATE TABLE user_assign_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);

-- ------------------------------------------------------------------- документы
CREATE TYPE doc_urgency AS ENUM ('normal','urgent','out_of_turn');
CREATE TYPE doc_status  AS ENUM (
    'draft','on_approval_hierarchy','on_approval_cross_dept',
    'on_signing','signed','sent','in_progress','executed','archived','rejected'
);

CREATE TABLE documents (
    id BIGSERIAL PRIMARY KEY,
    author_id BIGINT NOT NULL REFERENCES users(id),
    author_department_id BIGINT NOT NULL REFERENCES departments(id),
    title TEXT NOT NULL,
    body_summary TEXT,
    urgency doc_urgency NOT NULL DEFAULT 'normal',
    status doc_status NOT NULL DEFAULT 'draft',
    outgoing_number TEXT UNIQUE,
    due_date DATE,
    due_datetime TIMESTAMPTZ,
    executed_at TIMESTAMPTZ,
    archived_at TIMESTAMPTZ,
    controller_id BIGINT REFERENCES users(id),
    on_control BOOL NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_documents_status_created ON documents(status, created_at DESC);
CREATE INDEX idx_documents_author_created ON documents(author_id, created_at DESC);
CREATE INDEX idx_documents_dept_created ON documents(author_department_id, created_at DESC);
CREATE INDEX idx_documents_status_only ON documents(status);
CREATE INDEX idx_documents_urgency ON documents(urgency);
CREATE INDEX idx_documents_due ON documents(due_date) WHERE due_date IS NOT NULL;
CREATE INDEX idx_documents_executed_year ON documents(executed_at) WHERE status = 'executed' AND executed_at IS NOT NULL;
CREATE INDEX idx_documents_on_control ON documents(on_control) WHERE on_control = true;
CREATE INDEX idx_documents_controller ON documents(controller_id) WHERE controller_id IS NOT NULL;
CREATE INDEX idx_documents_search ON documents USING GIN (to_tsvector('russian', title || ' ' || coalesce(body_summary, '')));
CREATE INDEX idx_documents_title_trgm  ON documents USING gin (title gin_trgm_ops);
CREATE INDEX idx_documents_body_trgm   ON documents USING gin (coalesce(body_summary,'') gin_trgm_ops);
CREATE INDEX idx_documents_outnum_trgm ON documents USING gin (coalesce(outgoing_number,'') gin_trgm_ops);

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
-- +goose StatementEnd

CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON documents
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE document_history (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    actor_id BIGINT REFERENCES users(id),
    event_type TEXT NOT NULL,
    from_status doc_status,
    to_status doc_status,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_doc_history_doc ON document_history(document_id, created_at);

CREATE TABLE document_files (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    content BYTEA NOT NULL,
    sha256 TEXT NOT NULL,
    size_bytes INT NOT NULL,
    mime_type TEXT NOT NULL DEFAULT 'application/pdf' CHECK (mime_type = 'application/pdf'),
    uploaded_by BIGINT REFERENCES users(id),
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(document_id)
);

CREATE TABLE document_signatures (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    signer_id BIGINT NOT NULL REFERENCES users(id),
    signed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    signature_type TEXT NOT NULL CHECK (signature_type IN ('ПЭП','НЭП','УНЭП','УКЭП')),
    signature_hash TEXT NOT NULL,
    storage_resource TEXT NOT NULL,
    signer_fio TEXT,        -- снимок ФИО на момент подписи
    signer_position TEXT    -- снимок должности на момент подписи
);
CREATE INDEX idx_doc_signatures_doc ON document_signatures(document_id);

CREATE TABLE numbering_sequences (
    department_id BIGINT NOT NULL REFERENCES departments(id),
    year INT NOT NULL,
    seq_type TEXT NOT NULL CHECK (seq_type IN ('outgoing','incoming')),
    last_value INT NOT NULL DEFAULT 0,
    PRIMARY KEY (department_id, year, seq_type)
);

CREATE TABLE document_incoming_instances (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    receiving_department_id BIGINT NOT NULL REFERENCES departments(id),
    received_by BIGINT REFERENCES users(id),
    incoming_number TEXT NOT NULL,
    instance_label TEXT,
    first_viewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(document_id, receiving_department_id)
);
CREATE INDEX idx_incoming_dept ON document_incoming_instances(receiving_department_id, created_at DESC);
CREATE INDEX idx_incoming_number_trgm ON document_incoming_instances USING gin (incoming_number gin_trgm_ops);

CREATE TABLE document_recipients (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    recipient_user_id BIGINT NOT NULL REFERENCES users(id),
    recipient_department_id BIGINT NOT NULL REFERENCES departments(id),
    is_planned BOOL NOT NULL DEFAULT false,     -- плановый (активируется при подписи)
    completed_at TIMESTAMPTZ,
    completion_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_doc_recipient UNIQUE (document_id, recipient_user_id)
);
CREATE INDEX idx_doc_recipients_doc ON document_recipients(document_id);
CREATE INDEX idx_doc_recipients_user ON document_recipients(recipient_user_id);
CREATE INDEX idx_doc_recipients_incomplete ON document_recipients(document_id) WHERE completed_at IS NULL;

-- Получатель рассылки обязан иметь роль duty_officer или clerk в своём
-- подразделении (defence-in-depth на уровне БД).
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION check_recipient_role() RETURNS TRIGGER AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = NEW.recipient_user_id
      AND department_id = NEW.recipient_department_id
      AND role IN ('duty_officer', 'clerk')
  ) THEN
    RAISE EXCEPTION 'recipient % must have role duty_officer or clerk in department %',
      NEW.recipient_user_id, NEW.recipient_department_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
-- +goose StatementEnd

CREATE TRIGGER trg_check_recipient_role
BEFORE INSERT OR UPDATE ON document_recipients
FOR EACH ROW EXECUTE FUNCTION check_recipient_role();

-- --------------------------------------------------------------- согласование
CREATE TYPE stage_type AS ENUM ('hierarchy','cross_dept','signing');
CREATE TYPE stage_status AS ENUM ('waiting_deps','pending','approved','rejected');

CREATE TABLE approval_stages (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    stage_type stage_type NOT NULL,
    approver_id BIGINT NOT NULL REFERENCES users(id),
    status stage_status NOT NULL DEFAULT 'waiting_deps',
    display_order INT NOT NULL DEFAULT 0,
    decided_at TIMESTAMPTZ,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_approval_stage_doc ON approval_stages(document_id, display_order);
CREATE INDEX idx_approval_stage_approver ON approval_stages(approver_id, status);

CREATE TABLE approval_stage_dependencies (
    stage_id BIGINT NOT NULL REFERENCES approval_stages(id) ON DELETE CASCADE,
    depends_on_stage_id BIGINT NOT NULL REFERENCES approval_stages(id) ON DELETE CASCADE,
    PRIMARY KEY (stage_id, depends_on_stage_id),
    CHECK (stage_id <> depends_on_stage_id)
);
CREATE INDEX idx_stage_deps_stage ON approval_stage_dependencies(stage_id);
CREATE INDEX idx_stage_deps_depends_on ON approval_stage_dependencies(depends_on_stage_id);

CREATE TABLE executors (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    executor_id BIGINT NOT NULL REFERENCES users(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    report TEXT
);
CREATE INDEX idx_executors_doc ON executors(document_id);
CREATE INDEX idx_executors_user ON executors(executor_id, completed_at);

-- --------------------------------------------------------- доступ / чат / уведомл.
CREATE TABLE document_access (
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    access_reason TEXT NOT NULL,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (document_id, user_id, access_reason)
);
CREATE INDEX idx_doc_access_user ON document_access(user_id, document_id);
CREATE INDEX idx_doc_access_doc ON document_access(document_id);

CREATE TABLE chat_messages (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    author_id BIGINT NOT NULL REFERENCES users(id),
    text TEXT,
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_doc_created ON chat_messages(document_id, created_at);

CREATE TABLE chat_attachments (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    content BYTEA NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_attach_message ON chat_attachments(message_id);

CREATE TABLE notifications (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}',
    is_read BOOL NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, is_read, created_at DESC);

CREATE TABLE document_views (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    viewer_id BIGINT NOT NULL REFERENCES users(id),
    viewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_doc_views_doc ON document_views(document_id, viewed_at DESC);

-- ------------------------------------------------- связи / поручения / ознакомл.
CREATE TABLE document_links (
    id BIGSERIAL PRIMARY KEY,
    source_document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    target_document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,   -- NULL, если text_note
    text_note TEXT,
    link_type TEXT NOT NULL DEFAULT 'related'
        CHECK (link_type IN ('related','reply_to','in_pursuance_of','annuls','appendix')),
    created_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_document_id, target_document_id, link_type),
    CHECK (source_document_id <> target_document_id),
    -- ровно одно из двух: ссылка на документ ИЛИ текстовая пометка
    CONSTRAINT chk_link_target CHECK ((target_document_id IS NOT NULL) <> (text_note IS NOT NULL))
);
CREATE INDEX idx_document_links_source ON document_links(source_document_id);
CREATE INDEX idx_document_links_target ON document_links(target_document_id);

CREATE TABLE assignments (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    author_id BIGINT NOT NULL REFERENCES users(id),
    assignee_id BIGINT NOT NULL REFERENCES users(id),
    controller_id BIGINT REFERENCES users(id),
    text TEXT NOT NULL,
    due_date DATE,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open','in_progress','done','cancelled')),
    result_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ
);
CREATE INDEX idx_assignments_document ON assignments(document_id);
CREATE INDEX idx_assignments_assignee ON assignments(assignee_id) WHERE status IN ('open','in_progress');

CREATE TABLE document_acquaintances (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id),
    acquainted_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, user_id)
);
CREATE INDEX idx_acq_user ON document_acquaintances(user_id);

-- +goose Down
DROP TABLE IF EXISTS document_acquaintances;
DROP TABLE IF EXISTS assignments;
DROP TABLE IF EXISTS document_links;
DROP TABLE IF EXISTS document_views;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS chat_attachments;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS document_access;
DROP TABLE IF EXISTS executors;
DROP TABLE IF EXISTS approval_stage_dependencies;
DROP TABLE IF EXISTS approval_stages;
DROP TYPE IF EXISTS stage_status;
DROP TYPE IF EXISTS stage_type;
DROP TRIGGER IF EXISTS trg_check_recipient_role ON document_recipients;
DROP FUNCTION IF EXISTS check_recipient_role();
DROP TABLE IF EXISTS document_recipients;
DROP TABLE IF EXISTS document_incoming_instances;
DROP TABLE IF EXISTS numbering_sequences;
DROP TABLE IF EXISTS document_signatures;
DROP TABLE IF EXISTS document_files;
DROP TABLE IF EXISTS document_history;
DROP TRIGGER IF EXISTS trg_documents_updated_at ON documents;
DROP FUNCTION IF EXISTS set_updated_at();
DROP TABLE IF EXISTS documents;
DROP TYPE IF EXISTS doc_status;
DROP TYPE IF EXISTS doc_urgency;
DROP TABLE IF EXISTS user_assign_departments;
DROP TABLE IF EXISTS user_acquaint_departments;
DROP TABLE IF EXISTS user_visible_departments;
DROP TABLE IF EXISTS user_roles;
DROP TYPE IF EXISTS role_code;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS duty_closure;
DROP TABLE IF EXISTS duty_hierarchy;
DROP TABLE IF EXISTS department_closure;
DROP TABLE IF EXISTS departments;
