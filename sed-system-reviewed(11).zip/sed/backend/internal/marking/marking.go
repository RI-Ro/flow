// Package marking формирует и (опционально) накладывает текстовые штампы на PDF
// по конфигурации. Оригинал в БД не меняется — штампы наносятся на копию при
// выдаче файла.
//
// АРХИТЕКТУРА РЕНДЕРА (важно):
// Вся ЛОГИКА маркировки (какие из 5 штампов применимы, их текст с подстановкой
// плейсхолдеров, позиции, цвета, hash подписи, место хранения оригинала)
// выполняется здесь, на бэкенде, и не зависит от внешних библиотек — поэтому
// пакет всегда КОМПИЛИРУЕТСЯ без внешних зависимостей.
//
// Фактическое «вжигание» текста в PDF вынесено за pluggable-хук RenderHook.
// Причина: штампы на кириллице требуют встраивания Unicode-шрифта в PDF, а
// единственная подходящая pure-Go библиотека (pdfcpu) меняет пути пакетов и
// сигнатуры watermark-API между версиями (pkg/types ↔ pkg/pdfcpu ↔ pkg/model),
// что ломает сборку при несовпадении версии. Чтобы проект гарантированно
// собирался в любой среде, по умолчанию RenderHook == nil и Apply возвращает
// исходный PDF без изменений (маркировку в этом режиме показывает overlay
// вьювера на фронте). Чтобы включить вжигание в сам файл — присвойте RenderHook
// реализацию под ВАШУ версию pdfcpu (готовый пример: render_pdfcpu.go.example).
package marking

import (
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"

	"sed-system/backend/internal/config"
)

// Placeholders — значения для подстановки в штампы по имени (без {}).
type Placeholders map[string]string

const (
	KeySignerFIO      = "signer_fio"
	KeySignerPosition = "signer_position"
	KeySignTime       = "sign_time"
	KeySignDate       = "sign_date"
	KeyOutgoingNumber = "outgoing_number"
	KeyStorage        = "storage_resource"
	KeyDocumentID     = "document_id"
	KeySignHash       = "sign_hash"
	KeyIncomingNumber = "incoming_number"
	KeyInstanceLabel  = "instance_label"
	KeyReceivedBy     = "received_by"
	KeyReceivedTime   = "received_time"
	KeyReceivingDept  = "receiving_department"
	KeyArchivedAt     = "archived_at"
	KeyArchiveYear    = "archive_year"
)

var placeholderRe = regexp.MustCompile(`\{([a-z_]+)\}`)

// substitute подставляет значения из ph в строку с плейсхолдерами {name}.
// Неизвестные оставляются как есть — чтобы ошибки в конфиге были заметны.
func substitute(s string, ph Placeholders) string {
	return placeholderRe.ReplaceAllStringFunc(s, func(m string) string {
		key := m[1 : len(m)-1]
		if v, ok := ph[key]; ok {
			return v
		}
		return m
	})
}

// positionToAnchor переводит имя позиции из конфига в якорь pdfcpu.
func positionToAnchor(pos string) string {
	switch pos {
	case "top_left":
		return "tl"
	case "top_right":
		return "tr"
	case "bottom_left":
		return "bl"
	case "bottom_right":
		return "br"
	case "center":
		return "c"
	default:
		return "br"
	}
}

// hexToPDFColor переводит "#rrggbb" в "r.g.b" (0..1) для описания штампа.
func hexToPDFColor(hex string) string {
	hex = strings.TrimPrefix(hex, "#")
	if len(hex) != 6 {
		return "0 0 0"
	}
	var r, g, b int
	if _, err := fmt.Sscanf(hex, "%02x%02x%02x", &r, &g, &b); err != nil {
		return "0 0 0"
	}
	return fmt.Sprintf("%.3f %.3f %.3f", float64(r)/255, float64(g)/255, float64(b)/255)
}

// Spec — подготовленное описание одного штампа (текст + параметры отрисовки).
// Экспортируется, чтобы внешняя реализация RenderHook (например, на pdfcpu)
// могла его использовать. Position — якорь в стиле pdfcpu (tl/tr/bl/br/c),
// Color — строка "r g b" в диапазоне 0..1.
type Spec struct {
	Text        string
	Position    string  // якорь pdfcpu: tl/tr/bl/br/c
	OffsetX     float64
	OffsetY     float64
	FontSize    int
	Color       string // "r g b" 0..1 — для pdfcpu
	ColorHex    string // "#rrggbb" — для overlay на фронте
	Border      bool
	BorderColorHex string // "#rrggbb" — цвет рамки (пусто = ColorHex)
	FillColorHex   string // "#rrggbb" — цвет заливки/фона (пусто = без заливки)
	ImageFile   string // путь к изображению (факсимиле/печать); пусто = без картинки
}

// RenderHook — точка подключения реального рендера штампов в PDF. Если nil,
// renderStamps возвращает исходный PDF без изменений (маркировку показывает
// overlay на фронте). Присвойте свою реализацию под используемую версию
// pdfcpu (см. render_pdfcpu.go.example) в main.go при инициализации.
var RenderHook func(original []byte, specs []Spec) ([]byte, error)

// buildSpec формирует описание штампа из конфига и плейсхолдеров.
// Возвращает (spec, true), если штамп включён и непуст.
func buildSpec(sc config.StampConfig, ph Placeholders) (Spec, bool) {
	if !sc.Enabled || len(sc.Lines) == 0 {
		return Spec{}, false
	}
	lines := make([]string, 0, len(sc.Lines))
	for _, l := range sc.Lines {
		lines = append(lines, substitute(l, ph))
	}
	fontSize := int(sc.FontSize)
	if fontSize <= 0 {
		fontSize = 9
	}
	colorHex := sc.Color
	if colorHex == "" {
		colorHex = "#000000"
	}
	borderColorHex := sc.BorderColor
	if borderColorHex == "" {
		borderColorHex = colorHex // по умолчанию рамка цвета текста
	}
	return Spec{
		Text:           strings.Join(lines, "\n"),
		Position:       positionToAnchor(sc.Position),
		OffsetX:        sc.OffsetX,
		OffsetY:        sc.OffsetY,
		FontSize:       fontSize,
		Color:          hexToPDFColor(sc.Color),
		ColorHex:       colorHex,
		Border:         sc.Border,
		BorderColorHex: borderColorHex,
		FillColorHex:   sc.FillColor,
		ImageFile:      sc.ImageFile,
	}, true
}

// ComputeSpecs формирует список применимых штампов из конфига и плейсхолдеров
// (без рендера). Единая точка правил «какие из 5 штампов применимы» —
// используется и для вжигания в PDF (Apply), и для overlay-маркировки на
// фронте (эндпоинт GET /documents/:id/marking).
func ComputeSpecs(cfg config.MarkingConfig, ph Placeholders) []Spec {
	var specs []Spec
	// 1) Исходящий (регистрационный) номер — только после подписания.
	if ph[KeyOutgoingNumber] != "" {
		if s, ok := buildSpec(cfg.RegistrationNumber, ph); ok {
			specs = append(specs, s)
		}
	}
	// 5) Сведения о подписи — только если документ подписан.
	if ph[KeySignerFIO] != "" || ph[KeySignHash] != "" {
		if s, ok := buildSpec(cfg.SignatureStamp, ph); ok {
			specs = append(specs, s)
		}
	}
	// 2) Входящий номер (отметка о получении) — только при наличии.
	if ph[KeyIncomingNumber] != "" {
		if s, ok := buildSpec(cfg.IncomingStamp, ph); ok {
			specs = append(specs, s)
		}
	}
	// 3) Экземпляр — только если известен ярлык/номер экземпляра.
	if ph[KeyInstanceLabel] != "" || ph[KeyIncomingNumber] != "" {
		if s, ok := buildSpec(cfg.InstanceStamp, ph); ok {
			specs = append(specs, s)
		}
	}
	// 4) Факт переноса в архив — только у архивных документов.
	if ph[KeyArchivedAt] != "" {
		if s, ok := buildSpec(cfg.ArchiveStamp, ph); ok {
			specs = append(specs, s)
		}
	}
	return specs
}

// IsBaking сообщает, вжигает ли бэкенд штампы в сам PDF (RenderHook подключён).
// Фронт использует это, чтобы НЕ дублировать overlay, если бэкенд уже нанёс
// штампы, и наоборот — рисовать overlay, если бэкенд маркировку не выполняет.
func IsBaking() bool { return RenderHook != nil }

// imageCache кэширует прочитанные изображения-факсимиле как data-URL, чтобы не
// читать файл с диска на каждый запрос маркировки.
var (
	imageCacheMu sync.RWMutex
	imageCache   = map[string]string{}
)

// ImageDataURL читает файл изображения по пути и возвращает data-URL
// ("data:image/png;base64,....") для встраивания в overlay на фронте. Пустой
// путь или ошибка чтения → "" (штамп рисуется без картинки, только текст).
func ImageDataURL(path string) string {
	if path == "" {
		return ""
	}
	imageCacheMu.RLock()
	if v, ok := imageCache[path]; ok {
		imageCacheMu.RUnlock()
		return v
	}
	imageCacheMu.RUnlock()

	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	mime := "image/png"
	switch strings.ToLower(filepath.Ext(path)) {
	case ".jpg", ".jpeg":
		mime = "image/jpeg"
	case ".gif":
		mime = "image/gif"
	case ".svg":
		mime = "image/svg+xml"
	case ".webp":
		mime = "image/webp"
	}
	url := "data:" + mime + ";base64," + base64.StdEncoding.EncodeToString(data)
	imageCacheMu.Lock()
	imageCache[path] = url
	imageCacheMu.Unlock()
	return url
}

// Apply формирует список штампов и накладывает их на PDF через renderStamps.
// Оригинал не изменяется.
func Apply(original []byte, cfg config.MarkingConfig, ph Placeholders) ([]byte, error) {
	return renderStamps(original, ComputeSpecs(cfg, ph))
}

// renderStamps накладывает штампы на копию PDF через RenderHook. Если хук не
// подключён (по умолчанию), возвращает исходный PDF без изменений — это не
// ошибка, а штатный режим: маркировку показывает overlay вьювера на фронте.
// Любая ошибка хука не должна ломать выдачу файла: возвращаем оригинал (сбой
// изолирован; вызывающий код логирует err).
func renderStamps(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 || RenderHook == nil {
		return original, nil
	}
	out, err := RenderHook(original, specs)
	if err != nil {
		return original, fmt.Errorf("render stamps: %w", err)
	}
	return out, nil
}
