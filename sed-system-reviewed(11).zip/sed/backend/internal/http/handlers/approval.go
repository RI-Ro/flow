package handlers

import (
	"errors"
	"log"
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

type ApprovalHandler struct {
	pool     *pgxpool.Pool
	approval *service.ApprovalService
	status   *service.StatusService
	signing  *service.SigningService
	hub      *ws.Hub
}

func NewApprovalHandler(pool *pgxpool.Pool, approval *service.ApprovalService, status *service.StatusService, signing *service.SigningService, hub *ws.Hub) *ApprovalHandler {
	return &ApprovalHandler{pool: pool, approval: approval, status: status, signing: signing, hub: hub}
}

type decideRequest struct {
	Approve bool   `json:"approve"`
	Comment string `json:"comment"`
}

type decideResponse struct {
	StageType      string  `json:"stage_type"`
	NewStatus      string  `json:"new_status,omitempty"`
	OutgoingNumber *string `json:"outgoing_number,omitempty"`
}

// Decide POST /api/documents/:id/stages/:stageId/decide
//
// Если решаемый этап имеет stage_type='signing' и решение — подтверждение,
// это одновременно и есть акт подписания: SigningService присваивает
// исходящий номер и создаёт запись в document_signatures в ЭТОЙ ЖЕ
// транзакции (атомарно с переводом статуса этапа). Push согласующим
// следующего активированного этапа отправляется ПОСЛЕ коммита.
func (h *ApprovalHandler) Decide(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid document id")
	}
	stageID, err := strconv.ParseInt(c.Params("stageId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid stage id")
	}
	var req decideRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid body")
	}

	var resp decideResponse
	var notify []int64
	var interested []int64 // все заинтересованные — для персистентных уведомлений
	var eventKind string
	var autoSentTo []int64 // плановые адресаты, авто-направленные в момент подписи

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		stageType, activated, err := h.approval.Decide(c.Context(), tx, docID, stageID, userID, req.Approve, req.Comment)
		if err != nil {
			return err
		}
		resp.StageType = stageType
		notify = activated

		if !req.Approve {
			newStatus, err := h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			resp.NewStatus = newStatus
			eventKind = "stage_rejected"
		} else if stageType == "signing" {
			outgoingNumber, sentTo, err := h.signing.Sign(c.Context(), tx, docID, userID, "ПЭП")
			if err != nil {
				return err
			}
			resp.OutgoingNumber = &outgoingNumber
			if len(sentTo) > 0 {
				resp.NewStatus = "sent" // плановая рассылка -> авто-направлен
				autoSentTo = sentTo
			} else {
				resp.NewStatus = "signed"
			}
			eventKind = "document_signed"
		} else {
			newStatus, err := h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			resp.NewStatus = newStatus
			eventKind = "stage_approved"
		}

		// Единое уведомление всех заинтересованных о произошедшем изменении.
		payload := fmt.Sprintf(`{"actor_id":%d,"new_status":%q}`, userID, resp.NewStatus)
		ids, err := service.NotifyDocumentEvent(c.Context(), tx, docID, eventKind, userID, payload)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrForbiddenApprover):
			return fiber.NewError(fiber.StatusForbidden, "вы не являетесь согласующим на этом этапе")
		case errors.Is(txErr, service.ErrStageNotPending):
			return fiber.NewError(fiber.StatusConflict, "этап уже обработан или ещё не активирован")
		default:
			log.Printf("decide stage failed: doc=%d stage=%d user=%d: %v", docID, stageID, userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось обработать этап: "+txErr.Error())
		}
	}

	h.hub.NotifyUsers(notify, docID, "stage_pending")
	if len(interested) > 0 {
		h.hub.NotifyUsers(interested, docID, eventKind)
	}
	if len(autoSentTo) > 0 {
		h.hub.NotifyUsers(autoSentTo, docID, "document_sent")
	}

	return c.JSON(resp)
}
