package handlers

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// RegistryHandler — журналы/реестры документов: официальные табличные перечни
// со всеми реквизитами (исходящий/входящие номера с датами, рассылка с ФИО,
// должностью и подразделением, согласующие с датами, краткое содержание),
// пригодные для печати и выгрузки в Excel.
type RegistryHandler struct {
	pool *pgxpool.Pool
}

func NewRegistryHandler(pool *pgxpool.Pool) *RegistryHandler {
	return &RegistryHandler{pool: pool}
}

// Вложенные реквизиты (приходят из json_agg подзапросов).
type incomingInst struct {
	Number       string `json:"number"`
	Department   string `json:"department"`
	RegisteredAt string `json:"registered_at"`
}
type recipientRow struct {
	FIO        string `json:"fio"`
	Position   string `json:"position"`
	Department string `json:"department"`
}
type approverRow struct {
	FIO       string `json:"fio"`
	Position  string `json:"position"`
	DecidedAt string `json:"decided_at"`
	Status    string `json:"status"`
}

// registryRow — строка реестра со всеми реквизитами.
type registryRow struct {
	ID              int64          `json:"id"`
	OutgoingNumber  *string        `json:"outgoing_number,omitempty"`
	SignedAt        *string        `json:"signed_at,omitempty"` // дата-время подписи (к исх. номеру)
	IncomingNumbers []incomingInst `json:"incoming_numbers"`    // все вх. номера с подразделением и датой регистрации
	Title           string         `json:"title"`
	BodySummary     string         `json:"body_summary"`
	Status          string         `json:"status"`
	Urgency         string         `json:"urgency"`
	AuthorName      string         `json:"author_name"`  // ФИО (должность)
	SignerName      *string        `json:"signer_name,omitempty"`
	Recipients      []recipientRow `json:"recipients"`   // рассылка
	Approvers       []approverRow  `json:"approvers"`    // согласующие с датами
	CreatedAt       string         `json:"created_at"`   // дата-время создания
	DueDate         *string        `json:"due_date,omitempty"`
	DueDatetime     *string        `json:"due_datetime,omitempty"` // срок с временем
}

// fioPos форматирует "ФИО (должность)".
const fioPosSQL = `%s.full_name || CASE WHEN coalesce(%s.position,'')<>'' THEN ' (' || %s.position || ')' ELSE '' END`

// rows строит и выполняет запрос журнала по типу kind. year (или "") — фильтр
// по году (по дате создания; для архива — по дате помещения в архив).
func (h *RegistryHandler) rows(c *fiber.Ctx, kind string, userID int64) ([]registryRow, error) {
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	year := c.Query("year")

	var out []registryRow
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Подразделение пользователя (для фильтра входящих «для подразделения»).
		var deptID int64
		if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
			return e
		}

		var where string
		var args []any
		switch kind {
		case "outgoing":
			// Только исходящие = документы, получившие исходящий номер (подписаны).
			where = "d.outgoing_number IS NOT NULL"
		case "incoming":
			// Только входящие ДЛЯ ПОДРАЗДЕЛЕНИЯ пользователя (документ направлен
			// в его подразделение). Учитываем активных получателей.
			where = `EXISTS (SELECT 1 FROM document_recipients r
			                 WHERE r.document_id = d.id AND r.is_planned = false
			                   AND r.recipient_department_id = $1)`
			args = append(args, deptID)
		case "control":
			// На контроле — ВСЕ документы на контроле.
			where = "d.on_control = true"
		default:
			where = "TRUE"
		}

		// Фильтр по году (по дате создания).
		if year != "" {
			args = append(args, year)
			where = fmt.Sprintf("(%s) AND EXTRACT(YEAR FROM d.created_at)::text = $%d", where, len(args))
		}

		q := fmt.Sprintf(`
			SELECT d.id, d.outgoing_number,
			       to_char(sig.signed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS signed_at,
			       d.title, coalesce(d.body_summary,''),
			       d.status::text, d.urgency::text,
			       `+fmt.Sprintf(fioPosSQL, "au", "au", "au")+` AS author_name,
			       (SELECT `+fmt.Sprintf(fioPosSQL, "su", "su", "su")+`
			        FROM document_signatures ds JOIN users su ON su.id = ds.signer_id
			        WHERE ds.document_id = d.id ORDER BY ds.signed_at DESC LIMIT 1) AS signer_name,
			       to_char(d.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at,
			       to_char(d.due_date, 'YYYY-MM-DD') AS due_date,
			       to_char(d.due_datetime AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS due_datetime,
			       coalesce((SELECT json_agg(json_build_object(
			             'number', i.incoming_number,
			             'department', coalesce(dep.name,''),
			             'registered_at', to_char(i.first_viewed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
			           ORDER BY i.id)
			         FROM document_incoming_instances i
			         LEFT JOIN departments dep ON dep.id = i.receiving_department_id
			         WHERE i.document_id = d.id), '[]') AS incoming_numbers,
			       coalesce((SELECT json_agg(json_build_object(
			             'fio', ru.full_name, 'position', coalesce(ru.position,''),
			             'department', coalesce(rdep.name,'')) ORDER BY ru.full_name)
			         FROM document_recipients r
			         JOIN users ru ON ru.id = r.recipient_user_id
			         LEFT JOIN departments rdep ON rdep.id = r.recipient_department_id
			         WHERE r.document_id = d.id), '[]') AS recipients,
			       coalesce((SELECT json_agg(json_build_object(
			             'fio', apu.full_name, 'position', coalesce(apu.position,''),
			             'decided_at', to_char(aps.decided_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			             'status', aps.status::text) ORDER BY aps.display_order)
			         FROM approval_stages aps
			         JOIN users apu ON apu.id = aps.approver_id
			         WHERE aps.document_id = d.id AND aps.stage_type <> 'signing'), '[]') AS approvers
			FROM documents d
			JOIN users au ON au.id = d.author_id
			LEFT JOIN LATERAL (
			    SELECT signed_at FROM document_signatures
			    WHERE document_id = d.id ORDER BY signed_at DESC LIMIT 1) sig ON true
			WHERE %s
			ORDER BY d.created_at ASC
			LIMIT 2000`, where)

		rows, err := tx.Query(c.Context(), q, args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r registryRow
			var incJSON, recJSON, apprJSON []byte
			if err := rows.Scan(&r.ID, &r.OutgoingNumber, &r.SignedAt, &r.Title, &r.BodySummary,
				&r.Status, &r.Urgency, &r.AuthorName, &r.SignerName, &r.CreatedAt, &r.DueDate, &r.DueDatetime,
				&incJSON, &recJSON, &apprJSON); err != nil {
				return err
			}
			_ = json.Unmarshal(incJSON, &r.IncomingNumbers)
			_ = json.Unmarshal(recJSON, &r.Recipients)
			_ = json.Unmarshal(apprJSON, &r.Approvers)
			out = append(out, r)
		}
		return rows.Err()
	})
	return out, err
}

// List GET /api/registry/:kind — журнал в JSON (для таблицы на фронте).
func (h *RegistryHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	kind := c.Params("kind")
	rows, err := h.rows(c, kind, userID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to build registry")
	}
	return c.JSON(fiber.Map{"items": rows, "kind": kind})
}

// Export GET /api/registry/:kind/export — журнал в Excel (.xlsx) со всеми
// реквизитами. Служебные коды enum заменяются человекочитаемыми подписями.
func (h *RegistryHandler) Export(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	kind := c.Params("kind")
	rows, err := h.rows(c, kind, userID)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to export registry")
	}

	f := excelize.NewFile()
	sheet := "Реестр"
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"№ исх.", "Дата подписи", "№ вх. (подразделение, дата регистрации)",
		"Заголовок", "Краткое содержание", "Статус", "Срочность",
		"Автор", "Подписант", "Согласующие (дата/время)",
		"Рассылка (ФИО, должность, подразделение)", "Создан", "Срок",
	}
	for i, hdr := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, hdr)
	}
	for r, row := range rows {
		vals := []string{
			deref(row.OutgoingNumber), fmtTime(row.SignedAt), joinIncoming(row.IncomingNumbers),
			row.Title, row.BodySummary, statusLabelRU(row.Status), urgencyLabelRU(row.Urgency),
			row.AuthorName, deref(row.SignerName), joinApprovers(row.Approvers),
			joinRecipients(row.Recipients), fmtTime(&row.CreatedAt), deref(row.DueDate),
		}
		for col, v := range vals {
			cell, _ := excelize.CoordinatesToCellName(col+1, r+2)
			f.SetCellValue(sheet, cell, v)
		}
	}

	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="registry_%s_%s.xlsx"`, kind, time.Now().Format("2006-01-02")))

	buf, err := f.WriteToBuffer()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to build xlsx")
	}
	return c.Send(buf.Bytes())
}

func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

// fmtTime переводит ISO-строку в дату-время dd.mm.yyyy HH:MM для выгрузки.
func fmtTime(s *string) string {
	if s == nil || *s == "" {
		return ""
	}
	t, err := time.Parse(time.RFC3339, *s)
	if err != nil {
		return *s
	}
	return t.Format("02.01.2006 15:04")
}

func joinIncoming(items []incomingInst) string {
	parts := make([]string, 0, len(items))
	for _, i := range items {
		s := i.Number
		if i.Department != "" {
			s += " (" + i.Department
			if i.RegisteredAt != "" {
				if t, err := time.Parse(time.RFC3339, i.RegisteredAt); err == nil {
					s += ", " + t.Format("02.01.2006 15:04")
				}
			}
			s += ")"
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

func joinRecipients(items []recipientRow) string {
	parts := make([]string, 0, len(items))
	for _, r := range items {
		s := r.FIO
		if r.Position != "" {
			s += ", " + r.Position
		}
		if r.Department != "" {
			s += ", " + r.Department
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

func joinApprovers(items []approverRow) string {
	parts := make([]string, 0, len(items))
	for _, a := range items {
		s := a.FIO
		if a.Position != "" {
			s += " (" + a.Position + ")"
		}
		if a.DecidedAt != "" {
			if t, err := time.Parse(time.RFC3339, a.DecidedAt); err == nil {
				s += " — " + t.Format("02.01.2006 15:04")
			}
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

// ArchiveYears GET /api/registry/archive/years — годы с архивными документами.
func (h *RegistryHandler) ArchiveYears(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	type yearRow struct {
		Year  int   `json:"year"`
		Count int64 `json:"count"`
	}
	var items []yearRow
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT EXTRACT(YEAR FROM coalesce(archived_at, executed_at, created_at))::int AS y, count(*)
			FROM documents
			WHERE status = 'archived'
			GROUP BY y ORDER BY y DESC`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r yearRow
			if err := rows.Scan(&r.Year, &r.Count); err != nil {
				return err
			}
			items = append(items, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load archive years")
	}
	return c.JSON(fiber.Map{"items": items})
}

// ArchiveByYear GET /api/registry/archive/:year — архивные документы за год,
// со всеми реквизитами (переиспользует обогащённый rows-запрос с фильтром).
func (h *RegistryHandler) ArchiveByYear(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	year := c.Params("year")

	var out []registryRow
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		q := `
			SELECT d.id, d.outgoing_number,
			       to_char((SELECT max(signed_at) FROM document_signatures WHERE document_id=d.id) AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       d.title, coalesce(d.body_summary,''), d.status::text, d.urgency::text,
			       ` + fmt.Sprintf(fioPosSQL, "au", "au", "au") + `,
			       (SELECT ` + fmt.Sprintf(fioPosSQL, "su", "su", "su") + `
			        FROM document_signatures ds JOIN users su ON su.id=ds.signer_id
			        WHERE ds.document_id=d.id ORDER BY ds.signed_at DESC LIMIT 1),
			       to_char(d.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(d.due_date, 'YYYY-MM-DD'),
			       to_char(d.due_datetime AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce((SELECT json_agg(json_build_object('number', i.incoming_number,
			             'department', coalesce(dep.name,''),
			             'registered_at', to_char(i.first_viewed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')) ORDER BY i.id)
			         FROM document_incoming_instances i
			         LEFT JOIN departments dep ON dep.id=i.receiving_department_id
			         WHERE i.document_id=d.id), '[]'),
			       coalesce((SELECT json_agg(json_build_object('fio', ru.full_name, 'position', coalesce(ru.position,''),
			             'department', coalesce(rdep.name,'')) ORDER BY ru.full_name)
			         FROM document_recipients r
			         JOIN users ru ON ru.id=r.recipient_user_id
			         LEFT JOIN departments rdep ON rdep.id=r.recipient_department_id
			         WHERE r.document_id=d.id), '[]'),
			       coalesce((SELECT json_agg(json_build_object('fio', apu.full_name, 'position', coalesce(apu.position,''),
			             'decided_at', to_char(aps.decided_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			             'status', aps.status::text) ORDER BY aps.display_order)
			         FROM approval_stages aps JOIN users apu ON apu.id=aps.approver_id
			         WHERE aps.document_id=d.id AND aps.stage_type<>'signing'), '[]')
			FROM documents d
			JOIN users au ON au.id=d.author_id
			WHERE d.status='archived'
			  AND EXTRACT(YEAR FROM coalesce(d.archived_at, d.executed_at, d.created_at))::text = $1
			ORDER BY d.created_at ASC
			LIMIT 2000`
		rows, err := tx.Query(c.Context(), q, year)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r registryRow
			var incJSON, recJSON, apprJSON []byte
			if err := rows.Scan(&r.ID, &r.OutgoingNumber, &r.SignedAt, &r.Title, &r.BodySummary,
				&r.Status, &r.Urgency, &r.AuthorName, &r.SignerName, &r.CreatedAt, &r.DueDate, &r.DueDatetime,
				&incJSON, &recJSON, &apprJSON); err != nil {
				return err
			}
			_ = json.Unmarshal(incJSON, &r.IncomingNumbers)
			_ = json.Unmarshal(recJSON, &r.Recipients)
			_ = json.Unmarshal(apprJSON, &r.Approvers)
			out = append(out, r)
		}
		return rows.Err()
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load archive year")
	}
	return c.JSON(fiber.Map{"items": out, "year": year})
}

// statusLabelRU/urgencyLabelRU переводят коды enum в подписи для выгрузок.
func statusLabelRU(s string) string {
	m := map[string]string{
		"draft": "Черновик", "on_approval_hierarchy": "Согласование (иерархия)",
		"on_approval_cross_dept": "Согласование (межвед.)", "on_signing": "На подписи",
		"signed": "Подписан", "sent": "Направлен", "in_progress": "В работе",
		"executed": "Исполнен", "archived": "В архиве", "rejected": "Отклонён",
	}
	if v, ok := m[s]; ok {
		return v
	}
	return s
}

func urgencyLabelRU(s string) string {
	m := map[string]string{"normal": "Обычная", "urgent": "Срочно", "out_of_turn": "Вне очереди"}
	if v, ok := m[s]; ok {
		return v
	}
	return s
}
