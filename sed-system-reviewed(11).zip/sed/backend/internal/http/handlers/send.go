package handlers

import (
	"encoding/json"
	"errors"
	"log"
	"fmt"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

type SendHandler struct {
	pool *pgxpool.Pool
	send *service.SendService
	hub  *ws.Hub
}

func NewSendHandler(pool *pgxpool.Pool, send *service.SendService, hub *ws.Hub) *SendHandler {
	return &SendHandler{pool: pool, send: send, hub: hub}
}

type recipientDTO struct {
	UserID       int64 `json:"user_id"`
	DepartmentID int64 `json:"department_id"`
}
type sendRequest struct {
	Recipients []recipientDTO `json:"recipients"`
}

// Send POST /api/documents/:id/send — направление/до-направление списку
// получателей. Получатели обязаны быть duty_officer/clerk (DB-триггер).
func (h *SendHandler) Send(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid document id")
	}
	var req sendRequest
	// Пустое/битое тело допустимо: тогда сервис активирует ПЛАНОВЫХ адресатов
	// (выбранных при создании). Явный список — до-направление/переопределение.
	_ = c.BodyParser(&req)

	recipients := make([]service.Recipient, 0, len(req.Recipients))
	for _, r := range req.Recipients {
		if r.UserID == 0 || r.DepartmentID == 0 {
			return fiber.NewError(fiber.StatusBadRequest, "у каждого получателя нужны user_id и department_id")
		}
		recipients = append(recipients, service.Recipient{UserID: r.UserID, DepartmentID: r.DepartmentID})
	}

	var notified []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Направлять документ может только автор или подписант.
		allowed, err := service.IsAuthorOrSigner(c.Context(), tx, docID, userID)
		if err != nil {
			return err
		}
		if !allowed && !isAdmin {
			return service.ErrForbiddenSend
		}
		// Из архива дослать нельзя.
		var st string
		if err := tx.QueryRow(c.Context(), `SELECT status::text FROM documents WHERE id=$1`, docID).Scan(&st); err != nil {
			return err
		}
		if st == "archived" {
			return fiber.NewError(fiber.StatusConflict, "документ в архиве — досылка недоступна")
		}
		n, err := h.send.Send(c.Context(), tx, docID, userID, recipients)
		if err != nil {
			return err
		}
		notified = n
		// Персистентные уведомления всем заинтересованным о направлении адресатам.
		if _, err := service.NotifyDocumentEvent(c.Context(), tx, docID, "document_sent", userID,
			fmt.Sprintf(`{"actor_id":%d}`, userID)); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		var fe *fiber.Error
		if errors.As(txErr, &fe) {
			return fe // проброс явных HTTP-ошибок (напр. документ в архиве)
		}
		switch {
		case errors.Is(txErr, service.ErrForbiddenSend):
			return fiber.NewError(fiber.StatusForbidden, "направлять документ может только автор или подписант")
		case errors.Is(txErr, service.ErrDocumentNotSigned):
			return fiber.NewError(fiber.StatusConflict, "документ должен быть подписан перед направлением")
		case errors.Is(txErr, service.ErrNoRecipients):
			return fiber.NewError(fiber.StatusBadRequest, "нужно указать хотя бы одного получателя (или задать плановую рассылку при создании)")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		default:
			if strings.Contains(txErr.Error(), "must have role duty_officer or clerk") {
				return fiber.NewError(fiber.StatusBadRequest, "получателем может быть только дежурный или сотрудник канцелярии")
			}
			log.Printf("send failed: doc=%d user=%d: %v", docID, userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось направить документ: "+txErr.Error())
		}
	}

	h.hub.NotifyUsers(notified, docID, "document_sent")
	return c.JSON(fiber.Map{"notified": len(notified)})
}

// Recipients GET /api/documents/:id/recipients — список рассылки (вкладка "Рассылка").
func (h *SendHandler) Recipients(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid document id")
	}
	var items any
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		list, err := h.send.ListRecipients(c.Context(), tx, docID)
		if err != nil {
			return err
		}
		items = list
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить список рассылки")
	}
	return c.JSON(fiber.Map{"items": items})
}

// RecipientsCounts GET /api/documents/recipients-counts?ids=1,2,3 — пакетно
// возвращает по каждому документу количество адресатов и сколько исполнили.
// Один запрос на страницу списка (не N+1). RLS ограничивает видимость.
func (h *SendHandler) RecipientsCounts(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	idsParam := c.Query("ids")
	if idsParam == "" {
		return c.JSON(fiber.Map{"counts": fiber.Map{}})
	}
	var ids []int64
	for _, s := range strings.Split(idsParam, ",") {
		if v, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64); err == nil && v > 0 {
			ids = append(ids, v)
		}
	}
	counts := fiber.Map{}
	if len(ids) == 0 {
		return c.JSON(fiber.Map{"counts": counts})
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Счётчики адресатов.
		rows, err := tx.Query(c.Context(), `
			SELECT document_id, count(*),
			       count(*) FILTER (WHERE completed_at IS NOT NULL)
			FROM document_recipients
			WHERE document_id = ANY($1::bigint[]) AND is_planned = false
			GROUP BY document_id`, ids)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var docID, total, done int64
			if err := rows.Scan(&docID, &total, &done); err != nil {
				return err
			}
			counts[strconv.FormatInt(docID, 10)] = fiber.Map{"total": total, "done": done}
		}
		if err := rows.Err(); err != nil {
			return err
		}

		// Доп. реквизиты для строк списка (как в журнале): автор с должностью,
		// подписант, дата подписи, подразделение-автор, входящие номера.
		brows, err := tx.Query(c.Context(), `
			SELECT d.id,
			       au.full_name || CASE WHEN coalesce(au.position,'')<>'' THEN ' (' || au.position || ')' ELSE '' END,
			       coalesce(adep.name,''),
			       (SELECT su.full_name || CASE WHEN coalesce(su.position,'')<>'' THEN ' (' || su.position || ')' ELSE '' END
			        FROM document_signatures ds JOIN users su ON su.id = ds.signer_id
			        WHERE ds.document_id = d.id ORDER BY ds.signed_at DESC LIMIT 1),
			       to_char((SELECT max(signed_at) FROM document_signatures WHERE document_id = d.id) AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce((SELECT json_agg(json_build_object('number', i.incoming_number, 'department', coalesce(idep.name,''))
			           ORDER BY i.id)
			         FROM document_incoming_instances i
			         LEFT JOIN departments idep ON idep.id = i.receiving_department_id
			         WHERE i.document_id = d.id), '[]'),
			       coalesce((SELECT json_agg(json_build_object(
			               'name', u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			               'stage_type', s.stage_type,
			               'status', s.status,
			               'decided_at', to_char(s.decided_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
			               ORDER BY s.display_order)
			         FROM approval_stages s JOIN users u ON u.id = s.approver_id
			         WHERE s.document_id = d.id AND s.stage_type IN ('hierarchy','cross_dept')), '[]')
			FROM documents d
			JOIN users au ON au.id = d.author_id
			LEFT JOIN departments adep ON adep.id = d.author_department_id
			WHERE d.id = ANY($1::bigint[])`, ids)
		if err != nil {
			return err
		}
		defer brows.Close()
		for brows.Next() {
			var docID int64
			var authorName, deptName string
			var signerName, signedAt *string
			var incoming, approvers []byte
			if err := brows.Scan(&docID, &authorName, &deptName, &signerName, &signedAt, &incoming, &approvers); err != nil {
				return err
			}
			key := strconv.FormatInt(docID, 10)
			entry, _ := counts[key].(fiber.Map)
			if entry == nil {
				entry = fiber.Map{"total": 0, "done": 0}
			}
			entry["author_name"] = authorName
			entry["department_name"] = deptName
			entry["signer_name"] = signerName
			entry["signed_at"] = signedAt
			var inc []map[string]any
			_ = json.Unmarshal(incoming, &inc)
			entry["incoming_numbers"] = inc
			var apr []map[string]any
			_ = json.Unmarshal(approvers, &apr)
			entry["approvers"] = apr
			counts[key] = entry
		}
		return brows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить счётчики адресатов")
	}
	return c.JSON(fiber.Map{"counts": counts})
}
