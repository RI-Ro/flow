package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

type UsersHandler struct {
	pool *pgxpool.Pool
}

func NewUsersHandler(pool *pgxpool.Pool) *UsersHandler {
	return &UsersHandler{pool: pool}
}

type userListItem struct {
	ID             int64    `json:"id"`
	FullName       string   `json:"full_name"`
	DepartmentID   int64    `json:"department_id"`
	DepartmentName string   `json:"department_name"`
	Roles          []string `json:"roles"`
}

// List GET /api/users — полный список активных пользователей с ролями.
// Оставлен для обратной совместимости / небольших справочников; для выбора
// согласующих/подписантов используйте Candidates (серверный поиск).
func (h *UsersHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var items []userListItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, u.full_name, u.primary_department_id, coalesce(d.name, ''),
			       coalesce(array_agg(ur.role::text) FILTER (WHERE ur.role IS NOT NULL), '{}')
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			LEFT JOIN user_roles ur ON ur.user_id = u.id
			WHERE u.is_active = true
			GROUP BY u.id, u.full_name, u.primary_department_id, d.name
			ORDER BY u.full_name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var item userListItem
			if err := rows.Scan(&item.ID, &item.FullName, &item.DepartmentID, &item.DepartmentName, &item.Roles); err != nil {
				return err
			}
			items = append(items, item)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to list users")
	}
	return c.JSON(fiber.Map{"items": items})
}

// roleFilterByGroup сопоставляет "группу" (параметр group) с ролями, дающими
// право участвовать в соответствующем шаге маршрута. По требованию: в
// согласование/подпись попадают ТОЛЬКО пользователи, состоящие в
// соответствующих группах.
var roleFilterByGroup = map[string][]string{
	"hierarchy":  {"approver_hierarchy"},
	"cross_dept": {"approver_cross_dept"},
	"signing":    {"signer"},
	"recipients": {"duty_officer", "clerk"},
	"all":        nil, // любой активный пользователь (для поручений)
}

// Candidates GET /api/users/candidates?group=hierarchy&q=иван&department_id=4&limit=20
//
// Серверный поиск кандидатов для шага маршрута. Рассчитан на 300-500+
// согласующих: НИЧЕГО не возвращает, пока не задан непустой q (по требованию
// "показ пользователя только после набора чего-то в фильтр"), чтобы не
// грузить весь справочник. Фильтрует по группе (роль), опционально по
// подразделению, ранжирует по совпадению имени. limit ограничен сверху.
func (h *UsersHandler) Candidates(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	group := c.Query("group")
	roles, ok := roleFilterByGroup[group]
	if !ok {
		return fiber.NewError(fiber.StatusBadRequest, "group: hierarchy, cross_dept, signing, recipients")
	}

	q := c.Query("q")
	// При пустом q НЕ возвращаем пустоту, а показываем первых кандидатов
	// группы (по требованию: без фильтра должно быть видно, кто может
	// согласовать/подписать). Поиск сужает список; пустой q = «показать
	// начало списка», а не «скрыть всех».

	limit := 20
	if l := c.Query("limit"); l != "" {
		if n, err := strconv.Atoi(l); err == nil && n > 0 && n <= 50 {
			limit = n
		}
	}
	var departmentID int64
	if d := c.Query("department_id"); d != "" {
		departmentID, _ = strconv.ParseInt(d, 10, 64)
	}

	var items []userListItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		pattern := "%" + q + "%"
		var query string
		var args []any
		if group == "recipients" {
			// ВАЖНО (исправление бага "получатель не имеет роли duty_officer"):
			// получателем рассылки может стать только тот, у кого роль
			// duty_officer/clerk в КОНКРЕТНОМ подразделении — это проверяет
			// DB-триггер check_recipient_role по recipient_department_id.
			// Поэтому возвращаем не primary_department_id, а ИМЕННО то
			// подразделение, где выдана роль (ur.department_id). Пользователь
			// с ролью в нескольких подразделениях появится несколько раз —
			// по строке на каждое, чтобы можно было выбрать нужный экземпляр
			// и триггер гарантированно прошёл.
			query = `
				SELECT u.id, u.full_name, ur.department_id, coalesce(d.name, ''),
				       array_agg(DISTINCT ur.role::text)
				FROM users u
				JOIN user_roles ur ON ur.user_id = u.id
				  AND ur.role = ANY($1::role_code[])
				  AND ur.department_id IS NOT NULL
				LEFT JOIN departments d ON d.id = ur.department_id
				WHERE u.is_active = true
				  AND u.full_name ILIKE $2
				  AND ($3 = 0 OR ur.department_id = $3)
				  AND u.id <> $5
				GROUP BY u.id, u.full_name, ur.department_id, d.name
				ORDER BY u.full_name, d.name
				LIMIT $4`
			args = []any{roles, pattern, departmentID, limit, userID}
		} else if roles == nil {
			// Группа "all" — любой активный пользователь (для исполнителей поручений).
			query = `
				SELECT u.id, u.full_name, u.primary_department_id, coalesce(d.name, ''),
				       coalesce(array_agg(DISTINCT ur.role::text) FILTER (WHERE ur.role IS NOT NULL), '{}')
				FROM users u
				LEFT JOIN user_roles ur ON ur.user_id = u.id
				LEFT JOIN departments d ON d.id = u.primary_department_id
				WHERE u.is_active = true
				  AND u.full_name ILIKE $1
				  AND ($2 = 0 OR u.primary_department_id = $2)
				  AND u.id <> $4
				GROUP BY u.id, u.full_name, u.primary_department_id, d.name
				ORDER BY u.full_name
				LIMIT $3`
			args = []any{pattern, departmentID, limit, userID}
		} else {
			query = `
				SELECT u.id, u.full_name, u.primary_department_id, coalesce(d.name, ''),
				       coalesce(array_agg(DISTINCT ur.role::text) FILTER (WHERE ur.role IS NOT NULL), '{}')
				FROM users u
				JOIN user_roles ur ON ur.user_id = u.id AND ur.role = ANY($1::role_code[])
				LEFT JOIN departments d ON d.id = u.primary_department_id
				WHERE u.is_active = true
				  AND u.full_name ILIKE $2
				  AND ($3 = 0 OR u.primary_department_id = $3)
				  AND u.id <> $5
				GROUP BY u.id, u.full_name, u.primary_department_id, d.name
				ORDER BY u.full_name
				LIMIT $4`
			args = []any{roles, pattern, departmentID, limit, userID}
		}
		rows, err := tx.Query(c.Context(), query, args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var item userListItem
			if err := rows.Scan(&item.ID, &item.FullName, &item.DepartmentID, &item.DepartmentName, &item.Roles); err != nil {
				return err
			}
			items = append(items, item)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to search candidates")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Departments GET /api/departments — справочник подразделений для
// компоновки/группировки в выпадающем списке.
func (h *UsersHandler) Departments(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	type dept struct {
		ID   int64  `json:"id"`
		Name string `json:"name"`
	}
	var items []dept
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `SELECT id, name FROM departments WHERE is_active = true ORDER BY name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var d dept
			if err := rows.Scan(&d.ID, &d.Name); err != nil {
				return err
			}
			items = append(items, d)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to list departments")
	}
	return c.JSON(fiber.Map{"items": items})
}
