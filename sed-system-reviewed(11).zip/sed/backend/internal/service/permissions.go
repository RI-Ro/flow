package service

import (
	"context"

	"github.com/jackc/pgx/v5"
)

// IsAuthorOrSigner возвращает true, если пользователь — автор документа ИЛИ его
// подписант (назначенный на этап stage_type='signing', либо уже подписавший).
// Используется для прав на связи и направление документа.
func IsAuthorOrSigner(ctx context.Context, tx pgx.Tx, documentID, userID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM documents d WHERE d.id = $1 AND d.author_id = $2
			UNION ALL
			SELECT 1 FROM approval_stages s
			  WHERE s.document_id = $1 AND s.stage_type = 'signing' AND s.approver_id = $2
			UNION ALL
			SELECT 1 FROM document_signatures sig
			  WHERE sig.document_id = $1 AND sig.signer_id = $2
		)`, documentID, userID).Scan(&ok)
	return ok, err
}

// CanAcquaint проверяет, может ли actor ознакомить targetUser: тот должен быть
// в подразделении actor'а или ниже по иерархии, ЛИБО в одном из заданных
// actor'у подразделений ознакомления (user_acquaint_departments) и ниже по их
// иерархии. Полностью совпадает с логикой выборки кандидатов на ознакомление.
func CanAcquaint(ctx context.Context, tx pgx.Tx, actorID, targetUserID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		WITH RECURSIVE roots AS (
			SELECT primary_department_id AS id FROM users WHERE id = $1
			UNION
			SELECT department_id FROM user_acquaint_departments WHERE user_id = $1
		),
		subtree AS (
			SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
			UNION ALL
			SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
		)
		SELECT EXISTS (
			SELECT 1 FROM users u
			WHERE u.id = $2 AND u.primary_department_id IN (SELECT id FROM subtree)
		)`, actorID, targetUserID).Scan(&ok)
	return ok, err
}

// CanAssignTo проверяет право дать поручение assignee по документу.
// Правила:
//   - автор и подписант: могут поручать ВСЕМ, кому направлен документ
//     (получателям), а также сотрудникам своего подразделения и вниз по иерархии;
//   - остальные: только сотрудникам своего подразделения и вниз по иерархии.
// (Плюс отдельно в хендлере — тем, кого пользователь сам ознакомил.)
func CanAssignTo(ctx context.Context, tx pgx.Tx, documentID, actorID, assigneeID int64) (bool, error) {
	// Общая проверка «в моём подразделении/ниже по иерархии ИЛИ в заданных мне
	// подразделениях (user_assign_departments) и ниже по их иерархии».
	inSubtree := func() (bool, error) {
		var ok bool
		err := tx.QueryRow(ctx, `
			WITH RECURSIVE roots AS (
				SELECT primary_department_id AS id FROM users WHERE id = $1
				UNION
				SELECT department_id FROM user_assign_departments WHERE user_id = $1
			),
			subtree AS (
				SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
				UNION ALL
				SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
			)
			SELECT EXISTS (
				SELECT 1 FROM users u
				WHERE u.id = $2 AND u.primary_department_id IN (SELECT id FROM subtree)
			)`, actorID, assigneeID).Scan(&ok)
		return ok, err
	}

	sub, err := inSubtree()
	if err != nil {
		return false, err
	}
	if sub {
		return true, nil
	}

	authorOrSigner, err := IsAuthorOrSigner(ctx, tx, documentID, actorID)
	if err != nil {
		return false, err
	}
	if authorOrSigner {
		// Автор/подписант дополнительно могут поручать любому получателю документа.
		var isRecipient bool
		if err := tx.QueryRow(ctx, `
			SELECT EXISTS(SELECT 1 FROM document_recipients
				WHERE document_id = $1 AND recipient_user_id = $2 AND is_planned = false)`,
			documentID, assigneeID).Scan(&isRecipient); err != nil {
			return false, err
		}
		return isRecipient, nil
	}
	return false, nil
}
