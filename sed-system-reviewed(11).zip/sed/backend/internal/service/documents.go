package service

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var ErrNotPDF = errors.New("file is not a valid PDF")

// ErrNotEditable — документ нельзя редактировать/изменять на текущем этапе,
// либо действие выполняет не автор.
var ErrNotEditable = errors.New("документ нельзя изменить на текущем этапе")

type CreateDocumentInput struct {
	AuthorID           int64
	AuthorDepartmentID int64
	Title              string
	BodySummary        string
	Urgency            string // normal|urgent|out_of_turn
	DueDate            *string
	DueDatetime        *string
	FileContent        []byte
	Route              RouteInput   // согласующие (может быть пусто) + обязательный подписант
	Recipients         []Recipient  // плановые адресаты рассылки (применятся после подписи)
}

type DocumentsService struct {
	access   *AccessService
	approval *ApprovalService
}

func NewDocumentsService(access *AccessService, approval *ApprovalService) *DocumentsService {
	return &DocumentsService{access: access, approval: approval}
}

// isPDF проверяет магические байты "%PDF-" — единственный разрешённый
// формат по ТЗ. Проверка на MIME из заголовка запроса недостаточна
// (клиент может подделать), поэтому смотрим на содержимое файла.
func isPDF(content []byte) bool {
	return bytes.HasPrefix(content, []byte("%PDF-"))
}

// Create валидирует маршрут, вставляет документ + файл-оригинал, строит
// этапы (согласование + обязательная подпись последней) и открывает доступ
// автору/руководителям. Подпись всегда идёт после всех согласований; если
// согласующих нет — документ сразу переходит на подпись (пропуск
// согласования по требованию).
func (s *DocumentsService) Create(ctx context.Context, tx pgx.Tx, in CreateDocumentInput) (int64, []int64, error) {
	if !isPDF(in.FileContent) {
		return 0, nil, ErrNotPDF
	}
	if in.Urgency == "" {
		in.Urgency = "normal"
	}

	// Валидация маршрута: собираем роли всех участников одним запросом,
	// затем проверяем правила (себя нельзя, дубли нельзя, роли обязательны).
	participantIDs := make([]int64, 0, len(in.Route.Approvers)+1)
	for _, a := range in.Route.Approvers {
		participantIDs = append(participantIDs, a.ApproverID)
	}
	if in.Route.SignerID != 0 {
		participantIDs = append(participantIDs, in.Route.SignerID)
	}
	roleOK, signerOK, err := s.approval.LoadRoleCheckers(ctx, tx, participantIDs)
	if err != nil {
		return 0, nil, err
	}
	if err := ValidateRoute(in.Route, in.AuthorID, roleOK, signerOK); err != nil {
		return 0, nil, err
	}

	// Начальный статус: если согласующих нет (пропуск) — сразу на подпись;
	// иначе — по типу ПЕРВОГО этапа в маршруте (иерархия может идти не
	// первой, поэтому смотрим фактический первый этап, а не хардкодим).
	initialStatus := "on_signing"
	if len(in.Route.Approvers) > 0 {
		switch in.Route.Approvers[0].StageType {
		case "cross_dept":
			initialStatus = "on_approval_cross_dept"
		default:
			initialStatus = "on_approval_hierarchy"
		}
	}

	var docID int64
	err = tx.QueryRow(ctx, `
		INSERT INTO documents (author_id, author_department_id, title, body_summary, urgency, status, due_date, due_datetime)
		VALUES ($1, $2, $3, $4, $5::doc_urgency, $6::doc_status, $7::date, $8::timestamptz)
		RETURNING id`,
		in.AuthorID, in.AuthorDepartmentID, in.Title, in.BodySummary, in.Urgency, initialStatus, in.DueDate, in.DueDatetime).
		Scan(&docID)
	if err != nil {
		return 0, nil, fmt.Errorf("insert document: %w", err)
	}

	sum := sha256.Sum256(in.FileContent)
	_, err = tx.Exec(ctx, `
		INSERT INTO document_files (document_id, content, sha256, size_bytes, uploaded_by)
		VALUES ($1, $2, $3, $4, $5)`,
		docID, in.FileContent, hex.EncodeToString(sum[:]), len(in.FileContent), in.AuthorID)
	if err != nil {
		return 0, nil, fmt.Errorf("insert document file: %w", err)
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, to_status)
		VALUES ($1, $2, 'created', $3::doc_status)`, docID, in.AuthorID, initialStatus)
	if err != nil {
		return 0, nil, fmt.Errorf("insert history: %w", err)
	}

	if err := s.access.GrantAuthorAccess(ctx, tx, docID, in.AuthorID); err != nil {
		return 0, nil, err
	}
	if err := s.access.GrantChiefsAccess(ctx, tx, docID, in.AuthorDepartmentID); err != nil {
		return 0, nil, err
	}

	// Строим этапы (согласование + подпись) и запускаем маршрут. BuildStages
	// всегда добавляет этап подписи последним; если согласующих нет — он
	// активируется сразу.
	stages := BuildStages(in.Route)
	notified, err := s.approval.CreateRoute(ctx, tx, docID, stages)
	if err != nil {
		return 0, nil, fmt.Errorf("create approval route: %w", err)
	}

	// Плановые получатели рассылки: сохраняем СЕЙЧАС (на этапе создания их
	// выбирает автор), но доступ и уведомления они получат только при
	// подписании (см. SigningService — активация плановой рассылки). Так
	// адресат не видит неподписанный документ.
	for _, r := range in.Recipients {
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_recipients (document_id, recipient_user_id, recipient_department_id, is_planned)
			VALUES ($1, $2, $3, true) ON CONFLICT DO NOTHING`, docID, r.UserID, r.DepartmentID); err != nil {
			return 0, nil, fmt.Errorf("insert planned recipient: %w", err)
		}
	}

	return docID, notified, nil
}

// SetPlannedRecipients заменяет ПЛАНОВЫХ адресатов рассылки (is_planned=true)
// документа — используется формой редактирования (аналогичной созданию).
// Уже активированные (разосланные) получатели не трогаются. Разрешено только
// автору и только пока документ не разослан (до статуса sent). Роль каждого
// получателя проверяется DB-триггером check_recipient_role.
func (s *DocumentsService) SetPlannedRecipients(ctx context.Context, tx pgx.Tx, documentID, actorID int64, recipients []Recipient) error {
	var status string
	var authorID int64
	if err := tx.QueryRow(ctx, `SELECT status, author_id FROM documents WHERE id=$1`, documentID).Scan(&status, &authorID); err != nil {
		return err
	}
	if authorID != actorID {
		return ErrNotEditable
	}
	frozen := map[string]bool{"sent": true, "in_progress": true, "executed": true, "archived": true}
	if frozen[status] {
		return ErrNotEditable
	}
	if _, err := tx.Exec(ctx, `DELETE FROM document_recipients WHERE document_id=$1 AND is_planned=true`, documentID); err != nil {
		return fmt.Errorf("clear planned recipients: %w", err)
	}
	for _, r := range recipients {
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_recipients (document_id, recipient_user_id, recipient_department_id, is_planned)
			VALUES ($1, $2, $3, true)
			ON CONFLICT (document_id, recipient_user_id) DO NOTHING`, documentID, r.UserID, r.DepartmentID); err != nil {
			return fmt.Errorf("insert planned recipient: %w", err)
		}
	}
	return nil
}

// UpdateInput — редактируемые поля (метаданные, не файл и не маршрут).
type UpdateInput struct {
	Title       string
	BodySummary string
	Urgency     string
	DueDate     *string
	DueDatetime *string
}

// Update меняет метаданные документа с учётом этапа жизненного цикла.
// Правило: редактирование разрешено только пока согласование НЕ началось —
// то есть в статусах draft и on_signing БЕЗ пройденных этапов. Как только
// хотя бы один этап согласования/подписи обработан (approved/rejected),
// документ считается «в работе» и метаданные заморожены — иначе согласующие
// видели бы одно, а подписант другое. Это и есть "изменение с учётом
// этапов согласования и подписи".
func (s *DocumentsService) Update(ctx context.Context, tx pgx.Tx, documentID, actorID int64, in UpdateInput) error {
	var status string
	var authorID int64
	if err := tx.QueryRow(ctx, `SELECT status, author_id FROM documents WHERE id=$1`, documentID).Scan(&status, &authorID); err != nil {
		return err
	}
	if authorID != actorID {
		return ErrNotEditable // менять метаданные может только автор
	}
	editableStatuses := map[string]bool{"draft": true, "on_approval_hierarchy": true, "on_approval_cross_dept": true, "on_signing": true, "rejected": true}
	if !editableStatuses[status] {
		return ErrNotEditable
	}
	if in.Urgency == "" {
		in.Urgency = "normal"
	}
	_, err := tx.Exec(ctx, `
		UPDATE documents SET title=$1, body_summary=$2, urgency=$3::doc_urgency,
		       due_date=$4::date, due_datetime=$5::timestamptz
		WHERE id=$6`,
		in.Title, in.BodySummary, in.Urgency, in.DueDate, in.DueDatetime, documentID)
	if err != nil {
		return fmt.Errorf("update document: %w", err)
	}

	// Если согласование уже начато (статус на согласовании/подписи) или
	// документ был отклонён — правка сбрасывает маршрут в начало (все
	// согласования аннулируются). Требование: «изменение до подписи → этап
	// согласования начинается заново, все согласования сбрасываются».
	if status == "on_approval_hierarchy" || status == "on_approval_cross_dept" ||
		status == "on_signing" || status == "rejected" {
		if err := s.resetRoute(ctx, tx, documentID, actorID); err != nil {
			return err
		}
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type)
		VALUES ($1, $2, 'edited')`, documentID, actorID)
	return err
}

// resetRoute аннулирует все согласования документа и возвращает маршрут в
// начало: этапы сбрасываются в waiting_deps, затем этапы без незакрытых
// зависимостей активируются (pending) — корректно для последовательного DAG,
// в отличие от «все сразу в pending». Статус документа пересчитывается по
// первому активному этапу. Пишет историю route_restarted и уведомляет
// заинтересованных. Используется при правке метаданных и при замене файла.
func (s *DocumentsService) resetRoute(ctx context.Context, tx pgx.Tx, documentID, actorID int64) error {
	// 1) Все этапы — в ожидание, решения очищаем.
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET status='waiting_deps', decided_at=NULL, comment=NULL
		WHERE document_id=$1`, documentID); err != nil {
		return fmt.Errorf("reset stages: %w", err)
	}
	// 2) Активируем этапы без незакрытых зависимостей (корни DAG).
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages s SET status='pending'
		WHERE s.document_id=$1
		  AND NOT EXISTS (SELECT 1 FROM approval_stage_dependencies d WHERE d.stage_id = s.id)`,
		documentID); err != nil {
		return fmt.Errorf("activate root stages: %w", err)
	}
	// 3) Новый статус документа — по типу первого активного этапа.
	var firstType string
	err := tx.QueryRow(ctx, `
		SELECT stage_type::text FROM approval_stages
		WHERE document_id=$1 AND status='pending'
		ORDER BY display_order LIMIT 1`, documentID).Scan(&firstType)
	newStatus := "on_signing"
	if err == nil {
		switch firstType {
		case "hierarchy":
			newStatus = "on_approval_hierarchy"
		case "cross_dept":
			newStatus = "on_approval_cross_dept"
		case "signing":
			newStatus = "on_signing"
		}
	} else if err != pgx.ErrNoRows {
		return err
	}
	if _, err := tx.Exec(ctx, `UPDATE documents SET status=$1::doc_status WHERE id=$2`, newStatus, documentID); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'route_restarted', 'документ изменён — согласование начато заново')`,
		documentID, actorID); err != nil {
		return err
	}
	// Уведомляем всех заинтересованных о рестарте маршрута.
	_, err = NotifyDocumentEvent(ctx, tx, documentID, "route_restarted", actorID,
		fmt.Sprintf(`{"actor_id":%d,"new_status":%q}`, actorID, newStatus))
	return err
}

// ReplaceFile заменяет PDF-оригинал документа (до подписи) и сбрасывает
// маршрут согласования в начало (все согласования аннулируются), фиксируя
// факт изменения. Возвращает ErrNotEditable, если документ уже подписан или
// правит не автор.
func (s *DocumentsService) ReplaceFile(ctx context.Context, tx pgx.Tx, documentID, actorID int64, content []byte, sha256hex string) error {
	var status string
	var authorID int64
	if err := tx.QueryRow(ctx, `SELECT status, author_id FROM documents WHERE id=$1`, documentID).Scan(&status, &authorID); err != nil {
		return err
	}
	if authorID != actorID {
		return ErrNotEditable
	}
	editableStatuses := map[string]bool{"draft": true, "on_approval_hierarchy": true, "on_approval_cross_dept": true, "on_signing": true, "rejected": true}
	if !editableStatuses[status] {
		return ErrNotEditable
	}
	// document_files имеет UNIQUE(document_id) — обновляем существующую строку.
	if _, err := tx.Exec(ctx, `
		UPDATE document_files
		   SET content=$1, sha256=$2, size_bytes=$3, uploaded_by=$4, uploaded_at=now()
		 WHERE document_id=$5`, content, sha256hex, len(content), actorID, documentID); err != nil {
		return fmt.Errorf("replace file: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'file_replaced', 'заменён файл документа')`, documentID, actorID); err != nil {
		return err
	}
	// Замена файла во время/после согласования — сброс маршрута.
	if status == "on_approval_hierarchy" || status == "on_approval_cross_dept" ||
		status == "on_signing" || status == "rejected" {
		return s.resetRoute(ctx, tx, documentID, actorID)
	}
	return nil
}

// ReplaceRoute заменяет маршрут согласования и подписанта у документа —
// разрешено только пока согласование НЕ началось (нет обработанных этапов),
// как и Update. Старые этапы и их зависимости удаляются, строятся новые из
// RouteInput (та же логика, что при создании). Доступ согласующим будет выдан
// заново при активации этапов.
func (s *DocumentsService) ReplaceRoute(ctx context.Context, tx pgx.Tx, documentID, actorID int64, route RouteInput) error {
	var status string
	var authorID int64
	if err := tx.QueryRow(ctx, `SELECT status, author_id FROM documents WHERE id=$1`, documentID).Scan(&status, &authorID); err != nil {
		return err
	}
	if authorID != actorID {
		return ErrNotEditable // менять маршрут может только автор
	}
	var decided int
	if err := tx.QueryRow(ctx, `
		SELECT count(*) FROM approval_stages
		WHERE document_id=$1 AND status IN ('approved','rejected')`, documentID).Scan(&decided); err != nil {
		return err
	}
	if decided > 0 {
		return ErrNotEditable // уже кто-то согласовал/отклонил — маршрут заморожен
	}

	// Валидация нового маршрута (роли, дубли, self).
	participantIDs := make([]int64, 0, len(route.Approvers)+1)
	for _, a := range route.Approvers {
		participantIDs = append(participantIDs, a.ApproverID)
	}
	if route.SignerID != 0 {
		participantIDs = append(participantIDs, route.SignerID)
	}
	roleOK, signerOK, err := s.approval.LoadRoleCheckers(ctx, tx, participantIDs)
	if err != nil {
		return err
	}
	if err := ValidateRoute(route, authorID, roleOK, signerOK); err != nil {
		return err
	}

	// Удаляем старые этапы (зависимости уйдут каскадом по FK, если он есть;
	// на всякий случай чистим обе таблицы явно).
	if _, err := tx.Exec(ctx, `
		DELETE FROM approval_stage_dependencies
		WHERE stage_id IN (SELECT id FROM approval_stages WHERE document_id=$1)`, documentID); err != nil {
		return fmt.Errorf("clear old deps: %w", err)
	}
	if _, err := tx.Exec(ctx, `DELETE FROM approval_stages WHERE document_id=$1`, documentID); err != nil {
		return fmt.Errorf("clear old stages: %w", err)
	}

	// Строим новые этапы и статус.
	initialStatus := "on_signing"
	if len(route.Approvers) > 0 {
		switch route.Approvers[0].StageType {
		case "cross_dept":
			initialStatus = "on_approval_cross_dept"
		default:
			initialStatus = "on_approval_hierarchy"
		}
	}
	if _, err := tx.Exec(ctx, `UPDATE documents SET status=$1::doc_status WHERE id=$2`, initialStatus, documentID); err != nil {
		return fmt.Errorf("update status: %w", err)
	}

	stages := BuildStages(route)
	if _, err := s.approval.CreateRoute(ctx, tx, documentID, stages); err != nil {
		return fmt.Errorf("rebuild route: %w", err)
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type)
		VALUES ($1, $2, 'route_changed')`, documentID, actorID)
	return err
}
