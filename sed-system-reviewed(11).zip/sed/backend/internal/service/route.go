package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var (
	ErrSelfApproval      = errors.New("нельзя назначить самого себя согласующим")
	ErrDuplicateApprover = errors.New("один и тот же согласующий добавлен несколько раз")
	ErrApproverWrongRole = errors.New("пользователь не состоит в группе согласования нужного типа")
	ErrSignerWrongRole   = errors.New("подписант не имеет права подписи")
	ErrNoSigner          = errors.New("подписант обязателен")
)

// ApproverInput — один согласующий в маршруте (тип шага + пользователь).
// Порядок между согласующими задаётся Sequential: если true, каждый
// следующий согласующий видит документ только после предыдущего; если
// false — все согласующие параллельны. Подпись сюда НЕ входит — она
// отдельным полем в RouteInput и всегда идёт после всех согласований.
type ApproverInput struct {
	StageType  string // hierarchy | cross_dept
	ApproverID int64
}

// RouteInput описывает маршрут: список согласующих (может быть пустым —
// согласование можно пропустить) и обязательного подписанта. Подпись
// вынесена отдельно и всегда выполняется последней.
type RouteInput struct {
	Approvers  []ApproverInput
	Sequential bool  // true = согласующие по цепочке; false = параллельно
	SignerID   int64 // обязателен
}

// ValidateRoute проверяет бизнес-правила ДО записи в БД:
//   - подписант обязателен;
//   - нельзя назначить себя согласующим (автор);
//   - один согласующий не может встречаться дважды;
//   - каждый согласующий состоит в соответствующей группе (роли);
//   - подписант имеет роль signer.
// Роли переданы отдельными множествами (получены одним запросом), чтобы
// функция оставалась чистой и тестируемой без БД.
func ValidateRoute(in RouteInput, authorID int64, roleOK func(userID int64, stageType string) bool, signerOK func(userID int64) bool) error {
	if in.SignerID == 0 {
		return ErrNoSigner
	}
	seen := make(map[int64]bool)
	for _, a := range in.Approvers {
		if a.ApproverID == authorID {
			return ErrSelfApproval
		}
		if seen[a.ApproverID] {
			return ErrDuplicateApprover
		}
		seen[a.ApproverID] = true
		if !roleOK(a.ApproverID, a.StageType) {
			return ErrApproverWrongRole
		}
	}
	if !signerOK(in.SignerID) {
		return ErrSignerWrongRole
	}
	return nil
}

// BuildStages превращает RouteInput в плоский список StageInput с
// зависимостями (DependsOnIdx), пригодный для ApprovalService.CreateRoute.
// Логика:
//   - согласующие: параллельно (нет зависимостей) либо цепочкой (каждый
//     зависит от предыдущего), в зависимости от Sequential;
//   - подпись: ВСЕГДА последний этап, зависит от ВСЕХ согласующих (то есть
//     активируется только после того, как все согласовали). Если
//     согласующих нет — подпись активна сразу.
func BuildStages(in RouteInput) []StageInput {
	stages := make([]StageInput, 0, len(in.Approvers)+1)

	approverIdx := make([]int, 0, len(in.Approvers))
	for i, a := range in.Approvers {
		st := StageInput{
			StageType:    a.StageType,
			ApproverID:   a.ApproverID,
			DisplayOrder: i,
		}
		if in.Sequential && i > 0 {
			st.DependsOnIdx = []int{i - 1}
		}
		stages = append(stages, st)
		approverIdx = append(approverIdx, i)
	}

	// Этап подписи. Зависит от всех согласующих: при Sequential достаточно
	// зависеть от последнего (он транзитивно после всех), при параллельном —
	// от каждого. Для простоты и корректности зависим от всех согласующих в
	// обоих случаях — лишние ребра в DAG не вредят.
	signStage := StageInput{
		StageType:    "signing",
		ApproverID:   in.SignerID,
		DisplayOrder: len(in.Approvers),
		DependsOnIdx: append([]int{}, approverIdx...),
	}
	stages = append(stages, signStage)
	return stages
}

// LoadRoleCheckers одним запросом собирает, кто в какой группе состоит и кто
// имеет право подписи, и возвращает две замыкающие функции для ValidateRoute.
// Так валидация делает ровно один поход в БД, а не по запросу на каждого
// согласующего (важно при 300-500 участниках).
func (s *ApprovalService) LoadRoleCheckers(ctx context.Context, tx pgx.Tx, userIDs []int64) (
	roleOK func(int64, string) bool, signerOK func(int64) bool, err error) {

	// userID -> set of roles
	roles := make(map[int64]map[string]bool)
	rows, err := tx.Query(ctx, `
		SELECT user_id, role::text FROM user_roles
		WHERE user_id = ANY($1::bigint[])`, userIDs)
	if err != nil {
		return nil, nil, fmt.Errorf("load roles: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var uid int64
		var role string
		if err := rows.Scan(&uid, &role); err != nil {
			return nil, nil, err
		}
		if roles[uid] == nil {
			roles[uid] = make(map[string]bool)
		}
		roles[uid][role] = true
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}

	stageTypeToRole := map[string]string{
		"hierarchy":  "approver_hierarchy",
		"cross_dept": "approver_cross_dept",
	}
	roleOK = func(userID int64, stageType string) bool {
		need, ok := stageTypeToRole[stageType]
		if !ok {
			return false
		}
		return roles[userID][need]
	}
	signerOK = func(userID int64) bool {
		return roles[userID]["signer"]
	}
	return roleOK, signerOK, nil
}
