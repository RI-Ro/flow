package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"golang.org/x/crypto/bcrypt"
)

// AdminService — операции администрирования оргструктуры и пользователей.
// Ключевая сложность — корректное сопровождение таблицы транзитивного
// замыкания department_closure при создании и, особенно, при переносе
// (drag-and-drop) подразделений вместе с их поддеревом.
type AdminService struct{}

func NewAdminService() *AdminService { return &AdminService{} }

var (
	ErrDeptHasChildren = errors.New("подразделение содержит вложенные подразделения")
	ErrDeptHasUsers    = errors.New("в подразделении есть пользователи")
	ErrCycle           = errors.New("нельзя переместить подразделение внутрь его же поддерева")
	ErrLoginTaken      = errors.New("логин уже занят")
	ErrPrefixTaken     = errors.New("префикс (outgoing_prefix) уже занят")
)

// ---------------------------------------------------------------------------
// Подразделения
// ---------------------------------------------------------------------------

// CreateDepartment создаёт подразделение и добавляет строки замыкания:
// self (depth 0) + связи от всех предков нового родителя. parentID=0 => корень.
func (s *AdminService) CreateDepartment(ctx context.Context, tx pgx.Tx, name, outgoingPrefix, numberingPrefix string, parentID int64) (int64, error) {
	var newID int64
	var parent any
	if parentID > 0 {
		parent = parentID
	}
	err := tx.QueryRow(ctx, `
		INSERT INTO departments (parent_id, name, outgoing_prefix, numbering_prefix)
		VALUES ($1, $2, $3, NULLIF($4,''))
		RETURNING id`, parent, name, outgoingPrefix, numberingPrefix).Scan(&newID)
	if err != nil {
		if isUniqueViolation(err) {
			return 0, ErrPrefixTaken
		}
		return 0, fmt.Errorf("insert department: %w", err)
	}
	// self-link
	if _, err := tx.Exec(ctx, `INSERT INTO department_closure (ancestor_id, descendant_id, depth) VALUES ($1,$1,0)`, newID); err != nil {
		return 0, fmt.Errorf("closure self: %w", err)
	}
	// связи от всех предков родителя (включая самого родителя)
	if parentID > 0 {
		if _, err := tx.Exec(ctx, `
			INSERT INTO department_closure (ancestor_id, descendant_id, depth)
			SELECT c.ancestor_id, $1, c.depth + 1
			FROM department_closure c
			WHERE c.descendant_id = $2`, newID, parentID); err != nil {
			return 0, fmt.Errorf("closure ancestors: %w", err)
		}
	}
	return newID, nil
}

// UpdateDepartment меняет редактируемые поля (без родителя — для переноса есть
// MoveDepartment). Пустая строка numberingPrefix => NULL.
func (s *AdminService) UpdateDepartment(ctx context.Context, tx pgx.Tx, id int64, name, outgoingPrefix, numberingPrefix string, isActive bool) error {
	ct, err := tx.Exec(ctx, `
		UPDATE departments
		SET name=$2, outgoing_prefix=$3, numbering_prefix=NULLIF($4,''), is_active=$5
		WHERE id=$1`, id, name, outgoingPrefix, numberingPrefix, isActive)
	if err != nil {
		if isUniqueViolation(err) {
			return ErrPrefixTaken
		}
		return fmt.Errorf("update department: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// MoveDepartment переносит подразделение id (со всем поддеревом) под нового
// родителя newParentID (0 => сделать корневым). Полностью перестраивает
// department_closure для перемещённого поддерева по стандартному алгоритму
// closure-table move. Защита от циклов: newParent не должен быть потомком id.
func (s *AdminService) MoveDepartment(ctx context.Context, tx pgx.Tx, id, newParentID int64) error {
	if id == newParentID {
		return ErrCycle
	}
	if newParentID > 0 {
		var inSubtree bool
		if err := tx.QueryRow(ctx, `
			SELECT EXISTS(SELECT 1 FROM department_closure WHERE ancestor_id=$1 AND descendant_id=$2)`,
			id, newParentID).Scan(&inSubtree); err != nil {
			return err
		}
		if inSubtree {
			return ErrCycle
		}
	}

	// 1) Обновляем parent_id.
	var parent any
	if newParentID > 0 {
		parent = newParentID
	}
	if ct, err := tx.Exec(ctx, `UPDATE departments SET parent_id=$2 WHERE id=$1`, id, parent); err != nil {
		return fmt.Errorf("update parent: %w", err)
	} else if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}

	// 2) Удаляем «внешние» связи: пары (ancestor, descendant), где потомок —
	//    из поддерева id, а предок — НЕ из поддерева id (т.е. старые предки).
	if _, err := tx.Exec(ctx, `
		DELETE FROM department_closure
		WHERE descendant_id IN (SELECT descendant_id FROM department_closure WHERE ancestor_id=$1)
		  AND ancestor_id NOT IN (SELECT descendant_id FROM department_closure WHERE ancestor_id=$1)`,
		id); err != nil {
		return fmt.Errorf("closure detach: %w", err)
	}

	// 3) Добавляем новые связи: каждый предок нового родителя × каждый потомок
	//    перемещаемого узла, с суммой глубин + 1.
	if newParentID > 0 {
		if _, err := tx.Exec(ctx, `
			INSERT INTO department_closure (ancestor_id, descendant_id, depth)
			SELECT super.ancestor_id, sub.descendant_id, super.depth + sub.depth + 1
			FROM department_closure super
			CROSS JOIN department_closure sub
			WHERE super.descendant_id = $2
			  AND sub.ancestor_id = $1`, id, newParentID); err != nil {
			return fmt.Errorf("closure attach: %w", err)
		}
	}
	return nil
}

// DeleteDepartment удаляет подразделение. Нельзя, если есть вложенные
// подразделения или пользователи (parent_id — RESTRICT, users ссылаются).
func (s *AdminService) DeleteDepartment(ctx context.Context, tx pgx.Tx, id int64) error {
	var children, users int
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM departments WHERE parent_id=$1`, id).Scan(&children); err != nil {
		return err
	}
	if children > 0 {
		return ErrDeptHasChildren
	}
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM users WHERE primary_department_id=$1`, id).Scan(&users); err != nil {
		return err
	}
	if users > 0 {
		return ErrDeptHasUsers
	}
	// closure-строки уберутся каскадом (FK ON DELETE CASCADE).
	ct, err := tx.Exec(ctx, `DELETE FROM departments WHERE id=$1`, id)
	if err != nil {
		return fmt.Errorf("delete department: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// ---------------------------------------------------------------------------
// Пользователи
// ---------------------------------------------------------------------------

// CreateUser создаёт пользователя с bcrypt-хэшем пароля.
func (s *AdminService) CreateUser(ctx context.Context, tx pgx.Tx, login, password, fullName, position string, deptID int64) (int64, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return 0, fmt.Errorf("hash password: %w", err)
	}
	var dept any
	if deptID > 0 {
		dept = deptID
	}
	var id int64
	err = tx.QueryRow(ctx, `
		INSERT INTO users (login, password_hash, full_name, position, primary_department_id, numbering_department_id)
		VALUES ($1, $2, $3, NULLIF($4,''), $5, $5)
		RETURNING id`, login, string(hash), fullName, position, dept).Scan(&id)
	if err != nil {
		if isUniqueViolation(err) {
			return 0, ErrLoginTaken
		}
		return 0, fmt.Errorf("insert user: %w", err)
	}
	return id, nil
}

// UpdateUser меняет ФИО, должность, логин, подразделение и активность.
func (s *AdminService) UpdateUser(ctx context.Context, tx pgx.Tx, id int64, login, fullName, position string, deptID int64, isActive bool) error {
	var dept any
	if deptID > 0 {
		dept = deptID
	}
	ct, err := tx.Exec(ctx, `
		UPDATE users
		SET login=$2, full_name=$3, position=NULLIF($4,''), primary_department_id=$5,
		    numbering_department_id=$5, is_active=$6
		WHERE id=$1`, id, login, fullName, position, dept, isActive)
	if err != nil {
		if isUniqueViolation(err) {
			return ErrLoginTaken
		}
		return fmt.Errorf("update user: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// MoveUser переносит пользователя в другое подразделение (drag-and-drop).
func (s *AdminService) MoveUser(ctx context.Context, tx pgx.Tx, id, deptID int64) error {
	var dept any
	if deptID > 0 {
		dept = deptID
	}
	ct, err := tx.Exec(ctx, `UPDATE users SET primary_department_id=$2, numbering_department_id=$2 WHERE id=$1`, id, dept)
	if err != nil {
		return fmt.Errorf("move user: %w", err)
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// SetPassword задаёт новый пароль пользователю.
func (s *AdminService) SetPassword(ctx context.Context, tx pgx.Tx, id int64, password string) error {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return fmt.Errorf("hash password: %w", err)
	}
	ct, err := tx.Exec(ctx, `UPDATE users SET password_hash=$2 WHERE id=$1`, id, string(hash))
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return pgx.ErrNoRows
	}
	return nil
}

// SetRoles заменяет набор ролей пользователя в указанном подразделении.
// deptID=0 => глобальные роли (department_id IS NULL), напр. admin.
func (s *AdminService) SetRoles(ctx context.Context, tx pgx.Tx, id, deptID int64, roles []string) error {
	if deptID > 0 {
		if _, err := tx.Exec(ctx, `DELETE FROM user_roles WHERE user_id=$1 AND department_id=$2`, id, deptID); err != nil {
			return err
		}
	} else {
		if _, err := tx.Exec(ctx, `DELETE FROM user_roles WHERE user_id=$1 AND department_id IS NULL`, id); err != nil {
			return err
		}
	}
	for _, r := range roles {
		var dept any
		if deptID > 0 {
			dept = deptID
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO user_roles (user_id, department_id, role)
			VALUES ($1, $2, $3::role_code) ON CONFLICT DO NOTHING`, id, dept, r); err != nil {
			return fmt.Errorf("insert role %s: %w", r, err)
		}
	}
	return nil
}

// isUniqueViolation распознаёт нарушение уникальности Postgres (SQLSTATE 23505).
func isUniqueViolation(err error) bool {
	return err != nil && (containsSQLState(err, "23505"))
}

func containsSQLState(err error, code string) bool {
	type sqlStater interface{ SQLState() string }
	var s sqlStater
	if errors.As(err, &s) {
		return s.SQLState() == code
	}
	return false
}
