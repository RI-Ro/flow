import React, { useState } from 'react'
import { api } from '../api/client'
import PersonPicker from './PersonPicker'

// Направление документа рассылке. Мультивыбор получателей через тот же
// PersonPicker (group="recipients"), что и на форме создания — списки
// рассылки синхронизированы в разных местах системы. Получателем может быть
// только дежурный/канцелярия; PersonPicker уже фильтрует по роли и несёт
// корректное department_id (где выдана роль), поэтому DB-триггер не падает.
// Пустой список -> бэкенд активирует плановых адресатов, выбранных при создании.
export default function SendPanel({ documentId, onSent, plannedHint, excludeIds = [] }) {
  const [recipients, setRecipients] = useState([])
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSend() {
    setBusy(true)
    setError('')
    try {
      await api.sendDocument(
        documentId,
        recipients.map((r) => ({ user_id: r.id, department_id: r.department_id })),
      )
      setSent(true)
      onSent?.()
    } catch (err) {
      setError(err.message || 'Не удалось отправить документ')
    } finally {
      setBusy(false)
    }
  }

  if (sent) {
    return (
      <div className="bg-surface border border-border rounded-lg p-4 text-sm text-success">
        Документ направлен получателям
      </div>
    )
  }

  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h2 className="font-medium text-sm mb-2">Направить документ</h2>
      <p className="text-xs text-text-secondary mb-3">
        Получателями могут быть только дежурные и сотрудники канцелярии. Можно выбрать нескольких.
        {plannedHint ? ' Оставьте поле пустым, чтобы направить плановым адресатам, выбранным при создании.' : ''}
      </p>
      <PersonPicker
        group="recipients"
        multiple
        value={recipients}
        onChange={setRecipients}
        excludeIds={excludeIds}
        placeholder="Выберите получателей…"
      />
      {error && <div className="text-danger text-xs my-2">{error}</div>}
      <button
        onClick={handleSend}
        disabled={busy}
        className="w-full mt-2 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-60"
      >
        {busy ? 'Отправка…' : recipients.length > 0 ? `Направить (${recipients.length})` : 'Направить плановым адресатам'}
      </button>
    </div>
  )
}
