import React, { useEffect, useRef, useState } from "react";
import { ChevronDown, Folder, Flag, CircleDot, User, Hash, CalendarDays, CalendarCheck, Star, X } from "lucide-react";
import { PRIORITIES, orderedBoards, resolveUser, fmtDate } from "../lib/theme.js";
import { countFilters, emptyFilters } from "../lib/filters.js";
import { Chip, inputStyle } from "../lib/ui.jsx";

// Модуль предназначен для панели отбора задач, общей для всех вкладок (доска, «Все задачи», календарь, «Входящие»).
// За образец взят фильтр проекта; набор условий и проверка задач находятся в lib/filters.js.

const STATUSES = [
  ["all", "Любой"],
  ["active", "В работе"],
  ["done", "Завершённые"],
  ["overdue", "Просроченные"],
];

// Функция summarize предназначена для краткой сводки выбранных значений на капсуле.
const summarize = (labels) =>
  labels.length === 0 ? null : labels.length === 1 ? labels[0] : `${labels[0]} +${labels.length - 1}`;

// Функция range предназначена для формирования подписи диапазона «с — по».
const range = (from, to) =>
  from || to ? `${from ? fmtDate(from) : "…"} — ${to ? fmtDate(to) : "…"}` : null;

// Компонент TaskFilters предназначен для отображения и изменения условий отбора задач.
export default function TaskFilters({
  theme, filters, setFilters, directory, people = [], tags = [], boards = null, extra = null,
}) {
  const toggle = (kind, value) => setFilters((f) => {
    const next = new Set(f[kind]);
    if (next.has(value)) next.delete(value);
    else next.add(value);
    return { ...f, [kind]: next };
  });

  const active = countFilters(filters);
  const status = filters.status || "all";

  return (
    <div className="glass-pane mx-4 mt-3 p-1.5 flex flex-wrap items-center gap-1.5 relative z-30"
      style={{ borderRadius: 26 }}>

      {/* Фильтр по проекту показывается только там, где в списке задачи разных проектов. */}
      {boards && (
        <label className="pill relative cursor-pointer transition-colors hover:bg-[var(--t-surface)]"
          style={{ ...pillBase(theme, Boolean(filters.boardId)), paddingRight: 30 }}>
          <Folder size={14} aria-hidden />
          <select value={filters.boardId}
            onChange={(e) => setFilters((f) => ({ ...f, boardId: e.target.value }))}
            aria-label="Проект"
            style={{ color: "inherit", background: "transparent", appearance: "none", WebkitAppearance: "none" }}
            className="outline-none cursor-pointer max-w-[220px] text-[13px] font-medium">
            <option value="">Все проекты</option>
            {orderedBoards(boards).map((b) => (
              <option key={b.id} value={b.id}>
                {"  ".repeat(b.depth) + b.title}
              </option>
            ))}
          </select>
          <ChevronDown size={14} className="absolute right-3 pointer-events-none" style={{ opacity: 0.7 }} />
        </label>
      )}

      <FilterGroup theme={theme} label="Статус" icon={CircleDot}
        value={status !== "all" ? STATUSES.find(([id]) => id === status)?.[1] : null}>
        {STATUSES.map(([id, label]) => (
          <Chip key={id} theme={theme} active={status === id}
            onClick={() => setFilters((f) => ({ ...f, status: id }))}>{label}</Chip>
        ))}
      </FilterGroup>

      <FilterGroup theme={theme} label="Избранное" icon={Star}
        value={filters.favorite === "1" ? "Только избранные" : filters.favorite === "0" ? "Не избранные" : null}>
        {[["", "Все"], ["1", "Только избранные"], ["0", "Не избранные"]].map(([id, label]) => (
          <Chip key={id} theme={theme} active={(filters.favorite || "") === id}
            onClick={() => setFilters((f) => ({ ...f, favorite: id }))}>{label}</Chip>
        ))}
      </FilterGroup>

      <FilterGroup theme={theme} label="Приоритет" icon={Flag}
        value={summarize(Object.entries(PRIORITIES).filter(([k]) => filters.priority.has(k)).map(([, v]) => v.label))}>
        {Object.entries(PRIORITIES).map(([k, v]) => (
          <Chip key={k} theme={theme} active={filters.priority.has(k)}
            onClick={() => toggle("priority", k)}>{v.label}</Chip>
        ))}
      </FilterGroup>

      {people.length > 0 && (
        <FilterGroup theme={theme} label="Исполнитель" icon={User}
          value={summarize(people.filter((id) => filters.assignee.has(id)).map((id) => resolveUser(directory, id).fullName.split(" ")[0]))}>
          {people.map((id) => {
            const u = resolveUser(directory, id);
            return (
              <Chip key={id} theme={theme} active={filters.assignee.has(id)}
                title={u.fullName} onClick={() => toggle("assignee", id)}>
                {u.fullName.split(" ")[0]}
              </Chip>
            );
          })}
        </FilterGroup>
      )}

      {tags.length > 0 && (
        <FilterGroup theme={theme} label="Теги" icon={Hash}
          value={summarize(tags.filter((t) => filters.tag.has(t)).map((t) => `#${t}`))}>
          {tags.map((t) => (
            <Chip key={t} theme={theme} active={filters.tag.has(t)}
              onClick={() => toggle("tag", t)}>#{t}</Chip>
          ))}
        </FilterGroup>
      )}

      <FilterGroup theme={theme} label="Срок исполнения" icon={CalendarDays}
        value={range(filters.dueFrom, filters.dueTo)}>
        <div className="flex items-center gap-1.5">
          <input type="date" value={filters.dueFrom}
            onChange={(e) => setFilters((f) => ({ ...f, dueFrom: e.target.value }))}
            style={inputStyle(theme)} className="rounded-xl px-2.5 py-1.5 text-[13px] outline-none"
            title="Срок не раньше" />
          <span style={{ color: theme.textMuted }} className="text-[12px]">—</span>
          <input type="date" value={filters.dueTo}
            onChange={(e) => setFilters((f) => ({ ...f, dueTo: e.target.value }))}
            style={inputStyle(theme)} className="rounded-xl px-2.5 py-1.5 text-[13px] outline-none"
            title="Срок не позже" />
        </div>
      </FilterGroup>

      {/* Дата завершения задаётся диапазоном «с — по», как срок; при выборе диапазона остаются только завершённые задачи. */}
      <FilterGroup theme={theme} label="Дата завершения" icon={CalendarCheck}
        value={range(filters.doneFrom, filters.doneTo)}>
        <div className="flex items-center gap-1.5">
          <input type="date" value={filters.doneFrom || ""}
            onChange={(e) => setFilters((f) => ({ ...f, doneFrom: e.target.value }))}
            style={inputStyle(theme)} className="rounded-xl px-2.5 py-1.5 text-[13px] outline-none"
            title="Завершена не раньше" />
          <span style={{ color: theme.textMuted }} className="text-[12px]">—</span>
          <input type="date" value={filters.doneTo || ""}
            onChange={(e) => setFilters((f) => ({ ...f, doneTo: e.target.value }))}
            style={inputStyle(theme)} className="rounded-xl px-2.5 py-1.5 text-[13px] outline-none"
            title="Завершена не позже" />
        </div>
      </FilterGroup>

      {extra}

      {active > 0 && (
        <button onClick={() => setFilters(emptyFilters())}
          style={{ color: theme.danger }}
          className="pill ml-auto transition-colors hover:bg-[var(--t-surfaceAlt)]" >
          <X size={14} /> Сбросить всё
        </button>
      )}
    </div>
  );
}

// Функция pillBase предназначена для получения базового стиля капсулы.
function pillBase(theme, on) {
  return {
    padding: "6px 12px", fontSize: 13, lineHeight: "20px",
    background: on ? theme.surface : theme.surfaceAlt,
    color: on ? theme.accent : theme.text,
    boxShadow: on ? `0 0 0 1px ${theme.accent} inset` : `0 0 0 1px ${theme.border} inset`,
  };
}

// Компонент FilterGroup предназначен для группы отбора в виде выпадающей капсулы. Параметр value — краткая сводка выбранного
// (при наличии капсула выделяется акцентом). Используется и вне панели (сортировка доски в App.jsx).
export function FilterGroup({ theme, label, children, value = null, icon: Icon = null }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const on = Boolean(value);

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-haspopup="true"
        className="pill transition-colors hover:bg-[var(--t-surface)]"
        style={pillBase(theme, on || open)}>
        {Icon && <Icon size={14} aria-hidden style={{ opacity: on ? 1 : 0.75 }} />}
        <span style={{ color: on ? theme.textMuted : undefined }}>{label}</span>
        {on && <span className="font-semibold truncate max-w-[180px]">{value}</span>}
        <ChevronDown size={14} aria-hidden
          style={{ opacity: 0.7, transform: open ? "rotate(180deg)" : "none", transition: "transform .15s ease-out" }} />
      </button>
      {open && (
        <div className="glass-pane absolute left-0 top-full mt-2 p-3 z-40 min-w-[220px]"
          style={{ borderRadius: 18, boxShadow: theme.dark ? "0 16px 40px -12px rgba(0,0,0,.7)" : "0 16px 40px -14px rgba(30,30,60,.3)" }}>
          <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-2">{label}</div>
          <div className="flex flex-wrap gap-1.5 max-w-sm">{children}</div>
        </div>
      )}
    </div>
  );
}
