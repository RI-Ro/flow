import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, AlertTriangle, Clock, Database, Gauge as GaugeIcon, HardDrive,
  Layers, RefreshCw, Server, Timer, Users, Zap, ChevronDown, ChevronRight,
} from "lucide-react";

import { api } from "../lib/api.js";
import { Gauge, Sparkline, TimeChart, thresholdColor } from "../lib/charts.jsx";
import {
  fmtBytes, fmtDur, fmtNum, fmtPct, fmtSec, fmtTime,
} from "../lib/format.js";

// Модуль предназначен для встроенного дашборда состояния системы (для администратора): запросы, база данных,
// объём системы и события. Устроен по образцу систем мониторинга: период, автообновление, сворачиваемые разделы, панели.

const RANGES = [
  ["5m", "5 мин"],
  ["15m", "15 мин"],
  ["1h", "1 час"],
  ["6h", "6 часов"],
];

const REFRESH = [
  [0, "выкл."],
  [10, "10 с"],
  [30, "30 с"],
  [60, "1 мин"],
];

// Функция tk предназначена для получения цвета ряда из токенов темы, чтобы графики соответствовали выбранной теме.
const tk = (theme, i) => [theme.accent, theme.accent2, theme.success, theme.warning, theme.danger, theme.info][i % 6];
const seriesColor = tk;

// Подписи счётчиков объёма: ключи приходят с сервера.
const ENTITY_LABELS = {
  users: "Пользователей",
  users_active: "Из них активных",
  users_online_day: "Входили за сутки",
  sessions: "Живых сессий",
  boards: "Проектов",
  boards_archived: "В архиве",
  tasks: "Задач",
  tasks_open: "В работе",
  tasks_done: "Завершено",
  tasks_overdue: "Просрочено",
  tasks_archived: "Задач в архиве",
  comments: "Комментариев",
  attachments: "Файлов",
  charts: "Диаграмм",
  whiteboards: "Совместных досок",
  chats: "Чатов",
  chat_messages: "Сообщений",
  reminders: "Напоминаний",
  notifications_unread: "Непрочитанных уведомлений",
};

const ENTITY_ORDER = [
  "users", "users_active", "users_online_day", "sessions",
  "boards", "tasks", "tasks_open", "tasks_done", "tasks_overdue",
  "comments", "attachments", "charts", "whiteboards",
  "chats", "chat_messages", "reminders", "notifications_unread",
];

// Компонент UsageBar предназначен для полосы заполнения: занято из всего, цвет меняется при высокой загрузке.
function UsageBar({ theme, share }) {
  const v = Math.max(0, Math.min(1, share || 0));
  const color = v > 0.9 ? theme.danger : v > 0.75 ? theme.warning : theme.success;
  return (
    <div style={{ background: theme.surfaceAlt }} className="h-2 rounded-full overflow-hidden">
      <div style={{ width: `${v * 100}%`, background: color }} className="h-full" />
    </div>
  );
}

// Компонент HostPanel предназначен для вывода сведений о сервере: память (всего, занято, свободно), диски, нагрузка, версии.
// Данные запрашиваются отдельно от метрик, поэтому панель работает и при выключенном сборе метрик.
function HostPanel({ theme, every }) {
  const [h, setH] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    let alive = true;
    const run = () => api.systemHost().then((d) => { if (alive) { setH(d); setErr(""); } })
      .catch((e) => { if (alive) setErr(e.message); });
    run();
    const t = every > 0 ? setInterval(run, every * 1000) : null;
    return () => { alive = false; if (t) clearInterval(t); };
  }, [every]);
  if (err) return <p style={{ color: theme.danger }} className="text-[13px] mb-3">Сведения о сервере: {err}</p>;
  if (!h) return null;
  const m = h.memory || {};
  const memShare = m.total ? m.used / m.total : 0;
  const swapUsed = (m.swapTotal || 0) - (m.swapFree || 0);
  const row = (k, v) => (
    <div className="flex justify-between gap-3 text-[13px]">
      <span style={{ color: theme.textMuted }}>{k}</span>
      <span style={{ color: theme.text }} className="tabular-nums text-right">{v}</span>
    </div>
  );
  const card = "glass-pane p-3.5 space-y-2";
  return (
    <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-2.5 mb-4">
      <div className={card}>
        <div style={{ color: theme.text }} className="text-[14px] font-semibold flex items-center gap-2">
          <Server size={15} style={{ color: theme.accent }} /> Сервер
        </div>
        {row("Имя", h.hostname || "—")}
        {row("Система", h.os || "—")}
        {row("Ядро / архитектура", `${h.kernel || "—"} / ${h.arch}`)}
        {row("Работает", fmtDur(h.uptimeSeconds))}
        {row("Процессор", `${h.cpu?.cores} яд.`)}
        {h.cpu?.model && <div style={{ color: theme.textMuted }} className="text-[12px] break-words">{h.cpu.model}</div>}
        {row("Нагрузка 1/5/15 мин", `${fmtNum(h.cpu?.load1, 2)} / ${fmtNum(h.cpu?.load5, 2)} / ${fmtNum(h.cpu?.load15, 2)}`)}
      </div>
      <div className={card}>
        <div style={{ color: theme.text }} className="text-[14px] font-semibold flex items-center gap-2">
          <GaugeIcon size={15} style={{ color: theme.accent }} /> Оперативная память
        </div>
        <UsageBar theme={theme} share={memShare} />
        {row("Всего", fmtBytes(m.total))}
        {row("Занято", `${fmtBytes(m.used)} (${fmtPct(memShare * 100)})`)}
        {row("Свободно", fmtBytes(m.available))}
        {row("Кэш файлов", fmtBytes(m.cached))}
        {m.swapTotal > 0 && row("Подкачка занято / всего", `${fmtBytes(swapUsed)} / ${fmtBytes(m.swapTotal)}`)}
        {row("Приложение (куча / всего)", `${fmtBytes(h.process?.heapBytes)} / ${fmtBytes(h.process?.sysBytes)}`)}
      </div>
      <div className={card}>
        <div style={{ color: theme.text }} className="text-[14px] font-semibold flex items-center gap-2">
          <HardDrive size={15} style={{ color: theme.accent }} /> Дисковое пространство
        </div>
        {(h.disks || []).map((d) => (
          <div key={d.path} className="space-y-1">
            <div className="flex justify-between text-[12px]" style={{ color: theme.textMuted }}>
              <span>{d.name}</span><span className="tabular-nums">{fmtBytes(d.free)} свободно</span>
            </div>
            <UsageBar theme={theme} share={d.usedShare} />
            <div className="text-[11px] tabular-nums" style={{ color: theme.textMuted }}>
              всего {fmtBytes(d.total)}, занято {fmtBytes(d.used)} · {d.path}
            </div>
          </div>
        ))}
      </div>
      <div className={card}>
        <div style={{ color: theme.text }} className="text-[14px] font-semibold flex items-center gap-2">
          <Database size={15} style={{ color: theme.accent }} /> Приложение и база данных
        </div>
        {row("Go", h.process?.goVersion)}
        {row("Горутин", fmtNum(h.process?.goroutines, 0))}
        {row("Приложение работает", fmtDur(h.process?.uptimeSeconds))}
        {h.database?.version && row("PostgreSQL", h.database.version)}
        {h.database?.sizeBytes != null && row("Размер базы", fmtBytes(h.database.sizeBytes))}
        {h.database?.connections != null && row("Соединений с базой", fmtNum(h.database.connections, 0))}
        {h.counts?.users != null && row("Пользователей / задач", `${h.counts.users} / ${h.counts.tasks ?? "—"}`)}
        {h.counts && Object.keys(h.counts).length === 0 && (
          <div style={{ color: theme.warning }} className="text-[12px]">Объёмы данных недоступны: примените миграцию 0037.</div>
        )}
      </div>
    </div>
  );
}

// Компонент System предназначен для отображения состояния системы.
export default function System({ theme, onError }) {
  const [range, setRange] = useState("1h");
  const [every, setEvery] = useState(30);
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState("");
  const [at, setAt] = useState(null);
  // Состояние открытых разделов; свёрнутые разделы позволяют просматривать один срез из множества панелей.
  const [open, setOpen] = useState({ app: true, db: true, objects: true });
  const timer = useRef(null);

  const load = useCallback(async (silent) => {
    if (!silent) setBusy(true);
    try {
      const d = await api.systemState(range);
      setData(d);
      setAt(Date.now());
      setFailed("");
    } catch (e) {
      // Ошибка отображается в панели, а не всплывающим сообщением: при автообновлении оно повторялось бы.
      setFailed(e.message);
      if (!silent && onError) onError(e.message);
    } finally {
      setBusy(false);
    }
  }, [range, onError]);

  useEffect(() => { load(false); }, [load]);

  useEffect(() => {
    clearInterval(timer.current);
    if (every > 0) timer.current = setInterval(() => load(true), every * 1000);
    return () => clearInterval(timer.current);
  }, [every, load]);

  const pts = data?.points || [];
  const s = data?.summary || {};
  const ent = data?.entities || {};

  // Если история за выбранный период накоплена не полностью, это указывается на панели.
  const short = data && data.historySeconds < data.windowSeconds - 30;

  const palette = useMemo(() => ({
    ok: theme.success, warn: theme.warning, bad: theme.danger,
  }), [theme]);

  return (
    <div className="max-w-[1500px] mx-auto">
      {/* Блок: верхняя панель (период и обновление). Заголовок экрана отображает оболочка приложения. */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <div style={{ color: theme.textMuted }} className="flex items-center gap-2 mr-auto text-[14px]">
          <Server size={16} style={{ color: theme.accent }} />
          {data ? <span className="tabular-nums">Работает {fmtDur(data.uptimeSeconds)}</span> : "Состояние системы"}
        </div>

        <div className="segmented" role="group" aria-label="Период">
          {RANGES.map(([id, label]) => (
            <button key={id} onClick={() => setRange(id)} aria-pressed={range === id}>{label}</button>
          ))}
        </div>

        <select value={every} onChange={(e) => setEvery(Number(e.target.value))}
          title="Автообновление" aria-label="Автообновление"
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="rounded-full pl-4 pr-3 py-2 text-[13px] font-medium outline-none">
          {REFRESH.map(([v, label]) => (
            <option key={v} value={v}>Обновлять: {label}</option>
          ))}
        </select>

        <button onClick={() => load(false)} disabled={busy} className="btn-pill !text-[13px] tabular-nums">
          <RefreshCw size={14} className={busy ? "animate-spin" : ""} />
          {at ? fmtTime(at) : "Обновить"}
        </button>
      </div>

      <HostPanel theme={theme} every={every} />

      {failed && (
        <div style={{ border: `1px solid ${theme.danger}`, color: theme.text }}
          className="glass-pane !rounded-2xl p-3.5 mb-3 text-[14px] flex items-start gap-2">
          <AlertTriangle size={15} style={{ color: theme.danger }} className="shrink-0 mt-[1px]" />
          <span>{failed}</span>
        </div>
      )}

      {!data && !failed && (
        <div style={{ color: theme.textMuted }} className="text-[13px] py-10 text-center">
          Собираем показания…
        </div>
      )}

      {data && (
        <>
          {short && (
            <p style={{ color: theme.textMuted }} className="text-[12px] mb-3">
              История в памяти приложения — за {fmtDur(data.historySeconds)}: показания
              собираются с момента запуска и не сохраняются между перезапусками.
              Для длинной истории есть выгрузка в Prometheus.
            </p>
          )}

          {/* Блок: сводка */}
          <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-2.5 mb-4">
            <Stat theme={theme} label="Запросов/с" value={fmtNum(s.rps, 2)}
              points={pts} field="rps" color={seriesColor(theme, 0)} icon={Activity} />
            <Stat theme={theme} label="Ошибки 5xx" value={fmtPct(s.errShare)}
              points={pts} field="rps5xx"
              color={thresholdColor(theme, s.errShare, [[0, "ok"], [1, "warn"], [5, "bad"]])}
              icon={AlertTriangle} hint="Доля ответов 5xx — поломки на сервере" />
            <Stat theme={theme} label="Отказы 4xx" value={fmtPct(s.clientErrShare)}
              points={pts} field="rps4xx" color={seriesColor(theme, 3)}
              hint="Нет доступа, не найдено, превышена частота — обычная жизнь приложения" />
            <Stat theme={theme} label="Ответ p95" value={fmtSec(s.p95)}
              points={pts} field="p95"
              color={thresholdColor(theme, s.p95, [[0, "ok"], [0.3, "warn"], [1, "bad"]])}
              icon={Timer} hint="95 % запросов быстрее этого времени" />
            <Stat theme={theme} label="Ответ p99" value={fmtSec(s.p99)}
              points={pts} field="p99"
              color={thresholdColor(theme, s.p99, [[0, "ok"], [1, "warn"], [3, "bad"]])} />
            <Stat theme={theme} label="В обработке" value={fmtNum(s.inFlight, 0)}
              points={pts} field="inFlight" color={seriesColor(theme, 6)} />
            <Stat theme={theme} label="Медленных/мин" value={fmtNum(s.slowPerMin, 1)}
              color={thresholdColor(theme, s.slowPerMin, [[0, "ok"], [1, "warn"], [10, "bad"]])}
              icon={Clock} hint="Запросы дольше 500 мс, за последние пять минут" />
            <Stat theme={theme} label="Пользователей онлайн" value={fmtNum(s.wsUsers, 0)}
              points={pts} field="wsUsers" color={seriesColor(theme, 2)} icon={Users}
              hint={`Соединений: ${fmtNum(s.wsConns, 0)} — у одного человека может быть несколько вкладок`} />
          </div>

          {/* Блок: приложение */}
          <Section theme={theme} title="Запросы" icon={Zap}
            open={open.app} onToggle={() => setOpen((o) => ({ ...o, app: !o.app }))}>
            <div className="grid lg:grid-cols-2 gap-2">
              <Panel theme={theme} title="Запросов в секунду по кодам ответа"
                hint="Накопительно: видно и общий поток, и вклад ошибок">
                <TimeChart theme={theme} points={pts} stacked format="rps"
                  series={[
                    { key: "rps2xx", label: "2xx успешно", color: theme.success },
                    { key: "rps3xx", label: "3xx перенаправления", color: seriesColor(theme, 0) },
                    { key: "rps4xx", label: "4xx отказы", color: theme.warning },
                    { key: "rps5xx", label: "5xx ошибки", color: theme.danger },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Время ответа"
                hint="Среднее рядом с перцентилями намеренно: расхождение между ними и есть признак выбросов">
                <TimeChart theme={theme} points={pts} format="sec"
                  series={[
                    { key: "p50", label: "p50", color: tk(theme, 0) },
                    { key: "p95", label: "p95", color: tk(theme, 1) },
                    { key: "p99", label: "p99", color: tk(theme, 2) },
                    { key: "avg", label: "среднее", color: tk(theme, 3) },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Запросов в обработке">
                <TimeChart theme={theme} points={pts} format="num" height={120}
                  series={[{ key: "inFlight", label: "в обработке", fill: true, color: tk(theme, 0) }]} />
              </Panel>

              <Panel theme={theme} title="Исходящий трафик">
                <TimeChart theme={theme} points={pts} format="bps" height={120}
                  series={[{ key: "bytesPerSec", label: "отдано", color: seriesColor(theme, 6), fill: true }]} />
              </Panel>
            </div>

            <div className="grid xl:grid-cols-2 gap-2 mt-2">
              <Panel theme={theme} title="Маршруты за период"
                hint="Метка маршрута — шаблон (/api/tasks/:taskID), а не конкретный путь: иначе серий было бы столько же, сколько задач">
                <Table theme={theme}
                  cols={[
                    { k: "route", label: "Маршрут", grow: true,
                      render: (r) => (
                        <span className="flex items-center gap-1.5 min-w-0">
                          <b style={{ color: theme.textMuted }} className="mono text-[11px] shrink-0">{r.method}</b>
                          <span className="truncate">{r.route}</span>
                        </span>
                      ) },
                    { k: "requests", label: "Запросов", num: true, bar: true, fmt: (v) => fmtNum(v, 0) },
                    { k: "rps", label: "в сек.", num: true, fmt: (v) => fmtNum(v, 2) },
                    { k: "avg", label: "среднее", num: true, fmt: fmtSec },
                    { k: "p95", label: "p95", num: true, fmt: fmtSec },
                    { k: "errors", label: "ошибок", num: true, fmt: (v) => fmtNum(v, 0),
                      color: (v) => (v > 0 ? theme.warning : undefined) },
                  ]}
                  rows={data.routes} keyOf={(r) => r.method + r.route}
                  sort="requests" empty="За выбранный период запросов не было" />
              </Panel>

              <Panel theme={theme} title="Медленные запросы (от 500 мс)"
                hint="Журнал последних двухсот: в метриках времени события нет, а для разбора нужно именно оно">
                <Table theme={theme}
                  cols={[
                    { k: "at", label: "Время", fmt: (v) => fmtTime(new Date(v).getTime()) },
                    { k: "route", label: "Маршрут", grow: true,
                      render: (r) => (
                        <span className="flex items-center gap-1.5 min-w-0">
                          <b style={{ color: theme.textMuted }} className="mono text-[11px] shrink-0">{r.method}</b>
                          <span className="truncate">{r.route}</span>
                        </span>
                      ) },
                    { k: "status", label: "Код", num: true,
                      color: (v) => (v >= 500 ? theme.danger : v >= 400 ? theme.warning : undefined) },
                    { k: "seconds", label: "Время", num: true, fmt: fmtSec, bar: true,
                      color: (v) => (v >= 3 ? theme.danger : theme.warning) },
                  ]}
                  rows={data.slow} keyOf={(r, i) => r.at + i} sort={null}
                  empty="Медленных запросов не было — и это хорошая новость" />
              </Panel>
            </div>
          </Section>

          {/* Блок: база данных */}
          <Section theme={theme} title="База данных" icon={Database}
            open={open.db} onToggle={() => setOpen((o) => ({ ...o, db: !o.db }))}>
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2 mb-2">
              <Stat theme={theme} label="Размер базы" value={fmtBytes(s.dbSizeBytes)}
                color={seriesColor(theme, 0)} icon={HardDrive} />
              <Stat theme={theme} label="Попаданий в кэш" value={fmtPct(s.cacheHit, 2)}
                points={pts} field="cacheHit"
                color={thresholdColor(theme, 100 - (s.cacheHit || 100), [[0, "ok"], [1, "warn"], [5, "bad"]])}
                hint="Ниже 99 % на устоявшейся нагрузке — мало памяти под кэш либо не хватает индексов" />
              <Stat theme={theme} label="Соединений с базой"
                value={`${fmtNum(s.connections, 0)} / ${fmtNum(s.maxConnections, 0)}`}
                color={seriesColor(theme, 6)} />
              <Stat theme={theme} label="Транзакций/с" value={fmtNum(s.dbTxPerSec, 2)}
                points={pts} field="dbTxPerSec" color={seriesColor(theme, 2)} />
              <Stat theme={theme} label="Откатов" value={fmtPct(s.rollbackShare)}
                color={thresholdColor(theme, s.rollbackShare, [[0, "ok"], [2, "warn"], [10, "bad"]])} />
              <Stat theme={theme} label="Долгая транзакция" value={fmtSec(s.longestTx)}
                points={pts} field="longestTx"
                color={thresholdColor(theme, s.longestTx, [[0, "ok"], [5, "warn"], [120, "bad"]])}
                hint="Долгая транзакция держит снимок данных и мешает автоочистке" />
            </div>

            <div className="grid lg:grid-cols-3 gap-2">
              <Panel theme={theme} title="Пул соединений приложения" className="lg:col-span-2"
                hint="«Занято» вплотную к «пределу» — запросы начнут ждать свободное соединение">
                <TimeChart theme={theme} points={pts} format="num"
                  series={[
                    { key: "poolTotal", label: "всего", color: tk(theme, 0) },
                    { key: "poolAcquired", label: "занято", color: tk(theme, 1) },
                    { key: "poolIdle", label: "свободно", color: tk(theme, 2) },
                    { key: "poolMax", label: "предел", color: theme.danger },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Загрузка пула">
                {/* Предел передаётся как есть: при отсутствии данных шкала показывает прочерк. */}
                <Gauge theme={theme} value={s.poolAcquired} max={s.poolMax}
                  label={`${fmtNum(s.poolAcquired, 0)} из ${fmtNum(s.poolMax, 0)}`}
                  thresholds={[[0, "ok"], [70, "warn"], [90, "bad"]]} />
                <p style={{ color: theme.textMuted }} className="text-[12px] text-center">
                  Ожиданий свободного соединения: {fmtNum(s.poolWaits, 2)}/с
                </p>
              </Panel>

              <Panel theme={theme} title="Время транзакции">
                <TimeChart theme={theme} points={pts} format="sec" height={130}
                  series={[
                    { key: "dbAvg", label: "среднее", color: tk(theme, 0) },
                    { key: "dbP95", label: "p95", color: seriesColor(theme, 1) },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Фиксации и откаты">
                <TimeChart theme={theme} points={pts} format="rps" height={130}
                  series={[
                    { key: "commits", label: "фиксаций", color: theme.success },
                    { key: "rollbacks", label: "откатов", color: theme.warning },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Блоки: кэш и диск"
                hint="Чтения с диска на фоне кэша — признак нехватки памяти под кэш">
                <TimeChart theme={theme} points={pts} format="rps" height={130}
                  series={[
                    { key: "blksHit", label: "из кэша", color: seriesColor(theme, 2) },
                    { key: "blksRead", label: "с диска", color: seriesColor(theme, 1) },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Соединения по состоянию">
                <TimeChart theme={theme} points={pts} stacked format="num" height={130}
                  series={[
                    { key: "connsActive", label: "активные", color: seriesColor(theme, 0) },
                    { key: "connsIdle", label: "простаивают", color: seriesColor(theme, 2) },
                    { key: "connsIdleTx", label: "простой в транзакции", color: theme.danger },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Долгие операции"
                hint="«Простой в транзакции» — открытая транзакция без работы: держит блокировки и тормозит очистку">
                <TimeChart theme={theme} points={pts} format="sec" height={130}
                  series={[
                    { key: "longestQuery", label: "запрос", color: tk(theme, 0) },
                    { key: "longestTx", label: "транзакция", color: seriesColor(theme, 1) },
                    { key: "idleInTx", label: "простой в транзакции", color: theme.danger },
                  ]} />
              </Panel>

              <Panel theme={theme} title="Строки, блокировки, ошибки">
                <TimeChart theme={theme} points={pts} format="rps" height={130}
                  series={[
                    { key: "tupReturned", label: "просмотрено строк", color: tk(theme, 0) },
                    { key: "tupFetched", label: "возвращено строк", color: seriesColor(theme, 2) },
                    { key: "locksWaiting", label: "блокировок в ожидании", color: theme.warning },
                    { key: "dbErrors", label: "ошибок/с", color: theme.danger },
                  ]} />
              </Panel>
            </div>

            <div className="mt-2">
              <Panel theme={theme} title="Таблицы"
                hint="Высокая доля мёртвых строк вместе со старой очисткой — автоочистка не справляется">
                <Table theme={theme}
                  cols={[
                    { k: "table", label: "Таблица", grow: true },
                    { k: "sizeBytes", label: "Размер", num: true, bar: true, fmt: fmtBytes },
                    { k: "liveRows", label: "Живых строк", num: true, fmt: (v) => fmtNum(v, 0) },
                    { k: "deadRows", label: "Мёртвых", num: true, fmt: (v) => fmtNum(v, 0) },
                    { k: "deadShare", label: "Мёртвых, %", num: true, fmt: (v) => fmtPct(v),
                      color: (v) => (v >= 20 ? theme.danger : v >= 10 ? theme.warning : undefined) },
                    { k: "vacuumAge", label: "Очистка была", num: true, fmt: (v) => (v > 0 ? fmtDur(v) + " назад" : "—"),
                      color: (v) => (v > 604800 ? theme.danger : v > 259200 ? theme.warning : undefined) },
                    { k: "seqScans", label: "Полных чтений", num: true, fmt: (v) => fmtNum(v, 0) },
                    { k: "idxScans", label: "По индексу", num: true, fmt: (v) => fmtNum(v, 0) },
                  ]}
                  rows={data.tables} keyOf={(r) => r.table} sort="sizeBytes"
                  empty="Статистика по таблицам пока не снята" />
              </Panel>
            </div>
          </Section>

          {/* Блок: объём системы и события */}
          <Section theme={theme} title="Объём системы и события" icon={Layers}
            open={open.objects} onToggle={() => setOpen((o) => ({ ...o, objects: !o.objects }))}>
            <div className="grid lg:grid-cols-3 gap-2">
              <Panel theme={theme} title="Объекты в системе" className="lg:col-span-2"
                hint="Снимается с базы раз в 15 секунд">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-1.5">
                  {ENTITY_ORDER.filter((k) => ent[k] != null).map((k) => (
                    <div key={k} className="flex items-baseline justify-between gap-2">
                      <span style={{ color: theme.textMuted }} className="text-[13px] truncate">
                        {ENTITY_LABELS[k] || k}
                      </span>
                      <b style={{ color: theme.text, fontVariantNumeric: "tabular-nums" }}
                        className="text-[14px] shrink-0">{fmtNum(ent[k], 0)}</b>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel theme={theme} title="Реальное время">
                <TimeChart theme={theme} points={pts} format="num" height={120}
                  series={[
                    { key: "wsConns", label: "соединений", color: tk(theme, 0) },
                    { key: "wsUsers", label: "пользователей", color: seriesColor(theme, 2) },
                    { key: "wsEvents", label: "событий/с", color: seriesColor(theme, 1) },
                  ]} />
              </Panel>
            </div>

            <div className="grid lg:grid-cols-3 gap-2 mt-2">
              <Panel theme={theme} title="События WebSocket за всё время"
                hint="По типам: какие изменения расходятся по участникам чаще других">
                <Bars theme={theme} data={data.wsKinds} empty="Событий ещё не было" />
              </Panel>
              <Panel theme={theme} title="Прикладные события">
                <Bars theme={theme} data={data.events} empty="Событий ещё не было" />
              </Panel>
              <Panel theme={theme} title="Коды ответа за всё время">
                <Bars theme={theme} data={data.statuses} empty="Запросов ещё не было"
                  colorOf={(k) => (k.startsWith("5") ? theme.danger
                    : k.startsWith("4") ? theme.warning
                    : k.startsWith("2") ? theme.success : seriesColor(theme, 0))} />
              </Panel>
            </div>
          </Section>

          <p style={{ color: theme.textMuted }} className="text-[12px] mt-4 leading-relaxed">
            Показания берутся из того же <span className="mono">/metrics</span>, который
            забирает Prometheus, и считаются теми же правилами: скорость — приростом
            счётчика за шаг, перцентили — по кумулятивной гистограмме. История живёт в
            памяти приложения (шаг {fmtNum(data.sampleStep, 0)} с, до шести часов) и
            не сохраняется между перезапусками. Для длинной истории, оповещений и
            сопоставления с другими системами рядом по-прежнему работает связка
            Prometheus + Grafana — см. <span className="mono">deploy/monitoring</span>.
          </p>
        </>
      )}
    </div>
  );
}

/* Раздел: панели. */
/* Компонент Section предназначен для сворачиваемого раздела с заголовком. */

function Section({ theme, title, icon: Icon, open, onToggle, children }) {
  return (
    <div className="mb-4">
      <button onClick={onToggle} style={{ color: theme.text }} aria-expanded={open}
        className="flex items-center gap-2 mb-2.5 text-[17px] font-semibold rounded-full pr-2">
        {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        {Icon && <Icon size={16} style={{ color: theme.accent }} />}
        {title}
      </button>
      {open && children}
    </div>
  );
}

// Компонент Panel предназначен для панели с заголовком и подсказкой.
function Panel({ theme, title, hint, children, className = "" }) {
  return (
    <div className={`glass-pane p-4 min-w-0 ${className}`}>
      <div className="flex items-start gap-1.5 mb-3">
        <h4 style={{ color: theme.text }} className="text-[15px] font-semibold leading-tight">
          {title}
        </h4>
      </div>
      {children}
      {hint && (
        <p style={{ color: theme.textMuted }} className="text-[12px] mt-2 leading-snug">
          {hint}
        </p>
      )}
    </div>
  );
}

// Компонент Stat предназначен для плитки с числом: подпись, значение и спарклайн на фоне.
function Stat({ theme, label, value, points, field, color, icon: Icon, hint }) {
  return (
    <div className="glass stat-pill !min-w-0 !rounded-[18px] relative overflow-hidden" title={hint || label}>
      <div className="stat-label flex items-center gap-1 truncate">
        {Icon && <Icon size={12} className="shrink-0" />} <span className="truncate">{label}</span>
      </div>
      <div style={{ color }} className="stat-value truncate">
        {value}
      </div>
      {points && field && (
        <div className="absolute left-0 right-0 bottom-0 opacity-60 pointer-events-none">
          <Sparkline points={points} field={field} color={color} height={18} />
        </div>
      )}
    </div>
  );
}

/* Раздел: таблица. */

// Компонент Table предназначен для таблицы с сортировкой по любому столбцу и полосой в числовой ячейке;
// служит заменой графику для пользователей, которым график недоступен.
function Table({ theme, cols, rows, keyOf, sort, empty }) {
  const [by, setBy] = useState(sort);
  const [desc, setDesc] = useState(true);

  const sorted = useMemo(() => {
    const list = [...(rows || [])];
    if (!by) return list;
    return list.sort((a, b) => {
      const x = a[by];
      const y = b[by];
      const cmp = typeof x === "number" && typeof y === "number"
        ? x - y
        : String(x || "").localeCompare(String(y || ""));
      return desc ? -cmp : cmp;
    });
  }, [rows, by, desc]);

  const maxOf = useMemo(() => {
    const m = {};
    for (const c of cols) {
      if (!c.bar) continue;
      m[c.k] = Math.max(1e-9, ...(rows || []).map((r) => Number(r[c.k]) || 0));
    }
    return m;
  }, [cols, rows]);

  if (!rows || rows.length === 0) {
    return <p style={{ color: theme.textMuted }} className="text-[13px] py-2">{empty}</p>;
  }

  return (
    <div className="overflow-x-auto -mx-1">
      <table className="w-full text-[13px]" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr>
            {cols.map((c) => (
              <th key={c.k} onClick={() => {
                if (by === c.k) setDesc((v) => !v); else { setBy(c.k); setDesc(true); }
              }}
                style={{ color: theme.textMuted, borderBottom: `1px solid ${theme.border}` }}
                className={`px-2 py-1.5 font-medium text-[12px] cursor-pointer select-none
                  ${c.num ? "text-right" : "text-left"} ${c.grow ? "w-full" : "whitespace-nowrap"}`}>
                {c.label}{by === c.k ? (desc ? " ↓" : " ↑") : ""}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sorted.slice(0, 40).map((r, i) => (
            <tr key={keyOf(r, i)}>
              {cols.map((c) => {
                const v = r[c.k];
                const text = c.render ? c.render(r) : c.fmt ? c.fmt(v) : String(v ?? "—");
                const col = c.color ? c.color(v) : undefined;
                const share = c.bar ? (Number(v) || 0) / maxOf[c.k] : 0;
                return (
                  <td key={c.k}
                    style={{
                      color: col || theme.text,
                      borderBottom: `1px solid ${theme.border}`,
                      fontVariantNumeric: c.num ? "tabular-nums" : undefined,
                      // Полоса отображается фоном ячейки, отдельный столбец не нужен.
                      background: c.bar
                        ? `linear-gradient(to right, ${theme.accent}22 ${share * 100}%, transparent ${share * 100}%)`
                        : undefined,
                    }}
                    className={`px-2 py-1.5 ${c.num ? "text-right whitespace-nowrap" : ""} ${c.grow ? "max-w-0" : ""}`}>
                    {text}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {sorted.length > 40 && (
        <p style={{ color: theme.textMuted }} className="text-[12px] mt-1">
          Показаны 40 строк из {sorted.length}.
        </p>
      )}
    </div>
  );
}

// Компонент Bars предназначен для горизонтальных полос разбивки по типам: порядок по величине, цвет не кодирует значение.
function Bars({ theme, data, empty, colorOf }) {
  const rows = Object.entries(data || {})
    .filter(([, v]) => v > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12);
  if (rows.length === 0) {
    return <p style={{ color: theme.textMuted }} className="text-[13px] py-2">{empty}</p>;
  }
  const max = Math.max(...rows.map(([, v]) => v));
  return (
    <div className="space-y-1">
      {rows.map(([k, v], i) => (
        <div key={k} className="flex items-center gap-2">
          <span style={{ color: theme.textMuted }} className="text-[12px] w-[42%] truncate" title={k}>
            {k}
          </span>
          <span className="flex-1 h-[6px] rounded-full overflow-hidden"
            style={{ background: theme.surfaceAlt }}>
            <span className="block h-full rounded-full"
              style={{
                width: `${(v / max) * 100}%`,
                background: colorOf ? colorOf(k) : seriesColor(theme, i),
              }} />
          </span>
          <b style={{ color: theme.text, fontVariantNumeric: "tabular-nums" }}
            className="text-[12px] w-[52px] text-right">{fmtNum(v, 0)}</b>
        </div>
      ))}
    </div>
  );
}
