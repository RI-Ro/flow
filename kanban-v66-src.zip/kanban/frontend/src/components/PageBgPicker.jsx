import React, { useRef, useState } from "react";
import { Upload, ImageOff } from "lucide-react";
import { api } from "../lib/api.js";
import { ALL_BACKGROUNDS, bgThumbUrl } from "../lib/theme.js";
import { Toggle } from "../lib/ui.jsx";

// Компонент PageBgPicker предназначен для выбора общего фона всех страниц: готовые изображения, размытие и собственное
// изображение. Фон проекта, если он задан, перекрывает общий фон на странице этого проекта.
export default function PageBgPicker({ theme, value, onChange }) {
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const set = (patch) => onChange({ ...value, ...patch });

  const upload = async (file) => {
    if (!file) return;
    setBusy(true); setErr("");
    try {
      const r = await api.uploadPageBackground(file);
      onChange({ ...value, preset: "custom", fileId: r.fileId, stamp: Date.now() });
    } catch (e) { setErr(e.message || "Не удалось загрузить изображение"); }
    setBusy(false);
  };
  const drop = async () => {
    try { await api.deletePageBackground(); } catch { /* файл уже удалён */ }
    onChange({ ...value, preset: value.preset === "custom" ? "none" : value.preset, fileId: "", stamp: Date.now() });
  };

  return (
    <div className="px-3 pb-2">
      <div className="text-[12px] font-medium mb-1.5" style={{ color: theme.textMuted }}>Фон всех страниц</div>
      <div className="grid grid-cols-4 gap-1.5 max-h-40 overflow-y-auto pr-0.5">
        {ALL_BACKGROUNDS.map((p) => {
          const thumb = bgThumbUrl(p.id);
          return (
            <button key={p.id} onClick={() => set({ preset: p.id })} title={p.label} aria-pressed={value.preset === p.id}
              style={{
                background: thumb ? `url(${thumb}) center/cover` : p.css || theme.surfaceAlt,
                backgroundSize: thumb ? "cover" : p.size || "cover",
                border: `2px solid ${value.preset === p.id ? theme.accent : theme.border}`,
              }}
              className="h-9 rounded-lg" />
          );
        })}
      </div>
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
      <div className="flex items-center gap-1.5 mt-2">
        {value.fileId && (
          <button onClick={() => set({ preset: "custom" })} title="Использовать своё изображение" aria-label="Использовать своё изображение"
            style={{ backgroundImage: `url(${api.pageBackgroundUrl(value.stamp)})`, border: `2px solid ${value.preset === "custom" ? theme.accent : theme.border}` }}
            className="w-12 h-9 rounded-lg bg-cover bg-center shrink-0" />
        )}
        <button onClick={() => fileRef.current?.click()} disabled={busy} style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
          className="flex-1 flex items-center justify-center gap-1.5 text-[12px] font-medium rounded-lg h-9 disabled:opacity-50">
          <Upload size={13} /> {busy ? "Загружаем…" : value.fileId ? "Заменить" : "Своё изображение"}
        </button>
        {value.fileId && (
          <button onClick={drop} className="btn-icon" style={{ color: theme.danger }} title="Убрать своё изображение" aria-label="Убрать своё изображение"><ImageOff size={15} /></button>
        )}
        {value.preset && value.preset !== "none" && !value.fileId && (
          <button onClick={() => set({ preset: "none" })} className="text-[12px] underline underline-offset-2 shrink-0" style={{ color: theme.textMuted }}>Убрать</button>
        )}
      </div>
      <div className="mt-2"><Toggle theme={theme} checked={!!value.blur} onChange={(b) => set({ blur: b })} label="Размыть фон" /></div>
      {err && <div className="text-[12px] mt-1" style={{ color: theme.danger }}>{err}</div>}
    </div>
  );
}
