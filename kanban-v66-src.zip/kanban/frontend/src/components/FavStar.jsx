import React, { useEffect, useState } from "react";
import { Star } from "lucide-react";
import { api } from "../lib/api.js";

// Компонент FavStar предназначен для отметки задачи «избранной» (🌟) текущим пользователем: нажатие переключает отметку,
// состояние меняется сразу, а при ошибке сервера возвращается назад.
export default function FavStar({ theme, task, size = 16, onChange, onError }) {
  const [on, setOn] = useState(Boolean(task.favorite));
  useEffect(() => { setOn(Boolean(task.favorite)); }, [task.id, task.favorite]);
  const toggle = async (e) => {
    e.stopPropagation();
    const next = !on;
    setOn(next);
    try {
      await api.setFavorite(task.id, next);
      onChange?.(task.id, next);
    } catch (err) {
      setOn(!next);
      onError?.(err.message);
    }
  };
  return (
    <button type="button" onClick={toggle} aria-pressed={on}
      title={on ? "Убрать из избранных" : "Добавить в избранные"}
      aria-label={on ? "Убрать из избранных" : "Добавить в избранные"}
      className="inline-flex items-center justify-center shrink-0 w-7 h-7 rounded-full transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
      <Star size={size} style={{ color: on ? "#f5b301" : theme.textMuted, opacity: on ? 1 : 0.55 }}
        fill={on ? "#f5b301" : "none"} />
    </button>
  );
}
