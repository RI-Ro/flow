-- Скрипт предназначен для ответов на сообщения в личных и групповых чатах (как в Telegram): сообщение хранит ссылку
-- на сообщение, на которое отвечает. При удалении исходного сообщения из БД ссылка обнуляется, при мягком удалении
-- цитата показывается как «Сообщение удалено».
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0031_chat_replies.sql
--
-- Выполняется от app_owner после 0030_access_matrix.sql, идемпотентен.

ALTER TABLE app.chat_messages
    ADD COLUMN IF NOT EXISTS reply_to_id uuid REFERENCES app.chat_messages(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS chat_messages_reply_idx ON app.chat_messages (reply_to_id) WHERE reply_to_id IS NOT NULL;
