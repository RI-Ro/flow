-- Скрипт предназначен для журнала сработавших напоминаний: окно напоминания показывается не только тем, кто был в сети в момент
-- срабатывания, но и при первом входе после неактивности (отпуск, выходные), пока пользователь не закроет его явным действием.
--
-- Также исправлено накопление: повторяющееся напоминание, пропущенное на несколько периодов, срабатывает один раз
-- и переносится на ближайший будущий момент, а не по одному периоду за каждую минуту опроса.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0029_reminder_alerts.sql
--
-- Выполняется от app_owner после 0028_visibility_sets.sql, идемпотентен.

SET search_path = app, public;

-- Таблица app.reminder_alerts предназначена для хранения сработавших напоминаний до подтверждения пользователем.
CREATE TABLE IF NOT EXISTS app.reminder_alerts (
    id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    reminder_id uuid        REFERENCES app.reminders(id) ON DELETE SET NULL,
    title       text        NOT NULL,
    task_id     uuid        REFERENCES app.tasks(id) ON DELETE SET NULL,
    due_at      timestamptz NOT NULL,
    fired_at    timestamptz NOT NULL DEFAULT now(),
    acked_at    timestamptz
);
CREATE INDEX IF NOT EXISTS reminder_alerts_open_idx ON app.reminder_alerts (user_id, fired_at) WHERE acked_at IS NULL;
CREATE INDEX IF NOT EXISTS reminder_alerts_reminder_idx ON app.reminder_alerts (reminder_id) WHERE reminder_id IS NOT NULL;

ALTER TABLE app.reminder_alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS reminder_alerts_own ON app.reminder_alerts;
CREATE POLICY reminder_alerts_own ON app.reminder_alerts FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, UPDATE, DELETE ON app.reminder_alerts TO app_user;

-- Функция app.record_reminder_alert предназначена для записи сработавшего напоминания в журнал; вызывается фоновым опросом.
-- Возвращает идентификатор записи и момент, на который напоминание было назначено.
CREATE OR REPLACE FUNCTION app.record_reminder_alert(p_id uuid)
RETURNS TABLE (alert_id uuid, due_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE r app.reminders%ROWTYPE;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    -- Старые записи удаляются: подтверждённые через 30 суток, неподтверждённые через 90.
    DELETE FROM app.reminder_alerts a
     WHERE a.user_id = r.user_id
       AND ((a.acked_at IS NOT NULL AND a.acked_at < now() - interval '30 days')
         OR a.fired_at < now() - interval '90 days');
    RETURN QUERY
        INSERT INTO app.reminder_alerts (user_id, reminder_id, title, task_id, due_at)
        VALUES (r.user_id, r.id, r.title, r.task_id, r.remind_at)
        RETURNING id, reminder_alerts.due_at;
END $$;
REVOKE ALL ON FUNCTION app.record_reminder_alert(uuid) FROM PUBLIC;

-- Функция app.advance_reminder предназначена для переноса напоминания после срабатывания. Повторяющееся переносится
-- на ближайший момент в будущем (пропущенные периоды не срабатывают по одному), однократное отключается.
CREATE OR REPLACE FUNCTION app.advance_reminder(p_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r app.reminders%ROWTYPE;
    v_next timestamptz;
    v_guard int := 0;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    IF r.recur_freq = 'none' THEN
        UPDATE app.reminders SET active = false, last_fired = now() WHERE id = p_id;
    ELSE
        v_next := app.next_reminder_at(r.remind_at, r.recur_freq, r.recur_interval, r.recur_weekdays);
        WHILE v_next <= now() AND v_guard < 2000 LOOP
            v_next := app.next_reminder_at(v_next, r.recur_freq, r.recur_interval, r.recur_weekdays);
            v_guard := v_guard + 1;
        END LOOP;
        UPDATE app.reminders SET last_fired = now(), remind_at = v_next WHERE id = p_id;
    END IF;
END $$;
