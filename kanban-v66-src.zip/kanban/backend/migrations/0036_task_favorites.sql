-- Скрипт предназначен для избранных задач (🌟): у каждого пользователя собственный список.
-- Отметка хранится независимо от состояния задачи: закрытая задача из списка избранных скрывается запросом,
-- но отметка не снимается и вернётся при повторном открытии задачи.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0036_task_favorites.sql
--
-- Выполняется от app_owner после 0035_chat_reactions_forward.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.task_favorites (
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    task_id    uuid        NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, task_id)
);
CREATE INDEX IF NOT EXISTS task_favorites_task_idx ON app.task_favorites (task_id);

ALTER TABLE app.task_favorites ENABLE ROW LEVEL SECURITY;

-- Видна и меняется только собственная отметка; добавить можно только задачу, которую пользователь видит.
DROP POLICY IF EXISTS task_favorites_select ON app.task_favorites;
CREATE POLICY task_favorites_select ON app.task_favorites FOR SELECT
    USING (user_id = app.current_user_id());
DROP POLICY IF EXISTS task_favorites_insert ON app.task_favorites;
CREATE POLICY task_favorites_insert ON app.task_favorites FOR INSERT
    WITH CHECK (user_id = app.current_user_id()
                AND EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_id));
DROP POLICY IF EXISTS task_favorites_delete ON app.task_favorites;
CREATE POLICY task_favorites_delete ON app.task_favorites FOR DELETE
    USING (user_id = app.current_user_id());
GRANT SELECT, INSERT, DELETE ON app.task_favorites TO app_user;
