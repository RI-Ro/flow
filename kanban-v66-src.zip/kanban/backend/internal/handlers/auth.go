// Модуль предназначен для регистрации, входа, обновления и завершения сессий и выпуска пары токенов.

package handlers

import (
	"errors"
	"context"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// Тип credentials предназначен для разбора тела запросов входа и регистрации.
type credentials struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	FullName string `json:"fullName,omitempty"`
	Position string `json:"position,omitempty"`
	Phone    string `json:"phone,omitempty"`
}

// Тип tokenPair предназначен для описания ответа с access- и refresh-токенами и данными пользователя.
type tokenPair struct {
	AccessToken  string      `json:"accessToken"`
	RefreshToken string      `json:"refreshToken"`
	ExpiresIn    int         `json:"expiresIn"`
	User         models.User `json:"user"`
}

const avatarPalette = "#3D5A80,#E8734A,#6B9B54,#8B6BB1,#3D9B94,#C25450,#A87C3D,#4A6B8A"

// Метод Register предназначен для регистрации пользователя; при пустой БД первая регистрация даёт права администратора.
func (s *Server) Register(c *fiber.Ctx) error {
	if !s.cfg.PasswordLogin {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "password_login_disabled", "Вход по паролю отключён"))
	}
	var in credentials
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	in.Email = strings.TrimSpace(strings.ToLower(in.Email))
	in.FullName = strings.TrimSpace(in.FullName)

	if !strings.Contains(in.Email, "@") || in.FullName == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input",
			"Нужны корректный адрес почты и имя"))
	}
	// Проверка пароля по общему правилу (internal/auth).
	if e := auth.ValidatePassword(in.Password); e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "weak_password", e.Error()))
	}

	// Самостоятельная регистрация разрешена конфигурацией; на пустой БД она разрешена всегда.
	var firstUser bool
	if err := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT NOT EXISTS (SELECT 1 FROM app.users WHERE deleted_at IS NULL)`).Scan(&firstUser)
	}); err != nil {
		return httpx.Fail(c, err)
	}
	if !firstUser && !s.cfg.AllowSelfRegistration {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "registration_closed",
			"Регистрация закрыта — учётную запись создаёт администратор"))
	}

	hash, err := auth.HashPassword(in.Password)
	if err != nil {
		return httpx.Fail(c, err)
	}

	colors := strings.Split(avatarPalette, ",")
	color := colors[int(uuid.New().ID())%len(colors)]

	role := "member"
	if firstUser {
		role = "admin"
	}

	var userID uuid.UUID
	err = s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO app.users (email, password_hash, full_name, position, phone,
			                       avatar_color, role)
			VALUES ($1, $2, $3, $4, $5, $6, $7::app.system_role) RETURNING id`,
			in.Email, hash, in.FullName, in.Position, in.Phone, color, role).Scan(&userID)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return s.issue(c, userID)
}

// Метод Login предназначен для проверки учётных данных и выдачи токенов.
func (s *Server) Login(c *fiber.Ctx) error {
	if !s.cfg.PasswordLogin {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "password_login_disabled",
			"Вход по паролю отключён — используйте вход через Kerberos"))
	}
	var in credentials
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}

	var (
		userID   uuid.UUID
		hash     string
		isActive bool
		role     string
	)
	err := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT id, password_hash, is_active, role FROM app.authenticate($1)`,
			strings.TrimSpace(strings.ToLower(in.Email))).Scan(&userID, &hash, &isActive, &role)
	})

	// Пароль сверяется и при отсутствии пользователя, чтобы время ответа не выдавало существование адреса.
	if err != nil {
		auth.CheckPassword("$2a$12$0000000000000000000000000000000000000000000000000000", in.Password)
		return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "bad_credentials", "Неверная почта или пароль"))
	}
	if !auth.CheckPassword(hash, in.Password) || !isActive {
		return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "bad_credentials", "Неверная почта или пароль"))
	}

	// Сведения пользователя, хранимые в LDAP, актуализируются при каждой авторизации.
	if err := s.refreshFromLDAP(c.Context(), userID); err != nil {
		return httpx.Fail(c, err)
	}
	return s.issue(c, userID)
}

// Тип refreshRequest предназначен для разбора тела запроса обновления токена.
type refreshRequest struct {
	RefreshToken string `json:"refreshToken"`
}

// Метод Refresh предназначен для обмена refresh-токена на новую пару с ротацией. Повторное предъявление
// погашенного токена признаётся компрометацией, и всё семейство токенов отзывается.
func (s *Server) Refresh(c *fiber.Ctx) error {
	var in refreshRequest
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.RefreshToken == "" {
		return httpx.Fail(c, httpx.ErrUnauthorized)
	}

	hash := auth.HashRefresh(in.RefreshToken)

	var (
		userID    uuid.UUID
		familyID  uuid.UUID
		expiresAt time.Time
		revokedAt *time.Time
	)
	err := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT user_id, family_id, expires_at, revoked_at
			  FROM app.refresh_tokens WHERE token_hash = $1`, hash).
			Scan(&userID, &familyID, &expiresAt, &revokedAt)
	})
	if err != nil {
		// Отсутствие токена — окончательный отказ; сбой базы данных — временная ошибка, сессия при этом не теряется.
		if errors.Is(err, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "bad_refresh", "Сессия недействительна"))
		}
		return httpx.Fail(c, httpx.Err(fiber.StatusServiceUnavailable, "unavailable", "Сервер временно недоступен"))
	}

	if revokedAt != nil {
		// Токен уже обменян. Повторное предъявление в пределах окна допуска — обычное следствие гонки двух вкладок
		// или потерянного ответа сервера, а не кража: сессия продолжается, если в семействе есть действующий токен.
		// Если действующих токенов нет (выход, смена пароля, блокировка), семейство считается завершённым.
		grace := s.cfg.RefreshReuseGrace
		recent := grace > 0 && time.Since(*revokedAt) <= grace
		alive := false
		if recent {
			_ = s.db.AsService(c.Context(), func(tx pgx.Tx) error {
				return tx.QueryRow(c.Context(), `
					SELECT EXISTS (SELECT 1 FROM app.refresh_tokens
					                WHERE family_id = $1 AND revoked_at IS NULL AND expires_at > now())`, familyID).Scan(&alive)
			})
		}
		if !alive {
			return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "token_reuse",
				"Сессия завершена, войдите заново"))
		}
	}
	if time.Now().After(expiresAt) {
		return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "bad_refresh", "Сессия истекла"))
	}

	// Состояние учётной записи проверяется при обновлении, так как выданный access-токен отозвать нельзя.
	var (
		accActive  bool
		accDeleted bool
		accRole    string
	)
	if e := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT is_active, deleted, role FROM app.account_state($1)`, userID).
			Scan(&accActive, &accDeleted, &accRole)
	}); e != nil {
		if errors.Is(e, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "bad_refresh", "Сессия недействительна"))
		}
		return httpx.Fail(c, httpx.Err(fiber.StatusServiceUnavailable, "unavailable", "Сервер временно недоступен"))
	}
	if accDeleted || !accActive {
		// Семейство токенов заблокированной учётной записи отзывается.
		_ = s.db.AsService(c.Context(), func(tx pgx.Tx) error {
			_, e := tx.Exec(c.Context(), `SELECT app.revoke_user_sessions($1)`, userID)
			return e
		})
		return httpx.Fail(c, httpx.Err(fiber.StatusUnauthorized, "account_disabled",
			"Учётная запись отключена — обратитесь к администратору"))
	}

	raw, newHash, err := auth.NewRefreshToken()
	if err != nil {
		return httpx.Fail(c, err)
	}

	err = s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.refresh_tokens SET revoked_at = COALESCE(revoked_at, now()) WHERE token_hash = $1`, hash); e != nil {
			return e
		}
		// Старые обменянные и просроченные токены семейства удаляются, чтобы таблица не росла.
		if _, e := tx.Exec(c.Context(), `
			DELETE FROM app.refresh_tokens
			 WHERE family_id = $1 AND (expires_at < now() OR revoked_at < now() - make_interval(secs => $2))`,
			familyID, (2 * s.cfg.RefreshReuseGrace).Seconds()); e != nil {
			return e
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.refresh_tokens (user_id, token_hash, family_id, expires_at, user_agent)
			VALUES ($1, $2, $3, $4, $5)`,
			userID, newHash, familyID, time.Now().Add(s.auth.RefreshTTL()), c.Get("User-Agent"))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	access, err := s.auth.IssueAccess(userID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	user, err := s.loadUser(c.Context(), userID)
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, tokenPair{
		AccessToken:  access,
		RefreshToken: raw,
		ExpiresIn:    int(s.auth.AccessTTL().Seconds()),
		User:         user,
	})
}

// Метод Logout предназначен для завершения сессии отзывом refresh-токена.
func (s *Server) Logout(c *fiber.Ctx) error {
	var in refreshRequest
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.NoContent(c)
	}
	if in.RefreshToken != "" {
		_ = s.db.AsService(c.Context(), func(tx pgx.Tx) error {
			_, e := tx.Exec(c.Context(), `
				UPDATE app.refresh_tokens SET revoked_at = now()
				 WHERE family_id = (SELECT family_id FROM app.refresh_tokens WHERE token_hash = $1)
				   AND revoked_at IS NULL`, auth.HashRefresh(in.RefreshToken))
			return e
		})
	}
	return httpx.NoContent(c)
}

// Метод issue предназначен для выпуска пары токенов и сохранения хеша refresh-токена.
func (s *Server) issue(c *fiber.Ctx, userID uuid.UUID) error {
	pair, err := s.issueTokens(c.Context(), userID, c.Get("User-Agent"))
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, pair)
}

// Метод issueTokens предназначен для выпуска пары токенов без привязки к конкретному серверу HTTP: им пользуются
// вход по паролю и вход по Kerberos.
func (s *Server) issueTokens(ctx context.Context, userID uuid.UUID, userAgent string) (tokenPair, error) {
	access, err := s.auth.IssueAccess(userID)
	if err != nil {
		return tokenPair{}, err
	}
	raw, hash, err := auth.NewRefreshToken()
	if err != nil {
		return tokenPair{}, err
	}
	err = s.db.AsService(ctx, func(tx pgx.Tx) error {
		_, e := tx.Exec(ctx, `
			INSERT INTO app.refresh_tokens (user_id, token_hash, family_id, expires_at, user_agent)
			VALUES ($1, $2, gen_random_uuid(), $3, $4)`,
			userID, hash, time.Now().Add(s.auth.RefreshTTL()), userAgent)
		return e
	})
	if err != nil {
		return tokenPair{}, err
	}
	user, err := s.loadUser(ctx, userID)
	if err != nil {
		return tokenPair{}, err
	}
	return tokenPair{
		AccessToken:  access,
		RefreshToken: raw,
		ExpiresIn:    int(s.auth.AccessTTL().Seconds()),
		User:         user,
	}, nil
}

// Метод loadUser предназначен для загрузки пользователя по идентификатору.
func (s *Server) loadUser(ctx context.Context, id uuid.UUID) (models.User, error) {
	var u models.User
	var deletedAt *time.Time
	err := s.db.AsUser(ctx, id, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `
			SELECT id, email, full_name, position, phone, avatar_color,
			       is_active, deleted_at, role::text
			  FROM app.users WHERE id = $1`, id).
			Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone, &u.AvatarColor,
				&u.IsActive, &deletedAt, &u.Role)
	})
	u.Deleted = deletedAt != nil
	return u, err
}
