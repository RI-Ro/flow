// Модуль предназначен для общего фона страниц пользователя: загрузка собственного изображения, выдача и удаление.
// Выбор готового фона и размытие хранятся в настройке ui.pagebg ({preset, blur, fileId}); здесь — только файл.

package handlers

import (
	"encoding/json"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Тип pageBg предназначен для разбора настройки ui.pagebg.
type pageBg struct {
	Preset string `json:"preset"`
	Blur   bool   `json:"blur"`
	FileID string `json:"fileId,omitempty"`
}

// Метод loadPageBg предназначен для чтения настройки фона страниц текущего пользователя.
func (s *Server) loadPageBg(c *fiber.Ctx, tx pgx.Tx) (pageBg, error) {
	var raw []byte
	var v pageBg
	e := tx.QueryRow(c.Context(),
		`SELECT value FROM app.user_preferences WHERE user_id = $1 AND key = 'ui.pagebg'`, s.uid(c)).Scan(&raw)
	if e == pgx.ErrNoRows {
		return v, nil
	}
	if e != nil {
		return v, e
	}
	_ = json.Unmarshal(raw, &v)
	return v, nil
}

// Метод savePageBg предназначен для записи настройки фона страниц.
func (s *Server) savePageBg(c *fiber.Ctx, tx pgx.Tx, v pageBg) error {
	raw, _ := json.Marshal(v)
	_, e := tx.Exec(c.Context(), `
		INSERT INTO app.user_preferences (user_id, key, value) VALUES ($1, 'ui.pagebg', $2::jsonb)
		ON CONFLICT (user_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
		s.uid(c), string(raw))
	return e
}

// Метод UploadPageBackground предназначен для загрузки собственного изображения общего фона (POST /me/background).
func (s *Server) UploadPageBackground(c *fiber.Ctx) error {
	uid := s.uid(c)
	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	file, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer file.Close()
	stored, err := s.files.Save(file, header.Filename)
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", err.Error()))
	}
	if !strings.HasPrefix(stored.MIME, "image/") {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "not_an_image", "Фоном может быть только изображение"))
	}
	var fileID uuid.UUID
	var oldKey string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		cur, e := s.loadPageBg(c, tx)
		if e != nil {
			return e
		}
		if cur.FileID != "" {
			// Прежний файл удаляется вместе со строкой, чтобы не копились неиспользуемые изображения.
			if e := tx.QueryRow(c.Context(),
				`DELETE FROM app.files WHERE id = $1 AND owner_id = $2 RETURNING storage_key`, cur.FileID, uid).Scan(&oldKey); e != nil && e != pgx.ErrNoRows {
				return e
			}
		}
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
			VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
			uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).Scan(&fileID); e != nil {
			return e
		}
		cur.Preset, cur.FileID = "custom", fileID.String()
		return s.savePageBg(c, tx, cur)
	})
	if err != nil {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, err)
	}
	if oldKey != "" {
		_ = s.files.Delete(oldKey)
	}
	return httpx.JSON(c, fiber.StatusCreated, fiber.Map{"fileId": fileID})
}

// Метод GetPageBackground предназначен для выдачи собственного изображения общего фона (GET /me/background).
func (s *Server) GetPageBackground(c *fiber.Ctx) error {
	var key, mimeType, filename string
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		cur, e := s.loadPageBg(c, tx)
		if e != nil {
			return e
		}
		if cur.FileID == "" {
			return pgx.ErrNoRows
		}
		return tx.QueryRow(c.Context(),
			`SELECT storage_key, mime_type, filename FROM app.files WHERE id = $1 AND owner_id = $2`,
			cur.FileID, s.uid(c)).Scan(&key, &mimeType, &filename)
	})
	if err == pgx.ErrNoRows {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mimeType, filename, false)
}

// Метод DeletePageBackground предназначен для удаления собственного изображения общего фона (DELETE /me/background).
func (s *Server) DeletePageBackground(c *fiber.Ctx) error {
	var oldKey string
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		cur, e := s.loadPageBg(c, tx)
		if e != nil {
			return e
		}
		if cur.FileID != "" {
			if e := tx.QueryRow(c.Context(),
				`DELETE FROM app.files WHERE id = $1 AND owner_id = $2 RETURNING storage_key`, cur.FileID, s.uid(c)).Scan(&oldKey); e != nil && e != pgx.ErrNoRows {
				return e
			}
		}
		if cur.Preset == "custom" {
			cur.Preset = "none"
		}
		cur.FileID = ""
		return s.savePageBg(c, tx, cur)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if oldKey != "" {
		_ = s.files.Delete(oldKey)
	}
	return httpx.NoContent(c)
}
