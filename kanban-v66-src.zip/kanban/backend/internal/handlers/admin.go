// Модуль предназначен для администрирования учётных записей: проверка прав администратора, список, создание,
// изменение, смена пароля, удаление и восстановление пользователей.

package handlers

import (
	"errors"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/ldapsync"
	"github.com/example/kanban/internal/models"
)

// Метод RequireAdmin предназначен для middleware группы /api/admin: роль проверяется запросом к БД, а не по JWT,
// чтобы снятие прав вступало в силу немедленно.
func (s *Server) RequireAdmin(c *fiber.Ctx) error {
	uid := s.uid(c)
	var ok bool
	if err := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT app.is_admin($1)`, uid).Scan(&ok)
	}); err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		// Ответ 404 скрывает существование панели от пользователей без прав.
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	return c.Next()
}

// Метод AdminListUsers предназначен для получения списка учётных записей с числом активных сессий.
func (s *Server) AdminListUsers(c *fiber.Ctx) error {
	q := strings.TrimSpace(c.Query("q"))
	limit := httpx.QueryInt(c, "limit", 100, 1, 500)
	offset := httpx.QueryInt(c, "offset", 0, 0, 1000000)

	users := []models.User{}
	var total int

	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM app.users
			 WHERE ($1 = '' OR (full_name || ' ' || position || ' ' || phone) ILIKE '%' || $1 || '%'
			                OR email ILIKE '%' || $1 || '%' OR login ILIKE '%' || $1 || '%')`, q).Scan(&total); e != nil {
			return e
		}

		// Число сессий считается подзапросом с использованием индекса refresh_tokens_active_idx.
		rows, e := tx.Query(c.Context(), `
			SELECT u.id, u.email, u.full_name, u.position, u.phone, u.avatar_color,
			       u.is_active, u.deleted_at, u.role::text, u.created_at, u.login, u.source,
			       (SELECT count(*) FROM app.refresh_tokens r
			         WHERE r.user_id = u.id AND r.revoked_at IS NULL
			           AND r.expires_at > now())
			  FROM app.users u
			 WHERE ($1 = '' OR (u.full_name || ' ' || u.position || ' ' || u.phone) ILIKE '%' || $1 || '%'
			                OR u.email ILIKE '%' || $1 || '%' OR u.login ILIKE '%' || $1 || '%')
			 ORDER BY (u.deleted_at IS NOT NULL), u.full_name
			 LIMIT $2 OFFSET $3`, q, limit, offset)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var u models.User
			var deletedAt *time.Time
			var createdAt time.Time
			if e := rows.Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone,
				&u.AvatarColor, &u.IsActive, &deletedAt, &u.Role, &createdAt, &u.Login, &u.Source, &u.Sessions); e != nil {
				return e
			}
			u.Deleted = deletedAt != nil
			u.CreatedAt = &createdAt
			users = append(users, u)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"items": users, "total": total, "limit": limit, "offset": offset,
	})
}

// Тип adminUserCreate предназначен для разбора тела запроса создания пользователя.
type adminUserCreate struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	FullName string `json:"fullName"`
	Position string `json:"position"`
	Phone    string `json:"phone"`
	Role     string `json:"role"`
	Login    string `json:"login"`
	Source   string `json:"source"`
}

// Метод AdminCreateUser предназначен для создания пользователя администратором.
func (s *Server) AdminCreateUser(c *fiber.Ctx) error {
	var in adminUserCreate
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	in.Email = strings.TrimSpace(strings.ToLower(in.Email))
	in.FullName = strings.TrimSpace(in.FullName)
	in.Login = strings.TrimSpace(in.Login)
	in.Source = strings.TrimSpace(in.Source)
	if in.Source == "" {
		in.Source = "local"
	}
	if in.Source != "local" {
		if _, ok := ldapsync.Find(s.cfg.LDAPServers, in.Source); !ok {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_source", "Неизвестный источник сведений о пользователе"))
		}
		// Недостающие сведения подтягиваются из LDAP (анонимный запрос); ошибка связи не мешает создать пользователя,
		// если администратор заполнил поля вручную.
		if in.Login != "" {
			srv, _ := ldapsync.Find(s.cfg.LDAPServers, in.Source)
			if p, e := ldapsync.Lookup(c.Context(), srv, in.Login); e == nil {
				if in.FullName == "" {
					in.FullName = p.FullName
				}
				if in.Email == "" {
					in.Email = p.Email
				}
				if in.Position == "" {
					in.Position = p.Position
				}
				if in.Phone == "" {
					in.Phone = p.Phone
				}
			}
		}
	}
	if in.Login == "" && !s.cfg.PasswordLogin {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input",
			"Вход по паролю отключён — укажите логин для входа по Kerberos"))
	}

	if !strings.Contains(in.Email, "@") || in.FullName == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input",
			"Нужны корректный адрес почты и имя"))
	}
	// Для пользователей Kerberos/LDAP пароль не обязателен: если он не задан, ставится случайный (вход только по Kerberos).
	if in.Password == "" && in.Login != "" {
		in.Password = uuid.NewString() + "Aa1!"
	}
	if e := auth.ValidatePassword(in.Password); e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "weak_password", e.Error()))
	}
	if in.Role != "admin" {
		in.Role = "member"
	}

	hash, err := auth.HashPassword(in.Password)
	if err != nil {
		return httpx.Fail(c, err)
	}

	colors := strings.Split(avatarPalette, ",")
	color := colors[int(uuid.New().ID())%len(colors)]

	var u models.User
	var createdAt time.Time
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO app.users (email, password_hash, full_name, position, phone,
			                       avatar_color, role, login, source)
			VALUES ($1, $2, $3, $4, $5, $6, $7::app.system_role, $8, $9)
			RETURNING id, email, full_name, position, phone, avatar_color,
			          is_active, role::text, created_at, login, source`,
			in.Email, hash, in.FullName, in.Position, in.Phone, color, in.Role, in.Login, in.Source).
			Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone, &u.AvatarColor,
				&u.IsActive, &u.Role, &createdAt, &u.Login, &u.Source)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	u.CreatedAt = &createdAt
	return httpx.JSON(c, fiber.StatusCreated, u)
}

// Тип adminUserPatch предназначен для разбора тела запроса изменения пользователя.
type adminUserPatch struct {
	Email    *string `json:"email"`
	FullName *string `json:"fullName"`
	Position *string `json:"position"`
	Phone    *string `json:"phone"`
	Role     *string `json:"role"`
	IsActive *bool   `json:"isActive"`
	Login    *string `json:"login"`
	Source   *string `json:"source"`
}

// Метод AdminUpdateUser предназначен для изменения данных, роли и активности пользователя.
func (s *Server) AdminUpdateUser(c *fiber.Ctx) error {
	targetID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in adminUserPatch
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	actor := s.uid(c)

	if in.Role != nil && *in.Role != "admin" && *in.Role != "member" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_role", "Недопустимая роль"))
	}
	if in.Login != nil {
		t := strings.TrimSpace(*in.Login)
		in.Login = &t
	}
	if in.Source != nil {
		t := strings.TrimSpace(*in.Source)
		if t == "" {
			t = "local"
		}
		if t != "local" {
			if _, ok := ldapsync.Find(s.cfg.LDAPServers, t); !ok {
				return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_source", "Неизвестный источник сведений о пользователе"))
			}
		}
		in.Source = &t
	}
	if in.Email != nil {
		normalized := strings.TrimSpace(strings.ToLower(*in.Email))
		if !strings.Contains(normalized, "@") {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_email", "Некорректный адрес почты"))
		}
		in.Email = &normalized
	}

	// Снятие прав администратора и деактивация проверяются на сохранение хотя бы одного администратора.
	losingAdmin := (in.Role != nil && *in.Role == "member") ||
		(in.IsActive != nil && !*in.IsActive)

	var u models.User
	var deletedAt *time.Time
	var createdAt time.Time
	err = s.db.AsUser(c.Context(), actor, func(tx pgx.Tx) error {
		if losingAdmin {
			var others int
			if e := tx.QueryRow(c.Context(),
				`SELECT app.other_admins_count($1)`, targetID).Scan(&others); e != nil {
				return e
			}
			var targetIsAdmin bool
			if e := tx.QueryRow(c.Context(),
				`SELECT app.is_admin($1)`, targetID).Scan(&targetIsAdmin); e != nil {
				return e
			}
			if targetIsAdmin && others == 0 {
				return httpx.Err(fiber.StatusConflict, "last_admin",
					"Это последний администратор — сначала назначьте другого")
			}
		}

		if e := tx.QueryRow(c.Context(), `
			UPDATE app.users SET
				email     = COALESCE($2, email),
				full_name = COALESCE($3, full_name),
				position  = COALESCE($4, position),
				phone     = COALESCE($5, phone),
				role      = COALESCE($6::app.system_role, role),
				is_active = COALESCE($7, is_active),
				login     = COALESCE($8, login),
				source    = COALESCE($9, source)
			WHERE id = $1
			RETURNING id, email, full_name, position, phone, avatar_color,
			          is_active, deleted_at, role::text, created_at, login, source`,
			targetID, in.Email, in.FullName, in.Position, in.Phone, in.Role, in.IsActive, in.Login, in.Source).
			Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone, &u.AvatarColor,
				&u.IsActive, &deletedAt, &u.Role, &createdAt, &u.Login, &u.Source); e != nil {
			return e
		}

		// Деактивация прерывает все сессии пользователя.
		if in.IsActive != nil && !*in.IsActive {
			if _, e := tx.Exec(c.Context(), `SELECT app.revoke_user_sessions($1)`, targetID); e != nil {
				return e
			}
		}
		return nil
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	u.Deleted = deletedAt != nil
	u.CreatedAt = &createdAt

	if in.IsActive != nil && !*in.IsActive {
		s.hub.Disconnect(targetID)
	}
	return httpx.JSON(c, fiber.StatusOK, u)
}

// Тип adminPasswordReset предназначен для разбора тела запроса смены пароля.
type adminPasswordReset struct {
	NewPassword string `json:"newPassword"`
}

// Метод AdminResetPassword предназначен для принудительной смены пароля с завершением всех сессий пользователя.
func (s *Server) AdminResetPassword(c *fiber.Ctx) error {
	targetID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in adminPasswordReset
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if e := auth.ValidatePassword(in.NewPassword); e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "weak_password", e.Error()))
	}

	hash, err := auth.HashPassword(in.NewPassword)
	if err != nil {
		return httpx.Fail(c, err)
	}

	var affected int64
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(),
			`UPDATE app.users SET password_hash = $2 WHERE id = $1`, targetID, hash)
		if e != nil {
			return e
		}
		affected = tag.RowsAffected()
		if affected == 0 {
			return nil
		}
		_, e = tx.Exec(c.Context(), `SELECT app.revoke_user_sessions($1)`, targetID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	s.hub.Disconnect(targetID)
	return httpx.NoContent(c)
}

// Метод AdminDeleteUser предназначен для мягкого удаления пользователя со снятием доступа и передачей владения
// преемнику (поле successorId; без преемника при наличии владения — ответ 409 need_successor).
// Физическое удаление не выполняется: на пользователя ссылаются created_by в проектах, задачах и файлах.
func (s *Server) AdminDeleteUser(c *fiber.Ctx) error {
	targetID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	if targetID == s.uid(c) {
		return httpx.Fail(c, httpx.Err(fiber.StatusConflict, "self_delete",
			"Нельзя удалить собственную учётную запись"))
	}
	return s.offboard(c, targetID)
}

// Метод AdminRestoreUser предназначен для восстановления удалённой учётной записи. Доступ к проектам
// не восстанавливается и выдаётся повторно через панель «Доступы».
func (s *Server) AdminRestoreUser(c *fiber.Ctx) error {
	targetID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}

	var u models.User
	var deletedAt *time.Time
	var createdAt time.Time
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			UPDATE app.users SET deleted_at = NULL, is_active = true
			 WHERE id = $1 AND deleted_at IS NOT NULL
			RETURNING id, email, full_name, position, phone, avatar_color,
			          is_active, deleted_at, role::text, created_at`, targetID).
			Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone, &u.AvatarColor,
				&u.IsActive, &deletedAt, &u.Role, &createdAt)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	u.Deleted = deletedAt != nil
	u.CreatedAt = &createdAt
	return httpx.JSON(c, fiber.StatusOK, u)
}

// Метод AdminLDAPServers предназначен для списка настроенных LDAP-серверов (для выбора источника сведений о пользователе).
func (s *Server) AdminLDAPServers(c *fiber.Ctx) error {
	out := make([]fiber.Map, 0, len(s.cfg.LDAPServers))
	for _, sv := range s.cfg.LDAPServers {
		name := sv.Name
		if name == "" {
			name = sv.ID
		}
		out = append(out, fiber.Map{"id": sv.ID, "name": name, "url": sv.URL})
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Метод AdminLDAPCheck предназначен для проверки доступности сведений о пользователе в LDAP при его добавлении:
// анонимный запрос (как ldapsearch -x) и показ сопоставленных атрибутов (POST /admin/ldap/check {source, login}).
func (s *Server) AdminLDAPCheck(c *fiber.Ctx) error {
	var in struct {
		Source string `json:"source"`
		Login  string `json:"login"`
	}
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	srv, ok := ldapsync.Find(s.cfg.LDAPServers, strings.TrimSpace(in.Source))
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_source", "Выберите LDAP-сервер"))
	}
	p, err := ldapsync.Lookup(c.Context(), srv, in.Login)
	if err != nil {
		code := "ldap_error"
		if errors.Is(err, ldapsync.ErrNotFound) {
			code = "ldap_not_found"
		}
		return httpx.Fail(c, httpx.Err(fiber.StatusBadGateway, code, err.Error()))
	}
	return httpx.JSON(c, fiber.StatusOK, p)
}
