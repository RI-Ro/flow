// Модуль предназначен для выдачи администратору сведений о сервере: память, диски, нагрузка, процессор, версии.
// Данные читаются из /proc и файловой системы (Linux); на других системах недоступные поля остаются пустыми.

package handlers

import (
	"bufio"
	"os"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Момент запуска процесса для расчёта времени работы приложения.
var processStarted = time.Now()

// Тип diskInfo предназначен для описания одного тома: всего, занято и свободно в байтах.
type diskInfo struct {
	Name  string  `json:"name"`
	Path  string  `json:"path"`
	Total uint64  `json:"total"`
	Used  uint64  `json:"used"`
	Free  uint64  `json:"free"`
	Share float64 `json:"usedShare"`
}

// Функция readMeminfo предназначена для чтения /proc/meminfo; значения переводятся из килобайт в байты.
func readMeminfo() map[string]uint64 {
	out := map[string]uint64{}
	f, err := os.Open("/proc/meminfo")
	if err != nil {
		return out
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		parts := strings.Fields(sc.Text())
		if len(parts) < 2 {
			continue
		}
		v, err := strconv.ParseUint(parts[1], 10, 64)
		if err != nil {
			continue
		}
		out[strings.TrimSuffix(parts[0], ":")] = v * 1024
	}
	return out
}

// Функция statDisk предназначена для получения размера тома по пути.
func statDisk(name, path string) (diskInfo, bool) {
	var st syscall.Statfs_t
	if path == "" || syscall.Statfs(path, &st) != nil {
		return diskInfo{}, false
	}
	total := st.Blocks * uint64(st.Bsize)
	free := st.Bavail * uint64(st.Bsize)
	used := total - st.Bfree*uint64(st.Bsize)
	d := diskInfo{Name: name, Path: path, Total: total, Used: used, Free: free}
	if total > 0 {
		d.Share = float64(used) / float64(total)
	}
	return d, true
}

// Функция firstLine предназначена для чтения первой строки файла.
func firstLine(path string) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(strings.SplitN(string(b), "\n", 2)[0])
}

// Метод AdminHost предназначен для обработки запроса GET /admin/system/host: сведения о сервере для страницы состояния.
func (s *Server) AdminHost(c *fiber.Ctx) error {
	mem := readMeminfo()
	memTotal := mem["MemTotal"]
	memAvail := mem["MemAvailable"]
	if memAvail == 0 {
		memAvail = mem["MemFree"] + mem["Buffers"] + mem["Cached"]
	}
	memUsed := uint64(0)
	if memTotal > memAvail {
		memUsed = memTotal - memAvail
	}

	var disks []diskInfo
	seen := map[string]bool{}
	add := func(name, path string) {
		if d, ok := statDisk(name, path); ok && !seen[d.Path] {
			seen[d.Path] = true
			disks = append(disks, d)
		}
	}
	add("Файлы вложений", s.cfg.UploadDir)
	add("Приложение", ".")
	add("Корневой раздел", "/")
	add("Данные PostgreSQL", "/var/lib/postgresql")
	add("Временные файлы", os.TempDir())

	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	hostname, _ := os.Hostname()

	var load1, load5, load15 float64
	if f := strings.Fields(firstLine("/proc/loadavg")); len(f) >= 3 {
		load1, _ = strconv.ParseFloat(f[0], 64)
		load5, _ = strconv.ParseFloat(f[1], 64)
		load15, _ = strconv.ParseFloat(f[2], 64)
	}
	var uptime float64
	if f := strings.Fields(firstLine("/proc/uptime")); len(f) >= 1 {
		uptime, _ = strconv.ParseFloat(f[0], 64)
	}
	cpuModel := ""
	if b, err := os.ReadFile("/proc/cpuinfo"); err == nil {
		for _, ln := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(ln, "model name") {
				if i := strings.Index(ln, ":"); i >= 0 {
					cpuModel = strings.TrimSpace(ln[i+1:])
				}
				break
			}
		}
	}
	osName := ""
	if b, err := os.ReadFile("/etc/os-release"); err == nil {
		for _, ln := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(ln, "PRETTY_NAME=") {
				osName = strings.Trim(strings.TrimPrefix(ln, "PRETTY_NAME="), `"`)
			}
		}
	}

	// Сведения о базе данных: версия, размер, число соединений. Ошибки не прерывают ответ.
	db := fiber.Map{}
	_ = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		var version string
		if tx.QueryRow(c.Context(), `SHOW server_version`).Scan(&version) == nil {
			db["version"] = version
		}
		var size int64
		if tx.QueryRow(c.Context(), `SELECT pg_database_size(current_database())`).Scan(&size) == nil {
			db["sizeBytes"] = size
		}
		var conns int
		if tx.QueryRow(c.Context(), `SELECT count(*) FROM pg_stat_activity WHERE datname = current_database()`).Scan(&conns) == nil {
			db["connections"] = conns
		}
		return nil
	})
	// Объёмы данных; функция может отсутствовать в базе без миграции 0024/0037 — тогда блок пропускается.
	counts := fiber.Map{}
	if rows, err := s.db.Pool.Query(c.Context(), `SELECT kind, n FROM app.system_counts()`); err == nil {
		for rows.Next() {
			var k string
			var n int64
			if rows.Scan(&k, &n) == nil {
				counts[k] = n
			}
		}
		rows.Close()
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"time":     time.Now().UTC().Format(time.RFC3339),
		"hostname": hostname,
		"os":       osName,
		"kernel":   firstLine("/proc/sys/kernel/osrelease"),
		"arch":     runtime.GOARCH,
		"cpu":      fiber.Map{"model": cpuModel, "cores": runtime.NumCPU(), "load1": load1, "load5": load5, "load15": load15},
		"memory": fiber.Map{
			"total": memTotal, "used": memUsed, "free": mem["MemFree"], "available": memAvail,
			"cached": mem["Cached"], "swapTotal": mem["SwapTotal"], "swapFree": mem["SwapFree"],
		},
		"disks":         disks,
		"uptimeSeconds": uptime,
		"process": fiber.Map{
			"goVersion": runtime.Version(), "goroutines": runtime.NumGoroutine(),
			"heapBytes": ms.HeapAlloc, "sysBytes": ms.Sys, "startedAt": processStarted.UTC().Format(time.RFC3339),
			"uptimeSeconds": time.Since(processStarted).Seconds(),
		},
		"database": db,
		"counts":   counts,
	})
}
