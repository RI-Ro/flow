// Модуль предназначен для работы с напоминаниями («будильниками»), настройками категорий
// уведомлений и фоновым опросом сработавших напоминаний.

package handlers

import (
	"log/slog"
	"context"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)


type reminder struct {
	ID            uuid.UUID `json:"id"`
	Title         string    `json:"title"`
	RemindAt      string    `json:"remindAt"` // ISO datetime
	RecurFreq     string    `json:"recurFreq"`
	RecurInterval int       `json:"recurInterval"`
	RecurWeekdays []int     `json:"recurWeekdays"`
	Active        bool      `json:"active"`
	// Необязательная привязка напоминания к задаче.
	TaskID    *uuid.UUID `json:"taskId"`
	TaskTitle string     `json:"taskTitle"`
}

// Константа reminderTimeExpr задаёт SQL-выражение времени напоминания: UTC с суффиксом Z.
// Явная зона исключает зависимость результата от часового пояса сессии БД.
const reminderTimeExpr = `to_char(remind_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`

// Константа reminderCols задаёт список выбираемых столбцов напоминания.
// Название задачи возвращается через app.task_title_visible: недоступная задача заголовок не раскрывает.
const reminderCols = `id, title, ` + reminderTimeExpr + `,
	       recur_freq, recur_interval, recur_weekdays, active,
	       task_id, COALESCE(app.task_title_visible(task_id, user_id), '')`

const reminderSelect = `SELECT ` + reminderCols + ` FROM app.reminders`

// Функция scanReminder предназначена для чтения строки запроса в структуру reminder.
func scanReminder(row pgx.Row) (reminder, error) {
	var r reminder
	err := row.Scan(&r.ID, &r.Title, &r.RemindAt, &r.RecurFreq, &r.RecurInterval,
		&r.RecurWeekdays, &r.Active, &r.TaskID, &r.TaskTitle)
	return r, err
}

// Метод ListReminders предназначен для выдачи списка напоминаний текущего пользователя.
func (s *Server) ListReminders(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []reminder{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), reminderSelect+` WHERE user_id = $1 ORDER BY remind_at`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			r, e := scanReminder(rows)
			if e != nil {
				return e
			}
			out = append(out, r)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Тип reminderInput предназначен для разбора тела запросов создания и изменения напоминания.
type reminderInput struct {
	Title         string  `json:"title"`
	RemindAt      string  `json:"remindAt"`
	RecurFreq     string  `json:"recurFreq"`
	RecurInterval int     `json:"recurInterval"`
	RecurWeekdays []int   `json:"recurWeekdays"`
	Active        *bool   `json:"active"`
	// Привязка к задаче; отсутствие поля и null равнозначны («без задачи»).
	TaskID *uuid.UUID `json:"taskId"`
}

// Метод CreateReminder предназначен для создания напоминания.
func (s *Server) CreateReminder(c *fiber.Ctx) error {
	var in reminderInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Title == "" || in.RemindAt == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Укажите название и время напоминания"))
	}
	freq, interval, week := normalizeReminderRecur(in.RecurFreq, in.RecurInterval, in.RecurWeekdays)
	uid := s.uid(c)
	var r reminder
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			INSERT INTO app.reminders (user_id, title, remind_at, recur_freq, recur_interval,
			                           recur_weekdays, task_id)
			VALUES ($1, $2, $3::timestamptz, $4, $5, $6,
			        -- Привязать можно только видимую задачу: иначе по
			        -- ошибке или намеренно в напоминание попал бы чужой
			        -- идентификатор, а вместе с ним и название задачи.
			        (SELECT $7::uuid WHERE $7::uuid IS NULL
			              OR app.can_see_task($7::uuid, $1)))
			RETURNING ` + reminderCols,
			uid, in.Title, in.RemindAt, freq, interval, week, in.TaskID)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusCreated, r)
}

// Метод UpdateReminder предназначен для изменения напоминания, включая правило повторения.
func (s *Server) UpdateReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in reminderInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	freq, interval, week := normalizeReminderRecur(in.RecurFreq, in.RecurInterval, in.RecurWeekdays)
	active := true
	if in.Active != nil {
		active = *in.Active
	}
	uid := s.uid(c)
	var r reminder
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			UPDATE app.reminders
			   SET title = COALESCE(NULLIF($2,''), title),
			       remind_at = COALESCE(NULLIF($3,'')::timestamptz, remind_at),
			       recur_freq = $4, recur_interval = $5, recur_weekdays = $6, active = $7,
			       last_fired = CASE WHEN $3 <> '' THEN NULL ELSE last_fired END,
			       task_id = (SELECT $9::uuid WHERE $9::uuid IS NULL
			                       OR app.can_see_task($9::uuid, $8))
			 WHERE id = $1 AND user_id = $8
			 RETURNING ` + reminderCols,
			id, in.Title, in.RemindAt, freq, interval, week, active, uid, in.TaskID)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, r)
}

// Тип snoozeInput предназначен для разбора тела запроса переноса напоминания.
type snoozeInput struct {
	Minutes int `json:"minutes"`
}

// Метод SnoozeReminder предназначен для переноса напоминания на несколько минут вперёд.
// Отдельный маршрут, а не PATCH: PATCH переписывает правило повторения.
// Однократное напоминание при срабатывании отключается, поэтому перенос включает его
// и сбрасывает отметку о срабатывании. У повторяющегося перенос сдвигает и точку отсчёта.
func (s *Server) SnoozeReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in snoozeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Minutes < 1 || in.Minutes > 24*60 {
		in.Minutes = 5
	}
	uid := s.uid(c)

	var r reminder
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			UPDATE app.reminders
			   SET remind_at  = now() + ($2::int * interval '1 minute'),
			       active     = true,
			       last_fired = NULL
			 WHERE id = $1 AND user_id = $3
			 -- Набор колонок общий (reminderCols): в нём есть и
			 -- привязанная задача с названием. Раньше здесь был
			 -- укороченный список из семи колонок, а разбирал ответ
			 -- тот же scanReminder, ждущий девять, — и любая попытка
			 -- отложить напоминание падала с ошибкой.
			 RETURNING `+reminderCols,
			id, in.Minutes, uid)
		var e error
		r, e = scanReminder(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, r)
}

// Метод DeleteReminder предназначен для удаления напоминания.
func (s *Server) DeleteReminder(c *fiber.Ctx) error {
	id, err := param(c, "reminderID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `DELETE FROM app.reminders WHERE id = $1 AND user_id = $2`, id, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.NoContent(c)
}

// Функция normalizeReminderRecur предназначена для проверки и нормализации правила повторения.
func normalizeReminderRecur(freq string, interval int, week []int) (string, int, []int) {
	switch freq {
	case "daily", "weekly", "monthly":
	default:
		return "none", 1, []int{}
	}
	if interval < 1 {
		interval = 1
	}
	if week == nil || freq != "weekly" {
		week = []int{}
	}
	return freq, interval, week
}


func (s *Server) GetNotificationPrefs(c *fiber.Ctx) error {
	uid := s.uid(c)
	prefs := map[string]bool{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT category, enabled FROM app.notification_prefs WHERE user_id = $1`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var cat string
			var en bool
			if e := rows.Scan(&cat, &en); e != nil {
				return e
			}
			prefs[cat] = en
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, prefs)
}

// Тип prefInput предназначен для разбора тела запроса изменения настройки уведомлений.
type prefInput struct {
	Category string `json:"category"`
	Enabled  bool   `json:"enabled"`
}

// Метод SetNotificationPref предназначен для включения и отключения категории уведомлений.
func (s *Server) SetNotificationPref(c *fiber.Ctx) error {
	var in prefInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Category == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Не указана категория"))
	}
	uid := s.uid(c)
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.notification_prefs (user_id, category, enabled)
			VALUES ($1, $2, $3)
			ON CONFLICT (user_id, category) DO UPDATE SET enabled = EXCLUDED.enabled`,
			uid, in.Category, in.Enabled)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"category": in.Category, "enabled": in.Enabled})
}


// Метод StartReminderPoller предназначен для запуска фонового цикла: раз в минуту он находит
// сработавшие напоминания, создаёт уведомления и переносит повторяющиеся на следующий раз.
// Работает от системного пула без RLS, пишет через app.notify_cat.
func (s *Server) StartReminderPoller(ctx context.Context, pool *pgxpool.Pool) {
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				// Опрос выполняет один экземпляр: берётся рекомендательная блокировка Postgres.
				// Блокировка берётся и снимается на каждом обороте, чтобы при отказе экземпляра работу подхватил следующий.
				if s.tryReminderLock(ctx, pool) {
					s.fireDueReminders(ctx, pool)
					s.releaseReminderLock(ctx, pool)
				}
			}
		}
	}()
}

// Метод fireDueReminders предназначен для обработки сработавших напоминаний за один оборот опроса.
func (s *Server) fireDueReminders(ctx context.Context, pool *pgxpool.Pool) {
	// app.due_reminders выполняется с SECURITY DEFINER и обходит RLS.
	rows, err := pool.Query(ctx, `SELECT * FROM app.due_reminders()`)
	if err != nil {
		return
	}
	type due struct {
		id, user    uuid.UUID
		title, freq string
		interval    int
		weekdays    []int
		task        *uuid.UUID
	}
	var list []due
	for rows.Next() {
		var d due
		if e := rows.Scan(&d.id, &d.user, &d.title, &d.freq, &d.interval, &d.weekdays, &d.task); e != nil {
			continue
		}
		list = append(list, d)
	}
	rows.Close()

	for _, d := range list {
		var nid uuid.UUID
		var createdAt time.Time
		// Подлежащее в тексте отсутствует: напоминание создаёт сам пользователь.
		body := "Напоминание: «" + d.title + "»"
		// notify_cat учитывает категорию «reminder»; при отключённой категории уведомление не создаётся, расписание сдвигается.
		err := pool.QueryRow(ctx,
			`SELECT id, created_at FROM app.notify_cat($1, $2, 'reminder', NULL, $3)`,
			d.user, body, d.task).Scan(&nid, &createdAt)
		if err == nil {
			n := notifModel(nid, createdAt, body)
			n.TaskID = d.task
			s.publishNotification(d.user, n)
			s.pingNotifications([]uuid.UUID{d.user})
		}
		// Срабатывание записывается в журнал: окно будильника откроется по событию WS, а если пользователя в сети нет,
		// то при первом входе (GET /reminders/alerts), пока он не закроет окно явным действием.
		var alertID uuid.UUID
		var dueAt time.Time
		if e := pool.QueryRow(ctx, `SELECT alert_id, due_at FROM app.record_reminder_alert($1)`, d.id).
			Scan(&alertID, &dueAt); e == nil {
			s.publishReminder(d.user, alertID, d.id, d.title, d.task, dueAt)
		}
		_, _ = pool.Exec(ctx, `SELECT app.advance_reminder($1)`, d.id)
	}
}

// Функция notifModel предназначена для сборки модели уведомления для публикации по WebSocket.
func notifModel(id uuid.UUID, createdAt time.Time, body string) models.Notification {
	return models.Notification{ID: id, Body: body, CreatedAt: createdAt}
}

// Константа reminderLockKey задаёт ключ рекомендательной блокировки опроса; значение уникально в системе.
const reminderLockKey = 776_120_001

// Метод tryReminderLock предназначен для попытки получить блокировку опроса.
func (s *Server) tryReminderLock(ctx context.Context, pool *pgxpool.Pool) bool {
	var ok bool
	if err := pool.QueryRow(ctx,
		`SELECT pg_try_advisory_lock($1)`, reminderLockKey).Scan(&ok); err != nil {
		slog.Warn("напоминания: не удалось взять блокировку", "error", err)
		return false
	}
	return ok
}

// Метод releaseReminderLock предназначен для снятия блокировки опроса.
func (s *Server) releaseReminderLock(ctx context.Context, pool *pgxpool.Pool) {
	if _, err := pool.Exec(ctx,
		`SELECT pg_advisory_unlock($1)`, reminderLockKey); err != nil {
		slog.Warn("напоминания: не удалось отпустить блокировку", "error", err)
	}
}

// Тип reminderAlert предназначен для описания сработавшего напоминания, ожидающего подтверждения.
type reminderAlert struct {
	ID         uuid.UUID  `json:"id"`
	ReminderID *uuid.UUID `json:"reminderId"`
	Title      string     `json:"title"`
	TaskID     *uuid.UUID `json:"taskId"`
	DueAt      time.Time  `json:"dueAt"`
	FiredAt    time.Time  `json:"firedAt"`
}

// Метод ListReminderAlerts предназначен для выдачи неподтверждённых сработавших напоминаний текущего пользователя;
// клиент вызывает его при входе, чтобы показать напоминания, сработавшие в его отсутствие.
func (s *Server) ListReminderAlerts(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []reminderAlert{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT id, reminder_id, title, task_id, due_at, fired_at
			  FROM app.reminder_alerts
			 WHERE user_id = $1 AND acked_at IS NULL
			 ORDER BY fired_at LIMIT 50`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var a reminderAlert
			if e := rows.Scan(&a.ID, &a.ReminderID, &a.Title, &a.TaskID, &a.DueAt, &a.FiredAt); e != nil {
				return e
			}
			out = append(out, a)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Метод AckReminderAlert предназначен для подтверждения сработавшего напоминания: окно больше не показывается.
func (s *Server) AckReminderAlert(c *fiber.Ctx) error {
	id, err := param(c, "alertID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			UPDATE app.reminder_alerts SET acked_at = now()
			 WHERE id = $1 AND user_id = $2 AND acked_at IS NULL`, id, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.NoContent(c)
}
