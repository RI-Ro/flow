// Модуль предназначен для пользовательских настроек интерфейса, хранимых на сервере: чтение и запись значения по ключу.
// Строки защищены политикой RLS (user_preferences_own): пользователь видит только свои настройки.

package handlers

import (
	"encoding/json"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Метод GetPreference предназначен для обработки запроса GET /preferences/:key; для отсутствующего ключа возвращается null.
func (s *Server) GetPreference(c *fiber.Ctx) error {
	key := c.Params("key")
	var raw []byte
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		e := tx.QueryRow(c.Context(),
			`SELECT value FROM app.user_preferences WHERE user_id = $1 AND key = $2`, s.uid(c), key).Scan(&raw)
		if e == pgx.ErrNoRows {
			raw = []byte("null")
			return nil
		}
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	c.Set(fiber.HeaderContentType, fiber.MIMEApplicationJSON)
	return c.Send(raw)
}

// Метод SetPreference предназначен для обработки запроса PUT /preferences/:key: значение — любой JSON до 8 КБ.
func (s *Server) SetPreference(c *fiber.Ctx) error {
	key := c.Params("key")
	body := c.Body()
	if len(body) == 0 || len(body) > 8192 || !json.Valid(body) {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input", "Некорректное значение настройки"))
	}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.user_preferences (user_id, key, value) VALUES ($1, $2, $3::jsonb)
			ON CONFLICT (user_id, key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
			s.uid(c), key, string(body))
		return e
	})
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input", "Не удалось сохранить настройку"))
	}
	return httpx.NoContent(c)
}
