-- =====================================================================
-- Файл предназначен для развёртывания структуры базы данных одним запуском.
-- Содержит все миграции backend/migrations в порядке нумерации,
-- кроме 0004_seed.sql (демонстрационные данные, применяются отдельно).
-- Исходные файлы миграций сохранены без изменений.
--
-- Запуск на пустой базе суперпользователем PostgreSQL:
--     sudo -u postgres createdb kanban
--     sudo -u postgres psql -d kanban -v ON_ERROR_STOP=1 -f deploy/migrations/kanban_deploy.sql
--
-- Порядок выполнения:
--   1. 0001_roles.sql выполняется суперпользователем (создание ролей).
--   2. Ролям выдаётся доступ к текущей базе данных, создаются расширения и схема app.
--   3. Остальные миграции выполняются от имени app_owner (SET ROLE),
--      поэтому владельцем схемы, таблиц и SECURITY DEFINER-функций
--      становится app_owner.
--
-- Пароли ролей по умолчанию (change_me_owner, change_me_user) необходимо
-- заменить после применения: ALTER ROLE app_user PASSWORD '...';
--
-- Файл формируется скриптом deploy/migrations/build.sh, вручную не правится.
-- =====================================================================

\set ON_ERROR_STOP on

-- #####################################################################
-- Миграция 0001_roles.sql
-- #####################################################################

\echo '--> 0001_roles.sql'

-- Скрипт предназначен для создания ролей базы данных: владельца схемы (app_owner) и рабочей роли приложения (app_user).
-- Выполняется суперпользователем один раз на кластер: sudo -u postgres psql -d kanban -f 0001_roles.sql
-- Скрипт идемпотентен: роли общие для всех баз кластера, повторное применение безопасно.


-- Блок создаёт роль app_owner — владельца схемы, таблиц и SECURITY DEFINER-функций.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_owner') THEN
        CREATE ROLE app_owner LOGIN PASSWORD 'change_me_owner';
    END IF;
END $$;

-- Блок создаёт роль app_user — рабочую роль приложения без BYPASSRLS и SUPERUSER: разграничение доступа
-- держится на политиках RLS. Приложение проверяет роль при запуске (internal/database/db.go).
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user') THEN
        CREATE ROLE app_user LOGIN PASSWORD 'change_me_user';
    END IF;
END $$;

ALTER ROLE app_owner NOBYPASSRLS;
ALTER ROLE app_user  NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE;

-- Право подключения к базе выдаётся отдельно после её создания:
-- GRANT CONNECT ON DATABASE kanban TO app_user, app_owner;

-- Схема public закрыта; приложение работает со схемой app.
REVOKE ALL ON SCHEMA public FROM PUBLIC;


-- Выдача ролям доступа к текущей базе данных.
SELECT format('GRANT CONNECT ON DATABASE %I TO app_user, app_owner', current_database()) \gexec
SELECT format('GRANT CREATE ON DATABASE %I TO app_owner', current_database()) \gexec

-- Расширения создаются суперпользователем (схема public закрыта для app_owner),
-- схема app создаётся сразу с владельцем app_owner.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE SCHEMA IF NOT EXISTS app AUTHORIZATION app_owner;
GRANT USAGE ON SCHEMA public TO app_owner;
SET ROLE app_owner;

-- #####################################################################
-- Миграция 0002_schema.sql
-- #####################################################################

\echo '--> 0002_schema.sql'

-- Скрипт предназначен для создания структуры базы данных: расширения, типы, таблицы, индексы и триггеры.
-- Порядок применения: 0001_roles, 0002_schema, 0003_rls, далее 0004_seed (необязательно).
-- Выполняется владельцем таблиц (app_owner или суперпользователь), но не ролью app_user.


CREATE EXTENSION IF NOT EXISTS "pgcrypto";
-- Расширение citext предназначено для регистронезависимых адресов электронной почты.
CREATE EXTENSION IF NOT EXISTS "citext";
-- Расширение pg_trgm предназначено для триграммных индексов поиска.
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Схема app предназначена для хранения всех объектов приложения.
CREATE SCHEMA IF NOT EXISTS app;
SET search_path = app, public;
SET client_min_messages = warning;

-- Раздел: типы.

-- Тип app.board_role задаёт роль в проекте (не путать с system_role).
CREATE TYPE app.board_role AS ENUM ('owner', 'editor', 'reader');

-- Тип app.grant_access задаёт уровень точечного доступа к задаче человеку вне проекта.
CREATE TYPE app.grant_access AS ENUM ('read', 'contribute');

-- Тип app.task_priority задаёт приоритеты задач; dated означает явно назначенный срок.
CREATE TYPE app.task_priority AS ENUM
    ('normal', 'dated', 'prompt', 'urgent', 'very_urgent');

-- Тип app.system_role задаёт роль в системе.
CREATE TYPE app.system_role AS ENUM ('member', 'admin');

-- Тип app.task_link_kind задаёт виды связей между задачами.
CREATE TYPE app.task_link_kind AS ENUM ('blocks', 'relates', 'subtask');

-- Функция app.touch_updated_at предназначена для обновления поля updated_at при изменении строки.
CREATE OR REPLACE FUNCTION app.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END $$;

-- Таблица app.users предназначена для хранения пользователей.

CREATE TABLE app.users (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email         citext NOT NULL UNIQUE,
    password_hash text   NOT NULL,
    full_name     text   NOT NULL,
    position      text   NOT NULL DEFAULT '',
    phone         text   NOT NULL DEFAULT '',
    avatar_color  text   NOT NULL DEFAULT '#3D5A80',
    role          app.system_role NOT NULL DEFAULT 'member',
    is_active     boolean NOT NULL DEFAULT true,
    -- Удаление мягкое: created_by в проектах, задачах и комментариях имеет ограничение ON DELETE RESTRICT.
    deleted_at    timestamptz,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);

-- Индекс users_search_trgm_idx предназначен для поиска по справочнику (ILIKE '%подстрока%').
CREATE INDEX users_search_trgm_idx ON app.users
    USING gin ((full_name || ' ' || position || ' ' || phone) gin_trgm_ops);

-- Индекс users_directory_sort_idx предназначен для сортировки справочника: действующие, затем по алфавиту.
CREATE INDEX users_directory_sort_idx ON app.users ((deleted_at IS NOT NULL), full_name);

-- Индекс users_admin_idx предназначен для быстрой проверки прав администратора.
CREATE INDEX users_admin_idx ON app.users (id)
    WHERE role = 'admin' AND deleted_at IS NULL;

-- Триггер users_touch предназначен для обновления updated_at пользователя.
CREATE TRIGGER users_touch BEFORE UPDATE ON app.users
    FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- Таблица app.team_members предназначена для хранения личной команды пользователя (кандидаты в исполнители).
CREATE TABLE app.team_members (
    owner_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    member_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    added_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (owner_id, member_id),
    CONSTRAINT team_members_not_self CHECK (owner_id <> member_id)
);

-- Таблица app.refresh_tokens предназначена для хранения сессий (refresh-токенов).

CREATE TABLE app.refresh_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    -- Хранится SHA-256 токена, а не сам токен.
    token_hash  bytea NOT NULL UNIQUE,
    family_id   uuid NOT NULL,
    expires_at  timestamptz NOT NULL,
    revoked_at  timestamptz,
    user_agent  text NOT NULL DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX refresh_tokens_user_idx   ON app.refresh_tokens (user_id);
CREATE INDEX refresh_tokens_family_idx ON app.refresh_tokens (family_id);
CREATE INDEX refresh_tokens_active_idx ON app.refresh_tokens (user_id)
    WHERE revoked_at IS NULL;

-- Таблица app.delegations предназначена для хранения замещений на время отсутствия.

CREATE TABLE app.delegations (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    grantor_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    deputy_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    starts_at   date NOT NULL,
    ends_at     date NOT NULL,
    note        text NOT NULL DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT delegations_period_check CHECK (ends_at >= starts_at),
    CONSTRAINT delegations_not_self CHECK (grantor_id <> deputy_id)
);

CREATE INDEX delegations_deputy_idx  ON app.delegations (deputy_id, starts_at, ends_at);
CREATE INDEX delegations_grantor_idx ON app.delegations (grantor_id);

-- Таблица app.files предназначена для хранения сведений о файлах (содержимое лежит в хранилище на диске).

CREATE TABLE app.files (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id     uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    storage_key  text NOT NULL,
    filename     text NOT NULL,
    mime_type    text NOT NULL,
    size_bytes   bigint NOT NULL,
    checksum     text NOT NULL DEFAULT '',
    created_at   timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.boards предназначена для хранения проектов.

CREATE TABLE app.boards (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title        text NOT NULL CHECK (length(btrim(title)) > 0),
    description  text NOT NULL DEFAULT '',
    -- Дерево проектов: parent_id возвращается клиенту без изменений.
    parent_id    uuid REFERENCES app.boards(id) ON DELETE SET NULL,
    position     integer NOT NULL DEFAULT 0,
    bg_preset    text NOT NULL DEFAULT 'none',
    bg_file_id   uuid REFERENCES app.files(id) ON DELETE SET NULL,
    bg_blur      boolean NOT NULL DEFAULT false,
    archived     boolean NOT NULL DEFAULT false,
    created_by   uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX boards_parent_idx ON app.boards (parent_id, position);

-- Триггер boards_touch предназначен для обновления updated_at проекта.
CREATE TRIGGER boards_touch BEFORE UPDATE ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- Функция app.check_board_cycle предназначена для запрета циклов в дереве проектов.
CREATE OR REPLACE FUNCTION app.check_board_cycle() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
DECLARE
    cur uuid := NEW.parent_id;
    depth int := 0;
BEGIN
    IF NEW.parent_id IS NULL THEN
        RETURN NEW;
    END IF;
    IF NEW.parent_id = NEW.id THEN
        RAISE EXCEPTION 'Проект не может быть вложен сам в себя';
    END IF;

    WHILE cur IS NOT NULL LOOP
        depth := depth + 1;
        IF depth > 32 THEN
            RAISE EXCEPTION 'Слишком глубокая вложенность проектов';
        END IF;
        SELECT parent_id INTO cur FROM app.boards WHERE id = cur;
        IF cur = NEW.id THEN
            RAISE EXCEPTION 'Нельзя вложить проект внутрь его собственного подпроекта';
        END IF;
    END LOOP;
    RETURN NEW;
END $$;

-- Триггер boards_cycle_check предназначен для проверки отсутствия цикла при изменении parent_id.
CREATE TRIGGER boards_cycle_check BEFORE INSERT OR UPDATE OF parent_id ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.check_board_cycle();

-- Таблица app.board_members предназначена для хранения участников проектов и их ролей.
CREATE TABLE app.board_members (
    board_id  uuid NOT NULL REFERENCES app.boards(id) ON DELETE CASCADE,
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    role      app.board_role NOT NULL DEFAULT 'reader',
    added_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (board_id, user_id)
);

CREATE INDEX board_members_user_idx ON app.board_members (user_id);

-- Индекс board_single_owner_idx гарантирует одного владельца у проекта.
CREATE UNIQUE INDEX board_single_owner_idx ON app.board_members (board_id)
    WHERE role = 'owner';

-- Таблица app.columns предназначена для хранения колонок проектов.

CREATE TABLE app.columns (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id   uuid NOT NULL REFERENCES app.boards(id) ON DELETE CASCADE,
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    color      text NOT NULL DEFAULT '#8892A8',
    position   integer NOT NULL DEFAULT 0,
    -- Значение 0 означает отсутствие предела.
    wip_limit  integer NOT NULL DEFAULT 0 CHECK (wip_limit >= 0),
    -- Колонка завершения: перенос в неё закрывает задачу.
    is_done    boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX columns_board_idx ON app.columns (board_id, position);

-- Таблица app.tasks предназначена для хранения задач.

CREATE TABLE app.tasks (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id     uuid NOT NULL REFERENCES app.boards(id) ON DELETE CASCADE,
    column_id    uuid NOT NULL REFERENCES app.columns(id) ON DELETE CASCADE,
    title        text NOT NULL CHECK (length(btrim(title)) > 0),
    description  text NOT NULL DEFAULT '',
    priority     app.task_priority NOT NULL DEFAULT 'normal',
    -- Идентификатор цвета из палитры; оттенок определяется темой на клиенте.
    color        text NOT NULL DEFAULT 'none',
    due_date     date,
    -- Реквизиты входящего документа, по которому заведена задача.
    incoming_number text NOT NULL DEFAULT '',
    incoming_date   date,
    position     integer NOT NULL DEFAULT 0,
    tags         text[] NOT NULL DEFAULT '{}',
    completed_at timestamptz,
    archived     boolean NOT NULL DEFAULT false,
    created_by   uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT tasks_color_check CHECK (color IN (
        'none', 'amber', 'rose', 'violet', 'sky', 'emerald',
        'orange', 'slate', 'teal', 'crimson'))
);

CREATE INDEX tasks_board_idx  ON app.tasks (board_id);
CREATE INDEX tasks_column_idx ON app.tasks (column_id, position);
CREATE INDEX tasks_author_idx ON app.tasks (created_by);
CREATE INDEX tasks_search_idx ON app.tasks
    USING gin (to_tsvector('russian', title || ' ' || description));

-- Индекс tasks_due_date_idx частичный: предназначен для запросов календаря по диапазону дат.
CREATE INDEX tasks_due_date_idx ON app.tasks (due_date, board_id)
    WHERE due_date IS NOT NULL AND NOT archived;

-- Индекс tasks_incoming_number_idx предназначен для поиска по номеру входящего документа.
CREATE INDEX tasks_incoming_number_idx ON app.tasks (incoming_number)
    WHERE incoming_number <> '';

-- Триггер tasks_touch предназначен для обновления updated_at задачи.
CREATE TRIGGER tasks_touch BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- Таблица app.task_assignees предназначена для хранения исполнителей задач.
CREATE TABLE app.task_assignees (
    task_id      uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    user_id      uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    -- Отметка исполнителя о выполнении своей части (отличается от tasks.completed_at — решения автора).
    completed_at timestamptz,
    PRIMARY KEY (task_id, user_id)
);

CREATE INDEX task_assignees_user_idx ON app.task_assignees (user_id);
CREATE INDEX task_assignees_done_idx ON app.task_assignees (task_id)
    WHERE completed_at IS NOT NULL;

-- Таблица app.task_grants предназначена для хранения точечных прав доступа к задачам.
CREATE TABLE app.task_grants (
    task_id    uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    access     app.grant_access NOT NULL DEFAULT 'read',
    granted_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (task_id, user_id)
);

CREATE INDEX task_grants_user_idx ON app.task_grants (user_id);

-- Таблица app.task_steps предназначена для хранения пунктов чек-листа.
CREATE TABLE app.task_steps (
    id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id  uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    body     text NOT NULL CHECK (length(btrim(body)) > 0),
    done     boolean NOT NULL DEFAULT false,
    position integer NOT NULL DEFAULT 0,
    done_by  uuid REFERENCES app.users(id) ON DELETE SET NULL,
    done_at  timestamptz
);

CREATE INDEX task_steps_task_idx ON app.task_steps (task_id, position);

-- Таблица app.task_links предназначена для хранения связей между задачами.
CREATE TABLE app.task_links (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    from_task  uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    to_task    uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    kind       app.task_link_kind NOT NULL DEFAULT 'relates',
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT task_links_not_self CHECK (from_task <> to_task),
    CONSTRAINT task_links_unique UNIQUE (from_task, to_task, kind)
);

CREATE INDEX task_links_from_idx ON app.task_links (from_task);
CREATE INDEX task_links_to_idx   ON app.task_links (to_task);

-- Таблица app.comments предназначена для хранения комментариев к задачам.

CREATE TABLE app.comments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id    uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    body       text NOT NULL CHECK (length(btrim(body)) > 0),
    edited_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX comments_task_idx ON app.comments (task_id, created_at);

-- Таблица app.attachments предназначена для хранения вложений задач.
CREATE TABLE app.attachments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id    uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    title      text NOT NULL DEFAULT '',
    edited_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX attachments_task_idx ON app.attachments (task_id, created_at);

-- Таблица app.activity предназначена для хранения журнала изменений.
CREATE TABLE app.activity (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id    uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    actor_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX activity_task_idx ON app.activity (task_id, created_at DESC);

-- Таблица app.notifications предназначена для хранения уведомлений.
CREATE TABLE app.notifications (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    body       text NOT NULL,
    board_id   uuid REFERENCES app.boards(id) ON DELETE CASCADE,
    task_id    uuid REFERENCES app.tasks(id) ON DELETE CASCADE,
    read_at    timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX notifications_user_idx ON app.notifications (user_id, created_at DESC);
CREATE INDEX notifications_user_unread_idx ON app.notifications (user_id, created_at DESC)
    WHERE read_at IS NULL;

-- Таблица app.task_templates предназначена для хранения шаблонов задач.

CREATE TABLE app.task_templates (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    -- NULL означает личный шаблон владельца.
    board_id    uuid REFERENCES app.boards(id) ON DELETE CASCADE,
    owner_id    uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    name        text NOT NULL CHECK (length(btrim(name)) > 0),
    title       text NOT NULL DEFAULT '',
    description text NOT NULL DEFAULT '',
    priority    app.task_priority NOT NULL DEFAULT 'normal',
    color       text NOT NULL DEFAULT 'none',
    tags        text[] NOT NULL DEFAULT '{}',
    -- Срок задаётся смещением в днях от момента применения шаблона.
    due_in_days integer,
    steps       text[] NOT NULL DEFAULT '{}',
    assignees   uuid[] NOT NULL DEFAULT '{}',
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX task_templates_board_idx ON app.task_templates (board_id);
CREATE INDEX task_templates_owner_idx ON app.task_templates (owner_id);


-- #####################################################################
-- Миграция 0003_rls.sql
-- #####################################################################

\echo '--> 0003_rls.sql'

-- Скрипт предназначен для настройки разграничения доступа на уровне строк (RLS): функции-помощники,
-- функции получателей событий, включение RLS, политики и привилегии рабочей роли.
-- Модель: приложение подключается ролью app_user без BYPASSRLS; в каждой транзакции выполняется
-- SELECT set_config('app.user_id', '<uuid>', true) — параметр локален для транзакции.
-- Помощники объявлены SECURITY DEFINER и принадлежат владельцу таблиц, не находящемуся под FORCE ROW LEVEL SECURITY;
-- внутри помощников RLS не применяется, что исключает рекурсию политик. Политики обращаются к защищённым таблицам
-- только через эти функции.


SET search_path = app, public;
SET client_min_messages = warning;

-- Раздел 1: функции-помощники.

-- Функция app.current_user_id предназначена для получения текущего пользователя из параметра app.user_id;
-- при отсутствии параметра возвращает NULL, и политики не возвращают строк.
CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
LANGUAGE sql STABLE
AS $$
    SELECT nullif(current_setting('app.user_id', true), '')::uuid
$$;

-- Функция app.effective_users предназначена для получения действующих личностей пользователя: собственная и замещаемых на текущую дату.
CREATE OR REPLACE FUNCTION app.effective_users(p_user uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user
    UNION
    SELECT d.grantor_id FROM app.delegations d
     WHERE d.deputy_id = p_user
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.board_role предназначена для определения сильнейшей роли в проекте с учётом замещения; порядок ролей задан явно.
CREATE OR REPLACE FUNCTION app.board_role(p_board uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.board_members m
     WHERE m.board_id = p_board
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_edit_board предназначена для проверки права редактирования проекта.
CREATE OR REPLACE FUNCTION app.can_edit_board(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.board_role(p_board, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_board_owner предназначена для проверки, что пользователь — владелец проекта.
CREATE OR REPLACE FUNCTION app.is_board_owner(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.board_role(p_board, p_user) = 'owner' $$;

-- Функция app.can_see_board предназначена для проверки видимости проекта: участник видит проект целиком,
-- обладатель доступа к одной задаче — только строку проекта.
CREATE OR REPLACE FUNCTION app.can_see_board(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_role(p_board, p_user) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_grants g ON g.task_id = t.id
             WHERE t.board_id = p_board
               AND g.user_id IN (SELECT app.effective_users(p_user)))
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_assignees a ON a.task_id = t.id
             WHERE t.board_id = p_board
               AND a.user_id IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.task_access предназначена для определения уровня доступа к задаче: edit (владелец или редактор проекта)
-- либо contribute (читатель проекта, исполнитель, точечное право «участие»).
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id INTO v_board FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    ELSIF v_role = 'reader' THEN
        RETURN 'contribute';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;

    RETURN v_grant;
END $$;

-- Функция app.can_see_task предназначена для проверки видимости задачи.
CREATE OR REPLACE FUNCTION app.can_see_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) IS NOT NULL $$;

-- Функция app.can_contribute_task предназначена для проверки права участия в задаче.
CREATE OR REPLACE FUNCTION app.can_contribute_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) IN ('edit', 'contribute') $$;

-- Функция app.can_edit_task предназначена для проверки права редактирования задачи.
CREATE OR REPLACE FUNCTION app.can_edit_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.task_access(p_task, p_user) = 'edit' $$;

-- Функция app.can_close_task предназначена для проверки права завершения задачи: автор или владелец проекта.
CREATE OR REPLACE FUNCTION app.can_close_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) = 'owner'))
$$;

-- Функция app.is_admin предназначена для проверки прав администратора запросом к БД.
CREATE OR REPLACE FUNCTION app.is_admin(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.users u
         WHERE u.id = p_user AND u.role = 'admin'
           AND u.deleted_at IS NULL AND u.is_active)
$$;

-- Функция app.other_admins_count предназначена для подсчёта администраторов, оставшихся после исключения указанного.
CREATE OR REPLACE FUNCTION app.other_admins_count(p_except uuid)
RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)::integer FROM app.users u
     WHERE u.role = 'admin' AND u.deleted_at IS NULL AND u.is_active
       AND u.id <> p_except
$$;

-- Функция app.authenticate предназначена для входа: возвращает данные для проверки пароля, так как у app_user нет права SELECT на хеш.
CREATE OR REPLACE FUNCTION app.authenticate(p_email citext)
RETURNS TABLE (id uuid, password_hash text, is_active boolean, role text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.id, u.password_hash, u.is_active, u.role::text
      FROM app.users u
     WHERE u.email = p_email AND u.deleted_at IS NULL
$$;

-- Функция app.account_state предназначена для проверки состояния учётной записи при обновлении токена (до появления app.user_id).
CREATE OR REPLACE FUNCTION app.account_state(p_user uuid)
RETURNS TABLE (is_active boolean, deleted boolean, role text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.is_active, (u.deleted_at IS NOT NULL), u.role::text
      FROM app.users u WHERE u.id = p_user
$$;

-- Функция app.revoke_user_sessions предназначена для отзыва всех сессий пользователя.
CREATE OR REPLACE FUNCTION app.revoke_user_sessions(p_user uuid)
RETURNS integer
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    WITH killed AS (
        UPDATE app.refresh_tokens SET revoked_at = now()
         WHERE user_id = p_user AND revoked_at IS NULL
        RETURNING 1)
    SELECT count(*)::integer FROM killed
$$;

-- Раздел 2: получатели событий реального времени. Функции повторяют условия видимости политик и вычисляются в БД,
-- чтобы правила не расходились с приложением.
-- Функция app.board_watchers предназначена для получения получателей событий проекта.

CREATE OR REPLACE FUNCTION app.board_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.board_members m WHERE m.board_id = p_board
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.board_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.board_id = p_board
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.task_watchers предназначена для получения получателей событий задачи.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
    )
    SELECT user_id FROM base
    UNION
    SELECT d.deputy_id FROM base b
      JOIN app.delegations d ON d.grantor_id = b.user_id
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.task_watchers_for_board предназначена для получения получателей событий удалённой задачи; проект передаётся явно.
CREATE OR REPLACE FUNCTION app.task_watchers_for_board(p_board uuid, p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_watchers(p_board)
    UNION
    SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
    UNION
    SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
$$;

-- Функция app.notify предназначена для создания уведомления от имени сервиса: app_user не может вставлять строки другим пользователям.
CREATE OR REPLACE FUNCTION app.notify(
    p_user uuid, p_body text, p_board uuid DEFAULT NULL, p_task uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    VALUES (p_user, p_body, p_board, p_task)
    RETURNING notifications.id, notifications.created_at
$$;

-- Функция app.active_delegations предназначена для получения действующих замещений всех сотрудников при узкой политике delegations_select.
CREATE OR REPLACE FUNCTION app.active_delegations()
RETURNS TABLE (id uuid, grantor_id uuid, deputy_id uuid,
               starts_at text, ends_at text, note text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT d.id, d.grantor_id, d.deputy_id,
           to_char(d.starts_at, 'YYYY-MM-DD'),
           to_char(d.ends_at, 'YYYY-MM-DD'),
           d.note
      FROM app.delegations d
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.notify_task_watchers предназначена для создания уведомления всем наблюдателям задачи, кроме инициатора.
CREATE OR REPLACE FUNCTION app.notify_task_watchers(
    p_task uuid, p_actor uuid, p_body text)
RETURNS SETOF uuid
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    SELECT DISTINCT w.user_id, p_body, t.board_id, t.id
      FROM app.tasks t
      CROSS JOIN LATERAL app.task_watchers(t.id) AS w(user_id)
      JOIN app.users u ON u.id = w.user_id
     WHERE t.id = p_task
       -- Инициатор не уведомляется; проверка выполняется по всем его действующим личностям.
       AND w.user_id <> ALL (SELECT app.effective_users(p_actor))
       -- Отключённым и удалённым пользователям уведомления не создаются.
       AND u.deleted_at IS NULL AND u.is_active
    RETURNING notifications.user_id
$$;

-- Раздел 3: включение RLS.

ALTER TABLE app.users           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.team_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.refresh_tokens  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.delegations     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.files           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.boards          ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.board_members   ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.columns         ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.tasks           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_assignees  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_grants     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_steps      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.task_templates  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.comments        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.attachments     ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.activity        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.notifications   ENABLE ROW LEVEL SECURITY;

-- Раздел 4: политики.

-- Политика users_select: справочник виден всем вошедшим, включая удалённых.
CREATE POLICY users_select ON app.users FOR SELECT
    USING (app.current_user_id() IS NOT NULL);

-- Политика users_insert: регистрация выполняется до появления app.user_id (NULL допускается).
CREATE POLICY users_insert ON app.users FOR INSERT
    WITH CHECK (
        app.current_user_id() IS NULL
        OR app.is_admin(app.current_user_id())
    );

CREATE POLICY users_update ON app.users FOR UPDATE
    USING (
        id = app.current_user_id()
        OR app.is_admin(app.current_user_id())
    )
    WITH CHECK (
        id = app.current_user_id()
        OR app.is_admin(app.current_user_id())
    );

-- Политики DELETE нет: удаление пользователя — это deleted_at и is_active = false.

-- Политика team_own: личная команда доступна владельцу.
CREATE POLICY team_own ON app.team_members FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

-- Политика refresh_tokens_service_or_own: до появления app.user_id (вход, регистрация, обновление) либо собственные строки.
CREATE POLICY refresh_tokens_service_or_own ON app.refresh_tokens FOR ALL
    USING (app.current_user_id() IS NULL OR user_id = app.current_user_id())
    WITH CHECK (app.current_user_id() IS NULL OR user_id = app.current_user_id());

-- Политики delegations: видят обе стороны; заводит и отменяет замещаемый.
CREATE POLICY delegations_select ON app.delegations FOR SELECT
    USING (grantor_id = app.current_user_id() OR deputy_id = app.current_user_id());

CREATE POLICY delegations_write ON app.delegations FOR INSERT
    WITH CHECK (grantor_id = app.current_user_id());

CREATE POLICY delegations_delete ON app.delegations FOR DELETE
    USING (grantor_id = app.current_user_id());

-- Политика files_select: доступ к файлу определяется доступом к связанной сущности.
CREATE POLICY files_select ON app.files FOR SELECT
    USING (
        owner_id = app.current_user_id()
        OR EXISTS (
            SELECT 1 FROM app.attachments a
             WHERE a.file_id = files.id
               AND app.can_see_task(a.task_id, app.current_user_id()))
        OR EXISTS (
            SELECT 1 FROM app.boards b
             WHERE b.bg_file_id = files.id
               AND app.can_see_board(b.id, app.current_user_id()))
    );

CREATE POLICY files_insert ON app.files FOR INSERT
    WITH CHECK (owner_id = app.current_user_id());

CREATE POLICY files_delete ON app.files FOR DELETE
    USING (owner_id = app.current_user_id());

-- Политика boards_select: проекты, видимые пользователю.
CREATE POLICY boards_select ON app.boards FOR SELECT
    USING (app.can_see_board(id, app.current_user_id()));

CREATE POLICY boards_insert ON app.boards FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

CREATE POLICY boards_update ON app.boards FOR UPDATE
    USING (app.is_board_owner(id, app.current_user_id()))
    WITH CHECK (app.is_board_owner(id, app.current_user_id()));

CREATE POLICY boards_delete ON app.boards FOR DELETE
    USING (app.is_board_owner(id, app.current_user_id()));

-- Функция app.board_owner_bootstrap предназначена для добавления создателя проекта владельцем.
CREATE OR REPLACE FUNCTION app.board_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.board_members (board_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

-- Триггер boards_owner_bootstrap предназначен для вызова app.board_owner_bootstrap после создания проекта.
CREATE TRIGGER boards_owner_bootstrap AFTER INSERT ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.board_owner_bootstrap();

-- Политика board_members_select: участники видны тем, кто видит проект.
CREATE POLICY board_members_select ON app.board_members FOR SELECT
    USING (app.board_role(board_id, app.current_user_id()) IS NOT NULL);

CREATE POLICY board_members_write ON app.board_members FOR INSERT
    WITH CHECK (app.is_board_owner(board_id, app.current_user_id()));

CREATE POLICY board_members_update ON app.board_members FOR UPDATE
    USING (app.is_board_owner(board_id, app.current_user_id()))
    WITH CHECK (app.is_board_owner(board_id, app.current_user_id()));

-- Политика board_members_delete: владелец убирает любого, кроме себя; участник может выйти сам.
CREATE POLICY board_members_delete ON app.board_members FOR DELETE
    USING (
        (app.is_board_owner(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

-- Политика columns_select: колонки видит только участник проекта.
CREATE POLICY columns_select ON app.columns FOR SELECT
    USING (app.board_role(board_id, app.current_user_id()) IS NOT NULL);

CREATE POLICY columns_write ON app.columns FOR INSERT
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY columns_update ON app.columns FOR UPDATE
    USING (app.can_edit_board(board_id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY columns_delete ON app.columns FOR DELETE
    USING (app.can_edit_board(board_id, app.current_user_id()));

-- Политика tasks_select: видимость задач.
CREATE POLICY tasks_select ON app.tasks FOR SELECT
    USING (app.can_see_task(id, app.current_user_id()));

CREATE POLICY tasks_insert ON app.tasks FOR INSERT
    WITH CHECK (
        app.can_edit_board(board_id, app.current_user_id())
        AND created_by = app.current_user_id()
    );

CREATE POLICY tasks_update ON app.tasks FOR UPDATE
    USING (app.can_edit_task(id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(board_id, app.current_user_id()));

CREATE POLICY tasks_delete ON app.tasks FOR DELETE
    USING (app.can_edit_task(id, app.current_user_id()));

-- Политика task_assignees_select: видимость исполнителей.
CREATE POLICY task_assignees_select ON app.task_assignees FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY task_assignees_write ON app.task_assignees FOR INSERT
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_assignees_self_update: отметку о выполнении ставит только сам исполнитель.
CREATE POLICY task_assignees_self_update ON app.task_assignees FOR UPDATE
    USING (
        user_id = app.current_user_id()
        AND app.can_see_task(task_id, app.current_user_id())
    )
    WITH CHECK (
        user_id = app.current_user_id()
        AND app.can_see_task(task_id, app.current_user_id())
    );

CREATE POLICY task_assignees_delete ON app.task_assignees FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_grants_select: видимость точечных прав.
CREATE POLICY task_grants_select ON app.task_grants FOR SELECT
    USING (
        user_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

CREATE POLICY task_grants_write ON app.task_grants FOR INSERT
    WITH CHECK (
        app.can_edit_task(task_id, app.current_user_id())
        AND granted_by = app.current_user_id()
    );

CREATE POLICY task_grants_update ON app.task_grants FOR UPDATE
    USING (app.can_edit_task(task_id, app.current_user_id()))
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

CREATE POLICY task_grants_delete ON app.task_grants FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политики task_steps: отметить пункт может участник; менять текст и состав — только редактор (проверяется в обработчиках).
CREATE POLICY task_steps_select ON app.task_steps FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_insert ON app.task_steps FOR INSERT
    WITH CHECK (app.can_edit_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_update ON app.task_steps FOR UPDATE
    USING (app.can_contribute_task(task_id, app.current_user_id()))
    WITH CHECK (app.can_contribute_task(task_id, app.current_user_id()));

CREATE POLICY task_steps_delete ON app.task_steps FOR DELETE
    USING (app.can_edit_task(task_id, app.current_user_id()));

-- Политика task_links_select: связь видна, только если видны обе задачи.
CREATE POLICY task_links_select ON app.task_links FOR SELECT
    USING (
        app.can_see_task(from_task, app.current_user_id())
        AND app.can_see_task(to_task, app.current_user_id())
    );

CREATE POLICY task_links_write ON app.task_links FOR INSERT
    WITH CHECK (
        app.can_edit_task(from_task, app.current_user_id())
        AND app.can_see_task(to_task, app.current_user_id())
        AND created_by = app.current_user_id()
    );

CREATE POLICY task_links_delete ON app.task_links FOR DELETE
    USING (app.can_edit_task(from_task, app.current_user_id()));

-- Политика task_templates_select: видимость шаблонов.
CREATE POLICY task_templates_select ON app.task_templates FOR SELECT
    USING (
        owner_id = app.current_user_id()
        OR (board_id IS NOT NULL
            AND app.board_role(board_id, app.current_user_id()) IS NOT NULL)
    );

CREATE POLICY task_templates_write ON app.task_templates FOR INSERT
    WITH CHECK (
        owner_id = app.current_user_id()
        AND (board_id IS NULL OR app.can_edit_board(board_id, app.current_user_id()))
    );

CREATE POLICY task_templates_update ON app.task_templates FOR UPDATE
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

CREATE POLICY task_templates_delete ON app.task_templates FOR DELETE
    USING (
        owner_id = app.current_user_id()
        OR (board_id IS NOT NULL AND app.is_board_owner(board_id, app.current_user_id()))
    );

-- Политики comments: правка своего — в течение часа; удаление редактором задачи бессрочно.
CREATE POLICY comments_select ON app.comments FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY comments_insert ON app.comments FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND author_id = app.current_user_id()
    );

CREATE POLICY comments_update ON app.comments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

CREATE POLICY comments_delete ON app.comments FOR DELETE
    USING (
        (author_id = app.current_user_id() AND created_at > now() - interval '1 hour')
        OR app.can_edit_task(task_id, app.current_user_id())
    );

-- Политика attachments_select: видимость вложений.
CREATE POLICY attachments_select ON app.attachments FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY attachments_insert ON app.attachments FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND author_id = app.current_user_id()
    );

CREATE POLICY attachments_update ON app.attachments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

CREATE POLICY attachments_delete ON app.attachments FOR DELETE
    USING (
        (author_id = app.current_user_id() AND created_at > now() - interval '1 hour')
        OR app.can_edit_task(task_id, app.current_user_id())
    );

-- Политики activity: журнал только читается; изменение и удаление не допускаются.
CREATE POLICY activity_select ON app.activity FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

CREATE POLICY activity_insert ON app.activity FOR INSERT
    WITH CHECK (
        app.can_contribute_task(task_id, app.current_user_id())
        AND actor_id = app.current_user_id()
    );

-- Политика notifications_own: уведомления видит их получатель.
CREATE POLICY notifications_own ON app.notifications FOR SELECT
    USING (user_id = app.current_user_id());

CREATE POLICY notifications_update ON app.notifications FOR UPDATE
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

CREATE POLICY notifications_delete ON app.notifications FOR DELETE
    USING (user_id = app.current_user_id());

-- Раздел 5: привилегии рабочей роли.

GRANT USAGE ON SCHEMA app TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA app TO app_user;

-- Хеш пароля недоступен для чтения; доступ только через app.authenticate.
REVOKE SELECT ON app.users FROM app_user;
GRANT SELECT (id, email, full_name, position, phone, avatar_color,
              role, is_active, deleted_at, created_at, updated_at)
    ON app.users TO app_user;
GRANT UPDATE (full_name, position, phone, avatar_color, password_hash,
              email, is_active, deleted_at, role)
    ON app.users TO app_user;

-- Уведомления создаются только через app.notify.
REVOKE INSERT ON app.notifications FROM app_user;

-- В task_assignees рабочая роль изменяет только отметку о выполнении.
REVOKE UPDATE ON app.task_assignees FROM app_user;
GRANT UPDATE (completed_at) ON app.task_assignees TO app_user;

-- Связи задач не редактируются: только создаются и удаляются.
REVOKE UPDATE ON app.task_links FROM app_user;

GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA app TO app_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA app
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;


-- #####################################################################
-- Миграция 0005_features.sql
-- #####################################################################

\echo '--> 0005_features.sql'

-- Скрипт предназначен для применения доработок поверх базовой схемы (0002) и RLS (0003): столбцы, напоминания,
-- настройки уведомлений, функции доступа, перемещение задач, периодичность и политики RLS.
-- Выполняется от app_owner, идемпотентен: psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0005_features.sql


SET search_path = app, public;

-- Раздел 1: новые столбцы.

-- Столбцы task_steps: исполнитель, срок и автор пункта (объединённый чек-лист).
ALTER TABLE app.task_steps
    ADD COLUMN IF NOT EXISTS assignee_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS due_date    date,
    ADD COLUMN IF NOT EXISTS created_by  uuid REFERENCES app.users(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS task_steps_assignee_idx ON app.task_steps (assignee_id);

-- Столбцы tasks: периодичность задачи.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS recur_freq     text NOT NULL DEFAULT 'none'
        CHECK (recur_freq IN ('none','daily','weekly','monthly')),
    ADD COLUMN IF NOT EXISTS recur_interval integer NOT NULL DEFAULT 1
        CHECK (recur_interval >= 1),
    ADD COLUMN IF NOT EXISTS recur_weekdays integer[] NOT NULL DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS recur_monthday integer,
    ADD COLUMN IF NOT EXISTS recur_until    date;

-- Столбец tasks.report: отчёт о выполнении (свободный текст).
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS report text NOT NULL DEFAULT '';

-- Таблица app.reminders предназначена для хранения личных напоминаний: заголовок, время срабатывания, повторение.
-- Сработавшие напоминания обрабатывает фоновый опрос приложения.
CREATE TABLE IF NOT EXISTS app.reminders (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    remind_at   timestamptz NOT NULL,
    recur_freq  text NOT NULL DEFAULT 'none'
        CHECK (recur_freq IN ('none','daily','weekly','monthly')),
    recur_interval integer NOT NULL DEFAULT 1 CHECK (recur_interval >= 1),
    recur_weekdays integer[] NOT NULL DEFAULT '{}',
    active      boolean NOT NULL DEFAULT true,
    last_fired  timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS reminders_user_idx ON app.reminders (user_id);
CREATE INDEX IF NOT EXISTS reminders_due_idx  ON app.reminders (remind_at) WHERE active;

ALTER TABLE app.reminders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS reminders_own ON app.reminders;
CREATE POLICY reminders_own ON app.reminders FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.reminders TO app_user;

-- Таблица app.notification_prefs предназначена для хранения настроек категорий уведомлений пользователя.
CREATE TABLE IF NOT EXISTS app.notification_prefs (
    user_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    category text NOT NULL,
    enabled  boolean NOT NULL DEFAULT true,
    PRIMARY KEY (user_id, category)
);
ALTER TABLE app.notification_prefs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS notif_prefs_own ON app.notification_prefs;
CREATE POLICY notif_prefs_own ON app.notification_prefs FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.notification_prefs TO app_user;

-- Функция app.next_reminder_at предназначена для вычисления следующего времени срабатывания повторяющегося напоминания;
-- для weekly с выбранными днями определяется ближайший выбранный день недели, иначе добавляется интервал.
CREATE OR REPLACE FUNCTION app.next_reminder_at(
    p_from timestamptz, p_freq text, p_interval int, p_weekdays int[])
RETURNS timestamptz
LANGUAGE plpgsql IMMUTABLE
AS $$
DECLARE v_next timestamptz := p_from; v_guard int := 0; v_dow int;
BEGIN
    IF p_freq = 'daily' THEN
        RETURN p_from + (p_interval || ' days')::interval;
    ELSIF p_freq = 'monthly' THEN
        RETURN p_from + (p_interval || ' months')::interval;
    ELSIF p_freq = 'weekly' THEN
        IF array_length(p_weekdays, 1) IS NULL THEN
            RETURN p_from + (p_interval * 7 || ' days')::interval;
        END IF;
        LOOP
            v_next := v_next + interval '1 day';
            v_guard := v_guard + 1;
            v_dow := EXTRACT(dow FROM v_next)::int;
            EXIT WHEN v_dow = ANY (p_weekdays) OR v_guard > 370;
        END LOOP;
        RETURN v_next;
    END IF;
    RETURN p_from;
END $$;

-- Функция app.due_reminders предназначена для получения сработавших напоминаний.
CREATE OR REPLACE FUNCTION app.due_reminders()
RETURNS TABLE (id uuid, user_id uuid, title text, recur_freq text,
               recur_interval int, recur_weekdays int[])
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT id, user_id, title, recur_freq, recur_interval, recur_weekdays
      FROM app.reminders
     WHERE active AND remind_at <= now()
       AND (last_fired IS NULL OR last_fired < remind_at)
$$;

-- Функция app.advance_reminder предназначена для сдвига повторяющегося напоминания или отключения разового.
CREATE OR REPLACE FUNCTION app.advance_reminder(p_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE r app.reminders%ROWTYPE;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    IF r.recur_freq = 'none' THEN
        UPDATE app.reminders SET active = false, last_fired = now() WHERE id = p_id;
    ELSE
        UPDATE app.reminders
           SET last_fired = now(),
               remind_at = app.next_reminder_at(remind_at, recur_freq, recur_interval, recur_weekdays)
         WHERE id = p_id;
    END IF;
END $$;

GRANT EXECUTE ON FUNCTION app.next_reminder_at(timestamptz, text, int, int[]) TO app_user;
GRANT EXECUTE ON FUNCTION app.due_reminders() TO app_user;
GRANT EXECUTE ON FUNCTION app.advance_reminder(uuid) TO app_user;

-- Столбец notifications.category: категория уведомления.
ALTER TABLE app.notifications
    ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'other';

-- Функция app.notify_cat предназначена для создания уведомления с категорией и проверкой настроек: при отключённой
-- категории уведомление не создаётся. Категории: assigned (назначение исполнителем), granted (доступ к задаче),
-- comment (комментарий), step (чек-лист), task (изменения задачи), reminder (напоминания), other (прочее).
CREATE OR REPLACE FUNCTION app.notify_cat(
    p_user uuid, p_body text, p_category text,
    p_board uuid DEFAULT NULL, p_task uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_enabled boolean;
BEGIN
    SELECT enabled INTO v_enabled
      FROM app.notification_prefs
     WHERE user_id = p_user AND category = p_category;
    -- Отсутствие строки настроек означает, что категория включена.
    IF v_enabled IS NOT NULL AND v_enabled = false THEN
        RETURN; -- категория отключена пользователем
    END IF;
    RETURN QUERY
        INSERT INTO app.notifications (user_id, body, board_id, task_id, category)
        VALUES (p_user, p_body, p_board, p_task, p_category)
        RETURNING notifications.id, notifications.created_at;
END $$;


-- Функция app.task_access предназначена для определения уровня доступа к задаче по порядку убывания силы права:
-- владелец или редактор проекта — edit; автор задачи — edit; исполнитель — contribute; исполнитель пункта чек-листа —
-- contribute; точечное право — по праву; читатель проекта — read; иначе NULL.
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Автор задачи имеет полный доступ.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'edit';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    IF v_role = 'reader' THEN
        RETURN 'read';
    END IF;

    RETURN NULL;
END $$;

-- Функция app.can_see_board предназначена для проверки видимости проекта: участник либо обладатель видимой задачи.
CREATE OR REPLACE FUNCTION app.can_see_board(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_role(p_board, p_user) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
             WHERE t.board_id = p_board
               AND (t.created_by IN (SELECT app.effective_users(p_user))
                    OR EXISTS (SELECT 1 FROM app.task_assignees a
                                WHERE a.task_id = t.id
                                  AND a.user_id IN (SELECT app.effective_users(p_user)))
                    OR EXISTS (SELECT 1 FROM app.task_grants g
                                WHERE g.task_id = t.id
                                  AND g.user_id IN (SELECT app.effective_users(p_user)))
                    OR EXISTS (SELECT 1 FROM app.task_steps s
                                WHERE s.task_id = t.id
                                  AND s.assignee_id IN (SELECT app.effective_users(p_user)))))
$$;

-- Функция app.can_contribute_task предназначена для проверки права участия в задаче.
CREATE OR REPLACE FUNCTION app.can_contribute_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.task_access(p_task, p_user) IN ('edit', 'contribute')
        OR EXISTS (SELECT 1 FROM app.tasks t
                    WHERE t.id = p_task
                      AND t.created_by IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_edit_task предназначена для проверки права редактирования задачи.
CREATE OR REPLACE FUNCTION app.can_edit_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.task_access(p_task, p_user) = 'edit'
        OR EXISTS (SELECT 1 FROM app.tasks t
                    WHERE t.id = p_task
                      AND t.created_by IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_close_task предназначена для проверки права завершения: автор, редактор или владелец проекта.
CREATE OR REPLACE FUNCTION app.can_close_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner','editor')))
$$;

-- Функция app.can_move_task предназначена для проверки права перемещения задачи: автор, редактор или владелец.
CREATE OR REPLACE FUNCTION app.can_move_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

-- Функция app.is_task_assignee предназначена для проверки, что пользователь — исполнитель задачи.
CREATE OR REPLACE FUNCTION app.is_task_assignee(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.task_assignees a
                    WHERE a.task_id = p_task
                      AND a.user_id IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_assign_task предназначена для проверки права назначения исполнителей.
CREATE OR REPLACE FUNCTION app.can_assign_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (app.can_edit_task(p_task, p_user)
                OR t.created_by IN (SELECT app.effective_users(p_user))))
$$;

-- Функция app.board_title предназначена для получения названия проекта без учёта RLS.
CREATE OR REPLACE FUNCTION app.board_title(p_board uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT title FROM app.boards WHERE id = p_board $$;

-- Функция app.column_title предназначена для получения названия колонки без учёта RLS.
CREATE OR REPLACE FUNCTION app.column_title(p_column uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT title FROM app.columns WHERE id = p_column $$;

-- Функция app.ensure_assignee предназначена для добавления исполнителя при назначении в чек-листе.
CREATE OR REPLACE FUNCTION app.ensure_assignee(p_task uuid, p_assignee uuid, p_actor uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF p_assignee IS NULL THEN RETURN; END IF;
    INSERT INTO app.task_assignees (task_id, user_id)
    VALUES (p_task, p_assignee) ON CONFLICT DO NOTHING;
END $$;

-- Функция app.set_task_report предназначена для сохранения отчёта о выполнении; SECURITY DEFINER позволяет
-- участнику с уровнем contribute писать отчёт в обход политики tasks_update. Право проверяет обработчик.
CREATE OR REPLACE FUNCTION app.set_task_report(p_task uuid, p_report text, p_actor uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_old text;
BEGIN
    SELECT report INTO v_old FROM app.tasks WHERE id = p_task;
    UPDATE app.tasks SET report = COALESCE(p_report, '') WHERE id = p_task;
    IF COALESCE(v_old,'') IS DISTINCT FROM COALESCE(p_report,'') THEN
        INSERT INTO app.activity (task_id, actor_id, body)
        VALUES (p_task, p_actor,
                CASE WHEN COALESCE(p_report,'') = '' THEN 'Отчёт о выполнении очищен'
                     ELSE 'Обновлён отчёт о выполнении' END);
    END IF;
END $$;

-- Функция app.can_manage_steps предназначена для проверки права управлять составом чек-листа: автор, редактор или владелец.
CREATE OR REPLACE FUNCTION app.can_manage_steps(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

-- Функция app.can_check_step предназначена для проверки права отметки пункта: исполнитель пункта или менеджер чек-листа;
-- при отсутствии исполнителя — любой участник задачи.
CREATE OR REPLACE FUNCTION app.can_check_step(p_step uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_task uuid; v_assignee uuid;
BEGIN
    SELECT task_id, assignee_id INTO v_task, v_assignee FROM app.task_steps WHERE id = p_step;
    IF v_task IS NULL THEN RETURN false; END IF;
    IF app.can_manage_steps(v_task, p_user) THEN RETURN true; END IF;
    IF v_assignee IS NOT NULL THEN
        RETURN v_assignee IN (SELECT app.effective_users(p_user));
    END IF;
    RETURN app.can_contribute_task(v_task, p_user);
END $$;

-- Функция app.move_task (SECURITY DEFINER) предназначена для перемещения задачи: полные права — в любую колонку,
-- исполнитель — в любую, кроме колонки завершения. В журнал записываются исходная и целевая колонки.
CREATE OR REPLACE FUNCTION app.move_task(
    p_task uuid, p_user uuid, p_column uuid, p_position int)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_old_column uuid;
    v_is_done    boolean;
    v_col_title  text;
    v_old_title  text;
    v_pos        int := GREATEST(p_position, 0);
    v_can_full   boolean;
    v_is_assignee boolean;
    v_target_done boolean;
BEGIN
    v_can_full    := app.can_move_task(p_task, p_user);
    v_is_assignee := app.is_task_assignee(p_task, p_user);
    IF NOT v_can_full AND NOT v_is_assignee THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    SELECT t.column_id INTO v_old_column
      FROM app.tasks t
     WHERE t.id = p_task
       AND EXISTS (SELECT 1 FROM app.columns c WHERE c.id = p_column AND c.board_id = t.board_id)
     FOR UPDATE;
    IF v_old_column IS NULL THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    SELECT is_done INTO v_target_done FROM app.columns WHERE id = p_column;
    IF NOT v_can_full AND v_is_assignee AND v_target_done THEN
        RAISE EXCEPTION 'move_to_done_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    UPDATE app.tasks SET position = position + 1
     WHERE column_id = p_column AND position >= v_pos AND id <> p_task;
    UPDATE app.tasks SET column_id = p_column, position = v_pos WHERE id = p_task;

    WITH ordered AS (
        SELECT id, row_number() OVER (PARTITION BY column_id ORDER BY position, updated_at) - 1 AS pos
          FROM app.tasks WHERE column_id = ANY (ARRAY[v_old_column, p_column]))
    UPDATE app.tasks t SET position = o.pos FROM ordered o
     WHERE t.id = o.id AND t.position <> o.pos;

    IF v_old_column <> p_column THEN
        SELECT title, is_done INTO v_col_title, v_is_done FROM app.columns WHERE id = p_column;
        SELECT title INTO v_old_title FROM app.columns WHERE id = v_old_column;
        UPDATE app.tasks SET completed_at = CASE WHEN v_is_done THEN now() ELSE NULL END WHERE id = p_task;
        INSERT INTO app.activity (task_id, actor_id, body)
        VALUES (p_task, p_user, 'Перемещена из «' || COALESCE(v_old_title,'—') || '» в «' || v_col_title || '»');
    END IF;
    RETURN v_old_column;
END $$;

-- Функция app.spawn_recurrence предназначена для создания следующего экземпляра периодической задачи при завершении;
-- еженедельно без выбранных дней — следующий понедельник.
CREATE OR REPLACE FUNCTION app.spawn_recurrence(p_task uuid, p_actor uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r       app.tasks%ROWTYPE;
    v_base  date;
    v_next  date;
    v_col   uuid;
    v_new   uuid := gen_random_uuid();
    v_guard int := 0;
    v_dow   int;
BEGIN
    SELECT * INTO r FROM app.tasks WHERE id = p_task;
    IF NOT FOUND OR r.recur_freq = 'none' THEN RETURN NULL; END IF;

    v_base := COALESCE(r.due_date, current_date);

    IF r.recur_freq = 'daily' THEN
        v_next := v_base + (r.recur_interval || ' days')::interval;
    ELSIF r.recur_freq = 'monthly' THEN
        v_next := (v_base + (r.recur_interval || ' months')::interval)::date;
        IF r.recur_monthday IS NOT NULL THEN
            v_next := LEAST(
                date_trunc('month', v_next)::date + (r.recur_monthday - 1),
                (date_trunc('month', v_next) + interval '1 month - 1 day')::date);
        END IF;
    ELSIF r.recur_freq = 'weekly' THEN
        IF array_length(r.recur_weekdays, 1) IS NULL THEN
            -- Дни не выбраны: отсчёт от понедельника через (interval-1) полных недель; ISODOW: 1 — понедельник, 7 — воскресенье.
            v_next := (v_base + ((r.recur_interval - 1) * 7 || ' days')::interval)::date;
            v_next := v_next + ((8 - EXTRACT(isodow FROM v_next)::int) % 7);
            IF v_next <= v_base THEN
                v_next := v_next + 7;
            END IF;
        ELSE
            v_next := v_base;
            LOOP
                v_next := v_next + 1;
                v_guard := v_guard + 1;
                v_dow := EXTRACT(dow FROM v_next)::int; -- 0=Вс..6=Сб
                EXIT WHEN v_dow = ANY (r.recur_weekdays) OR v_guard > 370;
            END LOOP;
        END IF;
    END IF;

    IF v_next IS NULL THEN RETURN NULL; END IF;
    IF r.recur_until IS NOT NULL AND v_next > r.recur_until THEN RETURN NULL; END IF;

    SELECT id INTO v_col FROM app.columns
     WHERE board_id = r.board_id AND NOT is_done ORDER BY position LIMIT 1;
    IF v_col IS NULL THEN RETURN NULL; END IF;

    INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
                           due_date, tags, incoming_number, incoming_date, position, created_by,
                           recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
    VALUES (v_new, r.board_id, v_col, r.title, r.description, r.priority, r.color,
            v_next, r.tags, r.incoming_number, r.incoming_date,
            COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = v_col), 0), r.created_by,
            r.recur_freq, r.recur_interval, r.recur_weekdays, r.recur_monthday, r.recur_until);

    INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
    SELECT v_new, body, false, position, assignee_id, due_date, created_by
      FROM app.task_steps WHERE task_id = p_task;

    INSERT INTO app.task_assignees (task_id, user_id)
    SELECT v_new, user_id FROM app.task_assignees WHERE task_id = p_task
    ON CONFLICT DO NOTHING;

    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (v_new, p_actor, 'Создана по расписанию (повторение задачи)');
    RETURN v_new;
END $$;


-- Политика tasks_insert: создавать задачу может любой участник проекта.
DROP POLICY IF EXISTS tasks_insert ON app.tasks;
CREATE POLICY tasks_insert ON app.tasks FOR INSERT
    WITH CHECK (
        app.board_role(board_id, app.current_user_id()) IS NOT NULL
        AND created_by = app.current_user_id());

-- Политика tasks_update: USING и WITH CHECK используют can_edit_task (владелец, редактор проекта или автор задачи).
DROP POLICY IF EXISTS tasks_update ON app.tasks;
CREATE POLICY tasks_update ON app.tasks FOR UPDATE
    USING (app.can_edit_task(id, app.current_user_id()))
    WITH CHECK (app.can_edit_task(id, app.current_user_id()));

DROP POLICY IF EXISTS tasks_delete ON app.tasks;
CREATE POLICY tasks_delete ON app.tasks FOR DELETE
    USING (app.can_edit_task(id, app.current_user_id()));

-- Политика columns_select: колонки видит любой, кто видит проект.
DROP POLICY IF EXISTS columns_select ON app.columns;
CREATE POLICY columns_select ON app.columns FOR SELECT
    USING (app.can_see_board(board_id, app.current_user_id()));

-- Политика task_assignees_write: назначать и снимать исполнителей может редактирующий задачу или её автор.
DROP POLICY IF EXISTS task_assignees_write ON app.task_assignees;
CREATE POLICY task_assignees_write ON app.task_assignees FOR INSERT
    WITH CHECK (app.can_assign_task(task_id, app.current_user_id()));
DROP POLICY IF EXISTS task_assignees_delete ON app.task_assignees;
CREATE POLICY task_assignees_delete ON app.task_assignees FOR DELETE
    USING (app.can_assign_task(task_id, app.current_user_id()));

-- Политики task_steps: состав правит менеджер чек-листа, отметка проверяется по can_check_step в обработчике.
DROP POLICY IF EXISTS task_steps_insert ON app.task_steps;
CREATE POLICY task_steps_insert ON app.task_steps FOR INSERT
    WITH CHECK (app.can_manage_steps(task_id, app.current_user_id()));
DROP POLICY IF EXISTS task_steps_update ON app.task_steps;
CREATE POLICY task_steps_update ON app.task_steps FOR UPDATE
    USING (
        app.can_manage_steps(task_id, app.current_user_id())
        OR app.can_contribute_task(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id())))
    WITH CHECK (
        app.can_manage_steps(task_id, app.current_user_id())
        OR app.can_contribute_task(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id())));
DROP POLICY IF EXISTS task_steps_delete ON app.task_steps;
CREATE POLICY task_steps_delete ON app.task_steps FOR DELETE
    USING (app.can_manage_steps(task_id, app.current_user_id()));

-- Функция app.task_watchers предназначена для получения наблюдателей задачи для событий и уведомлений: участники проекта,
-- исполнители, обладатели точечных прав, исполнители пунктов и их заместители.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
        UNION SELECT s.assignee_id FROM app.task_steps s
               WHERE s.task_id = p_task AND s.assignee_id IS NOT NULL
    )
    SELECT user_id FROM base
    UNION
    SELECT d.deputy_id FROM base b
      JOIN app.delegations d ON d.grantor_id = b.user_id
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;



-- #####################################################################
-- Миграция 0006_views.sql
-- #####################################################################

\echo '--> 0006_views.sql'

-- Скрипт предназначен для создания отметок о просмотре задач и проектов: таблица, индекс, политика, триггеры уборки,
-- функции записи и чтения отметок и расчёта времени последнего изменения. Позволяет показывать, что изменилось
-- с момента последнего просмотра конкретным пользователем.


SET search_path = app, public;

-- Таблица app.view_marks предназначена для хранения отметок о просмотре. entity_id не имеет внешнего ключа:
-- таблица хранит отметки и по задачам, и по проектам; записи удаляются триггерами.
CREATE TABLE IF NOT EXISTS app.view_marks (
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    kind      text NOT NULL CHECK (kind IN ('task', 'board')),
    entity_id uuid NOT NULL,
    viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, kind, entity_id)
);

-- Индекс view_marks_entity_idx предназначен для запроса «кто смотрел задачу».
CREATE INDEX IF NOT EXISTS view_marks_entity_idx
    ON app.view_marks (kind, entity_id);

ALTER TABLE app.view_marks ENABLE ROW LEVEL SECURITY;

-- Политика view_marks_own: прямой доступ только к собственным строкам; отметки других выдаются SECURITY DEFINER-функциями.
DROP POLICY IF EXISTS view_marks_own ON app.view_marks;
CREATE POLICY view_marks_own ON app.view_marks FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.view_marks TO app_user;

-- Функция app.drop_view_marks предназначена для удаления отметок вместе с сущностью; SECURITY DEFINER, так как удаляются строки всех пользователей.
CREATE OR REPLACE FUNCTION app.drop_view_marks() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    DELETE FROM app.view_marks
     WHERE kind = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN OLD;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_view_marks ON app.tasks;
-- Триггер tasks_drop_view_marks предназначен для удаления отметок при удалении задачи.
CREATE TRIGGER tasks_drop_view_marks AFTER DELETE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('task');

DROP TRIGGER IF EXISTS boards_drop_view_marks ON app.boards;
-- Триггер boards_drop_view_marks предназначен для удаления отметок при удалении проекта.
CREATE TRIGGER boards_drop_view_marks AFTER DELETE ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('board');


-- Функция app.mark_seen предназначена для отметки сущности просмотренной; видимость проверяется внутри функции (SECURITY DEFINER).
CREATE OR REPLACE FUNCTION app.mark_seen(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_at timestamptz;
BEGIN
    IF p_user IS NULL OR p_entity IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_kind NOT IN ('task', 'board') THEN
        RAISE EXCEPTION 'unknown_view_kind';
    END IF;

    IF p_kind = 'task' AND NOT app.can_see_task(p_entity, p_user) THEN
        RETURN NULL;
    END IF;
    IF p_kind = 'board' AND NOT app.can_see_board(p_entity, p_user) THEN
        RETURN NULL;
    END IF;

    INSERT INTO app.view_marks (user_id, kind, entity_id, viewed_at)
    VALUES (p_user, p_kind, p_entity, now())
    ON CONFLICT (user_id, kind, entity_id)
    DO UPDATE SET viewed_at = now()
    RETURNING viewed_at INTO v_at;

    RETURN v_at;
END $$;

-- Функция app.seen_at предназначена для получения времени последнего просмотра сущности пользователем.
CREATE OR REPLACE FUNCTION app.seen_at(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.viewed_at FROM app.view_marks v
     WHERE v.user_id = p_user AND v.kind = p_kind AND v.entity_id = p_entity
$$;

-- Функция app.assignees_seen предназначена для получения исполнителей задачи, открывавших её.
CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- Функция app.task_activity_at предназначена для получения времени последнего изменения задачи: максимум из tasks.updated_at
-- и последней записи журнала, исключая действия указанного пользователя.
CREATE OR REPLACE FUNCTION app.task_activity_at(p_task uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               t.updated_at,
               COALESCE((SELECT max(a.created_at) FROM app.activity a
                          WHERE a.task_id = t.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        t.updated_at))
      FROM app.tasks t WHERE t.id = p_task
$$;

-- Функция app.board_activity_at предназначена для получения времени последнего изменения проекта или любой его задачи
-- (SECURITY DEFINER), исключая действия указанного пользователя.
CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(t.updated_at) FROM app.tasks t
                          WHERE t.board_id = b.id AND NOT t.archived),
                        b.updated_at),
               COALESCE((SELECT max(a.created_at)
                           FROM app.activity a
                           JOIN app.tasks t ON t.id = a.task_id
                          WHERE t.board_id = b.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;

GRANT EXECUTE ON FUNCTION app.mark_seen(text, uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.seen_at(text, uuid, uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.task_activity_at(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.board_activity_at(uuid, uuid)      TO app_user;




-- #####################################################################
-- Миграция 0007_editor_rights.sql
-- #####################################################################

\echo '--> 0007_editor_rights.sql'

-- Скрипт предназначен для передачи редактору проекта права управлять участниками и настройками проекта.
-- Удаление проекта остаётся за владельцем; роль владельца изменить нельзя.


SET search_path = app, public;

-- Политика boards_update: настройки проекта (название, описание, фон, положение в дереве) изменяет владелец или редактор.
DROP POLICY IF EXISTS boards_update ON app.boards;
CREATE POLICY boards_update ON app.boards FOR UPDATE
    USING (app.can_edit_board(id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(id, app.current_user_id()));

-- Политики board_members: состав участников изменяют владелец и редактор; условие role <> 'owner' проверяется
-- в USING и в WITH CHECK.
DROP POLICY IF EXISTS board_members_write ON app.board_members;
CREATE POLICY board_members_write ON app.board_members FOR INSERT
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

DROP POLICY IF EXISTS board_members_update ON app.board_members;
CREATE POLICY board_members_update ON app.board_members FOR UPDATE
    USING (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    )
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

-- Политика board_members_delete: владелец и редактор убирают любого, кроме владельца; участник может выйти сам.
DROP POLICY IF EXISTS board_members_delete ON app.board_members;
CREATE POLICY board_members_delete ON app.board_members FOR DELETE
    USING (
        (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );



-- #####################################################################
-- Миграция 0008_reminder_task.sql
-- #####################################################################

\echo '--> 0008_reminder_task.sql'

-- Скрипт предназначен для необязательной привязки напоминания к задаче: столбец, функция выдачи сработавших
-- напоминаний с задачей и функция получения названия задачи с проверкой видимости.


SET search_path = app, public;

ALTER TABLE app.reminders
    ADD COLUMN IF NOT EXISTS task_id uuid REFERENCES app.tasks(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS reminders_task_idx ON app.reminders (task_id)
    WHERE task_id IS NOT NULL;

-- Пересоздание app.due_reminders: функция возвращает задачу; DROP необходим при изменении набора столбцов результата.
DROP FUNCTION IF EXISTS app.due_reminders();

-- Функция app.due_reminders предназначена для получения сработавших напоминаний вместе с привязанной задачей.
CREATE FUNCTION app.due_reminders()
RETURNS TABLE (id uuid, user_id uuid, title text, recur_freq text,
               recur_interval int, recur_weekdays int[], task_id uuid)
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT id, user_id, title, recur_freq, recur_interval, recur_weekdays, task_id
      FROM app.reminders
     WHERE active AND remind_at <= now()
       AND (last_fired IS NULL OR last_fired < remind_at)
$$;

GRANT EXECUTE ON FUNCTION app.due_reminders() TO app_user;


-- Функция app.task_title_visible предназначена для получения названия задачи для списка напоминаний;
-- SECURITY DEFINER с проверкой видимости: недоступной задачи название не раскрывается.
CREATE OR REPLACE FUNCTION app.task_title_visible(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_see_task(t.id, p_user)
$$;

GRANT EXECUTE ON FUNCTION app.task_title_visible(uuid, uuid) TO app_user;


-- #####################################################################
-- Миграция 0009_chats.sql
-- #####################################################################

\echo '--> 0009_chats.sql'

-- Скрипт предназначен для создания переписки между сотрудниками (личные и групповые чаты, файлы, правка и удаление
-- сообщений, владелец группы) и для пересчёта отметок просмотра задачи (три состояния).


SET search_path = app, public;

-- Таблица app.chats предназначена для хранения чатов.

CREATE TABLE IF NOT EXISTS app.chats (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    kind       text NOT NULL CHECK (kind IN ('direct', 'group')),
    -- У личного чата названия нет: он называется именем собеседника.
    title      text NOT NULL DEFAULT '',
    owner_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.chat_members предназначена для хранения участников чатов.
CREATE TABLE IF NOT EXISTS app.chat_members (
    chat_id      uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    user_id      uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    added_at     timestamptz NOT NULL DEFAULT now(),
    -- Момент, до которого прочитана переписка; число непрочитанных считается по created_at сообщений.
    last_read_at timestamptz NOT NULL DEFAULT to_timestamp(0),
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS chat_members_user_idx ON app.chat_members (user_id);

-- Таблица app.chat_messages предназначена для хранения сообщений чатов.
CREATE TABLE IF NOT EXISTS app.chat_messages (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id    uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    author_id  uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL DEFAULT '',
    -- Файл — необязательное приложение; одно на сообщение.
    file_id    uuid REFERENCES app.files(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    -- Мягкое удаление: тело очищается, сообщение остаётся в ленте.
    deleted_at timestamptz,
    CHECK (body <> '' OR file_id IS NOT NULL OR deleted_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS chat_messages_chat_idx
    ON app.chat_messages (chat_id, created_at DESC);

-- Функция app.in_chat предназначена для проверки участия в чате (SECURITY DEFINER; исключает рекурсию политик).
CREATE OR REPLACE FUNCTION app.in_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.chat_members m
                    WHERE m.chat_id = p_chat AND m.user_id = p_user)
$$;

-- Функция app.chat_owner предназначена для получения владельца чата.
CREATE OR REPLACE FUNCTION app.chat_owner(p_chat uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT owner_id FROM app.chats WHERE id = p_chat
$$;

ALTER TABLE app.chats         ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_members  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_messages ENABLE ROW LEVEL SECURITY;

-- Политика chats_select: чат виден участникам; состав задаётся отдельно в той же транзакции, что и создание.
DROP POLICY IF EXISTS chats_select ON app.chats;
CREATE POLICY chats_select ON app.chats FOR SELECT
    USING (app.in_chat(id, app.current_user_id()));

DROP POLICY IF EXISTS chats_insert ON app.chats;
CREATE POLICY chats_insert ON app.chats FOR INSERT
    WITH CHECK (app.current_user_id() IS NOT NULL);

-- Политика chats_update: групповой чат переименовывает владелец; личный не переименовывается.
DROP POLICY IF EXISTS chats_update ON app.chats;
CREATE POLICY chats_update ON app.chats FOR UPDATE
    USING (kind = 'group' AND owner_id = app.current_user_id())
    WITH CHECK (kind = 'group' AND owner_id = app.current_user_id());

DROP POLICY IF EXISTS chats_delete ON app.chats;
CREATE POLICY chats_delete ON app.chats FOR DELETE
    USING (owner_id = app.current_user_id());

-- Политики chat_members: состав виден участникам; менять его может владелец группового чата, выйти можно всегда.
DROP POLICY IF EXISTS chat_members_select ON app.chat_members;
CREATE POLICY chat_members_select ON app.chat_members FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_members_insert ON app.chat_members;
CREATE POLICY chat_members_insert ON app.chat_members FOR INSERT
    WITH CHECK (
        app.chat_owner(chat_id) = app.current_user_id()
        -- Первый участник добавляется в момент создания чата.
        OR user_id = app.current_user_id()
        OR app.chat_owner(chat_id) IS NULL
    );

-- Политика chat_members_update: участник изменяет только собственную строку (отметка прочтения).
DROP POLICY IF EXISTS chat_members_update ON app.chat_members;
CREATE POLICY chat_members_update ON app.chat_members FOR UPDATE
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

DROP POLICY IF EXISTS chat_members_delete ON app.chat_members;
CREATE POLICY chat_members_delete ON app.chat_members FOR DELETE
    USING (
        app.chat_owner(chat_id) = app.current_user_id()
        OR user_id = app.current_user_id()
    );

-- Политики chat_messages: читают участники, пишет участник от своего имени, правит и удаляет автор.
DROP POLICY IF EXISTS chat_messages_select ON app.chat_messages;
CREATE POLICY chat_messages_select ON app.chat_messages FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_messages_insert ON app.chat_messages;
CREATE POLICY chat_messages_insert ON app.chat_messages FOR INSERT
    WITH CHECK (app.in_chat(chat_id, app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.chats         TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_members  TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_messages TO app_user;
GRANT EXECUTE ON FUNCTION app.in_chat(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.chat_owner(uuid)    TO app_user;

-- Политика files_select_chat: файл переписки виден участникам чата.
DROP POLICY IF EXISTS files_select_chat ON app.files;
CREATE POLICY files_select_chat ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chat_messages m
                    WHERE m.file_id = app.files.id
                      AND app.in_chat(m.chat_id, app.current_user_id())));

-- Функция app.ensure_direct_chat предназначена для получения или создания личного чата пары пользователей без дублей.
CREATE OR REPLACE FUNCTION app.ensure_direct_chat(p_a uuid, p_b uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
BEGIN
    IF p_a IS NULL OR p_b IS NULL OR p_a = p_b THEN
        RAISE EXCEPTION 'bad_direct_chat';
    END IF;

    SELECT c.id INTO v_id
      FROM app.chats c
      JOIN app.chat_members m1 ON m1.chat_id = c.id AND m1.user_id = p_a
      JOIN app.chat_members m2 ON m2.chat_id = c.id AND m2.user_id = p_b
     WHERE c.kind = 'direct'
     LIMIT 1;

    IF v_id IS NOT NULL THEN
        RETURN v_id;
    END IF;

    INSERT INTO app.chats (kind, owner_id) VALUES ('direct', p_a) RETURNING id INTO v_id;
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_a), (v_id, p_b);
    RETURN v_id;
END $$;

GRANT EXECUTE ON FUNCTION app.ensure_direct_chat(uuid, uuid) TO app_user;

-- Функция app.chat_watchers предназначена для получения состава чата для рассылки событий (SECURITY DEFINER:
-- рассылка выполняется без пользовательского контекста).
CREATE OR REPLACE FUNCTION app.chat_watchers(p_chat uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT user_id FROM app.chat_members WHERE chat_id = p_chat
$$;

GRANT EXECUTE ON FUNCTION app.chat_watchers(uuid) TO app_user;

-- Функция app.chat_unread_total предназначена для подсчёта непрочитанных по всем чатам.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > m.last_read_at
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_unread_total(uuid) TO app_user;

-- Раздел 2: отметки просмотра задачи. Состояния: серая галочка — исполнитель открывал задачу; зелёная — открывал после
-- последнего изменения; две зелёные — отметил свою часть выполненной. Последнее изменение — максимум из tasks.updated_at
-- и последней записи журнала, исключая действия самого исполнителя.
-- Функция app.assignees_seen предназначена для получения исполнителей, открывавших задачу.

CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- Функция app.assignees_fresh предназначена для получения исполнителей, чей просмотр новее последнего изменения задачи.
CREATE OR REPLACE FUNCTION app.assignees_fresh(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task'
       AND v.entity_id = p_task
       AND v.viewed_at >= app.task_activity_at(p_task, v.user_id)
$$;

GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_fresh(uuid) TO app_user;



-- #####################################################################
-- Миграция 0010_chat_polls.sql
-- #####################################################################

\echo '--> 0010_chat_polls.sql'

-- Скрипт предназначен для доработок переписки и задач: создание группового чата одной функцией, удаление чата и очистка
-- переписки, опросы в чатах, возврат задачи в прежнюю колонку, настройка уведомлений по чужим задачам.
-- Выполняется от app_owner после 0009_chats.sql, идемпотентен.


SET search_path = app, public;

-- Раздел 1: создание группового чата. Функция app.create_group_chat заменяет последовательность INSERT в chats и chat_members,
-- нарушавшую политику RLS из-за RETURNING.
CREATE OR REPLACE FUNCTION app.create_group_chat(
    p_owner uuid, p_title text, p_members uuid[])
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
    v_member uuid;
BEGIN
    IF p_owner IS NULL OR coalesce(btrim(p_title), '') = '' THEN
        RAISE EXCEPTION 'bad_group_chat';
    END IF;

    INSERT INTO app.chats (kind, title, owner_id)
    VALUES ('group', btrim(p_title), p_owner)
    RETURNING id INTO v_id;

    -- Владелец всегда является участником.
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_owner);

    FOREACH v_member IN ARRAY COALESCE(p_members, ARRAY[]::uuid[]) LOOP
        IF v_member IS NOT NULL AND v_member <> p_owner THEN
            INSERT INTO app.chat_members (chat_id, user_id)
            VALUES (v_id, v_member) ON CONFLICT DO NOTHING;
        END IF;
    END LOOP;

    RETURN v_id;
END $$;

GRANT EXECUTE ON FUNCTION app.create_group_chat(uuid, text, uuid[]) TO app_user;

-- Раздел 2: удаление чата и очистка переписки. Групповой чат удаляет владелец, личный — любой из двух участников.
-- Функция app.can_manage_chat предназначена для проверки права удаления и очистки чата.
CREATE OR REPLACE FUNCTION app.can_manage_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.chats c
         WHERE c.id = p_chat
           AND (c.owner_id = p_user
                OR (c.kind = 'direct' AND app.in_chat(p_chat, p_user)))
    )
$$;

-- Функция app.delete_chat предназначена для удаления чата.
CREATE OR REPLACE FUNCTION app.delete_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF NOT app.can_manage_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;
    -- Сообщения и состав удаляются каскадом.
    DELETE FROM app.chats WHERE id = p_chat;
    RETURN true;
END $$;

-- Функция app.clear_chat предназначена для очистки переписки с сохранением чата.
CREATE OR REPLACE FUNCTION app.clear_chat(p_chat uuid, p_user uuid)
RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_count bigint;
BEGIN
    IF NOT app.can_manage_chat(p_chat, p_user) THEN
        RETURN -1;
    END IF;
    WITH gone AS (DELETE FROM app.chat_messages WHERE chat_id = p_chat RETURNING 1)
    SELECT count(*) INTO v_count FROM gone;
    -- Отметки прочтения сбрасываются.
    UPDATE app.chat_members SET last_read_at = now() WHERE chat_id = p_chat;
    RETURN v_count;
END $$;

GRANT EXECUTE ON FUNCTION app.can_manage_chat(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_chat(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.clear_chat(uuid, uuid)      TO app_user;

-- Раздел 3: опросы. Опрос хранится рядом с сообщением особого вида и удаляется вместе с ним.
-- Таблица app.chat_polls предназначена для хранения опросов.
CREATE TABLE IF NOT EXISTS app.chat_polls (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid NOT NULL REFERENCES app.chat_messages(id) ON DELETE CASCADE,
    question   text NOT NULL,
    -- Признак выбора нескольких вариантов.
    multiple   boolean NOT NULL DEFAULT false,
    closed_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_polls_message_idx ON app.chat_polls (message_id);

-- Таблица app.chat_poll_options предназначена для хранения вариантов опросов.
CREATE TABLE IF NOT EXISTS app.chat_poll_options (
    id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    poll_id  uuid NOT NULL REFERENCES app.chat_polls(id) ON DELETE CASCADE,
    body     text NOT NULL,
    position int NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS chat_poll_options_poll_idx ON app.chat_poll_options (poll_id, position);

-- Таблица app.chat_poll_votes предназначена для хранения голосов.
CREATE TABLE IF NOT EXISTS app.chat_poll_votes (
    option_id uuid NOT NULL REFERENCES app.chat_poll_options(id) ON DELETE CASCADE,
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    voted_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (option_id, user_id)
);

ALTER TABLE app.chat_polls        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_poll_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_poll_votes   ENABLE ROW LEVEL SECURITY;

-- Функция app.poll_chat предназначена для определения чата опроса: видимость опроса определяется чатом.
CREATE OR REPLACE FUNCTION app.poll_chat(p_poll uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.chat_id FROM app.chat_polls p
      JOIN app.chat_messages m ON m.id = p.message_id
     WHERE p.id = p_poll
$$;

DROP POLICY IF EXISTS chat_polls_select ON app.chat_polls;
CREATE POLICY chat_polls_select ON app.chat_polls FOR SELECT
    USING (app.in_chat(app.poll_chat(id), app.current_user_id()));

DROP POLICY IF EXISTS chat_poll_options_select ON app.chat_poll_options;
CREATE POLICY chat_poll_options_select ON app.chat_poll_options FOR SELECT
    USING (app.in_chat(app.poll_chat(poll_id), app.current_user_id()));

-- Политика chat_poll_votes_select: голоса видны всем участникам чата.
DROP POLICY IF EXISTS chat_poll_votes_select ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_select ON app.chat_poll_votes FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chat_poll_options o
                    WHERE o.id = option_id
                      AND app.in_chat(app.poll_chat(o.poll_id), app.current_user_id())));

-- Политика chat_poll_votes_write: голосовать можно только за себя и только в незакрытом опросе.
DROP POLICY IF EXISTS chat_poll_votes_write ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_write ON app.chat_poll_votes FOR INSERT
    WITH CHECK (
        user_id = app.current_user_id()
        AND EXISTS (
            SELECT 1 FROM app.chat_poll_options o
              JOIN app.chat_polls p ON p.id = o.poll_id
             WHERE o.id = option_id
               AND p.closed_at IS NULL
               AND app.in_chat(app.poll_chat(o.poll_id), app.current_user_id()))
    );

DROP POLICY IF EXISTS chat_poll_votes_delete ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_delete ON app.chat_poll_votes FOR DELETE
    USING (user_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_polls        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_poll_options TO app_user;
GRANT SELECT, INSERT, DELETE         ON app.chat_poll_votes   TO app_user;
GRANT EXECUTE ON FUNCTION app.poll_chat(uuid) TO app_user;

-- Функция app.create_poll предназначена для создания опроса одной операцией: сообщение, опрос и варианты (SECURITY DEFINER).
CREATE OR REPLACE FUNCTION app.create_poll(
    p_chat uuid, p_author uuid, p_question text, p_options text[], p_multiple boolean)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_msg uuid;
    v_poll uuid;
    v_opt text;
    v_pos int := 0;
BEGIN
    IF NOT app.in_chat(p_chat, p_author) THEN
        RAISE EXCEPTION 'not_member';
    END IF;
    IF coalesce(btrim(p_question), '') = '' OR array_length(p_options, 1) < 2 THEN
        RAISE EXCEPTION 'bad_poll';
    END IF;

    -- Текст сообщения содержит вопрос опроса.
    INSERT INTO app.chat_messages (chat_id, author_id, body)
    VALUES (p_chat, p_author, btrim(p_question))
    RETURNING id INTO v_msg;

    INSERT INTO app.chat_polls (message_id, question, multiple)
    VALUES (v_msg, btrim(p_question), COALESCE(p_multiple, false))
    RETURNING id INTO v_poll;

    FOREACH v_opt IN ARRAY p_options LOOP
        IF coalesce(btrim(v_opt), '') <> '' THEN
            INSERT INTO app.chat_poll_options (poll_id, body, position)
            VALUES (v_poll, btrim(v_opt), v_pos);
            v_pos := v_pos + 1;
        END IF;
    END LOOP;

    UPDATE app.chats SET updated_at = now() WHERE id = p_chat;
    RETURN v_msg;
END $$;

-- Функция app.cast_vote предназначена для подачи голоса одной операцией (в опросе с одним вариантом прежний голос заменяется).
CREATE OR REPLACE FUNCTION app.cast_vote(p_option uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_poll uuid;
    v_multiple boolean;
    v_closed timestamptz;
    v_exists boolean;
BEGIN
    SELECT o.poll_id, p.multiple, p.closed_at
      INTO v_poll, v_multiple, v_closed
      FROM app.chat_poll_options o
      JOIN app.chat_polls p ON p.id = o.poll_id
     WHERE o.id = p_option;

    IF v_poll IS NULL OR NOT app.in_chat(app.poll_chat(v_poll), p_user) THEN
        RETURN false;
    END IF;
    IF v_closed IS NOT NULL THEN
        RETURN false;
    END IF;

    SELECT EXISTS (SELECT 1 FROM app.chat_poll_votes
                    WHERE option_id = p_option AND user_id = p_user)
      INTO v_exists;

    IF v_exists THEN
        -- Повторный голос за тот же вариант снимает голос.
        DELETE FROM app.chat_poll_votes WHERE option_id = p_option AND user_id = p_user;
        RETURN true;
    END IF;

    IF NOT v_multiple THEN
        DELETE FROM app.chat_poll_votes v
         USING app.chat_poll_options o
         WHERE v.option_id = o.id AND o.poll_id = v_poll AND v.user_id = p_user;
    END IF;

    INSERT INTO app.chat_poll_votes (option_id, user_id) VALUES (p_option, p_user);
    RETURN true;
END $$;

-- Функция app.close_poll предназначена для закрытия опроса автором.
CREATE OR REPLACE FUNCTION app.close_poll(p_poll uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_author uuid;
BEGIN
    SELECT m.author_id INTO v_author
      FROM app.chat_polls p JOIN app.chat_messages m ON m.id = p.message_id
     WHERE p.id = p_poll;
    IF v_author IS NULL OR v_author <> p_user THEN
        RETURN false;
    END IF;
    UPDATE app.chat_polls SET closed_at = now() WHERE id = p_poll AND closed_at IS NULL;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.create_poll(uuid, uuid, text, text[], boolean) TO app_user;
GRANT EXECUTE ON FUNCTION app.cast_vote(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.close_poll(uuid, uuid) TO app_user;

-- Раздел 4: возврат задачи в прежнюю колонку. При завершении запоминается колонка, из которой задача перенесена в «Готово».
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS prev_column_id uuid REFERENCES app.columns(id) ON DELETE SET NULL;

-- Раздел 5: уведомления по чужим задачам. Функция app.wants_foreign_task_notifs предназначена для проверки настройки получения
-- уведомлений о задачах, где пользователь не исполнитель.
CREATE OR REPLACE FUNCTION app.wants_foreign_task_notifs(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE((SELECT enabled FROM app.notification_prefs
                      WHERE user_id = p_user AND category = 'foreign_task'), true)
$$;

GRANT EXECUTE ON FUNCTION app.wants_foreign_task_notifs(uuid) TO app_user;



-- #####################################################################
-- Миграция 0011_reader_scope.sql
-- #####################################################################

\echo '--> 0011_reader_scope.sql'

-- Скрипт предназначен для ограничения видимости: участник проекта с ролью «исполнитель» видит только свои задачи.
-- Функция app.task_access пересоздаётся: членство в проекте само по себе не открывает все задачи.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Функция app.task_access предназначена для определения уровня доступа к задаче с ограничением видимости для роли «исполнитель».
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Автор задачи имеет полный доступ независимо от роли в проекте.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'edit';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    -- Исполнитель пункта чек-листа видит задачу целиком.
    IF EXISTS (SELECT 1 FROM app.task_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    -- Условие «читатель проекта видит все задачи» удалено: доступ определяется назначением, авторством или точечным правом.
    RETURN NULL;
END $$;



-- #####################################################################
-- Миграция 0012_chat_personal.sql
-- #####################################################################

\echo '--> 0012_chat_personal.sql'

-- Скрипт предназначен для удаления и очистки чата только у одного участника: личные отметки участника,
-- очистка у себя, удаление у себя, подсчёт непрочитанных с учётом личной границы и время голоса в опросе.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: личные отметки участника чата (граница видимости, скрытие чата).

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS cleared_at timestamptz NOT NULL DEFAULT to_timestamp(0);

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS hidden_at timestamptz;

-- Функция app.clear_chat_for_me предназначена для очистки переписки у одного участника: граница видимости и отметка прочтения сдвигаются к текущему моменту.
CREATE OR REPLACE FUNCTION app.clear_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;
    UPDATE app.chat_members
       SET cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

-- Функция app.delete_chat_for_me предназначена для удаления чата у одного участника: граница видимости и скрытие чата;
-- групповой чат при этом покидается.
CREATE OR REPLACE FUNCTION app.delete_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;

    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;

    IF v_kind = 'group' AND v_owner IS DISTINCT FROM p_user THEN
        DELETE FROM app.chat_members WHERE chat_id = p_chat AND user_id = p_user;
        RETURN true;
    END IF;

    -- Владелец группы и участники личного чата остаются в составе, чат скрывается из списка.
    UPDATE app.chat_members
       SET hidden_at = now(), cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.clear_chat_for_me(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_chat_for_me(uuid, uuid) TO app_user;

-- Функция app.chat_unread_total предназначена для подсчёта непрочитанных с учётом личной границы видимости.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > GREATEST(m.last_read_at, m.cleared_at)
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

-- Раздел 2: время голоса в опросе. Функция app.poll_option_votes предназначена для получения голосов варианта со временем голосования.
CREATE OR REPLACE FUNCTION app.poll_option_votes(p_option uuid)
RETURNS TABLE (user_id uuid, voted_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.user_id, v.voted_at
      FROM app.chat_poll_votes v
     WHERE v.option_id = p_option
     ORDER BY v.voted_at
$$;

GRANT EXECUTE ON FUNCTION app.poll_option_votes(uuid) TO app_user;



-- #####################################################################
-- Миграция 0013_watchers_visibility.sql
-- #####################################################################

\echo '--> 0013_watchers_visibility.sql'

-- Скрипт предназначен для ограничения уведомлений видимыми задачами и для отметок прочтения в переписке:
-- пересоздание app.task_watchers и функция app.chat_read_through.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Функция app.task_watchers предназначена для получения наблюдателей задачи, которые могут её открыть.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
    ),
    everyone AS (
        SELECT user_id FROM base
        UNION
        -- Заместитель получает те же уведомления, что и замещаемый.
        SELECT d.deputy_id FROM base b
          JOIN app.delegations d ON d.grantor_id = b.user_id
         WHERE current_date BETWEEN d.starts_at AND d.ends_at
    )
    -- Уведомление получает только тот, кто может открыть задачу (can_see_task).
    SELECT e.user_id FROM everyone e
     WHERE app.task_access(p_task, e.user_id) IS NOT NULL
$$;

-- Функция app.chat_read_through предназначена для определения момента, до которого переписку прочитали все остальные участники
-- (по last_read_at); используется для отметок «доставлено» и «прочитано».
CREATE OR REPLACE FUNCTION app.chat_read_through(p_chat uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT min(m.last_read_at)
      FROM app.chat_members m
     WHERE m.chat_id = p_chat AND m.user_id <> p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_read_through(uuid, uuid) TO app_user;



-- #####################################################################
-- Миграция 0014_chat_avatar.sql
-- #####################################################################

\echo '--> 0014_chat_avatar.sql'

-- Скрипт предназначен для хранения картинки группового чата: политика доступа к файлу и функция установки и снятия картинки.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

ALTER TABLE app.chats
    ADD COLUMN IF NOT EXISTS avatar_file_id uuid REFERENCES app.files(id) ON DELETE SET NULL;

-- Политика files_select_chat_avatar: картинка чата видна его участникам; дополняет существующие политики app.files (объединение по ИЛИ).
DROP POLICY IF EXISTS files_select_chat_avatar ON app.files;
CREATE POLICY files_select_chat_avatar ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chats c
                    WHERE c.avatar_file_id = app.files.id
                      AND app.in_chat(c.id, app.current_user_id())));

-- Функция app.set_chat_avatar предназначена для установки и снятия картинки с проверкой прав владельца группового чата.
CREATE OR REPLACE FUNCTION app.set_chat_avatar(p_chat uuid, p_user uuid, p_file uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;
    IF v_kind IS DISTINCT FROM 'group' OR v_owner IS DISTINCT FROM p_user THEN
        RETURN false;
    END IF;
    UPDATE app.chats SET avatar_file_id = p_file, updated_at = now() WHERE id = p_chat;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_chat_avatar(uuid, uuid, uuid) TO app_user;



-- #####################################################################
-- Миграция 0015_attachment_rules.sql
-- #####################################################################

\echo '--> 0015_attachment_rules.sql'

-- Скрипт предназначен для единых правил изменения вложений задач независимо от формата файла:
-- переименовать и удалить вложение может его автор или тот, кто вправе править задачу (политики attachments_update
-- и attachments_delete). Ограничение в один час отменено.
-- Выполняется от app_owner после 0014_chat_avatar.sql, идемпотентен:
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0015_attachment_rules.sql


SET search_path = app, public;

DROP POLICY IF EXISTS attachments_update ON app.attachments;
CREATE POLICY attachments_update ON app.attachments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    )
    WITH CHECK (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

DROP POLICY IF EXISTS attachments_delete ON app.attachments;
CREATE POLICY attachments_delete ON app.attachments FOR DELETE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );



-- #####################################################################
-- Миграция 0016_ready_for_review.sql
-- #####################################################################

\echo '--> 0016_ready_for_review.sql'

-- Скрипт предназначен для отметки «задача готова к сдаче», окна правки сообщений в переписке (как у комментариев)
-- и исправления настройки уведомлений по чужим задачам в функции app.notify_task_watchers.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: готовность к сдаче. Состояние между «в работе» и «завершено»: исполнитель закончил работу и ожидает приёмки.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS ready_at timestamptz,
    ADD COLUMN IF NOT EXISTS ready_by uuid REFERENCES app.users(id) ON DELETE SET NULL;

-- Функция app.set_task_ready предназначена для установки и снятия отметки готовности: ставит исполнитель, снимает исполнитель, автор или редактор проекта.
CREATE OR REPLACE FUNCTION app.set_task_ready(p_task uuid, p_user uuid, p_ready boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_assignee boolean;
    v_manage boolean;
BEGIN
    SELECT EXISTS (SELECT 1 FROM app.task_assignees a
                    WHERE a.task_id = p_task
                      AND a.user_id IN (SELECT app.effective_users(p_user)))
      INTO v_assignee;
    SELECT app.task_access(p_task, p_user) = 'edit' INTO v_manage;

    IF p_ready AND NOT v_assignee THEN
        RETURN false;
    END IF;
    IF NOT p_ready AND NOT (v_assignee OR v_manage) THEN
        RETURN false;
    END IF;

    UPDATE app.tasks
       SET ready_at = CASE WHEN p_ready THEN now() ELSE NULL END,
           ready_by = CASE WHEN p_ready THEN p_user ELSE NULL END
     WHERE id = p_task;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_task_ready(uuid, uuid, boolean) TO app_user;

-- Функция app.drop_ready_on_complete предназначена для снятия отметки готовности при завершении задачи; при возврате в работу отметка не восстанавливается.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
-- Триггер tasks_drop_ready предназначен для вызова app.drop_ready_on_complete при изменении задачи.
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();

CREATE INDEX IF NOT EXISTS tasks_ready_idx ON app.tasks (ready_at)
    WHERE ready_at IS NOT NULL;

-- Раздел 2: окно правки сообщений. Политики chat_messages_update и chat_messages_delete: автор изменяет и удаляет сообщение в течение часа, как у комментариев.
DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

-- Раздел 3: уведомления по чужим задачам. Функция app.notify_task_watchers применяет настройку во всех путях рассылки (комментарии, чек-лист, вложения).
CREATE OR REPLACE FUNCTION app.notify_task_watchers(
    p_task uuid, p_actor uuid, p_body text)
RETURNS SETOF uuid
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    SELECT DISTINCT w.user_id, p_body, t.board_id, t.id
      FROM app.tasks t
      CROSS JOIN LATERAL app.task_watchers(t.id) AS w(user_id)
      JOIN app.users u ON u.id = w.user_id
     WHERE t.id = p_task
       -- Инициатор не уведомляется; проверка выполняется по всем его действующим личностям.
       AND w.user_id <> ALL (SELECT app.effective_users(p_actor))
       -- Отключённым и удалённым пользователям уведомления не создаются.
       AND u.deleted_at IS NULL AND u.is_active
       -- Настройка «уведомления по задачам, где я не исполнитель»; собственные задачи пользователя уведомляются всегда.
       AND (
         EXISTS (SELECT 1 FROM app.task_assignees a
                  WHERE a.task_id = t.id AND a.user_id = w.user_id)
         OR EXISTS (SELECT 1 FROM app.task_grants g
                     WHERE g.task_id = t.id AND g.user_id = w.user_id)
         OR t.created_by = w.user_id
         OR app.wants_foreign_task_notifs(w.user_id)
       )
    RETURNING notifications.user_id
$$;

GRANT EXECUTE ON FUNCTION app.notify_task_watchers(uuid, uuid, text) TO app_user;



-- #####################################################################
-- Миграция 0017_recurrence_column.sql
-- #####################################################################

\echo '--> 0017_recurrence_column.sql'

-- Скрипт предназначен для создания следующего экземпляра периодической задачи в той же колонке, где шла работа:
-- пересоздание функции app.spawn_recurrence. Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Функция app.spawn_recurrence предназначена для создания следующего экземпляра периодической задачи в колонке работы.
CREATE OR REPLACE FUNCTION app.spawn_recurrence(p_task uuid, p_actor uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r       app.tasks%ROWTYPE;
    v_base  date;
    v_next  date;
    v_col   uuid;
    v_new   uuid := gen_random_uuid();
    v_guard int := 0;
    v_dow   int;
BEGIN
    SELECT * INTO r FROM app.tasks WHERE id = p_task;
    IF NOT FOUND OR r.recur_freq = 'none' THEN RETURN NULL; END IF;

    v_base := COALESCE(r.due_date, current_date);

    IF r.recur_freq = 'daily' THEN
        v_next := v_base + (r.recur_interval || ' days')::interval;
    ELSIF r.recur_freq = 'monthly' THEN
        v_next := (v_base + (r.recur_interval || ' months')::interval)::date;
        IF r.recur_monthday IS NOT NULL THEN
            v_next := LEAST(
                date_trunc('month', v_next)::date + (r.recur_monthday - 1),
                (date_trunc('month', v_next) + interval '1 month - 1 day')::date);
        END IF;
    ELSIF r.recur_freq = 'weekly' THEN
        IF array_length(r.recur_weekdays, 1) IS NULL THEN
            -- Дни не выбраны: отсчёт от понедельника через (interval-1) полных недель; ISODOW: 1 — понедельник, 7 — воскресенье.
            v_next := (v_base + ((r.recur_interval - 1) * 7 || ' days')::interval)::date;
            v_next := v_next + ((8 - EXTRACT(isodow FROM v_next)::int) % 7);
            IF v_next <= v_base THEN
                v_next := v_next + 7;
            END IF;
        ELSE
            v_next := v_base;
            LOOP
                v_next := v_next + 1;
                v_guard := v_guard + 1;
                v_dow := EXTRACT(dow FROM v_next)::int; -- 0=Вс..6=Сб
                EXIT WHEN v_dow = ANY (r.recur_weekdays) OR v_guard > 370;
            END LOOP;
        END IF;
    END IF;

    IF v_next IS NULL THEN RETURN NULL; END IF;
    IF r.recur_until IS NOT NULL AND v_next > r.recur_until THEN RETURN NULL; END IF;

    -- Колонка нового экземпляра: колонка, из которой задача была перенесена в «Готово».
    SELECT c.id INTO v_col
      FROM app.columns c
     WHERE c.id = r.prev_column_id AND c.board_id = r.board_id AND NOT c.is_done;

    IF v_col IS NULL THEN
        SELECT c.id INTO v_col
          FROM app.columns c
         WHERE c.id = r.column_id AND c.board_id = r.board_id AND NOT c.is_done;
    END IF;

    IF v_col IS NULL THEN
        SELECT id INTO v_col FROM app.columns
         WHERE board_id = r.board_id AND NOT is_done ORDER BY position LIMIT 1;
    END IF;

    IF v_col IS NULL THEN RETURN NULL; END IF;

    INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
                           due_date, tags, incoming_number, incoming_date, position, created_by,
                           recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
    VALUES (v_new, r.board_id, v_col, r.title, r.description, r.priority, r.color,
            v_next, r.tags, r.incoming_number, r.incoming_date,
            COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = v_col), 0), r.created_by,
            r.recur_freq, r.recur_interval, r.recur_weekdays, r.recur_monthday, r.recur_until);

    INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
    SELECT v_new, body, false, position, assignee_id, due_date, created_by
      FROM app.task_steps WHERE task_id = p_task;

    INSERT INTO app.task_assignees (task_id, user_id)
    SELECT v_new, user_id FROM app.task_assignees WHERE task_id = p_task
    ON CONFLICT DO NOTHING;

    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (v_new, p_actor, 'Создана по расписанию (повторение задачи)');
    RETURN v_new;
END $$;



-- #####################################################################
-- Миграция 0018_team_groups.sql
-- #####################################################################

\echo '--> 0018_team_groups.sql'

-- Скрипт предназначен для создания групп внутри личной команды: таблицы групп и их участников, политика доступа.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Таблица app.team_groups предназначена для хранения групп личной команды.
CREATE TABLE IF NOT EXISTS app.team_groups (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    title      text NOT NULL CHECK (btrim(title) <> ''),
    -- Порядок групп задаёт владелец.
    position   int  NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS team_groups_owner_idx ON app.team_groups (owner_id, position);

-- Таблица app.team_group_members предназначена для хранения участников групп.
CREATE TABLE IF NOT EXISTS app.team_group_members (
    group_id  uuid NOT NULL REFERENCES app.team_groups(id) ON DELETE CASCADE,
    -- Поле owner_id дублируется: оно необходимо для составного внешнего ключа на team_members.
    owner_id  uuid NOT NULL,
    member_id uuid NOT NULL,
    PRIMARY KEY (group_id, member_id),
    FOREIGN KEY (owner_id, member_id)
        REFERENCES app.team_members (owner_id, member_id) ON DELETE CASCADE
);

ALTER TABLE app.team_groups        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.team_group_members ENABLE ROW LEVEL SECURITY;

-- Политика team_groups_own: группы видит и изменяет только их владелец.
DROP POLICY IF EXISTS team_groups_own ON app.team_groups;
CREATE POLICY team_groups_own ON app.team_groups FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

DROP POLICY IF EXISTS team_group_members_own ON app.team_group_members;
CREATE POLICY team_group_members_own ON app.team_group_members FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_groups        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_group_members TO app_user;



-- #####################################################################
-- Миграция 0019_ready_into_report.sql
-- #####################################################################

\echo '--> 0019_ready_into_report.sql'

-- Скрипт предназначен для переноса отметки «готова к сдаче» в отчёт при завершении задачи: перед снятием отметки
-- триггер дописывает в отчёт строку с ФИО сдавшего и временем сдачи.
--
-- Перенос выполняется в триггере, а не в обработчике: задача завершается двумя путями (кнопка «Пометить завершённой»
-- и перенос карточки в колонку «Готово» через app.move_task), триггер срабатывает при любом из них.
--
-- Время указывается в часовом поясе клиента: сервер передаёт заголовок X-Timezone в транзакционную настройку app.tz.
-- Если настройка не задана или имя пояса неверно, используется пояс сессии.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0019_ready_into_report.sql
--
-- Выполняется от app_owner после 0018_team_groups.sql, идемпотентен.


SET search_path = app, public;

-- Функция app.drop_ready_on_complete предназначена для снятия отметки готовности при завершении задачи с записью
-- отметки в отчёт. Режим SECURITY DEFINER: имя сдавшего читается из app.users в обход политики на users.
-- Функция ничего не возвращает наружу и изменяет только обновляемую строку.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_tz    text;
    v_local timestamp;
    v_name  text;
    v_line  text;
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        IF OLD.ready_at IS NOT NULL THEN
            v_tz := nullif(current_setting('app.tz', true), '');
            BEGIN
                v_local := OLD.ready_at AT TIME ZONE COALESCE(v_tz, current_setting('TimeZone'));
            EXCEPTION WHEN invalid_parameter_value THEN
                v_local := OLD.ready_at AT TIME ZONE current_setting('TimeZone');
            END;

            SELECT u.full_name INTO v_name FROM app.users u WHERE u.id = OLD.ready_by;

            v_line := 'Отметка о готовности к сдаче: '
                   || COALESCE(nullif(btrim(v_name), ''), 'исполнитель')
                   || ' ' || to_char(v_local, 'DD.MM.YYYY, HH24:MI');

            -- Отчёт берётся из NEW: при изменении отчёта в том же UPDATE строка дописывается к новому тексту.
            -- Завершающие переводы строк удаляются, чтобы не возникало пустых строк между отчётом и отметкой.
            -- Одинаковая строка повторно не добавляется.
            IF position(v_line IN COALESCE(NEW.report, '')) = 0 THEN
                NEW.report := CASE
                    WHEN btrim(COALESCE(NEW.report, '')) = '' THEN v_line
                    ELSE rtrim(NEW.report, E' \n\r\t') || E'\n' || v_line
                END;
            END IF;
        END IF;

        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
-- Триггер tasks_drop_ready предназначен для вызова app.drop_ready_on_complete перед изменением задачи.
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();



-- #####################################################################
-- Миграция 0020_charts_whiteboards.sql
-- #####################################################################

\echo '--> 0020_charts_whiteboards.sql'

-- Скрипт предназначен для создания двух областей: диаграмм Ганта (этапы работ со сроками, связи «следующий за»,
-- ссылки на задачи проектов) и совместных досок (холст с фигурами, стикерами, линиями и текстом).
--
-- Модель прав обеих областей совпадает с моделью проектов (app.board_role, app.can_edit_board): владелец, редактор,
-- исполнитель; для каждой области используется отдельная таблица участников. Замещение учитывается через app.effective_users.
--
-- Записи диаграмм не являются задачами: они не попадают в календарь, список «Все задачи» и уведомления по задачам.
-- Связь с задачей проекта выполняется необязательной ссылкой.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0020_charts_whiteboards.sql
--
-- Выполняется от app_owner после 0019_ready_into_report.sql, идемпотентен.


SET search_path = app, public;

-- Раздел 1: диаграммы. Таблица app.charts предназначена для хранения диаграмм.

CREATE TABLE IF NOT EXISTS app.charts (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    -- Параметры вида диаграммы: масштаб (день, неделя, месяц), показ выходных, цвет по умолчанию и другие.
    settings    jsonb NOT NULL DEFAULT '{}'::jsonb,
    position    integer NOT NULL DEFAULT 0,
    archived    boolean NOT NULL DEFAULT false,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.chart_members предназначена для хранения участников диаграмм и их ролей.
CREATE TABLE IF NOT EXISTS app.chart_members (
    chart_id uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)  ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (chart_id, user_id)
);

CREATE INDEX IF NOT EXISTS chart_members_user_idx ON app.chart_members (user_id);

-- Таблица app.chart_items предназначена для хранения записей (этапов) диаграммы. Запись самостоятельна: свои название, даты
-- и прогресс; с задачами связана только ссылками из app.chart_item_tasks.
CREATE TABLE IF NOT EXISTS app.chart_items (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chart_id    uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    starts_on   date NOT NULL,
    ends_on     date NOT NULL,
    -- Процент готовности отображается заливкой полосы; диапазон 0–100 проверяется на уровне БД.
    progress    smallint NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    color       text NOT NULL DEFAULT '',
    -- Признак вехи: событие без длительности, ends_on равен starts_on.
    milestone   boolean NOT NULL DEFAULT false,
    position    integer NOT NULL DEFAULT 0,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    -- Ограничение: конец не раньше начала.
    CHECK (ends_on >= starts_on)
);

CREATE INDEX IF NOT EXISTS chart_items_chart_idx ON app.chart_items (chart_id, position);

-- Таблица app.chart_links предназначена для хранения связей «следующий за»: направленных, без петель на себя; дубли исключены первичным ключом.
CREATE TABLE IF NOT EXISTS app.chart_links (
    from_item uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    to_item   uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    PRIMARY KEY (from_item, to_item),
    CHECK (from_item <> to_item)
);

CREATE INDEX IF NOT EXISTS chart_links_to_idx ON app.chart_links (to_item);

-- Таблица app.chart_item_tasks предназначена для хранения ссылок записей на задачи. При удалении задачи ссылка удаляется каскадно.
CREATE TABLE IF NOT EXISTS app.chart_item_tasks (
    item_id uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    task_id uuid NOT NULL REFERENCES app.tasks(id)       ON DELETE CASCADE,
    PRIMARY KEY (item_id, task_id)
);

CREATE INDEX IF NOT EXISTS chart_item_tasks_task_idx ON app.chart_item_tasks (task_id);

-- Функция app.chart_role предназначена для определения роли пользователя в диаграмме с учётом замещения (аналог app.board_role).
CREATE OR REPLACE FUNCTION app.chart_role(p_chart uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.chart_members m
     WHERE m.chart_id = p_chart
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_see_chart предназначена для проверки права просмотра диаграммы.
CREATE OR REPLACE FUNCTION app.can_see_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IS NOT NULL $$;

-- Функция app.can_edit_chart предназначена для проверки права редактирования диаграммы.
CREATE OR REPLACE FUNCTION app.can_edit_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_chart_owner предназначена для проверки, что пользователь является владельцем диаграммы.
CREATE OR REPLACE FUNCTION app.is_chart_owner(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) = 'owner' $$;

-- Функция app.chart_watchers предназначена для получения получателей событий диаграммы: участников и их заместителей.
CREATE OR REPLACE FUNCTION app.chart_watchers(p_chart uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.chart_members m WHERE m.chart_id = p_chart
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.chart_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.chart_id = p_chart
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.chart_owner_bootstrap предназначена для записи владельца в участники сразу после создания диаграммы:
-- до этого владелец не проходит политику chart_members.
CREATE OR REPLACE FUNCTION app.chart_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.chart_members (chart_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS charts_owner_bootstrap ON app.charts;
-- Триггер charts_owner_bootstrap предназначен для вызова app.chart_owner_bootstrap после вставки в app.charts.
CREATE TRIGGER charts_owner_bootstrap AFTER INSERT ON app.charts
    FOR EACH ROW EXECUTE FUNCTION app.chart_owner_bootstrap();

-- Функция app.chart_task_brief предназначена для получения названия задачи, если она видна пользователю, иначе NULL:
-- ссылка на чужую задачу не раскрывает заголовок (аналог app.task_title_visible).
CREATE OR REPLACE FUNCTION app.chart_task_brief(p_task uuid, p_user uuid)
RETURNS TABLE (task_id uuid, title text, board_title text, completed boolean, visible boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.id,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.title ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN app.board_title(t.board_id) ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.completed_at IS NOT NULL ELSE false END,
           app.can_see_task(t.id, p_user)
      FROM app.tasks t
     WHERE t.id = p_task
$$;

ALTER TABLE app.charts           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_items      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_item_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS charts_select ON app.charts;
CREATE POLICY charts_select ON app.charts FOR SELECT
    USING (app.can_see_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_insert ON app.charts;
CREATE POLICY charts_insert ON app.charts FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Политики изменения диаграммы: название и параметры вида правят владелец и редактор.
DROP POLICY IF EXISTS charts_update ON app.charts;
CREATE POLICY charts_update ON app.charts FOR UPDATE
    USING (app.can_edit_chart(id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_delete ON app.charts;
CREATE POLICY charts_delete ON app.charts FOR DELETE
    USING (app.is_chart_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_select ON app.chart_members;
CREATE POLICY chart_members_select ON app.chart_members FOR SELECT
    USING (app.chart_role(chart_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS chart_members_write ON app.chart_members;
CREATE POLICY chart_members_write ON app.chart_members FOR INSERT
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_update ON app.chart_members;
CREATE POLICY chart_members_update ON app.chart_members FOR UPDATE
    USING (app.is_chart_owner(chart_id, app.current_user_id()))
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_delete ON app.chart_members;
CREATE POLICY chart_members_delete ON app.chart_members FOR DELETE
    USING (
        (app.is_chart_owner(chart_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS chart_items_select ON app.chart_items;
CREATE POLICY chart_items_select ON app.chart_items FOR SELECT
    USING (app.can_see_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_write ON app.chart_items;
CREATE POLICY chart_items_write ON app.chart_items FOR INSERT
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id())
                AND created_by = app.current_user_id());

DROP POLICY IF EXISTS chart_items_update ON app.chart_items;
CREATE POLICY chart_items_update ON app.chart_items FOR UPDATE
    USING (app.can_edit_chart(chart_id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_delete ON app.chart_items;
CREATE POLICY chart_items_delete ON app.chart_items FOR DELETE
    USING (app.can_edit_chart(chart_id, app.current_user_id()));

-- Функция app.chart_of_item предназначена для определения диаграммы по записи: права связей и ссылок на задачи наследуются от записи.
CREATE OR REPLACE FUNCTION app.chart_of_item(p_item uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT chart_id FROM app.chart_items WHERE id = p_item $$;

DROP POLICY IF EXISTS chart_links_select ON app.chart_links;
CREATE POLICY chart_links_select ON app.chart_links FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_links_write ON app.chart_links;
CREATE POLICY chart_links_write ON app.chart_links FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id())
        -- Связывать можно только записи одной диаграммы.
        AND app.chart_of_item(from_item) = app.chart_of_item(to_item));

DROP POLICY IF EXISTS chart_links_delete ON app.chart_links;
CREATE POLICY chart_links_delete ON app.chart_links FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_select ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_select ON app.chart_item_tasks FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Привязывать можно только видимую пользователю задачу: это исключает привязку к чужой задаче по подобранному идентификатору.
DROP POLICY IF EXISTS chart_item_tasks_write ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_write ON app.chart_item_tasks FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id())
        AND app.can_see_task(task_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_delete ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_delete ON app.chart_item_tasks FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Раздел 2: совместные доски. Таблица app.whiteboards предназначена для хранения досок.

CREATE TABLE IF NOT EXISTS app.whiteboards (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    position   integer NOT NULL DEFAULT 0,
    archived   boolean NOT NULL DEFAULT false,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.whiteboard_members предназначена для хранения участников досок и их ролей.
CREATE TABLE IF NOT EXISTS app.whiteboard_members (
    board_id uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)       ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (board_id, user_id)
);

CREATE INDEX IF NOT EXISTS whiteboard_members_user_idx ON app.whiteboard_members (user_id);

-- Таблица app.whiteboard_shapes предназначена для хранения фигур на холсте. Геометрия (x, y, w, h, angle, z) хранится
-- в колонках для быстрой выборки и перетаскивания, прочие свойства — в JSON.
CREATE TABLE IF NOT EXISTS app.whiteboard_shapes (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id   uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    kind       text NOT NULL CHECK (kind IN
                 ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                  'line', 'arrow', 'draw', 'image', 'frame')),
    x          double precision NOT NULL DEFAULT 0,
    y          double precision NOT NULL DEFAULT 0,
    w          double precision NOT NULL DEFAULT 160,
    h          double precision NOT NULL DEFAULT 120,
    angle      double precision NOT NULL DEFAULT 0,
    z          integer NOT NULL DEFAULT 0,
    data       jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    updated_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS whiteboard_shapes_board_idx ON app.whiteboard_shapes (board_id, z);

-- Функция app.wb_role предназначена для определения роли пользователя в доске.
CREATE OR REPLACE FUNCTION app.wb_role(p_board uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.whiteboard_members m
     WHERE m.board_id = p_board
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_see_wb предназначена для проверки права просмотра доски.
CREATE OR REPLACE FUNCTION app.can_see_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IS NOT NULL $$;

-- Функция app.can_edit_wb предназначена для проверки права редактирования доски.
CREATE OR REPLACE FUNCTION app.can_edit_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_wb_owner предназначена для проверки, что пользователь является владельцем доски.
CREATE OR REPLACE FUNCTION app.is_wb_owner(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) = 'owner' $$;

-- Функция app.wb_watchers предназначена для получения получателей событий доски.
CREATE OR REPLACE FUNCTION app.wb_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.whiteboard_members m WHERE m.board_id = p_board
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.whiteboard_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.board_id = p_board
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.wb_owner_bootstrap предназначена для записи владельца в участники сразу после создания доски.
CREATE OR REPLACE FUNCTION app.wb_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS whiteboards_owner_bootstrap ON app.whiteboards;
-- Триггер whiteboards_owner_bootstrap предназначен для вызова app.wb_owner_bootstrap после вставки в app.whiteboards.
CREATE TRIGGER whiteboards_owner_bootstrap AFTER INSERT ON app.whiteboards
    FOR EACH ROW EXECUTE FUNCTION app.wb_owner_bootstrap();

ALTER TABLE app.whiteboards        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_shapes  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS whiteboards_select ON app.whiteboards;
CREATE POLICY whiteboards_select ON app.whiteboards FOR SELECT
    USING (app.can_see_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_insert ON app.whiteboards;
CREATE POLICY whiteboards_insert ON app.whiteboards FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

DROP POLICY IF EXISTS whiteboards_update ON app.whiteboards;
CREATE POLICY whiteboards_update ON app.whiteboards FOR UPDATE
    USING (app.can_edit_wb(id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_delete ON app.whiteboards;
CREATE POLICY whiteboards_delete ON app.whiteboards FOR DELETE
    USING (app.is_wb_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_select ON app.whiteboard_members;
CREATE POLICY whiteboard_members_select ON app.whiteboard_members FOR SELECT
    USING (app.wb_role(board_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS whiteboard_members_write ON app.whiteboard_members;
CREATE POLICY whiteboard_members_write ON app.whiteboard_members FOR INSERT
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_update ON app.whiteboard_members;
CREATE POLICY whiteboard_members_update ON app.whiteboard_members FOR UPDATE
    USING (app.is_wb_owner(board_id, app.current_user_id()))
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_delete ON app.whiteboard_members;
CREATE POLICY whiteboard_members_delete ON app.whiteboard_members FOR DELETE
    USING (
        (app.is_wb_owner(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS whiteboard_shapes_select ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_select ON app.whiteboard_shapes FOR SELECT
    USING (app.can_see_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_write ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_write ON app.whiteboard_shapes FOR INSERT
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id())
                AND created_by = app.current_user_id());

-- Политика whiteboard_shapes_update: фигуры правит любой редактор доски, не только автор фигуры.
DROP POLICY IF EXISTS whiteboard_shapes_update ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_update ON app.whiteboard_shapes FOR UPDATE
    USING (app.can_edit_wb(board_id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_delete ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_delete ON app.whiteboard_shapes FOR DELETE
    USING (app.can_edit_wb(board_id, app.current_user_id()));

-- Раздел 3: привилегии роли app_user на таблицы диаграмм и досок.
GRANT SELECT, INSERT, UPDATE, DELETE ON app.charts             TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_members      TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_items        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_links        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_item_tasks   TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboards        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_members TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_shapes  TO app_user;

GRANT EXECUTE ON FUNCTION app.chart_role(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_chart(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_chart(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.is_chart_owner(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_watchers(uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_of_item(uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_task_brief(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_role(uuid, uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_wb(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_wb(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.is_wb_owner(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_watchers(uuid)             TO app_user;



-- #####################################################################
-- Миграция 0021_boards_charts_extras.sql
-- #####################################################################

\echo '--> 0021_boards_charts_extras.sql'

-- Скрипт предназначен для расширения досок и диаграмм: размер полотна, цвет фона и прозрачность фигур; собственные значки;
-- обсуждение и файлы этапов диаграммы; запрет замкнутых цепочек связей; ссылки в уведомлениях на диаграммы и доски.
--
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: размер и фон доски. Размер хранится в точках холста, а не в пикселях экрана, поэтому
-- доска одинакова на любом мониторе.

ALTER TABLE app.whiteboards
    ADD COLUMN IF NOT EXISTS width    integer NOT NULL DEFAULT 3840,
    ADD COLUMN IF NOT EXISTS height   integer NOT NULL DEFAULT 2160,
    -- Цвет фона: пустое значение означает цвет фона приложения (учитывается тема).
    ADD COLUMN IF NOT EXISTS bg_color text NOT NULL DEFAULT '';

-- Допустимые пределы размера полотна.
ALTER TABLE app.whiteboards DROP CONSTRAINT IF EXISTS whiteboards_size_ck;
ALTER TABLE app.whiteboards ADD CONSTRAINT whiteboards_size_ck
    CHECK (width BETWEEN 640 AND 16384 AND height BETWEEN 480 AND 16384);

-- Прозрачность фигуры хранится отдельной колонкой наряду с геометрией.
ALTER TABLE app.whiteboard_shapes
    ADD COLUMN IF NOT EXISTS opacity double precision NOT NULL DEFAULT 1;

ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_opacity_ck;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_opacity_ck
    CHECK (opacity BETWEEN 0 AND 1);

-- Вид фигуры «значок»: картинка из набора или загруженная участником.
ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_kind_check;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_kind_check
    CHECK (kind IN ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                    'line', 'arrow', 'draw', 'image', 'frame', 'icon'));

-- Раздел 2: собственные значки. Встроенный набор значков находится в коде клиента.
-- Таблица app.board_icons предназначена для хранения значков, загруженных участниками.

CREATE TABLE IF NOT EXISTS app.board_icons (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS board_icons_created_idx ON app.board_icons (created_at DESC);

ALTER TABLE app.board_icons ENABLE ROW LEVEL SECURITY;

-- Политика board_icons_select: значки видны всем вошедшим пользователям.
DROP POLICY IF EXISTS board_icons_select ON app.board_icons;
CREATE POLICY board_icons_select ON app.board_icons FOR SELECT
    USING (app.current_user_id() IS NOT NULL);

DROP POLICY IF EXISTS board_icons_insert ON app.board_icons;
CREATE POLICY board_icons_insert ON app.board_icons FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Политика board_icons_delete: значок удаляет загрузивший его пользователь или администратор.
DROP POLICY IF EXISTS board_icons_delete ON app.board_icons;
CREATE POLICY board_icons_delete ON app.board_icons FOR DELETE
    USING (created_by = app.current_user_id() OR app.is_admin(app.current_user_id()));

-- Политика files_select_board_icons: файл значка виден всем вошедшим пользователям.
DROP POLICY IF EXISTS files_select_board_icons ON app.files;
CREATE POLICY files_select_board_icons ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.board_icons i WHERE i.file_id = files.id)
           AND app.current_user_id() IS NOT NULL);

-- Раздел 3: обсуждение и файлы этапа диаграммы. Отдельные таблицы, так как comments и attachments привязаны к задаче.
-- Таблица app.chart_comments предназначена для хранения комментариев к записям диаграммы.

CREATE TABLE IF NOT EXISTS app.chart_comments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    body       text NOT NULL CHECK (length(btrim(body)) > 0),
    edited_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_comments_item_idx ON app.chart_comments (item_id, created_at);

-- Таблица app.chart_attachments предназначена для хранения файлов, прикреплённых к записям диаграммы.
CREATE TABLE IF NOT EXISTS app.chart_attachments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    title      text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_attachments_item_idx ON app.chart_attachments (item_id, created_at);

ALTER TABLE app.chart_comments    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_attachments ENABLE ROW LEVEL SECURITY;

-- Политики chart_comments: комментировать может любой участник диаграммы, изменять и удалять — только автор комментария.
DROP POLICY IF EXISTS chart_comments_select ON app.chart_comments;
CREATE POLICY chart_comments_select ON app.chart_comments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_comments_insert ON app.chart_comments;
CREATE POLICY chart_comments_insert ON app.chart_comments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_update ON app.chart_comments;
CREATE POLICY chart_comments_update ON app.chart_comments FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_delete ON app.chart_comments;
CREATE POLICY chart_comments_delete ON app.chart_comments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_select ON app.chart_attachments;
CREATE POLICY chart_attachments_select ON app.chart_attachments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_insert ON app.chart_attachments;
CREATE POLICY chart_attachments_insert ON app.chart_attachments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_attachments_delete ON app.chart_attachments;
CREATE POLICY chart_attachments_delete ON app.chart_attachments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS files_select_chart_attachments ON app.files;
CREATE POLICY files_select_chart_attachments ON app.files FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM app.chart_attachments a
         WHERE a.file_id = files.id
           AND app.can_see_chart(app.chart_of_item(a.item_id), app.current_user_id())));

-- Раздел 4: запрет замкнутых цепочек связей.
-- Функция app.chart_link_would_cycle предназначена для проверки, что новая связь замкнёт цепочку (путь из следующего этапа в текущий).

CREATE OR REPLACE FUNCTION app.chart_link_would_cycle(p_from uuid, p_to uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    -- Проверка выполняется обходом в ширину по существующим связям.
    WITH RECURSIVE reach(id) AS (
        SELECT p_to
        UNION
        SELECT l.to_item FROM app.chart_links l JOIN reach r ON l.from_item = r.id
    )
    SELECT p_from = p_to OR EXISTS (SELECT 1 FROM reach WHERE id = p_from)
$$;

-- Функция app.chart_links_no_cycle предназначена для отклонения связи, замыкающей цепочку.
CREATE OR REPLACE FUNCTION app.chart_links_no_cycle() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    IF app.chart_link_would_cycle(NEW.from_item, NEW.to_item) THEN
        RAISE EXCEPTION 'Связь замкнула бы цепочку этапов'
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS chart_links_no_cycle ON app.chart_links;
-- Триггер chart_links_no_cycle предназначен для вызова app.chart_links_no_cycle при вставке и изменении app.chart_links.
CREATE TRIGGER chart_links_no_cycle BEFORE INSERT OR UPDATE ON app.chart_links
    FOR EACH ROW EXECUTE FUNCTION app.chart_links_no_cycle();

-- Раздел 5: уведомления о диаграммах и досках. В уведомление добавляются поля ссылки на объект.

ALTER TABLE app.notifications
    ADD COLUMN IF NOT EXISTS chart_id uuid REFERENCES app.charts(id)      ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS wb_id    uuid REFERENCES app.whiteboards(id) ON DELETE CASCADE;

-- Функция app.notify_obj предназначена для создания уведомления со ссылкой на диаграмму или доску.
CREATE OR REPLACE FUNCTION app.notify_obj(
    p_user uuid, p_body text, p_category text,
    p_chart uuid DEFAULT NULL, p_wb uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_enabled boolean;
BEGIN
    SELECT enabled INTO v_enabled
      FROM app.notification_prefs
     WHERE user_id = p_user AND category = p_category;
    IF v_enabled IS NOT NULL AND v_enabled = false THEN
        RETURN;
    END IF;
    RETURN QUERY
        INSERT INTO app.notifications (user_id, body, category, chart_id, wb_id)
        VALUES (p_user, p_body, p_category, p_chart, p_wb)
        RETURNING notifications.id, notifications.created_at;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON app.board_icons       TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_comments    TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_attachments TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_link_would_cycle(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.notify_obj(uuid, text, text, uuid, uuid) TO app_user;



-- #####################################################################
-- Миграция 0022_chart_activity.sql
-- #####################################################################

\echo '--> 0022_chart_activity.sql'

-- Скрипт предназначен для хранения истории изменений этапов диаграммы (аналог app.activity для задач).
--
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Таблица app.chart_activity предназначена для хранения записей истории диаграммы.
CREATE TABLE IF NOT EXISTS app.chart_activity (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    -- Автор может быть удалён: запись истории сохраняется.
    actor_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_activity_item_idx
    ON app.chart_activity (item_id, created_at DESC);

ALTER TABLE app.chart_activity ENABLE ROW LEVEL SECURITY;

-- Политика chart_activity_select: историю читают все участники диаграммы.
DROP POLICY IF EXISTS chart_activity_select ON app.chart_activity;
CREATE POLICY chart_activity_select ON app.chart_activity FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Политика chart_activity_insert: запись добавляет участник диаграммы только от своего имени.
DROP POLICY IF EXISTS chart_activity_insert ON app.chart_activity;
CREATE POLICY chart_activity_insert ON app.chart_activity FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND actor_id = app.current_user_id());

-- Права на изменение и удаление не выдаются, политик UPDATE и DELETE нет: записи истории неизменяемы.

GRANT SELECT, INSERT ON app.chart_activity TO app_user;



-- #####################################################################
-- Миграция 0023_self_password.sql
-- #####################################################################

\echo '--> 0023_self_password.sql'

-- Скрипт предназначен для самостоятельной смены пароля пользователем: функция app.my_password_hash возвращает хеш
-- пароля текущего пользователя для проверки текущего пароля. Прямой SELECT на app.users.password_hash отозван в 0003_rls.sql.
-- Функция не принимает параметров и не может вернуть хеш другого пользователя (в отличие от app.authenticate(email)).
--
-- Выполняется от app_owner, идемпотентен (CREATE OR REPLACE).


-- Функция app.my_password_hash предназначена для получения хеша пароля текущего пользователя.
CREATE OR REPLACE FUNCTION app.my_password_hash()
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.password_hash
      FROM app.users u
     WHERE u.id = app.current_user_id()
       AND u.deleted_at IS NULL
       AND u.is_active
$$;

COMMENT ON FUNCTION app.my_password_hash() IS
    'Хеш пароля того, кто выполняет запрос. Нужен для подтверждения '
    'текущего пароля при самостоятельной смене. Чужой хеш отдать не может.';

-- Право вызова отзывается у PUBLIC и выдаётся адресно.
REVOKE EXECUTE ON FUNCTION app.my_password_hash() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.my_password_hash() TO app_user;


-- #####################################################################
-- Миграция 0024_system_counts.sql
-- #####################################################################

\echo '--> 0024_system_counts.sql'

-- Скрипт предназначен для получения счётчиков объёма системы для метрик: функция app.system_counts возвращает число проектов,
-- задач, досок и других сущностей. Подсчёт выполняется функцией с правами владельца, так как опрос метрик идёт вне
-- пользовательской транзакции (app.current_user_id() равен NULL) и политики RLS не пропускают ни одной строки.
-- Функция возвращает только итоговые числа и не раскрывает названия и содержимое.
--
-- Выполняется от app_owner, идемпотентен (CREATE OR REPLACE).

-- Функция app.system_counts предназначена для подсчёта сущностей системы (SECURITY DEFINER).

CREATE OR REPLACE FUNCTION app.system_counts()
RETURNS TABLE (kind text, n bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT 'boards',  count(*) FROM app.boards WHERE NOT archived
    UNION ALL SELECT 'boards_archived', count(*) FROM app.boards WHERE archived
    UNION ALL SELECT 'tasks', count(*) FROM app.tasks WHERE NOT archived
    UNION ALL SELECT 'tasks_open', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
    UNION ALL SELECT 'tasks_done', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NOT NULL
    UNION ALL SELECT 'tasks_overdue', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
                AND due_date IS NOT NULL AND due_date < current_date
    UNION ALL SELECT 'tasks_archived', count(*) FROM app.tasks WHERE archived
    UNION ALL SELECT 'users', count(*) FROM app.users WHERE deleted_at IS NULL
    UNION ALL SELECT 'users_active', count(*) FROM app.users
              WHERE is_active AND deleted_at IS NULL
    UNION ALL SELECT 'users_online_day', count(DISTINCT user_id)
              FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND created_at > now() - interval '1 day'
    UNION ALL SELECT 'comments', count(*) FROM app.comments
    UNION ALL SELECT 'attachments', count(*) FROM app.attachments
    UNION ALL SELECT 'charts', count(*) FROM app.charts
    UNION ALL SELECT 'whiteboards', count(*) FROM app.whiteboards
    UNION ALL SELECT 'chats', count(*) FROM app.chats
    UNION ALL SELECT 'chat_messages', count(*) FROM app.chat_messages
    UNION ALL SELECT 'reminders', count(*) FROM app.reminders
    UNION ALL SELECT 'notifications_unread', count(*) FROM app.notifications
              WHERE read_at IS NULL
    UNION ALL SELECT 'sessions', count(*) FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND expires_at > now()
$$;

COMMENT ON FUNCTION app.system_counts() IS
    'Итоговые количества объектов для метрик. Только числа: содержимого '
    'не отдаёт, поэтому обхода политик доступа не создаёт.';

-- Право вызова отзывается у PUBLIC и выдаётся адресно.
REVOKE EXECUTE ON FUNCTION app.system_counts() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.system_counts() TO app_user;


-- #####################################################################
-- Миграция 0025_seen_on_read.sql
-- #####################################################################

\echo '--> 0025_seen_on_read.sql'

-- Скрипт предназначен для связи отметок просмотра (view_marks) и уведомлений (read_at): прочтение уведомления о задаче
-- отмечает задачу просмотренной (проект — если в нём не осталось других непросмотренных задач),
-- а отметка задачи просмотренной помечает прочитанными её уведомления.
--
-- Связь реализована в БД, так как app.mark_seen вызывается из нескольких мест (POST /views, загрузка карточки).
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0025_seen_on_read.sql
--
-- Выполняется от app_owner после 0024_system_counts.sql, идемпотентен.


SET search_path = app, public;

-- Индекс notifications_user_task_unread_idx предназначен для выборки непрочитанных уведомлений задачи у пользователя.
CREATE INDEX IF NOT EXISTS notifications_user_task_unread_idx
    ON app.notifications (user_id, task_id) WHERE read_at IS NULL;

-- Функция app.board_has_unseen предназначена для проверки наличия в проекте задач, которые пользователь видит,
-- но не открывал после последнего изменения (ни разу не открытая задача считается непросмотренной, как isUnseen на клиенте).
CREATE OR REPLACE FUNCTION app.board_has_unseen(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.board_id = p_board
           AND NOT t.archived
           AND app.can_see_task(t.id, p_user)
           AND COALESCE(app.seen_at('task', t.id, p_user), '-infinity')
               < app.task_activity_at(t.id, p_user))
$$;

-- Функция app.mark_seen предназначена для отметки сущности просмотренной (версия из 0006 с дополнительной веткой:
-- отметка задачи помечает прочитанными её уведомления).
CREATE OR REPLACE FUNCTION app.mark_seen(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_at timestamptz;
BEGIN
    IF p_user IS NULL OR p_entity IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_kind NOT IN ('task', 'board') THEN
        RAISE EXCEPTION 'unknown_view_kind';
    END IF;

    IF p_kind = 'task' AND NOT app.can_see_task(p_entity, p_user) THEN
        RETURN NULL;
    END IF;
    IF p_kind = 'board' AND NOT app.can_see_board(p_entity, p_user) THEN
        RETURN NULL;
    END IF;

    INSERT INTO app.view_marks (user_id, kind, entity_id, viewed_at)
    VALUES (p_user, p_kind, p_entity, now())
    ON CONFLICT (user_id, kind, entity_id)
    DO UPDATE SET viewed_at = now()
    RETURNING viewed_at INTO v_at;

    IF p_kind = 'task' THEN
        UPDATE app.notifications SET read_at = now()
         WHERE user_id = p_user AND task_id = p_entity AND read_at IS NULL;
    END IF;

    RETURN v_at;
END $$;

-- Функция app.read_notifications предназначена для прочтения уведомлений текущего пользователя: перечисленных или,
-- при p_ids = NULL, всех. Возвращает поставленные отметки просмотра, по которым клиент снимает выделение.
CREATE OR REPLACE FUNCTION app.read_notifications(p_ids uuid[])
RETURNS TABLE (kind text, entity_id uuid, viewed_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_user   uuid := app.current_user_id();
    v_tasks  uuid[];
    v_boards uuid[];
    v_task   uuid;
    v_board  uuid;
    v_at     timestamptz;
BEGIN
    IF v_user IS NULL THEN
        RETURN;
    END IF;

    -- Проект определяется по уведомлению или по его задаче: у уведомлений о задачах board_id заполнен не всегда.
    WITH upd AS (
        UPDATE app.notifications n SET read_at = now()
         WHERE n.user_id = v_user AND n.read_at IS NULL
           AND (p_ids IS NULL OR n.id = ANY (p_ids))
        RETURNING n.task_id, n.board_id
    )
    SELECT array_agg(DISTINCT u.task_id) FILTER (WHERE u.task_id IS NOT NULL),
           array_agg(DISTINCT COALESCE(u.board_id, t.board_id))
               FILTER (WHERE COALESCE(u.board_id, t.board_id) IS NOT NULL)
      INTO v_tasks, v_boards
      FROM upd u LEFT JOIN app.tasks t ON t.id = u.task_id;

    FOREACH v_task IN ARRAY COALESCE(v_tasks, '{}') LOOP
        v_at := app.mark_seen('task', v_task, v_user);
        IF v_at IS NOT NULL THEN
            kind := 'task'; entity_id := v_task; viewed_at := v_at;
            RETURN NEXT;
        END IF;
    END LOOP;

    FOREACH v_board IN ARRAY COALESCE(v_boards, '{}') LOOP
        IF NOT app.board_has_unseen(v_board, v_user) THEN
            v_at := app.mark_seen('board', v_board, v_user);
            IF v_at IS NOT NULL THEN
                kind := 'board'; entity_id := v_board; viewed_at := v_at;
                RETURN NEXT;
            END IF;
        END IF;
    END LOOP;
END $$;

-- Функция app.unread_notifications предназначена для подсчёта непрочитанных уведомлений текущего пользователя (счётчик на колокольчике).
CREATE OR REPLACE FUNCTION app.unread_notifications()
RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)::int FROM app.notifications
     WHERE user_id = app.current_user_id() AND read_at IS NULL
$$;

GRANT EXECUTE ON FUNCTION app.board_has_unseen(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.read_notifications(uuid[])    TO app_user;
GRANT EXECUTE ON FUNCTION app.unread_notifications()        TO app_user;


-- #####################################################################
-- Миграция 0026_board_watchers.sql
-- #####################################################################

\echo '--> 0026_board_watchers.sql'

-- Скрипт предназначен для рассылки событий проекта всем, кому он виден: функция app.board_watchers приведена в соответствие
-- с условиями app.can_see_board (участники, автор, исполнитель, исполнитель пункта чек-листа, получатель точечного доступа)
-- с учётом замещения в обе стороны (effective_users). Сверка двух функций — раздел 9 в scripts/rls_test.sql.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0026_board_watchers.sql
--
-- Выполняется от app_owner после 0025_seen_on_read.sql, идемпотентен.


SET search_path = app, public;

-- Функция app.board_watchers предназначена для получения получателей событий проекта.
CREATE OR REPLACE FUNCTION app.board_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH direct AS (
        SELECT m.user_id FROM app.board_members m WHERE m.board_id = p_board
        UNION
        SELECT t.created_by FROM app.tasks t WHERE t.board_id = p_board
        UNION
        SELECT a.user_id FROM app.task_assignees a
          JOIN app.tasks t ON t.id = a.task_id WHERE t.board_id = p_board
        UNION
        SELECT g.user_id FROM app.task_grants g
          JOIN app.tasks t ON t.id = g.task_id WHERE t.board_id = p_board
        UNION
        SELECT s.assignee_id FROM app.task_steps s
          JOIN app.tasks t ON t.id = s.task_id
         WHERE t.board_id = p_board AND s.assignee_id IS NOT NULL
    )
    SELECT d.user_id FROM direct d
    UNION
    -- Заместитель получает события замещаемого (effective_users).
    SELECT dl.deputy_id FROM app.delegations dl
      JOIN direct d ON d.user_id = dl.grantor_id
     WHERE current_date BETWEEN dl.starts_at AND dl.ends_at
$$;


-- #####################################################################
-- Миграция 0027_access_panel.sql
-- #####################################################################

\echo '--> 0027_access_panel.sql'

-- Скрипт предназначен для панели «Доступы», онбординга и офбординга: просмотр доступа пользователя, точечная выдача и снятие
-- доступа к проектам и задачам, копирование доступа коллеги, удаление учётной записи с полным снятием доступа и передачей дел.
--
-- Все функции, изменяющие доступ, выполняются в режиме SECURITY DEFINER с явной проверкой прав вызывающего:
-- администратор не получает доступ к содержимому проектов через RLS, а панель должна позволять ему управлять доступом.
-- Проверки повторяют политики 0007 (владелец и редактор управляют составом, строка владельца неизменна),
-- политику task_grants (редактор задачи) и добавляют ветку «администратор».
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0027_access_panel.sql
--
-- Выполняется от app_owner после 0026_board_watchers.sql, идемпотентен.


SET search_path = app, public;

-- Раздел 1: замещение не действует после удаления замещаемого.
-- Функция app.effective_users предназначена для получения пользователей, от имени которых действует p_user (он сам и замещаемые).
-- Удалённые (deleted_at) замещаемые исключаются; заблокированные (is_active = false) не исключаются,
-- так как блокировка может быть временной (замещение на время отпуска).
CREATE OR REPLACE FUNCTION app.effective_users(p_user uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user
    UNION
    SELECT d.grantor_id FROM app.delegations d
      JOIN app.users g ON g.id = d.grantor_id
     WHERE d.deputy_id = p_user
       AND g.deleted_at IS NULL
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Раздел 2: проверка прав управления доступом.

-- Функции app.can_edit_board и app.can_edit_task возвращают NULL, а не false, если роль не найдена. В RLS это отказ,
-- но в PL/pgSQL условие «IF NOT NULL» не срабатывает, поэтому используется COALESCE, а проверки записаны как «IS NOT TRUE».
--
-- Функция app.can_manage_board_access предназначена для проверки права p_actor выдавать и снимать доступ к проекту.
CREATE OR REPLACE FUNCTION app.can_manage_board_access(p_board uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_board(p_board, p_actor), false)
$$;

-- Функция app.can_manage_task_access предназначена для проверки права p_actor выдавать и снимать точечный доступ к задаче.
CREATE OR REPLACE FUNCTION app.can_manage_task_access(p_task uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_task(p_task, p_actor), false)
$$;

-- Функция app.is_live_user предназначена для проверки, что учётная запись действующая: доступ выдаётся только таким.
CREATE OR REPLACE FUNCTION app.is_live_user(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.users u
                    WHERE u.id = p_user AND u.deleted_at IS NULL AND u.is_active)
$$;

-- Раздел 3: обзор доступа пользователя.
-- Обычный пользователь видит доступ другого только в проектах, где он владелец или редактор, и в задачах, которые вправе
-- редактировать. Администратор видит всё, включая диаграммы, доски и замещения.
--
-- Функция app.access_overview предназначена для получения списка доступов пользователя p_target.
-- Поле kind: board | task_grant | task_assignee | chart | whiteboard | delegation_to | delegation_from.
-- Поле level: роль в проекте (owner/editor/reader), уровень гранта (read/contribute); для остального пусто или период.
CREATE OR REPLACE FUNCTION app.access_overview(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, board_id uuid,
               board_title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me    uuid := app.current_user_id();
    v_admin boolean;
BEGIN
    IF v_me IS NULL THEN
        RETURN;
    END IF;
    v_admin := app.is_admin(v_me);

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, b.id, b.title, m.role::text,
           app.can_manage_board_access(b.id, v_me)
             AND (m.role <> 'owner' OR v_admin)
      FROM app.board_members m JOIN app.boards b ON b.id = m.board_id
     WHERE m.user_id = p_target
       AND (v_admin OR app.can_edit_board(b.id, v_me));

    RETURN QUERY
    SELECT 'task_grant'::text, t.id, t.title, b.id, b.title, g.access::text,
           app.can_manage_task_access(t.id, v_me)
      FROM app.task_grants g
      JOIN app.tasks t  ON t.id = g.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE g.user_id = p_target
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    -- Назначения исполнителем приводятся для полноты картины: они изменяются в карточке задачи.
    RETURN QUERY
    SELECT 'task_assignee'::text, t.id, t.title, b.id, b.title, NULL::text, false
      FROM app.task_assignees a
      JOIN app.tasks t  ON t.id = a.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE a.user_id = p_target AND NOT t.archived AND t.completed_at IS NULL
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    IF NOT v_admin THEN
        RETURN;
    END IF;

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.chart_members m JOIN app.charts c ON c.id = m.chart_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.whiteboard_members m JOIN app.whiteboards w ON w.id = m.board_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'delegation_to'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.deputy_id
     WHERE d.grantor_id = p_target AND d.ends_at >= current_date;

    RETURN QUERY
    SELECT 'delegation_from'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.grantor_id
     WHERE d.deputy_id = p_target AND d.ends_at >= current_date;
END $$;

-- Функция app.manageable_boards предназначена для получения проектов, в которые вызывающий может добавлять людей.
CREATE OR REPLACE FUNCTION app.manageable_boards()
RETURNS TABLE (id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT b.id, b.title FROM app.boards b
     WHERE NOT b.archived
       AND app.can_manage_board_access(b.id, app.current_user_id())
     ORDER BY b.title
$$;

-- Раздел 4: точечные изменения доступа. Изменяется одна строка, а не весь список, как в PUT /members:
-- при замене списка одновременные правки разных редакторов затирали друг друга.

-- Функция app.set_board_access предназначена для выдачи или смены роли в проекте.
-- Возвращает прежнюю роль (NULL — доступ выдан впервые) для уведомления только новых участников.
CREATE OR REPLACE FUNCTION app.set_board_access(p_board uuid, p_user uuid, p_role text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_role NOT IN ('editor', 'reader') THEN
        RAISE EXCEPTION 'Роль может быть только «редактор» или «исполнитель»'
            USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT role::text INTO v_prev FROM app.board_members
     WHERE board_id = p_board AND user_id = p_user;
    IF v_prev = 'owner' THEN
        RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
    END IF;

    INSERT INTO app.board_members (board_id, user_id, role)
    VALUES (p_board, p_user, p_role::app.board_role)
    ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    RETURN v_prev;
END $$;

-- Функция app.revoke_board_access предназначена для снятия доступа к проекту. Строка владельца не изменяется (как в политике 0007).
CREATE OR REPLACE FUNCTION app.revoke_board_access(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF EXISTS (SELECT 1 FROM app.board_members
                WHERE board_id = p_board AND user_id = p_user AND role = 'owner') THEN
        RAISE EXCEPTION 'Владельца нельзя снять с проекта — сначала передайте владение'
            USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.board_members WHERE board_id = p_board AND user_id = p_user;
    RETURN FOUND;
END $$;

-- Функция app.set_task_access предназначена для выдачи или смены точечного доступа к задаче.
-- Возвращает прежний уровень (NULL — доступ выдан впервые).
CREATE OR REPLACE FUNCTION app.set_task_access(p_task uuid, p_user uuid, p_access text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_access NOT IN ('read', 'contribute') THEN
        RAISE EXCEPTION 'Уровень может быть только «просмотр» или «участие»' USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_task_access(p_task, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT access::text INTO v_prev FROM app.task_grants
     WHERE task_id = p_task AND user_id = p_user;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    VALUES (p_task, p_user, p_access::app.grant_access, v_me)
    ON CONFLICT (task_id, user_id) DO UPDATE SET access = EXCLUDED.access;
    -- История записывается здесь, а не в обработчике: администратор вне состава проекта не может писать в неё под RLS.
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, v_me, 'Изменён доступ к задаче');
    RETURN v_prev;
END $$;

-- Функция app.revoke_task_access предназначена для снятия точечного доступа к задаче.
CREATE OR REPLACE FUNCTION app.revoke_task_access(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF app.can_manage_task_access(p_task, app.current_user_id()) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.task_grants WHERE task_id = p_task AND user_id = p_user;
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, app.current_user_id(), 'Изменён доступ к задаче');
    RETURN true;
END $$;

-- Функция app.task_brief предназначена для получения проекта и названия задачи для уведомлений и событий.
-- Доступна только управляющему доступом к задаче: иначе позволяла бы узнать название чужой задачи по идентификатору.
CREATE OR REPLACE FUNCTION app.task_brief(p_task uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.board_id, t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_manage_task_access(p_task, app.current_user_id())
$$;

-- Раздел 5: онбординг, доступ как у коллеги (только администратор).
-- Копируются членства в проектах, диаграммах и досках и точечные гранты. Владение не копируется: у проекта один владелец,
-- новый пользователь получает роль «редактор». Имеющийся доступ не понижается (ON CONFLICT DO NOTHING).
-- Назначения исполнителем не копируются.
--
-- Функция app.copy_access предназначена для копирования доступа пользователя p_from пользователю p_to.
CREATE OR REPLACE FUNCTION app.copy_access(p_from uuid, p_to uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Копировать доступ может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_from = p_to THEN
        RAISE EXCEPTION 'Нужны два разных сотрудника' USING ERRCODE = '22023';
    END IF;
    IF app.is_live_user(p_to) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    INSERT INTO app.chart_members (chart_id, user_id, role)
    SELECT m.chart_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.chart_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    SELECT m.board_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.whiteboard_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    SELECT g.task_id, p_to, g.access, v_me
      FROM app.task_grants g WHERE g.user_id = p_from
    ON CONFLICT DO NOTHING;

    -- Проекты возвращаются последними: по ним рассылаются уведомления и события о добавлении в проект.
    RETURN QUERY
    WITH ins AS (
        INSERT INTO app.board_members (board_id, user_id, role)
        SELECT m.board_id, p_to,
               CASE WHEN m.role = 'owner' THEN 'editor'::app.board_role ELSE m.role END
          FROM app.board_members m WHERE m.user_id = p_from
        ON CONFLICT DO NOTHING
        RETURNING board_members.board_id
    )
    SELECT b.id, b.title FROM ins JOIN app.boards b ON b.id = ins.board_id;
END $$;

-- Раздел 6: офбординг.
-- Функция app.offboard_user предназначена для удаления учётной записи с полным снятием доступа одной транзакцией.
-- - Владение проектами, диаграммами, досками и групповыми чатами переходит преемнику p_successor. Если владеть нечем,
-- преемник не нужен; если есть чем, а преемник не указан — отказ.
-- - Снимаются членства, гранты, назначения исполнителем, исполнители пунктов чек-листа, замещения и команды.
-- - Задачи без исполнителя не переназначаются: владелец и редакторы проекта получают уведомление по каждой такой задаче.
-- - Авторство (created_by) сохраняется как история.
-- Возвращает уведомления для рассылки по WebSocket и проекты со сменой состава (событие board/updated).
CREATE OR REPLACE FUNCTION app.offboard_user(p_target uuid, p_successor uuid)
RETURNS TABLE (notify_user uuid, notification_id uuid, created_at timestamptz,
               body text, board_id uuid, task_id uuid)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me      uuid := app.current_user_id();
    v_name    text;
    v_owned   int;
    v_tasks   uuid[];
    r         record;
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Удалять сотрудников может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_target = v_me THEN
        RAISE EXCEPTION 'Нельзя удалить собственную учётную запись' USING ERRCODE = '42501';
    END IF;

    SELECT u.full_name INTO v_name FROM app.users u
     WHERE u.id = p_target AND u.deleted_at IS NULL
       FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Учётная запись не найдена или уже удалена' USING ERRCODE = 'P0002';
    END IF;

    SELECT (SELECT count(*) FROM app.board_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chart_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.whiteboard_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chats c WHERE c.owner_id = p_target AND c.kind = 'group')
      INTO v_owned;

    IF v_owned > 0 THEN
        IF p_successor IS NULL THEN
            RAISE EXCEPTION 'need_successor:%', v_owned USING ERRCODE = 'P0001',
                HINT = 'Сотрудник владеет проектами — выберите, кому их передать';
        END IF;
        IF p_successor = p_target OR app.is_live_user(p_successor) IS NOT TRUE THEN
            RAISE EXCEPTION 'Преемником может быть только действующий сотрудник'
                USING ERRCODE = '22023';
        END IF;

        -- Передача владения: сначала удаляется строка прежнего владельца, затем преемник становится владельцем
        -- (уникальный индекс «один владелец на проект» не допускает другой порядок).
        FOR r IN DELETE FROM app.board_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.board_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT board_members_pkey DO UPDATE SET role = 'owner';
            body := 'Вам передан проект сотрудника ' || v_name || ': «'
                 || (SELECT b.title FROM app.boards b WHERE b.id = r.board_id) || '»';
            notification_id := NULL;
            SELECT n.id, n.created_at INTO notification_id, created_at
              FROM app.notify_cat(p_successor, body, 'other', r.board_id, NULL) n;
            IF notification_id IS NOT NULL THEN
                notify_user := p_successor; board_id := r.board_id; task_id := NULL;
                RETURN NEXT;
            END IF;
        END LOOP;

        FOR r IN DELETE FROM app.chart_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.chart_id LOOP
            INSERT INTO app.chart_members (chart_id, user_id, role)
            VALUES (r.chart_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT chart_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN DELETE FROM app.whiteboard_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.whiteboard_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT whiteboard_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN UPDATE app.chats c SET owner_id = p_successor
                  WHERE c.owner_id = p_target AND c.kind = 'group'
              RETURNING c.id LOOP
            INSERT INTO app.chat_members (chat_id, user_id)
            VALUES (r.id, p_successor) ON CONFLICT DO NOTHING;
        END LOOP;
    END IF;

    -- Назначения: запоминаются задачи, чтобы найти оставшиеся без исполнителя.
    WITH del AS (
        DELETE FROM app.task_assignees a WHERE a.user_id = p_target RETURNING a.task_id
    )
    SELECT array_agg(DISTINCT del.task_id) INTO v_tasks FROM del;

    UPDATE app.task_steps s SET assignee_id = NULL WHERE s.assignee_id = p_target;
    DELETE FROM app.task_grants        g WHERE g.user_id = p_target;
    DELETE FROM app.board_members      m WHERE m.user_id = p_target;
    DELETE FROM app.chart_members      m WHERE m.user_id = p_target;
    DELETE FROM app.whiteboard_members m WHERE m.user_id = p_target;
    -- Из групповых чатов пользователь выводится; личная переписка сохраняется у собеседника.
    DELETE FROM app.chat_members cm
     USING app.chats c
     WHERE c.id = cm.chat_id AND c.kind = 'group' AND cm.user_id = p_target;
    DELETE FROM app.delegations d WHERE d.grantor_id = p_target OR d.deputy_id = p_target;
    DELETE FROM app.team_groups tg WHERE tg.owner_id = p_target;
    DELETE FROM app.team_members tm WHERE tm.member_id = p_target OR tm.owner_id = p_target;

    UPDATE app.users u SET deleted_at = now(), is_active = false, role = 'member'
     WHERE u.id = p_target;
    PERFORM app.revoke_user_sessions(p_target);

    -- Задачи без исполнителя: уведомление владельцу и редакторам проекта.
    FOR r IN
        SELECT t.id AS tid, t.title, t.board_id AS bid, m.user_id AS uid
          FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id AND m.role IN ('owner', 'editor')
         WHERE t.id = ANY (COALESCE(v_tasks, '{}'))
           AND NOT t.archived AND t.completed_at IS NULL
           AND NOT EXISTS (SELECT 1 FROM app.task_assignees a WHERE a.task_id = t.id)
    LOOP
        body := 'После ухода сотрудника ' || v_name || ' задача «' || r.title
             || '» осталась без исполнителя';
        notification_id := NULL;
        SELECT n.id, n.created_at INTO notification_id, created_at
          FROM app.notify_cat(r.uid, body, 'task', r.bid, r.tid) n;
        IF notification_id IS NOT NULL THEN
            notify_user := r.uid; board_id := r.bid; task_id := r.tid;
            RETURN NEXT;
        END IF;
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION app.can_manage_board_access(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.can_manage_task_access(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.is_live_user(uuid)                  TO app_user;
GRANT EXECUTE ON FUNCTION app.access_overview(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.manageable_boards()                 TO app_user;
GRANT EXECUTE ON FUNCTION app.set_board_access(uuid, uuid, text)  TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_board_access(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.set_task_access(uuid, uuid, text)   TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_task_access(uuid, uuid)      TO app_user;
GRANT EXECUTE ON FUNCTION app.task_brief(uuid)                    TO app_user;
GRANT EXECUTE ON FUNCTION app.copy_access(uuid, uuid)             TO app_user;
GRANT EXECUTE ON FUNCTION app.offboard_user(uuid, uuid)           TO app_user;


-- #####################################################################
-- Миграция 0028_visibility_sets.sql
-- #####################################################################

\echo '--> 0028_visibility_sets.sql'

-- Скрипт предназначен для ускорения проверок видимости: политики чтения задач, проектов и связанных таблиц переведены
-- с построчного вызова функций (app.can_see_task, app.can_see_board) на множества, вычисляемые один раз за запрос.
--
-- Причина замедления: политика tasks_select вызывала app.task_access для каждой строки, а функция выполняла 4–6 внутренних запросов.
-- При 40 тыс. задач чтение списка занимало около 16 секунд, сводка — около 35 секунд (13 запросов, в каждом проверка дважды).
-- После изменения: чтение 20 тыс. доступных задач — около 25 мс.
--
-- Правила доступа не менялись: задача видна владельцу и редактору проекта, автору, исполнителю, исполнителю пункта
-- чек-листа и обладателю точечного права; замещение учитывается через app.effective_users. Строка проекта видна участнику
-- и обладателю доступа к отдельной задаче (исполнитель или точечное право).
-- Точечные проверки (app.task_access, app.can_edit_task и другие для записи) сохранены без изменений.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0028_visibility_sets.sql
--
-- Выполняется от app_owner после 0027_access_panel.sql, идемпотентен.

SET search_path = app, public;

-- Функция app.my_ids предназначена для получения идентификаторов, от имени которых действует текущий пользователь.
CREATE OR REPLACE FUNCTION app.my_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT app.effective_users(app.current_user_id()) $$;

-- Функция app.my_edit_boards предназначена для получения проектов, где текущий пользователь — владелец или редактор.
CREATE OR REPLACE FUNCTION app.my_edit_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.board_id FROM app.board_members m
     WHERE m.role IN ('owner', 'editor')
       AND m.user_id IN (SELECT app.effective_users(app.current_user_id()))
$$;

-- Функция app.my_task_ids предназначена для получения задач, доступных через назначение, пункт чек-листа или точечное право.
CREATE OR REPLACE FUNCTION app.my_task_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH me AS (SELECT app.effective_users(app.current_user_id()) AS id)
    SELECT a.task_id FROM app.task_assignees a WHERE a.user_id IN (SELECT id FROM me)
    UNION
    SELECT s.task_id FROM app.task_steps s WHERE s.assignee_id IN (SELECT id FROM me)
    UNION
    SELECT g.task_id FROM app.task_grants g WHERE g.user_id IN (SELECT id FROM me)
$$;

-- Политика tasks_select: набор проектов, набор задач автора и набор назначений вычисляются один раз за запрос (hashed SubPlan).
DROP POLICY IF EXISTS tasks_select ON app.tasks;
CREATE POLICY tasks_select ON app.tasks FOR SELECT USING (
       board_id IN (SELECT app.my_edit_boards())
    OR created_by IN (SELECT app.my_ids())
    OR id IN (SELECT app.my_task_ids()));

-- Функция app.can_see_task предназначена для проверки видимости одной задачи: один SQL-запрос вместо цепочки функций.
CREATE OR REPLACE FUNCTION app.can_see_task(p_task uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user IS NOT NULL AND EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (EXISTS (SELECT 1 FROM app.board_members m
                         WHERE m.board_id = t.board_id AND m.role IN ('owner', 'editor')
                           AND m.user_id IN (SELECT app.effective_users(p_user)))
             OR t.created_by IN (SELECT app.effective_users(p_user))
             OR EXISTS (SELECT 1 FROM app.task_assignees a WHERE a.task_id = t.id
                           AND a.user_id IN (SELECT app.effective_users(p_user)))
             OR EXISTS (SELECT 1 FROM app.task_steps s WHERE s.task_id = t.id
                           AND s.assignee_id IN (SELECT app.effective_users(p_user)))
             OR EXISTS (SELECT 1 FROM app.task_grants g WHERE g.task_id = t.id
                           AND g.user_id IN (SELECT app.effective_users(p_user)))))
$$;

-- Политики чтения связанных таблиц: задача видна, если её возвращает tasks (поиск по первичному ключу).
-- Рекурсии нет: политика tasks использует только функции SECURITY DEFINER.
DROP POLICY IF EXISTS task_assignees_select ON app.task_assignees;
CREATE POLICY task_assignees_select ON app.task_assignees FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_assignees.task_id));
DROP POLICY IF EXISTS comments_select ON app.comments;
CREATE POLICY comments_select ON app.comments FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = comments.task_id));
DROP POLICY IF EXISTS activity_select ON app.activity;
CREATE POLICY activity_select ON app.activity FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = activity.task_id));
DROP POLICY IF EXISTS attachments_select ON app.attachments;
CREATE POLICY attachments_select ON app.attachments FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = attachments.task_id));
DROP POLICY IF EXISTS task_steps_select ON app.task_steps;
CREATE POLICY task_steps_select ON app.task_steps FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_steps.task_id));

-- Проекты, где текущий пользователь (или замещаемый им) — участник.
CREATE OR REPLACE FUNCTION app.my_member_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.board_id FROM app.board_members m
     WHERE m.user_id IN (SELECT app.effective_users(app.current_user_id()))
$$;

-- Проекты, строка которых видна: участие либо доступ к отдельной задаче (исполнитель или точечное право).
CREATE OR REPLACE FUNCTION app.my_boards()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH me AS (SELECT app.effective_users(app.current_user_id()) AS id)
    SELECT m.board_id FROM app.board_members m WHERE m.user_id IN (SELECT id FROM me)
    UNION
    SELECT t.board_id FROM app.task_grants g JOIN app.tasks t ON t.id = g.task_id
     WHERE g.user_id IN (SELECT id FROM me)
    UNION
    SELECT t.board_id FROM app.task_assignees a JOIN app.tasks t ON t.id = a.task_id
     WHERE a.user_id IN (SELECT id FROM me)
$$;

DROP POLICY IF EXISTS boards_select ON app.boards;
CREATE POLICY boards_select ON app.boards FOR SELECT USING (id IN (SELECT app.my_boards()));
DROP POLICY IF EXISTS columns_select ON app.columns;
CREATE POLICY columns_select ON app.columns FOR SELECT USING (board_id IN (SELECT app.my_boards()));
DROP POLICY IF EXISTS board_members_select ON app.board_members;
CREATE POLICY board_members_select ON app.board_members FOR SELECT USING (board_id IN (SELECT app.my_member_boards()));
CREATE INDEX IF NOT EXISTS tasks_board_upd_idx ON app.tasks (board_id, updated_at DESC) WHERE NOT archived;

-- Активность проекта: для каждой задачи берётся только последняя подходящая запись (LATERAL ... LIMIT 1 по индексу),
-- а не все записи журнала.
CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(t.updated_at) FROM app.tasks t
                          WHERE t.board_id = b.id AND NOT t.archived),
                        b.updated_at),
               COALESCE((SELECT max(x.at)
                           FROM app.tasks t
                           CROSS JOIN LATERAL (
                                SELECT a.created_at AS at FROM app.activity a
                                 WHERE a.task_id = t.id
                                   AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)
                                 ORDER BY a.created_at DESC LIMIT 1) x
                          WHERE t.board_id = b.id),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;

GRANT EXECUTE ON FUNCTION app.my_ids(), app.my_edit_boards(), app.my_task_ids(),
                          app.my_member_boards(), app.my_boards() TO app_user;

-- Индексы для внешних ключей, по которым выполняются соединения и каскадное удаление.
CREATE INDEX IF NOT EXISTS attachments_file_idx      ON app.attachments (file_id);
CREATE INDEX IF NOT EXISTS chat_messages_file_idx    ON app.chat_messages (file_id)    WHERE file_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS chart_attachments_file_idx ON app.chart_attachments (file_id);
CREATE INDEX IF NOT EXISTS notifications_task_idx    ON app.notifications (task_id)    WHERE task_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_board_idx   ON app.notifications (board_id)   WHERE board_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_chart_idx   ON app.notifications (chart_id)   WHERE chart_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS notifications_wb_idx      ON app.notifications (wb_id)      WHERE wb_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS comments_author_idx       ON app.comments (author_id);
CREATE INDEX IF NOT EXISTS activity_actor_idx        ON app.activity (actor_id);

ANALYZE;


-- #####################################################################
-- Миграция 0029_reminder_alerts.sql
-- #####################################################################

\echo '--> 0029_reminder_alerts.sql'

-- Скрипт предназначен для журнала сработавших напоминаний: окно напоминания показывается не только тем, кто был в сети в момент
-- срабатывания, но и при первом входе после неактивности (отпуск, выходные), пока пользователь не закроет его явным действием.
--
-- Также исправлено накопление: повторяющееся напоминание, пропущенное на несколько периодов, срабатывает один раз
-- и переносится на ближайший будущий момент, а не по одному периоду за каждую минуту опроса.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0029_reminder_alerts.sql
--
-- Выполняется от app_owner после 0028_visibility_sets.sql, идемпотентен.

SET search_path = app, public;

-- Таблица app.reminder_alerts предназначена для хранения сработавших напоминаний до подтверждения пользователем.
CREATE TABLE IF NOT EXISTS app.reminder_alerts (
    id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    reminder_id uuid        REFERENCES app.reminders(id) ON DELETE SET NULL,
    title       text        NOT NULL,
    task_id     uuid        REFERENCES app.tasks(id) ON DELETE SET NULL,
    due_at      timestamptz NOT NULL,
    fired_at    timestamptz NOT NULL DEFAULT now(),
    acked_at    timestamptz
);
CREATE INDEX IF NOT EXISTS reminder_alerts_open_idx ON app.reminder_alerts (user_id, fired_at) WHERE acked_at IS NULL;
CREATE INDEX IF NOT EXISTS reminder_alerts_reminder_idx ON app.reminder_alerts (reminder_id) WHERE reminder_id IS NOT NULL;

ALTER TABLE app.reminder_alerts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS reminder_alerts_own ON app.reminder_alerts;
CREATE POLICY reminder_alerts_own ON app.reminder_alerts FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, UPDATE, DELETE ON app.reminder_alerts TO app_user;

-- Функция app.record_reminder_alert предназначена для записи сработавшего напоминания в журнал; вызывается фоновым опросом.
-- Возвращает идентификатор записи и момент, на который напоминание было назначено.
CREATE OR REPLACE FUNCTION app.record_reminder_alert(p_id uuid)
RETURNS TABLE (alert_id uuid, due_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE r app.reminders%ROWTYPE;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    -- Старые записи удаляются: подтверждённые через 30 суток, неподтверждённые через 90.
    DELETE FROM app.reminder_alerts a
     WHERE a.user_id = r.user_id
       AND ((a.acked_at IS NOT NULL AND a.acked_at < now() - interval '30 days')
         OR a.fired_at < now() - interval '90 days');
    RETURN QUERY
        INSERT INTO app.reminder_alerts (user_id, reminder_id, title, task_id, due_at)
        VALUES (r.user_id, r.id, r.title, r.task_id, r.remind_at)
        RETURNING id, reminder_alerts.due_at;
END $$;
REVOKE ALL ON FUNCTION app.record_reminder_alert(uuid) FROM PUBLIC;

-- Функция app.advance_reminder предназначена для переноса напоминания после срабатывания. Повторяющееся переносится
-- на ближайший момент в будущем (пропущенные периоды не срабатывают по одному), однократное отключается.
CREATE OR REPLACE FUNCTION app.advance_reminder(p_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r app.reminders%ROWTYPE;
    v_next timestamptz;
    v_guard int := 0;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    IF r.recur_freq = 'none' THEN
        UPDATE app.reminders SET active = false, last_fired = now() WHERE id = p_id;
    ELSE
        v_next := app.next_reminder_at(r.remind_at, r.recur_freq, r.recur_interval, r.recur_weekdays);
        WHILE v_next <= now() AND v_guard < 2000 LOOP
            v_next := app.next_reminder_at(v_next, r.recur_freq, r.recur_interval, r.recur_weekdays);
            v_guard := v_guard + 1;
        END LOOP;
        UPDATE app.reminders SET last_fired = now(), remind_at = v_next WHERE id = p_id;
    END IF;
END $$;


-- #####################################################################
-- Миграция 0030_access_matrix.sql
-- #####################################################################

\echo '--> 0030_access_matrix.sql'

-- Скрипт предназначен для панели «Доступы»: (1) матрица «все мои проекты, диаграммы и доски и статус доступа выбранного
-- пользователя» с выдачей и снятием доступа к диаграммам и доскам по образцу проектов; (2) обзор доступов ограничен
-- объектами, где просматривающий владелец или редактор (исполнитель — для задач), без исключения для администратора.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0030_access_matrix.sql
--
-- Выполняется от app_owner после 0029_reminder_alerts.sql, идемпотентен.

SET search_path = app, public;

-- Функция app.access_matrix предназначена для выдачи всех объектов текущего пользователя, доступом к которым он вправе
-- управлять (проекты, диаграммы, доски: он владелец или редактор), и уровня доступа выбранного пользователя (NULL — доступа нет).
CREATE OR REPLACE FUNCTION app.access_matrix(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE v_me uuid := app.current_user_id();
BEGIN
    IF v_me IS NULL THEN RETURN; END IF;

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.boards b
      LEFT JOIN app.board_members m ON m.board_id = b.id AND m.user_id = p_target
     WHERE NOT b.archived AND app.can_edit_board(b.id, v_me)
     ORDER BY b.title;

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.charts c
      LEFT JOIN app.chart_members m ON m.chart_id = c.id AND m.user_id = p_target
     WHERE app.can_edit_chart(c.id, v_me)
     ORDER BY c.title;

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, m.role::text,
           (m.role IS NULL OR m.role <> 'owner')
      FROM app.whiteboards w
      LEFT JOIN app.whiteboard_members m ON m.board_id = w.id AND m.user_id = p_target
     WHERE app.can_edit_wb(w.id, v_me)
     ORDER BY w.title;
END $$;

-- Функция app.set_object_access предназначена для выдачи или смены роли в диаграмме или доске (p_kind: chart | whiteboard).
-- Выдавать вправе владелец и редактор; роль владельца не меняется. Возвращает прежнюю роль.
CREATE OR REPLACE FUNCTION app.set_object_access(p_kind text, p_object uuid, p_user uuid, p_role text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_me uuid := app.current_user_id(); v_prev text;
BEGIN
    IF p_role NOT IN ('editor', 'reader') THEN
        RAISE EXCEPTION 'Роль может быть только «редактор» или «исполнитель»' USING ERRCODE = '22023';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;
    IF p_kind = 'chart' THEN
        IF app.can_edit_chart(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой диаграмме' USING ERRCODE = '42501';
        END IF;
        SELECT role::text INTO v_prev FROM app.chart_members WHERE chart_id = p_object AND user_id = p_user;
        IF v_prev = 'owner' THEN
            RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
        END IF;
        INSERT INTO app.chart_members (chart_id, user_id, role) VALUES (p_object, p_user, p_role::app.board_role)
        ON CONFLICT (chart_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    ELSIF p_kind = 'whiteboard' THEN
        IF app.can_edit_wb(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой доске' USING ERRCODE = '42501';
        END IF;
        SELECT role::text INTO v_prev FROM app.whiteboard_members WHERE board_id = p_object AND user_id = p_user;
        IF v_prev = 'owner' THEN
            RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
        END IF;
        INSERT INTO app.whiteboard_members (board_id, user_id, role) VALUES (p_object, p_user, p_role::app.board_role)
        ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    ELSE
        RAISE EXCEPTION 'Неизвестный тип объекта' USING ERRCODE = '22023';
    END IF;
    RETURN v_prev;
END $$;

-- Функция app.revoke_object_access предназначена для снятия доступа к диаграмме или доске; владельца снять нельзя.
CREATE OR REPLACE FUNCTION app.revoke_object_access(p_kind text, p_object uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_me uuid := app.current_user_id(); n int;
BEGIN
    IF p_kind = 'chart' THEN
        IF app.can_edit_chart(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой диаграмме' USING ERRCODE = '42501';
        END IF;
        DELETE FROM app.chart_members WHERE chart_id = p_object AND user_id = p_user AND role <> 'owner';
    ELSIF p_kind = 'whiteboard' THEN
        IF app.can_edit_wb(p_object, v_me) IS NOT TRUE THEN
            RAISE EXCEPTION 'Нет права управлять доступом к этой доске' USING ERRCODE = '42501';
        END IF;
        DELETE FROM app.whiteboard_members WHERE board_id = p_object AND user_id = p_user AND role <> 'owner';
    ELSE
        RAISE EXCEPTION 'Неизвестный тип объекта' USING ERRCODE = '22023';
    END IF;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n > 0;
END $$;

-- Функция app.access_overview предназначена для обзора доступов выбранного пользователя только в объектах просматривающего:
-- проекты и диаграммы/доски, где он владелец или редактор, задачи, где он редактор или исполнитель. Исключения для
-- администратора нет: чужие проекты в панели не раскрываются. Замещения показываются администратору.
CREATE OR REPLACE FUNCTION app.access_overview(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, board_id uuid, board_title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE v_me uuid := app.current_user_id(); v_admin boolean;
BEGIN
    IF v_me IS NULL THEN RETURN; END IF;
    v_admin := app.is_admin(v_me);

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, b.id, b.title, m.role::text,
           app.can_manage_board_access(b.id, v_me) AND (m.role <> 'owner' OR v_admin)
      FROM app.board_members m JOIN app.boards b ON b.id = m.board_id
     WHERE m.user_id = p_target AND app.can_edit_board(b.id, v_me);

    RETURN QUERY
    SELECT 'task_grant'::text, t.id, t.title, b.id, b.title, g.access::text,
           app.can_manage_task_access(t.id, v_me)
      FROM app.task_grants g
      JOIN app.tasks t  ON t.id = g.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE g.user_id = p_target AND app.can_edit_task(t.id, v_me);

    RETURN QUERY
    SELECT 'task_assignee'::text, t.id, t.title, b.id, b.title, NULL::text, false
      FROM app.task_assignees a
      JOIN app.tasks t  ON t.id = a.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE a.user_id = p_target AND NOT t.archived AND t.completed_at IS NULL
       AND app.can_edit_task(t.id, v_me);

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, NULL::uuid, NULL::text, m.role::text, (m.role <> 'owner')
      FROM app.chart_members m JOIN app.charts c ON c.id = m.chart_id
     WHERE m.user_id = p_target AND app.can_edit_chart(c.id, v_me);

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, NULL::uuid, NULL::text, m.role::text, (m.role <> 'owner')
      FROM app.whiteboard_members m JOIN app.whiteboards w ON w.id = m.board_id
     WHERE m.user_id = p_target AND app.can_edit_wb(w.id, v_me);

    IF NOT v_admin THEN RETURN; END IF;

    RETURN QUERY
    SELECT 'delegation_to'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.deputy_id
     WHERE d.grantor_id = p_target AND d.ends_at >= current_date;

    RETURN QUERY
    SELECT 'delegation_from'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.grantor_id
     WHERE d.deputy_id = p_target AND d.ends_at >= current_date;
END $$;

GRANT EXECUTE ON FUNCTION app.access_matrix(uuid)                      TO app_user;
GRANT EXECUTE ON FUNCTION app.set_object_access(text, uuid, uuid, text) TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_object_access(text, uuid, uuid)   TO app_user;
GRANT EXECUTE ON FUNCTION app.access_overview(uuid)                    TO app_user;


-- #####################################################################
-- Миграция 0031_chat_replies.sql
-- #####################################################################

\echo '--> 0031_chat_replies.sql'

-- Скрипт предназначен для ответов на сообщения в личных и групповых чатах (как в Telegram): сообщение хранит ссылку
-- на сообщение, на которое отвечает. При удалении исходного сообщения из БД ссылка обнуляется, при мягком удалении
-- цитата показывается как «Сообщение удалено».
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0031_chat_replies.sql
--
-- Выполняется от app_owner после 0030_access_matrix.sql, идемпотентен.

ALTER TABLE app.chat_messages
    ADD COLUMN IF NOT EXISTS reply_to_id uuid REFERENCES app.chat_messages(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS chat_messages_reply_idx ON app.chat_messages (reply_to_id) WHERE reply_to_id IS NOT NULL;


-- #####################################################################
-- Миграция 0032_self_password_repair.sql
-- #####################################################################

\echo '--> 0032_self_password_repair.sql'

-- Скрипт предназначен для восстановления функции app.my_password_hash (миграция 0023) в базах, где она не была применена:
-- при самостоятельной смене пароля сервер получал ошибку «function app.my_password_hash does not exist».
-- Функция возвращает хеш пароля только текущего пользователя и нужна для проверки текущего пароля.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0032_self_password_repair.sql
--
-- Выполняется от app_owner (или суперпользователем после SET ROLE app_owner), идемпотентен.

CREATE OR REPLACE FUNCTION app.my_password_hash()
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.password_hash
      FROM app.users u
     WHERE u.id = app.current_user_id()
       AND u.deleted_at IS NULL
       AND u.is_active
$$;

REVOKE EXECUTE ON FUNCTION app.my_password_hash() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.my_password_hash() TO app_user;


-- #####################################################################
-- Миграция 0033_user_preferences.sql
-- #####################################################################

\echo '--> 0033_user_preferences.sql'

-- Скрипт предназначен для хранения пользовательских настроек интерфейса на сервере (масштаб элементов, размер шрифта):
-- настройки принадлежат пользователю, а не браузеру, и применяются на любом устройстве. Значение — JSON ограниченного размера.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0033_user_preferences.sql
--
-- Выполняется от app_owner после 0032_self_password_repair.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.user_preferences (
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    key        text        NOT NULL CHECK (key ~ '^[a-z][a-z0-9_.]{0,63}$'),
    value      jsonb       NOT NULL CHECK (pg_column_size(value) <= 8192),
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);

ALTER TABLE app.user_preferences ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS user_preferences_own ON app.user_preferences;
CREATE POLICY user_preferences_own ON app.user_preferences FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.user_preferences TO app_user;


-- #####################################################################
-- Миграция 0034_chat_reopen.sql
-- #####################################################################

\echo '--> 0034_chat_reopen.sql'

-- Скрипт предназначен для исправления повторного начала личного чата после его удаления: удаление только скрывает чат у
-- пользователя (hidden_at), а app.ensure_direct_chat возвращала скрытый чат, который не попадал в список, — начать новый
-- чат с тем же собеседником было невозможно. Теперь чат возвращается в список того, кто его открывает; история остаётся
-- очищенной (cleared_at не меняется).
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0034_chat_reopen.sql
--
-- Выполняется от app_owner, идемпотентен.

CREATE OR REPLACE FUNCTION app.ensure_direct_chat(p_a uuid, p_b uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
BEGIN
    IF p_a IS NULL OR p_b IS NULL OR p_a = p_b THEN
        RAISE EXCEPTION 'bad_direct_chat';
    END IF;

    SELECT c.id INTO v_id
      FROM app.chats c
      JOIN app.chat_members m1 ON m1.chat_id = c.id AND m1.user_id = p_a
      JOIN app.chat_members m2 ON m2.chat_id = c.id AND m2.user_id = p_b
     WHERE c.kind = 'direct'
     LIMIT 1;

    IF v_id IS NOT NULL THEN
        -- Скрытый (удалённый у p_a) чат возвращается в его список.
        UPDATE app.chat_members SET hidden_at = NULL WHERE chat_id = v_id AND user_id = p_a AND hidden_at IS NOT NULL;
        RETURN v_id;
    END IF;

    INSERT INTO app.chats (kind, owner_id) VALUES ('direct', p_a) RETURNING id INTO v_id;
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_a), (v_id, p_b);
    RETURN v_id;
END $$;


-- #####################################################################
-- Миграция 0035_chat_reactions_forward.sql
-- #####################################################################

\echo '--> 0035_chat_reactions_forward.sql'

-- Скрипт предназначен для реакций на сообщения чатов (эмодзи, как в YouGile) и пересылки сообщений с отметкой автора.
-- Реакция — пара «сообщение, пользователь, эмодзи»; повторное нажатие снимает её. Пересланное сообщение хранит автора
-- и время исходного сообщения.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0035_chat_reactions_forward.sql
--
-- Выполняется от app_owner после 0034_chat_reopen.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.chat_reactions (
    message_id uuid        NOT NULL REFERENCES app.chat_messages(id) ON DELETE CASCADE,
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    emoji      text        NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 16),
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (message_id, user_id, emoji)
);
CREATE INDEX IF NOT EXISTS chat_reactions_message_idx ON app.chat_reactions (message_id, created_at);

ALTER TABLE app.chat_reactions ENABLE ROW LEVEL SECURITY;

-- Функция app.message_chat предназначена для получения чата сообщения (SECURITY DEFINER: политики не зацикливаются).
CREATE OR REPLACE FUNCTION app.message_chat(p_message uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT chat_id FROM app.chat_messages WHERE id = p_message $$;
GRANT EXECUTE ON FUNCTION app.message_chat(uuid) TO app_user;

DROP POLICY IF EXISTS chat_reactions_select ON app.chat_reactions;
CREATE POLICY chat_reactions_select ON app.chat_reactions FOR SELECT
    USING (app.in_chat(app.message_chat(message_id), app.current_user_id()));
DROP POLICY IF EXISTS chat_reactions_insert ON app.chat_reactions;
CREATE POLICY chat_reactions_insert ON app.chat_reactions FOR INSERT
    WITH CHECK (user_id = app.current_user_id()
                AND app.in_chat(app.message_chat(message_id), app.current_user_id()));
DROP POLICY IF EXISTS chat_reactions_delete ON app.chat_reactions;
CREATE POLICY chat_reactions_delete ON app.chat_reactions FOR DELETE
    USING (user_id = app.current_user_id());
GRANT SELECT, INSERT, DELETE ON app.chat_reactions TO app_user;

ALTER TABLE app.chat_messages
    ADD COLUMN IF NOT EXISTS fwd_author_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS fwd_at        timestamptz;


-- #####################################################################
-- Миграция 0036_task_favorites.sql
-- #####################################################################

\echo '--> 0036_task_favorites.sql'

-- Скрипт предназначен для избранных задач (🌟): у каждого пользователя собственный список.
-- Отметка хранится независимо от состояния задачи: закрытая задача из списка избранных скрывается запросом,
-- но отметка не снимается и вернётся при повторном открытии задачи.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0036_task_favorites.sql
--
-- Выполняется от app_owner после 0035_chat_reactions_forward.sql, идемпотентен.

CREATE TABLE IF NOT EXISTS app.task_favorites (
    user_id    uuid        NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    task_id    uuid        NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, task_id)
);
CREATE INDEX IF NOT EXISTS task_favorites_task_idx ON app.task_favorites (task_id);

ALTER TABLE app.task_favorites ENABLE ROW LEVEL SECURITY;

-- Видна и меняется только собственная отметка; добавить можно только задачу, которую пользователь видит.
DROP POLICY IF EXISTS task_favorites_select ON app.task_favorites;
CREATE POLICY task_favorites_select ON app.task_favorites FOR SELECT
    USING (user_id = app.current_user_id());
DROP POLICY IF EXISTS task_favorites_insert ON app.task_favorites;
CREATE POLICY task_favorites_insert ON app.task_favorites FOR INSERT
    WITH CHECK (user_id = app.current_user_id()
                AND EXISTS (SELECT 1 FROM app.tasks t WHERE t.id = task_id));
DROP POLICY IF EXISTS task_favorites_delete ON app.task_favorites;
CREATE POLICY task_favorites_delete ON app.task_favorites FOR DELETE
    USING (user_id = app.current_user_id());
GRANT SELECT, INSERT, DELETE ON app.task_favorites TO app_user;


-- #####################################################################
-- Миграция 0037_system_counts_repair.sql
-- #####################################################################

\echo '--> 0037_system_counts_repair.sql'

-- Скрипт предназначен для получения счётчиков объёма системы для метрик: функция app.system_counts возвращает число проектов,
-- задач, досок и других сущностей. Подсчёт выполняется функцией с правами владельца, так как опрос метрик идёт вне
-- пользовательской транзакции (app.current_user_id() равен NULL) и политики RLS не пропускают ни одной строки.
-- Функция возвращает только итоговые числа и не раскрывает названия и содержимое.
--
-- Повторно создаёт функцию 0024 для баз, развёрнутых без неё («function app.system_counts() does not exist»).
-- Выполняется от app_owner после 0036_task_favorites.sql, идемпотентен (CREATE OR REPLACE).

-- Функция app.system_counts предназначена для подсчёта сущностей системы (SECURITY DEFINER).

CREATE OR REPLACE FUNCTION app.system_counts()
RETURNS TABLE (kind text, n bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT 'boards',  count(*) FROM app.boards WHERE NOT archived
    UNION ALL SELECT 'boards_archived', count(*) FROM app.boards WHERE archived
    UNION ALL SELECT 'tasks', count(*) FROM app.tasks WHERE NOT archived
    UNION ALL SELECT 'tasks_open', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
    UNION ALL SELECT 'tasks_done', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NOT NULL
    UNION ALL SELECT 'tasks_overdue', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
                AND due_date IS NOT NULL AND due_date < current_date
    UNION ALL SELECT 'tasks_archived', count(*) FROM app.tasks WHERE archived
    UNION ALL SELECT 'users', count(*) FROM app.users WHERE deleted_at IS NULL
    UNION ALL SELECT 'users_active', count(*) FROM app.users
              WHERE is_active AND deleted_at IS NULL
    UNION ALL SELECT 'users_online_day', count(DISTINCT user_id)
              FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND created_at > now() - interval '1 day'
    UNION ALL SELECT 'comments', count(*) FROM app.comments
    UNION ALL SELECT 'attachments', count(*) FROM app.attachments
    UNION ALL SELECT 'charts', count(*) FROM app.charts
    UNION ALL SELECT 'whiteboards', count(*) FROM app.whiteboards
    UNION ALL SELECT 'chats', count(*) FROM app.chats
    UNION ALL SELECT 'chat_messages', count(*) FROM app.chat_messages
    UNION ALL SELECT 'reminders', count(*) FROM app.reminders
    UNION ALL SELECT 'notifications_unread', count(*) FROM app.notifications
              WHERE read_at IS NULL
    UNION ALL SELECT 'sessions', count(*) FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND expires_at > now()
$$;

COMMENT ON FUNCTION app.system_counts() IS
    'Итоговые количества объектов для метрик. Только числа: содержимого '
    'не отдаёт, поэтому обхода политик доступа не создаёт.';

-- Право вызова отзывается у PUBLIC и выдаётся адресно.
REVOKE EXECUTE ON FUNCTION app.system_counts() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.system_counts() TO app_user;


-- #####################################################################
-- Миграция 0038_forwarded_immutable.sql
-- #####################################################################

\echo '--> 0038_forwarded_immutable.sql'

-- Скрипт предназначен для защиты пересланных сообщений от правки: текст и вложение сообщения с пометкой «Переслано от …»
-- изменить нельзя никому, включая переславшего (иначе можно приписать автору слова, которых он не писал).
-- Удаление сообщения (deleted_at) разрешено.
--
-- Выполняется от app_owner после 0037_system_counts_repair.sql, идемпотентен.

CREATE OR REPLACE FUNCTION app.chat_forwarded_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.fwd_author_id IS NOT NULL
       AND (NEW.body IS DISTINCT FROM OLD.body OR NEW.file_id IS DISTINCT FROM OLD.file_id)
       AND NEW.deleted_at IS NOT DISTINCT FROM OLD.deleted_at THEN
        RAISE EXCEPTION 'Пересланное сообщение нельзя изменить' USING ERRCODE = 'P0001';
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS chat_forwarded_guard ON app.chat_messages;
CREATE TRIGGER chat_forwarded_guard BEFORE UPDATE ON app.chat_messages
    FOR EACH ROW EXECUTE FUNCTION app.chat_forwarded_guard();


-- #####################################################################
-- Миграция 0039_user_login_source.sql
-- #####################################################################

\echo '--> 0039_user_login_source.sql'

-- Миграция 0039 предназначена для входа по Kerberos и сверки с LDAP: у пользователя появляются логин (principal вида
-- ii-ivanov@DOMAIN1.LOCAL) и источник сведений (local — в базе, иначе идентификатор LDAP-сервера из конфигурации).
-- Логины ii-ivanov@DOMAIN1.LOCAL и ii-ivanov@DOMAIN2.LOCAL — разные пользователи; регистр не различается.
-- Применение: psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0039_user_login_source.sql

ALTER TABLE app.users ADD COLUMN IF NOT EXISTS login  text NOT NULL DEFAULT '';
ALTER TABLE app.users ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'local';

-- Логин уникален среди неудалённых пользователей; пустой логин (вход только по паролю) не учитывается.
CREATE UNIQUE INDEX IF NOT EXISTS users_login_uq ON app.users (lower(login))
    WHERE login <> '' AND deleted_at IS NULL;

GRANT SELECT (login, source) ON app.users TO app_user;
GRANT UPDATE (login, source) ON app.users TO app_user;

-- Функция app.user_by_login предназначена для поиска пользователя по логину при входе по Kerberos (до появления app.user_id).
CREATE OR REPLACE FUNCTION app.user_by_login(p_login text)
RETURNS TABLE (id uuid, is_active boolean, role text, source text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.id, u.is_active, u.role::text, u.source
      FROM app.users u
     WHERE lower(u.login) = lower(p_login) AND u.login <> '' AND u.deleted_at IS NULL
$$;

-- Функция app.user_source предназначена для получения логина и источника сведений пользователя при входе по паролю.
CREATE OR REPLACE FUNCTION app.user_source(p_user uuid)
RETURNS TABLE (login text, source text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT u.login, u.source FROM app.users u WHERE u.id = p_user
$$;

-- Функция app.sync_user_profile предназначена для актуализации сведений из LDAP при входе. Пустые значения не затирают
-- имеющиеся; почта меняется, только если она не занята другим пользователем. Роль и активность не затрагиваются.
CREATE OR REPLACE FUNCTION app.sync_user_profile(p_user uuid, p_full_name text, p_position text, p_phone text, p_email text)
RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    UPDATE app.users u SET
        full_name = COALESCE(NULLIF(btrim(p_full_name), ''), u.full_name),
        position  = COALESCE(NULLIF(btrim(p_position), ''), u.position),
        phone     = COALESCE(NULLIF(btrim(p_phone), ''), u.phone),
        email     = CASE WHEN NULLIF(btrim(p_email), '') IS NOT NULL
                          AND NOT EXISTS (SELECT 1 FROM app.users o WHERE o.email = btrim(p_email) AND o.id <> u.id)
                         THEN btrim(p_email) ELSE u.email END,
        updated_at = now()
     WHERE u.id = p_user
$$;

REVOKE EXECUTE ON FUNCTION app.user_by_login(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.user_source(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.sync_user_profile(uuid, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.user_by_login(text) TO app_user;
GRANT EXECUTE ON FUNCTION app.user_source(uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.sync_user_profile(uuid, text, text, text, text) TO app_user;


RESET ROLE;
