import { useQuery } from '@tanstack/react-query';

// ---------- Типы (совпадают с JSON сервера) ----------

export interface Agent {
  id: string; machine_id: string; hostname: string; name: string;
  status: 'pending' | 'approved' | 'rejected' | 'disabled';
  version: string | null; last_seen: string | null;
  clock_synced: boolean | null; clock_err_us: number | null;
  channels: number; groups: number[]; created_at: string;
}

export interface Channel {
  id: number; agent_id: string; agent: string;
  name: string; display_name: string | null; label: string; tags: string[]; stale: boolean;
  interface: string; source_ip: string | null; reflector: string; dscp: number; dscp_name: string;
  profile_id: number; sla_id: number | null; enabled: boolean; groups: number[];
}

export interface ChannelPatch {
  display_name?: string; tags?: string[]; enabled?: boolean;
  profile_id?: number; sla_id?: number; clear_sla?: boolean;
}

export interface User {
  id: number; login: string; role: 'big_admin' | 'admin' | 'viewer';
  disabled: boolean; groups: number[]; last_login: string | null;
}

export type DashVisibility = 'private' | 'users' | 'shared';
export interface DashboardMeta {
  id: number; owner_id: number | null; name: string; shared: boolean;
  visibility: DashVisibility; own: boolean;
  layout: unknown;
}
export interface DashWidget {
  id?: number; kind: WidgetKind; title: string; config: WidgetConfig; pos?: number;
}
export type WidgetKind = 'timeseries' | 'stat' | 'topN' | 'load' | 'alerts';
export interface WidgetConfig {
  channel_ids?: number[];
  metric?: string;         // rtt_avg | loss_pct | fwd_loss_pct | bwd_loss_pct | fwd_jitter | ...
  chart?: 'line' | 'area' | 'bar';
  range?: RangeKey;
  topN?: number;
  monitor_ids?: number[];  // для kind=load
  w?: number;              // ширина в колонках сетки (1..4)
  h?: number;              // высота содержимого, px
  refresh_sec?: number;    // период автообновления виджета, с (0 — по умолчанию)
}
export interface Dashboard extends DashboardMeta { widgets: DashWidget[]; shares: number[] }

export interface Group { id: number; parent_id: number | null; name: string; tags: string[]; channels: number }

export interface SeriesPoint {
  ts: string; sent: number | null; received: number | null;
  loss_pct: number | null; fwd_loss_pct: number | null; bwd_loss_pct: number | null;
  rtt_avg: number | null; rtt_p95: number | null; rtt_max: number | null;
  fwd_delay_avg: number | null; bwd_delay_avg: number | null;
  fwd_jitter: number | null; bwd_jitter: number | null;
  fwd_remarked: number | null; bwd_remarked: number | null; mos: number | null;
}

export interface SmokePoint { ts: string; rtt_q: number[] | null; rtt_p50: number | null; loss_pct: number | null }

export interface LoadPoint {
  ts: string; rx_bps: number | null; tx_bps: number | null;
  rx_util_pct: number | null; tx_util_pct: number | null;
  rx_pps: number | null; tx_pps: number | null; rx_drops: number | null; tx_drops: number | null;
}

export interface IfaceMonitor {
  id: number; agent_id: string; agent: string; interface: string;
  speed_bits: number | null; interval_sec: number; enabled: boolean;
  ts: string | null; rx_bps: number | null; tx_bps: number | null;
  rx_util_pct: number | null; tx_util_pct: number | null; rx_drops: number | null; tx_drops: number | null;
}

export interface LatestRow {
  channel_id: number; channel: string; agent_id: string; agent: string; interface: string;
  reflector: string; dscp: number; dscp_name: string; ts: string;
  rtt_avg: number | null; fwd_delay_avg: number | null; bwd_delay_avg: number | null;
  fwd_jitter: number | null; bwd_jitter: number | null;
  loss_pct: number | null; fwd_loss_pct: number | null; bwd_loss_pct: number | null;
  mos: number | null; fwd_remarked: number | null; bwd_remarked: number | null;
}

export interface Alert {
  id: number; kind: string; severity: 'warning' | 'critical';
  started_at: string; ended_at: string | null; last_seen_at: string | null; acked_at: string | null;
  details: Record<string, unknown> | null;
  channel_id: number | null; channel: string | null; dscp_name: string | null;
  agent_id: string | null; agent: string | null;
}

export interface Overview {
  agents_total: number; agents_online: number; agents_pending: number; channels: number;
  latest: LatestRow[] | null; open_alerts: Alert[] | null;
}

export interface SLAProfile {
  id: number; name: string;
  max_rtt_ms: number | null; max_oneway_ms: number | null; max_jitter_ms: number | null;
  max_loss_pct: number | null; min_mos: number | null; max_util_pct: number | null;
  allow_remarking: boolean; breach_intervals: number; channels: number;
}

export interface TestProfile { id: number; name: string; pps: number; packet_size: number; poisson: boolean; interval_sec: number }

export interface TestRunItem {
  id: number; kind: string; group_id: number | null; group_name: string | null;
  channel_id: number | null; target: string;
  start_at: string; duration_sec: number; expected: number; received: number; status: string;
  created_by: string | null; created_at: string;
}

export interface IntervalSummary { min: number; avg: number; p50: number; p95: number; p99: number; max: number }
export interface IntervalResult {
  sent: number; received: number; rtt?: IntervalSummary; fwd?: IntervalSummary; bwd?: IntervalSummary;
  fwd_jitter: number; bwd_jitter: number; mos: number; oneway_valid: boolean;
  fwd_remarked: number; bwd_remarked: number;
}
export interface TestResultDetail {
  channel_id: number; channel: string; agent: string;
  state: 'ok' | 'fail' | 'pending';
  result: IntervalResult | null; error: string | null;
}
export interface TestRunDetail extends Omit<TestRunItem, 'group_name' | 'received'> {
  kind: string; created_at: string; channel_id: number | null;
  results: TestResultDetail[] | null;
}

// ---------- Транспорт ----------

// Авторизация — серверная, по логину/паролю. Сервер ставит HttpOnly-cookie сессии,
// поэтому токен не хранится в JS и недоступен для XSS. Все запросы идут с credentials.

export interface Me { login: string; role: 'big_admin' | 'admin' | 'viewer' }

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  // 401 на любом запросе, кроме самого логина, означает истёкшую сессию —
  // сообщаем приложению, чтобы оно показало экран входа.
  if (res.status === 401 && !path.endsWith('/login')) {
    window.dispatchEvent(new Event('linkmon:logout'));
  }
  const text = await res.text();
  if (!res.ok) {
    let msg = res.statusText;
    try { msg = JSON.parse(text).error ?? msg; } catch { /* не JSON */ }
    throw new ApiError(res.status, msg);
  }
  return (text ? JSON.parse(text) : undefined) as T;
}

export const api = {
  get: <T>(p: string) => request<T>('GET', p),
  post: <T>(p: string, b: unknown = {}) => request<T>('POST', p, b),
  put: <T>(p: string, b: unknown) => request<T>('PUT', p, b),
  patch: <T>(p: string, b: unknown) => request<T>('PATCH', p, b),
  del: <T>(p: string) => request<T>('DELETE', p),

  login: (login: string, password: string) => request<Me>('POST', '/v1/admin/login', { login, password }),
  logout: () => request<void>('POST', '/v1/admin/logout'),
  whoami: () => request<Me>('GET', '/v1/admin/whoami'),
  changePassword: (oldPassword: string, newPassword: string) =>
    request<void>('POST', '/v1/admin/change-password', { old_password: oldPassword, new_password: newPassword }),
};

// ---------- Диапазоны времени ----------

export const ranges = {
  '30m': 30 * 60e3, '1h': 3600e3, '3h': 3 * 3600e3, '6h': 6 * 3600e3, '24h': 24 * 3600e3, '7d': 7 * 86400e3,
} as const;
export type RangeKey = keyof typeof ranges;

function rangeQuery(r: RangeKey) {
  const to = new Date();
  const from = new Date(to.getTime() - ranges[r]);
  return `from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}`;
}

// rangeWindow — абсолютные границы выбранного диапазона (мс) для оси времени графиков,
// чтобы ось всегда охватывала весь период, даже когда данных мало.
export function rangeWindow(r: RangeKey): { min: number; max: number } {
  const max = Date.now();
  return { min: max - ranges[r], max };
}

// ---------- Хуки ----------

export const useOverview = () =>
  useQuery({ queryKey: ['overview'], queryFn: () => api.get<Overview>('/v1/admin/overview'), refetchInterval: 30_000 });

export const useAgents = () =>
  useQuery({ queryKey: ['agents'], queryFn: () => api.get<Agent[]>('/v1/admin/agents'), refetchInterval: 15_000 });

export const useChannels = () =>
  useQuery({ queryKey: ['channels'], queryFn: () => api.get<Channel[]>('/v1/admin/channels') });

export const useGroups = () =>
  useQuery({ queryKey: ['groups'], queryFn: () => api.get<Group[]>('/v1/admin/groups') });

export const useSeries = (id: number, r: RangeKey) =>
  useQuery({
    queryKey: ['series', id, r],
    queryFn: () => api.get<{ source: string; points: SeriesPoint[] | null }>(`/v1/admin/channels/${id}/series?${rangeQuery(r)}`),
    refetchInterval: 60_000,
  });

export const useSmoke = (id: number, r: RangeKey) =>
  useQuery({
    queryKey: ['smoke', id, r],
    queryFn: () => api.get<{ points: SmokePoint[] | null }>(`/v1/admin/channels/${id}/smoke?${rangeQuery(r)}`),
    refetchInterval: 60_000,
  });

export const useIfaceMonitors = () =>
  useQuery({
    queryKey: ['iface-monitors'],
    queryFn: () => api.get<IfaceMonitor[]>('/v1/admin/iface-load'),
    refetchInterval: 30_000,
  });

export const useChannelLoad = (id: number, r: RangeKey) =>
  useQuery({
    queryKey: ['channel-load', id, r],
    queryFn: () => api.get<{ monitor_id: number; points: LoadPoint[] | null }>(`/v1/admin/channels/${id}/load?${rangeQuery(r)}`),
    refetchInterval: 60_000,
  });

export const useLoadSeries = (monitorId: number | null, r: RangeKey) =>
  useQuery({
    queryKey: ['load-series', monitorId, r],
    queryFn: () => api.get<{ points: LoadPoint[] | null }>(`/v1/admin/iface-monitors/${monitorId}/series?${rangeQuery(r)}`),
    enabled: monitorId !== null,
    refetchInterval: 60_000,
  });

export const useAlerts = (state: 'open' | 'all', channelId?: number) =>
  useQuery({
    queryKey: ['alerts', state, channelId],
    queryFn: () => api.get<Alert[]>(`/v1/admin/alerts?state=${state}${channelId ? `&channel_id=${channelId}` : ''}`),
    refetchInterval: 30_000,
  });

export const useSLA = () =>
  useQuery({ queryKey: ['sla'], queryFn: () => api.get<SLAProfile[]>('/v1/admin/sla-profiles') });

export const useTestRuns = (groupId?: number) =>
  useQuery({
    queryKey: ['tests', groupId],
    queryFn: () => api.get<TestRunItem[]>(`/v1/admin/tests${groupId ? `?group_id=${groupId}` : ''}`),
    refetchInterval: 5_000,
  });

// Вся история тестов (последние N), без фильтра по группе.
export const useTestHistory = (limit = 500) =>
  useQuery({
    queryKey: ['test-history', limit],
    queryFn: () => api.get<TestRunItem[]>(`/v1/admin/tests?limit=${limit}`),
    refetchInterval: 10_000,
  });

export const useTestRun = (id: number | null) =>
  useQuery({
    queryKey: ['test', id],
    queryFn: () => api.get<TestRunDetail>(`/v1/admin/tests/${id}`),
    enabled: id !== null,
    refetchInterval: (q) => (q.state.data?.status === 'done' ? false : 3_000),
  });

export const useTags = () =>
  useQuery({ queryKey: ['tags'], queryFn: () => api.get<string[]>('/v1/admin/tags') });

export const useUsers = (enabled = true) =>
  useQuery({ queryKey: ['users'], queryFn: () => api.get<User[]>('/v1/admin/users'), enabled });

export const useAllGroups = (enabled = true) =>
  useQuery({ queryKey: ['all-groups'], queryFn: () => api.get<Group[]>('/v1/admin/all-groups'), enabled });

export interface UserName { id: number; login: string; role: 'big_admin' | 'admin' | 'viewer' }
export const useUserNames = (enabled = true) =>
  useQuery({ queryKey: ['user-names'], queryFn: () => api.get<UserName[]>('/v1/admin/user-names'), enabled });

export const useDashboards = () =>
  useQuery({ queryKey: ['dashboards'], queryFn: () => api.get<DashboardMeta[]>('/v1/admin/dashboards') });

export const useDashboard = (id: number | null) =>
  useQuery({
    queryKey: ['dashboard', id],
    queryFn: () => api.get<Dashboard>(`/v1/admin/dashboards/${id}`),
    enabled: id !== null,
  });

// ---------- Тесты пропускной способности (iperf-подобные) ----------

export interface BWTestParams {
  proto: 'tcp' | 'udp';
  duration_sec: number;
  streams: number;
  length_bytes: number;
  target_mbps: number;
  reverse: boolean;
  dscp: number;
}

export interface BWTestResultData {
  proto: string; duration_sec: number; bytes: number; mbps: number;
  packets: number; lost_packets: number; loss_pct: number; jitter_ms: number;
  retransmits: number; streams: number; reverse: boolean;
}

export interface BWTest {
  id: number; proto: string; reverse: boolean; bidir: boolean;
  duration_sec: number; streams: number; length_bytes: number; target_mbps: number | null; dscp: number;
  server_addr: string; status: 'scheduled' | 'running' | 'done' | 'failed';
  result: BWTestResultData | null; error: string | null;
  created_by: string | null; created_at: string; finished_at: string | null;
  client_name: string | null; server_name: string | null;
  client_agent: string | null; server_agent: string | null;
}

export interface BWTestCreate {
  client_agent: string;
  server_agent?: string;
  server_addr: string;
  start_at?: string | null;
  params: BWTestParams;
}

export const useBWTests = (limit = 100) =>
  useQuery({
    queryKey: ['bwtests', limit],
    queryFn: () => api.get<BWTest[]>(`/v1/admin/bwtests?limit=${limit}`),
    refetchInterval: 5_000,
  });

export const useBWTest = (id: number | null) =>
  useQuery({
    queryKey: ['bwtest', id],
    queryFn: () => api.get<BWTest>(`/v1/admin/bwtests/${id}`),
    enabled: id !== null,
    refetchInterval: (q) =>
      q.state.data && (q.state.data.status === 'done' || q.state.data.status === 'failed') ? false : 3_000,
  });
