import type { Alert, LatestRow } from './api';

const dtf = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'medium' });

// parseDate безопасно парсит дату: возвращает null для пустых и некорректных значений,
// чтобы Intl.DateTimeFormat не падал с "date value is not finite".
function parseDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  const d = new Date(s);
  return Number.isFinite(d.getTime()) ? d : null;
}

export const fmtTime = (s: string | null | undefined) => {
  const d = parseDate(s);
  return d ? dtf.format(d) : '—';
};

export function fmtAgo(s: string | null | undefined): string {
  const d = parseDate(s);
  if (!d) return 'никогда';
  const sec = Math.round((Date.now() - d.getTime()) / 1000);
  if (sec < 60) return `${Math.max(sec, 0)} с назад`;
  if (sec < 3600) return `${Math.round(sec / 60)} мин назад`;
  if (sec < 86400) return `${Math.round(sec / 3600)} ч назад`;
  return `${Math.round(sec / 86400)} дн назад`;
}

export function fmtDuration(from: string, to: string | null): string {
  const f = parseDate(from);
  if (!f) return '—';
  const t = parseDate(to);
  const sec = Math.round(((t ? t.getTime() : Date.now()) - f.getTime()) / 1000);
  if (sec < 90) return `${sec} с`;
  if (sec < 5400) return `${Math.round(sec / 60)} мин`;
  if (sec < 172800) return `${(sec / 3600).toFixed(1)} ч`;
  return `${Math.round(sec / 86400)} дн`;
}

export const fmtMs = (v: number | null | undefined) =>
  v == null ? '—' : v < 10 ? `${v.toFixed(2)} мс` : `${v.toFixed(1)} мс`;

export const fmtPct = (v: number | null | undefined) =>
  v == null ? '—' : v === 0 ? '0%' : v < 1 ? `${v.toFixed(2)}%` : `${v.toFixed(1)}%`;

// Скорость в битах/с в человекочитаемый вид (СИ: 1 кбит = 1000 бит).
export function fmtBps(v: number | null | undefined): string {
  if (v == null) return '—';
  const u = ['бит/с', 'кбит/с', 'Мбит/с', 'Гбит/с'];
  let i = 0;
  let x = v;
  while (x >= 1000 && i < u.length - 1) { x /= 1000; i++; }
  return `${x < 10 && i > 0 ? x.toFixed(2) : x.toFixed(x < 100 ? 1 : 0)} ${u[i]}`;
}

export function fmtBytes(v: number | null | undefined): string {
  if (v == null) return '—';
  const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
  let i = 0;
  let x = v;
  while (x >= 1024 && i < u.length - 1) { x /= 1024; i++; }
  return `${i === 0 ? x : x.toFixed(1)} ${u[i]}`;
}

// canManage — может ли роль изменять объекты (admin и big_admin). viewer — только чтение.
export function canManage(role: string | undefined): boolean {
  return role === 'big_admin' || role === 'admin';
}

// minuteGaps находит пропуски в поминутном ряду: интервалы, где агент не прислал данные.
// Данные ожидаются раз в минуту. Возвращает пары [startMs, endMs] «дыр»:
//  * внутренние пропуски между двумя соседними точками (разрыв > 90 с);
//  * «хвост» от последней точки до now, если агент молчит дольше 90 с (канал сейчас не работает).
// До первой точки ничего не помечаем — там канала могло ещё не быть (не ложная тревога).
// Такие красные зоны на графике означают ошибку/простой агента.
export function minuteGaps(tsIso: (string | null | undefined)[], nowMs = Date.now()): [number, number][] {
  const ms = tsIso
    .map((s) => (s ? new Date(s).getTime() : NaN))
    .filter((x) => Number.isFinite(x))
    .sort((a, b) => a - b);
  if (ms.length === 0) return [];
  const MIN = 60_000;
  const THRESH = 90_000; // допускаем небольшой сдвиг; разрыв > 1.5 мин считаем пропуском
  const gaps: [number, number][] = [];
  for (let i = 1; i < ms.length; i++) {
    if (ms[i] - ms[i - 1] > THRESH) gaps.push([ms[i - 1] + MIN, ms[i]]);
  }
  const last = ms[ms.length - 1];
  if (nowMs - last > THRESH) gaps.push([last + MIN, nowMs]);
  return gaps;
}

// Подробные описания измеряемых параметров для всплывающих подсказок (кнопка info).
// Ключ совпадает с идентификатором метрики/графика.
export const metricInfo: Record<string, string> = {
  rtt:
    'RTT (Round-Trip Time) — время оборота пакета «туда и обратно». Считается как ' +
    '(T4−T1) − (T3−T2), поэтому не зависит от синхронизации часов. Рост RTT означает ' +
    'увеличение задержки на маршруте (перегрузка, смена пути, дальний резервный канал) и ' +
    'напрямую бьёт по интерактивных приложениях, VoIP и играх.',
  oneway:
    'Односторонняя задержка — время в одну сторону: туда (агент→сервер, T2−T1) и обратно ' +
    '(сервер→агент, T4−T3) отдельно. Показывает асимметрию маршрута. Достоверна только при ' +
    'синхронных часах на обеих сторонах (chrony/PTP); иначе значения скрыты. Полезна, чтобы ' +
    'понять, в какую сторону деградирует канал.',
  loss:
    'Потери пакетов, %. Разделяются по направлениям: потери «туда» = отправлено − дошло до ' +
    'рефлектора; «обратно» = дошло до рефлектора − вернулось агенту. Потери сильнее всего ' +
    'бьют по TCP (повторы, падение окна) и по голосу (разрывы). Даже 1–2% заметно ухудшают качество.',
  jitter:
    'Джиттер — вариация задержки (RFC 3550), по направлениям. Считается по разностям ' +
    'транзитного времени, поэтому не зависит от синхронизации часов. Высокий джиттер критичен ' +
    'для реального времени: буферы джиттера растут, растёт задержка и риск разрывов в VoIP/видео.',
  mos:
    'MOS (Mean Opinion Score, 1–5) — расчётная оценка качества речи по E-модели ITU-T G.107 ' +
    'на основе задержки, джиттера и потерь. 4.0+ — отлично, 3.6–4.0 — хорошо, 3.1–3.6 — ' +
    'удовлетворительно, ниже 3.1 — пользователи жалуются. Интегральный показатель «слышимости» канала.',
  smoke:
    'Распределение RTT (smoke-график в духе SmokePing): затемнение показывает разброс ' +
    'значений RTT внутри интервала (перцентили), линия — медиану. Широкая «дымка» = ' +
    'нестабильная задержка, узкая = стабильный канал.',
  load:
    'Фактическая загрузка интерфейса из счётчиков ядра: приём (rx) и отдача (tx) в бит/с и в ' +
    '% от номинала. Рост утилизации к 100% одновременно с ростом потерь — признак перегрузки ' +
    'самого канала (а не проблемы у оператора).',
  util:
    'Утилизация интерфейса, % от номинальной скорости (speed_mbit). Считается из фактических ' +
    'бит/с. Если номинал задан неверно — проценты будут неточными, но абсолютные бит/с корректны.',
  remarking:
    'Перемаркировка DSCP — оператор в пути изменил класс QoS пакета. Сравнивается заданный ' +
    'DSCP с тем, что фактически увидел рефлектор (и что вернулось агенту). Перемаркировка ' +
    'означает, что ваш трафик обслуживается не в том классе, на который вы рассчитывали.',
  throughput:
    'Пропускная способность — фактическая скорость передачи данных между двумя точками ' +
    '(как iperf). Для TCP это достижимая полезная скорость с учётом окна и повторов; для UDP — ' +
    'сколько данных реально дошло. Ниже номинала канала — узкое место, шейпер оператора или ' +
    'ограничение по задержке/потерям (для TCP).',
  bwloss:
    'Потери при нагрузочном тесте UDP, % — доля не дошедших датаграмм при заливке трафика на ' +
    'заданной скорости. В отличие от лёгких проб, показывает поведение канала под реальной ' +
    'нагрузкой: рост потерь при приближении к номиналу означает, что канал/шейпер начинает ' +
    'отбрасывать пакеты.',
  bwjitter:
    'Джиттер при нагрузочном тесте UDP (RFC 1889/3550), мс — вариация задержки датаграмм под ' +
    'нагрузкой. Растущий джиттер при заливке говорит о переполнении очередей на маршруте и ' +
    'предсказывает проблемы для трафика реального времени в часы пик.',
  retransmits:
    'Ретрансмиссии TCP — число повторных отправок сегментов из-за потерь. Косвенный признак ' +
    'потерь/перегрузки на пути: чем больше повторов, тем ниже эффективная пропускная способность TCP.',
};

export const alertKinds: Record<string, string> = {
  rtt: 'Задержка RTT',
  oneway: 'Односторонняя задержка',
  jitter: 'Джиттер',
  loss: 'Потери',
  mos: 'Качество голоса (MOS)',
  remarking: 'Перемаркировка DSCP',
  util: 'Загрузка интерфейса',
  agent_down: 'Агент не на связи',
};

export type Status = 'ok' | 'warn' | 'crit' | 'nodata';

// Состояние одного направления канала для матрицы: открытые алерты важнее сырых значений.
export function directionStatus(row: LatestRow | undefined, alerts: Alert[], dir: 'fwd' | 'bwd'): Status {
  if (!row) return 'nodata';
  const stale = Date.now() - new Date(row.ts).getTime() > 5 * 60_000;
  if (stale) return 'nodata';
  let st: Status = 'ok';
  const loss = dir === 'fwd' ? row.fwd_loss_pct : row.bwd_loss_pct;
  const remarked = dir === 'fwd' ? row.fwd_remarked : row.bwd_remarked;
  if ((loss ?? 0) >= 2) st = 'crit';
  else if ((loss ?? 0) > 0 || (remarked ?? 0) > 0) st = 'warn';
  for (const a of alerts) {
    const d = a.details ?? {};
    const directional = 'fwd_breach' in d || 'bwd_breach' in d;
    if (directional && !d[`${dir}_breach`]) continue;
    if (a.kind === 'remarking' && !Number(d[dir] ?? 0)) continue;
    if (a.severity === 'critical') return 'crit';
    st = st === 'crit' ? 'crit' : 'warn';
  }
  return st;
}

export const statusLabel: Record<Status, string> = {
  ok: 'в норме', warn: 'деградация', crit: 'нарушение SLA', nodata: 'нет данных',
};
