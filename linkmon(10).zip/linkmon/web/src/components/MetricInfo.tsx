import { HoverCard, Text, UnstyledButton } from '@mantine/core';
import { metricInfo } from '../format';

// MetricInfo — маленькая курсивная кнопка «info» рядом с названием параметра.
// При наведении/нажатии показывает подробное описание: за что отвечает и на что влияет.
export function MetricInfo({ metric }: { metric: keyof typeof metricInfo | string }) {
  const text = metricInfo[metric];
  if (!text) return null;
  return (
    <HoverCard width={320} shadow="md" openDelay={100} withArrow position="top">
      <HoverCard.Target>
        <UnstyledButton
          aria-label="Подробнее о параметре"
          style={{ fontSize: '0.72rem', fontStyle: 'italic', color: 'var(--muted)', cursor: 'help', marginLeft: 6 }}>
          info
        </UnstyledButton>
      </HoverCard.Target>
      <HoverCard.Dropdown>
        <Text size="sm">{text}</Text>
      </HoverCard.Dropdown>
    </HoverCard>
  );
}
