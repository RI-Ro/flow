import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ActionIcon, Badge, Button, Group, Paper, Text, Tooltip } from '@mantine/core';
import { IconBell, IconBellOff, IconVolume, IconVolumeOff, IconCheck } from '@tabler/icons-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useAlerts, type Alert } from '../api';
import { alertKinds } from '../format';

const SOUND_KEY = 'linkmon.soundEnabled';
const REPEAT_MS = 15_000; // как часто повторять сигнал, пока алерт не подтверждён

// beep — короткий звуковой сигнал через Web Audio. Тон зависит от критичности.
function beep(ctx: AudioContext, critical: boolean) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.type = 'sine';
  osc.frequency.value = critical ? 880 : 620;
  gain.gain.setValueAtTime(0.0001, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);
  osc.start();
  osc.stop(ctx.currentTime + 0.42);
  if (critical) {
    // Для критичных — двойной сигнал.
    const o2 = ctx.createOscillator();
    const g2 = ctx.createGain();
    o2.connect(g2); g2.connect(ctx.destination);
    o2.type = 'sine'; o2.frequency.value = 880;
    g2.gain.setValueAtTime(0.0001, ctx.currentTime + 0.5);
    g2.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.52);
    g2.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.9);
    o2.start(ctx.currentTime + 0.5);
    o2.stop(ctx.currentTime + 0.92);
  }
}

// AlertCenter — глобальная плашка снизу: показывает открытые неподтверждённые алерты,
// периодически звучит, пока администратор их не подтвердит (ack). Звук по умолчанию
// выключен и включается кнопкой (браузеры требуют жеста пользователя для аудио).
export function AlertCenter() {
  const { data } = useAlerts('open');
  const qc = useQueryClient();
  const [soundOn, setSoundOn] = useState(() => {
    try { return localStorage.getItem(SOUND_KEY) === '1'; } catch { return false; }
  });
  const ctxRef = useRef<AudioContext | null>(null);
  const lastBeep = useRef(0);

  // ensureCtx создаёт AudioContext лениво (без гарантии, что он «разблокирован»).
  const ensureCtx = (): AudioContext | null => {
    if (!ctxRef.current) {
      try {
        const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return null;
        ctxRef.current = new AC();
      } catch { return null; }
    }
    return ctxRef.current;
  };

  // Браузеры запускают звук только после жеста пользователя. Если звук включён (в т.ч.
  // восстановлен из localStorage при перезагрузке), а контекст ещё «suspended», ждём
  // первый клик/нажатие на странице и разблокируем аудио — тогда сигналы заработают.
  useEffect(() => {
    if (!soundOn) return;
    const ctx = ensureCtx();
    if (!ctx || ctx.state !== 'suspended') return;
    const unlock = () => { void ctx.resume(); };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [soundOn]);

  // Неподтверждённые открытые алерты — именно они требуют реакции и звучат.
  const unacked = useMemo(
    () => (data ?? []).filter((a) => !a.acked_at && !a.ended_at),
    [data],
  );
  const hasCritical = unacked.some((a) => a.severity === 'critical');

  const ack = useMutation({
    mutationFn: (id: number) => api.post(`/v1/admin/alerts/${id}/ack`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['alerts'] });
      qc.invalidateQueries({ queryKey: ['overview'] });
    },
  });

  const enableSound = () => {
    const ctx = ensureCtx();
    // Клик по кнопке — это жест пользователя: разблокируем и сразу проверяем сигналом.
    if (ctx) {
      void ctx.resume().then(() => { try { beep(ctx, hasCritical); lastBeep.current = Date.now(); } catch { /* */ } });
    }
    setSoundOn(true);
    try { localStorage.setItem(SOUND_KEY, '1'); } catch { /* */ }
  };
  const disableSound = () => {
    setSoundOn(false);
    try { localStorage.setItem(SOUND_KEY, '0'); } catch { /* */ }
  };

  // Цикличная эскалация: пока есть неподтверждённые алерты и звук включён — сигналим.
  useEffect(() => {
    if (!soundOn || unacked.length === 0) return;
    const tick = () => {
      const ctx = ensureCtx();
      if (!ctx) return;
      if (ctx.state === 'suspended') { void ctx.resume(); return; } // ждём разблокировки жестом
      const now = Date.now();
      if (now - lastBeep.current >= REPEAT_MS - 200) {
        lastBeep.current = now;
        try { beep(ctx, hasCritical); } catch { /* */ }
      }
    };
    tick(); // сразу при появлении нового алерта
    const t = setInterval(tick, REPEAT_MS);
    return () => clearInterval(t);
  }, [soundOn, unacked.length, hasCritical]);

  if (unacked.length === 0) {
    return null;
  }

  return (
    <Paper className="alert-center" shadow="md" withBorder
      style={{ borderColor: hasCritical ? 'var(--crit)' : 'var(--warn)' }}>
      <Group justify="space-between" wrap="nowrap" gap="sm">
        <Group gap="xs" wrap="nowrap">
          <Badge color={hasCritical ? 'red' : 'yellow'} variant="filled" size="lg">{unacked.length}</Badge>
          <div>
            <Text fw={600} size="sm">Требуют внимания</Text>
            <Text size="xs" c="dimmed">
              {unacked.slice(0, 3).map((a) => alertLabel(a)).join(' · ')}
              {unacked.length > 3 ? ` и ещё ${unacked.length - 3}` : ''}
            </Text>
          </div>
        </Group>
        <Group gap="xs" wrap="nowrap">
          {soundOn ? (
            <Tooltip label="Выключить звук"><ActionIcon variant="subtle" onClick={disableSound}><IconVolume size={18} /></ActionIcon></Tooltip>
          ) : (
            <Tooltip label="Включить звук оповещений"><ActionIcon variant="light" color="red" onClick={enableSound}><IconVolumeOff size={18} /></ActionIcon></Tooltip>
          )}
          <Button size="xs" variant="light" component={Link} to="/alerts">Все</Button>
          <Button size="xs" leftSection={<IconCheck size={14} />}
            loading={ack.isPending}
            onClick={() => unacked.forEach((a) => ack.mutate(a.id))}>
            Подтвердить все
          </Button>
        </Group>
      </Group>
    </Paper>
  );
}

function alertLabel(a: Alert): string {
  const what = alertKinds[a.kind] ?? a.kind;
  const where = a.channel ?? a.agent ?? '';
  return where ? `${what} — ${where}` : what;
}

// Иконки экспортируем на случай переиспользования индикатора в шапке.
export const AlertBellIcons = { On: IconBell, Off: IconBellOff };
