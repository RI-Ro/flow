import ReactECharts from 'echarts-for-react';
import { tokens } from '../theme';
import { MetricInfo } from './MetricInfo';
import { gapMarkArea } from './SymmetricChart';

interface Props {
  title: string;
  ts: string[];
  values: (number | null)[];
  fmt: (v: number) => string;
  color?: string;
  min?: number;
  max?: number;
  info?: string;
  note?: string;
  height?: number;
  xMin?: number;
  xMax?: number;
  gaps?: [number, number][];
}

// LineChart — простой одиночный график метрики во времени (например, MOS).
export function LineChart({ title, ts, values, fmt, color = tokens.fwd, min, max, info, note, height = 240, xMin, xMax, gaps }: Props) {
  const empty = values.every((v) => v == null);
  const option = {
    animation: false,
    grid: { left: 56, right: 16, top: 16, bottom: 54 },
    xAxis: { type: 'time', min: xMin, max: xMax, axisLine: { lineStyle: { color: tokens.line } }, axisLabel: { color: tokens.muted } },
    yAxis: {
      type: 'value', min, max, splitNumber: 4,
      axisLabel: { color: tokens.muted, formatter: (v: number) => fmt(v) },
      splitLine: { lineStyle: { color: '#E7ECEF' } },
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross', label: { backgroundColor: tokens.ink } },
      valueFormatter: (v: number | null) => (v == null ? '—' : fmt(v)),
    },
    toolbox: {
      right: 8, top: 4, itemSize: 13, feature: {
        dataZoom: { yAxisIndex: 'none', title: { zoom: 'Зум', back: 'Сброс' } },
        restore: { title: 'Сброс' },
        saveAsImage: { title: 'PNG', pixelRatio: 2 },
      },
      iconStyle: { borderColor: tokens.muted },
    },
    dataZoom: [
      { type: 'inside', throttle: 50 },
      { type: 'slider', height: 16, bottom: 24, borderColor: tokens.line, textStyle: { color: tokens.muted } },
    ],
    series: [{
      type: 'line', color, showSymbol: false, sampling: 'lttb', lineStyle: { width: 1.5 },
      areaStyle: { opacity: 0.14 }, connectNulls: false, emphasis: { focus: 'series' },
      data: ts.map((t, i) => [t, values[i]]),
      markArea: gapMarkArea(gaps),
    }],
  };
  return (
    <div className="panel">
      <div className="chart-title">
        <h3>{title}{info && <MetricInfo metric={info} />}</h3>
      </div>
      {note && <div className="muted" style={{ fontSize: '0.82rem' }}>{note}</div>}
      {empty
        ? <div className="muted" style={{ height, display: 'grid', placeItems: 'center' }}>За выбранный период данных нет</div>
        : <ReactECharts option={option} style={{ height }} notMerge />}
    </div>
  );
}
