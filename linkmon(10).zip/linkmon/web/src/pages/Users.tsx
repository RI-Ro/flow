import { useState } from 'react';
import {
  ActionIcon, Badge, Button, Group, Loader, Menu, Modal, MultiSelect, PasswordInput,
  Select, Stack, Table, Text, TextInput, Title,
} from '@mantine/core';
import { IconDots, IconTrash, IconKey, IconLock, IconLockOpen, IconPlus, IconEye } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, useAllGroups, useUsers, type User } from '../api';
import { fmtTime } from '../format';

const roleName: Record<User['role'], string> = {
  big_admin: 'Полный доступ', admin: 'Администратор', viewer: 'Наблюдатель',
};
const roleColor: Record<User['role'], string> = { big_admin: 'grape', admin: 'cobalt', viewer: 'gray' };

// Страница управления пользователями. Доступна только big_admin (маршрут скрыт для остальных,
// а сервер дополнительно проверяет роль на каждом запросе).
export function UsersPage() {
  const users = useUsers();
  const groups = useAllGroups();
  const qc = useQueryClient();
  const [create, setCreate] = useState(false);
  const [scopes, setScopes] = useState<User | null>(null);

  const groupName = new Map((groups.data ?? []).map((g) => [g.id, g.name]));
  const invalidate = () => qc.invalidateQueries({ queryKey: ['users'] });

  const act = useMutation({
    mutationFn: ({ id, path, body }: { id: number; path: string; body?: unknown }) =>
      api.post(`/v1/admin/users/${id}/${path}`, body ?? {}),
    onSuccess: () => { invalidate(); notifications.show({ message: 'Готово', color: 'teal' }); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  const del = useMutation({
    mutationFn: (id: number) => api.del(`/v1/admin/users/${id}`),
    onSuccess: () => { invalidate(); notifications.show({ message: 'Пользователь удалён', color: 'teal' }); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  const [resetFor, setResetFor] = useState<User | null>(null);

  return (
    <>
      <div className="page-head">
        <div>
          <Title order={1}>Пользователи</Title>
          <p>Роли и область видимости. Администратор и наблюдатель видят только назначенные им группы каналов (проверяется на уровне БД через RLS). Полный доступ (big_admin) видит всё и управляет пользователями.</p>
        </div>
        <Button leftSection={<IconPlus size={16} />} onClick={() => setCreate(true)}>Добавить пользователя</Button>
      </div>

      <div className="panel">
        {users.isLoading ? <Loader /> : (
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Логин</Table.Th><Table.Th>Роль</Table.Th><Table.Th>Область видимости</Table.Th>
                <Table.Th>Вход</Table.Th><Table.Th>Статус</Table.Th><Table.Th w={44} />
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {users.data?.map((u) => (
                <Table.Tr key={u.id}>
                  <Table.Td fw={500}>{u.login}</Table.Td>
                  <Table.Td>
                    <Group gap={6} wrap="nowrap">
                      <Badge variant="light" color={roleColor[u.role]}>{roleName[u.role]}</Badge>
                      <Select size="xs" w={140} value={u.role} allowDeselect={false}
                        data={Object.entries(roleName).map(([v, l]) => ({ value: v, label: l }))}
                        onChange={(v) => v && act.mutate({ id: u.id, path: 'role', body: { role: v } })} />
                    </Group>
                  </Table.Td>
                  <Table.Td>
                    {u.role === 'big_admin'
                      ? <Text size="sm" c="dimmed">все группы</Text>
                      : (
                        <Group gap={4}>
                          {u.groups.length === 0 && <Text size="sm" c="red">нет доступа</Text>}
                          {u.groups.slice(0, 4).map((g) => <Badge key={g} size="sm" variant="light">{groupName.get(g) ?? g}</Badge>)}
                          {u.groups.length > 4 && <Badge size="sm" variant="outline">+{u.groups.length - 4}</Badge>}
                          <ActionIcon size="sm" variant="subtle" onClick={() => setScopes(u)}><IconEye size={14} /></ActionIcon>
                        </Group>
                      )}
                  </Table.Td>
                  <Table.Td c="dimmed">{u.last_login ? fmtTime(u.last_login) : '—'}</Table.Td>
                  <Table.Td>{u.disabled ? <Badge color="gray" variant="light">заблокирован</Badge> : <Badge color="teal" variant="light">активен</Badge>}</Table.Td>
                  <Table.Td>
                    <Menu position="bottom-end" withinPortal>
                      <Menu.Target><ActionIcon variant="subtle" color="gray"><IconDots size={18} /></ActionIcon></Menu.Target>
                      <Menu.Dropdown>
                        {u.role !== 'big_admin' && <Menu.Item leftSection={<IconEye size={14} />} onClick={() => setScopes(u)}>Область видимости</Menu.Item>}
                        <Menu.Item leftSection={<IconKey size={14} />} onClick={() => setResetFor(u)}>Сбросить пароль</Menu.Item>
                        {u.disabled
                          ? <Menu.Item leftSection={<IconLockOpen size={14} />} onClick={() => act.mutate({ id: u.id, path: 'disable', body: { disabled: false } })}>Разблокировать</Menu.Item>
                          : <Menu.Item leftSection={<IconLock size={14} />} onClick={() => act.mutate({ id: u.id, path: 'disable', body: { disabled: true } })}>Заблокировать</Menu.Item>}
                        <Menu.Divider />
                        <Menu.Item color="red" leftSection={<IconTrash size={14} />}
                          onClick={() => { if (confirm(`Удалить пользователя «${u.login}»?`)) del.mutate(u.id); }}>Удалить</Menu.Item>
                      </Menu.Dropdown>
                    </Menu>
                  </Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </div>

      {create && <CreateUserModal groups={groups.data ?? []} onClose={() => setCreate(false)} onDone={() => { setCreate(false); invalidate(); }} />}
      {scopes && <ScopesModal user={scopes} groups={groups.data ?? []} onClose={() => setScopes(null)} onDone={() => { setScopes(null); invalidate(); }} />}
      {resetFor && <ResetPasswordModal user={resetFor} onClose={() => setResetFor(null)} />}
    </>
  );
}

function CreateUserModal({ groups, onClose, onDone }:
  { groups: { id: number; name: string }[]; onClose: () => void; onDone: () => void }) {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<User['role']>('viewer');
  const [sel, setSel] = useState<string[]>([]);
  const create = useMutation({
    mutationFn: () => api.post('/v1/admin/users', { login, password, role, groups: sel.map(Number) }),
    onSuccess: () => { notifications.show({ message: 'Пользователь создан', color: 'teal' }); onDone(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title="Новый пользователь">
      <Stack>
        <TextInput label="Логин" value={login} onChange={(e) => setLogin(e.currentTarget.value)} required />
        <PasswordInput label="Пароль" description="не короче 8 символов" value={password} onChange={(e) => setPassword(e.currentTarget.value)} required />
        <Select label="Роль" value={role} onChange={(v) => setRole((v as User['role']) ?? 'viewer')}
          data={Object.entries(roleName).map(([v, l]) => ({ value: v, label: l }))} />
        {role !== 'big_admin' && (
          <MultiSelect label="Область видимости (группы каналов)" placeholder="выберите группы" searchable
            data={groups.map((g) => ({ value: String(g.id), label: g.name }))} value={sel} onChange={setSel} />
        )}
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={create.isPending} disabled={!login || password.length < 8} onClick={() => create.mutate()}>Создать</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function ScopesModal({ user, groups, onClose, onDone }:
  { user: User; groups: { id: number; name: string }[]; onClose: () => void; onDone: () => void }) {
  const [sel, setSel] = useState<string[]>(user.groups.map(String));
  const save = useMutation({
    mutationFn: () => api.post(`/v1/admin/users/${user.id}/scopes`, { groups: sel.map(Number) }),
    onSuccess: () => { notifications.show({ message: 'Область видимости обновлена', color: 'teal' }); onDone(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title={`Область видимости — ${user.login}`}>
      <Stack>
        <Text size="sm" c="dimmed">Пользователь увидит каналы только из выбранных групп (и их каналы на графиках, в алертах, дашбордах).</Text>
        <MultiSelect data={groups.map((g) => ({ value: String(g.id), label: g.name }))} value={sel} onChange={setSel} searchable
          placeholder="выберите группы" />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} onClick={() => save.mutate()}>Сохранить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}

function ResetPasswordModal({ user, onClose }: { user: User; onClose: () => void }) {
  const [password, setPassword] = useState('');
  const save = useMutation({
    mutationFn: () => api.post(`/v1/admin/users/${user.id}/password`, { password }),
    onSuccess: () => { notifications.show({ message: 'Пароль сброшен, сессии пользователя завершены', color: 'teal' }); onClose(); },
    onError: (e: Error) => notifications.show({ message: e.message, color: 'red' }),
  });
  return (
    <Modal opened onClose={onClose} title={`Сброс пароля — ${user.login}`}>
      <Stack>
        <PasswordInput label="Новый пароль" description="не короче 8 символов" value={password} onChange={(e) => setPassword(e.currentTarget.value)} />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Отмена</Button>
          <Button loading={save.isPending} disabled={password.length < 8} onClick={() => save.mutate()}>Сбросить</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
