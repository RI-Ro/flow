import { useState, type FormEvent } from 'react';
import { Alert, Button, Group, Modal, PasswordInput, Stack } from '@mantine/core';
import { IconAlertTriangle } from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { api, ApiError } from '../api';

export function ChangePasswordModal({ opened, onClose }: { opened: boolean; onClose: () => void }) {
  const [oldPassword, setOld] = useState('');
  const [newPassword, setNew] = useState('');
  const [repeat, setRepeat] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const reset = () => { setOld(''); setNew(''); setRepeat(''); setError(''); };
  const close = () => { reset(); onClose(); };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (newPassword.length < 8) { setError('Новый пароль должен быть не короче 8 символов.'); return; }
    if (newPassword !== repeat) { setError('Пароли не совпадают.'); return; }
    setBusy(true);
    try {
      await api.changePassword(oldPassword, newPassword);
      notifications.show({ message: 'Пароль изменён', color: 'teal' });
      close();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Не удалось сменить пароль.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal opened={opened} onClose={close} title="Смена пароля" size="sm">
      <form onSubmit={submit}>
        <Stack>
          {error && <Alert color="red" variant="light" icon={<IconAlertTriangle size={16} />}>{error}</Alert>}
          <PasswordInput label="Текущий пароль" value={oldPassword} onChange={(e) => setOld(e.currentTarget.value)}
            autoComplete="current-password" required />
          <PasswordInput label="Новый пароль" value={newPassword} onChange={(e) => setNew(e.currentTarget.value)}
            autoComplete="new-password" required />
          <PasswordInput label="Повторите новый пароль" value={repeat} onChange={(e) => setRepeat(e.currentTarget.value)}
            autoComplete="new-password" required />
          <Group justify="flex-end">
            <Button variant="default" onClick={close}>Отмена</Button>
            <Button type="submit" loading={busy}>Сменить</Button>
          </Group>
        </Stack>
      </form>
    </Modal>
  );
}
