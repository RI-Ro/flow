import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Badge, Button, Group, Loader, Table, Text, Title } from '@mantine/core';
import { IconArrowLeft, IconPrinter } from '@tabler/icons-react';
import {
  useChannels, useChannelLoad, useGroups, useSeries, useSmoke, useSLA,
  type RangeKey, type SeriesPoint,
} from '../api';
import { RangePicker, useStickyRange } from '../components/RangePicker';
import { SymmetricChart } from '../components/SymmetricChart';
import { SmokeChart } from '../components/SmokeChart';
import { LoadChart } from '../components/LoadChart';
import { LineChart } from '../components/LineChart';
import { tokens } from '../theme';
import { fmtMs, fmtPct } from '../format';

const RANGE_LABEL: Record<RangeKey, string> = {
  '30m': 'за 30 минут', '1h': 'за 1 час', '3h': 'за 3 часа', '6h': 'за 6 часов', '24h': 'за 24 часа', '7d': 'за 7 дней',
};

// Отчёт по каналу: печатная страница «подпись → графики → сводка SLA».
export function ChannelReportPage() {
  const { id } = useParams();
  const channelId = Number(id);
  const [range, setRange] = useStickyRange('linkmon.range.report', '24h');
  const channels = useChannels();
  const channel = channels.data?.find((c) => c.id === channelId);

  if (channels.isLoading) return <Loader />;
  if (!channel) return <Text>Канал не найден. <Link to="/channels">К списку каналов</Link></Text>;

  return (
    <>
      <div className="no-print" style={{ marginBottom: 16 }}>
        <Group justify="space-between">
          <Button component={Link} to={`/channels/${channelId}`} variant="subtle" leftSection={<IconArrowLeft size={16} />}>Назад</Button>
          <Group>
            <RangePicker value={range} onChange={setRange} />
            <Button leftSection={<IconPrinter size={16} />} onClick={() => window.print()}>Печать / PDF</Button>
          </Group>
        </Group>
      </div>
      <ReportHeader title="Отчёт по каналу связи" subtitle={RANGE_LABEL[range]} />
      <ChannelReportSection channelId={channelId} range={range} />
    </>
  );
}

// Отчёт по группе: для каждого канала группы — его подпись и графики.
export function GroupReportPage() {
  const { id } = useParams();
  const groupId = Number(id);
  const [range, setRange] = useStickyRange('linkmon.range.report', '24h');
  const groups = useGroups();
  const channels = useChannels();
  const group = groups.data?.find((g) => g.id === groupId);
  const members = useMemo(
    () => (channels.data ?? []).filter((c) => c.groups.includes(groupId)),
    [channels.data, groupId],
  );

  if (channels.isLoading || groups.isLoading) return <Loader />;

  return (
    <>
      <div className="no-print" style={{ marginBottom: 16 }}>
        <Group justify="space-between">
          <Button component={Link} to="/groups" variant="subtle" leftSection={<IconArrowLeft size={16} />}>Назад</Button>
          <Group>
            <RangePicker value={range} onChange={setRange} />
            <Button leftSection={<IconPrinter size={16} />} onClick={() => window.print()}>Печать / PDF</Button>
          </Group>
        </Group>
      </div>
      <ReportHeader title={`Отчёт по группе «${group?.name ?? groupId}»`} subtitle={`${members.length} каналов · ${RANGE_LABEL[range]}`} />
      {members.length === 0 ? <Text c="dimmed">В группе нет каналов.</Text> : members.map((c) => (
        <div key={c.id} style={{ breakInside: 'avoid', marginBottom: 24 }}>
          <ChannelReportSection channelId={c.id} range={range} compact />
        </div>
      ))}
    </>
  );
}

function ReportHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div style={{ marginBottom: 20, borderBottom: '2px solid var(--ink)', paddingBottom: 10 }}>
      <Title order={1}>{title}</Title>
      <Text c="dimmed">LinkMon · {subtitle} · сформировано {new Date().toLocaleString('ru-RU')}</Text>
    </div>
  );
}

// Секция отчёта по одному каналу: подпись сверху, затем графики, затем сводка SLA.
function ChannelReportSection({ channelId, range, compact }: { channelId: number; range: RangeKey; compact?: boolean }) {
  const channels = useChannels();
  const sla = useSLA();
  const series = useSeries(channelId, range);
  const smoke = useSmoke(channelId, range);
  const load = useChannelLoad(channelId, range);

  const channel = channels.data?.find((c) => c.id === channelId);
  const pts = series.data?.points ?? [];
  const ts = pts.map((p) => p.ts);
  const col = (k: keyof SeriesPoint) => pts.map((p) => p[k] as number | null);
  if (!channel) return null;
  const slaProfile = sla.data?.find((s) => s.id === channel.sla_id);

  // Сводка за период: средние и максимумы ключевых метрик.
  const nums = (k: keyof SeriesPoint) => col(k).filter((v): v is number => v != null);
  const avg = (k: keyof SeriesPoint) => { const a = nums(k); return a.length ? a.reduce((s, v) => s + v, 0) / a.length : null; };
  const max = (k: keyof SeriesPoint) => { const a = nums(k); return a.length ? Math.max(...a) : null; };
  const min = (k: keyof SeriesPoint) => { const a = nums(k); return a.length ? Math.min(...a) : null; };

  return (
    <div style={{ breakInside: 'avoid' }}>
      {/* Подпись канала — сначала, как просили */}
      <div style={{ marginBottom: 10 }}>
        <Title order={compact ? 3 : 2}>{channel.label}</Title>
        <Text size="sm" c="dimmed">
          {channel.agent} / {channel.interface} · класс {channel.dscp_name} · до {channel.reflector}
          {channel.tags.length > 0 && ` · теги: ${channel.tags.join(', ')}`}
        </Text>
      </div>

      {series.isLoading ? <Loader size="sm" /> : (
        <>
          {/* Сводка за период */}
          <Table mb="sm" withTableBorder>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Показатель</Table.Th><Table.Th>Среднее</Table.Th><Table.Th>Максимум</Table.Th><Table.Th>Порог SLA</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              <Table.Tr><Table.Td>RTT</Table.Td><Table.Td>{fmtMs(avg('rtt_avg'))}</Table.Td><Table.Td>{fmtMs(max('rtt_max'))}</Table.Td><Table.Td>{slaProfile?.max_rtt_ms != null ? `≤ ${slaProfile.max_rtt_ms} мс` : '—'}</Table.Td></Table.Tr>
              <Table.Tr><Table.Td>Потери</Table.Td><Table.Td>{fmtPct(avg('loss_pct'))}</Table.Td><Table.Td>{fmtPct(max('loss_pct'))}</Table.Td><Table.Td>{slaProfile?.max_loss_pct != null ? `≤ ${slaProfile.max_loss_pct}%` : '—'}</Table.Td></Table.Tr>
              <Table.Tr><Table.Td>Джиттер (туда)</Table.Td><Table.Td>{fmtMs(avg('fwd_jitter'))}</Table.Td><Table.Td>{fmtMs(max('fwd_jitter'))}</Table.Td><Table.Td>{slaProfile?.max_jitter_ms != null ? `≤ ${slaProfile.max_jitter_ms} мс` : '—'}</Table.Td></Table.Tr>
              <Table.Tr><Table.Td>MOS</Table.Td><Table.Td>{avg('mos') != null ? avg('mos')!.toFixed(2) : '—'}</Table.Td><Table.Td>мин {min('mos') != null ? min('mos')!.toFixed(2) : '—'}</Table.Td><Table.Td>{slaProfile?.min_mos != null ? `≥ ${slaProfile.min_mos}` : '—'}</Table.Td></Table.Tr>
            </Table.Tbody>
          </Table>
          {slaProfile
            ? <Badge variant="light" mb="sm">SLA-профиль: {slaProfile.name}</Badge>
            : <Badge variant="outline" color="gray" mb="sm">SLA-профиль не назначен</Badge>}

          {/* Графики */}
          <div className="chart-grid">
            <SymmetricChart title="Задержка в одну сторону" info="oneway" ts={ts} fwd={col('fwd_delay_avg')} bwd={col('bwd_delay_avg')} fmt={fmtMs} />
            <SymmetricChart title="Потери пакетов" info="loss" ts={ts} fwd={col('fwd_loss_pct')} bwd={col('bwd_loss_pct')} fmt={fmtPct} kind="bar" />
            {!compact && <SymmetricChart title="Джиттер" info="jitter" ts={ts} fwd={col('fwd_jitter')} bwd={col('bwd_jitter')} fmt={fmtMs} />}
            <LineChart title="MOS" info="mos" ts={ts} values={col('mos')} fmt={(v) => v.toFixed(2)} color={tokens.ok} min={1} max={5} />
            {!compact && <SmokeChart points={smoke.data?.points ?? []} />}
            {!compact && (load.data?.monitor_id ?? 0) !== 0 && <LoadChart points={load.data?.points ?? []} />}
          </div>
        </>
      )}
    </div>
  );
}
