import { createTheme, type MantineColorsTuple } from '@mantine/core';

// Направление — главный смысловой код интерфейса: «туда» кобальт и над осью, «обратно» медь и под осью.
export const tokens = {
  fog: '#EDF1F3',
  surface: '#FFFFFF',
  ink: '#16262E',
  muted: '#5D6F78',
  line: '#D5DDE1',
  fwd: '#2A5CDB',
  bwd: '#B8672E',
  ok: '#2F8F6B',
  warn: '#D19A12',
  crit: '#C23B4B',
  nodata: '#B7C1C6',
};

const cobalt: MantineColorsTuple = [
  '#ecf1ff', '#d6defb', '#aabcf3', '#7b97ec', '#5478e5', '#3b64e1', '#2A5CDB', '#1f4bc4', '#1742b0', '#07389c',
];

export const theme = createTheme({
  fontFamily: '"Golos Text", system-ui, sans-serif',
  headings: {
    fontFamily: '"Golos Text", system-ui, sans-serif',
    fontWeight: '600',
    sizes: {
      h1: { fontSize: '1.75rem', lineHeight: '1.2' },
      h2: { fontSize: '1.3rem', lineHeight: '1.25' },
      h3: { fontSize: '1.05rem', lineHeight: '1.3' },
    },
  },
  colors: { cobalt },
  primaryColor: 'cobalt',
  primaryShade: 6,
  black: tokens.ink,
  defaultRadius: 'sm',
  components: {
    Modal: { defaultProps: { radius: 'md', centered: true } },
    Table: { defaultProps: { verticalSpacing: 6, horizontalSpacing: 'sm', highlightOnHover: true } },
  },
});
