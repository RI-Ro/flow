import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// При разработке API сервера (listen_admin) проксируется, поэтому CORS не нужен.
const api = process.env.LINKMON_ADMIN ?? 'http://127.0.0.1:8080';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/v1': api, '/metrics': api },
  },
});
