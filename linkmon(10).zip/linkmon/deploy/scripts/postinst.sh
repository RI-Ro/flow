#!/bin/sh
set -e
if ! getent passwd linkmon >/dev/null; then
    adduser --system --group --home /var/lib/linkmon --no-create-home linkmon
fi
mkdir -p /etc/linkmon
chown root:linkmon /etc/linkmon
chmod 0750 /etc/linkmon
for f in /etc/linkmon/*.yaml /etc/linkmon/token /etc/linkmon/ca.crt; do
    [ -e "$f" ] && chown root:linkmon "$f" && chmod 0640 "$f"
done
if [ -d /run/systemd/system ]; then
    systemctl daemon-reload || true
fi
exit 0
