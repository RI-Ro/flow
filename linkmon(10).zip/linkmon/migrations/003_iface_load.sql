-- 003_iface_load.sql — фактическая загрузка интерфейсов

-- Какие интерфейсы агента мониторить по загрузке. Ключ — (agent_id, interface),
-- потому что загрузка снимается с интерфейса целиком, а не с отдельного DSCP-канала.
CREATE TABLE iface_monitors (
    id           bigserial PRIMARY KEY,
    agent_id     uuid NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    interface    text NOT NULL,
    speed_bits   bigint,                 -- номинал канала; NULL — брать из sysfs на агенте
    interval_sec int NOT NULL DEFAULT 60 CHECK (interval_sec IN (10, 30, 60, 300)),
    enabled      boolean NOT NULL DEFAULT true,
    created_at   timestamptz NOT NULL DEFAULT now(),
    UNIQUE (agent_id, interface)
);
CREATE INDEX iface_monitors_agent ON iface_monitors (agent_id) WHERE enabled;

CREATE TABLE iface_load (
    ts           timestamptz NOT NULL,
    monitor_id   bigint NOT NULL,
    interval_sec int NOT NULL DEFAULT 60,
    speed_bits   bigint,
    rx_bytes     bigint, tx_bytes bigint,
    rx_packets   bigint, tx_packets bigint,
    rx_bps       double precision, tx_bps double precision,
    rx_pps       double precision, tx_pps double precision,
    rx_util_pct  real, tx_util_pct real,
    rx_errors    bigint, tx_errors bigint,
    rx_drops     bigint, tx_drops bigint,
    PRIMARY KEY (monitor_id, ts)
);

CREATE INDEX iface_load_ts ON iface_load (ts DESC);

-- Плоское представление для API и Grafana: загрузка вместе с именем агента и интерфейса.
CREATE VIEW v_iface_load AS
SELECT l.ts, l.interval_sec, m.id AS monitor_id, m.agent_id, a.hostname AS agent, m.interface,
       COALESCE(l.speed_bits, m.speed_bits) AS speed_bits,
       l.rx_bps, l.tx_bps, l.rx_pps, l.tx_pps,
       l.rx_util_pct, l.tx_util_pct,
       l.rx_bytes, l.tx_bytes, l.rx_packets, l.tx_packets,
       l.rx_errors, l.tx_errors, l.rx_drops, l.tx_drops
FROM iface_load l
JOIN iface_monitors m ON m.id = l.monitor_id
JOIN agents a         ON a.id = m.agent_id;

-- Часовой агрегат для длинных диапазонов: пики важнее средних, поэтому храним и max.
-- Без TimescaleDB — обычное представление, считающее агрегат на лету.
CREATE VIEW iface_load_1h AS
SELECT date_trunc('hour', ts) AS ts,
       monitor_id,
       avg(rx_bps) AS rx_bps, max(rx_bps) AS rx_bps_max,
       avg(tx_bps) AS tx_bps, max(tx_bps) AS tx_bps_max,
       avg(rx_util_pct) AS rx_util_pct, max(rx_util_pct) AS rx_util_pct_max,
       avg(tx_util_pct) AS tx_util_pct, max(tx_util_pct) AS tx_util_pct_max,
       sum(rx_bytes) AS rx_bytes, sum(tx_bytes) AS tx_bytes,
       sum(rx_errors) AS rx_errors, sum(tx_errors) AS tx_errors,
       sum(rx_drops) AS rx_drops, sum(tx_drops) AS tx_drops
FROM iface_load
GROUP BY 1, 2;

CREATE VIEW v_iface_load_1h AS
SELECT h.ts, 3600 AS interval_sec, m.id AS monitor_id, m.agent_id, a.hostname AS agent, m.interface,
       m.speed_bits,
       h.rx_bps, h.tx_bps, h.rx_bps_max, h.tx_bps_max,
       h.rx_util_pct, h.tx_util_pct, h.rx_util_pct_max, h.tx_util_pct_max,
       h.rx_bytes, h.tx_bytes, h.rx_errors, h.tx_errors, h.rx_drops, h.tx_drops
FROM iface_load_1h h
JOIN iface_monitors m ON m.id = h.monitor_id
JOIN agents a         ON a.id = m.agent_id;

-- Порог утилизации для алерта «канал перегружен» на профиль SLA.
ALTER TABLE sla_profiles ADD COLUMN max_util_pct real;
