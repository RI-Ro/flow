// Package api описывает контракт между агентом и сервером (JSON поверх HTTPS с mTLS).
package api

import (
	"encoding/json"
	"time"
)

const DefaultReflectorPort = 8620

const (
	StatusPending  = "pending"
	StatusApproved = "approved"
	StatusRejected = "rejected"
)

// ---------- Регистрация ----------

type TargetCap struct {
	Name    string `json:"name"`
	Address string `json:"address"`
	Port    int    `json:"port"`
}

type IfaceCap struct {
	Name    string      `json:"name"`
	Source  string      `json:"source,omitempty"`
	DSCP    []int       `json:"dscp"`
	Targets []TargetCap `json:"targets"`
	// Monitor — агент готов снимать фактическую загрузку этого интерфейса.
	Monitor bool `json:"monitor,omitempty"`
	// SpeedBits — номинальная скорость канала, если задана в конфиге агента.
	SpeedBits   int64 `json:"speed_bits,omitempty"`
	IntervalSec int   `json:"monitor_interval_sec,omitempty"`
	// TWAMP — пробы этого интерфейса шлём в формате TWAMP-Light (совместимость с
	// аппаратными TWAMP-ответчиками); цели считаются внешними TWAMP-responder'ами.
	TWAMP bool `json:"twamp,omitempty"`
}

// Capabilities — то, что разрешено агенту его локальным конфигом.
// Сервер назначает каналы только внутри этих рамок, агент дополнительно проверяет это сам.
type Capabilities struct {
	Interfaces []IfaceCap `json:"interfaces"`
	// BWTestPort — порт (TCP+UDP), на котором агент принимает тесты пропускной способности
	// (iperf-подобные). 0 — агент не выступает сервером bwtest.
	BWTestPort int `json:"bwtest_port,omitempty"`
}

type EnrollRequest struct {
	Token        string       `json:"token,omitempty"`
	MachineID    string       `json:"machine_id"`
	Hostname     string       `json:"hostname"`
	Name         string       `json:"name,omitempty"` // понятное имя из конфига агента (используется при первичной регистрации)
	Version      string       `json:"version"`
	CSRPEM       string       `json:"csr_pem"`
	Capabilities Capabilities `json:"capabilities"`
}

type EnrollResponse struct {
	AgentID       string `json:"agent_id,omitempty"`
	Status        string `json:"status"`
	CertPEM       string `json:"cert_pem,omitempty"`
	RetryAfterSec int    `json:"retry_after_sec,omitempty"`
}

// ---------- Конфигурация ----------

// ChannelConfig — один канал: интерфейс × рефлектор × DSCP.
type ChannelConfig struct {
	ChannelID     int64  `json:"channel_id"`
	SessionID     uint64 `json:"session_id"`
	SessionKey    []byte `json:"session_key"`
	Interface     string `json:"interface"`
	SourceIP      string `json:"source_ip,omitempty"`
	ReflectorAddr string `json:"reflector_addr"`
	ReflectorPort int    `json:"reflector_port"`
	DSCP          int    `json:"dscp"`
	PPS           int    `json:"pps"`
	PacketSize    int    `json:"packet_size"`
	Poisson       bool   `json:"poisson"`
	IntervalSec   int    `json:"interval_sec"`
	TWAMP         bool   `json:"twamp,omitempty"` // формат проб TWAMP-Light (внешний ответчик)
}

// IfaceMonitor — интерфейс, у которого агент снимает фактическую загрузку из счётчиков ядра.
// SpeedBits — номинальная скорость канала (бит/с) для расчёта утилизации в процентах;
// 0 — берём из /sys/class/net/<name>/speed, если ядро её отдаёт (иначе утилизация неизвестна).
type IfaceMonitor struct {
	Interface   string `json:"interface"`
	SpeedBits   int64  `json:"speed_bits,omitempty"`
	IntervalSec int    `json:"interval_sec"`
}

type AgentConfig struct {
	Revision string          `json:"revision"`
	Channels []ChannelConfig `json:"channels"`
	Monitors []IfaceMonitor  `json:"monitors,omitempty"`
}

// ---------- Результаты ----------

// Summary — статистика распределения в миллисекундах.
type Summary struct {
	Min float64 `json:"min"`
	Avg float64 `json:"avg"`
	P50 float64 `json:"p50"`
	P95 float64 `json:"p95"`
	P99 float64 `json:"p99"`
	Max float64 `json:"max"`
}

// Interval — агрегат замеров канала за интервал (по умолчанию минута, выровнена по UTC).
type Interval struct {
	ChannelID    int64     `json:"channel_id"`
	TS           time.Time `json:"ts"`
	Seconds      int       `json:"seconds"`
	Sent         int       `json:"sent"`
	Received     int       `json:"received"`
	Duplicates   int       `json:"dup"`
	Reordered    int       `json:"reordered"`
	RTT          *Summary  `json:"rtt,omitempty"`
	Fwd          *Summary  `json:"fwd,omitempty"`
	Bwd          *Summary  `json:"bwd,omitempty"`
	FwdJitter    float64   `json:"fwd_jitter"`
	BwdJitter    float64   `json:"bwd_jitter"`
	FwdDSCPSeen  int       `json:"fwd_dscp_seen"`
	BwdDSCPSeen  int       `json:"bwd_dscp_seen"`
	FwdRemarked  int       `json:"fwd_remarked"`
	BwdRemarked  int       `json:"bwd_remarked"`
	MOS          float64   `json:"mos"`
	OneWayValid  bool      `json:"oneway_valid"`
	RTTQuantiles []float64 `json:"rtt_q,omitempty"`
}

// IfaceLoad — фактическая загрузка интерфейса за интервал, посчитанная из дельты
// счётчиков ядра. Скорости уже усреднены по интервалу (в секунду), объёмы — суммарные.
type IfaceLoad struct {
	Interface string    `json:"interface"`
	TS        time.Time `json:"ts"`
	Seconds   int       `json:"seconds"`
	SpeedBits int64     `json:"speed_bits,omitempty"` // номинал канала, если известен

	RxBytes   int64 `json:"rx_bytes"`
	TxBytes   int64 `json:"tx_bytes"`
	RxPackets int64 `json:"rx_packets"`
	TxPackets int64 `json:"tx_packets"`

	RxBps float64 `json:"rx_bps"` // средняя скорость за интервал, бит/с
	TxBps float64 `json:"tx_bps"`
	RxPps float64 `json:"rx_pps"`
	TxPps float64 `json:"tx_pps"`

	// Утилизация относительно SpeedBits, %; nil — номинал неизвестен, считать нечего.
	RxUtilPct *float64 `json:"rx_util_pct,omitempty"`
	TxUtilPct *float64 `json:"tx_util_pct,omitempty"`

	RxErrors int64 `json:"rx_errors"`
	TxErrors int64 `json:"tx_errors"`
	RxDrops  int64 `json:"rx_drops"`
	TxDrops  int64 `json:"tx_drops"`
}

type ResultBatch struct {
	Seq        uint64      `json:"batch_seq"`
	Intervals  []Interval  `json:"intervals"`
	IfaceLoads []IfaceLoad `json:"iface_loads,omitempty"`
}

type Ack struct {
	Seq       uint64 `json:"batch_seq"`
	Duplicate bool   `json:"duplicate,omitempty"`
}

type Heartbeat struct {
	Version      string `json:"version"`
	ClockSynced  bool   `json:"clock_synced"`
	ClockErrUS   int64  `json:"clock_err_us"`
	Sessions     int    `json:"sessions"`
	SpoolBatches int    `json:"spool_batches"`
}

// ---------- Команды сервера ----------

const (
	CmdReloadConfig = "reload_config"
	CmdRunTest      = "run_test"
	CmdRunBWTest    = "run_bwtest"
)

type Command struct {
	ID      int64           `json:"id"`
	Kind    string          `json:"kind"`
	Payload json.RawMessage `json:"payload,omitempty"`
}

type RunTestPayload struct {
	RunID       int64     `json:"run_id"`
	StartAt     time.Time `json:"start_at"`
	DurationSec int       `json:"duration_sec"`
	PPS         int       `json:"pps"`
	PacketSize  int       `json:"packet_size"`
	ChannelIDs  []int64   `json:"channel_ids,omitempty"`
}

type TestResult struct {
	RunID   int64            `json:"run_id"`
	Results []Interval       `json:"results"`
	Errors  map[int64]string `json:"errors,omitempty"`
}

// ---------- Тест пропускной способности (iperf-подобный) ----------

// BWTestParams — параметры теста пропускной способности между двумя агентами.
// Задаются администратором перед запуском (аналог ключей iperf).
type BWTestParams struct {
	Proto       string  `json:"proto"`        // tcp | udp
	DurationSec int     `json:"duration_sec"` // длительность нагрузки, с
	Streams     int     `json:"streams"`      // число параллельных потоков (-P)
	LengthBytes int     `json:"length_bytes"` // размер блока (-l), 0 — по умолчанию (1350)
	TargetMbps  float64 `json:"target_mbps"`  // целевая полоса (-b), Мбит/с; работает для TCP и UDP; 0 — без лимита
	Reverse     bool    `json:"reverse"`      // сервер отдаёт клиенту (-R, download)
	DSCP        int     `json:"dscp"`         // метка DSCP (0..63) для пакетов теста; 0 — BE
}

// RunBWTestPayload — команда клиентскому агенту: провести тест против ServerAddr.
type RunBWTestPayload struct {
	RunID      int64        `json:"run_id"`
	StartAt    time.Time    `json:"start_at"`
	ServerAddr string       `json:"server_addr"` // host:port агента-сервера bwtest
	Params     BWTestParams `json:"params"`
}

// BWTestResultData — итоговые метрики теста (зеркалит bwtest.Result).
type BWTestResultData struct {
	Proto       string  `json:"proto"`
	DurationSec float64 `json:"duration_sec"`
	Bytes       int64   `json:"bytes"`
	Mbps        float64 `json:"mbps"`
	Packets     int64   `json:"packets"`
	LostPackets int64   `json:"lost_packets"`
	LossPct     float64 `json:"loss_pct"`
	JitterMs    float64 `json:"jitter_ms"`
	Retransmits int64   `json:"retransmits"`
	Streams     int     `json:"streams"`
	Reverse     bool    `json:"reverse"`
}

// BWTestResult — отчёт клиентского агента серверу LinkMon.
type BWTestResult struct {
	RunID  int64             `json:"run_id"`
	Result *BWTestResultData `json:"result,omitempty"`
	Error  string            `json:"error,omitempty"`
}
