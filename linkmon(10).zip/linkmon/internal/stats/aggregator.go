// Package stats агрегирует отдельные замеры канала в интервальные записи.
package stats

import (
	"math"
	"sort"
	"sync"
	"time"

	"github.com/example/linkmon/internal/api"
)

// Sample — один отражённый пакет со всеми четырьмя метками времени (unix ns).
type Sample struct {
	Seq            uint32
	T1, T2, T3, T4 int64
	FwdDSCP        int // DSCP, который увидел рефлектор; -1 — неизвестно
	BwdDSCP        int // DSCP ответа на стороне агента; -1 — неизвестно
}

type bucket struct {
	start   time.Time
	sent    int
	samples []Sample
	seen    map[uint32]struct{}
	dup     int
	reord   int
	maxSeq  uint32
	hasSeq  bool
}

// Aggregator потокобезопасен: OnSent вызывается из горутины отправки, OnReply — из горутины приёма.
// Пакет относится к интервалу по времени отправки T1, поэтому агент и рефлектор
// раскладывают один и тот же пакет в один и тот же интервал.
type Aggregator struct {
	mu        sync.Mutex
	channelID int64
	dscp      int
	width     int64
	origin    int64
	buckets   map[int64]*bucket
	oneWayOK  func() bool
}

func NewAggregator(channelID int64, dscp int, width time.Duration, originNanos int64, oneWayOK func() bool) *Aggregator {
	if width <= 0 {
		width = time.Minute
	}
	return &Aggregator{
		channelID: channelID, dscp: dscp, width: int64(width), origin: originNanos,
		buckets: make(map[int64]*bucket), oneWayOK: oneWayOK,
	}
}

func (a *Aggregator) key(t1 int64) int64 {
	x := t1 - a.origin
	q := x / a.width
	if x%a.width != 0 && x < 0 {
		q--
	}
	return q
}

func (a *Aggregator) OnSent(t1 int64) {
	a.mu.Lock()
	defer a.mu.Unlock()
	k := a.key(t1)
	b := a.buckets[k]
	if b == nil {
		b = &bucket{start: time.Unix(0, a.origin+k*a.width).UTC(), seen: make(map[uint32]struct{})}
		a.buckets[k] = b
	}
	b.sent++
}

func (a *Aggregator) OnReply(s Sample) {
	a.mu.Lock()
	defer a.mu.Unlock()
	b := a.buckets[a.key(s.T1)]
	if b == nil {
		return // интервал уже закрыт: слишком поздний ответ считается потерей
	}
	if _, dup := b.seen[s.Seq]; dup {
		b.dup++
		return
	}
	b.seen[s.Seq] = struct{}{}
	if b.hasSeq && s.Seq < b.maxSeq {
		b.reord++ // RFC 4737: пришёл раньше пакета с меньшим номером
	} else {
		b.maxSeq, b.hasSeq = s.Seq, true
	}
	b.samples = append(b.samples, s)
}

// Flush закрывает интервалы, закончившиеся не позднее чем grace назад (force — все).
func (a *Aggregator) Flush(now time.Time, grace time.Duration, force bool) []api.Interval {
	a.mu.Lock()
	var ready []*bucket
	for k, b := range a.buckets {
		end := b.start.Add(time.Duration(a.width))
		if force || now.Sub(end) >= grace {
			ready = append(ready, b)
			delete(a.buckets, k)
		}
	}
	a.mu.Unlock()
	if len(ready) == 0 {
		return nil
	}
	sort.Slice(ready, func(i, j int) bool { return ready[i].start.Before(ready[j].start) })
	oneWay := a.oneWayOK == nil || a.oneWayOK()
	out := make([]api.Interval, 0, len(ready))
	for _, b := range ready {
		out = append(out, a.finalize(b, oneWay))
	}
	return out
}

func (a *Aggregator) finalize(b *bucket, oneWay bool) api.Interval {
	iv := api.Interval{
		ChannelID: a.channelID, TS: b.start, Seconds: int(a.width / int64(time.Second)),
		Sent: b.sent, Received: len(b.samples), Duplicates: b.dup, Reordered: b.reord,
		FwdDSCPSeen: -1, BwdDSCPSeen: -1, OneWayValid: oneWay,
	}
	n := len(b.samples)
	if n == 0 {
		return iv
	}
	sort.Slice(b.samples, func(i, j int) bool { return b.samples[i].Seq < b.samples[j].Seq })

	rtt := make([]float64, 0, n)
	fwd := make([]float64, 0, n)
	bwd := make([]float64, 0, n)
	var fj, bj float64
	for i, s := range b.samples {
		// Отрицательная задержка физически невозможна: она возникает из-за смешения
		// источников меток (T1 — userspace, T2/T4 — метки ядра). На быстром пути (loopback,
		// один хост) это даёт микроскопические отрицательные значения — приводим их к 0,
		// чтобы не показывать «странные» отрицательные задержки.
		rtt = append(rtt, nonneg(ms((s.T4-s.T1)-(s.T3-s.T2))))
		f, w := nonneg(ms(s.T2-s.T1)), nonneg(ms(s.T4-s.T3))
		fwd = append(fwd, f)
		bwd = append(bwd, w)
		// Джиттер по RFC 3550 на разностях транзитного времени: смещение часов
		// сокращается, поэтому значение корректно и без синхронизации.
		if i > 0 {
			fj += (math.Abs(f-fwd[i-1]) - fj) / 16
			bj += (math.Abs(w-bwd[i-1]) - bj) / 16
		}
		if s.FwdDSCP >= 0 {
			iv.FwdDSCPSeen = s.FwdDSCP
			if s.FwdDSCP != a.dscp {
				iv.FwdRemarked++
			}
		}
		if s.BwdDSCP >= 0 {
			iv.BwdDSCPSeen = s.BwdDSCP
			if s.BwdDSCP != a.dscp {
				iv.BwdRemarked++
			}
		}
	}
	iv.FwdJitter, iv.BwdJitter = r3(fj), r3(bj)
	iv.RTT = summarize(rtt) // сортирует rtt на месте
	iv.RTTQuantiles = quantiles(rtt, 20)
	iv.Fwd = summarize(fwd)
	iv.Bwd = summarize(bwd)

	lossPct := 0.0
	if b.sent > 0 {
		lossPct = 100 * float64(b.sent-n) / float64(b.sent)
	}
	iv.MOS = r3(MOS(iv.RTT.Avg/2, (fj+bj)/2, lossPct))
	return iv
}

// MOS — упрощённая E-модель ITU-T G.107 (кодек G.711, без учёта маскирования потерь).
func MOS(oneWayMs, jitterMs, lossPct float64) float64 {
	eff := oneWayMs + 2*jitterMs + 10
	var r float64
	if eff < 160 {
		r = 93.2 - eff/40
	} else {
		r = 93.2 - (eff-120)/10
	}
	r -= 2.5 * lossPct
	if r <= 0 {
		return 1
	}
	if r > 100 {
		r = 100
	}
	return 1 + 0.035*r + 0.000007*r*(r-60)*(100-r)
}

func ms(ns int64) float64  { return float64(ns) / 1e6 }
func r3(x float64) float64 { return math.Round(x*1000) / 1000 }
func nonneg(x float64) float64 {
	if x < 0 {
		return 0
	}
	return x
}

func pct(sorted []float64, p float64) float64 {
	n := len(sorted)
	i := int(math.Ceil(p/100*float64(n))) - 1
	if i < 0 {
		i = 0
	}
	if i >= n {
		i = n - 1
	}
	return sorted[i]
}

func summarize(v []float64) *api.Summary {
	sort.Float64s(v)
	var sum float64
	for _, x := range v {
		sum += x
	}
	return &api.Summary{
		Min: r3(v[0]), Max: r3(v[len(v)-1]), Avg: r3(sum / float64(len(v))),
		P50: r3(pct(v, 50)), P95: r3(pct(v, 95)), P99: r3(pct(v, 99)),
	}
}

// quantiles — n равномерных квантилей RTT (5%, 10% … 100%) для smoke-графика в духе SmokePing.
func quantiles(sorted []float64, n int) []float64 {
	q := make([]float64, n)
	for i := range q {
		q[i] = r3(pct(sorted, float64(i+1)*100/float64(n)))
	}
	return q
}
