package stats

import (
	"testing"
	"time"
)

func TestAggregatorDirections(t *testing.T) {
	const msec = int64(time.Millisecond)
	a := NewAggregator(1, 46, time.Minute, 0, func() bool { return true })
	base := time.Date(2026, 1, 1, 10, 0, 0, 0, time.UTC).UnixNano()

	for i := 0; i < 10; i++ {
		t1 := base + int64(i)*100*msec
		a.OnSent(t1)
		if i%5 == 4 {
			continue // теряем 2 пакета из 10
		}
		// прямое 5 мс, обработка на рефлекторе 1 мс, обратное 10 мс; ответ перемаркирован в BE
		a.OnReply(Sample{Seq: uint32(i + 1), T1: t1, T2: t1 + 5*msec, T3: t1 + 6*msec, T4: t1 + 16*msec, FwdDSCP: 46, BwdDSCP: 0})
	}

	out := a.Flush(time.Unix(0, base), 0, true)
	if len(out) != 1 {
		t.Fatalf("intervals: %d", len(out))
	}
	iv := out[0]
	if !iv.TS.Equal(time.Unix(0, base)) {
		t.Fatalf("bucket start %v", iv.TS)
	}
	if iv.Sent != 10 || iv.Received != 8 {
		t.Fatalf("sent/received %d/%d", iv.Sent, iv.Received)
	}
	if iv.RTT.Avg != 15 || iv.Fwd.Avg != 5 || iv.Bwd.Avg != 10 {
		t.Fatalf("rtt=%v fwd=%v bwd=%v", iv.RTT.Avg, iv.Fwd.Avg, iv.Bwd.Avg)
	}
	if iv.FwdRemarked != 0 || iv.BwdRemarked != 8 || iv.BwdDSCPSeen != 0 {
		t.Fatalf("remark fwd=%d bwd=%d seen=%d", iv.FwdRemarked, iv.BwdRemarked, iv.BwdDSCPSeen)
	}
	if len(iv.RTTQuantiles) != 20 {
		t.Fatalf("quantiles: %d", len(iv.RTTQuantiles))
	}
}
