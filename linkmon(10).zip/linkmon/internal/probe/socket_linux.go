//go:build linux

// Package probe — низкоуровневая работа с UDP-сокетами измерителя:
// привязка к (под)интерфейсу, установка DSCP, приём фактического TOS и меток времени ядра.
package probe

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/unix"
)

type Options struct {
	Device    string // eth0.100, bond0.200, vrf-blue; пусто — без привязки
	Source    string // IP источника; пусто — любой
	Port      int
	TOS       int // значение байта TOS (DSCP<<2); -1 — не выставлять
	ReusePort bool
}

// Conn не потокобезопасен на чтение: у каждой читающей горутины свой Conn (свой oob-буфер).
type Conn struct {
	*net.UDPConn
	oob []byte
}

type RecvMeta struct {
	N          int
	From       *net.UDPAddr
	TOS        int // -1, если ядро не вернуло TOS
	KernelTime time.Time
}

func Listen(o Options) (*Conn, error) {
	lc := net.ListenConfig{Control: func(_, _ string, rc syscall.RawConn) error {
		var serr error
		if err := rc.Control(func(fd uintptr) { serr = setOpts(int(fd), o) }); err != nil {
			return err
		}
		return serr
	}}
	pc, err := lc.ListenPacket(context.Background(), "udp4", net.JoinHostPort(o.Source, strconv.Itoa(o.Port)))
	if err != nil {
		return nil, err
	}
	return &Conn{UDPConn: pc.(*net.UDPConn), oob: make([]byte, 256)}, nil
}

func setOpts(fd int, o Options) error {
	if o.Device != "" {
		if err := unix.SetsockoptString(fd, unix.SOL_SOCKET, unix.SO_BINDTODEVICE, o.Device); err != nil {
			return fmt.Errorf("SO_BINDTODEVICE %q: %w", o.Device, err)
		}
	}
	if o.TOS >= 0 {
		if err := unix.SetsockoptInt(fd, unix.IPPROTO_IP, unix.IP_TOS, o.TOS); err != nil {
			return fmt.Errorf("IP_TOS: %w", err)
		}
	}
	if err := unix.SetsockoptInt(fd, unix.IPPROTO_IP, unix.IP_RECVTOS, 1); err != nil {
		return fmt.Errorf("IP_RECVTOS: %w", err)
	}
	if err := unix.SetsockoptInt(fd, unix.SOL_SOCKET, unix.SO_TIMESTAMPNS, 1); err != nil {
		return fmt.Errorf("SO_TIMESTAMPNS: %w", err)
	}
	if o.ReusePort {
		if err := unix.SetsockoptInt(fd, unix.SOL_SOCKET, unix.SO_REUSEPORT, 1); err != nil {
			return fmt.Errorf("SO_REUSEPORT: %w", err)
		}
	}
	// Всплески burst-тестов не должны теряться в буфере хоста и искажать результат.
	_ = unix.SetsockoptInt(fd, unix.SOL_SOCKET, unix.SO_RCVBUF, 4<<20)
	return nil
}

// Recv читает датаграмму вместе с TOS и меткой времени приёма из ядра.
func (c *Conn) Recv(b []byte) (RecvMeta, error) {
	n, oobn, _, from, err := c.ReadMsgUDP(b, c.oob)
	m := RecvMeta{N: n, From: from, TOS: -1}
	if err != nil {
		return m, err
	}
	if msgs, perr := unix.ParseSocketControlMessage(c.oob[:oobn]); perr == nil {
		for _, cm := range msgs {
			switch {
			case cm.Header.Level == unix.IPPROTO_IP && cm.Header.Type == unix.IP_TOS && len(cm.Data) >= 1:
				m.TOS = int(cm.Data[0])
			case cm.Header.Level == unix.SOL_SOCKET && cm.Header.Type == unix.SCM_TIMESTAMPNS &&
				len(cm.Data) >= int(unsafe.Sizeof(unix.Timespec{})):
				ts := (*unix.Timespec)(unsafe.Pointer(&cm.Data[0]))
				m.KernelTime = time.Unix(int64(ts.Sec), int64(ts.Nsec))
			}
		}
	}
	if m.KernelTime.IsZero() {
		m.KernelTime = time.Now()
	}
	return m, nil
}

// Заранее подготовленные cmsg IP_TOS для каждого DSCP: рефлектор отвечает на одном сокете
// всем сессиям, поэтому класс ответа задаётся для каждого пакета отдельно.
var tosCmsg [64][]byte

func init() {
	for d := range tosCmsg {
		b := make([]byte, unix.CmsgSpace(4))
		h := (*unix.Cmsghdr)(unsafe.Pointer(&b[0]))
		h.Level = unix.IPPROTO_IP
		h.Type = unix.IP_TOS
		h.SetLen(unix.CmsgLen(4))
		binary.NativeEndian.PutUint32(b[unix.CmsgLen(0):], uint32(d<<2))
		tosCmsg[d] = b
	}
}

// SendDSCP отправляет датаграмму с заданным DSCP независимо от настроек сокета.
func (c *Conn) SendDSCP(b []byte, to *net.UDPAddr, dscp int) error {
	_, _, err := c.WriteMsgUDP(b, tosCmsg[dscp&63], to)
	return err
}
