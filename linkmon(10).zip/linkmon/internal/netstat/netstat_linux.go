//go:build linux

// Package netstat читает счётчики сетевого интерфейса из /sys/class/net.
// Это не требует привилегий и одинаково работает для физических интерфейсов,
// VLAN-подинтерфейсов (eth0.100), бондов и VRF.
package netstat

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// Counters — снимок кумулятивных счётчиков интерфейса.
type Counters struct {
	RxBytes, TxBytes     int64
	RxPackets, TxPackets int64
	RxErrors, TxErrors   int64
	RxDrops, TxDrops     int64
}

func readInt(path string) int64 {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	v, _ := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	return v
}

// Exists сообщает, поднят ли интерфейс в системе (есть каталог в sysfs).
func Exists(iface string) bool {
	fi, err := os.Stat(filepath.Join("/sys/class/net", iface))
	return err == nil && fi.IsDir()
}

// Read снимает счётчики интерфейса. Второе значение — удалось ли прочитать
// (интерфейс может ещё не существовать, например VLAN не поднят).
func Read(iface string) (Counters, bool) {
	dir := filepath.Join("/sys/class/net", iface, "statistics")
	if _, err := os.Stat(dir); err != nil {
		return Counters{}, false
	}
	return Counters{
		RxBytes:   readInt(filepath.Join(dir, "rx_bytes")),
		TxBytes:   readInt(filepath.Join(dir, "tx_bytes")),
		RxPackets: readInt(filepath.Join(dir, "rx_packets")),
		TxPackets: readInt(filepath.Join(dir, "tx_packets")),
		RxErrors:  readInt(filepath.Join(dir, "rx_errors")),
		TxErrors:  readInt(filepath.Join(dir, "tx_errors")),
		RxDrops:   readInt(filepath.Join(dir, "rx_dropped")),
		TxDrops:   readInt(filepath.Join(dir, "tx_dropped")),
	}, true
}

// SpeedBits возвращает скорость линка в битах/с из /sys/class/net/<iface>/speed
// (значение в Мбит/с). Возвращает 0, если ядро не знает скорость: у VLAN и
// многих виртуальных интерфейсов файла нет или там -1.
func SpeedBits(iface string) int64 {
	b, err := os.ReadFile(filepath.Join("/sys/class/net", iface, "speed"))
	if err != nil {
		return 0
	}
	mbit, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	if err != nil || mbit <= 0 {
		return 0
	}
	return mbit * 1_000_000
}
