package proto

import "testing"

func TestRoundTripAndAuth(t *testing.T) {
	key := []byte("0123456789abcdef0123456789abcdef")
	buf := make([]byte, 128)
	in := Packet{Flags: FlagReply, DSCPSent: 46, DSCPRecv: 34, SessionID: 42,
		SeqTx: 7, SeqRefl: 3, ReflRxCount: 5, T1: 1, T2: 2, T3: 3}
	if err := in.Marshal(buf, key); err != nil {
		t.Fatal(err)
	}
	var out Packet
	if err := Unmarshal(buf, key, &out); err != nil {
		t.Fatal(err)
	}
	if out != in {
		t.Fatalf("got %+v, want %+v", out, in)
	}
	buf[20] ^= 1
	if err := Unmarshal(buf, key, &out); err != ErrAuth {
		t.Fatalf("expected ErrAuth, got %v", err)
	}
}
