package server

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/example/linkmon/internal/probe"
	"github.com/example/linkmon/internal/proto"
)

const (
	sessionQueue   = 4096
	srvFlushGrace  = 5 * time.Second
	maxOpenBuckets = 16
)

// Reflector — серверная часть измерений.
//
// Горячий путь (N читателей на SO_REUSEPORT): принять → проверить HMAC → проставить T2/T3,
// фактический DSCP и счётчики → отправить ответ в исходном классе. Без аллокаций и без БД.
//
// На каждый канал (интерфейс агента × DSCP) — своя сессионная горутина: она считает,
// сколько пакетов дошло до сервера в каждом интервале. Это «прямая» половина канала,
// из которой вычисляются потери отдельно туда и обратно.
type Reflector struct {
	listen   string
	readers  int
	store    *Store
	log      *slog.Logger
	sessions atomic.Pointer[map[uint64]*rsession]
	stats    chan ServerStat
	unknown  atomic.Uint64
}

type rmeta struct {
	seq uint32
	t1  int64
	tos int
}

type rsession struct {
	ReflectorSession
	tx, rx  atomic.Uint32
	in      chan rmeta
	cancel  context.CancelFunc
	dropped atomic.Uint64
}

func NewReflector(listen string, readers int, st *Store, log *slog.Logger) *Reflector {
	return &Reflector{listen: listen, readers: max(readers, 1), store: st,
		log: log.With("component", "reflector"), stats: make(chan ServerStat, 8192)}
}

func (r *Reflector) current() map[uint64]*rsession {
	if p := r.sessions.Load(); p != nil {
		return *p
	}
	return nil
}

func (r *Reflector) Run(ctx context.Context) error {
	host, portStr, err := net.SplitHostPort(r.listen)
	if err != nil {
		return err
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}
	if err := r.reload(ctx); err != nil {
		return fmt.Errorf("load sessions: %w", err)
	}
	var conns []*probe.Conn
	for i := 0; i < r.readers; i++ {
		c, err := probe.Listen(probe.Options{Source: host, Port: port, TOS: -1, ReusePort: true})
		if err != nil {
			for _, c := range conns {
				c.Close()
			}
			return err
		}
		conns = append(conns, c)
	}
	go r.writer(ctx)
	for _, c := range conns {
		go r.readLoop(ctx, c)
	}
	r.log.Info("reflector listening", "addr", r.listen, "readers", r.readers)

	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			for _, c := range conns {
				c.Close()
			}
			return nil
		case <-t.C:
			if err := r.reload(ctx); err != nil {
				r.log.Warn("session reload failed", "err", err)
			}
		}
	}
}

// reload синхронизирует набор сессий с БД. Неизменившиеся сессии и их горутины сохраняются.
func (r *Reflector) reload(ctx context.Context) error {
	list, err := r.store.ReflectorSessions(ctx)
	if err != nil {
		return err
	}
	old := r.current()
	next := make(map[uint64]*rsession, len(list))
	started, stopped := 0, 0
	for _, rs := range list {
		if o, ok := old[rs.SessionID]; ok && bytes.Equal(o.Key, rs.Key) && o.Width == rs.Width &&
			o.DSCP == rs.DSCP && o.ChannelID == rs.ChannelID {
			next[rs.SessionID] = o
			continue
		}
		sctx, cancel := context.WithCancel(ctx)
		s := &rsession{ReflectorSession: rs, in: make(chan rmeta, sessionQueue), cancel: cancel}
		go r.sessionLoop(sctx, s)
		next[rs.SessionID] = s
		started++
	}
	r.sessions.Store(&next)
	for id, o := range old {
		if next[id] != o {
			o.cancel()
			stopped++
		}
	}
	if started > 0 || stopped > 0 {
		r.log.Info("sessions reloaded", "total", len(next), "started", started, "stopped", stopped)
	}
	return nil
}

func (r *Reflector) readLoop(ctx context.Context, c *probe.Conn) {
	buf := make([]byte, 2048)
	var p proto.Packet
	for {
		m, err := c.Recv(buf)
		if err != nil {
			if ctx.Err() != nil || errors.Is(err, net.ErrClosed) {
				return
			}
			continue
		}
		b := buf[:m.N]
		sid, err := proto.PeekSession(b)
		if err != nil {
			continue
		}
		s := r.current()[sid]
		if s == nil {
			r.unknown.Add(1)
			continue
		}
		if proto.Unmarshal(b, s.Key, &p) != nil || p.IsReply() {
			continue
		}
		p.Flags |= proto.FlagReply
		p.T2 = m.KernelTime.UnixNano()
		p.DSCPRecv = proto.DSCPUnknown
		if m.TOS >= 0 {
			p.DSCPRecv = uint8(m.TOS >> 2)
		}
		p.SeqRefl = s.tx.Add(1)
		p.ReflRxCount = s.rx.Add(1)
		p.T3 = time.Now().UnixNano()
		_ = p.Marshal(b, s.Key)
		// Ответ уходит в исходном классе (DSCPSent), чтобы обратное направление мерило тот же класс QoS.
		if c.SendDSCP(b, m.From, int(p.DSCPSent)) != nil {
			continue
		}
		if p.Flags&proto.FlagTest != 0 {
			continue // разовые тесты не смешиваем с постоянной статистикой
		}
		select {
		case s.in <- rmeta{seq: p.SeqTx, t1: p.T1, tos: m.TOS}:
		default:
			s.dropped.Add(1)
		}
	}
}

type srvBucket struct {
	start                   time.Time
	last                    time.Time
	rx, dup, remarked, dscp int
	seen                    map[uint32]struct{}
}

// sessionLoop — горутина канала. Интервалы определяются по T1 (как у агента),
// поэтому серверная и агентская половины ложатся в одну строку measurements.
func (r *Reflector) sessionLoop(ctx context.Context, s *rsession) {
	width := int64(s.Width)
	if width <= 0 {
		width = int64(time.Minute)
	}
	buckets := make(map[int64]*srvBucket)
	t := time.NewTicker(srvFlushGrace)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case m := <-s.in:
			k := m.t1 / width
			b := buckets[k]
			if b == nil {
				if len(buckets) >= maxOpenBuckets {
					continue // защита от мусорных меток времени
				}
				b = &srvBucket{start: time.Unix(0, k*width).UTC(), dscp: -1, seen: make(map[uint32]struct{})}
				buckets[k] = b
			}
			b.last = time.Now()
			if _, dup := b.seen[m.seq]; dup {
				b.dup++
				continue
			}
			b.seen[m.seq] = struct{}{}
			b.rx++
			if m.tos >= 0 {
				b.dscp = m.tos >> 2
				if b.dscp != s.DSCP {
					b.remarked++
				}
			}
		case now := <-t.C:
			for k, b := range buckets {
				endedByClock := now.Sub(b.start.Add(time.Duration(width))) >= srvFlushGrace
				// Если часы агента убежали вперёд, закрываем интервал по тишине.
				endedByIdle := now.Sub(b.last) >= time.Duration(width)+srvFlushGrace
				if !endedByClock && !endedByIdle {
					continue
				}
				st := ServerStat{ChannelID: s.ChannelID, TS: b.start, IntervalSec: int(width / int64(time.Second)),
					Rx: b.rx, Dup: b.dup, DSCPSeen: b.dscp, Remarked: b.remarked}
				select {
				case r.stats <- st:
				case <-ctx.Done():
					return
				}
				delete(buckets, k)
			}
		}
	}
}

// writer пакетно пишет серверную статистику в БД раз в 5 секунд.
func (r *Reflector) writer(ctx context.Context) {
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	var buf []ServerStat
	flush := func() {
		if len(buf) == 0 {
			return
		}
		wctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		err := r.store.UpsertServerStats(wctx, buf)
		cancel()
		if err != nil {
			r.log.Error("server stats write failed", "err", err, "rows", len(buf))
			if len(buf) > 100000 {
				buf = buf[len(buf)-100000:]
			}
			return
		}
		buf = buf[:0]
	}
	for {
		select {
		case st := <-r.stats:
			buf = append(buf, st)
		case <-t.C:
			flush()
		case <-ctx.Done():
			flush()
			return
		}
	}
}
