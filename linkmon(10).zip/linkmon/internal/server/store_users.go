package server

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
)

// UserView — пользователь для экрана управления (только для big_admin).
type UserView struct {
	ID        int64      `db:"id" json:"id"`
	Login     string     `db:"login" json:"login"`
	Role      string     `db:"role" json:"role"`
	Disabled  bool       `db:"disabled" json:"disabled"`
	Groups    []int32    `db:"groups" json:"groups"` // id групп области видимости
	LastLogin *time.Time `db:"last_login" json:"last_login"`
}

func (s *Store) ListUsers(ctx context.Context) ([]UserView, error) {
	rows, err := s.pool.Query(ctx, `SELECT u.id, u.login, u.role, u.disabled,
			COALESCE((SELECT array_agg(us.group_id ORDER BY us.group_id)
			          FROM user_scopes us WHERE us.user_id = u.id), '{}') AS groups,
			u.last_login_at AS last_login
		FROM admin_users u ORDER BY u.login`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[UserView])
}

func validRole(role string) bool {
	return role == RoleBigAdmin || role == RoleAdmin || role == RoleViewer
}

// CreateUser заводит нового пользователя с паролем и (для не-big_admin) областью видимости.
func (s *Store) CreateUser(ctx context.Context, login, password, role string, groups []int64) (int64, error) {
	if !validRole(role) {
		return 0, errors.New("unknown role")
	}
	hash, err := hashPassword(password)
	if err != nil {
		return 0, err
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)
	var id int64
	err = tx.QueryRow(ctx, `INSERT INTO admin_users (login, password_hash, role) VALUES ($1, $2, $3) RETURNING id`,
		login, hash, role).Scan(&id)
	if err != nil {
		return 0, err
	}
	if role != RoleBigAdmin && len(groups) > 0 {
		if _, err := tx.Exec(ctx, `INSERT INTO user_scopes (user_id, group_id)
			SELECT $1, unnest($2::int[]) ON CONFLICT DO NOTHING`, id, groups); err != nil {
			return 0, err
		}
	}
	return id, tx.Commit(ctx)
}

// SetUserScopes полностью заменяет область видимости пользователя.
func (s *Store) SetUserScopes(ctx context.Context, userID int64, groups []int64) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM user_scopes WHERE user_id = $1`, userID); err != nil {
		return err
	}
	if len(groups) > 0 {
		if _, err := tx.Exec(ctx, `INSERT INTO user_scopes (user_id, group_id)
			SELECT $1, unnest($2::int[]) ON CONFLICT DO NOTHING`, userID, groups); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// SetUserRole меняет роль. Область видимости big_admin не имеет смысла, поэтому очищаем её.
func (s *Store) SetUserRole(ctx context.Context, userID int64, role string) error {
	if !validRole(role) {
		return errors.New("unknown role")
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	tag, err := tx.Exec(ctx, `UPDATE admin_users SET role = $2 WHERE id = $1`, userID, role)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	if role == RoleBigAdmin {
		if _, err := tx.Exec(ctx, `DELETE FROM user_scopes WHERE user_id = $1`, userID); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// SetUserDisabled блокирует/разблокирует вход. Блокировка сбрасывает активные сессии.
func (s *Store) SetUserDisabled(ctx context.Context, userID int64, disabled bool) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	tag, err := tx.Exec(ctx, `UPDATE admin_users SET disabled = $2 WHERE id = $1`, userID, disabled)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	if disabled {
		if _, err := tx.Exec(ctx, `DELETE FROM admin_sessions WHERE user_id = $1`, userID); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ResetPassword задаёт новый пароль пользователю (big_admin). Сбрасывает его сессии.
func (s *Store) ResetPassword(ctx context.Context, userID int64, newPassword string) error {
	hash, err := hashPassword(newPassword)
	if err != nil {
		return err
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	tag, err := tx.Exec(ctx, `UPDATE admin_users SET password_hash = $2 WHERE id = $1`, userID, hash)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	if _, err := tx.Exec(ctx, `DELETE FROM admin_sessions WHERE user_id = $1`, userID); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// DeleteUser удаляет пользователя (кроме последнего big_admin — чтобы не потерять доступ).
func (s *Store) DeleteUser(ctx context.Context, userID int64) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	var role string
	if err := tx.QueryRow(ctx, `SELECT role FROM admin_users WHERE id = $1`, userID).Scan(&role); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return ErrNotFound
		}
		return err
	}
	if role == RoleBigAdmin {
		var others int
		if err := tx.QueryRow(ctx, `SELECT count(*) FROM admin_users WHERE role = 'big_admin' AND id <> $1`, userID).Scan(&others); err != nil {
			return err
		}
		if others == 0 {
			return errors.New("нельзя удалить последнего big_admin")
		}
	}
	if _, err := tx.Exec(ctx, `DELETE FROM admin_users WHERE id = $1`, userID); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
