package server

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
)

var ErrAuth = errors.New("invalid login or password")

// AdminUser — учётная запись администратора веб-интерфейса.
type AdminUser struct {
	ID    int64
	Login string
	Role  string
}

// EnsureAdmin создаёт учётку администратора, если её ещё нет (bootstrap из конфига).
// Если пользователь с таким логином уже есть, пароль не меняется — конфиг не перетирает
// то, что администратор мог сменить через интерфейс.
func (s *Store) EnsureAdmin(ctx context.Context, login, password string) (created bool, err error) {
	var exists bool
	if err = s.pool.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM admin_users WHERE login = $1)`, login).Scan(&exists); err != nil {
		return false, err
	}
	if exists {
		return false, nil
	}
	hash, err := hashPassword(password)
	if err != nil {
		return false, err
	}
	// Первый пользователь — big_admin: он управляет остальными и областями видимости.
	_, err = s.pool.Exec(ctx, `INSERT INTO admin_users (login, password_hash, role) VALUES ($1, $2, 'big_admin')`, login, hash)
	return err == nil, err
}

// Authenticate проверяет логин и пароль. Возвращает ErrAuth при любой неудаче,
// не раскрывая, что именно не совпало (логин или пароль).
func (s *Store) Authenticate(ctx context.Context, login, password string) (*AdminUser, error) {
	var u AdminUser
	var hash string
	var disabled bool
	err := s.pool.QueryRow(ctx, `SELECT id, login, role, password_hash, disabled FROM admin_users WHERE login = $1`, login).
		Scan(&u.ID, &u.Login, &u.Role, &hash, &disabled)
	if errors.Is(err, pgx.ErrNoRows) {
		// Прогоняем проверку по фиктивному хэшу, чтобы время ответа не выдавало
		// отсутствие пользователя (защита от перебора логинов по таймингу).
		_, _ = verifyPassword(password, dummyHash)
		return nil, ErrAuth
	}
	if err != nil {
		return nil, err
	}
	ok, err := verifyPassword(password, hash)
	if err != nil {
		return nil, err
	}
	if !ok || disabled {
		return nil, ErrAuth
	}
	_, _ = s.pool.Exec(ctx, `UPDATE admin_users SET last_login_at = now() WHERE id = $1`, u.ID)
	return &u, nil
}

// dummyHash — валидный argon2id-хэш случайной строки для выравнивания времени ответа.
var dummyHash = mustDummyHash()

func mustDummyHash() string {
	h, err := hashPassword("linkmon-timing-guard")
	if err != nil {
		panic(err)
	}
	return h
}

// CreateSession выпускает сессионный токен и сохраняет его хэш. Возвращается сам токен
// (для cookie) — в БД он не хранится.
func (s *Store) CreateSession(ctx context.Context, userID int64, ttl time.Duration, userAgent, ip string) (string, error) {
	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	token := base64.RawURLEncoding.EncodeToString(raw)
	sum := sha256.Sum256([]byte(token))
	var ipArg any
	if ip != "" {
		ipArg = ip
	}
	// TTL передаём в секундах: Duration.String() (например "24h0m0s") PostgreSQL как interval не парсит.
	_, err := s.pool.Exec(ctx, `INSERT INTO admin_sessions (token_hash, user_id, expires_at, user_agent, ip)
		VALUES ($1, $2, now() + make_interval(secs => $3), $4, $5::inet)`,
		sum[:], userID, int64(ttl.Seconds()), truncate(userAgent, 512), ipArg)
	if err != nil {
		return "", err
	}
	return token, nil
}

// SessionUser проверяет сессионный токен и возвращает пользователя. Заодно продлевает
// last_seen. Просроченные и несуществующие сессии, а также отключённые/удалённые
// пользователи дают ErrAuth.
func (s *Store) SessionUser(ctx context.Context, token string) (*AdminUser, error) {
	if token == "" {
		return nil, ErrAuth
	}
	sum := sha256.Sum256([]byte(token))
	var u AdminUser
	err := s.pool.QueryRow(ctx, `UPDATE admin_sessions se SET last_seen_at = now()
		FROM admin_users au
		WHERE se.token_hash = $1 AND se.expires_at > now()
		  AND au.id = se.user_id AND NOT au.disabled
		RETURNING au.id, au.login, au.role`, sum[:]).
		Scan(&u.ID, &u.Login, &u.Role)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrAuth
	}
	if err != nil {
		return nil, err
	}
	return &u, nil
}

// DeleteSession завершает конкретную сессию (выход из системы).
func (s *Store) DeleteSession(ctx context.Context, token string) error {
	if token == "" {
		return nil
	}
	sum := sha256.Sum256([]byte(token))
	_, err := s.pool.Exec(ctx, `DELETE FROM admin_sessions WHERE token_hash = $1`, sum[:])
	return err
}

// ChangePassword меняет пароль пользователя после проверки старого.
func (s *Store) ChangePassword(ctx context.Context, userID int64, oldPassword, newPassword string) error {
	var hash string
	if err := s.pool.QueryRow(ctx, `SELECT password_hash FROM admin_users WHERE id = $1`, userID).Scan(&hash); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return ErrNotFound
		}
		return err
	}
	ok, err := verifyPassword(oldPassword, hash)
	if err != nil {
		return err
	}
	if !ok {
		return ErrAuth
	}
	newHash, err := hashPassword(newPassword)
	if err != nil {
		return err
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `UPDATE admin_users SET password_hash = $2 WHERE id = $1`, userID, newHash); err != nil {
		return err
	}
	// Смена пароля завершает все прочие сессии этого пользователя.
	if _, err := tx.Exec(ctx, `DELETE FROM admin_sessions WHERE user_id = $1`, userID); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// PurgeExpiredSessions удаляет протухшие сессии (вызывается периодически).
func (s *Store) PurgeExpiredSessions(ctx context.Context) error {
	_, err := s.pool.Exec(ctx, `DELETE FROM admin_sessions WHERE expires_at < now()`)
	return err
}

func truncate(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}
