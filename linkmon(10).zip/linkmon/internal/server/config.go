package server

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	ListenAgents string `yaml:"listen_agents"` // HTTPS+mTLS для агентов
	ListenAdmin  string `yaml:"listen_admin"`  // REST для веб-интерфейса (за nginx), /metrics
	Reflector    struct {
		Listen  string `yaml:"listen"`
		Readers int    `yaml:"readers"`
	} `yaml:"reflector"`
	DatabaseURL   string   `yaml:"database_url"`
	StateDir      string   `yaml:"state_dir"`
	TLSHosts      []string `yaml:"tls_hosts"`
	MaxClockErrUS int64    `yaml:"max_clock_err_us"`

	// BWTestPort — порт (TCP+UDP), на котором сам сервер принимает нагрузочные тесты
	// пропускной способности (чтобы можно было тестировать «агент ↔ сервер»). 0 — выключено.
	BWTestPort int `yaml:"bwtest_port"`

	// RetentionDays — срок хранения метрик и загрузки интерфейсов; данные старше удаляются
	// встроенным планировщиком (без внешнего cron). 0 — по умолчанию 7 дней.
	RetentionDays int `yaml:"retention_days"`

	// Web — раздача собранного веб-интерфейса и параметры админ-авторизации.
	Web WebConfig `yaml:"web"`

	Alerts struct {
		IntervalSec       int    `yaml:"interval_sec"`
		AgentDownAfterSec int    `yaml:"agent_down_after_sec"`
		WebhookURL        string `yaml:"webhook_url"`
	} `yaml:"alerts"`
	Dev struct {
		// BootstrapToken создаётся при старте как токен регистрации агентов
		// с автоодобрением — только для разработки.
		BootstrapToken string `yaml:"bootstrap_token"`
	} `yaml:"dev"`
}

type WebConfig struct {
	// Dir — каталог собранного веб-интерфейса (web/dist). Пусто — сервер UI не раздаёт
	// (например, при разработке фронт поднимается через vite).
	Dir string `yaml:"dir"`
	// SessionTTLHours — срок жизни сессии администратора. 0 — по умолчанию (24 часа).
	SessionTTLHours int `yaml:"session_ttl_hours"`
	// SecureCookie — ставить ли на cookie флаг Secure. По умолчанию true; при разработке
	// без HTTPS на localhost можно выключить, чтобы cookie отдавалась по http.
	SecureCookie *bool `yaml:"secure_cookie"`
	// BootstrapAdmin — учётка администратора, создаваемая при старте, если её ещё нет.
	// Пароль хранится в БД как argon2id-хэш; в конфиге он нужен только для первичной
	// инициализации, потом строку можно удалить.
	BootstrapAdmin struct {
		Login    string `yaml:"login"`
		Password string `yaml:"password"`
	} `yaml:"bootstrap_admin"`
}

func (w WebConfig) SessionTTL() time.Duration {
	if w.SessionTTLHours <= 0 {
		return 24 * time.Hour
	}
	return time.Duration(w.SessionTTLHours) * time.Hour
}

func (w WebConfig) Secure() bool { return w.SecureCookie == nil || *w.SecureCookie }

func LoadConfig(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	if c.ListenAgents == "" {
		c.ListenAgents = ":8443"
	}
	if c.ListenAdmin == "" {
		c.ListenAdmin = "127.0.0.1:8080"
	}
	if c.Reflector.Listen == "" {
		c.Reflector.Listen = "0.0.0.0:8620"
	}
	if c.Reflector.Readers <= 0 {
		c.Reflector.Readers = runtime.NumCPU()
	}
	if c.StateDir == "" {
		c.StateDir = "state"
	}
	if c.Alerts.IntervalSec <= 0 {
		c.Alerts.IntervalSec = 60
	}
	if c.Alerts.AgentDownAfterSec <= 0 {
		c.Alerts.AgentDownAfterSec = 180
	}
	base, err := filepath.Abs(filepath.Dir(path))
	if err != nil {
		return nil, err
	}
	for _, p := range []*string{&c.StateDir, &c.Web.Dir} {
		if *p != "" && !filepath.IsAbs(*p) {
			*p = filepath.Join(base, *p)
		}
	}
	if c.DatabaseURL == "" {
		return nil, fmt.Errorf("database_url is required")
	}
	return &c, nil
}
