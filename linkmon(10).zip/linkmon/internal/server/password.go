package server

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"fmt"
	"strings"

	"golang.org/x/crypto/argon2"
)

// Хэширование паролей администраторов через argon2id с сохранением параметров в
// PHC-строке ($argon2id$v=19$m=...,t=...,p=...$salt$hash). Формат самодостаточен:
// параметры и соль лежат рядом с хэшем, поэтому их можно менять со временем, а старые
// хэши продолжат проверяться.

type argonParams struct {
	memory  uint32 // КиБ
	time    uint32
	threads uint8
	keyLen  uint32
	saltLen uint32
}

// Параметры по умолчанию: ~64 МиБ, 3 прохода. Разумный баланс для входа в админку.
var defaultArgon = argonParams{memory: 64 * 1024, time: 3, threads: 4, keyLen: 32, saltLen: 16}

func hashPassword(password string) (string, error) {
	p := defaultArgon
	salt := make([]byte, p.saltLen)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}
	key := argon2.IDKey([]byte(password), salt, p.time, p.memory, p.threads, p.keyLen)
	return fmt.Sprintf("$argon2id$v=%d$m=%d,t=%d,p=%d$%s$%s",
		argon2.Version, p.memory, p.time, p.threads,
		base64.RawStdEncoding.EncodeToString(salt),
		base64.RawStdEncoding.EncodeToString(key)), nil
}

var errBadHash = errors.New("malformed password hash")

// verifyPassword сравнивает пароль с хранимым PHC-хэшем за постоянное время.
func verifyPassword(password, encoded string) (bool, error) {
	parts := strings.Split(encoded, "$")
	if len(parts) != 6 || parts[1] != "argon2id" {
		return false, errBadHash
	}
	var version int
	if _, err := fmt.Sscanf(parts[2], "v=%d", &version); err != nil || version != argon2.Version {
		return false, errBadHash
	}
	var p argonParams
	if _, err := fmt.Sscanf(parts[3], "m=%d,t=%d,p=%d", &p.memory, &p.time, &p.threads); err != nil {
		return false, errBadHash
	}
	salt, err := base64.RawStdEncoding.DecodeString(parts[4])
	if err != nil {
		return false, errBadHash
	}
	want, err := base64.RawStdEncoding.DecodeString(parts[5])
	if err != nil {
		return false, errBadHash
	}
	got := argon2.IDKey([]byte(password), salt, p.time, p.memory, p.threads, uint32(len(want)))
	return subtle.ConstantTimeCompare(got, want) == 1, nil
}
