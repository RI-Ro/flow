package server

import (
	"context"
	"log/slog"
	"time"
)

// Prune удаляет метрики и загрузку интерфейсов старше days суток (через SQL-функцию linkmon_prune).
func (s *Store) Prune(ctx context.Context, days int) error {
	_, err := s.pool.Exec(ctx, `SELECT linkmon_prune($1, $1)`, days)
	return err
}

// RunRetention — встроенный планировщик авто-удаления старых данных. Запускается один раз
// при старте и далее раз в 6 часов удаляет всё старше retentionDays (по умолчанию 7 суток).
// Не требует внешнего cron/pg_cron.
func RunRetention(ctx context.Context, st *Store, retentionDays int, log *slog.Logger) {
	if retentionDays <= 0 {
		retentionDays = 7
	}
	run := func() {
		cctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		defer cancel()
		if err := st.Prune(cctx, retentionDays); err != nil && ctx.Err() == nil {
			log.Warn("retention prune failed", "err", err)
		} else if ctx.Err() == nil {
			log.Info("retention prune done", "keep_days", retentionDays)
		}
	}
	// Небольшая задержка на старте, чтобы не мешать миграциям/прогреву.
	select {
	case <-ctx.Done():
		return
	case <-time.After(30 * time.Second):
	}
	run()
	t := time.NewTicker(6 * time.Hour)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			run()
		}
	}
}
