package server

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
)

// IfaceMonitorView — монитор загрузки интерфейса с последними значениями.
type IfaceMonitorView struct {
	ID          int64      `db:"id" json:"id"`
	AgentID     string     `db:"agent_id" json:"agent_id"`
	Agent       string     `db:"agent" json:"agent"`
	Interface   string     `db:"interface" json:"interface"`
	SpeedBits   *int64     `db:"speed_bits" json:"speed_bits"`
	IntervalSec int        `db:"interval_sec" json:"interval_sec"`
	Enabled     bool       `db:"enabled" json:"enabled"`
	TS          *time.Time `db:"ts" json:"ts"`
	RxBps       *float64   `db:"rx_bps" json:"rx_bps"`
	TxBps       *float64   `db:"tx_bps" json:"tx_bps"`
	RxUtilPct   *float64   `db:"rx_util_pct" json:"rx_util_pct"`
	TxUtilPct   *float64   `db:"tx_util_pct" json:"tx_util_pct"`
	RxDrops     *int64     `db:"rx_drops" json:"rx_drops"`
	TxDrops     *int64     `db:"tx_drops" json:"tx_drops"`
}

// ListIfaceMonitors возвращает мониторы и их последнее значение за 10 минут (в области видимости).
func (s *Store) ListIfaceMonitors(ctx context.Context, u *AdminUser, agentID *string) ([]IfaceMonitorView, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, err
	}
	defer c.Release()
	rows, err := c.Query(ctx, `SELECT m.id, m.agent_id::text AS agent_id,
			COALESCE(NULLIF(a.name, ''), a.hostname, a.machine_id) AS agent, m.interface,
			m.speed_bits, m.interval_sec, m.enabled,
			l.ts, l.rx_bps, l.tx_bps, l.rx_util_pct, l.tx_util_pct, l.rx_drops, l.tx_drops
		FROM iface_monitors m
		JOIN agents a ON a.id = m.agent_id
		LEFT JOIN LATERAL (
			SELECT ts, rx_bps, tx_bps, rx_util_pct, tx_util_pct, rx_drops, tx_drops
			FROM iface_load il WHERE il.monitor_id = m.id AND il.ts > now() - interval '10 minutes'
			ORDER BY ts DESC LIMIT 1
		) l ON true
		WHERE ($1::uuid IS NULL OR m.agent_id = $1) AND linkmon_can_see_monitor(m.id)
		ORDER BY agent, m.interface`, agentID)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[IfaceMonitorView])
}

type LoadPoint struct {
	TS        time.Time `db:"ts" json:"ts"`
	RxBps     *float64  `db:"rx_bps" json:"rx_bps"`
	TxBps     *float64  `db:"tx_bps" json:"tx_bps"`
	RxUtilPct *float64  `db:"rx_util_pct" json:"rx_util_pct"`
	TxUtilPct *float64  `db:"tx_util_pct" json:"tx_util_pct"`
	RxPps     *float64  `db:"rx_pps" json:"rx_pps"`
	TxPps     *float64  `db:"tx_pps" json:"tx_pps"`
	RxDrops   *int64    `db:"rx_drops" json:"rx_drops"`
	TxDrops   *int64    `db:"tx_drops" json:"tx_drops"`
}

const loadCols = `ts, rx_bps, tx_bps, rx_util_pct, tx_util_pct, rx_pps, tx_pps, rx_drops, tx_drops`

// LoadSeries отдаёт ряд загрузки: сырые минуты или часовой агрегат для длинных диапазонов.
// Для часового агрегата берём пиковые значения — они важнее средних при анализе перегрузки.
func (s *Store) LoadSeries(ctx context.Context, u *AdminUser, monitorID int64, from, to time.Time) ([]LoadPoint, string, error) {
	c, err := s.asUser(ctx, u)
	if err != nil {
		return nil, "", err
	}
	defer c.Release()
	if to.Sub(from) > 48*time.Hour {
		rows, err := c.Query(ctx, `SELECT ts, rx_bps_max AS rx_bps, tx_bps_max AS tx_bps,
				rx_util_pct_max AS rx_util_pct, tx_util_pct_max AS tx_util_pct,
				NULL::float8 AS rx_pps, NULL::float8 AS tx_pps, rx_drops, tx_drops
			FROM v_iface_load_1h WHERE monitor_id = $1 AND ts >= $2 AND ts < $3
			  AND linkmon_can_see_monitor(monitor_id) ORDER BY ts`,
			monitorID, from, to)
		if err != nil {
			return nil, "v_iface_load_1h", err
		}
		pts, err := pgx.CollectRows(rows, pgx.RowToStructByName[LoadPoint])
		return pts, "v_iface_load_1h", err
	}
	rows, err := c.Query(ctx, `SELECT `+loadCols+` FROM v_iface_load
		WHERE monitor_id = $1 AND ts >= $2 AND ts < $3 AND linkmon_can_see_monitor(monitor_id) ORDER BY ts`, monitorID, from, to)
	if err != nil {
		return nil, "v_iface_load", err
	}
	pts, err := pgx.CollectRows(rows, pgx.RowToStructByName[LoadPoint])
	return pts, "v_iface_load", err
}

// MonitorForChannel находит монитор загрузки того же интерфейса, что и канал
// (чтобы на странице канала показать его фактическую загрузку). 0 — монитора нет.
func (s *Store) MonitorForChannel(ctx context.Context, channelID int64) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx, `SELECT m.id FROM iface_monitors m
		JOIN channels c ON c.agent_id = m.agent_id AND c.interface = m.interface
		WHERE c.id = $1 AND m.enabled`, channelID).Scan(&id)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, nil
	}
	return id, err
}

// LoadForAlerts — последние N интервалов загрузки для каналов с порогом max_util_pct.
type UtilRow struct {
	ChannelID       int64     `db:"channel_id"`
	TS              time.Time `db:"ts"`
	RxUtilPct       *float64  `db:"rx_util_pct"`
	TxUtilPct       *float64  `db:"tx_util_pct"`
	MaxUtil         *float64  `db:"max_util_pct"`
	BreachIntervals int       `db:"breach_intervals"`
}

func (s *Store) UtilWindows(ctx context.Context) ([]UtilRow, error) {
	rows, err := s.pool.Query(ctx, `SELECT m.channel_id, m.ts, m.rx_util_pct::float8 AS rx_util_pct,
			m.tx_util_pct::float8 AS tx_util_pct, s.max_util_pct::float8 AS max_util_pct, s.breach_intervals
		FROM (
			SELECT c.id AS channel_id, l.ts, l.rx_util_pct, l.tx_util_pct,
			       row_number() OVER (PARTITION BY c.id ORDER BY l.ts DESC) AS rn
			FROM channels c
			JOIN iface_monitors im ON im.agent_id = c.agent_id AND im.interface = c.interface AND im.enabled
			JOIN iface_load l ON l.monitor_id = im.id
			WHERE l.ts > now() - interval '2 hours'
		) m
		JOIN channels c2    ON c2.id = m.channel_id
		JOIN sla_profiles s ON s.id = c2.sla_id
		WHERE s.max_util_pct IS NOT NULL AND m.rn <= s.breach_intervals AND c2.enabled
		ORDER BY m.channel_id, m.ts DESC`)
	if err != nil {
		return nil, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[UtilRow])
}
