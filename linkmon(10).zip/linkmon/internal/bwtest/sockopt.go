package bwtest

import (
	"net"
	"syscall"
)

// setTOS выставляет байт IP TOS (DSCP<<2) на сокете соединения. Ошибки не фатальны:
// без нужных привилегий или на неподдерживаемой платформе тест просто идёт с DSCP=0.
func setTOS(conn syscall.Conn, dscp int) {
	if dscp <= 0 {
		return
	}
	rc, err := conn.SyscallConn()
	if err != nil {
		return
	}
	tos := dscp << 2
	_ = rc.Control(func(fd uintptr) {
		_ = syscall.SetsockoptInt(int(fd), syscall.IPPROTO_IP, syscall.IP_TOS, tos)
	})
}

// setConnTOS — удобная обёртка для net.Conn (TCP/UDP), реализующего syscall.Conn.
func setConnTOS(conn net.Conn, dscp int) {
	if sc, ok := conn.(syscall.Conn); ok {
		setTOS(sc, dscp)
	}
}
