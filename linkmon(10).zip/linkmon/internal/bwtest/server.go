package bwtest

import (
	"context"
	"encoding/binary"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// Server принимает тесты пропускной способности: управляющее TCP-соединение + потоки данных
// (TCP-соединения или UDP-датаграммы), сгруппированные по cookie. Один порт на TCP и UDP.
type Server struct {
	addr string
	mu   sync.Mutex
	sess map[string]*serverSession // ключ — cookie в hex
}

type serverSession struct {
	params    Params
	rxBytes   atomic.Int64
	rxPkts    atomic.Int64
	maxSeq    atomic.Int64
	jitter    jitterCalc
	udpAddr   atomic.Pointer[net.UDPAddr] // адрес клиента для reverse-UDP
	udpTxOnce atomic.Bool                 // отправитель reverse-UDP запущен
	deadline  time.Time                   // конец нагрузки (для reverse-UDP)
}

func NewServer(addr string) *Server { return &Server{addr: addr, sess: map[string]*serverSession{}} }

func (s *Server) get(cookie string) *serverSession {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.sess[cookie]
}

func (s *Server) put(cookie string, ss *serverSession) {
	s.mu.Lock()
	s.sess[cookie] = ss
	s.mu.Unlock()
}

func (s *Server) drop(cookie string) {
	s.mu.Lock()
	delete(s.sess, cookie)
	s.mu.Unlock()
}

// Run слушает TCP и UDP на одном порту до отмены контекста.
func (s *Server) Run(ctx context.Context) error {
	lc := net.ListenConfig{}
	ln, err := lc.Listen(ctx, "tcp", s.addr)
	if err != nil {
		return err
	}
	pc, err := lc.ListenPacket(ctx, "udp", s.addr)
	if err != nil {
		ln.Close()
		return err
	}
	udp := pc.(*net.UDPConn)
	go func() { <-ctx.Done(); ln.Close(); udp.Close() }()
	go s.udpLoop(udp)

	for {
		conn, err := ln.Accept()
		if err != nil {
			return nil // контекст отменён или слушатель закрыт
		}
		go s.handleTCP(ctx, conn)
	}
}

// handleTCP разбирает роль соединения: управляющее (C) или поток данных (D).
func (s *Server) handleTCP(ctx context.Context, conn net.Conn) {
	defer conn.Close()
	hdr := make([]byte, 1+cookieLen)
	conn.SetReadDeadline(time.Now().Add(ctlTimeout))
	if _, err := io.ReadFull(conn, hdr); err != nil {
		return
	}
	role := hdr[0]
	cookie := hexstr(hdr[1:])

	switch role {
	case roleCtl:
		s.handleControl(conn, cookie)
	case roleData:
		ss := s.get(cookie)
		if ss == nil {
			return
		}
		conn.SetReadDeadline(time.Time{})
		if ss.params.Reverse {
			s.tcpSource(conn, ss) // сервер отдаёт данные (download)
		} else {
			s.tcpSink(conn, ss) // сервер принимает данные (upload)
		}
	}
}

func (s *Server) handleControl(conn net.Conn, cookie string) {
	var p Params
	if err := readMsg(conn, &p); err != nil {
		return
	}
	p.norm()
	ss := &serverSession{params: p}
	ss.deadline = time.Now().Add(time.Duration(p.DurationSec) * time.Second)
	s.put(cookie, ss)
	defer s.drop(cookie)

	if err := writeMsg(conn, map[string]any{"ok": true}); err != nil {
		return
	}
	// Ждём сигнал завершения от клиента (он управляет длительностью), затем отдаём свою статистику.
	var done map[string]any
	conn.SetReadDeadline(time.Now().Add(time.Duration(p.DurationSec+30) * time.Second))
	if err := readMsg(conn, &done); err != nil {
		return
	}
	res := Result{
		Proto: p.Proto, Streams: p.Streams, Reverse: p.Reverse,
		DurationSec: float64(p.DurationSec),
		Bytes:       ss.rxBytes.Load(),
		Packets:     ss.rxPkts.Load(),
	}
	if res.DurationSec > 0 {
		res.Mbps = float64(res.Bytes) * 8 / 1e6 / res.DurationSec
	}
	if p.Proto == "udp" && !p.Reverse {
		expected := ss.maxSeq.Load() + 1
		if expected > res.Packets {
			res.LostPackets = expected - res.Packets
		}
		if expected > 0 {
			res.LossPct = 100 * float64(res.LostPackets) / float64(expected)
		}
		res.JitterMs = ss.jitter.value()
	}
	_ = writeMsg(conn, res)
}

func (s *Server) tcpSink(conn net.Conn, ss *serverSession) {
	buf := make([]byte, 128*1024)
	for {
		n, err := conn.Read(buf)
		if n > 0 {
			ss.rxBytes.Add(int64(n))
		}
		if err != nil {
			return
		}
	}
}

func (s *Server) tcpSource(conn net.Conn, ss *serverSession) {
	setConnTOS(conn, ss.params.DSCP)
	buf := make([]byte, ss.params.LengthBytes)
	deadline := time.Now().Add(time.Duration(ss.params.DurationSec) * time.Second)
	conn.SetWriteDeadline(deadline)
	gap := pktGap(ss.params.TargetMbps, ss.params.Streams, ss.params.LengthBytes)
	next := time.Now()
	for time.Now().Before(deadline) {
		n, err := conn.Write(buf)
		if n > 0 {
			ss.rxBytes.Add(int64(n)) // для reverse считаем отданное как объём сессии
		}
		if err != nil {
			return
		}
		if gap > 0 {
			next = next.Add(gap)
			if d := time.Until(next); d > 0 {
				time.Sleep(d)
			}
		}
	}
}

// udpLoop принимает UDP-датаграммы всех сессий и раскладывает по cookie.
// Формат датаграммы: cookie(16) | seq(8, BE) | sendNanos(8, BE) | payload.
func (s *Server) udpLoop(udp *net.UDPConn) {
	buf := make([]byte, 65535)
	for {
		n, from, err := udp.ReadFromUDP(buf)
		if err != nil {
			return
		}
		if n < cookieLen+16 {
			continue
		}
		ss := s.get(hexstr(buf[:cookieLen]))
		if ss == nil || ss.params.Proto != "udp" {
			continue
		}
		if ss.params.Reverse {
			// «hello» от клиента: узнаём его адрес и один раз запускаем отправитель.
			ss.udpAddr.Store(from)
			if ss.udpTxOnce.CompareAndSwap(false, true) {
				go s.udpSource(udp, from, ss)
			}
			continue
		}
		ss.udpAddr.Store(from)
		ss.rxBytes.Add(int64(n))
		ss.rxPkts.Add(1)
		seq := int64(binary.BigEndian.Uint64(buf[cookieLen : cookieLen+8]))
		if seq > ss.maxSeq.Load() {
			ss.maxSeq.Store(seq)
		}
		sendNs := int64(binary.BigEndian.Uint64(buf[cookieLen+8 : cookieLen+16]))
		ss.jitter.add(sendNs, time.Now().UnixNano())
	}
}

// udpSource шлёт reverse-UDP поток клиенту (download) до дедлайна сессии.
func (s *Server) udpSource(udp *net.UDPConn, to *net.UDPAddr, ss *serverSession) {
	// DSCP для reverse-UDP выставляется на общем сокете слушателя (ограничение: при
	// одновременных reverse-UDP тестах с разным DSCP применится последний заданный).
	setTOS(udp, ss.params.DSCP)
	pkt := make([]byte, ss.params.LengthBytes)
	gap := pktGap(ss.params.TargetMbps, ss.params.Streams, ss.params.LengthBytes)
	var seq int64
	next := time.Now()
	for time.Now().Before(ss.deadline) {
		binary.BigEndian.PutUint64(pkt[cookieLen:cookieLen+8], uint64(seq))
		binary.BigEndian.PutUint64(pkt[cookieLen+8:cookieLen+16], uint64(time.Now().UnixNano()))
		n, err := udp.WriteToUDP(pkt, to)
		if n > 0 {
			ss.rxBytes.Add(int64(n)) // для reverse считаем отданное как объём сессии
			ss.rxPkts.Add(1)
		}
		if err != nil {
			return
		}
		seq++
		if gap > 0 {
			next = next.Add(gap)
			if d := time.Until(next); d > 0 {
				time.Sleep(d)
			}
		}
	}
}

// jitterCalc — оценка джиттера по RFC 1889 (как в iperf для UDP).
type jitterCalc struct {
	mu       sync.Mutex
	prevSend int64
	prevRecv int64
	jitter   float64
	has      bool
}

func (j *jitterCalc) add(sendNs, recvNs int64) {
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.has {
		d := float64((recvNs - j.prevRecv) - (sendNs - j.prevSend))
		if d < 0 {
			d = -d
		}
		j.jitter += (d - j.jitter) / 16
	}
	j.prevSend, j.prevRecv, j.has = sendNs, recvNs, true
}

func (j *jitterCalc) value() float64 {
	j.mu.Lock()
	defer j.mu.Unlock()
	return j.jitter / 1e6 // нс → мс
}

const hexdigits = "0123456789abcdef"

func hexstr(b []byte) string {
	out := make([]byte, len(b)*2)
	for i, c := range b {
		out[i*2] = hexdigits[c>>4]
		out[i*2+1] = hexdigits[c&0xf]
	}
	return string(out)
}
