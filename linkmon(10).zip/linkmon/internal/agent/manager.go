package agent

import (
	"context"
	"log/slog"
	"reflect"
	"sync"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/clock"
)

// Manager держит по сессии на каждый канал и по монитору на каждый интерфейс
// и приводит их наборы к конфигурации сервера.
type Manager struct {
	mu        sync.Mutex
	running   map[int64]*runningSession
	monitors  map[string]*runningMonitor
	out       chan<- api.Interval
	loadOut   chan<- api.IfaceLoad
	clock     *clock.Monitor
	allow     func(api.ChannelConfig) error
	device    func(string) string // имя для SO_BINDTODEVICE ("" — без привязки)
	sysDevice func(string) string // реальное имя устройства для чтения счётчиков
	log       *slog.Logger
}

type runningSession struct {
	cfg    api.ChannelConfig
	cancel context.CancelFunc
	done   chan struct{}
}

type runningMonitor struct {
	cfg    api.IfaceMonitor
	cancel context.CancelFunc
	done   chan struct{}
}

func NewManager(out chan<- api.Interval, loadOut chan<- api.IfaceLoad, clk *clock.Monitor,
	allow func(api.ChannelConfig) error, device, sysDevice func(string) string, log *slog.Logger) *Manager {
	return &Manager{
		running: make(map[int64]*runningSession), monitors: make(map[string]*runningMonitor),
		out: out, loadOut: loadOut, clock: clk, allow: allow, device: device, sysDevice: sysDevice, log: log,
	}
}

func (m *Manager) Apply(ctx context.Context, chans []api.ChannelConfig) {
	m.mu.Lock()
	defer m.mu.Unlock()

	want := make(map[int64]api.ChannelConfig, len(chans))
	for _, c := range chans {
		if err := m.allow(c); err != nil {
			m.log.Warn("channel rejected by local policy", "channel_id", c.ChannelID, "err", err)
			continue
		}
		want[c.ChannelID] = c
	}
	for id, r := range m.running {
		if c, ok := want[id]; ok && reflect.DeepEqual(c, r.cfg) {
			continue
		}
		r.cancel()
		<-r.done
		delete(m.running, id)
	}
	for id, c := range want {
		if _, ok := m.running[id]; !ok {
			m.running[id] = m.start(ctx, c)
		}
	}
}

// ApplyMonitors приводит набор мониторов загрузки к списку из конфигурации сервера.
// Разрешён только интерфейс, который встречается хотя бы в одном локально дозволенном канале
// или явно перечислен в локальном конфиге агента (проверку делает вызывающий через allowIface).
func (m *Manager) ApplyMonitors(ctx context.Context, mons []api.IfaceMonitor, allowIface func(string) bool) {
	m.mu.Lock()
	defer m.mu.Unlock()

	want := make(map[string]api.IfaceMonitor, len(mons))
	for _, mon := range mons {
		if !allowIface(mon.Interface) {
			m.log.Warn("iface monitor rejected by local policy", "iface", mon.Interface)
			continue
		}
		want[mon.Interface] = mon
	}
	for iface, r := range m.monitors {
		if c, ok := want[iface]; ok && c == r.cfg {
			continue
		}
		r.cancel()
		<-r.done
		delete(m.monitors, iface)
	}
	for iface, mon := range want {
		if _, ok := m.monitors[iface]; !ok {
			m.monitors[iface] = m.startMonitor(ctx, mon)
		}
	}
}

func (m *Manager) startMonitor(ctx context.Context, mon api.IfaceMonitor) *runningMonitor {
	mctx, cancel := context.WithCancel(ctx)
	r := &runningMonitor{cfg: mon, cancel: cancel, done: make(chan struct{})}
	log := m.log.With("iface", mon.Interface)
	lm := newLoadMonitor(mon, m.sysDevice(mon.Interface), log)
	go func() {
		defer close(r.done)
		log.Info("load monitor started", "interval_sec", mon.IntervalSec)
		lm.Run(mctx, m.loadOut)
	}()
	return r
}

func (m *Manager) MonitorCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.monitors)
}

func (m *Manager) start(ctx context.Context, c api.ChannelConfig) *runningSession {
	sctx, cancel := context.WithCancel(ctx)
	r := &runningSession{cfg: c, cancel: cancel, done: make(chan struct{})}
	log := m.log.With("channel_id", c.ChannelID, "iface", c.Interface, "dscp", c.DSCP, "reflector", c.ReflectorAddr)
	go func() {
		defer close(r.done)
		for {
			s := newSession(c, sessionOpts{device: m.device(c.Interface), width: time.Duration(c.IntervalSec) * time.Second}, m.clock.OneWayOK, log)
			log.Info("session started")
			err := s.Run(sctx, m.out)
			if sctx.Err() != nil {
				return
			}
			// Например, подинтерфейс ещё не поднят: повторяем, пока канал есть в конфигурации.
			log.Warn("session stopped, restarting", "err", err)
			select {
			case <-sctx.Done():
				return
			case <-time.After(10 * time.Second):
			}
		}
	}()
	return r
}

func (m *Manager) Channel(id int64) (api.ChannelConfig, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	r, ok := m.running[id]
	if !ok {
		return api.ChannelConfig{}, false
	}
	return r.cfg, true
}

func (m *Manager) Count() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.running)
}

func (m *Manager) StopAll() {
	m.mu.Lock()
	defer m.mu.Unlock()
	for id, r := range m.running {
		r.cancel()
		<-r.done
		delete(m.running, id)
	}
	for iface, r := range m.monitors {
		r.cancel()
		<-r.done
		delete(m.monitors, iface)
	}
}
