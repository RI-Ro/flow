package agent

import (
	"fmt"
	"net"
	"os"
	"path/filepath"
	"slices"
	"time"

	"gopkg.in/yaml.v3"

	"github.com/example/linkmon/internal/api"
)

// Config — локальный конфиг агента. Он задаёт границы дозволенного:
// сервер может назначить только комбинации интерфейс × цель × DSCP, перечисленные здесь.
//
// Один агент может работать с несколькими серверами одновременно: секция servers.
// Каждый сервер — независимый аплинк: своя регистрация, свой сертификат, свой spool и
// своя очередь команд. Измерения на рефлектор каждого сервера идут отдельно (трафик
// дублируется). Для обратной совместимости одиночный agent.server превращается в один сервер.
type Config struct {
	Agent      AgentSection `yaml:"agent"`
	Servers    []ServerConn `yaml:"servers"`
	Targets    []Target     `yaml:"targets"`
	Interfaces []Interface  `yaml:"interfaces"`

	servers []ServerConn // нормализованный список (заполняется в LoadConfig)
}

// ServerConn — один сервер, к которому подключается агент.
type ServerConn struct {
	Name        string `yaml:"name"`              // короткое имя (каталог состояния, логи)
	URL         string `yaml:"url"`               // https://host:8443
	CAFile      string `yaml:"ca_file"`           // CA этого сервера
	TokenFile   string `yaml:"enroll_token_file"` // файл с токеном регистрации
	EnrollToken string `yaml:"enroll_token"`      // токен строкой (приоритетнее файла)

	stateDir string // <agent.state_dir>/<name>: сертификат, spool, кэш конфига этого сервера
}

func (s ServerConn) StateDir() string { return s.stateDir }

type AgentSection struct {
	// Одиночный сервер (обратная совместимость). Если задана секция servers — игнорируется.
	Server      string `yaml:"server"`
	CAFile      string `yaml:"ca_file"`
	TokenFile   string `yaml:"enroll_token_file"`
	EnrollToken string `yaml:"enroll_token"`

	Name                string `yaml:"name"`       // понятное имя агента (передаётся серверу при регистрации)
	MachineID           string `yaml:"machine_id"` // переопределение /etc/machine-id
	StateDir            string `yaml:"state_dir"`
	SpoolMaxMB          int    `yaml:"spool_max_mb"`
	MaxClockErrUS       int64  `yaml:"max_clock_err_us"`
	StateRetentionHours int    `yaml:"state_retention_hours"` // сколько держать неотправленные данные (по умолчанию 48 ч)
	// BWTestPort — порт (TCP+UDP) для приёма тестов пропускной способности между агентами.
	// 0 — тесты пропускной способности отключены (агент не слушает как сервер bwtest).
	BWTestPort int `yaml:"bwtest_port"`
}

// Servers возвращает нормализованный список серверов.
func (c *Config) Servers2() []ServerConn { return c.servers }

// RetentionDur — срок хранения неотправленных данных на агенте (по умолчанию 48 часов).
func (c *Config) RetentionDur() time.Duration {
	h := c.Agent.StateRetentionHours
	if h <= 0 {
		h = 48
	}
	return time.Duration(h) * time.Hour
}

type Target struct {
	Name    string `yaml:"name"`
	Address string `yaml:"address"`
	Port    int    `yaml:"port"`
}

type Interface struct {
	Name    string   `yaml:"name"`
	Source  string   `yaml:"source"`
	DSCP    []int    `yaml:"dscp"`
	Targets []string `yaml:"targets"`
	// Bind — привязывать сокет к интерфейсу (SO_BINDTODEVICE, нужен CAP_NET_RAW).
	// false — имя служит только меткой канала: удобно для запуска через go run без root.
	Bind *bool `yaml:"bind"`
	// Device — реальное имя устройства в системе, если оно отличается от Name
	// (например, Name — понятная метка «Провайдер А», Device — eth0.100).
	Device string `yaml:"device"`
	// Monitor — снимать фактическую загрузку интерфейса из счётчиков ядра.
	Monitor bool `yaml:"monitor"`
	// SpeedMbit — номинальная скорость канала (Мбит/с) для расчёта утилизации.
	// 0 — попытаться взять из sysfs; для VLAN обычно недоступна.
	SpeedMbit int64 `yaml:"speed_mbit"`
	// MonitorIntervalSec — интервал снятия загрузки; 0 — по умолчанию (60 с).
	MonitorIntervalSec int `yaml:"monitor_interval_sec"`
	// TWAMP — слать пробы в формате TWAMP-Light (RFC 5357, unauthenticated) для совместимости
	// с аппаратными TWAMP-ответчиками. Цели интерфейса при этом — внешние TWAMP-responder'ы.
	TWAMP bool `yaml:"twamp"`
}

// sysName — имя устройства в /sys/class/net (для счётчиков) и для SO_BINDTODEVICE.
func (i Interface) sysName() string {
	if i.Device != "" {
		return i.Device
	}
	return i.Name
}

// Device возвращает имя устройства для SO_BINDTODEVICE или "" без привязки.
func (c *Config) Device(iface string) string {
	for _, i := range c.Interfaces {
		if i.Name == iface {
			if i.Bind != nil && !*i.Bind {
				return ""
			}
			return i.sysName()
		}
	}
	return iface
}

// SysDevice всегда возвращает реальное имя устройства для чтения счётчиков,
// независимо от флага bind.
func (c *Config) SysDevice(iface string) string {
	for _, i := range c.Interfaces {
		if i.Name == iface {
			return i.sysName()
		}
	}
	return iface
}

// Monitors — интерфейсы, помеченные monitor: true. Их capabilities передаются серверу,
// а сервер возвращает их в AgentConfig.Monitors.
func (c *Config) Monitors() []api.IfaceMonitor {
	var out []api.IfaceMonitor
	for _, i := range c.Interfaces {
		if !i.Monitor {
			continue
		}
		out = append(out, api.IfaceMonitor{
			Interface:   i.Name,
			SpeedBits:   i.SpeedMbit * 1_000_000,
			IntervalSec: i.MonitorIntervalSec,
		})
	}
	return out
}

// AllowIface разрешает мониторинг загрузки только для интерфейсов из локального конфига.
func (c *Config) AllowIface(iface string) bool {
	for _, i := range c.Interfaces {
		if i.Name == iface {
			return true
		}
	}
	return false
}

// sanitizeName делает из имени сервера безопасное имя каталога.
func sanitizeName(s string) string {
	out := make([]rune, 0, len(s))
	for _, r := range s {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '-', r == '_':
			out = append(out, r)
		default:
			out = append(out, '_')
		}
	}
	if len(out) == 0 {
		return "srv"
	}
	return string(out)
}

// resolve делает путь абсолютным относительно каталога конфигурационного файла.
func resolve(base, p string) string {
	if p == "" || filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(base, p)
}

func LoadConfig(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	a := &c.Agent
	if a.StateDir == "" {
		a.StateDir = "state"
	}
	base, err := filepath.Abs(filepath.Dir(path))
	if err != nil {
		return nil, err
	}
	a.StateDir = resolve(base, a.StateDir)
	if a.SpoolMaxMB <= 0 {
		a.SpoolMaxMB = 512
	}

	// Нормализуем список серверов: либо явная секция servers, либо один сервер из agent.*.
	servers := c.Servers
	if len(servers) == 0 {
		if a.Server == "" {
			return nil, fmt.Errorf("нужно задать либо servers, либо agent.server")
		}
		servers = []ServerConn{{
			Name: "default", URL: a.Server, CAFile: a.CAFile,
			TokenFile: a.TokenFile, EnrollToken: a.EnrollToken,
		}}
	}
	seenSrv := map[string]bool{}
	for i := range servers {
		sv := &servers[i]
		if sv.URL == "" {
			return nil, fmt.Errorf("server #%d: url is required", i)
		}
		if sv.Name == "" {
			sv.Name = fmt.Sprintf("srv%d", i+1)
		}
		if seenSrv[sv.Name] {
			return nil, fmt.Errorf("duplicate server name %q", sv.Name)
		}
		seenSrv[sv.Name] = true
		if sv.CAFile == "" {
			sv.CAFile = "ca.crt"
		}
		if sv.TokenFile == "" {
			sv.TokenFile = "token"
		}
		sv.CAFile = resolve(base, sv.CAFile)
		sv.TokenFile = resolve(base, sv.TokenFile)
		// Отдельный каталог состояния на каждый сервер: свои ключ, сертификат, spool, кэш.
		sv.stateDir = filepath.Join(a.StateDir, sanitizeName(sv.Name))
	}
	c.servers = servers
	names := map[string]bool{}
	for i := range c.Targets {
		t := &c.Targets[i]
		if t.Name == "" || names[t.Name] {
			return nil, fmt.Errorf("target #%d: empty or duplicate name", i)
		}
		names[t.Name] = true
		if ip := net.ParseIP(t.Address); ip == nil || ip.To4() == nil {
			return nil, fmt.Errorf("target %s: address must be IPv4", t.Name)
		}
		if t.Port == 0 {
			t.Port = api.DefaultReflectorPort
		}
	}
	for _, ifc := range c.Interfaces {
		if ifc.Name == "" {
			return nil, fmt.Errorf("interface without name")
		}
		for _, d := range ifc.DSCP {
			if d < 0 || d > 63 {
				return nil, fmt.Errorf("interface %s: DSCP %d out of range", ifc.Name, d)
			}
		}
		for _, tn := range ifc.Targets {
			if !names[tn] {
				return nil, fmt.Errorf("interface %s: unknown target %q", ifc.Name, tn)
			}
		}
	}
	return &c, nil
}

func (c *Config) target(name string) *Target {
	for i := range c.Targets {
		if c.Targets[i].Name == name {
			return &c.Targets[i]
		}
	}
	return nil
}

func (c *Config) Capabilities() api.Capabilities {
	var caps api.Capabilities
	caps.BWTestPort = c.Agent.BWTestPort
	for _, ifc := range c.Interfaces {
		ic := api.IfaceCap{
			Name: ifc.Name, Source: ifc.Source, DSCP: ifc.DSCP,
			Monitor: ifc.Monitor, SpeedBits: ifc.SpeedMbit * 1_000_000, IntervalSec: ifc.MonitorIntervalSec,
			TWAMP: ifc.TWAMP,
		}
		for _, tn := range ifc.Targets {
			t := c.target(tn)
			ic.Targets = append(ic.Targets, api.TargetCap{Name: t.Name, Address: t.Address, Port: t.Port})
		}
		caps.Interfaces = append(caps.Interfaces, ic)
	}
	return caps
}

// Allow проверяет, что назначенный сервером канал не выходит за рамки локального конфига.
func (c *Config) Allow(ch api.ChannelConfig) error {
	for _, ifc := range c.Interfaces {
		if ifc.Name != ch.Interface {
			continue
		}
		if !slices.Contains(ifc.DSCP, ch.DSCP) {
			return fmt.Errorf("DSCP %d not allowed on %s", ch.DSCP, ifc.Name)
		}
		for _, tn := range ifc.Targets {
			if t := c.target(tn); t != nil && t.Address == ch.ReflectorAddr && t.Port == ch.ReflectorPort {
				return nil
			}
		}
		return fmt.Errorf("reflector %s:%d not allowed on %s", ch.ReflectorAddr, ch.ReflectorPort, ifc.Name)
	}
	return fmt.Errorf("interface %q not allowed", ch.Interface)
}
