package agent

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"github.com/example/linkmon/internal/api"
)

// Identity — ключ и сертификат агента. Сертификат подменяется на лету при перевыпуске.
type Identity struct {
	AgentID  string
	certFile string
	pool     *x509.CertPool
	key      *ecdsa.PrivateKey
	keyPEM   []byte
	cert     atomic.Pointer[tls.Certificate]
}

func (id *Identity) TLSConfig() *tls.Config {
	return &tls.Config{
		RootCAs:    id.pool,
		MinVersion: tls.VersionTLS12,
		GetClientCertificate: func(*tls.CertificateRequestInfo) (*tls.Certificate, error) {
			return id.cert.Load(), nil
		},
	}
}

func (id *Identity) NotAfter() time.Time {
	if c := id.cert.Load(); c != nil && c.Leaf != nil {
		return c.Leaf.NotAfter
	}
	return time.Time{}
}

func (id *Identity) setCert(certPEM []byte) error {
	c, err := tls.X509KeyPair(certPEM, id.keyPEM)
	if err != nil {
		return err
	}
	leaf, err := x509.ParseCertificate(c.Certificate[0])
	if err != nil {
		return err
	}
	if _, err := leaf.Verify(x509.VerifyOptions{Roots: id.pool, KeyUsages: []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth}}); err != nil {
		return fmt.Errorf("certificate not issued by server CA: %w", err)
	}
	c.Leaf = leaf
	id.cert.Store(&c)
	id.AgentID = leaf.Subject.CommonName
	return nil
}

// LoadOrEnroll загружает сохранённый сертификат или регистрирует агента на конкретном сервере.
// Регистрация повторяется, пока администратор не подтвердит агента (или токен не даёт автоапрув).
func LoadOrEnroll(ctx context.Context, cfg *Config, sv ServerConn, version string, log *slog.Logger) (*Identity, error) {
	dir := sv.stateDir
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	caPEM, err := os.ReadFile(sv.CAFile)
	if err != nil {
		return nil, fmt.Errorf("server CA: %w", err)
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(caPEM) {
		return nil, fmt.Errorf("%s: no certificates", sv.CAFile)
	}
	key, keyPEM, err := loadOrCreateKey(filepath.Join(dir, "agent.key"))
	if err != nil {
		return nil, err
	}
	id := &Identity{certFile: filepath.Join(dir, "agent.crt"), pool: pool, key: key, keyPEM: keyPEM}

	if certPEM, err := os.ReadFile(id.certFile); err == nil {
		if err := id.setCert(certPEM); err == nil && time.Now().Before(id.NotAfter()) {
			return id, nil
		}
		log.Warn("stored certificate is unusable, enrolling again")
	}

	mid := cfg.Agent.MachineID
	if mid == "" {
		mid = machineID()
	}
	csr, err := makeCSR(key, mid)
	if err != nil {
		return nil, err
	}
	host, _ := os.Hostname()
	req := api.EnrollRequest{MachineID: mid, Hostname: host, Name: cfg.Agent.Name,
		Version: version, CSRPEM: csr, Capabilities: cfg.Capabilities()}
	req.Token = sv.EnrollToken
	if req.Token == "" {
		if tok, err := os.ReadFile(sv.TokenFile); err == nil {
			req.Token = strings.TrimSpace(string(tok))
		}
	}
	anon := NewClient(sv.URL, &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12})

	for {
		wait := 30 * time.Second
		var resp api.EnrollResponse
		err := anon.Do(ctx, http.MethodPost, "/v1/enroll", req, &resp, 30*time.Second)
		switch {
		case err != nil:
			log.Warn("enrollment failed", "err", err)
		case resp.Status == api.StatusApproved:
			if err := id.setCert([]byte(resp.CertPEM)); err != nil {
				return nil, err
			}
			if err := writeFileAtomic(id.certFile, []byte(resp.CertPEM), 0o600); err != nil {
				return nil, err
			}
			log.Info("agent enrolled", "agent_id", id.AgentID)
			return id, nil
		case resp.Status == api.StatusPending:
			log.Info("waiting for administrator approval", "machine_id", mid)
			if resp.RetryAfterSec > 0 {
				wait = time.Duration(resp.RetryAfterSec) * time.Second
			}
		default:
			return nil, fmt.Errorf("enrollment: unexpected status %q", resp.Status)
		}
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-time.After(wait):
		}
	}
}

// RenewLoop перевыпускает сертификат за 30 дней до окончания срока.
func (id *Identity) RenewLoop(ctx context.Context, c *Client, log *slog.Logger) {
	for {
		if time.Until(id.NotAfter()) < 30*24*time.Hour {
			if err := id.renew(ctx, c); err != nil {
				log.Warn("certificate renewal failed", "err", err)
			} else {
				log.Info("certificate renewed", "not_after", id.NotAfter())
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(12 * time.Hour):
		}
	}
}

func (id *Identity) renew(ctx context.Context, c *Client) error {
	csr, err := makeCSR(id.key, id.AgentID)
	if err != nil {
		return err
	}
	var resp api.EnrollResponse
	if err := c.Do(ctx, http.MethodPost, "/v1/agent/renew", api.EnrollRequest{CSRPEM: csr}, &resp, 30*time.Second); err != nil {
		return err
	}
	if err := id.setCert([]byte(resp.CertPEM)); err != nil {
		return err
	}
	if err := writeFileAtomic(id.certFile, []byte(resp.CertPEM), 0o600); err != nil {
		return err
	}
	c.CloseIdle() // новые соединения пойдут уже с новым сертификатом
	return nil
}

func loadOrCreateKey(path string) (*ecdsa.PrivateKey, []byte, error) {
	b, err := os.ReadFile(path)
	if err == nil {
		blk, _ := pem.Decode(b)
		if blk == nil {
			return nil, nil, fmt.Errorf("%s: invalid PEM", path)
		}
		k, err := x509.ParseECPrivateKey(blk.Bytes)
		return k, b, err
	}
	if !errors.Is(err, os.ErrNotExist) {
		return nil, nil, err
	}
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, nil, err
	}
	der, err := x509.MarshalECPrivateKey(k)
	if err != nil {
		return nil, nil, err
	}
	b = pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: der})
	return k, b, writeFileAtomic(path, b, 0o600)
}

func makeCSR(key *ecdsa.PrivateKey, cn string) (string, error) {
	der, err := x509.CreateCertificateRequest(rand.Reader, &x509.CertificateRequest{Subject: pkix.Name{CommonName: cn}}, key)
	if err != nil {
		return "", err
	}
	return string(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE REQUEST", Bytes: der})), nil
}

func machineID() string {
	if b, err := os.ReadFile("/etc/machine-id"); err == nil {
		if s := strings.TrimSpace(string(b)); s != "" {
			return s
		}
	}
	h, _ := os.Hostname()
	return h
}
