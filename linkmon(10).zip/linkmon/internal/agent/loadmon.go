package agent

import (
	"context"
	"log/slog"
	"time"

	"github.com/example/linkmon/internal/api"
	"github.com/example/linkmon/internal/netstat"
)

// loadMonitor снимает счётчики интерфейса и раз в интервал выдаёт фактическую загрузку.
// Интервалы выровнены по UTC так же, как у измерителей качества, поэтому загрузку
// и качество канала можно сопоставлять по времени (например, «потери при заполнении uplink»).
type loadMonitor struct {
	mon    api.IfaceMonitor
	device string // имя устройства в sysfs (обычно совпадает с mon.Interface)
	log    *slog.Logger
}

func newLoadMonitor(mon api.IfaceMonitor, device string, log *slog.Logger) *loadMonitor {
	if mon.IntervalSec <= 0 {
		mon.IntervalSec = 60
	}
	return &loadMonitor{mon: mon, device: device, log: log}
}

func (m *loadMonitor) Run(ctx context.Context, out chan<- api.IfaceLoad) {
	width := time.Duration(m.mon.IntervalSec) * time.Second

	// Ждём начала следующей выровненной границы, затем тикаем ровно по границам интервалов.
	next := time.Now().UTC().Truncate(width).Add(width)
	select {
	case <-ctx.Done():
		return
	case <-time.After(time.Until(next)):
	}
	// Базовая точка отсчёта — ровно на границе интервала. Первый полный интервал будет
	// выдан на следующем тике, без частичного «хвоста» от старта агента.
	prevCounters, prevOK := netstat.Read(m.device)
	prevAt := time.Now().UTC()

	t := time.NewTicker(width)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		at := time.Now().UTC()
		cur, ok := netstat.Read(m.device)
		if ok && prevOK {
			// Метка интервала — его начало (границы UTC), как у метрик качества.
			load := m.delta(prevCounters, cur, prevAt, at, prevAt.Truncate(width))
			select {
			case out <- load:
			case <-ctx.Done():
				return
			}
		} else if !ok {
			m.log.Debug("interface counters unavailable", "iface", m.device)
		}
		prevCounters, prevOK, prevAt = cur, ok, at
	}
}

// delta переводит разницу кумулятивных счётчиков в скорости и объёмы за интервал.
func (m *loadMonitor) delta(a, b netstat.Counters, from, to, bucket time.Time) api.IfaceLoad {
	secs := to.Sub(from).Seconds()
	if secs <= 0 {
		secs = float64(m.mon.IntervalSec)
	}
	speed := m.mon.SpeedBits
	if speed == 0 {
		speed = netstat.SpeedBits(m.device)
	}

	rxBytes := diff(a.RxBytes, b.RxBytes)
	txBytes := diff(a.TxBytes, b.TxBytes)
	load := api.IfaceLoad{
		Interface: m.mon.Interface,
		TS:        bucket,
		Seconds:   m.mon.IntervalSec,
		SpeedBits: speed,
		RxBytes:   rxBytes,
		TxBytes:   txBytes,
		RxPackets: diff(a.RxPackets, b.RxPackets),
		TxPackets: diff(a.TxPackets, b.TxPackets),
		RxBps:     float64(rxBytes) * 8 / secs,
		TxBps:     float64(txBytes) * 8 / secs,
		RxPps:     float64(diff(a.RxPackets, b.RxPackets)) / secs,
		TxPps:     float64(diff(a.TxPackets, b.TxPackets)) / secs,
		RxErrors:  diff(a.RxErrors, b.RxErrors),
		TxErrors:  diff(a.TxErrors, b.TxErrors),
		RxDrops:   diff(a.RxDrops, b.RxDrops),
		TxDrops:   diff(a.TxDrops, b.TxDrops),
	}
	if speed > 0 {
		rx := load.RxBps * 100 / float64(speed)
		tx := load.TxBps * 100 / float64(speed)
		load.RxUtilPct, load.TxUtilPct = &rx, &tx
	}
	return load
}

// diff — разница кумулятивных счётчиков. Отрицательное значение означает перезапуск
// интерфейса или обнуление счётчиков ядром: такой интервал не искажаем нулём.
func diff(prev, cur int64) int64 {
	if cur >= prev {
		return cur - prev
	}
	return 0
}
