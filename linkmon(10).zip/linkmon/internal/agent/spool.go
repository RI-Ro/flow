package agent

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/example/linkmon/internal/api"
)

// Spool — журнал неподтверждённых батчей на диске: один батч — один файл.
// Файл удаляется только после Ack сервера, который шлётся после COMMIT в PostgreSQL.
// Номер батча монотонен и переживает рестарты: сервер дедуплицирует по (agent_id, batch_seq).
type Spool struct {
	dir      string
	maxBytes int64
	log      *slog.Logger
	mu       sync.Mutex
	next     uint64
}

func OpenSpool(dir string, maxMB int, log *slog.Logger) (*Spool, error) {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	s := &Spool{dir: dir, maxBytes: int64(maxMB) << 20, log: log, next: 1}
	if b, err := os.ReadFile(filepath.Join(dir, "seq")); err == nil {
		if v, err := strconv.ParseUint(strings.TrimSpace(string(b)), 10, 64); err == nil {
			s.next = v
		}
	}
	seqs, err := s.Pending()
	if err != nil {
		return nil, err
	}
	for _, q := range seqs {
		if q >= s.next {
			s.next = q + 1
		}
	}
	return s, nil
}

func fileName(seq uint64) string { return fmt.Sprintf("%020d.json", seq) }

func (s *Spool) Put(iv []api.Interval, loads []api.IfaceLoad) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	seq := s.next
	data, err := json.Marshal(api.ResultBatch{Seq: seq, Intervals: iv, IfaceLoads: loads})
	if err != nil {
		return err
	}
	if err := writeFileAtomic(filepath.Join(s.dir, fileName(seq)), data, 0o600); err != nil {
		return err
	}
	s.next++
	if err := writeFileAtomic(filepath.Join(s.dir, "seq"), []byte(strconv.FormatUint(s.next, 10)), 0o600); err != nil {
		return err
	}
	s.enforceLimit()
	return nil
}

// Pending возвращает номера неподтверждённых батчей по возрастанию.
func (s *Spool) Pending() ([]uint64, error) {
	entries, err := os.ReadDir(s.dir) // уже отсортировано по имени, имена дополнены нулями
	if err != nil {
		return nil, err
	}
	var out []uint64
	for _, e := range entries {
		n := e.Name()
		if e.IsDir() || strings.HasPrefix(n, ".") || !strings.HasSuffix(n, ".json") {
			continue
		}
		if v, err := strconv.ParseUint(strings.TrimSuffix(n, ".json"), 10, 64); err == nil {
			out = append(out, v)
		}
	}
	return out, nil
}

func (s *Spool) Load(seq uint64) (api.ResultBatch, error) {
	var b api.ResultBatch
	data, err := os.ReadFile(filepath.Join(s.dir, fileName(seq)))
	if err != nil {
		return b, err
	}
	err = json.Unmarshal(data, &b)
	return b, err
}

func (s *Spool) Remove(seq uint64) error {
	err := os.Remove(filepath.Join(s.dir, fileName(seq)))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

func (s *Spool) Count() int {
	seqs, _ := s.Pending()
	return len(seqs)
}

// PruneOlderThan удаляет батчи, чьё время создания (mtime файла) старше d.
// Возвращает число удалённых. Используется для ограничения срока хранения на агенте.
func (s *Spool) PruneOlderThan(d time.Duration) int {
	s.mu.Lock()
	defer s.mu.Unlock()
	entries, err := os.ReadDir(s.dir)
	if err != nil {
		return 0
	}
	cutoff := time.Now().Add(-d)
	dropped := 0
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".json") || strings.HasPrefix(e.Name(), ".") {
			continue
		}
		fi, err := e.Info()
		if err != nil || !fi.ModTime().Before(cutoff) {
			continue
		}
		if os.Remove(filepath.Join(s.dir, e.Name())) == nil {
			dropped++
		}
	}
	return dropped
}

// enforceLimit удаляет самые старые батчи при переполнении.
// TODO: вместо удаления прореживать минутные записи в 5-минутные.
func (s *Spool) enforceLimit() {
	entries, err := os.ReadDir(s.dir)
	if err != nil {
		return
	}
	var total int64
	var files []os.DirEntry
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".json") && !strings.HasPrefix(e.Name(), ".") {
			if fi, err := e.Info(); err == nil {
				total += fi.Size()
				files = append(files, e)
			}
		}
	}
	dropped := 0
	for i := 0; total > s.maxBytes && i < len(files)-1; i++ {
		fi, err := files[i].Info()
		if err != nil {
			continue
		}
		if os.Remove(filepath.Join(s.dir, files[i].Name())) == nil {
			total -= fi.Size()
			dropped++
		}
	}
	if dropped > 0 {
		s.log.Warn("spool limit exceeded, oldest batches dropped", "dropped", dropped)
	}
}

// writeFileAtomic: tmp → fsync → rename → fsync каталога. Переживает внезапное отключение питания.
func writeFileAtomic(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	tmp := filepath.Join(dir, "."+filepath.Base(path)+".tmp")
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, perm)
	if err != nil {
		return err
	}
	if _, err := f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		return err
	}
	d, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer d.Close()
	return d.Sync()
}
