import React, { useState } from "react";
import { Trash2, Plus, X, Users as UsersIcon, Calendar as CalendarIcon } from "lucide-react";
import { PRIORITIES, fmtDate, resolveUser, TASK_COLORS, taskColorFill } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, inputStyle } from "../lib/ui.jsx";

const today = () => new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10);

const emptyTask = (columnId) => ({
  title: "", description: "", priority: "normal", color: "none",
  incomingNumber: "", incomingDate: "",
  columnId, dueDate: today(), assignees: [], tags: [], steps: [],
  recurFreq: "none", recurInterval: 1, recurWeekdays: [], recurMonthday: null, recurUntil: null,
});

export default function TaskModal({ theme, directory, team, boardMemberIds, currentUser, columns, initial, onClose, onSave, onRequestDelete, busy }) {
  const [form, setForm] = useState(() => ({
    ...emptyTask(columns[0]?.id),
    ...(initial || {}),
    dueDate: initial?.dueDate || today(),
    recurFreq: initial?.recurFreq || "none",
    recurInterval: initial?.recurInterval || 1,
    recurWeekdays: initial?.recurWeekdays || [],
    recurMonthday: initial?.recurMonthday ?? null,
    recurUntil: initial?.recurUntil || null,
  }));
  const [tagText, setTagText] = useState((initial?.tags || []).join(", "));
  const [error, setError] = useState("");

  const isEdit = Boolean(initial?.id);
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  // Список кандидатов — объединение личной команды, участников проекта
  // и тех, кто уже назначен. Иначе возникала тихая потеря данных:
  // форма отправляет полный список исполнителей, а видел редактор
  // только свою личную команду — все назначенные владельцем люди, не
  // входящие в неё, просто не попадали в отправляемый список и
  // снимались с задачи при первом же сохранении.
  const candidateIds = [...new Set([
    ...team,
    ...(boardMemberIds || []),
    ...(initial?.assignees || []),
  ])];
  // Себя в списке исполнителей не показываем (п.2): назначить задачу
  // самому себе через этот список нельзя. Уже назначенного ранее себя
  // (из initial) тоже убираем — снятие делается тем же тумблером, но
  // отдельной строкой быть не должно.
  const candidates = candidateIds
    .filter((id) => id !== currentUser?.id)
    .map((id) => resolveUser(directory, id));

  // Назначенные, которых нет ни в личной команде, ни в проекте —
  // помечаем, чтобы снятие было осознанным действием, а не случайным.
  const outsideMyTeam = new Set(
    (initial?.assignees || []).filter((id) => !team.includes(id))
  );

  const toggleAssignee = (id) =>
    set("assignees", form.assignees.includes(id) ? form.assignees.filter((a) => a !== id) : [...form.assignees, id]);

  const submit = () => {
    if (!form.title.trim()) return setError("Укажите название задачи");
    if (!form.columnId) return setError("Выберите колонку");
    // Приоритет «установлен срок» без даты теряет смысл — он именно про
    // то, что дата назначена.
    if (form.priority === "dated" && !form.dueDate) {
      return setError("Для приоритета «Установлен срок» укажите срок исполнения");
    }
    onSave({
      ...form,
      title: form.title.trim(),
      tags: tagText.split(",").map((t) => t.trim().replace(/^#/, "")).filter(Boolean),
      // Чек-лист уходит только при создании: у существующей задачи он
      // правится в самой карточке, отдельными запросами со своими
      // правами, и повторно слать его отсюда нельзя.
      steps: isEdit ? undefined : (form.steps || []),
    });
  };

  const hasDeletedAssignee = form.assignees.some((id) => resolveUser(directory, id).deleted);

  return (
    // Ширина как у окна просмотра задачи (max-w-3xl): в форме теперь
    // и реквизиты документа, и повторение, и чек-лист — на узком окне
    // всё это превращалось в длинную ленту с прокруткой.
    <Modal theme={theme} onClose={onClose} width="max-w-3xl">
      <ModalHeader theme={theme} title={isEdit ? "Редактировать задачу" : "Новая задача"} onClose={onClose} />

      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()}
          autoFocus style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13.5px] outline-none"
          placeholder="Новая задача" />
      </Field>

      <Field label="Описание" theme={theme}>
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3}
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none resize-none" />
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Входящий №" theme={theme}>
          <input value={form.incomingNumber || ""} onChange={(e) => set("incomingNumber", e.target.value)}
            placeholder="например, 01-15/238" style={inputStyle(theme)}
            className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
        </Field>
        <Field label="Дата документа" theme={theme}>
          <input type="date" value={String(form.incomingDate || "").slice(0, 10)}
            onChange={(e) => set("incomingDate", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Приоритет" theme={theme}>
          <select value={form.priority} onChange={(e) => set("priority", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-lg px-2 py-2 text-[13px] outline-none">
            {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </Field>
        <Field label="Колонка" theme={theme}>
          <select value={form.columnId || ""} onChange={(e) => set("columnId", e.target.value)} style={inputStyle(theme)}
            className="w-full rounded-lg px-2 py-2 text-[13px] outline-none">
            {columns.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
          </select>
        </Field>
      </div>

      <Field label="Срок исполнения" theme={theme}>
        <input type="date" value={String(form.dueDate || "").slice(0, 10)} onChange={(e) => set("dueDate", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <Field label="Повторение" theme={theme}
        hint="Цикличная задача: при завершении автоматически создаётся следующая с новым сроком.">
        <select value={form.recurFreq} onChange={(e) => set("recurFreq", e.target.value)} style={inputStyle(theme)}
          className="w-full rounded-lg px-3 py-2 text-[13px] outline-none">
          <option value="none">Без повторения</option>
          <option value="daily">Ежедневно</option>
          <option value="weekly">Еженедельно</option>
          <option value="monthly">Ежемесячно</option>
        </select>

        {form.recurFreq !== "none" && (
          <div className="mt-2 space-y-2">
            <div className="flex items-center gap-2">
              <span style={{ color: theme.textMuted }} className="text-[12.5px]">Каждые</span>
              <input type="number" min="1" max="99" value={form.recurInterval}
                onChange={(e) => set("recurInterval", Math.max(1, parseInt(e.target.value || "1", 10)))}
                style={inputStyle(theme)} className="w-16 rounded-lg px-2 py-1.5 text-[13px] outline-none" />
              <span style={{ color: theme.textMuted }} className="text-[12.5px]">
                {form.recurFreq === "daily" ? "дн." : form.recurFreq === "weekly" ? "нед." : "мес."}
              </span>
            </div>

            {form.recurFreq === "weekly" && (
              <div className="flex flex-wrap gap-1">
                {["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"].map((d, i) => {
                  const active = (form.recurWeekdays || []).includes(i);
                  return (
                    <button key={i} type="button"
                      onClick={() => set("recurWeekdays", active
                        ? form.recurWeekdays.filter((x) => x !== i)
                        : [...(form.recurWeekdays || []), i].sort((a, b) => a - b))}
                      style={{ background: active ? theme.accent : theme.surfaceAlt, color: active ? theme.accentText : theme.text, border: `1px solid ${theme.border}` }}
                      className="w-9 py-1.5 rounded-lg text-[12px] font-medium">{d}</button>
                  );
                })}
              </div>
            )}

            {form.recurFreq === "monthly" && (
              <div className="flex items-center gap-2">
                <span style={{ color: theme.textMuted }} className="text-[12.5px]">Число месяца</span>
                <input type="number" min="1" max="31" value={form.recurMonthday || ""}
                  placeholder="как у срока"
                  onChange={(e) => set("recurMonthday", e.target.value ? Math.min(31, Math.max(1, parseInt(e.target.value, 10))) : null)}
                  style={inputStyle(theme)} className="w-20 rounded-lg px-2 py-1.5 text-[13px] outline-none" />
              </div>
            )}

            <div className="flex items-center gap-2">
              <span style={{ color: theme.textMuted }} className="text-[12.5px]">До даты (необязательно)</span>
              <input type="date" value={form.recurUntil || ""}
                onChange={(e) => set("recurUntil", e.target.value || null)}
                style={inputStyle(theme)} className="rounded-lg px-2 py-1.5 text-[13px] outline-none" />
            </div>
          </div>
        )}
      </Field>

      <Field label="Исполнители" theme={theme}
        hint={candidates.length === 0 ? "Команда пуста — добавьте сотрудников в разделе «Моя команда»."
          : hasDeletedAssignee ? "Среди исполнителей есть удалённая учётная запись — назначьте замену."
          : outsideMyTeam.size > 0 ? "Отмеченные точкой назначены не из вашей команды — снимайте их осознанно."
          : undefined}>
        <div className="flex flex-wrap gap-1.5">
          {candidates.map((u) => {
            const active = form.assignees.includes(u.id);
            return (
              <button key={u.id} onClick={() => !u.deleted && toggleAssignee(u.id)} disabled={u.deleted}
                style={{ background: active ? theme.accent : theme.surfaceAlt, color: active ? theme.accentText : theme.text, border: `1px solid ${theme.border}`, opacity: u.deleted ? 0.45 : 1 }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px] font-medium max-w-full">
                <Avatar user={u} size={16} theme={theme} />
                {/* Полное имя, а не только первое слово: однофамильцы
                    и просто похожие имена в списке из тридцати человек
                    делают выбор по имени лотереей. */}
                <span className="truncate max-w-[190px]">{u.fullName}</span>
                {u.position && (
                  <span style={{ opacity: 0.7 }} className="text-[10.5px] truncate max-w-[120px] hidden sm:inline">
                    · {u.position}
                  </span>
                )}
                {outsideMyTeam.has(u.id) && (
                  <span title="Назначен не из вашей команды"
                    style={{ background: active ? theme.accentText : theme.warning }}
                    className="w-1 h-1 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </Field>

      <Field label="Цвет карточки" theme={theme}
        hint="Заливка полупрозрачная — карточка остаётся читаемой в любой теме и на любом фоне доски.">
        <div className="flex flex-wrap gap-1.5">
          {TASK_COLORS.map((c) => {
            const fill = taskColorFill(c.id, theme);
            const active = (form.color || "none") === c.id;
            return (
              <button key={c.id} onClick={() => set("color", c.id)} title={c.label}
                style={{
                  background: fill
                    ? `linear-gradient(${fill}, ${fill}), ${theme.surface}`
                    : theme.surfaceAlt,
                  border: `2px solid ${active ? theme.accent : theme.border}`,
                }}
                className="w-8 h-8 rounded-lg flex items-center justify-center">
                {c.id === "none" && (
                  <span style={{ color: theme.textMuted }} className="text-[15px] leading-none">×</span>
                )}
              </button>
            );
          })}
        </div>
      </Field>

      {/* Чек-лист прямо в форме создания (п.1). У существующей задачи
          пункты правятся в её карточке — там у каждого своя проверка
          прав и своя запись в историю, дублировать это в форме
          редактирования незачем. */}
      {!isEdit && (
        <Field label="Чек-лист" theme={theme}
          hint="Пункты будут созданы вместе с задачей. Исполнитель пункта получает доступ к задаче.">
          <NewTaskChecklist theme={theme} candidates={candidates}
            steps={form.steps || []} onChange={(next) => set("steps", next)} />
        </Field>
      )}

      <Field label="Теги через запятую" theme={theme}>
        <input value={tagText} onChange={(e) => setTagText(e.target.value)} style={inputStyle(theme)}
          className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" placeholder="интерфейс, сервер, срочно" />
      </Field>

      {error && <p style={{ color: theme.danger }} className="text-[12.5px] mb-2">{error}</p>}

      <div className="flex items-center gap-2 mt-4">
        <button onClick={submit} disabled={busy} style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13.5px] font-semibold disabled:opacity-50">
          {busy ? "Сохраняем…" : isEdit ? "Сохранить изменения" : "Создать задачу"}
        </button>
        {isEdit && (
          <button onClick={() => onRequestDelete(form.id)} style={{ color: theme.danger, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 py-2.5" title="Удалить задачу">
            <Trash2 size={16} />
          </button>
        )}
      </div>
    </Modal>
  );
}

// Черновик чек-листа для новой задачи. Пункты живут в состоянии формы и
// уходят на сервер вместе с самой задачей — одним запросом, в одной
// транзакции. Отправлять их отдельными вызовами после создания было бы
// проще в коде, но при обрыве связи между запросами пользователь
// получил бы задачу с наполовину заполненным чек-листом и без всякого
// сообщения об этом.
function NewTaskChecklist({ theme, candidates, steps, onChange }) {
  const [draft, setDraft] = useState({ body: "", assigneeId: "", dueDate: "" });

  const add = () => {
    const body = draft.body.trim();
    if (!body) return;
    onChange([...steps, {
      body,
      assigneeId: draft.assigneeId || null,
      dueDate: draft.dueDate || null,
    }]);
    setDraft({ body: "", assigneeId: "", dueDate: "" });
  };

  const removeAt = (i) => onChange(steps.filter((_, idx) => idx !== i));

  return (
    <div>
      {steps.map((s, i) => {
        const u = s.assigneeId ? candidates.find((c) => c.id === s.assigneeId) : null;
        return (
          <div key={i} style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
            className="flex items-start gap-2 rounded-lg px-2.5 py-1.5 mb-1.5">
            <span style={{ borderColor: theme.border }}
              className="w-3.5 h-3.5 rounded border mt-0.5 shrink-0" aria-hidden />
            <div className="flex-1 min-w-0">
              <div style={{ color: theme.text }} className="text-[12.5px] break-words">{s.body}</div>
              {(u || s.dueDate) && (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-0.5">
                  {u && (
                    <span style={{ color: theme.textMuted }} className="text-[11px] flex items-center gap-1">
                      <UsersIcon size={11} />{u.fullName}
                    </span>
                  )}
                  {s.dueDate && (
                    <span style={{ color: theme.textMuted }} className="text-[11px] flex items-center gap-1">
                      <CalendarIcon size={11} />до {fmtDate(s.dueDate)}
                    </span>
                  )}
                </div>
              )}
            </div>
            <button type="button" onClick={() => removeAt(i)} style={{ color: theme.danger }}
              title="Убрать пункт"><X size={13} /></button>
          </div>
        );
      })}

      <div style={{ background: theme.surfaceAlt, border: `1px dashed ${theme.border}` }}
        className="rounded-lg p-2.5">
        <input value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); add(); } }}
          placeholder="Что нужно сделать" style={inputStyle(theme)}
          className="w-full rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none mb-2" />
        <div className="grid grid-cols-2 gap-2">
          <div>
            <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Исполнитель</div>
            <select value={draft.assigneeId} onChange={(e) => setDraft({ ...draft, assigneeId: e.target.value })}
              style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12px] outline-none">
              <option value="">Не назначен</option>
              {candidates.filter((u) => !u.deleted).map((u) => (
                <option key={u.id} value={u.id}>{u.fullName}</option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Срок пункта</div>
            <input type="date" value={draft.dueDate}
              onChange={(e) => setDraft({ ...draft, dueDate: e.target.value })}
              style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12px] outline-none" />
          </div>
        </div>
        <button type="button" onClick={add} disabled={!draft.body.trim()}
          style={{ color: theme.accent }}
          className="mt-2 flex items-center gap-1.5 text-[12.5px] font-medium disabled:opacity-40">
          <Plus size={14} /> Добавить пункт
        </button>
      </div>
    </div>
  );
}
