package handlers

import (
	"context"
	"errors"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Переписка сотрудников: личные и групповые чаты.
//
// Почему отдельно от комментариев к задачам. Комментарий привязан к
// задаче и виден всем, кто видит задачу; переписка — наоборот, видна
// только участникам и живёт независимо от проектов. Смешивать их
// значило бы либо ограничивать разговор рамками задачи, либо открывать
// задачу тому, кому её не давали.
//
// Права целиком на политиках RLS (миграция 0009): участник видит чат и
// сообщения, автор правит и удаляет своё, владелец группового чата
// распоряжается составом. Обработчики ниже добавляют к этому только то,
// что политикой не выражается: рассылку событий и счётчики.

type chatMessage struct {
	ID        uuid.UUID  `json:"id"`
	ChatID    uuid.UUID  `json:"chatId"`
	AuthorID  *uuid.UUID `json:"authorId"`
	Body      string     `json:"body"`
	CreatedAt time.Time  `json:"createdAt"`
	EditedAt  *time.Time `json:"editedAt"`
	Deleted   bool       `json:"deleted"`
	// Файл описывается прямо в сообщении: отдельный запрос за каждым
	// вложением в переписке — это десятки запросов на один экран.
	FileID      *uuid.UUID `json:"fileId"`
	Filename    string     `json:"filename"`
	MIME        string     `json:"mime"`
	Size        int64      `json:"size"`
	Previewable bool       `json:"previewable"`
}

type chatInfo struct {
	ID          uuid.UUID   `json:"id"`
	Kind        string      `json:"kind"`
	Title       string      `json:"title"`
	OwnerID     *uuid.UUID  `json:"ownerId"`
	Members     []uuid.UUID `json:"members"`
	Unread      int         `json:"unread"`
	LastBody    string      `json:"lastBody"`
	LastAt      *time.Time  `json:"lastAt"`
	LastAuthor  *uuid.UUID  `json:"lastAuthorId"`
	UpdatedAt   time.Time   `json:"updatedAt"`
}

const chatMessageCols = `
	m.id, m.chat_id, m.author_id,
	CASE WHEN m.deleted_at IS NULL THEN m.body ELSE '' END,
	m.created_at, m.edited_at, (m.deleted_at IS NOT NULL),
	m.file_id, COALESCE(f.filename, ''), COALESCE(f.mime_type, ''), COALESCE(f.size_bytes, 0)`

func scanChatMessage(row pgx.Row) (chatMessage, error) {
	var m chatMessage
	err := row.Scan(&m.ID, &m.ChatID, &m.AuthorID, &m.Body, &m.CreatedAt,
		&m.EditedAt, &m.Deleted, &m.FileID, &m.Filename, &m.MIME, &m.Size)
	m.Previewable = previewable[m.MIME]
	return m, err
}

// ListChats — список чатов пользователя с последним сообщением и числом
// непрочитанных. Всё одним запросом: список чатов — это экран, который
// открывают часто, и запрос на каждый чат превратил бы его в десятки
// обращений к базе.
func (s *Server) ListChats(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []chatInfo{}

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT c.id, c.kind, c.title, c.owner_id, c.updated_at,
			       COALESCE(array_agg(DISTINCT mem.user_id)
			                FILTER (WHERE mem.user_id IS NOT NULL), '{}'),
			       (SELECT count(*) FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id
			           AND msg.deleted_at IS NULL
			           AND msg.author_id IS DISTINCT FROM $1
			           AND msg.created_at > me.last_read_at),
			       (SELECT CASE WHEN msg.deleted_at IS NOT NULL THEN 'сообщение удалено'
			                    WHEN msg.body <> '' THEN msg.body
			                    ELSE 'файл' END
			          FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id
			         ORDER BY msg.created_at DESC LIMIT 1),
			       (SELECT msg.created_at FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id ORDER BY msg.created_at DESC LIMIT 1),
			       (SELECT msg.author_id FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id ORDER BY msg.created_at DESC LIMIT 1)
			  FROM app.chats c
			  JOIN app.chat_members me  ON me.chat_id = c.id AND me.user_id = $1
			  LEFT JOIN app.chat_members mem ON mem.chat_id = c.id
			 GROUP BY c.id, c.kind, c.title, c.owner_id, c.updated_at, me.last_read_at
			 ORDER BY 9 DESC NULLS LAST, c.updated_at DESC`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var ci chatInfo
			var lastBody *string
			if e := rows.Scan(&ci.ID, &ci.Kind, &ci.Title, &ci.OwnerID, &ci.UpdatedAt,
				&ci.Members, &ci.Unread, &lastBody, &ci.LastAt, &ci.LastAuthor); e != nil {
				return e
			}
			if lastBody != nil {
				ci.LastBody = *lastBody
			}
			out = append(out, ci)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type newChatInput struct {
	Kind    string      `json:"kind"`    // direct | group
	Title   string      `json:"title"`   // только для группового
	UserID  *uuid.UUID  `json:"userId"`  // только для личного
	Members []uuid.UUID `json:"members"` // только для группового
}

// CreateChat создаёт личный или групповой чат.
//
// Личный ищется через app.ensure_direct_chat: нажатие «написать» на
// человеке, с которым переписка уже идёт, должно открывать её, а не
// плодить пустые чаты. Функция же снимает гонку — два одновременных
// нажатия дадут один чат, а не два.
func (s *Server) CreateChat(c *fiber.Ctx) error {
	var in newChatInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var chatID uuid.UUID
	var members []uuid.UUID

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		switch in.Kind {
		case "direct":
			if in.UserID == nil || *in.UserID == uid {
				return httpx.Err(fiber.StatusBadRequest, "bad_user",
					"Выберите собеседника")
			}
			if e := tx.QueryRow(c.Context(),
				`SELECT app.ensure_direct_chat($1, $2)`, uid, *in.UserID).Scan(&chatID); e != nil {
				return e
			}
			members = []uuid.UUID{uid, *in.UserID}

		case "group":
			title := strings.TrimSpace(in.Title)
			if title == "" {
				return httpx.Err(fiber.StatusBadRequest, "no_title",
					"У группового чата должно быть название")
			}
			if e := tx.QueryRow(c.Context(), `
				INSERT INTO app.chats (kind, title, owner_id)
				VALUES ('group', $1, $2) RETURNING id`, title, uid).Scan(&chatID); e != nil {
				return e
			}
			// Владелец всегда участник: чат, которым нельзя
			// пользоваться, но можно переименовывать — бессмыслица.
			seen := map[uuid.UUID]bool{uid: true}
			members = []uuid.UUID{uid}
			for _, m := range in.Members {
				if m == uuid.Nil || seen[m] {
					continue
				}
				seen[m] = true
				members = append(members, m)
			}
			for _, m := range members {
				if _, e := tx.Exec(c.Context(),
					`INSERT INTO app.chat_members (chat_id, user_id) VALUES ($1, $2)
					 ON CONFLICT DO NOTHING`, chatID, m); e != nil {
					return e
				}
			}

		default:
			return httpx.Err(fiber.StatusBadRequest, "bad_kind",
				"Чат бывает личным или групповым")
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	go s.publishChat(members, chatID, "created")
	return httpx.JSON(c, fiber.StatusCreated, fiber.Map{"id": chatID})
}

type chatTitleInput struct {
	Title string `json:"title"`
}

func (s *Server) RenameChat(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chatTitleInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	title := strings.TrimSpace(in.Title)
	if title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_title",
			"Название не может быть пустым"))
	}
	uid := s.uid(c)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET title = $2, updated_at = now() WHERE id = $1`, chatID, title)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			// Политика chats_update пропускает только владельца
			// группового чата.
			return httpx.Err(fiber.StatusForbidden, "not_owner",
				"Переименовать чат может только его владелец")
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(s.chatMembers(c.Context(), chatID), chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID, "title": title})
}

type chatMemberInput struct {
	UserID uuid.UUID `json:"userId"`
}

func (s *Server) AddChatMember(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chatMemberInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var kind string
		if e := tx.QueryRow(c.Context(),
			`SELECT kind FROM app.chats WHERE id = $1`, chatID).Scan(&kind); e != nil {
			return e
		}
		if kind != "group" {
			return httpx.Err(fiber.StatusBadRequest, "not_group",
				"Участников можно добавлять только в групповой чат")
		}
		_, e := tx.Exec(c.Context(),
			`INSERT INTO app.chat_members (chat_id, user_id) VALUES ($1, $2)
			 ON CONFLICT DO NOTHING`, chatID, in.UserID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(s.chatMembers(c.Context(), chatID), chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

func (s *Server) RemoveChatMember(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	userID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	// Состав до удаления: тому, кого убрали, тоже нужно событие — иначе
	// чат останется у него на экране до перезагрузки.
	before := s.chatMembers(c.Context(), chatID)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var owner *uuid.UUID
		if e := tx.QueryRow(c.Context(),
			`SELECT owner_id FROM app.chats WHERE id = $1`, chatID).Scan(&owner); e != nil {
			return e
		}
		if owner != nil && *owner == userID {
			return httpx.Err(fiber.StatusBadRequest, "owner_stays",
				"Владельца нельзя убрать из чата")
		}
		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.chat_members WHERE chat_id = $1 AND user_id = $2`, chatID, userID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(before, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// ListMessages отдаёт переписку. Необязательный q — поиск внутри чата;
// он идёт по телу и по именам файлов, потому что «где-то тут был файл с
// актом» — такой же законный способ искать, как и по словам.
func (s *Server) ListMessages(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	q := strings.TrimSpace(c.Query("q"))

	out := []chatMessage{}
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.chat_id = $1
			   AND ($2 = '' OR m.body ILIKE '%' || $2 || '%'
			                OR COALESCE(f.filename, '') ILIKE '%' || $2 || '%')
			 ORDER BY m.created_at DESC
			 LIMIT 300`, chatID, q)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			m, e := scanChatMessage(rows)
			if e != nil {
				return e
			}
			out = append(out, m)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	// Клиенту удобнее по возрастанию: так читают переписку. Выбираем с
	// конца, потому что нужны последние, а не первые триста.
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type messageInput struct {
	Body   string     `json:"body"`
	FileID *uuid.UUID `json:"fileId"`
}

func (s *Server) SendMessage(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in messageInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" && in.FileID == nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty",
			"Пустое сообщение отправить нельзя"))
	}
	uid := s.uid(c)

	var m chatMessage
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var id uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chat_messages (chat_id, author_id, body, file_id)
			VALUES ($1, $2, $3, $4) RETURNING id`, chatID, uid, body, in.FileID).Scan(&id); e != nil {
			return e
		}
		// Время чата двигается вместе с сообщением: список чатов
		// сортируется по нему, и без этого свежая переписка оставалась
		// бы внизу.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET updated_at = now() WHERE id = $1`, chatID); e != nil {
			return e
		}
		// Своё сообщение прочитано по определению.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		row := tx.QueryRow(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, id)
		var e error
		m, e = scanChatMessage(row)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishMessage(s.chatMembers(c.Context(), chatID), m, "created")
	return httpx.JSON(c, fiber.StatusCreated, m)
}

// UploadChatFile принимает файл и сразу отправляет его сообщением:
// загрузка без отправки оставила бы в базе файл, на который никто не
// ссылается, и чистить такие пришлось бы отдельной задачей.
func (s *Server) UploadChatFile(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	file, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer file.Close()

	stored, err := s.files.Save(file, header.Filename)
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", err.Error()))
	}

	caption := strings.TrimSpace(c.FormValue("body"))

	var m chatMessage
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var fileID uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
			VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
			uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).
			Scan(&fileID); e != nil {
			return e
		}
		var id uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chat_messages (chat_id, author_id, body, file_id)
			VALUES ($1, $2, $3, $4) RETURNING id`,
			chatID, uid, caption, fileID).Scan(&id); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET updated_at = now() WHERE id = $1`, chatID); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		row := tx.QueryRow(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, id)
		var e error
		m, e = scanChatMessage(row)
		return e
	})
	if err != nil {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, err)
	}
	go s.publishMessage(s.chatMembers(c.Context(), chatID), m, "created")
	return httpx.JSON(c, fiber.StatusCreated, m)
}

// DownloadChatFile отдаёт содержимое файла из переписки. Права — на
// политике files_select_chat: участник чата видит файл, остальные нет.
func (s *Server) DownloadChatFile(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var key, filename, mime string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.filename, f.mime_type
			  FROM app.chat_messages m
			  JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, msgID).Scan(&key, &filename, &mime)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mime, filename, c.Query("download") == "1")
}

func (s *Server) EditMessage(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in messageInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty",
			"Текст сообщения не может быть пустым. Чтобы убрать его, удалите сообщение"))
	}
	uid := s.uid(c)

	var m chatMessage
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			WITH upd AS (
				UPDATE app.chat_messages
				   SET body = $2, edited_at = now()
				 WHERE id = $1 AND deleted_at IS NULL
				 RETURNING id
			)
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  JOIN upd ON upd.id = m.id
			  LEFT JOIN app.files f ON f.id = m.file_id`, msgID, body)
		var e error
		m, e = scanChatMessage(row)
		return e
	})
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_author",
				"Править сообщение может только его автор"))
		}
		return httpx.Fail(c, err)
	}
	go s.publishMessage(s.chatMembers(c.Context(), m.ChatID), m, "updated")
	return httpx.JSON(c, fiber.StatusOK, m)
}

// DeleteMessage удаляет мягко: в переписке важно, что сообщение было.
// Тело очищается, на месте остаётся «сообщение удалено».
func (s *Server) DeleteMessage(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var m chatMessage
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			WITH upd AS (
				UPDATE app.chat_messages
				   SET deleted_at = now(), body = '', file_id = NULL
				 WHERE id = $1
				 RETURNING id
			)
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  JOIN upd ON upd.id = m.id
			  LEFT JOIN app.files f ON f.id = m.file_id`, msgID)
		var e error
		m, e = scanChatMessage(row)
		return e
	})
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_author",
				"Удалить сообщение может только его автор"))
		}
		return httpx.Fail(c, err)
	}
	go s.publishMessage(s.chatMembers(c.Context(), m.ChatID), m, "deleted")
	return httpx.JSON(c, fiber.StatusOK, m)
}

// MarkChatRead сдвигает отметку прочтения. Отдельным вызовом, а не при
// загрузке сообщений: список открывают и чтобы просто найти в нём файл,
// а прочитанным чат становится, когда человек в него зашёл.
func (s *Server) MarkChatRead(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var total int
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(),
			`SELECT app.chat_unread_total($1)`, uid).Scan(&total)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"chatId": chatID, "unreadTotal": total})
}

// chatMembers — состав чата для рассылки событий.
//
// Через app.chat_watchers, а не прямым запросом к таблице: AsService
// выполняется без пользовательского контекста и под RLS не видит
// ни одной строки chat_members. Прямой SELECT здесь молча возвращал
// пустой список — и события переписки не уходили никому.
func (s *Server) chatMembers(ctx context.Context, chatID uuid.UUID) []uuid.UUID {
	var ids []uuid.UUID
	_ = s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.chat_watchers($1)`, chatID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	return ids
}
