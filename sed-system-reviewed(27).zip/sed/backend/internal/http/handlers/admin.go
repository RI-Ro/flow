package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
)

type AdminHandler struct {
	pool *pgxpool.Pool
	svc  *service.AdminService
}

func NewAdminHandler(pool *pgxpool.Pool, svc *service.AdminService) *AdminHandler {
	return &AdminHandler{pool: pool, svc: svc}
}

// ctx извлекает userID/isAdmin и проверяет права администратора.
func (h *AdminHandler) ctx(c *fiber.Ctx) (int64, bool, error) {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	if !isAdmin {
		return 0, false, fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return userID, isAdmin, nil
}

func mapAdminErr(err error) error {
	switch {
	case errors.Is(err, service.ErrDeptHasChildren), errors.Is(err, service.ErrDeptHasUsers), errors.Is(err, service.ErrCycle):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, service.ErrLoginTaken), errors.Is(err, service.ErrPrefixTaken):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, pgx.ErrNoRows):
		return fiber.NewError(fiber.StatusNotFound, "не найдено")
	default:
		return fiber.NewError(fiber.StatusInternalServerError, "внутренняя ошибка")
	}
}

// ---------------- Departments ----------------

// ListDepartments GET /api/admin/departments — плоский список для построения дерева.
func (h *AdminHandler) ListDepartments(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	type dept struct {
		ID              int64   `json:"id"`
		ParentID        *int64  `json:"parent_id"`
		Name            string  `json:"name"`
		OutgoingPrefix  string  `json:"outgoing_prefix"`
		NumberingPrefix string  `json:"numbering_prefix"`
		IsActive        bool    `json:"is_active"`
		UserCount       int     `json:"user_count"`
	}
	var out []dept
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT d.id, d.parent_id, d.name, d.outgoing_prefix, coalesce(d.numbering_prefix,''), d.is_active,
			       (SELECT count(*) FROM users u WHERE u.primary_department_id = d.id)
			FROM departments d
			ORDER BY d.parent_id NULLS FIRST, d.name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var d dept
			if err := rows.Scan(&d.ID, &d.ParentID, &d.Name, &d.OutgoingPrefix, &d.NumberingPrefix, &d.IsActive, &d.UserCount); err != nil {
				return err
			}
			out = append(out, d)
		}
		return rows.Err()
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.JSON(fiber.Map{"departments": out})
}

func (h *AdminHandler) CreateDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	var req struct {
		Name            string `json:"name"`
		OutgoingPrefix  string `json:"outgoing_prefix"`
		NumberingPrefix string `json:"numbering_prefix"`
		ParentID        int64  `json:"parent_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.Name == "" || req.OutgoingPrefix == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название и outgoing_prefix")
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var e error
		id, e = h.svc.CreateDepartment(c.Context(), tx, req.Name, req.OutgoingPrefix, req.NumberingPrefix, req.ParentID)
		return e
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

func (h *AdminHandler) UpdateDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Name            string `json:"name"`
		OutgoingPrefix  string `json:"outgoing_prefix"`
		NumberingPrefix string `json:"numbering_prefix"`
		IsActive        bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.UpdateDepartment(c.Context(), tx, id, req.Name, req.OutgoingPrefix, req.NumberingPrefix, req.IsActive)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// MoveDepartment PATCH /api/admin/departments/:id/parent — перенос (drag-drop).
func (h *AdminHandler) MoveDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		ParentID int64 `json:"parent_id"` // 0 => корень
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.MoveDepartment(c.Context(), tx, id, req.ParentID)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

func (h *AdminHandler) DeleteDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.DeleteDepartment(c.Context(), tx, id)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// ---------------- Users ----------------

// ListUsers GET /api/admin/users — все пользователи с ролями и подразделением.
func (h *AdminHandler) ListUsers(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	type usr struct {
		ID              int64    `json:"id"`
		Login           string   `json:"login"`
		FullName        string   `json:"full_name"`
		Position        string   `json:"position"`
		DepartmentID    *int64   `json:"department_id"`
		NumberingDeptID *int64   `json:"numbering_department_id"`
		IsActive        bool     `json:"is_active"`
		Roles           []string `json:"roles"`
		Visible         []int64  `json:"visible_departments"`
		Acquaint        []int64  `json:"acquaint_departments"`
		Assign          []int64  `json:"assign_departments"`
	}
	var out []usr
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, u.login, u.full_name, coalesce(u.position,''), u.primary_department_id,
			       u.numbering_department_id, u.is_active,
			       coalesce(array_agg(DISTINCT ur.role::text) FILTER (WHERE ur.role IS NOT NULL), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_visible_departments  x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_acquaint_departments x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_assign_departments   x WHERE x.user_id=u.id), '{}')
			FROM users u
			LEFT JOIN user_roles ur ON ur.user_id = u.id
			GROUP BY u.id
			ORDER BY u.full_name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var u usr
			if err := rows.Scan(&u.ID, &u.Login, &u.FullName, &u.Position, &u.DepartmentID,
				&u.NumberingDeptID, &u.IsActive,
				&u.Roles, &u.Visible, &u.Acquaint, &u.Assign); err != nil {
				return err
			}
			out = append(out, u)
		}
		return rows.Err()
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.JSON(fiber.Map{"users": out})
}

func (h *AdminHandler) CreateUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	var req struct {
		Login        string `json:"login"`
		Password     string `json:"password"`
		FullName     string `json:"full_name"`
		Position     string `json:"position"`
		DepartmentID int64  `json:"department_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.Login == "" || req.Password == "" || req.FullName == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите логин, пароль и ФИО")
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var e error
		id, e = h.svc.CreateUser(c.Context(), tx, req.Login, req.Password, req.FullName, req.Position, req.DepartmentID)
		return e
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

func (h *AdminHandler) UpdateUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Login           string `json:"login"`
		FullName        string `json:"full_name"`
		Position        string `json:"position"`
		DepartmentID    int64  `json:"department_id"`
		NumberingDeptID int64  `json:"numbering_department_id"`
		IsActive        bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.UpdateUser(c.Context(), tx, id, req.Login, req.FullName, req.Position,
			req.DepartmentID, req.NumberingDeptID, req.IsActive)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// MoveUser PATCH /api/admin/users/:id/department — перенос (drag-drop).
func (h *AdminHandler) MoveUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		DepartmentID int64 `json:"department_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.MoveUser(c.Context(), tx, id, req.DepartmentID)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// SetUserDepartments PATCH /api/admin/users/:id/departments — заменяет наборы
// доп. подразделений (видимость исходящих / ознакомление / поручения).
func (h *AdminHandler) SetUserDepartments(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Visible  []int64 `json:"visible_departments"`
		Acquaint []int64 `json:"acquaint_departments"`
		Assign   []int64 `json:"assign_departments"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if e := h.svc.SetUserDepartmentSet(c.Context(), tx, "user_visible_departments", id, req.Visible); e != nil {
			return e
		}
		if e := h.svc.SetUserDepartmentSet(c.Context(), tx, "user_acquaint_departments", id, req.Acquaint); e != nil {
			return e
		}
		return h.svc.SetUserDepartmentSet(c.Context(), tx, "user_assign_departments", id, req.Assign)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

func (h *AdminHandler) SetUserPassword(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Password string `json:"password"`
	}
	if err := c.BodyParser(&req); err != nil || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите пароль")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.SetPassword(c.Context(), tx, id, req.Password)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// SetUserRoles PATCH /api/admin/users/:id/roles — заменить роли пользователя
// в подразделении (department_id=0 => глобальные, напр. admin).
func (h *AdminHandler) SetUserRoles(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		DepartmentID int64    `json:"department_id"`
		Roles        []string `json:"roles"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.SetRoles(c.Context(), tx, id, req.DepartmentID, req.Roles)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}
