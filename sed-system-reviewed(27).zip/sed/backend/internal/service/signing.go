package service

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)

type SigningService struct {
	numbering *NumberingService
}

func NewSigningService(numbering *NumberingService) *SigningService {
	return &SigningService{numbering: numbering}
}

// Sign выполняется, когда согласующий этапа stage_type='signing' подтверждает
// решение (см. handlers.ApprovalHandler.Decide) — это и есть момент
// подписания. Присваивает исходящий номер атомарно (см. NumberingService),
// пишет маркировку в document_signatures и переводит статус в 'signed'.
// Номер выдаётся ЗДЕСЬ, а не при создании документа — иначе удалённые/
// отклонённые черновики оставляли бы дыры в нумерации.
func (s *SigningService) Sign(ctx context.Context, tx pgx.Tx, documentID, signerID int64, signatureType string) (string, []int64, error) {
	var authorDepartmentID int64
	var authorNumberingDeptID *int64
	err := tx.QueryRow(ctx, `
		SELECT d.author_department_id, au.numbering_department_id
		FROM documents d
		JOIN users au ON au.id = d.author_id
		WHERE d.id = $1`, documentID).Scan(&authorDepartmentID, &authorNumberingDeptID)
	if err != nil {
		return "", nil, fmt.Errorf("lookup document/author: %w", err)
	}
	// Номер регистрируется по подразделению АВТОРА документа (по ТЗ), а не
	// подписанта. Берём numbering_department_id автора, если задан, иначе —
	// основное подразделение автора.
	deptForNumbering := authorDepartmentID
	if authorNumberingDeptID != nil && *authorNumberingDeptID != 0 {
		deptForNumbering = *authorNumberingDeptID
	}

	// Присвоение номера обёрнуто в SAVEPOINT с ретраем на UNIQUE-конфликт.
	// В норме NextOutgoing гарантирует уникальность (department_id, year,
	// seq_type — атомарный счётчик + pathPrefix уникален на подразделение).
	// Но numbering_prefix теперь редактируется вручную через консоль
	// администрирования и НЕ имеет UNIQUE-ограничения в БД — если админ по
	// ошибке присвоит одинаковый numbering_prefix двум подразделениям, номера
	// могут совпасть. Вместо падения всей подписи — перевыпускаем номер
	// (счётчик уже продвинут, следующий вызов даст новое значение) и пробуем
	// снова, до 5 попыток.
	const maxAttempts = 5
	var outgoingNumber string
	for attempt := 1; ; attempt++ {
		if _, err = tx.Exec(ctx, `SAVEPOINT sp_outgoing_number`); err != nil {
			return "", nil, fmt.Errorf("savepoint: %w", err)
		}
		outgoingNumber, err = s.numbering.NextOutgoing(ctx, tx, deptForNumbering)
		if err == nil {
			_, err = tx.Exec(ctx, `UPDATE documents SET status = 'signed', outgoing_number = $1 WHERE id = $2`, outgoingNumber, documentID)
		}
		if err == nil {
			if _, relErr := tx.Exec(ctx, `RELEASE SAVEPOINT sp_outgoing_number`); relErr != nil {
				return "", nil, fmt.Errorf("release savepoint: %w", relErr)
			}
			break
		}
		if !isUniqueViolation(err) || attempt >= maxAttempts {
			return "", nil, fmt.Errorf("assign outgoing number (attempt %d): %w", attempt, err)
		}
		if _, rbErr := tx.Exec(ctx, `ROLLBACK TO SAVEPOINT sp_outgoing_number`); rbErr != nil {
			return "", nil, fmt.Errorf("rollback savepoint: %w", rbErr)
		}
		// коллизия номера — повторяем с новым значением счётчика
	}

	// Хэш подписи — здесь упрощённо детерминированный отпечаток факта
	// подписания (документ+подписант+время+номер). Для юридически значимой
	// ПЭП/УНЭП это место интеграции с реальным крипто-провайдером/УЦ —
	// намеренно не изображаю это как настоящую криптографию.
	fingerprint := fmt.Sprintf("%d|%d|%s|%s", documentID, signerID, outgoingNumber, time.Now().UTC().Format(time.RFC3339Nano))
	sum := sha256.Sum256([]byte(fingerprint))
	signatureHash := hex.EncodeToString(sum[:])

	storageResource := fmt.Sprintf("СЭД / Архив %d / %s", time.Now().Year(), outgoingNumber)

	// Снимок ФИО и должности подписанта на момент подписи.
	var signerFIO, signerPos string
	if err := tx.QueryRow(ctx, `SELECT coalesce(full_name,''), coalesce(position,'') FROM users WHERE id=$1`, signerID).Scan(&signerFIO, &signerPos); err != nil {
		return "", nil, fmt.Errorf("lookup signer snapshot: %w", err)
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_signatures (document_id, signer_id, signature_type, signature_hash, storage_resource, signer_fio, signer_position)
		VALUES ($1, $2, $3, $4, $5, $6, $7)`, documentID, signerID, signatureType, signatureHash, storageResource, signerFIO, signerPos)
	if err != nil {
		return "", nil, fmt.Errorf("insert signature: %w", err)
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, to_status, comment)
		VALUES ($1, $2, 'signed', 'signed', $3)`, documentID, signerID, outgoingNumber)
	if err != nil {
		return "", nil, fmt.Errorf("insert history: %w", err)
	}

	// Уведомляем автора документа о подписании (важное событие). Автор может
	// не совпадать с подписантом, поэтому шлём отдельное уведомление.
	_, err = tx.Exec(ctx, `
		INSERT INTO notifications (user_id, document_id, kind, payload)
		SELECT author_id, $1, 'document_signed', '{}'
		FROM documents WHERE id = $1 AND author_id <> $2`, documentID, signerID)
	if err != nil {
		return "", nil, fmt.Errorf("notify author on sign: %w", err)
	}

	// Активируем плановых получателей (выбранных при создании): выдаём им
	// доступ к документу и уведомляем. До подписания они не видели документ.
	planned, err := tx.Query(ctx, `
		SELECT recipient_user_id FROM document_recipients
		WHERE document_id = $1 AND is_planned = true`, documentID)
	if err != nil {
		return "", nil, fmt.Errorf("load planned recipients: %w", err)
	}
	var plannedIDs []int64
	for planned.Next() {
		var uid int64
		if err := planned.Scan(&uid); err != nil {
			planned.Close()
			return "", nil, err
		}
		plannedIDs = append(plannedIDs, uid)
	}
	planned.Close()
	for _, uid := range plannedIDs {
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_access (document_id, user_id, access_reason)
			VALUES ($1, $2, 'recipient') ON CONFLICT DO NOTHING`, documentID, uid); err != nil {
			return "", nil, err
		}
		// Номер экземпляра получателю здесь НЕ выдаём — он присваивается только
		// когда получатель РЕАЛЬНО откроет документ (присвоение при первом
		// просмотре в Get). Иначе номер «зависал» бы за исключённым из рассылки.
		if _, err := tx.Exec(ctx, `
			INSERT INTO notifications (user_id, document_id, kind, payload)
			VALUES ($1, $2, 'document_sent', '{}')`, uid, documentID); err != nil {
			return "", nil, err
		}
	}
	// Снимаем флаг планового — теперь они обычные активные получатели.
	if _, err := tx.Exec(ctx, `
		UPDATE document_recipients SET is_planned = false
		WHERE document_id = $1 AND is_planned = true`, documentID); err != nil {
		return "", nil, err
	}

	// СЕМАНТИКА signed/sent: если при создании была задана плановая рассылка,
	// то подпись = автоматическое направление. Переводим в 'sent' и пишем
	// событие истории — иначе документ «завис» бы в 'signed', хотя адресаты
	// уже уведомлены. Если плановых не было — остаёмся в 'signed' (ждём ручного
	// «Направить» с выбором адресатов).
	if len(plannedIDs) > 0 {
		if _, err := tx.Exec(ctx, `UPDATE documents SET status = 'sent' WHERE id = $1`, documentID); err != nil {
			return "", nil, fmt.Errorf("auto-send after sign: %w", err)
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'sent', 'signed', 'sent', 'автоматически направлен плановым адресатам')`, documentID, signerID); err != nil {
			return "", nil, fmt.Errorf("insert sent history: %w", err)
		}
	}

	return outgoingNumber, plannedIDs, nil
}
