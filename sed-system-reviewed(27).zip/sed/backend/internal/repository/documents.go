package repository

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
	"sed-system/backend/internal/domain"
)

type DocumentsRepo struct{}

func NewDocumentsRepo() *DocumentsRepo { return &DocumentsRepo{} }

// Category соответствует вкладкам в UI: исходящие/входящие/на согласовании/
// на подписи/исполнено/архив. RLS (document_access) уже ограничивает набор
// строк, доступных пользователю в текущей транзакции — здесь остаётся
// только фильтрация по статусу/направлению и пагинация.
type Category string

const (
	CategoryOutgoing   Category = "outgoing"
	CategoryIncoming   Category = "incoming"
	CategoryOnApproval Category = "on_approval"
	CategoryOnSigning  Category = "on_signing"
	CategoryExecuted   Category = "executed"
	CategoryArchive    Category = "archive"
	CategoryControl    Category = "control"
	CategoryPrintUnreg Category = "print_unregistered"
	CategoryAll        Category = "all"
)

var categoryStatusFilter = map[Category][]domain.Status{
	CategoryOnApproval: {domain.StatusOnApprovalHierarchy, domain.StatusOnApprovalCrossDept},
	CategoryOnSigning:  {domain.StatusOnSigning},
	CategoryExecuted:   {domain.StatusExecuted},
	CategoryArchive:    {domain.StatusArchived},
}

// List возвращает страницу документов доступных текущему пользователю
// (ограничение уже применено RLS-политикой внутри переданной tx).
// Использует композитный индекс idx_documents_status_created для
// категорий, ограниченных по статусу, либо idx_documents_dept_created
// для "исходящие"/"входящие" (см. ветвление ниже).
func (r *DocumentsRepo) List(ctx context.Context, tx pgx.Tx, cat Category, userID, deptID int64, page, pageSize, year int) (domain.PagedResult[domain.Document], error) {
	if page < 1 {
		page = 1
	}
	offset := (page - 1) * pageSize

	var rows pgx.Rows
	var err error
	var total int64

	switch cat {
	case CategoryOutgoing:
		// Исходящие = документы моего подразделения, уже получившие
		// исходящий номер (т.е. подписанные и далее по циклу). Черновики и
		// документы на согласовании сюда НЕ попадают — они в своих категориях.
		err = tx.QueryRow(ctx, `
			SELECT count(*) FROM documents
			WHERE author_department_id = $1 AND outgoing_number IS NOT NULL AND status <> 'archived'`, deptID).Scan(&total)
		if err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		rows, err = tx.Query(ctx, `
			SELECT id, author_id, author_department_id, title, coalesce(body_summary,''), urgency, status,
			       outgoing_number, due_date, due_datetime, created_at, updated_at
			FROM documents
			WHERE author_department_id = $1 AND outgoing_number IS NOT NULL AND status <> 'archived'
			ORDER BY created_at DESC
			LIMIT $2 OFFSET $3`, deptID, pageSize, offset)

	case CategoryIncoming:
		// Входящие = документы, направленные текущему пользователю как
		// получателю (document_recipients), в статусе sent и далее. До
		// отправки (draft/на согласовании/на подписи) получатель их НЕ видит
		// — по требованию "у адресата видно только после подписи".
		err = tx.QueryRow(ctx, `
			SELECT count(*) FROM documents d
			JOIN document_recipients r ON r.document_id = d.id
			WHERE r.recipient_user_id = $1
			  AND d.status IN ('sent','in_progress')`, userID).Scan(&total)
		if err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		rows, err = tx.Query(ctx, `
			SELECT d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
			       d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at
			FROM documents d
			JOIN document_recipients r ON r.document_id = d.id
			WHERE r.recipient_user_id = $1
			  AND d.status IN ('sent','in_progress')
			ORDER BY d.created_at DESC
			LIMIT $2 OFFSET $3`, userID, pageSize, offset)

	case CategoryControl:
		// На контроле = документы с on_control=true. RLS уже ограничивает
		// видимость (контролёр получает document_access при постановке на
		// контроль, автор видит свои напрямую). Индекс idx_documents_on_control.
		err = tx.QueryRow(ctx, `SELECT count(*) FROM documents WHERE on_control = true AND status <> 'archived'`).Scan(&total)
		if err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		rows, err = tx.Query(ctx, `
			SELECT id, author_id, author_department_id, title, coalesce(body_summary,''), urgency, status,
			       outgoing_number, due_date, due_datetime, created_at, updated_at
			FROM documents
			WHERE on_control = true AND status <> 'archived'
			ORDER BY created_at DESC
			LIMIT $1 OFFSET $2`, pageSize, offset)

	case CategoryPrintUnreg:
		// «На регистрацию» = документы, которые ТЕКУЩИЙ пользователь скачал на
		// печать, но ещё не зарегистрировал в бумажном журнале (reg_at IS NULL).
		err = tx.QueryRow(ctx, `
			SELECT count(DISTINCT d.id) FROM documents d
			JOIN document_prints p ON p.document_id = d.id AND p.user_id = $1 AND p.reg_at IS NULL`, userID).Scan(&total)
		if err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		rows, err = tx.Query(ctx, `
			SELECT DISTINCT d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
			       d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at
			FROM documents d
			JOIN document_prints p ON p.document_id = d.id AND p.user_id = $1 AND p.reg_at IS NULL
			ORDER BY d.created_at DESC
			LIMIT $2 OFFSET $3`, userID, pageSize, offset)

	default:
		statuses, hasFilter := categoryStatusFilter[cat]
		if hasFilter {
			// pgx не умеет напрямую сериализовать []domain.Status (срез
			// кастомного строкового типа) в enum-массив Postgres — получаем
			// 500. Приводим к []string: тогда параметр уходит как text[], а
			// Postgres сам кастует к doc_status в сравнении status = ANY(...).
			statusStrs := make([]string, len(statuses))
			for i, s := range statuses {
				statusStrs[i] = string(s)
			}
			// Для архива поддерживаем фильтр по году (по дате помещения в
			// архив/исполнения/создания). year=0 — все годы.
			yearFilter := ""
			if cat == CategoryArchive && year > 0 {
				yearFilter = " AND EXTRACT(YEAR FROM coalesce(archived_at, executed_at, created_at)) = " + strconv.Itoa(year)
			}
			err = tx.QueryRow(ctx, `SELECT count(*) FROM documents WHERE status = ANY($1::doc_status[])`+yearFilter, statusStrs).Scan(&total)
			if err != nil {
				return domain.PagedResult[domain.Document]{}, err
			}
			rows, err = tx.Query(ctx, `
				SELECT id, author_id, author_department_id, title, coalesce(body_summary,''), urgency, status,
				       outgoing_number, due_date, due_datetime, created_at, updated_at
				FROM documents
				WHERE status = ANY($1::doc_status[])`+yearFilter+`
				ORDER BY created_at DESC
				LIMIT $2 OFFSET $3`, statusStrs, pageSize, offset)
		} else {
			// CategoryAll — просто всё, что видно по RLS
			err = tx.QueryRow(ctx, `SELECT count(*) FROM documents WHERE status <> 'archived'`).Scan(&total)
			if err != nil {
				return domain.PagedResult[domain.Document]{}, err
			}
			rows, err = tx.Query(ctx, `
				SELECT id, author_id, author_department_id, title, coalesce(body_summary,''), urgency, status,
				       outgoing_number, due_date, due_datetime, created_at, updated_at
				FROM documents
				WHERE status <> 'archived'
				ORDER BY created_at DESC
				LIMIT $1 OFFSET $2`, pageSize, offset)
		}
	}
	if err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("query documents: %w", err)
	}
	defer rows.Close()

	var items []domain.Document
	for rows.Next() {
		var d domain.Document
		if err := rows.Scan(&d.ID, &d.AuthorID, &d.AuthorDepartmentID, &d.Title, &d.BodySummary, &d.Urgency, &d.Status,
			&d.OutgoingNumber, &d.DueDate, &d.DueDatetime, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		items = append(items, d)
	}
	if err := rows.Err(); err != nil {
		return domain.PagedResult[domain.Document]{}, err
	}

	return domain.PagedResult[domain.Document]{
		Items:      items,
		Page:       page,
		PageSize:   pageSize,
		TotalCount: total,
	}, nil
}

// Search выполняет полнотекстовый поиск по title+body_summary через
// to_tsvector('russian', ...), используя GIN-индекс idx_documents_search
// (миграция 0002). RLS применяется как обычно — поиск никогда не вернёт
// документ, невидимый текущему пользователю. Ранжирование через ts_rank,
// пагинация стандартная (LIMIT/OFFSET), т.к. страниц результатов поиска
// обычно немного и глубокий offset здесь не характерен для UX.
// SearchFilter — набор опциональных фильтров. Пустые поля игнорируются.
// SearchFilter — максимально гибкий набор фильтров по всем атрибутам документа.
// Все поля опциональны; пустые игнорируются. Текстовые поля (Query, Number,
// IncomingNumber) ищутся через ILIKE — частичное совпадение без учёта регистра
// (по требованию: НЕ полнотекстовый поиск).
type SearchFilter struct {
	Category       string   // категория-вкладка для ограничения поиска её пределами
	UserID         int64    // текущий пользователь (для incoming)
	DeptID         int64    // подразделение пользователя (для outgoing)
	Query          string   // частичное совпадение (ILIKE) по title + body_summary
	AuthorID       int64    // 0 = любой
	SignerID       int64    // 0 = любой (по document_signatures)
	ControllerID   int64    // 0 = любой (контролёр документа)
	ApproverID     int64    // 0 = любой (участник маршрута согласования)
	RecipientID    int64    // 0 = любой (адресат рассылки)
	DepartmentID   int64    // 0 = любое подразделение-автор
	Statuses       []string // пусто = любые
	Urgencies      []string // пусто = любые
	OnControl      string   // "" любой | "true" только на контроле | "false" только не на контроле
	DueFrom        string   // срок исполнения от, YYYY-MM-DD или ""
	DueTo          string   // срок исполнения до, YYYY-MM-DD или ""
	CreatedFrom    string   // дата создания от, YYYY-MM-DD или ""
	CreatedTo      string   // дата создания до, YYYY-MM-DD или ""
	SignedFrom     string   // дата подписания от, YYYY-MM-DD или ""
	SignedTo       string   // дата подписания до, YYYY-MM-DD или ""
	Number         string   // исходящий номер (ILIKE, частичное совпадение)
	IncomingNumber string   // входящий номер (ILIKE, по document_incoming_instances)
}

func (r *DocumentsRepo) Search(ctx context.Context, tx pgx.Tx, f SearchFilter, page, pageSize int) (domain.PagedResult[domain.Document], error) {
	if page < 1 {
		page = 1
	}
	offset := (page - 1) * pageSize

	// Собираем WHERE динамически. $1.. — позиционные параметры.
	where := []string{"1=1"}
	args := []any{}
	add := func(cond string, val any) {
		args = append(args, val)
		where = append(where, fmt.Sprintf(cond, len(args)))
	}

	// Ограничение по КАТЕГОРИИ (вкладке) — чтобы поиск/фильтр работал строго в
	// пределах категории, а не по всей базе. Совпадает с логикой List.
	switch Category(f.Category) {
	case CategoryOutgoing:
		add("d.author_department_id = $%d", f.DeptID)
		where = append(where, "d.outgoing_number IS NOT NULL")
	case CategoryIncoming:
		add("EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id = d.id AND r.recipient_user_id = $%d AND d.status IN ('sent','in_progress'))", f.UserID)
	case CategoryControl:
		where = append(where, "d.on_control = true")
	case CategoryPrintUnreg:
		add("EXISTS (SELECT 1 FROM document_prints p WHERE p.document_id = d.id AND p.user_id = $%d AND p.reg_at IS NULL)", f.UserID)
	case CategoryOnSigning:
		where = append(where, "d.status = 'on_signing'")
	case CategoryOnApproval:
		where = append(where, "d.status IN ('on_approval_hierarchy','on_approval_cross_dept')")
	case CategoryExecuted:
		where = append(where, "d.status = 'executed'")
	case CategoryArchive:
		where = append(where, "d.status = 'archived'")
	}

	// Архивные документы не должны попадать НИ В ОДИН список/поиск, кроме
	// категории «Архив». Для incoming статус уже сужен выше.
	if Category(f.Category) != CategoryArchive {
		where = append(where, "d.status <> 'archived'")
	}

	if f.Query != "" {
		// ILIKE — частичное совпадение без учёта регистра по названию И
		// содержанию. Один параметр используем дважды (по title и body).
		args = append(args, f.Query)
		n := len(args)
		where = append(where, fmt.Sprintf(
			"(d.title ILIKE '%%' || $%d || '%%' OR coalesce(d.body_summary,'') ILIKE '%%' || $%d || '%%')", n, n))
	}
	if f.AuthorID != 0 {
		add("d.author_id = $%d", f.AuthorID)
	}
	if f.DepartmentID != 0 {
		add("d.author_department_id = $%d", f.DepartmentID)
	}
	if f.SignerID != 0 {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signer_id = $%d)", f.SignerID)
	}
	if f.ControllerID != 0 {
		add("d.controller_id = $%d", f.ControllerID)
	}
	if f.ApproverID != 0 {
		add("EXISTS (SELECT 1 FROM approval_stages a WHERE a.document_id = d.id AND a.approver_id = $%d)", f.ApproverID)
	}
	if f.RecipientID != 0 {
		add("EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id = d.id AND r.recipient_user_id = $%d)", f.RecipientID)
	}
	if len(f.Statuses) > 0 {
		add("d.status = ANY($%d::doc_status[])", f.Statuses)
	}
	if len(f.Urgencies) > 0 {
		add("d.urgency = ANY($%d::doc_urgency[])", f.Urgencies)
	}
	if f.OnControl == "true" {
		where = append(where, "d.on_control = true")
	} else if f.OnControl == "false" {
		where = append(where, "d.on_control = false")
	}
	if f.DueFrom != "" {
		add("d.due_date >= $%d::date", f.DueFrom)
	}
	if f.DueTo != "" {
		add("d.due_date <= $%d::date", f.DueTo)
	}
	if f.CreatedFrom != "" {
		add("d.created_at >= $%d::date", f.CreatedFrom)
	}
	if f.CreatedTo != "" {
		add("d.created_at < ($%d::date + interval '1 day')", f.CreatedTo)
	}
	if f.Number != "" {
		add("d.outgoing_number ILIKE '%%' || $%d || '%%'", f.Number)
	}
	if f.IncomingNumber != "" {
		add("EXISTS (SELECT 1 FROM document_incoming_instances i WHERE i.document_id = d.id AND i.incoming_number ILIKE '%%' || $%d || '%%')", f.IncomingNumber)
	}
	if f.SignedFrom != "" {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signed_at >= $%d::date)", f.SignedFrom)
	}
	if f.SignedTo != "" {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signed_at < ($%d::date + interval '1 day'))", f.SignedTo)
	}

	whereSQL := strings.Join(where, " AND ")

	var total int64
	if err := tx.QueryRow(ctx, "SELECT count(*) FROM documents d WHERE "+whereSQL, args...).Scan(&total); err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("count search: %w", err)
	}

	// Пагинация: добавляем limit/offset как последние параметры.
	args = append(args, pageSize, offset)
	listSQL := fmt.Sprintf(`
		SELECT d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
		       d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at
		FROM documents d
		WHERE %s
		ORDER BY d.created_at DESC
		LIMIT $%d OFFSET $%d`, whereSQL, len(args)-1, len(args))

	rows, err := tx.Query(ctx, listSQL, args...)
	if err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("search documents: %w", err)
	}
	defer rows.Close()

	var items []domain.Document
	for rows.Next() {
		var d domain.Document
		if err := rows.Scan(&d.ID, &d.AuthorID, &d.AuthorDepartmentID, &d.Title, &d.BodySummary, &d.Urgency, &d.Status,
			&d.OutgoingNumber, &d.DueDate, &d.DueDatetime, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return domain.PagedResult[domain.Document]{}, err
		}
		items = append(items, d)
	}
	if err := rows.Err(); err != nil {
		return domain.PagedResult[domain.Document]{}, err
	}
	return domain.PagedResult[domain.Document]{Items: items, Page: page, PageSize: pageSize, TotalCount: total}, nil
}

func (r *DocumentsRepo) GetByID(ctx context.Context, tx pgx.Tx, id int64) (domain.Document, error) {
	var d domain.Document
	err := tx.QueryRow(ctx, `
		SELECT d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
		       d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at,
		       coalesce(d.on_control,false), d.controller_id, cu.full_name,
		       (SELECT max(signed_at) FROM document_signatures WHERE document_id = d.id)
		FROM documents d
		LEFT JOIN users cu ON cu.id = d.controller_id
		WHERE d.id = $1`, id).Scan(
		&d.ID, &d.AuthorID, &d.AuthorDepartmentID, &d.Title, &d.BodySummary, &d.Urgency, &d.Status,
		&d.OutgoingNumber, &d.DueDate, &d.DueDatetime, &d.CreatedAt, &d.UpdatedAt,
		&d.OnControl, &d.ControllerID, &d.ControllerName, &d.SignedAt)
	// Если строки нет — либо документ не существует, либо (что чаще) он
	// невидим по RLS для текущего app.user_id: pgx вернёт ErrNoRows в обоих
	// случаях, и снаружи это всегда трактуется как 404, а не 403 — так мы
	// не раскрываем факт существования документа пользователю без доступа.
	if err != nil {
		return domain.Document{}, err
	}
	return d, nil
}

// ListStages возвращает маршрут согласования документа для отображения на
// фронте (кто согласовал/на каком этапе сейчас). RLS документа уже
// применена выше по стеку (документ либо виден пользователю, либо этот
// метод не будет вызван), approval_stages собственной RLS-политики не
// имеет — видимость всего маршрута тому, кто видит документ, осознанный
// выбор (иначе нельзя показать прогресс согласования в UI).
func (r *DocumentsRepo) ListStages(ctx context.Context, tx pgx.Tx, documentID int64) ([]domain.ApprovalStage, error) {
	rows, err := tx.Query(ctx, `
		SELECT s.id, s.document_id, s.stage_type, s.approver_id,
		       coalesce(u.full_name,''), coalesce(u.position,''),
		       s.status, s.display_order, s.decided_at,
		       coalesce(s.comment, ''),
		       coalesce(array_agg(d.depends_on_stage_id) FILTER (WHERE d.depends_on_stage_id IS NOT NULL), '{}')
		FROM approval_stages s
		LEFT JOIN users u ON u.id = s.approver_id
		LEFT JOIN approval_stage_dependencies d ON d.stage_id = s.id
		WHERE s.document_id = $1
		GROUP BY s.id, u.full_name, u.position
		ORDER BY s.display_order`, documentID)
	if err != nil {
		return nil, fmt.Errorf("query stages: %w", err)
	}
	defer rows.Close()

	var stages []domain.ApprovalStage
	for rows.Next() {
		var s domain.ApprovalStage
		if err := rows.Scan(&s.ID, &s.DocumentID, &s.StageType, &s.ApproverID,
			&s.ApproverName, &s.ApproverPosition,
			&s.Status, &s.DisplayOrder, &s.DecidedAt, &s.Comment, &s.DependsOn); err != nil {
			return nil, err
		}
		stages = append(stages, s)
	}
	return stages, rows.Err()
}
