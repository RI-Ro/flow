import React, { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import UrgencyBadge from '../components/UrgencyBadge'
import DocumentViewer from '../components/DocumentViewer'
import ChatPanel from '../components/ChatPanel'
import ApprovalPanel from '../components/ApprovalPanel'
import DocumentTabs from '../components/DocumentTabs'
import EditDocumentModal from '../components/EditDocumentModal'
import NotFound from '../components/NotFound'
import { fmtDateTime } from '../utils/format'

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split('.')[1]))
  } catch (_) {
    return null
  }
}

export default function DocumentDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [doc, setDoc] = useState(null)
  const [myCopy, setMyCopy] = useState(null)
  const [incomingMarking, setIncomingMarking] = useState(null)
  const [marks, setMarks] = useState({ stamps: [], baked: false })
  const [error, setError] = useState('')
  const [editing, setEditing] = useState(false)
  const [loading, setLoading] = useState(true)

  const currentUserId = (() => {
    const token = localStorage.getItem('sed_token')
    const payload = token ? parseJwt(token) : null
    return payload?.uid
  })()

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      // Ответ { document, incoming_marking } — второе поле заполняется
      // бэкендом при регистрации входящего экземпляра (первый просмотр
      // получателем), см. IncomingService.RegisterView.
      const res = await api.getDocument(id)
      setDoc(res.document)
      setIncomingMarking(res.incoming_marking)
      setMyCopy(res.my_copy_number ?? null)
      // Маркировка (штампы по конфигу). Если бэкенд вжигает штампы в PDF —
      // baked=true и overlay на фронте не рисуем.
      api.getDocumentMarking(id).then(setMarks).catch(() => setMarks({ stamps: [], baked: false }))
    } catch (err) {
      setError(err.message || 'Документ не найден или недоступен')
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => {
    load()
  }, [load])

  if (loading) return <div className="p-6 text-text-secondary">Загрузка…</div>
  if (error) {
    // Единый экран 404 с иллюстрацией на тему документов.
    return <NotFound />
  }
  if (!doc) return null

  const preSigned = !['signed', 'sent', 'in_progress', 'executed', 'archived'].includes(doc.status)

  // Маркировка — исходящий номер/место хранения (после подписания) плюс,
  // если применимо, номер входящего экземпляра (после регистрации у
  // получателя). Оба слоя показываются overlay поверх вьювера, не
  // "вшиваются" в сам PDF (см. архитектурную спецификацию, п.4.3).
  const markingLines = []
  if (doc.outgoing_number) {
    markingLines.push(doc.outgoing_number)
    markingLines.push(`СЭД / Архив ${new Date(doc.created_at).getFullYear()}`)
  }
  if (incomingMarking) {
    markingLines.push(`${incomingMarking.incoming_number} · ${incomingMarking.instance_label}`)
  }
  const marking = markingLines.length ? markingLines.join('\n') : null

  return (
    <div className="h-[calc(100vh-56px)] flex flex-col">
      <div className="px-6 py-4 border-b border-border bg-surface flex items-start justify-between gap-4">
        <div>
          <button className="text-accent text-sm mb-1" onClick={() => navigate(-1)}>
            ← Назад к списку
          </button>
          <h1 className="font-display text-lg font-semibold">{doc.title}</h1>
          <div className="kicker mt-0.5">
            {doc.outgoing_number || `Черновик #${doc.id}`}
            {doc.signed_at && ` · подписан ${fmtDateTime(doc.signed_at)}`}
            {` · создан ${fmtDateTime(doc.created_at)}`}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {myCopy != null && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-accent/40 bg-accent/10 text-accent" title="Ваш номер экземпляра документа">
              Экз. № {myCopy}
            </span>
          )}
          {doc.on_control && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-danger/40 bg-danger/10 text-danger">
              ● На контроле
            </span>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button onClick={() => setEditing(true)} className="px-3 py-1.5 rounded-md border border-border text-sm">
              Изменить
            </button>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button
              onClick={async () => {
                if (!confirm('Удалить документ безвозвратно?')) return
                try {
                  await api.deleteDocument(doc.id)
                  navigate('/documents/all')
                } catch (e) {
                  alert(e.message)
                }
              }}
              className="px-3 py-1.5 rounded-md border border-danger/40 text-danger text-sm"
            >
              Удалить
            </button>
          )}
          <UrgencyBadge urgency={doc.urgency} />
        </div>
      </div>

      <div className="flex-1 grid grid-cols-5 gap-4 p-4 min-h-0">
        <div className="col-span-3 min-h-0 flex flex-col gap-2">
          {doc.body_summary && (
            <div className="bg-surface border border-border rounded-lg p-3 text-sm">
              <div className="kicker mb-1">// краткое содержание</div>
              <div className="whitespace-pre-wrap">{doc.body_summary}</div>
            </div>
          )}
          <div className="flex-1 min-h-0">
            <DocumentViewer documentId={doc.id} marking={marking} stamps={marks.baked ? [] : marks.stamps} />
          </div>
        </div>
        <div className="col-span-2 min-h-0 flex flex-col gap-4">
          {/* Вкладки (маршрут/история/…) — фиксированная высота, своя прокрутка */}
          <div className="h-[45%] min-h-0 overflow-hidden flex flex-col">
            <DocumentTabs
              documentId={doc.id}
              currentUserId={currentUserId}
              docStatus={doc.status}
              doc={doc}
              onChanged={load}
              patchDoc={(p) => setDoc((d) => (d ? { ...d, ...p } : d))}
              routeSlot={<ApprovalPanel documentId={doc.id} currentUserId={currentUserId} onChanged={load} />}
            />
          </div>
          {/* Обсуждение — фиксированная высота, своя прокрутка */}
          <div className="flex-1 min-h-0 overflow-hidden">
            <ChatPanel documentId={doc.id} currentUserId={currentUserId} />
          </div>
        </div>
      </div>
      {editing && (
        <EditDocumentModal
          doc={doc}
          currentUserId={currentUserId}
          onClose={() => setEditing(false)}
          onSaved={load}
        />
      )}
    </div>
  )
}
