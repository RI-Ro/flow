-- Плоский дамп чистых миграций (0001+0002+0003) БЕЗ goose-директив.
-- Автогенерируется из ../migrations. Не редактировать вручную.

-- ===== 0001_schema.sql =====
-- ============================================================================
-- СХЕМА СЭД — единый, консолидированный файл (проект разворачивается с нуля).
-- Здесь СРАЗУ финальное состояние всех таблиц/типов/индексов/функций. Никаких
-- отдельных «чинящих» миграций: каждый объект определён один раз и правильно.
-- RLS-политики вынесены в 0002_rls.sql, демо-данные — в 0003_seed_demo.sql.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------- оргструктура
CREATE TABLE departments (
    id BIGSERIAL PRIMARY KEY,
    parent_id BIGINT REFERENCES departments(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    outgoing_prefix TEXT NOT NULL UNIQUE,     -- краткий код (напр. "ГУ")
    numbering_prefix TEXT,                     -- иерархический префикс (напр. "9/8/7")
    is_active BOOL NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE department_closure (
    ancestor_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    descendant_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    depth INT NOT NULL,
    PRIMARY KEY (ancestor_id, descendant_id)
);
CREATE INDEX idx_dept_closure_desc ON department_closure(descendant_id);
CREATE INDEX idx_dept_closure_anc ON department_closure(ancestor_id);

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    login TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    position TEXT,                              -- должность (для штампа подписи)
    primary_department_id BIGINT REFERENCES departments(id),
    numbering_department_id BIGINT REFERENCES departments(id),
    is_active BOOL NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_dept ON users(primary_department_id);

CREATE TYPE role_code AS ENUM (
    'author','approver_hierarchy','approver_cross_dept','signer','executor',
    'clerk','duty_officer','chief','controller','admin'
);

CREATE TABLE user_roles (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT REFERENCES departments(id) ON DELETE CASCADE, -- NULL = глобальная роль (admin)
    role role_code NOT NULL,
    PRIMARY KEY (user_id, department_id, role)
);
CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_user_roles_dept_role ON user_roles(department_id, role);

-- Доп. подразделения (вне основной иерархии пользователя):
--   видимость исходящих, ознакомление, поручения.
CREATE TABLE user_visible_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX idx_user_visible_dept ON user_visible_departments(department_id);

CREATE TABLE user_acquaint_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);

CREATE TABLE user_assign_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);

-- ------------------------------------------------------------------- документы
CREATE TYPE doc_urgency AS ENUM ('normal','urgent','out_of_turn');
CREATE TYPE doc_status  AS ENUM (
    'draft','on_approval_hierarchy','on_approval_cross_dept',
    'on_signing','signed','sent','in_progress','executed','archived','rejected'
);

CREATE TABLE documents (
    id BIGSERIAL PRIMARY KEY,
    author_id BIGINT NOT NULL REFERENCES users(id),
    author_department_id BIGINT NOT NULL REFERENCES departments(id),
    title TEXT NOT NULL,
    body_summary TEXT,
    urgency doc_urgency NOT NULL DEFAULT 'normal',
    status doc_status NOT NULL DEFAULT 'draft',
    outgoing_number TEXT UNIQUE,
    due_date DATE,
    due_datetime TIMESTAMPTZ,
    executed_at TIMESTAMPTZ,
    archived_at TIMESTAMPTZ,
    controller_id BIGINT REFERENCES users(id),
    on_control BOOL NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_documents_status_created ON documents(status, created_at DESC);
CREATE INDEX idx_documents_author_created ON documents(author_id, created_at DESC);
CREATE INDEX idx_documents_dept_created ON documents(author_department_id, created_at DESC);
CREATE INDEX idx_documents_status_only ON documents(status);
CREATE INDEX idx_documents_urgency ON documents(urgency);
CREATE INDEX idx_documents_due ON documents(due_date) WHERE due_date IS NOT NULL;
CREATE INDEX idx_documents_executed_year ON documents(executed_at) WHERE status = 'executed' AND executed_at IS NOT NULL;
CREATE INDEX idx_documents_on_control ON documents(on_control) WHERE on_control = true;
CREATE INDEX idx_documents_controller ON documents(controller_id) WHERE controller_id IS NOT NULL;
CREATE INDEX idx_documents_search ON documents USING GIN (to_tsvector('russian', title || ' ' || coalesce(body_summary, '')));
CREATE INDEX idx_documents_title_trgm  ON documents USING gin (title gin_trgm_ops);
CREATE INDEX idx_documents_body_trgm   ON documents USING gin (coalesce(body_summary,'') gin_trgm_ops);
CREATE INDEX idx_documents_outnum_trgm ON documents USING gin (coalesce(outgoing_number,'') gin_trgm_ops);

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON documents
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE document_history (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    actor_id BIGINT REFERENCES users(id),
    event_type TEXT NOT NULL,
    from_status doc_status,
    to_status doc_status,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_doc_history_doc ON document_history(document_id, created_at);

CREATE TABLE document_files (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    content BYTEA NOT NULL,
    sha256 TEXT NOT NULL,
    size_bytes INT NOT NULL,
    mime_type TEXT NOT NULL DEFAULT 'application/pdf' CHECK (mime_type = 'application/pdf'),
    uploaded_by BIGINT REFERENCES users(id),
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(document_id)
);

CREATE TABLE document_signatures (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    signer_id BIGINT NOT NULL REFERENCES users(id),
    signed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    signature_type TEXT NOT NULL CHECK (signature_type IN ('ПЭП','НЭП','УНЭП','УКЭП')),
    signature_hash TEXT NOT NULL,
    storage_resource TEXT NOT NULL,
    signer_fio TEXT,        -- снимок ФИО на момент подписи
    signer_position TEXT    -- снимок должности на момент подписи
);
CREATE INDEX idx_doc_signatures_doc ON document_signatures(document_id);

CREATE TABLE numbering_sequences (
    department_id BIGINT NOT NULL REFERENCES departments(id),
    year INT NOT NULL,
    seq_type TEXT NOT NULL CHECK (seq_type IN ('outgoing','incoming')),
    last_value INT NOT NULL DEFAULT 0,
    PRIMARY KEY (department_id, year, seq_type)
);

CREATE TABLE document_incoming_instances (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    receiving_department_id BIGINT NOT NULL REFERENCES departments(id),
    received_by BIGINT REFERENCES users(id),
    incoming_number TEXT NOT NULL,
    instance_label TEXT,
    first_viewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(document_id, receiving_department_id)
);
CREATE INDEX idx_incoming_dept ON document_incoming_instances(receiving_department_id, created_at DESC);
CREATE INDEX idx_incoming_number_trgm ON document_incoming_instances USING gin (incoming_number gin_trgm_ops);

CREATE TABLE document_recipients (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    recipient_user_id BIGINT NOT NULL REFERENCES users(id),
    recipient_department_id BIGINT NOT NULL REFERENCES departments(id),
    is_planned BOOL NOT NULL DEFAULT false,     -- плановый (активируется при подписи)
    completed_at TIMESTAMPTZ,
    completion_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_doc_recipient UNIQUE (document_id, recipient_user_id)
);
CREATE INDEX idx_doc_recipients_doc ON document_recipients(document_id);
CREATE INDEX idx_doc_recipients_user ON document_recipients(recipient_user_id);
CREATE INDEX idx_doc_recipients_incomplete ON document_recipients(document_id) WHERE completed_at IS NULL;

-- Получатель рассылки обязан иметь роль duty_officer или clerk в своём
-- подразделении (defence-in-depth на уровне БД).
CREATE OR REPLACE FUNCTION check_recipient_role() RETURNS TRIGGER AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = NEW.recipient_user_id
      AND department_id = NEW.recipient_department_id
      AND role IN ('duty_officer', 'clerk')
  ) THEN
    RAISE EXCEPTION 'recipient % must have role duty_officer or clerk in department %',
      NEW.recipient_user_id, NEW.recipient_department_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_recipient_role
BEFORE INSERT OR UPDATE ON document_recipients
FOR EACH ROW EXECUTE FUNCTION check_recipient_role();

-- --------------------------------------------------------------- согласование
CREATE TYPE stage_type AS ENUM ('hierarchy','cross_dept','signing');
CREATE TYPE stage_status AS ENUM ('waiting_deps','pending','approved','rejected');

CREATE TABLE approval_stages (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    stage_type stage_type NOT NULL,
    approver_id BIGINT NOT NULL REFERENCES users(id),
    status stage_status NOT NULL DEFAULT 'waiting_deps',
    display_order INT NOT NULL DEFAULT 0,
    decided_at TIMESTAMPTZ,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_approval_stage_doc ON approval_stages(document_id, display_order);
CREATE INDEX idx_approval_stage_approver ON approval_stages(approver_id, status);

CREATE TABLE approval_stage_dependencies (
    stage_id BIGINT NOT NULL REFERENCES approval_stages(id) ON DELETE CASCADE,
    depends_on_stage_id BIGINT NOT NULL REFERENCES approval_stages(id) ON DELETE CASCADE,
    PRIMARY KEY (stage_id, depends_on_stage_id),
    CHECK (stage_id <> depends_on_stage_id)
);
CREATE INDEX idx_stage_deps_stage ON approval_stage_dependencies(stage_id);
CREATE INDEX idx_stage_deps_depends_on ON approval_stage_dependencies(depends_on_stage_id);

CREATE TABLE executors (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    executor_id BIGINT NOT NULL REFERENCES users(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    report TEXT
);
CREATE INDEX idx_executors_doc ON executors(document_id);
CREATE INDEX idx_executors_user ON executors(executor_id, completed_at);

-- --------------------------------------------------------- доступ / чат / уведомл.
CREATE TABLE document_access (
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    access_reason TEXT NOT NULL,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (document_id, user_id, access_reason)
);
CREATE INDEX idx_doc_access_user ON document_access(user_id, document_id);
CREATE INDEX idx_doc_access_doc ON document_access(document_id);

CREATE TABLE chat_messages (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    author_id BIGINT NOT NULL REFERENCES users(id),
    text TEXT,
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_doc_created ON chat_messages(document_id, created_at);

CREATE TABLE chat_attachments (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    content BYTEA NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_attach_message ON chat_attachments(message_id);

CREATE TABLE notifications (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}',
    is_read BOOL NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, is_read, created_at DESC);

CREATE TABLE document_views (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    viewer_id BIGINT NOT NULL REFERENCES users(id),
    viewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_doc_views_doc ON document_views(document_id, viewed_at DESC);

-- ------------------------------------------------- связи / поручения / ознакомл.
CREATE TABLE document_links (
    id BIGSERIAL PRIMARY KEY,
    source_document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    target_document_id BIGINT REFERENCES documents(id) ON DELETE CASCADE,   -- NULL, если text_note
    text_note TEXT,
    link_type TEXT NOT NULL DEFAULT 'related'
        CHECK (link_type IN ('related','reply_to','in_pursuance_of','annuls','appendix')),
    created_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_document_id, target_document_id, link_type),
    CHECK (source_document_id <> target_document_id),
    -- ровно одно из двух: ссылка на документ ИЛИ текстовая пометка
    CONSTRAINT chk_link_target CHECK ((target_document_id IS NOT NULL) <> (text_note IS NOT NULL))
);
CREATE INDEX idx_document_links_source ON document_links(source_document_id);
CREATE INDEX idx_document_links_target ON document_links(target_document_id);

CREATE TABLE assignments (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    author_id BIGINT NOT NULL REFERENCES users(id),
    assignee_id BIGINT NOT NULL REFERENCES users(id),
    controller_id BIGINT REFERENCES users(id),
    text TEXT NOT NULL,
    due_date DATE,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open','in_progress','done','cancelled')),
    result_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ
);
CREATE INDEX idx_assignments_document ON assignments(document_id);
CREATE INDEX idx_assignments_assignee ON assignments(assignee_id) WHERE status IN ('open','in_progress');

CREATE TABLE document_acquaintances (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id),
    acquainted_by BIGINT NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, user_id)
);
CREATE INDEX idx_acq_user ON document_acquaintances(user_id);

-- ===== 0002_rls.sql =====
-- ============================================================================
-- RLS-политики — сразу в финальном (каноническом) виде. FORCE RLS включён для
-- трёх таблиц: documents, chat_messages, notifications. Никаких последующих
-- «чинящих» миграций: политики определены здесь один раз и правильно.
--
-- Ключевые моменты, из-за которых раньше были повторяющиеся ошибки:
--   * Для FORCE RLS + INSERT нужен WITH CHECK (иначе "new row violates RLS").
--   * notifications INSERT: уведомление создаёт СЕРВЕРНЫЙ код ДЛЯ ДРУГОГО
--     пользователя (автор→согласующему, подписант→всем заинтересованным).
--     Публичного эндпоинта создания уведомлений нет. Поэтому INSERT
--     БЕЗУСЛОВНО разрешён (WITH CHECK true) — это надёжно исключает ошибку
--     "new row violates row-level security policy for table notifications"
--     независимо от того, как выставлена сессионная переменная в конкретном
--     пути. Чтение по-прежнему строго ограничено своими (notifications_select).
--   * DELETE на chat_messages/notifications разрешён (USING true) для каскада
--     ON DELETE при удалении документа (прямых hard-delete эндпоинтов нет).
-- ============================================================================

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents FORCE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages FORCE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications FORCE ROW LEVEL SECURITY;

-- --------------------------------------------------------------- documents ---
CREATE POLICY documents_select ON documents FOR SELECT USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR (documents.outgoing_number IS NOT NULL AND documents.author_department_id IN (
        SELECT uvd.department_id FROM user_visible_departments uvd
        WHERE uvd.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint))
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_insert ON documents FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_update ON documents FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_delete ON documents FOR DELETE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

-- ------------------------------------------------------------ chat_messages ---
CREATE POLICY chat_select ON chat_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
          AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY chat_insert ON chat_messages FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  AND EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
              AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint));

CREATE POLICY chat_update ON chat_messages FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY chat_delete ON chat_messages FOR DELETE USING (true);

-- ------------------------------------------------------------ notifications ---
CREATE POLICY notifications_select ON notifications FOR SELECT USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

-- INSERT безусловно разрешён (см. заголовок файла).
CREATE POLICY notifications_insert ON notifications FOR INSERT WITH CHECK (true);

CREATE POLICY notifications_update ON notifications FOR UPDATE USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY notifications_delete ON notifications FOR DELETE USING (true);

-- ===== 0003_seed_demo.sql =====
-- Демо-данные для локального запуска/разработки. Пароль всех демо-пользователей:
-- "password123" (bcrypt). В production сиды заменяются реальной оргструктурой
-- через консоль администрирования.

INSERT INTO departments (id, parent_id, name, outgoing_prefix, numbering_prefix) VALUES
  (1, NULL, 'Главное управление', 'ГУ',   '1'),
  (2, 1,    'Департамент цифровизации', 'ЭД', '1/2'),
  (3, 1,    'Департамент финансов', 'ФИН',  '1/3'),
  (4, 2,    'Отдел разработки', 'РАЗР',     '1/2/4');
SELECT setval('departments_id_seq', 4, true);

INSERT INTO department_closure (ancestor_id, descendant_id, depth) VALUES
  (1,1,0), (2,2,0), (3,3,0), (4,4,0),
  (1,2,1), (1,3,1), (1,4,2),
  (2,4,1);

INSERT INTO users (id, login, password_hash, full_name, position, primary_department_id, numbering_department_id) VALUES
  (1, 'author1',   '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Иванов И.И. (автор)',            'Специалист отдела разработки',              4, 4),
  (2, 'chief1',     '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Петров П.П. (нач. отдела)',      'Начальник отдела разработки',               4, 4),
  (3, 'crossdept1', '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Сидоров С.С. (согласование ФИН)','Главный специалист департамента финансов',  3, 3),
  (4, 'signer1',    '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Смирнов А.А. (подписант)',       'Заместитель руководителя',                  1, 1),
  (5, 'duty1',      '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Кузнецов К.К. (дежурный)',       'Дежурный по департаменту',                  2, 2),
  (6, 'clerk1',     '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Морозова М.М. (канцелярия)',     'Делопроизводитель канцелярии',              1, 1);
SELECT setval('users_id_seq', 6, true);

INSERT INTO user_roles (user_id, department_id, role) VALUES
  (1, 4, 'author'),
  (2, 4, 'approver_hierarchy'),
  (2, 4, 'chief'),
  (3, 3, 'approver_cross_dept'),
  (4, 1, 'signer'),
  (5, 2, 'duty_officer'),
  (6, 1, 'clerk');
