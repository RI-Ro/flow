-- ============================================================================
--  ГЕНЕРАТОР ТЕСТОВЫХ ДАННЫХ (документы) для СЭД
-- ============================================================================
--  Наполняет БД реалистичным набором документов во всех статусах и с полным
--  «обвесом» (файл-оригинал, этапы согласования + подпись, история, рассылка,
--  входящие экземпляры, поручения, ознакомления, чат, уведомления), чтобы
--  можно было проверить списки, дашборд, фильтры, карточку и права.
--
--  ЗАПУСК (от роли-владельца схемы или суперпользователя):
--     psql "$DATABASE_URL" -v ndocs=60 -f testdata_generator.sql
--
--  Параметр  -v ndocs=N   — сколько документов сгенерировать (по умолчанию 40).
--  Идемпотентность: перед генерацией удаляются ранее сгенерированные этим
--  скриптом документы (у них title начинается с префикса '[TD]').
--
--  ВАЖНО про RLS: таблицы documents/chat_messages/notifications имеют FORCE
--  ROW LEVEL SECURITY. Скрипт отключает row_security на время сессии
--  (`SET row_security = off`) — это допустимо для владельца таблиц/суперюзера.
--  Триггер check_recipient_role остаётся активным, поэтому получателями
--  рассылки назначаются только пользователи с ролью duty_officer/clerk.
-- ============================================================================

\set ON_ERROR_STOP on
\if :{?ndocs}
\else
  \set ndocs 40
\endif

-- Пробрасываем psql-переменную :ndocs в GUC (внутри dollar-quoted DO-блока
-- psql-переменные НЕ подставляются, поэтому читаем через current_setting).
SELECT set_config('sed.ndocs', :'ndocs', false);

SET row_security = off;

-- app.* заданы на случай, если скрипт запускают под ролью без BYPASSRLS, но
-- с правом отключать row_security; заодно проходят WITH CHECK-политики.
SET app.user_id  = '1';
SET app.is_admin = 'true';

-- ---------------------------------------------------------------------------
-- 0. Очистка ранее сгенерированных тестовых документов (ON DELETE CASCADE
--    уберёт файлы/этапы/историю/рассылку/поручения/ознакомления/чат).
-- ---------------------------------------------------------------------------
-- Очистка ранее сгенерированных тестовых документов. Ловим ДВУМЯ способами
-- на случай, если предыдущий запуск был прерван (Ctrl+C) до того, как дошёл
-- до конца, или использовал более раннюю версию скрипта с другим текстом
-- заголовка: по префиксу заголовка И по префиксу исходящего номера. Это
-- гарантирует чистый старт независимо от того, чем был вызван предыдущий
-- сбой ("duplicate key value violates unique constraint
-- documents_outgoing_number_key" — типичный симптом недочищенного хвоста).
-- Очистка ранее сгенерированных тестовых документов. Тестовые документы имеют
-- заголовок с префиксом '[TD]' — по нему и чистим. По outgoing_number чистить
-- НЕЛЬЗЯ: теперь тестовые номера имеют тот же префикс ИСХ-/ВХ-, что и боевые
-- (удалили бы реальные). Генерация атомарна (один DO-блок): прерванный прогон
-- откатывается целиком, остатков не оставляет; успешный прошлый прогон
-- убирается этим DELETE по заголовку.
DELETE FROM documents WHERE title LIKE '[TD]%';

-- ---------------------------------------------------------------------------
-- 1. Основная генерация в одном DO-блоке (plpgsql).
-- ---------------------------------------------------------------------------
DO $gen$
DECLARE
  v_ndocs        int := current_setting('sed.ndocs')::int;
  -- Демо-пользователи (см. all_in_one.sql):
  --  1 author1 (отдел разработки, dept 4)
  --  2 chief1  (нач. отдела, dept 4, approver_hierarchy)
  --  3 crossdept1 (ФИН, dept 3, approver_cross_dept)
  --  4 signer1  (ГУ, dept 1, signer)
  --  5 duty1    (dept 2, duty_officer)   — может быть получателем рассылки
  --  6 clerk1   (dept 1, clerk)          — может быть получателем рассылки
  v_author       bigint := 1;
  v_author_dept  bigint := 4;
  v_approver_h   bigint := 2;
  v_approver_c   bigint := 3;
  v_signer       bigint := 4;
  v_recipients   bigint[] := ARRAY[5,6];       -- только duty/clerk (триггер!)
  v_recip_dept   bigint[] := ARRAY[2,1];       -- их подразделения

  -- Минимальный валидный PDF (проходит проверку isPDF по префиксу %PDF-).
  v_pdf          bytea := convert_to(
    E'%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n'
    '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n'
    '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\n'
    'trailer<</Root 1 0 R>>\n%%EOF\n', 'UTF8');

  v_statuses  text[] := ARRAY[
    'draft','on_approval_hierarchy','on_approval_cross_dept','on_signing',
    'signed','sent','in_progress','executed','archived','rejected'];
  v_urgencies text[] := ARRAY['normal','normal','normal','urgent','out_of_turn'];

  i            int;
  v_doc        bigint;
  v_status     text;
  v_urgency    text;
  v_outnum     text;
  v_signed_at  timestamptz;
  v_created    timestamptz;
  v_due        timestamptz;
  v_year       int := extract(year from now())::int;
  v_seq        int := 0;
  -- Префиксы подразделений из БД для РЕАЛИСТИЧНОГО формата номеров, как в
  -- боевой нумерации: ИСХ-{префикс}-{номер}/{год}, ВХ-{префикс}-{номер}/{год}.
  -- Берём numbering_prefix, если пуст — outgoing_prefix (как в NextOutgoing).
  v_out_prefix   text;      -- префикс подразделения-автора (для ИСХ)
  v_inc_prefix   text[];    -- префиксы подразделений-получателей (для ВХ)
  v_inc_seq      int[] := ARRAY[0,0];  -- отдельные счётчики входящих на каждое подразд.
  -- Соль-квалификатор на весь запуск: гарантирует отсутствие коллизий с
  -- боевыми номерами/остатками. Ставим как суффикс префикса подразделения,
  -- чтобы формат оставался читаемым: ИСХ-{префикс}.{соль}-{номер}/{год}.
  v_run_salt   text := substr(md5(clock_timestamp()::text || random()::text), 1, 4);

  -- id этапов для выстраивания зависимостей и статусов
  v_st_h       bigint;
  v_st_c       bigint;
  v_st_sign    bigint;
  v_msg        bigint;
  r_idx        int;
BEGIN
  IF v_ndocs IS NULL OR v_ndocs < 1 THEN v_ndocs := 40; END IF;

  -- Префикс подразделения-автора и получателей (как в боевой нумерации).
  SELECT coalesce(NULLIF(numbering_prefix,''), outgoing_prefix) INTO v_out_prefix
    FROM departments WHERE id = v_author_dept;
  v_inc_prefix := ARRAY[
    (SELECT coalesce(NULLIF(numbering_prefix,''), outgoing_prefix) FROM departments WHERE id = v_recip_dept[1]),
    (SELECT coalesce(NULLIF(numbering_prefix,''), outgoing_prefix) FROM departments WHERE id = v_recip_dept[2])
  ];

  FOR i IN 1..v_ndocs LOOP
    IF i % 5000 = 0 THEN
      RAISE NOTICE 'Сгенерировано % из % документов…', i, v_ndocs;
    END IF;
    v_status  := v_statuses[1 + (i % array_length(v_statuses,1))];
    v_urgency := v_urgencies[1 + (i % array_length(v_urgencies,1))];
    v_created := now() - ((v_ndocs - i) || ' hours')::interval - (i || ' days')::interval;

    -- Срок исполнения С ВРЕМЕНЕМ (у части — просрочен, у части — в будущем).
    v_due := CASE
      WHEN i % 4 = 0 THEN NULL
      WHEN i % 3 = 0 THEN v_created + interval '2 days' + interval '17 hours'   -- просрочен
      ELSE now() + ((i % 10) || ' days')::interval + interval '15 hours 30 min'
    END;

    -- Исходящий номер и дата подписи появляются только у подписанных и далее.
    v_outnum    := NULL;
    v_signed_at := NULL;
    IF v_status IN ('signed','sent','in_progress','executed','archived') THEN
      v_seq   := v_seq + 1;
      -- Реалистичный формат как в боевой нумерации: ИСХ-{префикс}-{номер}/{год}.
      -- Соль вплетаем в префикс (ИСХ-{префикс}.{соль}-...), чтобы гарантировать
      -- отсутствие коллизий с боевыми номерами и остатками прошлых прогонов,
      -- сохранив читаемый вид. НЕ используем lpad (он усекает строку!).
      v_outnum    := format('ИСХ-%s.%s-%s/%s', v_out_prefix, v_run_salt, v_seq, v_year);
      v_signed_at := v_created + interval '1 day';
    END IF;

    -- ---- documents ----
    INSERT INTO documents (author_id, author_department_id, title, body_summary,
                           urgency, status, outgoing_number, due_date, due_datetime,
                           created_at, updated_at,
                           on_control, controller_id,
                           executed_at, archived_at)
    VALUES (
      v_author, v_author_dept,
      format('[TD] Документ №%s — %s', i, v_status),
      format('Тестовое содержание документа №%s. Срочность: %s. Сгенерировано автоматически для проверки списков и карточки.', i, v_urgency),
      v_urgency::doc_urgency, v_status::doc_status, v_outnum,
      (v_due)::date, v_due,
      v_created, v_created,
      (i % 5 = 0),                                    -- каждый 5-й на контроле
      CASE WHEN i % 5 = 0 THEN v_signer END,          -- контролёр — подписант
      CASE WHEN v_status = 'executed' THEN v_created + interval '3 days' END,
      CASE WHEN v_status = 'archived' THEN v_created + interval '5 days' END
    ) RETURNING id INTO v_doc;

    -- ---- файл-оригинал ----
    INSERT INTO document_files (document_id, content, sha256, size_bytes, uploaded_by)
    VALUES (v_doc, v_pdf, encode(sha256(v_pdf), 'hex'), length(v_pdf), v_author);

    -- ---- доступ автору и руководителю отдела ----
    INSERT INTO document_access (document_id, user_id, access_reason) VALUES
      (v_doc, v_author, 'author'),
      (v_doc, v_approver_h, 'chief_of_dept')
    ON CONFLICT DO NOTHING;

    -- ---- этапы согласования: иерархия -> межвед -> подпись ----
    -- статусы этапов согласуем с общим статусом документа.
    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, decided_at, comment)
      VALUES (v_doc, 'hierarchy', v_approver_h,
        CASE v_status
          WHEN 'draft' THEN 'waiting_deps'
          WHEN 'on_approval_hierarchy' THEN 'pending'
          WHEN 'rejected' THEN 'rejected'
          ELSE 'approved' END::stage_status,
        1,
        CASE WHEN v_status NOT IN ('draft','on_approval_hierarchy') THEN v_created + interval '4 hours' END,
        CASE WHEN v_status = 'rejected' THEN 'Отклонено на этапе иерархии (тест)' END)
      RETURNING id INTO v_st_h;

    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, decided_at)
      VALUES (v_doc, 'cross_dept', v_approver_c,
        CASE v_status
          WHEN 'draft' THEN 'waiting_deps'
          WHEN 'on_approval_hierarchy' THEN 'waiting_deps'
          WHEN 'on_approval_cross_dept' THEN 'pending'
          WHEN 'rejected' THEN 'waiting_deps'
          ELSE 'approved' END::stage_status,
        2,
        CASE WHEN v_status IN ('on_signing','signed','sent','in_progress','executed','archived')
             THEN v_created + interval '8 hours' END)
      RETURNING id INTO v_st_c;

    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, decided_at)
      VALUES (v_doc, 'signing', v_signer,
        CASE v_status
          WHEN 'on_signing' THEN 'pending'
          WHEN 'signed' THEN 'approved'
          WHEN 'sent' THEN 'approved'
          WHEN 'in_progress' THEN 'approved'
          WHEN 'executed' THEN 'approved'
          WHEN 'archived' THEN 'approved'
          ELSE 'waiting_deps' END::stage_status,
        3, v_signed_at)
      RETURNING id INTO v_st_sign;

    -- зависимости: cross_dept после hierarchy, signing после cross_dept
    INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
      VALUES (v_st_c, v_st_h), (v_st_sign, v_st_c)
    ON CONFLICT DO NOTHING;

    -- Доступ согласующим/подписанту — СТРОГО по этапу (как в реальном потоке:
    -- доступ выдаётся, только когда этап становится активным/пройден). Иначе
    -- документ «на согласовании» был бы виден будущему подписанту раньше времени.
    --   * иерархический согласующий видит, когда его этап активен или пройден:
    --     т.е. на всех статусах, кроме draft;
    --   * межведомственный — начиная со своего этапа: on_approval_cross_dept и далее;
    --   * подписант — только начиная с этапа подписи: on_signing и далее.
    IF v_status <> 'draft' THEN
      INSERT INTO document_access (document_id, user_id, access_reason)
        VALUES (v_doc, v_approver_h, 'approval_stage') ON CONFLICT DO NOTHING;
    END IF;
    IF v_status IN ('on_approval_cross_dept','on_signing','signed','sent','in_progress','executed','archived') THEN
      INSERT INTO document_access (document_id, user_id, access_reason)
        VALUES (v_doc, v_approver_c, 'approval_stage') ON CONFLICT DO NOTHING;
    END IF;
    IF v_status IN ('on_signing','signed','sent','in_progress','executed','archived') THEN
      INSERT INTO document_access (document_id, user_id, access_reason)
        VALUES (v_doc, v_signer, 'approval_stage') ON CONFLICT DO NOTHING;
    END IF;

    -- ---- подпись ----
    IF v_signed_at IS NOT NULL THEN
      INSERT INTO document_signatures (document_id, signer_id, signed_at, signature_type, signature_hash, storage_resource)
      VALUES (v_doc, v_signer, v_signed_at, 'УКЭП', encode(sha256(v_pdf || v_doc::text::bytea), 'hex'),
              format('vault://sig/%s', v_doc));
    END IF;

    -- ---- рассылка + входящие экземпляры (для разосланных) ----
    IF v_status IN ('sent','in_progress','executed','archived') THEN
      FOR r_idx IN 1..array_length(v_recipients,1) LOOP
        INSERT INTO document_recipients (document_id, recipient_user_id, recipient_department_id, is_planned, completed_at, completion_note)
        VALUES (v_doc, v_recipients[r_idx], v_recip_dept[r_idx], false,
                CASE WHEN v_status IN ('executed','archived') THEN v_created + interval '4 days' END,
                CASE WHEN v_status IN ('executed','archived') THEN 'Исполнено (тест)' END)
        ON CONFLICT (document_id, recipient_user_id) DO NOTHING;

        v_inc_seq[r_idx] := v_inc_seq[r_idx] + 1;
        INSERT INTO document_incoming_instances (document_id, receiving_department_id, received_by, incoming_number, instance_label, first_viewed_at)
        VALUES (v_doc, v_recip_dept[r_idx], v_recipients[r_idx],
                format('ВХ-%s.%s-%s/%s', v_inc_prefix[r_idx], v_run_salt, v_inc_seq[r_idx], v_year),
                format('Экз. № %s', r_idx),
                CASE WHEN v_status <> 'sent' THEN v_created + interval '2 days' END)
        ON CONFLICT (document_id, receiving_department_id) DO NOTHING;

        INSERT INTO document_access (document_id, user_id, access_reason)
        VALUES (v_doc, v_recipients[r_idx], 'recipient') ON CONFLICT DO NOTHING;
      END LOOP;
    END IF;

    -- ---- поручение (assignment) на часть документов в работе ----
    IF v_status IN ('in_progress','executed') THEN
      INSERT INTO assignments (document_id, author_id, assignee_id, controller_id, text, due_date, status, created_at)
      VALUES (v_doc, v_signer, v_recipients[1], v_signer,
              'Проработать вопрос и доложить (тестовое поручение).',
              (v_created + interval '3 days')::date,
              CASE WHEN v_status='executed' THEN 'done' ELSE 'in_progress' END,
              v_created + interval '1 day 2 hours');
      -- ознакомление ответственного (чтобы документ был «открыт»)
      INSERT INTO document_acquaintances (document_id, user_id, acquainted_by, created_at)
      VALUES (v_doc, v_recipients[1], v_signer, v_created + interval '1 day 2 hours')
      ON CONFLICT (document_id, user_id) DO NOTHING;
    END IF;

    -- ---- чат (2 сообщения) ----
    INSERT INTO chat_messages (document_id, author_id, text, created_at)
      VALUES (v_doc, v_author, 'Прошу согласовать. (тест)', v_created + interval '10 minutes')
      RETURNING id INTO v_msg;
    INSERT INTO chat_messages (document_id, author_id, text, created_at)
      VALUES (v_doc, v_approver_h, 'Замечаний нет. (тест)', v_created + interval '3 hours');

    -- ---- история ----
    INSERT INTO document_history (document_id, actor_id, event_type, to_status, created_at)
      VALUES (v_doc, v_author, 'created', 'draft'::doc_status, v_created);
    IF v_signed_at IS NOT NULL THEN
      INSERT INTO document_history (document_id, actor_id, event_type, to_status, created_at)
        VALUES (v_doc, v_signer, 'signed', 'signed'::doc_status, v_signed_at);
    END IF;

    -- ---- уведомления (в непрочитанные — по одному активному действию) ----
    IF v_status = 'on_approval_hierarchy' THEN
      INSERT INTO notifications (user_id, document_id, kind, payload, created_at)
      VALUES (v_approver_h, v_doc, 'stage_pending', '{}', v_created + interval '1 min');
    ELSIF v_status = 'on_approval_cross_dept' THEN
      INSERT INTO notifications (user_id, document_id, kind, payload, created_at)
      VALUES (v_approver_c, v_doc, 'stage_pending', '{}', v_created + interval '1 min');
    ELSIF v_status = 'on_signing' THEN
      INSERT INTO notifications (user_id, document_id, kind, payload, created_at)
      VALUES (v_signer, v_doc, 'stage_pending', '{}', v_created + interval '1 min');
    ELSIF v_status = 'sent' THEN
      INSERT INTO notifications (user_id, document_id, kind, payload, created_at)
      VALUES (v_recipients[1], v_doc, 'document_received', '{}', v_created + interval '2 days');
    END IF;

  END LOOP;

  -- numbering_sequences НЕ трогаем: тестовые номера имеют солёный префикс
  -- (ИСХ-{префикс}.{соль}-...), поэтому не пересекаются с боевыми, а боевая
  -- нумерация должна начинаться с 1 (ИСХ-{префикс}-1/{год}), а не с номера
  -- после тестовых данных.

  RAISE NOTICE 'Сгенерировано документов: %', v_ndocs;
END
$gen$;

RESET row_security;

-- Короткая сводка по сгенерированному.
SELECT status, count(*) AS docs
FROM documents WHERE title LIKE '[TD]%'
GROUP BY status ORDER BY status;
