package service

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// AccessService пересчитывает материализованную таблицу document_access.
// Это НЕ вызывается на каждое чтение — только событийно, при изменениях,
// которые могут повлиять на видимость документа:
//   - создание документа (автор получает доступ)
//   - активация этапа согласования (waiting_deps -> pending)
//   - назначение исполнителя
//   - регистрация входящего экземпляра (канцелярия/дежурный подразделения-получателя)
//   - смена статуса на signed/sent (руководители по department_closure, дежурные и канцелярия по роли в подразделении)
//
// Такой подход даёт O(1) SELECT на списки документов вместо джойнов по
// иерархиям на каждый запрос (см. repository/documents.go).
type AccessService struct{}

func NewAccessService() *AccessService { return &AccessService{} }

func (s *AccessService) grant(ctx context.Context, tx pgx.Tx, documentID, userID int64, reason string) error {
	_, err := tx.Exec(ctx, `
		INSERT INTO document_access (document_id, user_id, access_reason)
		VALUES ($1, $2, $3)
		ON CONFLICT (document_id, user_id, access_reason) DO NOTHING`, documentID, userID, reason)
	if err != nil {
		return fmt.Errorf("grant access: %w", err)
	}
	return nil
}

// GrantAuthorAccess вызывается сразу при создании документа.
func (s *AccessService) GrantAuthorAccess(ctx context.Context, tx pgx.Tx, documentID, authorID int64) error {
	return s.grant(ctx, tx, documentID, authorID, "author")
}

// GrantChiefsAccess открывает документ руководителям всех подразделений
// вверх по department_closure от автора (руководитель видит документы
// своего подразделения и всех подчинённых — по ТЗ "и указания всех
// подчинённых подразделений", т.е. обход в противоположную сторону:
// нам нужны все ancestor'ы department, у которых есть роль chief).
func (s *AccessService) GrantChiefsAccess(ctx context.Context, tx pgx.Tx, documentID, authorDepartmentID int64) error {
	rows, err := tx.Query(ctx, `
		SELECT ur.user_id
		FROM department_closure dc
		JOIN user_roles ur ON ur.department_id = dc.ancestor_id AND ur.role = 'chief'
		WHERE dc.descendant_id = $1`, authorDepartmentID)
	if err != nil {
		return fmt.Errorf("query chiefs: %w", err)
	}
	defer rows.Close()

	var chiefIDs []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return err
		}
		chiefIDs = append(chiefIDs, id)
	}
	for _, id := range chiefIDs {
		if err := s.grant(ctx, tx, documentID, id, "chief_of_dept"); err != nil {
			return err
		}
	}
	return nil
}

// GrantStageApproverAccess открывает документ конкретному согласующему,
// когда его этап переходит в pending (см. ApprovalService.propagate).
func (s *AccessService) GrantStageApproverAccess(ctx context.Context, tx pgx.Tx, documentID, approverID int64) error {
	return s.grant(ctx, tx, documentID, approverID, "approval_stage")
}

func (s *AccessService) GrantExecutorAccess(ctx context.Context, tx pgx.Tx, documentID, executorID int64) error {
	return s.grant(ctx, tx, documentID, executorID, "executor")
}

func (s *AccessService) GrantClerkAccess(ctx context.Context, tx pgx.Tx, documentID, departmentID int64) error {
	rows, err := tx.Query(ctx, `SELECT user_id FROM user_roles WHERE department_id = $1 AND role = 'clerk'`, departmentID)
	if err != nil {
		return fmt.Errorf("query clerks: %w", err)
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return err
		}
		ids = append(ids, id)
	}
	for _, id := range ids {
		if err := s.grant(ctx, tx, documentID, id, "clerk"); err != nil {
			return err
		}
	}
	return nil
}
