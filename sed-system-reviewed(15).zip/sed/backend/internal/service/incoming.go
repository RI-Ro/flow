package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

type IncomingService struct {
	numbering *NumberingService
}

func NewIncomingService(numbering *NumberingService) *IncomingService {
	return &IncomingService{numbering: numbering}
}

// IncomingMarking — то, что накладывается overlay-слоем поверх вьювера при
// отображении полученного документа (см. фронтенд DocumentViewer): номер
// входящего экземпляра и его метка.
type IncomingMarking struct {
	IncomingNumber string `json:"incoming_number"`
	InstanceLabel  string `json:"instance_label"`
}

// RegisterView вызывается при каждом открытии карточки документа (см.
// handlers.DocumentsHandler.Get). Идемпотентно: если для подразделения
// пользователя уже зарегистрирован входящий экземпляр — просто фиксирует
// first_viewed_at (если ещё не была зафиксирована) и возвращает существующую
// маркировку; если нет — атомарно выдаёт номер через NumberingService и
// создаёт запись. Возвращает nil, если этот пользователь не является
// получателем документа (нет смысла регистрировать вход для автора/
// согласующего — только для реального получателя-адресата).
func (s *IncomingService) RegisterView(ctx context.Context, tx pgx.Tx, documentID, userID int64) (*IncomingMarking, error) {
	var receivingDepartmentID int64
	err := tx.QueryRow(ctx, `
		SELECT recipient_department_id FROM document_recipients
		WHERE document_id = $1 AND recipient_user_id = $2
		LIMIT 1`, documentID, userID).Scan(&receivingDepartmentID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil // пользователь не адресат этого документа — не регистрируем
		}
		return nil, fmt.Errorf("lookup recipient: %w", err)
	}

	var existingID int64
	var existingNumber, existingLabel string
	err = tx.QueryRow(ctx, `
		SELECT id, incoming_number, coalesce(instance_label, '')
		FROM document_incoming_instances
		WHERE document_id = $1 AND receiving_department_id = $2`, documentID, receivingDepartmentID).
		Scan(&existingID, &existingNumber, &existingLabel)
	if err == nil {
		// Уже зарегистрирован ранее (кем-то из подразделения) — фиксируем
		// first_viewed_at только если это первый просмотр вообще (COALESCE
		// не перезаписывает уже установленное значение).
		_, err = tx.Exec(ctx, `
			UPDATE document_incoming_instances
			SET first_viewed_at = COALESCE(first_viewed_at, now())
			WHERE id = $1`, existingID)
		if err != nil {
			return nil, fmt.Errorf("update first_viewed_at: %w", err)
		}
		return &IncomingMarking{IncomingNumber: existingNumber, InstanceLabel: existingLabel}, nil
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return nil, fmt.Errorf("lookup existing instance: %w", err)
	}

	// Первая регистрация: считаем, какой это экземпляр по счёту для данного
	// документа (если он разослан в несколько подразделений), и выдаём номер.
	var instanceOrdinal int
	if err := tx.QueryRow(ctx, `
		SELECT count(*) + 1 FROM document_incoming_instances WHERE document_id = $1`, documentID).
		Scan(&instanceOrdinal); err != nil {
		return nil, fmt.Errorf("count instances: %w", err)
	}

	incomingNumber, err := s.numbering.NextIncoming(ctx, tx, receivingDepartmentID)
	if err != nil {
		return nil, fmt.Errorf("assign incoming number: %w", err)
	}
	instanceLabel := fmt.Sprintf("Экз. № %d", instanceOrdinal)

	// Идемпотентная вставка: при первом открытии документа возможны ДВА
	// почти одновременных запроса (React StrictMode вызывает эффекты дважды;
	// возможен и быстрый повтор). Оба проходят проверку "экземпляра нет",
	// оба доходят сюда — без ON CONFLICT второй INSERT падает на UNIQUE
	// (document_id, receiving_department_id) и роняет весь запрос Get
	// ("failed to get document"), из-за чего документ не открывался с первого
	// раза. ON CONFLICT DO NOTHING + повторное чтение делает регистрацию
	// безопасной к гонке: победитель пишет экземпляр и историю, проигравший
	// просто читает уже созданный номер.
	var insertedID int64
	err = tx.QueryRow(ctx, `
		INSERT INTO document_incoming_instances
			(document_id, receiving_department_id, received_by, incoming_number, instance_label, first_viewed_at)
		VALUES ($1, $2, $3, $4, $5, now())
		ON CONFLICT (document_id, receiving_department_id) DO NOTHING
		RETURNING id`,
		documentID, receivingDepartmentID, userID, incomingNumber, instanceLabel).Scan(&insertedID)
	if errors.Is(err, pgx.ErrNoRows) {
		// Конфликт: экземпляр уже создан параллельным запросом — читаем его.
		var num, label string
		if e := tx.QueryRow(ctx, `
			SELECT incoming_number, coalesce(instance_label,'')
			FROM document_incoming_instances
			WHERE document_id = $1 AND receiving_department_id = $2`,
			documentID, receivingDepartmentID).Scan(&num, &label); e != nil {
			return nil, fmt.Errorf("read conflicting instance: %w", e)
		}
		return &IncomingMarking{IncomingNumber: num, InstanceLabel: label}, nil
	}
	if err != nil {
		return nil, fmt.Errorf("insert incoming instance: %w", err)
	}

	// История: входящий номер присваивается ОДИН раз на подразделение-получатель
	// (даже если адресатов из него несколько) — фиксируем это событие.
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		SELECT $1, $2, 'incoming_registered',
		       'вх. № ' || $3 || ' (' || COALESCE((SELECT name FROM departments WHERE id = $4), '') || ')'`,
		documentID, userID, incomingNumber, receivingDepartmentID)
	if err != nil {
		return nil, fmt.Errorf("insert incoming history: %w", err)
	}

	return &IncomingMarking{IncomingNumber: incomingNumber, InstanceLabel: instanceLabel}, nil
}
