// По умолчанию API_URL пустой -> запросы идут на относительные пути
// (/api/..., /ws/...), которые Vite dev-proxy направляет на бэкенд через
// тот же origin. Так браузер не делает cross-origin запросов и CORS не
// участвует вообще. Если нужно бить в API напрямую (напр. в проде, когда
// фронт и API на разных доменах) — задайте VITE_API_URL.
const API_URL = import.meta.env.VITE_API_URL || ''

function getToken() {
  return localStorage.getItem('sed_token')
}

// wsBase возвращает абсолютный origin для WebSocket. new WebSocket() требует
// абсолютный ws://|wss:// URL — относительный путь не примет. Если API_URL
// задан (прямой режим) — берём его; иначе (режим Vite-прокси) строим из
// текущего window.location, чтобы WS шёл на тот же origin (5173) и Vite
// проксировал его на бэкенд.
function wsBase() {
  if (API_URL) return API_URL.replace(/^http/, 'ws')
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${proto}://${window.location.host}`
}

async function request(path, options = {}) {
  const token = getToken()
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  }
  if (token) headers.Authorization = `Bearer ${token}`

  const res = await fetch(`${API_URL}${path}`, { ...options, headers })
  if (res.status === 401) {
    // Токен истёк/недействителен — не оставляем пользователя в подвешенном
    // состоянии с непонятными ошибками: чистим токен и уводим на вход.
    try { localStorage.removeItem('sed_token') } catch (_) { /* noop */ }
    if (!location.pathname.startsWith('/login')) location.assign('/login')
    throw new Error('Сессия истекла, войдите заново')
  }
  if (!res.ok) {
    let message = `Ошибка ${res.status}`
    try {
      const body = await res.json()
      if (body.error) message = body.error
    } catch (_) {
      /* тело не JSON — оставляем дефолтное сообщение */
    }
    throw new Error(message)
  }
  const contentType = res.headers.get('content-type') || ''
  if (contentType.includes('application/json')) return res.json()
  return res.blob()
}

export const api = {
  login: (login, password) =>
    request('/api/auth/login', { method: 'POST', body: JSON.stringify({ login, password }) }),
  // Проактивное обновление токена, чтобы активная сессия не истекала.
  refreshToken: () => request('/api/auth/refresh', { method: 'POST' }),
  getMe: () => request('/api/me'),
  getAppConfig: () => request('/api/app-config'),
  getDocumentMarking: (id) => request(`/api/documents/${id}/marking`),

  listUsers: () => request('/api/users'),

  // Серверный поиск кандидатов для шага маршрута. group: hierarchy|cross_dept|signing.
  // Возвращает пустой список, пока q пустой (защита от загрузки 300-500 человек).
  searchCandidates: ({ group, q, departmentId, limit = 20 } = {}) => {
    const params = new URLSearchParams({ group, q: q || '', limit: String(limit) })
    if (departmentId) params.set('department_id', String(departmentId))
    return request(`/api/users/candidates?${params.toString()}`)
  },

  listDepartments: () => request('/api/departments'),

  // multipart/form-data: без Content-Type — браузер сам проставит boundary.
  createDocument: async (formData) => {
    const token = getToken()
    const res = await fetch(`${API_URL}/api/documents`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try {
        const body = await res.json()
        if (body.error) message = body.error
      } catch (_) {
        /* тело не JSON */
      }
      throw new Error(message)
    }
    return res.json()
  },

  listDocuments: ({ category = 'all', page = 1, pageSize, departmentId, year } = {}) => {
    const params = new URLSearchParams({ category, page: String(page) })
    if (pageSize) params.set('page_size', String(pageSize))
    if (departmentId) params.set('department_id', String(departmentId))
    if (year) params.set('year', String(year))
    return request(`/api/documents?${params.toString()}`)
  },

  // Возвращает { document, incoming_marking }; incoming_marking заполнен,
  // только если текущий пользователь — зарегистрированный получатель.
  getDocument: (id) => request(`/api/documents/${id}`),

  // Направление рассылке. recipients: [{ user_id, department_id }].
  // Пустой массив -> бэкенд активирует плановых адресатов (выбранных при создании).
  sendDocument: (id, recipients = []) =>
    request(`/api/documents/${id}/send`, {
      method: 'POST',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({
          user_id: Number(r.user_id ?? r.id),
          department_id: Number(r.department_id),
        })),
      }),
    }),

  getStages: (id) => request(`/api/documents/${id}/stages`),

  getMyRoles: (id) => request(`/api/documents/${id}/my-roles`),
  getDashboardStats: () => request('/api/dashboard/stats'),

  getRegistry: (kind, year) => request(`/api/registry/${kind}${year ? `?year=${year}` : ''}`),
  downloadRegistryCsv: async (kind, year) => {
    const token = localStorage.getItem('sed_token')
    const res = await fetch(`${API_URL}/api/registry/${kind}/export${year ? `?year=${year}` : ''}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) throw new Error(`Ошибка ${res.status}`)
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `registry_${kind}${year ? `_${year}` : ''}.xlsx`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  },
  getLinks: (id) => request(`/api/documents/${id}/links`),
  // Связь с системным документом (мультивыбор делается на фронте по одному вызову на документ).
  createLink: (id, targetDocumentId, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ target_document_id: Number(targetDocumentId), link_type: linkType }),
    }),
  // Связь-заметка на несистемный (бумажный/внешний) документ.
  createLinkNote: (id, textNote, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ text_note: textNote, link_type: linkType }),
    }),
  // Поиск системных документов для связывания (частичное совпадение, ILIKE).
  searchSystemDocuments: (q) =>
    request(`/api/documents/search?q=${encodeURIComponent(q)}&page=1&page_size=10`),

  getAssignments: (id) => request(`/api/documents/${id}/assignments`),
  createAssignment: (id, { assigneeId, controllerId, text, dueDate }) =>
    request(`/api/documents/${id}/assignments`, {
      method: 'POST',
      body: JSON.stringify({
        assignee_id: Number(assigneeId),
        controller_id: controllerId ? Number(controllerId) : 0,
        text,
        due_date: dueDate || '',
      }),
    }),
  updateAssignment: (id, status, resultNote) =>
    request(`/api/assignments/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status, result_note: resultNote || '' }),
    }),

  getNotifications: ({ onlyUnread = false, limit = 50 } = {}) =>
    request(`/api/notifications?only_unread=${onlyUnread}&limit=${limit}`),
  markNotificationRead: (id) => request(`/api/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: () => request('/api/notifications/read-all', { method: 'POST' }),

  // Расширенный поиск/фильтр по ВСЕМ атрибутам документа. Любой параметр опционален.
  searchDocuments: (f = {}) => {
    const params = new URLSearchParams({ page: String(f.page || 1) })
    const set = (k, v) => { if (v !== undefined && v !== null && v !== '') params.set(k, String(v)) }
    set('category', f.category)
    set('q', f.q)
    set('author_id', f.authorId)
    set('signer_id', f.signerId)
    set('controller_id', f.controllerId)
    set('approver_id', f.approverId)
    set('recipient_id', f.recipientId)
    set('department_id', f.departmentId)
    set('status', f.status)
    set('urgency', f.urgency)
    set('on_control', f.onControl)
    set('number', f.number)
    set('incoming_number', f.incomingNumber)
    set('signed_from', f.signedFrom)
    set('signed_to', f.signedTo)
    set('created_from', f.createdFrom)
    set('created_to', f.createdTo)
    set('due_from', f.dueFrom)
    set('due_to', f.dueTo)
    set('page_size', f.pageSize)
    return request(`/api/documents/search?${params.toString()}`)
  },
  getHistory: (id) => request(`/api/documents/${id}/history`),
  getViews: (id) => request(`/api/documents/${id}/views`),
  getRecipients: (id) => request(`/api/documents/${id}/recipients`),
  // Пакетные счётчики адресатов для страницы списка (без N+1).
  recipientsCounts: (ids = []) =>
    ids.length ? request(`/api/recipients-counts?ids=${ids.join(',')}`) : Promise.resolve({ counts: {} }),
  // Ознакомление.
  getAcquaintances: (id) => request(`/api/documents/${id}/acquaintances`),
  acquaintCandidates: (q = '') => request(`/api/acquaint-candidates?q=${encodeURIComponent(q)}`),
  acquaint: (id, userIds = []) =>
    request(`/api/documents/${id}/acquaint`, {
      method: 'POST',
      body: JSON.stringify({ user_ids: userIds.map(Number) }),
    }),
  completeDocument: (id, note) =>
    request(`/api/documents/${id}/complete`, { method: 'POST', body: JSON.stringify({ note }) }),
  updateDocument: (id, patch) =>
    request(`/api/documents/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),

  // Замена PDF-оригинала до подписи (multipart). Сбрасывает согласование.
  replaceDocumentFile: async (id, file) => {
    const token = getToken()
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch(`${API_URL}/api/documents/${id}/file`, {
      method: 'PATCH',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: fd,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) message = b.error } catch (_) { /* noop */ }
      throw new Error(message)
    }
    return true
  },
  deleteDocument: (id) => request(`/api/documents/${id}`, { method: 'DELETE' }),
  updateRoute: (id, route) =>
    request(`/api/documents/${id}/route`, { method: 'PATCH', body: JSON.stringify(route) }),
  updatePlannedRecipients: (id, recipients) =>
    request(`/api/documents/${id}/planned-recipients`, {
      method: 'PATCH',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({ user_id: Number(r.id), department_id: Number(r.department_id) })),
      }),
    }),
  setControl: (id, onControl, controllerId) =>
    request(`/api/documents/${id}/control`, {
      method: 'POST',
      body: JSON.stringify({ on_control: onControl, controller_id: controllerId ? Number(controllerId) : 0 }),
    }),

  // Файл отдаётся только через авторизованный запрос (Authorization header),
  // не по прямой ссылке с токеном в query — иначе токен утекает в логи
  // прокси/браузера. Компонент вьювера сам создаёт object URL из blob.
  getDocumentFileBlob: (id) => request(`/api/documents/${id}/file`),

  decideStage: (documentId, stageId, approve, comment, extra) =>
    request(`/api/documents/${documentId}/stages/${stageId}/decide`, {
      method: 'POST',
      body: JSON.stringify({ approve, comment, ...(extra || {}) }),
    }),

  // Обсуждение документа.
  getChatHistory: (id) => request(`/api/documents/${id}/chat`),
  postChatMessage: async (id, text, files = []) => {
    const fd = new FormData()
    fd.append('text', text || '')
    for (const f of files) fd.append('files', f)
    const token = getToken()
    const res = await fetch(`${API_URL}/api/documents/${id}/chat`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: fd,
    })
    if (!res.ok) {
      let m = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) m = b.error } catch (_) { /* noop */ }
      throw new Error(m)
    }
    return res.json()
  },
  downloadChatAttachment: async (aid, fileName) => {
    const token = getToken()
    const res = await fetch(`${API_URL}/api/chat/attachments/${aid}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) throw new Error('Не удалось скачать вложение')
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = fileName || 'attachment'
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  },
  editChatMessage: (mid, text) =>
    request(`/api/chat/messages/${mid}`, { method: 'PATCH', body: JSON.stringify({ text }) }),
  deleteChatMessage: (mid) => request(`/api/chat/messages/${mid}`, { method: 'DELETE' }),

  wsURL: (documentId) => {
    const token = getToken()
    return `${wsBase()}/ws/documents/${documentId}/chat?token=${encodeURIComponent(token || '')}`
  },

  wsNotificationsURL: () => {
    const token = getToken()
    return `${wsBase()}/ws/notifications?token=${encodeURIComponent(token || '')}`
  },
}

export function setToken(token) {
  localStorage.setItem('sed_token', token)
}

export function clearToken() {
  localStorage.removeItem('sed_token')
}

export function isAuthenticated() {
  return !!getToken()
}
