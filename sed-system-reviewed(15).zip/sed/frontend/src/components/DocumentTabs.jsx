import React, { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import PersonPicker from './PersonPicker'
import SendPanel from './SendPanel'
import { fmtDateTime } from '../utils/format'

const LINK_TYPE_LABELS = {
  related: 'Связанный',
  reply_to: 'В ответ на',
  in_pursuance_of: 'Во исполнение',
  annuls: 'Отменяет',
  appendix: 'Приложение',
}

const STATUS_LABELS = {
  created: 'Создан', edited: 'Изменён', stage_approved: 'Согласовано',
  stage_rejected: 'Отклонено', signed: 'Подписано', sent: 'Отправлено',
  approver_added: 'Направлено на доп. согласование',
  status_changed: 'Смена статуса', received: 'Получено', completed: 'Исполнено',
  incoming_registered: 'Присвоен входящий номер', put_on_control: 'Поставлен на контроль',
  removed_from_control: 'Снят с контроля', assignment_created: 'Дано поручение',
  assignment_completed: 'Поручение исполнено', acquainted: 'Ознакомление',
  archived: 'Передан в архив',
}

// Технологические события маршрута/служебные — пользователю не показываем
// (они шумят и не несут смысла для человека). Показываем только значимые.
const HIDDEN_HISTORY_EVENTS = new Set(['route_changed', 'route_rebuilt', 'access_granted', 'access_revoked'])

function fmt(dt) {
  if (!dt) return ''
  try { return fmtDateTime(dt) } catch { return dt }
}

// Вкладки карточки документа: Маршрут | История | Просмотры | Рассылка.
// Рассылка включает кнопку "Отметить исполнение" для текущего получателя.
export default function DocumentTabs({ documentId, currentUserId, routeSlot, onChanged, docStatus, doc, patchDoc }) {
  const [tab, setTab] = useState('route')
  const [roles, setRoles] = useState(null)
  const [history, setHistory] = useState(null)
  const [views, setViews] = useState(null)
  const [recipients, setRecipients] = useState(null)
  const [links, setLinks] = useState(null)
  const [linkMode, setLinkMode] = useState('system') // 'system' | 'external'
  const [linkDocs, setLinkDocs] = useState([]) // мультивыбор системных документов
  const [linkSearch, setLinkSearch] = useState('')
  const [linkSearchResults, setLinkSearchResults] = useState([])
  const [linkNote, setLinkNote] = useState('') // текст для несистемного документа
  const [linkType, setLinkType] = useState('related')
  const [assignments, setAssignments] = useState(null)
  const [asgAssignees, setAsgAssignees] = useState([]) // мультивыбор ответственных
  const [asgText, setAsgText] = useState('')
  const [asgDue, setAsgDue] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const loadTab = useCallback(async (t) => {
    setError('')
    try {
      if (t === 'history' && !history) setHistory((await api.getHistory(documentId)).items || [])
      if (t === 'views' && !views) setViews((await api.getViews(documentId)).items || [])
      if (t === 'recipients') setRecipients((await api.getRecipients(documentId)).items || [])
      if (t === 'links') setLinks((await api.getLinks(documentId)).items || [])
      if (t === 'assignments') setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    }
  }, [documentId, history, views])

  useEffect(() => { loadTab(tab) }, [tab, loadTab])

  useEffect(() => {
    api.getMyRoles(documentId).then(setRoles).catch(() => setRoles(null))
  }, [documentId])

  async function markComplete() {
    setBusy(true); setError('')
    try {
      await api.completeDocument(documentId, note)
      setNote('')
      setRecipients((await api.getRecipients(documentId)).items || [])
      onChanged?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const myRecipient = recipients?.find((r) => r.user_id === currentUserId)

  // Участие пользователя определяет, какие вкладки показывать. Базовые
  // (маршрут/история/просмотры/связанные) видят все с доступом к документу.
  // Рассылка и поручения — только участникам (автор, подписант, получатель,
  // контролёр), чтобы не показывать посторонним лишние управляющие вкладки.
  // Роли берём из /my-roles (надёжный источник). Пока не загрузились —
  // показываем базовые вкладки. Рассылка/поручения — только участникам.
  const isParticipant = roles
    ? roles.is_author || roles.is_controller || roles.is_signer || roles.is_approver || roles.is_recipient || roles.is_admin
    : false
  const isApprovalParticipant = roles
    ? roles.is_author || roles.is_approver || roles.is_signer || roles.is_admin
    : true

  // Права управления: связи и направление — только автор/подписант.
  const canManage = !!(roles && (roles.is_author || roles.is_signer || roles.is_admin))
  const canSend = canManage && ['signed', 'sent', 'in_progress', 'executed'].includes(docStatus)
  // Ознакамливать вправе получатель документа (дежурный/канцелярия).
  const canAcquaint = !!myRecipient

  const TABS = [
    ...(isApprovalParticipant ? [{ id: 'route', label: 'Маршрут' }] : []),
    { id: 'history', label: 'История' },
    { id: 'views', label: 'Просмотры' },
    ...(isParticipant ? [{ id: 'recipients', label: 'Рассылка' }] : []),
    { id: 'links', label: 'Связанные' },
    ...(isParticipant ? [{ id: 'assignments', label: 'Поручения' }] : []),
    { id: 'control', label: doc?.on_control ? 'На контроле ●' : 'Контроль' },
  ]

  // Поиск системных документов для связывания (ILIKE, частичное совпадение).
  useEffect(() => {
    if (linkMode !== 'system' || !linkSearch.trim()) { setLinkSearchResults([]); return }
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const res = await api.searchSystemDocuments(linkSearch.trim())
        if (!cancelled) setLinkSearchResults((res.items || []).filter((d) => String(d.id) !== String(documentId)))
      } catch (_) { if (!cancelled) setLinkSearchResults([]) }
    }, 300)
    return () => { cancelled = true; clearTimeout(t) }
  }, [linkSearch, linkMode, documentId])

  const pickLinkDoc = (d) => {
    if (linkDocs.some((x) => x.id === d.id)) return
    setLinkDocs([...linkDocs, { id: d.id, title: d.title, number: d.outgoing_number || `#${d.id}` }])
    setLinkSearch('')
    setLinkSearchResults([])
  }

  async function addLink() {
    setBusy(true); setError('')
    try {
      if (linkMode === 'system') {
        if (linkDocs.length === 0) return
        // Мультивыбор: одна связь на каждый выбранный системный документ.
        for (const d of linkDocs) {
          await api.createLink(documentId, d.id, linkType)
        }
        setLinkDocs([])
      } else {
        if (!linkNote.trim()) return
        await api.createLinkNote(documentId, linkNote.trim(), linkType)
        setLinkNote('')
      }
      setLinks((await api.getLinks(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function addAssignment() {
    if (asgAssignees.length === 0 || !asgText) return
    setBusy(true); setError('')
    try {
      // По одному поручению на каждого выбранного ответственного — так можно
      // раздать одно поручение сразу нескольким людям/группам.
      for (const person of asgAssignees) {
        await api.createAssignment(documentId, { assigneeId: person.id, text: asgText, dueDate: asgDue })
      }
      setAsgAssignees([]); setAsgText(''); setAsgDue('')
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function changeAssignmentStatus(id, status) {
    setBusy(true); setError('')
    try {
      await api.updateAssignment(id, status)
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="bg-surface border border-border rounded-lg overflow-hidden flex flex-col h-full">
      <div className="flex flex-wrap border-b border-border shrink-0 gap-x-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-2.5 py-2 text-xs whitespace-nowrap ${
              tab === t.id ? 'border-b-2 border-accent text-text-primary' : 'text-text-secondary'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="p-3 flex-1 min-h-0 overflow-auto">
        {error && <div className="text-danger text-xs mb-2">{error}</div>}

        {tab === 'route' && routeSlot}
        {tab === 'control' && (
          <ControlTab
            documentId={documentId}
            doc={doc}
            canManage={canManage}
            patchDoc={patchDoc}
          />
        )}

        {tab === 'history' && (
          <ol className="space-y-1.5 text-sm">
            {(history || []).filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).map((e, i) => (
              <li key={i} className="flex justify-between border-b border-border last:border-0 pb-1.5">
                <span>
                  {STATUS_LABELS[e.event_type] || e.event_type}
                  {e.actor_name && <span className="text-text-secondary"> — {e.actor_name}</span>}
                  {e.comment && <span className="text-text-secondary"> «{e.comment}»</span>}
                </span>
                <span className="kicker whitespace-nowrap ml-2">{fmt(e.created_at)}</span>
              </li>
            ))}
            {history && history.filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).length === 0 && (
              <div className="text-text-secondary text-xs">Событий нет</div>
            )}
          </ol>
        )}

        {tab === 'views' && (
          <ol className="space-y-1 text-sm">
            {(views || []).map((v, i) => (
              <li key={i} className="flex justify-between border-b border-border last:border-0 pb-1">
                <span>{v.viewer_name}</span>
                <span className="kicker">{fmt(v.viewed_at)}</span>
              </li>
            ))}
            {views && views.length === 0 && <div className="text-text-secondary text-xs">Просмотров нет</div>}
          </ol>
        )}

        {tab === 'recipients' && (
          <div>
            <ul className="space-y-1.5 text-sm mb-3">
              {(recipients || []).map((r) => (
                <li key={r.user_id} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  <span>
                    {r.full_name}
                    {r.department_name && <span className="text-text-secondary"> · {r.department_name}</span>}
                    {r.incoming_number && <span className="kicker ml-1">{r.incoming_number}</span>}
                  </span>
                  <span className={r.completed_at ? 'text-success text-xs' : 'text-text-secondary text-xs'}>
                    {r.completed_at ? `исполнено ${fmt(r.completed_at)}` : 'ожидает'}
                  </span>
                </li>
              ))}
              {recipients && recipients.length === 0 && (
                <div className="text-text-secondary text-xs">Документ ещё не направлен</div>
              )}
            </ul>

            {/* Направление рассылке — автор/подписант, во вкладке «Рассылка»,
                с учётом уже показанных выше адресатов. */}
            {canSend && (
              <div className="border-t border-border pt-3 mb-3">
                <SendPanel
                  documentId={documentId}
                  plannedHint={docStatus === 'signed'}
                  excludeIds={(recipients || []).map((r) => r.user_id)}
                  onSent={async () => {
                    setRecipients((await api.getRecipients(documentId)).items || [])
                    onChanged?.()
                  }}
                />
              </div>
            )}

            {/* Ознакомление — получатель (дежурный/канцелярия) может ознакомить
                людей из административно назначенных ему подразделений. */}
            {canAcquaint && (
              <AcquaintBlock
                documentId={documentId}
                onDone={async () => {
                  setRecipients((await api.getRecipients(documentId)).items || [])
                  onChanged?.()
                }}
              />
            )}

            {/* Отметка исполнения — только если я получатель и ещё не отметил */}
            {myRecipient && !myRecipient.completed_at && (
              <div className="border-t border-border pt-3">
                <p className="text-xs text-text-secondary mb-2">Отметить исполнение своей части:</p>
                <input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Комментарий (необязательно)"
                  className="w-full mb-2 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                />
                <button
                  onClick={markComplete}
                  disabled={busy}
                  className="w-full py-1.5 rounded-md bg-success text-white text-sm font-medium disabled:opacity-60"
                >
                  {busy ? 'Отметка…' : 'Отметить исполненным'}
                </button>
              </div>
            )}
          </div>
        )}

        {tab === 'links' && (
          <div className="p-1">
            <ul className="space-y-1.5 text-sm mb-3">
              {(links || []).map((l, i) => (
                <li key={i} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  {l.document_id ? (
                    // Системный документ — кликабельная ссылка.
                    <Link to={`/document/${l.document_id}`} className="text-accent hover:underline">
                      <span className="kicker mr-1">{l.number}</span>
                      {l.title}
                    </Link>
                  ) : (
                    // Несистемный (внешний/бумажный) документ — простой текст.
                    <span className="text-text-primary">
                      <span className="kicker mr-1">внешний</span>
                      {l.text_note}
                    </span>
                  )}
                  <span className="text-xs text-text-secondary whitespace-nowrap ml-2">
                    {LINK_TYPE_LABELS[l.link_type] || l.link_type}
                    {l.document_id ? (l.direction === 'incoming' ? ' ↩' : ' ↪') : ''}
                  </span>
                </li>
              ))}
              {links && links.length === 0 && (
                <div className="text-text-secondary text-xs">Связанных документов нет</div>
              )}
            </ul>

            <div className="border-t border-border pt-2 space-y-2">
              {!canManage && (
                <div className="text-xs text-text-secondary">Добавлять связи может только автор или подписант.</div>
              )}
              {canManage && (
              <>
              {/* Переключатель вида связи */}
              <div className="flex gap-1 text-xs">
                <button type="button" onClick={() => setLinkMode('system')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'system' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Документ из системы
                </button>
                <button type="button" onClick={() => setLinkMode('external')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'external' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Внешний документ
                </button>
              </div>

              {linkMode === 'system' && (
                <div className="relative">
                  {linkDocs.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-1">
                      {linkDocs.map((d) => (
                        <span key={d.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                          <span className="kicker">{d.number}</span>{d.title}
                          <button type="button" className="text-danger ml-0.5" onClick={() => setLinkDocs(linkDocs.filter((x) => x.id !== d.id))}>×</button>
                        </span>
                      ))}
                    </div>
                  )}
                  <input
                    value={linkSearch}
                    onChange={(e) => setLinkSearch(e.target.value)}
                    placeholder="Поиск документа по названию/номеру…"
                    className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                  />
                  {linkSearchResults.length > 0 && (
                    <div className="absolute z-20 mt-1 w-full max-h-48 overflow-auto bg-surface border border-border rounded-md shadow-lg">
                      {linkSearchResults.map((d) => (
                        <button key={d.id} type="button" onClick={() => pickLinkDoc(d)}
                          className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                          <span className="kicker mr-1">{d.outgoing_number || `#${d.id}`}</span>{d.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {linkMode === 'external' && (
                <input
                  value={linkNote}
                  onChange={(e) => setLinkNote(e.target.value)}
                  placeholder="Реквизиты внешнего документа (напр. «Приказ № 12 от 01.03.2025»)"
                  className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                />
              )}

              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="block text-xs text-text-secondary mb-1">Тип связи</label>
                  <select value={linkType} onChange={(e) => setLinkType(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm">
                    {Object.entries(LINK_TYPE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <button onClick={addLink}
                  disabled={busy || (linkMode === 'system' ? linkDocs.length === 0 : !linkNote.trim())}
                  className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm disabled:opacity-60">
                  Связать
                </button>
              </div>
              </>
              )}
            </div>
          </div>
        )}

        {tab === 'assignments' && (
          <div className="p-4">
            <div className="space-y-2 mb-4">
              {(assignments || []).map((a) => (
                <div key={a.id} className="border border-border rounded-md p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="text-sm">{a.text}</div>
                      <div className="text-xs text-text-secondary mt-1">
                        Ответственный: {a.assignee_name}
                        {a.due_date && ` · срок ${fmtDateTime(a.due_date)}`}
                        {' · '}от {a.author_name}
                      </div>
                      {a.result_note && (
                        <div className="text-xs mt-1 text-text-secondary">Результат: {a.result_note}</div>
                      )}
                    </div>
                    <select
                      value={a.status}
                      onChange={(e) => changeAssignmentStatus(a.id, e.target.value)}
                      disabled={busy}
                      className="text-xs px-2 py-1 rounded border border-border bg-surface-alt"
                    >
                      <option value="open">Открыто</option>
                      <option value="in_progress">В работе</option>
                      <option value="done">Выполнено</option>
                      <option value="cancelled">Отменено</option>
                    </select>
                  </div>
                </div>
              ))}
              {assignments && assignments.length === 0 && (
                <div className="text-sm text-text-secondary">Поручений нет</div>
              )}
            </div>

            <div className="border-t border-border pt-3 space-y-2">
              <div className="text-xs text-text-secondary">Новое поручение</div>
              <input
                value={asgText}
                onChange={(e) => setAsgText(e.target.value)}
                placeholder="Текст поручения"
                className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
              />
              <PersonPicker
                group="all"
                multiple
                value={asgAssignees}
                onChange={setAsgAssignees}
                excludeIds={[currentUserId].filter(Boolean)}
              />
              <div className="flex gap-2 items-center">
                <input
                  type="date"
                  value={asgDue}
                  onChange={(e) => setAsgDue(e.target.value)}
                  className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                />
                <button
                  onClick={addAssignment}
                  disabled={busy || asgAssignees.length === 0 || !asgText}
                  className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm disabled:opacity-60"
                >
                  Дать поручение{asgAssignees.length > 1 ? ` (${asgAssignees.length})` : ''}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// AcquaintBlock — ознакомление сотрудников с документом. Кандидаты — только из
// административно назначенных текущему пользователю подразделений (бэкенд
// /acquaint-candidates фильтрует). Мультивыбор.
function AcquaintBlock({ documentId, onDone }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [picked, setPicked] = useState([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [list, setList] = useState([])

  useEffect(() => {
    api.getAcquaintances(documentId).then((r) => setList(r.items || [])).catch(() => {})
  }, [documentId])

  useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const r = await api.acquaintCandidates(q.trim())
        if (!cancelled) setResults(r.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      }
    }, q.trim() ? 250 : 0)
    return () => { cancelled = true; clearTimeout(t) }
  }, [q, open])

  async function submit() {
    if (picked.length === 0) return
    setBusy(true); setError('')
    try {
      await api.acquaint(documentId, picked.map((p) => p.id))
      setPicked([])
      setOpen(false)
      setList((await api.getAcquaintances(documentId)).items || [])
      onDone?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const pickedIds = new Set(picked.map((p) => p.id))

  return (
    <div className="border-t border-border pt-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs text-text-secondary">Ознакомление</p>
        <button onClick={() => setOpen((v) => !v)} className="text-xs text-accent">
          {open ? 'Скрыть' : 'Ознакомить сотрудников'}
        </button>
      </div>

      {list.length > 0 && (
        <ul className="text-xs text-text-secondary mb-2 space-y-0.5">
          {list.map((a) => (
            <li key={a.user_id}>
              {a.full_name} <span className="opacity-70">— ознакомил {a.acquainted_by_name}</span>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div>
          {picked.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-1">
              {picked.map((p) => (
                <span key={p.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                  {p.full_name}
                  <button type="button" className="text-danger ml-0.5" onClick={() => setPicked(picked.filter((x) => x.id !== p.id))}>×</button>
                </span>
              ))}
            </div>
          )}
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск сотрудника для ознакомления…"
            className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm mb-1"
          />
          <div className="max-h-40 overflow-auto border border-border rounded-md mb-2">
            {results.filter((r) => !pickedIds.has(r.id)).length === 0 && (
              <div className="px-3 py-2 text-xs text-text-secondary">
                {q.trim() ? 'Ничего не найдено' : 'Нет доступных для ознакомления сотрудников'}
              </div>
            )}
            {results.filter((r) => !pickedIds.has(r.id)).map((r) => (
              <button key={r.id} type="button"
                onClick={() => { setPicked([...picked, r]); setQ('') }}
                className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                {r.full_name}
                {r.department_name && <span className="text-text-secondary text-xs ml-2">{r.department_name}</span>}
              </button>
            ))}
          </div>
          {error && <div className="text-danger text-xs mb-1">{error}</div>}
          <button onClick={submit} disabled={busy || picked.length === 0}
            className="w-full py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-60">
            {busy ? 'Ознакомление…' : `Ознакомить (${picked.length})`}
          </button>
        </div>
      )}
    </div>
  )
}

// ControlTab — постановка/снятие с контроля и выбор/смена контролёра.
// Автор (canManage) может менять; остальные видят статус.
function ControlTab({ documentId, doc, canManage, patchDoc }) {
  const [onControl, setOnControl] = useState(!!doc?.on_control)
  const [controller, setController] = useState(
    doc?.controller_id ? [{ id: doc.controller_id, full_name: doc.controller_name || 'Контролёр' }] : [],
  )
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)

  async function save() {
    setBusy(true); setError(''); setSaved(false)
    try {
      await api.setControl(documentId, onControl, controller[0]?.id || 0)
      setSaved(true)
      // Локальное обновление — без перезагрузки всей карточки/просмотрщика.
      patchDoc?.({
        on_control: onControl,
        controller_id: controller[0]?.id || null,
        controller_name: controller[0]?.full_name || null,
      })
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  if (!canManage) {
    return (
      <div className="p-1 text-sm">
        {doc?.on_control ? (
          <div className="text-danger">● Документ на контроле{doc.controller_name ? ` — контролёр: ${doc.controller_name}` : ''}</div>
        ) : (
          <div className="text-text-secondary">Документ не на контроле</div>
        )}
      </div>
    )
  }

  return (
    <div className="p-1 space-y-3">
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
        Документ на контроле
      </label>
      {onControl && (
        <div>
          <label className="block text-xs text-text-secondary mb-1">Контролёр</label>
          <PersonPicker group="all" multiple={false} value={controller} onChange={setController} />
        </div>
      )}
      {error && <div className="text-danger text-xs">{error}</div>}
      {saved && <div className="text-success text-xs">Сохранено</div>}
      <button onClick={save} disabled={busy}
        className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-60">
        {busy ? 'Сохранение…' : 'Сохранить'}
      </button>
    </div>
  )
}
