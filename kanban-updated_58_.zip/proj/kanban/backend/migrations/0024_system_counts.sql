-- =====================================================================
-- 0024. Счётчики объёма системы для метрик
--
-- Метрика kanban_entities (сколько в системе проектов, задач, досок)
-- считалась обычным запросом от имени рабочей роли — и всегда выдавала
-- нули. Причина в том, что политики RLS честно отрабатывают и здесь:
-- опрос метрик идёт вне пользовательской транзакции, app.user_id не
-- задан, app.current_user_id() равен NULL, и ни одна строка проверку не
-- проходит. Метрика выглядела работающей: серия в выдаче была, значения
-- выводились — просто нулевые.
--
-- Правильный путь для таких подсчётов — функция с правами владельца.
-- Отдаёт она только итоговые числа: ни названий проектов, ни имён, ни
-- содержимого задач. Знать, что в системе 1240 задач, не значит иметь
-- к ним доступ, поэтому обхода политик здесь не возникает.
--
-- Миграция идемпотентна: CREATE OR REPLACE.
-- =====================================================================

CREATE OR REPLACE FUNCTION app.system_counts()
RETURNS TABLE (kind text, n bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT 'boards',  count(*) FROM app.boards WHERE NOT archived
    UNION ALL SELECT 'boards_archived', count(*) FROM app.boards WHERE archived
    UNION ALL SELECT 'tasks', count(*) FROM app.tasks WHERE NOT archived
    UNION ALL SELECT 'tasks_open', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
    UNION ALL SELECT 'tasks_done', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NOT NULL
    UNION ALL SELECT 'tasks_overdue', count(*) FROM app.tasks
              WHERE NOT archived AND completed_at IS NULL
                AND due_date IS NOT NULL AND due_date < current_date
    UNION ALL SELECT 'tasks_archived', count(*) FROM app.tasks WHERE archived
    UNION ALL SELECT 'users', count(*) FROM app.users WHERE deleted_at IS NULL
    UNION ALL SELECT 'users_active', count(*) FROM app.users
              WHERE is_active AND deleted_at IS NULL
    UNION ALL SELECT 'users_online_day', count(DISTINCT user_id)
              FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND created_at > now() - interval '1 day'
    UNION ALL SELECT 'comments', count(*) FROM app.comments
    UNION ALL SELECT 'attachments', count(*) FROM app.attachments
    UNION ALL SELECT 'charts', count(*) FROM app.charts
    UNION ALL SELECT 'whiteboards', count(*) FROM app.whiteboards
    UNION ALL SELECT 'chats', count(*) FROM app.chats
    UNION ALL SELECT 'chat_messages', count(*) FROM app.chat_messages
    UNION ALL SELECT 'reminders', count(*) FROM app.reminders
    UNION ALL SELECT 'notifications_unread', count(*) FROM app.notifications
              WHERE read_at IS NULL
    UNION ALL SELECT 'sessions', count(*) FROM app.refresh_tokens
              WHERE revoked_at IS NULL AND expires_at > now()
$$;

COMMENT ON FUNCTION app.system_counts() IS
    'Итоговые количества объектов для метрик. Только числа: содержимого '
    'не отдаёт, поэтому обхода политик доступа не создаёт.';

-- Право вызова отзывается у PUBLIC и выдаётся адресно: по умолчанию
-- PostgreSQL разрешает EXECUTE всем, а у функции с правами
-- владельца такой подарок лишний.
REVOKE EXECUTE ON FUNCTION app.system_counts() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app.system_counts() TO app_user;
