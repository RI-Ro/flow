package metrics

import (
	"context"
	"math"
	"sort"
	"strings"
	"sync"
	"time"
)

// Sampler — хранилище истории метрик внутри приложения.
//
// Это тот самый кусок работы, который в обычной схеме делает
// Prometheus: раз в несколько секунд снимает показания и складывает их
// в память, а при запросе считает по накопленному скорости и
// перцентили. Понадобилось потому, что встроенный дашборд должен
// открываться с готовыми графиками, а не рисовать линию с нуля от
// момента, когда на него зашли.
//
// Устройство намеренно скромное: кольцевой буфер на шесть часов, без
// записи на диск и без запросов на языке выражений. При перезапуске
// приложения история теряется — для наблюдения за «что происходит
// сейчас» этого достаточно, а для разбора недельных тенденций рядом
// по-прежнему стоит связка Prometheus + Grafana (deploy/monitoring).
//
// Снимается всё из того же текста /metrics, что читает Prometheus, —
// см. scrape.go о том, почему источник один.
const (
	// SampleStep — шаг снятия показаний. Совпадает с типовым шагом
	// Prometheus: чаще — лишняя работа, реже — рваные графики.
	SampleStep = 10 * time.Second
	// SampleKeep — сколько точек держать: шесть часов при шаге 10 с.
	SampleKeep = 2160
	// RouteEvery — через сколько точек сохранять разбивку по маршрутам.
	// Каждая такая точка — это таблица на десятки строк, и хранить её
	// с тем же шагом, что скаляры, незачем: по маршрутам смотрят
	// суммарную картину за период, а не форму линии.
	RouteEvery = 6 // то есть раз в минуту
	// RouteKeepTop — сколько маршрутов оставлять в точке.
	//
	// Предел стоит выше, чем число маршрутов приложения (их около
	// полутора сотен), и это важно: при подрезке маршрут, вылетевший
	// из списка в старом снимке, но попавший в него в новом, оставался
	// без базы для вычитания — и в таблице показывал весь свой счётчик
	// с момента запуска вместо прироста за период. Предел остаётся
	// предохранителем от разрастания меток, а не рабочим режимом; если
	// он всё-таки сработал, снимок помечается, и такие маршруты в
	// расчёт не идут.
	RouteKeepTop = 250
)

// routeFrame — накопленные счётчики одного маршрута на момент снимка.
// Ступени нужны, чтобы перцентиль по маршруту считался за выбранный
// период, а не за всё время работы процесса: иначе в таблице рядом
// оказались бы числа за разные промежутки.
type routeFrame struct {
	count   float64
	sumSec  float64
	errors  float64
	buckets []float64 // по durationBuckets, кумулятивно
}

// frame — сокращённый снимок: только то, что рисуется на дашборде.
// Полный разбор (со всеми ступенями по каждому маршруту) в истории
// держать нельзя — это тысячи серий на точку.
type frame struct {
	at time.Time
	// Время опроса базы: метрики pg_* снимаются реже, чем всё
	// остальное, и прирост по ним считается между разными опросами, а
	// не между соседними снимками.
	pgAt time.Time

	reqTotal         float64
	req2xx, req3xx   float64
	req4xx, req5xx   float64
	durCount, durSum float64
	durBuckets       map[float64]float64
	sizeSum          float64
	inFlight         float64
	slowTotal        float64
	wsEvents         float64
	wsConns, wsUsers float64
	dbTx, dbTxSum    float64
	dbTxBuckets      map[float64]float64
	dbErrors         float64
	poolTotal        float64
	poolAcquired     float64
	poolIdle         float64
	poolMax          float64
	poolEmpty        float64
	pgCommits        float64
	pgRollbacks      float64
	pgHit, pgRead    float64
	pgDeadlocks      float64
	pgConnsActive    float64
	pgConnsIdle      float64
	pgConnsIdleTx    float64
	pgSize           float64
	pgLongestQuery   float64
	pgLongestTx      float64
	pgIdleInTx       float64
	pgLocksWaiting   float64
	pgTupReturned    float64
	pgTupFetched     float64

	routes map[string]routeFrame // не в каждой точке, см. RouteEvery
	// Список маршрутов подрезан по RouteKeepTop: значит, отсутствие
	// маршрута в нём ещё не означает, что запросов к нему не было.
	routesCapped bool
}

// Sampler снимает и хранит показания.
type Sampler struct {
	reg *Registry
	pg  *PGCollector

	mu    sync.RWMutex
	ring  []frame
	next  int
	count int
	n     int64 // сколько снимков сделано — для шага маршрутов
	last  *Scrape
}

func NewSampler(reg *Registry, pg *PGCollector) *Sampler {
	return &Sampler{reg: reg, pg: pg, ring: make([]frame, SampleKeep)}
}

// Start запускает снятие показаний.
func (s *Sampler) Start(ctx context.Context) {
	go func() {
		s.sample() // первая точка сразу: дашборд не должен быть пустым
		t := time.NewTicker(SampleStep)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				s.sample()
			}
		}
	}()
}

// text собирает тот же текст, что отдаёт /metrics.
func (s *Sampler) text() string {
	out := s.reg.Render()
	if s.pg != nil {
		out += s.pg.Text()
	}
	return out
}

func (s *Sampler) sample() {
	now := time.Now()
	sc := ParseScrape(s.text(), now)

	s.mu.Lock()
	// Разбивка по маршрутам нужна не в каждой точке (см. RouteEvery), а
	// собирать её — самая дорогая часть разбора. Решаем до вызова, а не
	// после: раньше она строилась всегда и в пяти случаях из шести
	// сразу выбрасывалась.
	withRoutes := s.n%RouteEvery == 0
	s.n++
	s.mu.Unlock()

	f := reduce(sc, withRoutes)
	if s.pg != nil {
		f.pgAt = s.pg.At()
	} else {
		f.pgAt = now
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.last = sc
	s.ring[s.next] = f
	s.next = (s.next + 1) % len(s.ring)
	if s.count < len(s.ring) {
		s.count++
	}
}

// reduce оставляет от полного разбора только нужные числа.
func reduce(sc *Scrape, withRoutes bool) frame {
	conns := sc.By("pg_connections", "state")
	f := frame{
		at:       sc.At,
		reqTotal: sc.Sum("kanban_http_requests_total"),
		req2xx:   sc.Sum("kanban_http_requests_total", "status", "~2"),
		req3xx:   sc.Sum("kanban_http_requests_total", "status", "~3"),
		req4xx:   sc.Sum("kanban_http_requests_total", "status", "~4"),
		req5xx:   sc.Sum("kanban_http_requests_total", "status", "~5"),

		durCount:   sc.Sum("kanban_http_request_duration_seconds_count"),
		durSum:     sc.Sum("kanban_http_request_duration_seconds_sum"),
		durBuckets: sc.Buckets("kanban_http_request_duration_seconds_bucket"),
		sizeSum:    sc.Sum("kanban_http_response_bytes_sum"),
		inFlight:   sc.One("kanban_http_requests_in_flight"),
		slowTotal:  sc.Sum("kanban_slow_requests_total"),

		wsEvents: sc.Sum("kanban_ws_events_total"),
		wsConns:  sc.One("kanban_ws_connections"),
		wsUsers:  sc.One("kanban_ws_users"),

		dbTx:        sc.Sum("kanban_db_queries_total"),
		dbTxSum:     sc.Sum("kanban_db_query_duration_seconds_sum"),
		dbTxBuckets: sc.Buckets("kanban_db_query_duration_seconds_bucket"),
		dbErrors:    sc.Sum("kanban_db_errors_total"),

		poolTotal:    sc.One("kanban_db_pool_total"),
		poolAcquired: sc.One("kanban_db_pool_acquired"),
		poolIdle:     sc.One("kanban_db_pool_idle"),
		poolMax:      sc.One("kanban_db_pool_max"),
		poolEmpty:    sc.One("kanban_db_pool_empty_acquires"),

		pgCommits:      sc.Sum("pg_xact_commit_total"),
		pgRollbacks:    sc.Sum("pg_xact_rollback_total"),
		pgHit:          sc.Sum("pg_blks_hit_total"),
		pgRead:         sc.Sum("pg_blks_read_total"),
		pgDeadlocks:    sc.Sum("pg_deadlocks_total"),
		pgConnsActive:  conns["active"],
		pgConnsIdle:    conns["idle"],
		pgConnsIdleTx:  conns["idle in transaction"],
		pgSize:         sc.Sum("pg_database_size_bytes"),
		pgLongestQuery: sc.One("pg_longest_query_seconds"),
		pgLongestTx:    sc.One("pg_longest_transaction_seconds"),
		pgIdleInTx:     sc.One("pg_idle_in_transaction_seconds"),
		pgLocksWaiting: sc.One("pg_locks_waiting"),
		pgTupReturned:  sc.Sum("pg_tup_returned_total"),
		pgTupFetched:   sc.Sum("pg_tup_fetched_total"),
	}

	if withRoutes {
		f.routes, f.routesCapped = routesOf(sc)
	}
	return f
}

// routesOf — разбивка по маршрутам из снимка. Ключ — «МЕТОД маршрут»,
// как её видит человек в таблице.
func routesOf(sc *Scrape) (map[string]routeFrame, bool) {
	routes := map[string]routeFrame{}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_count"] {
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.count += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_sum"] {
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.sumSec += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_request_duration_seconds_bucket"] {
		i, ok := durationBucketIndex[lv.Labels["le"]]
		if !ok {
			continue // «+Inf»: его роль играет count
		}
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		if rf.buckets == nil {
			rf.buckets = make([]float64, len(durationBuckets))
		}
		rf.buckets[i] += lv.Value
		routes[k] = rf
	}
	for _, lv := range sc.Series["kanban_http_requests_total"] {
		st := lv.Labels["status"]
		if !strings.HasPrefix(st, "4") && !strings.HasPrefix(st, "5") {
			continue
		}
		k := lv.Labels["method"] + " " + lv.Labels["route"]
		rf := routes[k]
		rf.errors += lv.Value
		routes[k] = rf
	}
	capped := len(routes) > RouteKeepTop
	return topRoutes(routes, RouteKeepTop), capped
}

// topRoutes оставляет самые нагруженные маршруты.
func topRoutes(in map[string]routeFrame, limit int) map[string]routeFrame {
	if len(in) <= limit {
		return in
	}
	keys := make([]string, 0, len(in))
	for k := range in {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool { return in[keys[i]].count > in[keys[j]].count })
	out := make(map[string]routeFrame, limit)
	for _, k := range keys[:limit] {
		out[k] = in[k]
	}
	return out
}

// framesLocked возвращает точки в хронологическом порядке, не старше
// window. Вызывается только при взятом s.mu: карты внутри кадров общие
// с кольцом, и читать их можно, пока никто не пишет.
func (s *Sampler) framesLocked(window time.Duration) []frame {
	cut := time.Now().Add(-window)
	out := make([]frame, 0, s.count)
	start := 0
	if s.count == len(s.ring) {
		start = s.next
	}
	for i := 0; i < s.count; i++ {
		f := s.ring[(start+i)%len(s.ring)]
		if f.at.IsZero() || f.at.Before(cut) {
			continue
		}
		out = append(out, f)
	}
	return out
}

// ── расчёты по накопленному ──────────────────────────────────────────

// rate — прирост счётчика в секунду между двумя точками.
//
// Счётчик может уменьшиться: при перезапуске приложения он начинается
// с нуля. Отрицательный прирост отбрасывается — иначе на графике
// возник бы огромный выброс вниз. Prometheus в этом месте умнее: он
// распознаёт сброс и досчитывает значение до перезапуска. Нам этого не
// нужно: при перезапуске теряется вся история в памяти, и одна
// пропущенная точка на её фоне ничего не меняет.
func rate(cur, prev float64, dt float64) float64 {
	if dt <= 0 || cur < prev {
		return 0
	}
	return (cur - prev) / dt
}

// quantile считает перцентиль по кумулятивной гистограмме — тем же
// способом, что histogram_quantile в Prometheus: находим ступень, в
// которую попадает нужная доля наблюдений, и линейно интерполируем
// внутри неё.
func quantile(buckets map[float64]float64, total, q float64) float64 {
	if total <= 0 || len(buckets) == 0 {
		return 0
	}
	bounds := make([]float64, 0, len(buckets))
	for b := range buckets {
		bounds = append(bounds, b)
	}
	sort.Float64s(bounds)

	want := q * total
	prevBound, prevCount := 0.0, 0.0
	for _, b := range bounds {
		c := buckets[b]
		if c >= want {
			if c == prevCount {
				return b
			}
			// Доля внутри ступени — отсюда линейная интерполяция.
			return prevBound + (b-prevBound)*(want-prevCount)/(c-prevCount)
		}
		prevBound, prevCount = b, c
	}
	// Выше последней границы наблюдения есть, но где именно — неизвестно:
	// в ступень «+Inf» границы не входит. Возвращаем последнюю границу,
	// отмечая этим, что значение не меньше неё.
	if len(bounds) > 0 {
		return bounds[len(bounds)-1]
	}
	return 0
}

// diffBuckets — прирост каждой ступени между точками.
func diffBuckets(cur, prev map[float64]float64) (map[float64]float64, float64) {
	out := make(map[float64]float64, len(cur))
	var top float64
	for b, v := range cur {
		d := v - prev[b]
		if d < 0 {
			d = 0
		}
		out[b] = d
		if d > top {
			top = d
		}
	}
	return out, top
}

func safeDiv(a, b float64) float64 {
	if b == 0 || math.IsNaN(b) {
		return 0
	}
	return a / b
}
