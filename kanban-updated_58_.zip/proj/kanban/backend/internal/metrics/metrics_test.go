package metrics

import (
	"bytes"
	"encoding/json"
	"math"
	"strings"
	"sync"
	"testing"
	"time"
)

// Разбор собственной выдачи: метки с экранированием, значения с
// показателем степени, комментарии, «+Inf».
func TestParseScrape(t *testing.T) {
	text := `# HELP kanban_http_requests_total Обработано
# TYPE kanban_http_requests_total counter
kanban_http_requests_total{method="GET",route="/api/tasks/:id",status="200"} 17
kanban_http_requests_total{method="GET",route="/api/tasks/:id",status="500"} 3
kanban_http_request_duration_seconds_bucket{method="GET",route="/a",le="0.005"} 4
kanban_http_request_duration_seconds_bucket{method="GET",route="/a",le="+Inf"} 9
kanban_http_requests_in_flight 2
kanban_http_request_duration_seconds_sum{method="GET",route="/a"} 3.1362e-05
pg_table_size_bytes{table="chart_items"} 8192
kanban_ws_events_total{type="task \"срочно\""} 5
`
	sc := ParseScrape(text, time.Now())

	if got := sc.Sum("kanban_http_requests_total"); got != 20 {
		t.Errorf("сумма запросов = %v, ожидалось 20", got)
	}
	if got := sc.Sum("kanban_http_requests_total", "status", "~5"); got != 3 {
		t.Errorf("5xx = %v, ожидалось 3", got)
	}
	if got := sc.One("kanban_http_requests_in_flight"); got != 2 {
		t.Errorf("в обработке = %v, ожидалось 2", got)
	}
	if got := sc.Sum("kanban_http_request_duration_seconds_sum"); math.Abs(got-3.1362e-05) > 1e-12 {
		t.Errorf("сумма длительностей = %v", got)
	}
	// «+Inf» в ступени не попадает: его роль играет _count.
	b := sc.Buckets("kanban_http_request_duration_seconds_bucket")
	if len(b) != 1 || b[0.005] != 4 {
		t.Errorf("ступени = %v, ожидалась одна со значением 4", b)
	}
	if got := sc.By("pg_table_size_bytes", "table")["chart_items"]; got != 8192 {
		t.Errorf("размер таблицы = %v", got)
	}
	// Кавычка внутри метки разэкранируется.
	if got := sc.By("kanban_ws_events_total", "type")[`task "срочно"`]; got != 5 {
		t.Errorf("метка с кавычками разобрана неверно: %v", sc.Series["kanban_ws_events_total"])
	}
}

// Текст, который отдаёт сам Registry, должен разбираться обратно без
// потерь — иначе дашборд покажет не то, что Prometheus.
func TestRenderParseRoundTrip(t *testing.T) {
	r := New()
	r.Request("GET", "/api/tasks/:id", 200, 12*time.Millisecond, 512)
	r.Request("GET", "/api/tasks/:id", 500, 700*time.Millisecond, 64)
	r.Request("POST", "/api/boards", 201, 3*time.Millisecond, 128)
	r.DBQuery("user_tx", 2*time.Millisecond, false)
	r.WSEvent("task")
	r.Inc("login")
	r.Gauge("kanban_db_pool_max", func() float64 { return 40 })

	sc := ParseScrape(r.Render(), time.Now())

	if got := sc.Sum("kanban_http_requests_total"); got != 3 {
		t.Errorf("запросов = %v, ожидалось 3", got)
	}
	if got := sc.Sum("kanban_http_request_duration_seconds_count"); got != 3 {
		t.Errorf("наблюдений длительности = %v, ожидалось 3", got)
	}
	// Сумма должна сойтись с внесённым: 12 мс + 700 мс + 3 мс.
	if got := sc.Sum("kanban_http_request_duration_seconds_sum"); math.Abs(got-0.715) > 1e-6 {
		t.Errorf("сумма длительностей = %v, ожидалось 0.715", got)
	}
	if got := sc.One("kanban_db_pool_max"); got != 40 {
		t.Errorf("датчик пула = %v, ожидалось 40", got)
	}
	if got := sc.By("kanban_app_events_total", "event")["login"]; got != 1 {
		t.Errorf("прикладной счётчик = %v", got)
	}
	// Ступени кумулятивны: в последней — все наблюдения.
	b := sc.Buckets("kanban_http_request_duration_seconds_bucket")
	last := durationBuckets[len(durationBuckets)-1]
	if b[last] != 3 {
		t.Errorf("верхняя ступень = %v, ожидалось 3", b[last])
	}
	if b[0.005] != 1 {
		t.Errorf("ступень 5 мс = %v, ожидалось 1 (только 3 мс)", b[0.005])
	}
}

// Медленный запрос попадает в журнал, быстрый — нет.
func TestSlowLog(t *testing.T) {
	r := New()
	r.Request("GET", "/fast", 200, 10*time.Millisecond, 1)
	r.Request("GET", "/slow", 200, SlowThreshold+time.Millisecond, 1)
	slow := r.Slow()
	if len(slow) != 1 || slow[0].Route != "/slow" {
		t.Fatalf("журнал = %+v, ожидалась одна запись про /slow", slow)
	}

	// Кольцо не растёт за предел и хранит самые свежие записи.
	for i := 0; i < SlowKeep+50; i++ {
		r.Request("GET", "/x", 200, time.Second, 1)
	}
	if n := len(r.Slow()); n != SlowKeep {
		t.Errorf("в журнале %d записей, предел %d", n, SlowKeep)
	}
	if r.Slow()[0].Route != "/x" {
		t.Errorf("свежая запись должна быть первой, получено %q", r.Slow()[0].Route)
	}
}

// rate обязан отбрасывать уход счётчика назад: после перезапуска
// приложения он начинается с нуля, и без этой проверки на графике
// возник бы огромный отрицательный выброс.
func TestRate(t *testing.T) {
	if got := rate(120, 100, 10); got != 2 {
		t.Errorf("rate = %v, ожидалось 2", got)
	}
	if got := rate(5, 100, 10); got != 0 {
		t.Errorf("сброс счётчика должен давать 0, получено %v", got)
	}
	if got := rate(120, 100, 0); got != 0 {
		t.Errorf("нулевой интервал должен давать 0, получено %v", got)
	}
}

// Перцентиль по кумулятивной гистограмме — тем же способом, что
// histogram_quantile в Prometheus.
func TestQuantile(t *testing.T) {
	// 10 наблюдений: 5 в ступени ≤1, ещё 5 в ступени ≤2.
	b := map[float64]float64{1: 5, 2: 10}

	if got := quantile(b, 10, 0.5); math.Abs(got-1) > 1e-9 {
		t.Errorf("медиана = %v, ожидалось 1", got)
	}
	// 0,9 × 10 = 9 наблюдений: внутри второй ступени, на 80 % её пути.
	if got := quantile(b, 10, 0.9); math.Abs(got-1.8) > 1e-9 {
		t.Errorf("p90 = %v, ожидалось 1.8", got)
	}
	if got := quantile(b, 0, 0.95); got != 0 {
		t.Errorf("без наблюдений ожидался 0, получено %v", got)
	}
	// Наблюдения выше последней границы: точнее последней границы
	// сказать нечего — в «+Inf» верхнего предела нет.
	if got := quantile(map[float64]float64{1: 2}, 10, 0.95); got != 1 {
		t.Errorf("за пределом ступеней ожидалась последняя граница, получено %v", got)
	}
}

// Сводка целиком: от снятых показаний до готового отчёта.
func TestSamplerReport(t *testing.T) {
	r := New()
	s := NewSampler(r, nil)

	// Три снимка с заданными промежутками — так же, как это делает
	// ticker, но без ожидания.
	r.Request("GET", "/api/me", 200, 5*time.Millisecond, 100)
	s.sample()
	for i := 0; i < 20; i++ {
		r.Request("GET", "/api/me", 200, 5*time.Millisecond, 100)
	}
	r.Request("GET", "/api/me", 500, 2*time.Second, 100)
	s.sample()

	// Сдвигаем время снимков назад: без этого оба лежат в одной
	// миллисекунде и скорость посчитать нельзя.
	s.mu.Lock()
	s.ring[0].at = time.Now().Add(-20 * time.Second)
	s.ring[1].at = time.Now().Add(-10 * time.Second)
	s.mu.Unlock()

	rep := s.Report(15*time.Minute, 180)
	if len(rep.Points) == 0 {
		t.Fatal("в отчёте нет точек")
	}
	p := rep.Points[len(rep.Points)-1]
	// 21 запрос за 10 секунд.
	if math.Abs(p.RPS-2.1) > 0.01 {
		t.Errorf("скорость = %v, ожидалось 2.1", p.RPS)
	}
	if math.Abs(p.RPS5xx-0.1) > 0.01 {
		t.Errorf("скорость 5xx = %v, ожидалось 0.1", p.RPS5xx)
	}
	if p.P95 <= 0 {
		t.Errorf("p95 = %v, ожидалось больше нуля", p.P95)
	}
	if len(rep.Routes) != 1 || rep.Routes[0].Route != "/api/me" {
		t.Fatalf("маршруты = %+v", rep.Routes)
	}
	if rep.Routes[0].Requests != 21 {
		t.Errorf("запросов по маршруту = %v, ожидалось 21", rep.Routes[0].Requests)
	}
	if rep.Routes[0].Errors != 1 {
		t.Errorf("ошибок по маршруту = %v, ожидалось 1", rep.Routes[0].Errors)
	}
	// Медленный запрос (2 с) должен попасть в журнал.
	if len(rep.Slow) != 1 {
		t.Errorf("медленных = %d, ожидался 1", len(rep.Slow))
	}
}

// Отчёт на пустом хранилище не должен паниковать и обязан отдавать
// пустые списки, а не nil: дашборд перебирает их без проверок.
func TestEmptyReport(t *testing.T) {
	s := NewSampler(New(), nil)
	rep := s.Report(time.Hour, 180)
	if rep.Points == nil || rep.Routes == nil || rep.Tables == nil || rep.Slow == nil {
		t.Errorf("пустые поля отчёта должны быть списками, получено %+v", rep)
	}
	if len(rep.Points) != 0 {
		t.Errorf("без снимков точек быть не должно, получено %d", len(rep.Points))
	}
}

// Ограничение числа маршрутов в снимке: память не должна расти вместе
// с числом разных путей.
func TestTopRoutes(t *testing.T) {
	in := map[string]routeFrame{}
	for i := 0; i < 100; i++ {
		in[strings.Repeat("a", i+1)] = routeFrame{count: float64(i)}
	}
	out := topRoutes(in, 10)
	if len(out) != 10 {
		t.Fatalf("оставлено %d маршрутов, ожидалось 10", len(out))
	}
	// Остаться должны самые нагруженные.
	for _, rf := range out {
		if rf.count < 90 {
			t.Errorf("в выборке маршрут с count=%v — ожидались только верхние", rf.count)
		}
	}
}

// Состязание за данные: показания снимаются, пока запросы идут, а
// отчёт строится. Карты внутри кадров общие с кольцом, поэтому
// проверять это нужно именно под -race.
func TestConcurrentSampleAndReport(t *testing.T) {
	r := New()
	s := NewSampler(r, nil)
	r.Gauge("kanban_db_pool_max", func() float64 { return 40 })

	stop := make(chan struct{})
	var wg sync.WaitGroup

	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			routes := []string{"/api/me", "/api/tasks", "/api/boards/:id"}
			for {
				select {
				case <-stop:
					return
				default:
				}
				r.Request("GET", routes[n%len(routes)], 200, time.Millisecond, 10)
				r.DBQuery("user_tx", time.Millisecond, false)
				r.WSEvent("task")
			}
		}(i)
	}
	for i := 0; i < 2; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				select {
				case <-stop:
					return
				default:
				}
				s.sample()
			}
		}()
	}
	for i := 0; i < 3; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				select {
				case <-stop:
					return
				default:
				}
				rep := s.Report(time.Hour, 180)
				_ = rep.Summary.RPS
				for _, p := range rep.Points {
					_ = p.P95
				}
				for _, rt := range rep.Routes {
					_ = rt.Requests
				}
				_ = r.Render()
				_ = r.Slow()
			}
		}()
	}

	time.Sleep(300 * time.Millisecond)
	close(stop)
	wg.Wait()
}

// Все числа отчёта обязаны быть представимы в JSON: encoding/json
// отказывается кодировать NaN и ±Inf, и одно такое значение превратило
// бы весь ответ дашборда в ошибку 500.
func TestReportIsJSON(t *testing.T) {
	r := New()
	s := NewSampler(r, nil)

	// Датчик, который отдаёт бесконечность: именно такой случай и
	// ломал бы выдачу, если бы разбор не отбрасывал нечисла.
	r.Gauge("kanban_db_pool_max", func() float64 { return math.Inf(1) })
	r.Gauge("kanban_ws_users", func() float64 { return math.NaN() })
	r.Request("GET", "/api/me", 200, time.Millisecond, 10)
	s.sample()
	r.Request("GET", "/api/me", 500, 2*time.Second, 10)
	s.sample()

	s.mu.Lock()
	s.ring[0].at = time.Now().Add(-20 * time.Second)
	s.ring[1].at = time.Now().Add(-10 * time.Second)
	s.mu.Unlock()

	data, err := json.Marshal(s.Report(time.Hour, 180))
	if err != nil {
		t.Fatalf("отчёт не кодируется в JSON: %v", err)
	}
	if bytes.Contains(data, []byte("NaN")) || bytes.Contains(data, []byte("Inf")) {
		t.Errorf("в JSON попало нечисло")
	}
}

// Прирост по метрикам базы считается между разными опросами: опрос
// идёт раз в 15 секунд, а показания снимаются раз в 10, и на части
// интервалов новых данных по базе просто нет.
func TestPGRateCarriedForward(t *testing.T) {
	now := time.Now()
	pgAt := now.Add(-15 * time.Second)

	a := frame{at: now.Add(-20 * time.Second), pgAt: pgAt, pgCommits: 100}
	b := frame{at: now.Add(-10 * time.Second), pgAt: pgAt, pgCommits: 100} // опрос не обновился
	c := frame{at: now, pgAt: now, pgCommits: 160}

	if p, fresh := pointBetween(a, b); fresh || p.Commits != 0 {
		t.Errorf("без нового опроса ожидались fresh=false и 0, получено %v / %v", fresh, p.Commits)
	}
	// 60 фиксаций за 15 секунд опроса — 4 в секунду, а не 6 (что вышло
	// бы при делении на десятисекундный шаг графика).
	p, fresh := pointBetween(b, c)
	if !fresh {
		t.Error("при новом опросе ожидалось fresh=true")
	}
	if math.Abs(p.Commits-4) > 1e-9 {
		t.Errorf("фиксаций в секунду = %v, ожидалось 4", p.Commits)
	}
}

// Маршрут, попавший в подрезанный список только в свежем снимке, не
// должен показывать счётчик с момента запуска как прирост за период.
func TestRouteWithoutBaselineSkipped(t *testing.T) {
	now := time.Now()
	first := frame{
		at:           now.Add(-5 * time.Minute),
		routesCapped: true,
		routes: map[string]routeFrame{
			"GET /a": {count: 100, sumSec: 1},
		},
	}
	cur := map[string]routeFrame{
		"GET /a": {count: 160, sumSec: 2},
		"GET /b": {count: 500000, sumSec: 900}, // базы нет: список был подрезан
	}

	out := routesBetween([]frame{first}, cur, true, now)
	if len(out) != 1 {
		t.Fatalf("строк %d, ожидалась одна: %+v", len(out), out)
	}
	if out[0].Route != "/a" || out[0].Requests != 60 {
		t.Errorf("строка = %+v, ожидался /a с 60 запросами", out[0])
	}

	// Если подрезки не было, отсутствие маршрута означает, что запросов
	// к нему раньше просто не поступало, и его нужно показать.
	first.routesCapped = false
	out = routesBetween([]frame{first}, cur, false, now)
	if len(out) != 2 {
		t.Errorf("без подрезки ожидались обе строки, получено %+v", out)
	}
}
