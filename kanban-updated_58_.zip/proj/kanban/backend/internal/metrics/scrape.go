package metrics

import (
	"math"
	"strconv"
	"strings"
	"time"
)

// Разбор собственной текстовой выдачи метрик.
//
// Зачем читать то, что сами же и написали, вместо прямого доступа к
// счётчикам: встроенный дашборд администратора должен показывать ровно
// то, что увидит Prometheus. Если он будет считать по внутренним
// структурам, а Prometheus — по тексту, две картины рано или поздно
// разойдутся, и выяснять, какая из них правдива, придётся в бою.
// Поэтому источник один — текст /metrics, а разбор занимает пятьдесят
// строк.
//
// Формат простой и описан публично: строки «имя{метка="значение"}
// число», комментарии начинаются с решётки. Разбираем только то, что
// сами выводим: ни временных отметок в строках, ни экспоненциальных
// гистограмм у нас нет.

// LabeledValue — одно значение серии вместе с её метками.
type LabeledValue struct {
	Labels map[string]string
	Value  float64
}

// Scrape — разобранный снимок метрик.
type Scrape struct {
	At     time.Time
	Series map[string][]LabeledValue
}

// ParseScrape разбирает текст в формате Prometheus.
func ParseScrape(text string, at time.Time) *Scrape {
	s := &Scrape{At: at, Series: map[string][]LabeledValue{}}
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || line[0] == '#' {
			continue
		}
		name, lbl, val, ok := parseLine(line)
		if !ok || !isFinite(val) {
			// NaN и ±Inf формат допускает, а encoding/json — нет: одно
			// такое значение превратило бы весь ответ дашборда в
			// ошибку 500. Отбрасываем на входе, чтобы дальше по
			// расчётам заведомо шли настоящие числа.
			continue
		}
		s.Series[name] = append(s.Series[name], LabeledValue{Labels: lbl, Value: val})
	}
	return s
}

func isFinite(v float64) bool {
	return !math.IsNaN(v) && !math.IsInf(v, 0)
}

func parseLine(line string) (name string, lbl map[string]string, val float64, ok bool) {
	// Значение отделено последним пробелом: в метках пробелы бывают
	// (названия таблиц и типов событий), а после закрывающей скобки —
	// нет.
	sp := strings.LastIndexByte(line, ' ')
	if sp < 0 {
		return "", nil, 0, false
	}
	v, err := strconv.ParseFloat(strings.TrimSpace(line[sp+1:]), 64)
	if err != nil {
		return "", nil, 0, false
	}
	head := strings.TrimSpace(line[:sp])

	if br := strings.IndexByte(head, '{'); br >= 0 {
		if !strings.HasSuffix(head, "}") {
			return "", nil, 0, false
		}
		return head[:br], parseLabels(head[br+1 : len(head)-1]), v, true
	}
	return head, nil, v, true
}

// parseLabels разбирает «a="1",b="2"». Значения экранированы по
// правилам формата (см. esc в metrics.go), поэтому запятую внутри
// кавычек учитываем, а обратный слэш разэкранируем.
func parseLabels(s string) map[string]string {
	out := map[string]string{}
	for len(s) > 0 {
		eq := strings.IndexByte(s, '=')
		if eq < 0 {
			break
		}
		key := strings.TrimSpace(s[:eq])
		rest := s[eq+1:]
		if len(rest) == 0 || rest[0] != '"' {
			break
		}
		var b strings.Builder
		i := 1
		for i < len(rest) {
			if rest[i] == '\\' && i+1 < len(rest) {
				switch rest[i+1] {
				case 'n':
					b.WriteByte('\n')
				default:
					b.WriteByte(rest[i+1])
				}
				i += 2
				continue
			}
			if rest[i] == '"' {
				break
			}
			b.WriteByte(rest[i])
			i++
		}
		out[key] = b.String()
		s = strings.TrimPrefix(strings.TrimSpace(rest[min(i+1, len(rest)):]), ",")
	}
	return out
}

// ── выборка значений ─────────────────────────────────────────────────

// Sum складывает все серии метрики: так из разбивки по методу и
// маршруту получается общее число запросов.
func (s *Scrape) Sum(name string, match ...string) float64 {
	var total float64
	for _, lv := range s.Series[name] {
		if lv.matches(match) {
			total += lv.Value
		}
	}
	return total
}

// One возвращает единственное значение (датчики без меток).
func (s *Scrape) One(name string) float64 {
	if v := s.Series[name]; len(v) > 0 {
		return v[0].Value
	}
	return 0
}

// By группирует метрику по значению одной метки, складывая остальные.
func (s *Scrape) By(name, label string) map[string]float64 {
	out := map[string]float64{}
	for _, lv := range s.Series[name] {
		out[lv.Labels[label]] += lv.Value
	}
	return out
}

// Buckets складывает ступени гистограммы по границам: получается та же
// кумулятивная гистограмма, но без разбивки по маршрутам. Ключ — верхняя
// граница ступени; «+Inf» отбрасывается, его роль играет _count.
func (s *Scrape) Buckets(name string, match ...string) map[float64]float64 {
	out := map[float64]float64{}
	for _, lv := range s.Series[name] {
		if !lv.matches(match) {
			continue
		}
		le := lv.Labels["le"]
		if le == "" || le == "+Inf" {
			continue
		}
		b, err := strconv.ParseFloat(le, 64)
		if err != nil {
			continue
		}
		out[b] += lv.Value
	}
	return out
}

// matches проверяет пары «метка, значение»: Sum("...", "status", "500").
// Значение с запятыми означает «любое из перечисленных», а префикс «~»
// — сравнение по первому символу кода ответа («~2» → 2xx).
func (lv LabeledValue) matches(match []string) bool {
	for i := 0; i+1 < len(match); i += 2 {
		have := lv.Labels[match[i]]
		want := match[i+1]
		if strings.HasPrefix(want, "~") {
			if !strings.HasPrefix(have, want[1:]) {
				return false
			}
			continue
		}
		if have != want {
			return false
		}
	}
	return true
}
