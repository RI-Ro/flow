package metrics

import (
	"sort"
	"strings"
	"time"
)

// Сводка для встроенного дашборда.
//
// Здесь делается то, что в обычной схеме пишут запросами на PromQL:
// скорость считается как прирост счётчика за шаг, перцентили — по
// кумулятивной гистограмме, доля ошибок — отношением приростов. Правила
// те же, что у Prometheus (см. rate и quantile в sampler.go), поэтому
// числа на встроенном дашборде и в Grafana совпадают.
//
// Всё считается при запросе, а не при снятии показаний: в памяти лежат
// накопленные значения, и любой период пересчитывается по ним заново.
// Иначе смена периода требовала бы своего набора заранее посчитанных
// данных — ровно та сложность, от которой здесь хотелось уйти.

// Point — одна точка всех графиков. Один массив вместо десятка: все
// графики на дашборде стоят на одной временной оси, и расхождение
// точек между ними только мешало бы сопоставлять.
type Point struct {
	T int64 `json:"t"` // unix-время в миллисекундах

	RPS    float64 `json:"rps"`
	RPS2xx float64 `json:"rps2xx"`
	RPS3xx float64 `json:"rps3xx"`
	RPS4xx float64 `json:"rps4xx"`
	RPS5xx float64 `json:"rps5xx"`

	Avg         float64 `json:"avg"`
	P50         float64 `json:"p50"`
	P95         float64 `json:"p95"`
	P99         float64 `json:"p99"`
	InFlight    float64 `json:"inFlight"`
	BytesPerSec float64 `json:"bytesPerSec"`

	WSEvents float64 `json:"wsEvents"`
	WSConns  float64 `json:"wsConns"`
	WSUsers  float64 `json:"wsUsers"`

	DBTxPerSec float64 `json:"dbTxPerSec"`
	DBAvg      float64 `json:"dbAvg"`
	DBP95      float64 `json:"dbP95"`
	DBErrors   float64 `json:"dbErrors"`

	PoolTotal    float64 `json:"poolTotal"`
	PoolAcquired float64 `json:"poolAcquired"`
	PoolIdle     float64 `json:"poolIdle"`
	PoolMax      float64 `json:"poolMax"`
	PoolWaits    float64 `json:"poolWaits"`

	Commits     float64 `json:"commits"`
	Rollbacks   float64 `json:"rollbacks"`
	BlksHit     float64 `json:"blksHit"`
	BlksRead    float64 `json:"blksRead"`
	CacheHit    float64 `json:"cacheHit"`
	TupReturned float64 `json:"tupReturned"`
	TupFetched  float64 `json:"tupFetched"`
	Deadlocks   float64 `json:"deadlocks"`

	ConnsActive  float64 `json:"connsActive"`
	ConnsIdle    float64 `json:"connsIdle"`
	ConnsIdleTx  float64 `json:"connsIdleTx"`
	LongestQuery float64 `json:"longestQuery"`
	LongestTx    float64 `json:"longestTx"`
	IdleInTx     float64 `json:"idleInTx"`
	LocksWaiting float64 `json:"locksWaiting"`
}

// RouteStat — строка таблицы маршрутов за выбранный период.
type RouteStat struct {
	Method   string  `json:"method"`
	Route    string  `json:"route"`
	Requests float64 `json:"requests"`
	RPS      float64 `json:"rps"`
	Avg      float64 `json:"avg"`
	P95      float64 `json:"p95"`
	P99      float64 `json:"p99"`
	Errors   float64 `json:"errors"`
	ErrShare float64 `json:"errShare"` // доля ошибок в запросах маршрута
}

// TableStat — строка таблицы по таблицам базы.
type TableStat struct {
	Table     string  `json:"table"`
	SizeBytes float64 `json:"sizeBytes"`
	LiveRows  float64 `json:"liveRows"`
	DeadRows  float64 `json:"deadRows"`
	DeadShare float64 `json:"deadShare"`
	VacuumAge float64 `json:"vacuumAge"`
	SeqScans  float64 `json:"seqScans"`
	IdxScans  float64 `json:"idxScans"`
}

// Summary — мгновенные значения для верхнего ряда плиток.
type Summary struct {
	RPS float64 `json:"rps"`
	// Доли ошибок разделены намеренно. 5xx — поломка на сервере, повод
	// разбираться немедленно; 4xx — отказы по правам, ненайденные
	// объекты и превышение частоты, то есть обычная жизнь приложения.
	// Одним числом они складывались в «50 % ошибок» на совершенно
	// здоровом сервере.
	ErrShare       float64 `json:"errShare"`
	ClientErrShare float64 `json:"clientErrShare"`
	Avg            float64 `json:"avg"`
	P50            float64 `json:"p50"`
	P95            float64 `json:"p95"`
	P99            float64 `json:"p99"`
	InFlight       float64 `json:"inFlight"`
	SlowPerMin     float64 `json:"slowPerMin"`
	BytesPerSec    float64 `json:"bytesPerSec"`

	WSConns float64 `json:"wsConns"`
	WSUsers float64 `json:"wsUsers"`

	DBTxPerSec   float64 `json:"dbTxPerSec"`
	DBAvg        float64 `json:"dbAvg"`
	DBP95        float64 `json:"dbP95"`
	DBErrors     float64 `json:"dbErrors"`
	PoolAcquired float64 `json:"poolAcquired"`
	PoolMax      float64 `json:"poolMax"`
	PoolUsage    float64 `json:"poolUsage"`
	PoolWaits    float64 `json:"poolWaits"`

	DBSizeBytes    float64 `json:"dbSizeBytes"`
	CacheHit       float64 `json:"cacheHit"`
	Connections    float64 `json:"connections"`
	MaxConnections float64 `json:"maxConnections"`
	RollbackShare  float64 `json:"rollbackShare"`
	LongestQuery   float64 `json:"longestQuery"`
	LongestTx      float64 `json:"longestTx"`
	IdleInTx       float64 `json:"idleInTx"`
	LocksWaiting   float64 `json:"locksWaiting"`
	Deadlocks      float64 `json:"deadlocks"`
}

// Report — всё, что показывает дашборд, одним ответом.
//
// Одним, а не десятком запросов на панель: панели смотрят на один и тот
// же момент, и собирать их из разных ответов значило бы показывать
// рядом числа, снятые в разное время.
type Report struct {
	At            time.Time `json:"at"`
	UptimeSeconds float64   `json:"uptimeSeconds"`
	WindowSeconds float64   `json:"windowSeconds"`
	StepSeconds   float64   `json:"stepSeconds"`
	// HistorySeconds — сколько истории вообще накоплено. Нужно, чтобы
	// дашборд честно говорил «данных пока на три минуты», а не рисовал
	// обрезанный график как полный.
	HistorySeconds float64 `json:"historySeconds"`
	SampleStep     float64 `json:"sampleStep"`

	Summary  Summary            `json:"summary"`
	Points   []Point            `json:"points"`
	Routes   []RouteStat        `json:"routes"`
	Slow     []SlowRequest      `json:"slow"`
	Tables   []TableStat        `json:"tables"`
	Entities map[string]float64 `json:"entities"`
	Statuses map[string]float64 `json:"statuses"`
	WSKinds  map[string]float64 `json:"wsKinds"`
	Events   map[string]float64 `json:"events"`
}

// Report собирает сводку за период.
func (s *Sampler) Report(window time.Duration, maxPoints int) Report {
	if window <= 0 {
		window = time.Hour
	}
	if maxPoints <= 0 {
		maxPoints = 180
	}

	s.mu.RLock()
	fs := s.framesLocked(window)
	last := s.last
	oldest := s.oldestLocked()
	s.mu.RUnlock()

	rep := Report{
		At:            time.Now(),
		WindowSeconds: window.Seconds(),
		SampleStep:    SampleStep.Seconds(),
		Entities:      map[string]float64{},
		Statuses:      map[string]float64{},
		WSKinds:       map[string]float64{},
		Events:        map[string]float64{},
		Points:        []Point{},
		Routes:        []RouteStat{},
		Tables:        []TableStat{},
		Slow:          []SlowRequest{},
	}
	if last != nil {
		rep.UptimeSeconds = last.One("kanban_uptime_seconds")
		rep.Entities = last.By("kanban_entities", "kind")
		rep.Statuses = last.By("kanban_http_requests_total", "status")
		rep.WSKinds = last.By("kanban_ws_events_total", "type")
		rep.Events = last.By("kanban_app_events_total", "event")
		rep.Tables = tablesOf(last)
	}
	// История — от первой сохранённой точки до последней, а не до
	// «сейчас»: иначе она получалась длиннее времени работы процесса,
	// и страница обещала больше, чем есть.
	if !oldest.IsZero() && len(fs) > 0 {
		rep.HistorySeconds = fs[len(fs)-1].at.Sub(oldest).Seconds()
	}

	// Шаг графика: период, поделённый на желаемое число точек, но не
	// мельче шага снятия показаний. Так же поступает Grafana со своим
	// $__interval — иначе на шестичасовом периоде пришлось бы передать
	// две тысячи точек, которые всё равно не разглядеть.
	stride := 1
	if len(fs) > maxPoints {
		stride = (len(fs) + maxPoints - 1) / maxPoints
	}
	rep.StepSeconds = SampleStep.Seconds() * float64(stride)

	// Идём от конца к началу: последняя точка графика обязана быть
	// самой свежей. При проходе с начала остаток отбрасывался, и на
	// шестичасовом периоде правый край графика отставал от плиток на
	// две минуты.
	var idx []int
	for i := len(fs) - 1; i-stride >= 0; i -= stride {
		idx = append(idx, i)
	}
	for i := len(idx) - 1; i >= 0; i-- {
		j := idx[i]
		p, pgFresh := pointBetween(fs[j-stride], fs[j])
		// Метрики базы снимаются раз в 15 секунд, графики — раз в 10:
		// в части интервалов опрос базы не обновлялся, и прирост по
		// ним равен нулю не потому, что работы не было, а потому, что
		// нет новых данных. Повторяем предыдущее значение — так принято
		// поступать с рядом, снятым реже остальных.
		if !pgFresh && len(rep.Points) > 0 {
			carryPG(&p, rep.Points[len(rep.Points)-1])
		}
		rep.Points = append(rep.Points, p)
	}

	if len(fs) >= 2 {
		rep.Summary = summaryOf(fs, last, s.reg)
	} else if len(fs) == 1 {
		// Одна точка — скоростей ещё нет, но мгновенные значения уже
		// есть, и прятать их незачем.
		f := fs[0]
		rep.Summary = Summary{
			InFlight: f.inFlight, WSConns: f.wsConns, WSUsers: f.wsUsers,
			PoolAcquired: f.poolAcquired, PoolMax: f.poolMax,
			PoolUsage:   safeDiv(f.poolAcquired, f.poolMax) * 100,
			DBSizeBytes: f.pgSize, Connections: f.pgConnsActive + f.pgConnsIdle + f.pgConnsIdleTx,
			LongestQuery: f.pgLongestQuery, LongestTx: f.pgLongestTx,
			IdleInTx: f.pgIdleInTx, LocksWaiting: f.pgLocksWaiting,
		}
	}
	if last != nil {
		rep.Summary.MaxConnections = last.One("pg_max_connections")
	}

	// Верхняя граница таблицы маршрутов — последний снимок целиком, а
	// не последняя точка с сохранённой разбивкой. Разбивка хранится раз
	// в минуту (см. RouteEvery), и если считать только по ней, таблица
	// отстаёт от графиков до минуты, а на пятиминутном периоде это
	// пятая часть данных.
	if last != nil {
		cur, capped := routesOf(last)
		rep.Routes = routesBetween(fs, cur, capped, last.At)
	}
	// Журнал медленных запросов — тоже за выбранный период: рядом с
	// графиком на пять минут не место записям трёхчасовой давности.
	cut := time.Now().Add(-window)
	for _, r := range s.reg.Slow() {
		if r.At.After(cut) {
			rep.Slow = append(rep.Slow, r)
		}
	}
	return rep
}

// carryPG повторяет в точке значения, снятые с базы: они обновляются
// реже, чем строятся точки графика.
func carryPG(p *Point, prev Point) {
	p.Commits = prev.Commits
	p.Rollbacks = prev.Rollbacks
	p.BlksHit = prev.BlksHit
	p.BlksRead = prev.BlksRead
	p.CacheHit = prev.CacheHit
	p.TupReturned = prev.TupReturned
	p.TupFetched = prev.TupFetched
	p.Deadlocks = prev.Deadlocks
}

// oldestLocked — время самой старой сохранённой точки. Вызывается при
// взятом s.mu.
func (s *Sampler) oldestLocked() time.Time {
	var out time.Time
	for _, f := range s.ring {
		if f.at.IsZero() {
			continue
		}
		if out.IsZero() || f.at.Before(out) {
			out = f.at
		}
	}
	return out
}

// pointBetween считает скорости и перцентили на отрезке между двумя
// снимками: именно так из накопленных счётчиков получается график.
// Второе возвращаемое значение — обновились ли метрики базы: опрос
// базы идёт реже, и на части интервалов новых данных по ней нет.
func pointBetween(a, b frame) (Point, bool) {
	dt := b.at.Sub(a.at).Seconds()
	// Прирост по базе считается между разными опросами и за их
	// собственный промежуток времени, а не за шаг графика.
	pgDt := b.pgAt.Sub(a.pgAt).Seconds()
	pgFresh := pgDt > 0
	p := Point{
		T:      b.at.UnixMilli(),
		RPS:    rate(b.reqTotal, a.reqTotal, dt),
		RPS2xx: rate(b.req2xx, a.req2xx, dt),
		RPS3xx: rate(b.req3xx, a.req3xx, dt),
		RPS4xx: rate(b.req4xx, a.req4xx, dt),
		RPS5xx: rate(b.req5xx, a.req5xx, dt),

		InFlight:    b.inFlight,
		BytesPerSec: rate(b.sizeSum, a.sizeSum, dt),

		WSEvents: rate(b.wsEvents, a.wsEvents, dt),
		WSConns:  b.wsConns,
		WSUsers:  b.wsUsers,

		DBTxPerSec: rate(b.dbTx, a.dbTx, dt),
		DBErrors:   rate(b.dbErrors, a.dbErrors, dt),

		PoolTotal:    b.poolTotal,
		PoolAcquired: b.poolAcquired,
		PoolIdle:     b.poolIdle,
		PoolMax:      b.poolMax,
		PoolWaits:    rate(b.poolEmpty, a.poolEmpty, dt),

		Commits:     rate(b.pgCommits, a.pgCommits, pgDt),
		Rollbacks:   rate(b.pgRollbacks, a.pgRollbacks, pgDt),
		BlksHit:     rate(b.pgHit, a.pgHit, pgDt),
		BlksRead:    rate(b.pgRead, a.pgRead, pgDt),
		TupReturned: rate(b.pgTupReturned, a.pgTupReturned, pgDt),
		TupFetched:  rate(b.pgTupFetched, a.pgTupFetched, pgDt),
		Deadlocks:   rate(b.pgDeadlocks, a.pgDeadlocks, pgDt),

		ConnsActive:  b.pgConnsActive,
		ConnsIdle:    b.pgConnsIdle,
		ConnsIdleTx:  b.pgConnsIdleTx,
		LongestQuery: b.pgLongestQuery,
		LongestTx:    b.pgLongestTx,
		IdleInTx:     b.pgIdleInTx,
		LocksWaiting: b.pgLocksWaiting,
	}
	// Доля попаданий в кэш считается только когда обращения к блокам
	// были. Без них это не «ноль процентов», а «нет данных», и ноль на
	// графике выглядел бы как полный промах кэша.
	if p.BlksHit+p.BlksRead > 0 {
		p.CacheHit = p.BlksHit / (p.BlksHit + p.BlksRead) * 100
	}

	// Время ответа: среднее — из прироста суммы и числа, перцентили —
	// по приросту ступеней. Среднее показывается рядом с перцентилями
	// намеренно: расхождение между ними и есть признак выбросов.
	if n := b.durCount - a.durCount; n > 0 {
		p.Avg = (b.durSum - a.durSum) / n
		db, _ := diffBuckets(b.durBuckets, a.durBuckets)
		p.P50 = quantile(db, n, 0.5)
		p.P95 = quantile(db, n, 0.95)
		p.P99 = quantile(db, n, 0.99)
	}
	if n := b.dbTx - a.dbTx; n > 0 {
		p.DBAvg = (b.dbTxSum - a.dbTxSum) / n
		db, _ := diffBuckets(b.dbTxBuckets, a.dbTxBuckets)
		p.DBP95 = quantile(db, n, 0.95)
	}
	return p, pgFresh
}

// summaryOf считает мгновенные значения.
//
// «Мгновенные» — это прирост за последнюю минуту, а не за весь период:
// плитка «запросов в секунду» должна показывать то, что происходит
// сейчас, иначе она отстаёт от графика рядом на часы.
func summaryOf(fs []frame, last *Scrape, reg *Registry) Summary {
	cur := fs[len(fs)-1]
	// Минута назад или самая старая точка, если истории меньше.
	ref := fs[0]
	for i := len(fs) - 1; i >= 0; i-- {
		if cur.at.Sub(fs[i].at) >= time.Minute {
			ref = fs[i]
			break
		}
	}
	inst, pgFresh := pointBetween(ref, cur)

	s := Summary{
		RPS: inst.RPS, Avg: inst.Avg, P50: inst.P50, P95: inst.P95, P99: inst.P99,
		InFlight: cur.inFlight, BytesPerSec: inst.BytesPerSec,
		WSConns: cur.wsConns, WSUsers: cur.wsUsers,
		DBTxPerSec: inst.DBTxPerSec, DBAvg: inst.DBAvg, DBP95: inst.DBP95,
		DBErrors:     inst.DBErrors,
		PoolAcquired: cur.poolAcquired, PoolMax: cur.poolMax,
		PoolUsage:    safeDiv(cur.poolAcquired, cur.poolMax) * 100,
		PoolWaits:    inst.PoolWaits,
		DBSizeBytes:  cur.pgSize,
		Connections:  cur.pgConnsActive + cur.pgConnsIdle + cur.pgConnsIdleTx,
		LongestQuery: cur.pgLongestQuery, LongestTx: cur.pgLongestTx,
		IdleInTx: cur.pgIdleInTx, LocksWaiting: cur.pgLocksWaiting,
		Deadlocks: inst.Deadlocks,
	}
	s.ErrShare = safeDiv(inst.RPS5xx, inst.RPS) * 100
	s.ClientErrShare = safeDiv(inst.RPS4xx, inst.RPS) * 100

	// Доли по базе за минуту считаются, только если за эту минуту была
	// работа и был свежий опрос. Иначе берётся отношение накопленных
	// значений с момента запуска: «попаданий в кэш за всё время» —
	// осмысленное число, а ноль на простое означал бы полный промах
	// кэша, чего не было.
	s.CacheHit = inst.CacheHit
	s.RollbackShare = safeDiv(inst.Rollbacks, inst.Commits+inst.Rollbacks) * 100
	if last != nil {
		if !pgFresh || inst.BlksHit+inst.BlksRead == 0 {
			hit := last.Sum("pg_blks_hit_total")
			read := last.Sum("pg_blks_read_total")
			s.CacheHit = safeDiv(hit, hit+read) * 100
		}
		if !pgFresh || inst.Commits+inst.Rollbacks == 0 {
			com := last.Sum("pg_xact_commit_total")
			roll := last.Sum("pg_xact_rollback_total")
			s.RollbackShare = safeDiv(roll, com+roll) * 100
		}
	}

	// Медленных запросов в минуту — приростом счётчика, а не подсчётом
	// по журналу: журнал кольцевой, и при настоящей беде он
	// переполняется, а плитка упиралась бы в предел кольца ровно
	// тогда, когда должна показывать рост.
	s.SlowPerMin = rate(cur.slowTotal, ref.slowTotal, cur.at.Sub(ref.at).Seconds()) * 60
	return s
}

// routesBetween строит таблицу маршрутов за период: разницу между
// самым старым и самым свежим снимком, где разбивка сохранена.
func routesBetween(fs []frame, cur map[string]routeFrame, capped bool,
	at time.Time) []RouteStat {

	// Нижняя граница — самый старый снимок периода, где разбивка есть.
	var first *frame
	for i := range fs {
		if fs[i].routes != nil {
			first = &fs[i]
			break
		}
	}
	if first == nil || len(cur) == 0 {
		return []RouteStat{}
	}
	dt := at.Sub(first.at).Seconds()
	if dt <= 0 {
		return []RouteStat{}
	}

	out := make([]RouteStat, 0, len(cur))
	for key, cur := range cur {
		prev, known := first.routes[key]
		if !known && (first.routesCapped || capped) {
			// База для вычитания неизвестна: маршрут мог быть и новым,
			// и просто не попавшим в подрезанный список. Во втором
			// случае мы показали бы его счётчик с момента запуска как
			// прирост за период — число на три порядка больше
			// настоящего, да ещё и первой строкой таблицы.
			continue
		}
		n := cur.count - prev.count
		if n <= 0 {
			continue
		}
		method, route := key, ""
		if sp := strings.IndexByte(key, ' '); sp >= 0 {
			method, route = key[:sp], key[sp+1:]
		}
		st := RouteStat{
			Method: method, Route: route,
			Requests: n,
			RPS:      n / dt,
			Avg:      safeDiv(cur.sumSec-prev.sumSec, n),
			Errors:   maxZero(cur.errors - prev.errors),
		}
		st.ErrShare = safeDiv(st.Errors, n) * 100
		if cur.buckets != nil {
			db := map[float64]float64{}
			for i, bound := range durationBuckets {
				var p float64
				if prev.buckets != nil {
					p = prev.buckets[i]
				}
				db[bound] = maxZero(cur.buckets[i] - p)
			}
			st.P95 = quantile(db, n, 0.95)
			st.P99 = quantile(db, n, 0.99)
		}
		out = append(out, st)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Requests > out[j].Requests })
	return out
}

// tablesOf собирает строки по таблицам базы из последнего снимка.
// Это датчики, а не счётчики: размер и мёртвые строки — текущее
// состояние, скорость тут считать нечего.
func tablesOf(sc *Scrape) []TableStat {
	byName := map[string]*TableStat{}
	get := func(name string) *TableStat {
		if t, ok := byName[name]; ok {
			return t
		}
		t := &TableStat{Table: name}
		byName[name] = t
		return t
	}
	for _, lv := range sc.Series["pg_table_size_bytes"] {
		get(lv.Labels["table"]).SizeBytes = lv.Value
	}
	for _, lv := range sc.Series["pg_table_live_rows"] {
		get(lv.Labels["table"]).LiveRows = lv.Value
	}
	for _, lv := range sc.Series["pg_table_dead_rows"] {
		get(lv.Labels["table"]).DeadRows = lv.Value
	}
	for _, lv := range sc.Series["pg_table_vacuum_age_seconds"] {
		get(lv.Labels["table"]).VacuumAge = lv.Value
	}
	for _, lv := range sc.Series["pg_table_seq_scan_total"] {
		get(lv.Labels["table"]).SeqScans = lv.Value
	}
	for _, lv := range sc.Series["pg_table_idx_scan_total"] {
		get(lv.Labels["table"]).IdxScans = lv.Value
	}

	out := make([]TableStat, 0, len(byName))
	for _, t := range byName {
		t.DeadShare = safeDiv(t.DeadRows, t.LiveRows+t.DeadRows) * 100
		out = append(out, *t)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].SizeBytes > out[j].SizeBytes })
	return out
}

func maxZero(v float64) float64 {
	if v < 0 {
		return 0
	}
	return v
}
