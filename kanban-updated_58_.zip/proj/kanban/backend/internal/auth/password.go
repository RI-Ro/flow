package auth

import (
	"fmt"
	"strings"
	"unicode"
	"unicode/utf8"
)

// Требования к паролю — в одном месте.
//
// Правило проверяется и при самостоятельной смене пароля, и при
// создании пользователя администратором, и при регистрации. Раньше
// каждое место проверяло только длину, причём свою: 10 символов в
// одном файле и 10 в другом, без оглядки на состав. Пароль
// «1111111111» такую проверку проходил.
//
// Теперь условий два: длина и разнообразие. Разнообразие считается по
// четырём типам символов, из которых нужны любые три, — это
// общепринятая формулировка «3 of 4 character categories», она же
// используется в политике паролей Windows.
const (
	// PasswordMinLen — минимальная длина в символах (не в байтах:
	// «Пароль1!» из кириллицы — восемь символов, а не шестнадцать).
	PasswordMinLen = 8
	// PasswordMinClasses — сколько типов символов обязательно.
	PasswordMinClasses = 3
	// PasswordMaxBytes — предел bcrypt. Всё, что длиннее 72 байт,
	// библиотека отрезает молча: пароль из 80 символов совпал бы с
	// любым другим, у которого те же первые 72 байта. Поэтому лучше
	// отказать явно.
	PasswordMaxBytes = 72
)

// PasswordRule — человеческая формулировка требований. Одна строка на
// интерфейс, подсказки и тексты ошибок: разойтись они не могут.
const PasswordRule = "Пароль должен быть не короче 8 символов и содержать символы минимум трёх типов из четырёх: строчные буквы, заглавные буквы, цифры, знаки."

// PasswordClasses возвращает, символы каких типов встретились. Типы
// определяются по таблицам Unicode, поэтому кириллица считается
// буквами наравне с латиницей: «пароль» — строчные, «ПАРОЛЬ» —
// заглавные.
func PasswordClasses(p string) (lower, upper, digit, special bool) {
	for _, r := range p {
		switch {
		case unicode.IsLower(r):
			lower = true
		case unicode.IsUpper(r) || unicode.IsTitle(r):
			upper = true
		case unicode.IsDigit(r):
			digit = true
		default:
			// Знаки препинания, символы, пробел и всё прочее. Отдельно
			// их не разделяем: для оценки разнообразия достаточно того,
			// что это не буква и не цифра.
			special = true
		}
	}
	return
}

// PasswordClassCount — число задействованных типов символов.
func PasswordClassCount(p string) int {
	lower, upper, digit, special := PasswordClasses(p)
	n := 0
	for _, ok := range []bool{lower, upper, digit, special} {
		if ok {
			n++
		}
	}
	return n
}

// ValidatePassword проверяет пароль по правилу и объясняет, чего не
// хватает: «слишком простой» без подробностей заставляет угадывать.
func ValidatePassword(p string) error {
	if n := utf8.RuneCountInString(p); n < PasswordMinLen {
		return fmt.Errorf("Пароль короче %d символов (сейчас %d). %s",
			PasswordMinLen, n, PasswordRule)
	}
	if len(p) > PasswordMaxBytes {
		return fmt.Errorf("Пароль слишком длинный: допустимо до %d байт",
			PasswordMaxBytes)
	}
	if strings.TrimSpace(p) == "" {
		return fmt.Errorf("Пароль не может состоять из одних пробелов")
	}

	lower, upper, digit, special := PasswordClasses(p)
	if n := PasswordClassCount(p); n < PasswordMinClasses {
		var missing []string
		if !lower {
			missing = append(missing, "строчных букв")
		}
		if !upper {
			missing = append(missing, "заглавных букв")
		}
		if !digit {
			missing = append(missing, "цифр")
		}
		if !special {
			missing = append(missing, "знаков (!, ?, -, _ и подобных)")
		}
		// Формулировка нарочно без согласования числа со словом «тип»:
		// «1 типов» и «2 типов» одинаково неграмотны, а падежи здесь
		// пришлось бы разбирать отдельной таблицей.
		return fmt.Errorf("В пароле задействовано типов символов: %d из четырёх, "+
			"нужно %d. Не хватает: %s", n, PasswordMinClasses, strings.Join(missing, ", "))
	}
	return nil
}
