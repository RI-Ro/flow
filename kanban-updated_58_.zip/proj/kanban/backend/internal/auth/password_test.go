package auth

import "testing"

func TestValidatePassword(t *testing.T) {
	bad := []string{"", "short1A", "1234567890", "parolparol", "ПАРОЛЬПАРОЛЬ", "        ", "Parol123"[:7]}
	for _, p := range bad {
		if ValidatePassword(p) == nil {
			t.Errorf("должен быть отклонён: %q", p)
		}
	}
	good := []string{"Parol123", "парольА1", "parol-12", "ПАРОЛЬ-1", "p@ssW0rd", "Пароль!!"}
	for _, p := range good {
		if e := ValidatePassword(p); e != nil {
			t.Errorf("должен быть принят: %q — %v", p, e)
		}
	}
	if ValidatePassword(string(make([]byte, 80))) == nil {
		t.Error("слишком длинный должен быть отклонён")
	}
	if n := PasswordClassCount("aA1!"); n != 4 {
		t.Errorf("типов 4, получено %d", n)
	}
}
