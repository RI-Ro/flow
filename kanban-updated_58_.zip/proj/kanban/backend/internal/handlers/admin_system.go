package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/example/kanban/internal/httpx"
)

// Состояние системы для администратора.
//
// Отдаёт то же, что увидел бы Grafana, забрав метрики из Prometheus:
// скорость запросов, время ответа по перцентилям, медленные запросы,
// состояние пула и базы, количество объектов в системе. Считается по
// истории, которую приложение держит само (internal/metrics/sampler.go),
// поэтому для просмотра «что происходит сейчас» ни Prometheus, ни
// Grafana поднимать не нужно.
//
// Связка с Prometheus и Grafana при этом никуда не делась: /metrics
// работает как раньше, дашборды лежат в deploy/monitoring. Встроенный
// дашборд — для быстрого взгляда и для установок, где отдельный контур
// наблюдения разворачивать не станут; внешний — для долгой истории,
// оповещений и сопоставления с другими системами.

// Допустимые периоды. Список закрытый, потому что история в памяти
// ограничена шестью часами: просить больше бессмысленно, а молча
// отдавать меньше запрошенного — хуже, чем не дать выбрать.
var systemWindows = map[string]time.Duration{
	"5m":  5 * time.Minute,
	"15m": 15 * time.Minute,
	"1h":  time.Hour,
	"6h":  6 * time.Hour,
}

func (s *Server) AdminSystem(c *fiber.Ctx) error {
	if s.samples == nil {
		// Метрики выключены настройкой METRICS_ENABLED=false. Это не
		// ошибка сервера, и дашборд должен сказать об этом человеку, а
		// не показывать пустые графики.
		return httpx.Fail(c, httpx.Err(fiber.StatusServiceUnavailable, "metrics_disabled",
			"Сбор метрик отключён настройкой METRICS_ENABLED — состояние системы недоступно"))
	}

	window, ok := systemWindows[c.Query("range", "1h")]
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_range",
			"Период может быть 5m, 15m, 1h или 6h"))
	}

	return httpx.JSON(c, fiber.StatusOK, s.samples.Report(window, 180))
}
