import React, { useEffect, useRef, useState } from "react";
import {
  Pencil, Trash2, Calendar, Users as UsersIcon, Eye, Lock, Share2, Send, Upload,
  Paperclip, Download, ExternalLink, Check, CheckCheck, X, Plus, CircleDot, CheckCircle2, RotateCcw, Video, Mail, Copy, Printer,
  FolderInput, UserPlus, Hash, BellPlus, Link2, PackageCheck,
} from "lucide-react";
import { api } from "../lib/api.js";
import FilePreview from "./FilePreview.jsx";
import AuthImage, { downloadFile } from "./AuthImage.jsx";
import AssigneePicker from "./AssigneePicker.jsx";
import { assigneeCandidates, outsideTeam } from "../lib/assignees.js";
import { printTaskPdf } from "../lib/taskPdf.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { PRIORITIES, GRANT_LABEL, fmtDate, fmtDateTime, fmtRelative, fmtSize, resolveUser, conferenceLink, conferenceNames, taskMailLink } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Checkbox, ConfirmDialog, Field, MultilineField, inputStyle, RecurMark } from "../lib/ui.jsx";

// Заменяет элемент списка по id или добавляет новый в конец — общая
// операция и для собственных оптимистичных правок, и для событий,
// пришедших по WebSocket от других участников.
function upsertById(list, item) {
  const i = list.findIndex((x) => x.id === item.id);
  if (i === -1) return [...list, item];
  const next = [...list];
  next[i] = item;
  return next;
}

export default function TaskDetail({ theme, task, directory, team, currentUser, onClose, onEdit, onTaskPatched, onRequestDelete, onRequestCopy, onRequestMove, onRequestReminder, onOpenBoard, teamGroups = [], onError, onOpenUser, onOpenTask }) {
  const [tab, setTab] = useState("details");
  const [comments, setComments] = useState([]);
  const [files, setFiles] = useState([]);
  const [activity, setActivity] = useState([]);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [assignOpen, setAssignOpen] = useState(false);
  const [dueOpen, setDueOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const access = task.access;

  // Ссылка вида /tasks/<id>: такой адрес приложение понимает при
  // открытии и сразу показывает карточку.
  // Копирование ссылки — тем же способом, что и у проекта.
  //
  // Прежний вариант полагался только на navigator.clipboard, а он
  // доступен лишь на https и по разрешению; в остальных случаях
  // выскакивало окно с адресом, из которого копировать неудобно.
  // Запасной путь — скрытое поле и execCommand: старый приём, но
  // работает везде.
  const copyTaskLink = async () => {
    const url = `${window.location.origin}/tasks/${task.id}`;
    const done = () => {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 1800);
    };
    try {
      await navigator.clipboard.writeText(url);
      done();
      return;
    } catch {
      /* пробуем запасной путь ниже */
    }
    try {
      const field = document.createElement("textarea");
      field.value = url;
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      field.remove();
      done();
    } catch {
      onError("Не удалось скопировать ссылку. Адрес задачи: " + url);
    }
  };
  // Автор задачи всегда управляет ею полностью (совпадает с правилом
  // task_access на сервере). Поэтому кнопка редактирования и прочие
  // действия доступны автору, даже если в проекте он лишь исполнитель
  // и сервер по иным основаниям вернул бы для него 'contribute'.
  const isAuthor = task.createdBy === currentUser?.id;
  const canEdit = access === "edit" || isAuthor;
  const readOnly = access === "read" && !isAuthor;
  // Менять исполнителей вправе тот же, кто вправе править задачу:
  // поручение — это распоряжение чужим временем.
  const canAssign = canEdit && !Boolean(task.completedAt);
  const completed = Boolean(task.completedAt);
  const pr = PRIORITIES[task.priority] || PRIORITIES.medium;
  const assignees = task.assignees.map((id) => resolveUser(directory, id));

  // В конференцию зовём исполнителей, автора задачи и тех, кому она
  // открыта точечно, — то есть всех, кто по ней работает. Дубли
  // убираются по идентификатору, удалённые и безтелефонные отсеиваются
  // внутри conferenceLink.
  const confParticipants = [
    ...new Set([
      ...task.assignees,
      task.createdBy,
      ...(task.grants || []).map((g) => g.userId),
    ].filter(Boolean)),
  ]
    .map((id) => resolveUser(directory, id))
    .filter((u) => !u.deleted && u.phone);
  const confLink =
    confParticipants.length >= 2 ? conferenceLink(confParticipants, currentUser.id) : null;
  const confNames = conferenceNames(confParticipants, currentUser.id);

  // Незавершённые задачи, блокирующие эту.
  const blockedBy = links.filter(
    (l) => l.kind === "blocks" && l.toTask === task.id && !l.completed);

  // Отметка исполнителя: доступна, только если текущий пользователь сам
  // в списке исполнителей. Автор задачи, не будучи исполнителем, кнопки
  // не увидит — за него отметиться нельзя.
  const iAmAssignee = task.assignees.includes(currentUser.id);
  const doneIds = task.assigneesDone || [];
  // Кто из исполнителей задачу открывал (п.3). Одна галочка —
  // открывал, две — отметил свою часть выполненной. Отметка о
  // просмотре ставится сервером при открытии карточки, поэтому
  // «открывал» здесь означает именно это, а не «получил уведомление».
  const seenIds = task.assigneesSeen || [];
  // Исполнители, чей просмотр свежее последнего изменения задачи:
  // у них галочка зелёная, у остальных «видевших» — серая.
  const freshIds = task.assigneesFresh || [];
  const iMarkedDone = doneIds.includes(currentUser.id);

  const markAssignment = async (next) => {
    try {
      const updated = await api.completeAssignment(task.id, next);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };
  const mailLink = taskMailLink(confParticipants, task.title, currentUser.id);
  // Вызов уходит только после подтверждения: случайное нажатие
  // мгновенно поднимает трубку у нескольких человек сразу.
  const [pendingCall, setPendingCall] = useState(null);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    Promise.all([api.comments(task.id), api.attachments(task.id), api.activity(task.id),
                 api.taskLinks(task.id)])
      .then(([c, f, a, l]) => {
        if (!alive) return;
        setComments(c);
        setFiles(f);
        setActivity(a);
        setLinks(l);
      })
      .catch((e) => onError(e.message))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [task.id, onError]);

  // Пока карточка открыта, подписываемся на события именно этой задачи —
  // так все её вкладки (и других пользователей с доступом) видят новый
  // комментарий, файл или отметку в чек-листе без перезапроса всей доски.
  useEffect(() => {
    const offComment = onRealtimeMessage("comment", (e) => {
      if (e.payload.taskId !== task.id) return;
      setComments((prev) =>
        e.action === "deleted" ? prev.filter((c) => c.id !== e.payload.id) : upsertById(prev, e.payload)
      );
    });
    const offAttachment = onRealtimeMessage("attachment", (e) => {
      if (e.payload.taskId !== task.id) return;
      setFiles((prev) =>
        e.action === "deleted" ? prev.filter((f) => f.id !== e.payload.id) : upsertById(prev, e.payload)
      );
    });
    const offStep = onRealtimeMessage("step", (e) => {
      if (e.payload.taskId !== task.id) return;
      const cur = task.steps || [];
      const next = e.action === "deleted"
        ? cur.filter((x) => x.id !== e.payload.step.id)
        : upsertById(cur, e.payload.step);
      onTaskPatched({ ...task, steps: next });
    });
    return () => { offComment(); offAttachment(); offStep(); };
  }, [task.id, task, onTaskPatched]);

  const reloadActivity = () => api.activity(task.id).then(setActivity).catch(() => {});

  const toggleComplete = async () => {
    try {
      const updated = await api.completeTask(task.id, !completed);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" padded={false} geometryKey="task-detail">
      {/* Плашка выше всего остального: это первое, что должен увидеть
          тот, кто открыл задачу на приёмку. У завершённой её нет —
          там уже принято. */}
      {task.readyAt && !task.completedAt && (
        <div style={{ background: theme.success, color: "#fff" }}
          className="px-5 py-2 flex items-center gap-2 flex-wrap">
          <PackageCheck size={15} />
          <span className="text-[13px] font-bold uppercase tracking-wide">Готова к сдаче</span>
          <span className="text-[11.5px] opacity-90">
            {task.readyBy ? resolveUser(directory, task.readyBy).fullName : ""} · {fmtDateTime(task.readyAt)}
          </span>
        </div>
      )}

      <div className="p-5 pb-3">
        <ModalHeader theme={theme} onClose={onClose} title={task.title}
          extra={(
            <>
              <button onClick={() => printTaskPdf(task, directory)} style={{ color: theme.textMuted }} title="Печать / сохранить в PDF"><Printer size={16} /></button>
              <button onClick={() => onRequestCopy(task)} style={{ color: theme.textMuted }} title="Копировать задачу"><Copy size={16} /></button>
              <button onClick={() => onRequestReminder?.(task)} style={{ color: theme.textMuted }}
                title="Напомнить об этой задаче"><BellPlus size={16} /></button>
              {/* Ссылка на задачу — чтобы отправить её коллеге в
                  переписке. Адрес строится от текущего происхождения:
                  прописывать его в настройках значило бы ломать ссылки
                  при любом переносе стенда. */}
              <button onClick={copyTaskLink}
                style={{ color: linkCopied ? theme.success : theme.textMuted }}
                title={linkCopied ? "Ссылка скопирована" : "Скопировать ссылку на задачу"}>
                {linkCopied ? <Check size={16} /> : <Link2 size={16} />}
              </button>
              {canEdit && (
                <button onClick={() => onRequestMove?.(task)} style={{ color: theme.textMuted }}
                  title="Перенести в другой проект"><FolderInput size={16} /></button>
              )}
              {canEdit && (
                <button onClick={() => onEdit(task)} style={{ color: theme.textMuted }} title="Редактировать"><Pencil size={16} /></button>
              )}
            </>
          )} />

        <div className="flex items-center gap-2 flex-wrap -mt-2 mb-3">
          <span style={{ background: theme[pr.color] }} className="w-2 h-2 rounded-full" />
          <span style={{ color: theme.textMuted }} className="text-[11px] uppercase tracking-wide font-medium">{pr.label}</span>
          {task.boardTitle && (
            // Название проекта — ссылка. Переход проверяет права:
            // если человек в проекте не состоит и задача открыта ему
            // точечно, он увидит объяснение, а не пустую доску.
            <button onClick={() => onOpenBoard?.(task.boardId)}
              style={{ background: theme.surfaceAlt, color: theme.accent }}
              className="text-[10.5px] px-1.5 py-0.5 rounded font-medium"
              title="Перейти в проект">
              {task.boardTitle}
            </button>
          )}
          {/* Колонка рядом с проектом: по ней видно стадию работы, а
              иначе за этим приходилось закрывать карточку и искать
              задачу на доске глазами. */}
          {/* Цикличность — в шапке карточки: раньше о повторении
              можно было узнать только из формы правки, то есть имея
              право на правку. */}
          <RecurMark task={task} theme={theme} withText
            className="px-1.5 py-0.5 rounded"
            />
          {task.columnTitle && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }}
              className="text-[10.5px] px-1.5 py-0.5 rounded" title="Колонка на доске">
              {task.columnTitle}
            </span>
          )}
          {readOnly && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="flex items-center gap-1 text-[10.5px] px-1.5 py-0.5 rounded">
              <Eye size={11} /> только просмотр
            </span>
          )}
          {access === "contribute" && !isAuthor && (
            <span style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="flex items-center gap-1 text-[10.5px] px-1.5 py-0.5 rounded">
              <Lock size={11} /> участие без редактирования
            </span>
          )}
          {completed && (
            <span style={{ background: theme.success, color: "#fff" }} className="flex items-center gap-1 text-[10.5px] px-1.5 py-0.5 rounded"
              title="Когда задачу пометили завершённой">
              <Check size={11} /> завершена {fmtDateTime(task.completedAt)}
            </span>
          )}
        </div>

        {task.description && (
          <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed mb-3 whitespace-pre-wrap">{task.description}</p>
        )}

        <div className="flex items-center gap-4 text-[12.5px] flex-wrap" style={{ color: theme.textMuted }}>
          <span className="flex items-center gap-1"><Calendar size={13} />{fmtDate(task.dueDate)}</span>
          <span className="flex items-center gap-1"><UsersIcon size={13} />{assignees.length}</span>
          {/* Входящий номер и его дата — реквизиты документа, по
              которым задачу ищут в бумажной переписке. До сих пор их
              можно было увидеть только в форме редактирования, то есть
              тем, у кого есть право править. */}
          {task.incomingNumber && (
            <span className="flex items-center gap-1" title="Входящий номер">
              <Hash size={13} />{task.incomingNumber}
              {task.incomingDate ? ` от ${fmtDate(task.incomingDate)}` : ""}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
          {assignees.map((u, i) => {
            const done = doneIds.includes(u.id);
            const seen = seenIds.includes(u.id);
            const fresh = freshIds.includes(u.id);
            // Три состояния, от сильного к слабому:
            //   две зелёные — отметил свою часть выполненной;
            //   зелёная     — видел задачу в нынешнем виде;
            //   серая       — открывал, но с тех пор задача менялась.
            const mark = done
              ? { icon: <CheckCheck size={13} style={{ color: theme.success }} />,
                  hint: "Две зелёные галочки: исполнитель отметил свою часть выполненной" }
              : fresh
              ? { icon: <Check size={13} style={{ color: theme.success }} />,
                  hint: "Зелёная галочка: исполнитель видел задачу после последнего изменения" }
              : seen
              ? { icon: <Check size={13} style={{ color: theme.textMuted }} />,
                  hint: "Серая галочка: исполнитель знакомился с задачей, но после этого она менялась" }
              : { icon: null, hint: "Исполнитель ещё не открывал задачу" };
            return (
              <button key={`${u.id}-${i}`} onClick={() => onOpenUser(u)} style={{ background: theme.surfaceAlt }}
                title={`${u.fullName} — ${mark.hint}`}
                className="flex items-center gap-1.5 pr-2 rounded-full">
                <Avatar user={u} size={24} theme={theme} />
                <span style={{ color: u.deleted ? theme.textMuted : theme.text, textDecoration: u.deleted ? "line-through" : "none" }} className="text-[12px]">
                  {u.fullName}
                </span>
                {mark.icon}
              </button>
            );
          })}
        </div>

        {/* Готовность к сдаче — состояние между «в работе» и
            «завершена»: исполнитель закончил и ждёт приёмки. Кнопку
            видит только исполнитель; снять отметку может ещё и тот,
            кто ведёт задачу. У завершённой задачи её нет — там уже
            принято. */}
        {!task.completedAt && (iAmAssignee || (canEdit && task.readyAt)) && (
          <button
            onClick={async () => {
              try { onTaskPatched(await api.setTaskReady(task.id, !task.readyAt)); }
              catch (e) { onError(e.message); }
            }}
            style={task.readyAt
              ? { background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }
              : { background: theme.success, color: "#fff" }}
            className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-[12.5px] font-semibold mt-2">
            <PackageCheck size={14} />
            {task.readyAt ? "Снять отметку о готовности" : "Задача готова к сдаче"}
          </button>
        )}

        {canAssign && (
          // Смена исполнителей отдельной кнопкой.
          //
          // Поручить задачу — это не «отредактировать задачу»: условия
          // остаются прежними, меняется только кто делает. Гонять ради
          // этого через форму со всеми полями (где легко задеть срок
          // или описание) неудобно и рискованно.
          <button onClick={() => setAssignOpen(true)} style={{ color: theme.accent }}
            className="flex items-center gap-1.5 text-[12.5px] font-medium mt-2">
            <UserPlus size={14} /> Поручить
          </button>
        )}

        {canEdit && !completed && (
          // Срок — отдельной кнопкой, по тем же причинам, что и
          // поручение: перенос даты не должен требовать открытия формы
          // со всеми полями задачи, где легко задеть описание или
          // состав исполнителей.
          <button onClick={() => setDueOpen(true)} style={{ color: theme.accent }}
            className="flex items-center gap-1.5 text-[12.5px] font-medium mt-2 ml-4">
            <Calendar size={14} /> {task.dueDate ? "Изменить срок" : "Назначить срок"}
          </button>
        )}

        {assignees.length > 0 && (
          // Легенда обязательна: одна и две галочки различимы, только
          // если знать, что они означают. Иначе первая же галочка
          // читается как «сделано», а это не так.
          <div style={{ color: theme.textMuted }} className="flex items-center gap-3 mt-1.5 text-[10.5px] flex-wrap">
            <span className="flex items-center gap-1"><Check size={11} /> ознакомился</span>
            <span className="flex items-center gap-1"><Check size={11} style={{ color: theme.success }} /> видел последние изменения</span>
            <span className="flex items-center gap-1"><CheckCheck size={11} style={{ color: theme.success }} /> выполнил свою часть</span>
          </div>
        )}

        {/* Видеоконференция со всеми участниками задачи. Схема
            callto://n1&n2 собирает несколько номеров в один вызов —
            её понимают корпоративные клиенты связи, регистрирующие
            обработчик callto. Кнопка появляется, только когда есть
            хотя бы два участника с телефонами: звать на «конференцию»
            одного человека смысла нет, для этого есть видеозвонок
            в его карточке. */}
        {mailLink && (
          <a href={mailLink}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="w-full mt-3 rounded-lg py-2.5 text-[12.5px] font-semibold flex items-center justify-center gap-2"
            title={`Написать: ${confNames}`}>
            <Mail size={15} style={{ color: theme.accent }} />
            <span className="flex flex-col items-start leading-tight">
              <span>Написать участникам</span>
              <span style={{ color: theme.textMuted }} className="text-[10.5px] font-normal">
                {confNames}
              </span>
            </span>
          </a>
        )}

        {confLink && (
          <button onClick={() => setPendingCall({ href: confLink, names: confNames })}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="w-full mt-3 rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-2"
            title={`Собрать участников: ${confNames}`}>
            <Video size={15} style={{ color: theme.accent }} />
            <span className="flex flex-col items-start leading-tight">
              <span>Видеоконференция</span>
              <span style={{ color: theme.textMuted }} className="text-[11px] font-normal">
                {confNames}
              </span>
            </span>
          </button>
        )}

        {iAmAssignee && (
          <button onClick={() => markAssignment(!iMarkedDone)}
            style={{
              background: iMarkedDone ? theme.surfaceAlt : theme.accent,
              color: iMarkedDone ? theme.text : theme.accentText,
              border: `1px solid ${theme.border}`,
            }}
            className="w-full mt-3 rounded-lg py-2 text-[12.5px] font-semibold flex items-center justify-center gap-2">
            {iMarkedDone ? <RotateCcw size={14} /> : <Check size={14} />}
            {iMarkedDone ? "Снять мою отметку о выполнении" : "Я выполнил свою часть"}
          </button>
        )}

        {blockedBy.length > 0 && !completed && (
          <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.danger}` }}
            className="w-full mt-3 rounded-lg p-2.5 text-[12px] leading-snug"
            role="status">
            <span style={{ color: theme.danger }} className="font-semibold">Заблокирована. </span>
            <span style={{ color: theme.text }}>
              Нельзя завершить, пока не закрыты: {blockedBy.map((l) => `«${l.title}»`).join(", ")}.
            </span>
          </div>
        )}

        {canEdit && (
          <button onClick={toggleComplete}
            style={{ background: completed ? theme.surfaceAlt : theme.success, color: completed ? theme.text : "#fff", border: `1px solid ${theme.border}` }}
            className="w-full mt-4 rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-2">
            {completed ? <RotateCcw size={15} /> : <CheckCircle2 size={15} />}
            {completed ? "Вернуть в работу" : "Пометить завершённой"}
          </button>
        )}
      </div>

      <nav style={{ borderColor: theme.border }} className="flex border-t border-b px-5 overflow-x-auto">
        {[["details", "Детали"], ["comments", `Комментарии (${comments.length})`], ["files", `Файлы (${files.length})`], ["links", `Связи (${links.length})`], ["activity", "История"]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)}
            style={{ color: tab === key ? theme.text : theme.textMuted, borderColor: tab === key ? theme.accent : "transparent" }}
            className="px-3 py-2.5 text-[12.5px] font-medium border-b-2 -mb-px whitespace-nowrap">
            {label}
          </button>
        ))}
      </nav>

      {/* Прокрутка у карточки одна — общая, её даёт само окно (Modal).
          Раньше содержимое вкладки прокручивалось ещё и отдельно, со
          своей высотой от окна браузера. Два вложенных прокручиваемых
          поля на длинной переписке вели себя плохо: колесо то крутило
          внутреннее поле, то «проваливалось» во внешнее, а конец
          комментариев было не достать. Теперь шапка, вкладки и
          содержимое листаются вместе. */}
      <div className="p-5 pb-8">
        {loading && <p style={{ color: theme.textMuted }} className="text-[13px]">Загружаем…</p>}

        {!loading && tab === "details" && (
          <DetailsTab theme={theme} task={task} directory={directory} team={team} currentUser={currentUser} canEdit={canEdit} readOnly={readOnly} access={access} isAuthor={isAuthor}
            onTaskPatched={onTaskPatched} onError={onError} onRequestDelete={onRequestDelete} reloadActivity={reloadActivity} />
        )}

        {!loading && tab === "comments" && (
          <CommentsTab theme={theme} task={task} directory={directory} currentUser={currentUser}
            comments={comments} setComments={setComments} readOnly={readOnly} onError={onError} onOpenUser={onOpenUser} />
        )}

        {!loading && tab === "files" && (
          <FilesTab theme={theme} task={task} directory={directory} files={files} setFiles={setFiles} readOnly={readOnly} onError={onError} />
        )}

        {!loading && tab === "links" && (
          <LinksTab theme={theme} task={task} links={links} setLinks={setLinks}
            canEdit={canEdit} onError={onError} onOpenTask={onOpenTask} />
        )}

        {!loading && tab === "activity" && (
          <div>
            {activity.map((h) => (
              <div key={h.id} className="flex items-start gap-2 mb-2.5">
                <CircleDot size={12} style={{ color: theme.accent, marginTop: 3 }} />
                <div>
                  <div style={{ color: theme.text }} className="text-[13px]">{h.body}</div>
                  <div style={{ color: theme.textMuted }} className="text-[11px]">
                    {fmtDateTime(h.createdAt)}{h.actorId ? ` · ${resolveUser(directory, h.actorId).fullName}` : ""}
                  </div>
                </div>
              </div>
            ))}
            {activity.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px]">Записей нет.</p>}
          </div>
        )}
      </div>

      {/* Окно поручения живёт здесь, в самой карточке: состояние
          assignOpen объявлено рядом с остальными действиями над
          задачей, а вкладка «Детали» — отдельный компонент и о нём
          ничего не знает. */}
      {assignOpen && (
        <AssignModal theme={theme} task={task} directory={directory} team={team} teamGroups={teamGroups}
          currentUser={currentUser}
          onClose={() => setAssignOpen(false)}
          onSaved={(t) => { onTaskPatched(t); setAssignOpen(false); }}
          onError={onError} />
      )}

      {dueOpen && (
        <DueDateModal theme={theme} task={task}
          onClose={() => setDueOpen(false)}
          onSaved={(t) => { onTaskPatched(t); setDueOpen(false); reloadActivity(); }}
          onError={onError} />
      )}

      {pendingCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеоконференцию?"
          message={`Вызов будет отправлен участникам: ${pendingCall.names}. Убедитесь, что это не случайное нажатие.`}
          confirmLabel="Позвонить" danger={false}
          onCancel={() => setPendingCall(null)}
          onConfirm={() => {
            const href = pendingCall.href;
            setPendingCall(null);
            window.location.href = href;
          }} />
      )}
    </Modal>
  );
}

/* ------------------------------------------------------------- детали */

function DetailsTab({ theme, task, directory, team, currentUser, canEdit, readOnly, access, isAuthor, onTaskPatched, onError, onRequestDelete, reloadActivity }) {
  const [grantOpen, setGrantOpen] = useState(false);
  const [grantSearch, setGrantSearch] = useState("");

  // Патчим только массив steps внутри задачи и отдаём наверх — без
  // похода за всей задачей целиком. Именно это чинит прежде «неработавшую»
  // отметку выполнения: раньше клик по чекбоксу дожидался ответа и следом
  // перечитывал всю доску, и если пользователь успевал кликнуть дважды,
  // более медленный первый ответ перезаписывал уже обновлённое состояние.
  const patchSteps = (updater) => onTaskPatched({ ...task, steps: updater(task.steps) });

  const toggleStep = async (stepId, done) => {
    // Оптимистично обновляем отметку.
    patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, done } : s)));
    try {
      const updated = await api.toggleStep(task.id, stepId, done);
      // Мержим ответ сервера в актуальный пункт по id (сохраняя порядок).
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, ...updated } : s)));
    } catch (e) {
      // Откат: возвращаем прежнее значение отметки.
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? { ...s, done: !done } : s)));
      onError(e.message);
    }
  };

  const renameStep = async (stepId, payload) => {
    try {
      const updated = await api.renameStep(task.id, stepId, payload);
      patchSteps((steps) => steps.map((s) => (s.id === stepId ? updated : s)));
    } catch (e) {
      onError(e.message);
    }
  };

  const addStep = async (payload) => {
    const body = (payload.body || "").trim();
    if (!body) return;
    try {
      const created = await api.createStep(task.id, { ...payload, body });
      patchSteps((steps) => (steps.some((s) => s.id === created.id)
        ? steps.map((s) => (s.id === created.id ? created : s))
        : [...steps, created]));
    } catch (e) {
      onError(e.message);
    }
  };

  const deleteStep = async (stepId) => {
    const prev = task.steps;
    patchSteps((steps) => steps.filter((s) => s.id !== stepId));
    try {
      await api.deleteStep(task.id, stepId);
    } catch (e) {
      onTaskPatched({ ...task, steps: prev });
      onError(e.message);
    }
  };

  const saveGrants = async (grants) => {
    try {
      const updated = await api.setGrants(task.id, grants);
      onTaskPatched(updated);
      reloadActivity();
    } catch (e) {
      onError(e.message);
    }
  };

  const candidates = directory
    // Точечный доступ открывается любому сотруднику в системе, а не
    // только своей команде.
    //
    // Команда очерчивает, кому можно ПОРУЧАТЬ задачи — это про
    // подчинённость. Дать почитать задачу нужно и вне неё: юристу из
    // другого отдела, смежнику, руководителю чужого направления. Раньше
    // такого человека в списке просто не было, и задачу пересылали
    // скриншотом.
    .filter((u) => u.id !== currentUser?.id)
    .filter((u) => !u.deleted && !task.assignees.includes(u.id) && !task.grants.some((g) => g.userId === u.id))
    .filter((u) => {
      const q = grantSearch.trim().toLowerCase();
      if (!q) return true;
      return u.fullName.toLowerCase().includes(q)
        || (u.position || "").toLowerCase().includes(q);
    })
    .slice(0, 8);

  return (
    <div>
      {task.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-4">
          {task.tags.map((t) => (
            <span key={t} style={{ background: theme.surfaceAlt, color: theme.textMuted }} className="text-[11px] px-2 py-1 rounded-md">#{t}</span>
          ))}
        </div>
      )}

      <ReportSection theme={theme} task={task}
        canWrite={canEdit || access === "contribute" || isAuthor}
        onSaved={(t) => onTaskPatched(t)} onError={onError} />

      {/* pb-8 у секции чек-листа: при длинном списке последний пункт
          прижимался к краю прокручиваемой области, и его кнопки
          оказывались наполовину за границей окна. */}
      <ChecklistSection theme={theme} task={task} directory={directory} team={team}
        currentUser={currentUser} canManage={canEdit || task.createdBy === currentUser?.id}
        onToggle={toggleStep} onRename={renameStep} onAdd={addStep} onDelete={deleteStep} />

      {canEdit && (
        <div className="mb-4">
          <button onClick={() => setGrantOpen((v) => !v)} style={{ color: theme.accent }} className="flex items-center gap-1.5 text-[12.5px] font-medium">
            <Share2 size={13} /> Доступ к задаче{task.grants.length > 0 && ` (${task.grants.length})`}
          </button>

          {task.grants.map((g) => {
            const u = resolveUser(directory, g.userId);
            return (
              <div key={g.userId} className="flex items-center gap-2 mt-2">
                <Avatar user={u} size={22} theme={theme} />
                <span style={{ color: theme.text }} className="text-[12.5px] flex-1 truncate">{u.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[11.5px]">{GRANT_LABEL[g.access]}</span>
                <button onClick={() => saveGrants(task.grants.filter((x) => x.userId !== g.userId))} style={{ color: theme.danger }} title="Отозвать доступ"><X size={13} /></button>
              </div>
            );
          })}

          {grantOpen && (
            <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-xl p-2.5 mt-2">
              <input value={grantSearch} onChange={(e) => setGrantSearch(e.target.value)} placeholder="Найти сотрудника — по имени или должности, по всей системе"
                style={inputStyle(theme)} className="w-full rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none mb-2" />
              {candidates.map((u) => (
                <div key={u.id} className="flex items-center gap-2 py-1">
                  <Avatar user={u} size={20} theme={theme} />
                  <span style={{ color: theme.text }} className="text-[12.5px] flex-1 truncate">{u.fullName}</span>
                  <button onClick={() => saveGrants([...task.grants, { userId: u.id, access: "read" }])} style={{ color: theme.textMuted, border: `1px solid ${theme.border}` }} className="text-[11px] px-1.5 py-0.5 rounded">Просмотр</button>
                  <button onClick={() => saveGrants([...task.grants, { userId: u.id, access: "contribute" }])} style={{ color: theme.accent, border: `1px solid ${theme.border}` }} className="text-[11px] px-1.5 py-0.5 rounded">Участие</button>
                </div>
              ))}
              {candidates.length === 0 && <p style={{ color: theme.textMuted }} className="text-[12px]">Никого не найдено.</p>}
              <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-2 leading-relaxed">
                Человек получит только эту задачу — остальная доска останется закрытой. Она появится у него в разделе «Входящие».
              </p>
            </div>
          )}
        </div>
      )}

      {canEdit && (
        <button onClick={() => onRequestDelete(task.id)} style={{ color: theme.danger }} className="flex items-center gap-1.5 text-[12.5px] font-medium">
          <Trash2 size={13} /> Удалить задачу
        </button>
      )}
    </div>
  );
}

/* ------------------------------------------ расширенный чек-лист (п.8) */

// Права:
//   canManage — автор задачи, редактор или владелец проекта: правит
//     текст, исполнителя и срок, добавляет и удаляет пункты;
//   отметку о выполнении и фактический срок ставит ТОЛЬКО назначенный
//     исполнитель пункта — остальным чекбокс неактивен.
// ---------------------------------------------------------------- отчёт
// Отчёт о выполнении задачи (п.3): свободный текст, который затем
// выводится в печатной версии/PDF. Заполнять может тот, кто участвует
// в задаче (автор, редактор/владелец, назначенный исполнитель).
function ReportSection({ theme, task, canWrite, onSaved, onError }) {
  const [text, setText] = useState(task.report || "");
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  // Подхватываем внешние изменения отчёта (например, по WebSocket),
  // пока пользователь его не редактирует.
  useEffect(() => {
    if (!dirty) setText(task.report || "");
  }, [task.report, dirty]);

  const save = async () => {
    setSaving(true);
    try {
      const updated = await api.setReport(task.id, text);
      onSaved(updated);
      setDirty(false);
    } catch (e) {
      onError(e.message);
    } finally {
      setSaving(false);
    }
  };

  // У завершённой задачи отчёт только читается.
  //
  // Отчёт — итог работы: по нему её принимали, на него ссылались.
  // Правка задним числом делает такую ссылку недостоверной, поэтому
  // после закрытия задачи поле запирается. Нужно исправить — верните
  // задачу в работу, и это останется в истории. Сервер проверяет то же
  // самое, здесь — чтобы человек не набирал текст впустую.
  const locked = Boolean(task.completedAt);

  // Высота подгоняется под содержимое после каждой правки: сбрасываем
  // в auto, чтобы поле умело и уменьшаться, затем ставим по реальной
  // высоте текста.
  const reportRef = useRef(null);
  useEffect(() => {
    const el = reportRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  }, [text]);

  if (!canWrite || locked) {
    if (!task.report) {
      return locked && canWrite ? (
        <div className="mb-4">
          <div style={{ color: theme.text }} className="text-[13px] font-medium mb-2">Отчёт о выполнении</div>
          <p style={{ color: theme.textMuted }} className="text-[12.5px] leading-relaxed">
            Задача завершена без отчёта. Чтобы его добавить, верните задачу в работу.
          </p>
        </div>
      ) : null;
    }
    return (
      <div className="mb-4">
        <div style={{ color: theme.text }} className="text-[13px] font-medium mb-2">Отчёт о выполнении</div>
        <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed whitespace-pre-wrap">{task.report}</p>
        {locked && canWrite && (
          <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-1.5">
            Задача завершена — отчёт не редактируется. Верните её в работу, если нужно исправить.
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="mb-4">
      <div style={{ color: theme.text }} className="text-[13px] font-medium mb-2">Отчёт о выполнении</div>
      {/* В отчёте Enter — обычный перенос строки: это связный текст на
          несколько абзацев, и отправлять его по Enter было бы
          вредительством. Сохраняет Ctrl+Enter — привычное сочетание
          для «готово» в больших полях. */}
      {/* Поле растёт под текст, а не прокручивается внутри себя.
          Отчёт перечитывают и правят целиком, а во внутренней
          прокрутке на три строки его приходится листать в окне, которое
          и так листается, — две прокрутки одна в другой. */}
      <textarea ref={reportRef} value={text}
        onChange={(e) => { setText(e.target.value); setDirty(true); }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); }
        }}
        placeholder="Что сделано по задаче… Ctrl+Enter — сохранить" rows={3}
        style={{ ...inputStyle(theme), resize: "none", overflow: "hidden" }}
        className="w-full rounded-lg px-2.5 py-2 text-[13px] outline-none" />
      {dirty && (
        <div className="flex gap-2 mt-1.5">
          <button onClick={save} disabled={saving} style={{ background: theme.accent, color: theme.accentText }}
            className="rounded-lg px-3 py-1.5 text-[12.5px] font-semibold disabled:opacity-50">
            {saving ? "Сохранение…" : "Сохранить отчёт"}
          </button>
          <button onClick={() => { setText(task.report || ""); setDirty(false); }}
            style={{ color: theme.textMuted, border: `1px solid ${theme.border}` }} className="rounded-lg px-3 py-1.5 text-[12.5px]">
            Отмена
          </button>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- чек-лист
// Объединённый чек-лист (п.5): у каждого пункта необязательный
// исполнитель и срок. Если исполнитель задан — отметку ставит только он
// (или тот, кто ведёт чек-лист); если нет — любой участник. Состав
// (текст/исполнитель/срок/добавление/удаление) правит автор задачи,
// редактор или владелец проекта — это передаётся как canManage.
function ChecklistSection({ theme, task, directory, team, currentUser, canManage, onToggle, onRename, onAdd, onDelete }) {
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ body: "", assigneeId: "", dueDate: "" });
  const [editingId, setEditingId] = useState(null);

  const teamSet = new Set(team || []);
  const candidates = directory
    .filter((u) => !u.deleted && (teamSet.has(u.id) || u.id !== currentUser.id))
    .filter((u) => teamSet.has(u.id))
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  const resetDraft = () => setDraft({ body: "", assigneeId: "", dueDate: "" });

  // keepOpen — добавление с клавиатуры (Enter). Форма остаётся
  // открытой и пустой: пункты чек-листа почти всегда заводят пачкой, и
  // закрывать её после каждого значило бы заставлять тянуться к мыши
  // между строками.
  const submitNew = (keepOpen = false) => {
    if (!draft.body.trim()) return;
    onAdd({ body: draft.body.trim(), assigneeId: draft.assigneeId || null, dueDate: draft.dueDate || null });
    resetDraft();
    if (!keepOpen) setAdding(false);
  };

  const editor = (value, setValue, onSave, onCancel, onSubmitKey = onSave) => (
    <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-xl p-2.5 mb-2">
      <MultilineField theme={theme} value={value.body} autoFocus
        onChange={(body) => setValue({ ...value, body })}
        onSubmit={onSubmitKey}
        placeholder="Что нужно сделать. Ctrl+Enter — добавить, Enter — новая строка"
        className="w-full rounded-lg px-2.5 py-1.5 text-[13px] outline-none mb-2" />
      <div className="grid grid-cols-2 gap-2">
        <div>
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Исполнитель</div>
          <select value={value.assigneeId} onChange={(e) => setValue({ ...value, assigneeId: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none">
            <option value="">Не назначен (любой может отметить)</option>
            {candidates.map((u) => <option key={u.id} value={u.id}>{u.fullName}</option>)}
          </select>
        </div>
        <div>
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Срок (необязательно)</div>
          <input type="date" value={value.dueDate || ""} onChange={(e) => setValue({ ...value, dueDate: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none" />
        </div>
      </div>
      <div className="flex gap-2 mt-2">
        <button onClick={onSave} style={{ background: theme.accent, color: theme.accentText }} className="rounded-lg px-3 py-1.5 text-[12.5px] font-semibold">Сохранить</button>
        <button onClick={onCancel} style={{ color: theme.textMuted, border: `1px solid ${theme.border}` }} className="rounded-lg px-3 py-1.5 text-[12.5px]">Отмена</button>
      </div>
    </div>
  );

  return (
    // mb-4 плюс запас снизу: при длинном чек-листе последний пункт
    // упирался в границу прокручиваемой области, и его кнопки
    // оказывались наполовину срезаны.
    <div className="mb-4 pb-6">
      <div style={{ color: theme.text }} className="text-[13px] font-medium mb-2">Чек-лист</div>
      {(task.steps || []).length === 0 && !adding && (
        <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-2">Пунктов пока нет.</p>
      )}

      {(task.steps || []).map((s) => {
        if (editingId === s.id) {
          return (
            <StepEditor key={s.id} theme={theme} candidates={candidates} initial={s} editor={editor}
              onSave={(val) => { onRename(s.id, { body: val.body.trim(), assigneeId: val.assigneeId || null, dueDate: val.dueDate || null }); setEditingId(null); }}
              onCancel={() => setEditingId(null)} />
          );
        }
        const assignee = s.assigneeId ? resolveUser(directory, s.assigneeId) : null;
        const iAmAssignee = s.assigneeId === currentUser.id;
        const canToggle = canManage || iAmAssignee || (!s.assigneeId);
        const doneBy = s.doneBy ? resolveUser(directory, s.doneBy) : null;
        const overdue = s.dueDate && !s.done && s.dueDate < todayStr();
        return (
          <div key={s.id} className="mb-1.5 group">
            <div className="flex items-start gap-2">
              <span className="flex items-center pt-0.5" title={canToggle ? "" : "Отметить может только назначенный исполнитель"}>
                <Checkbox theme={theme} checked={s.done} disabled={!canToggle} onChange={(next) => onToggle(s.id, next)} />
              </span>
              <div className="flex-1 min-w-0">
                {/* Пункт может быть многострочным — переносы строк
                    сохраняем как есть, иначе весь смысл ввода по
                    Ctrl+Enter теряется при показе. */}
                <div style={{ color: theme.text, textDecoration: s.done ? "line-through" : "none" }}
                  className="text-[13px] whitespace-pre-wrap break-words">{s.body}</div>
                {(assignee || s.dueDate || (s.done && (doneBy || s.doneAt))) && (
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-0.5">
                    {assignee && !assignee.deleted && (
                      <span style={{ color: theme.textMuted }} className="text-[11px] flex items-center gap-1"><UsersIcon size={11} />{assignee.fullName}</span>
                    )}
                    {s.dueDate && (
                      <span style={{ color: overdue ? theme.danger : theme.textMuted }} className="text-[11px] flex items-center gap-1"><Calendar size={11} />до {fmtDate(s.dueDate)}</span>
                    )}
                    {s.done && (doneBy || s.doneAt) && (
                      <span style={{ color: theme.success }} className="text-[11px] flex items-center gap-1">
                        <Check size={11} />
                        {doneBy && !doneBy.deleted ? doneBy.fullName : "выполнено"}
                        {s.doneAt ? ` · ${fmtDateTime(s.doneAt)}` : ""}
                      </span>
                    )}
                  </div>
                )}
              </div>
              {canManage && (
                <span className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => setEditingId(s.id)} style={{ color: theme.textMuted }} title="Изменить"><Pencil size={13} /></button>
                  <button onClick={() => onDelete(s.id)} style={{ color: theme.danger }} title="Удалить"><Trash2 size={13} /></button>
                </span>
              )}
            </div>
          </div>
        );
      })}

      {adding && editor(draft, setDraft, () => submitNew(false),
        () => { resetDraft(); setAdding(false); },
        () => submitNew(true))}

      {canManage && !adding && (
        <button onClick={() => setAdding(true)} style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
          className="w-full flex items-center justify-center gap-1.5 rounded-xl py-2 text-[12.5px] font-medium mt-1">
          <Plus size={14} /> Добавить пункт
        </button>
      )}
    </div>
  );
}

function StepEditor({ theme, editor, initial, onSave, onCancel }) {
  const [val, setVal] = useState({ body: initial.body, assigneeId: initial.assigneeId || "", dueDate: initial.dueDate || "" });
  return editor(val, setVal, () => onSave(val), onCancel);
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/* -------------------------------------------------------- комментарии */

function CommentsTab({ theme, task, directory, currentUser, comments, setComments, readOnly, onError, onOpenUser }) {
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setText("");
    try {
      const created = await api.addComment(task.id, body);
      setComments((prev) => upsertById(prev, created));
    } catch (e) {
      onError(e.message);
    }
  };

  const saveEdit = async (id) => {
    const body = editText.trim();
    if (!body) return;
    try {
      const updated = await api.editComment(id, body);
      setComments((prev) => upsertById(prev, updated));
      setEditingId(null);
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteComment(id);
      setComments((prev) => prev.filter((c) => c.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {comments.map((c) => {
        const author = resolveUser(directory, c.authorId);
        const mine = c.authorId === currentUser.id;
        return (
          <div key={c.id} className="flex gap-2 mb-3.5 group">
            <button onClick={() => onOpenUser(author)} className="shrink-0"><Avatar user={author} size={26} theme={theme} /></button>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2 flex-wrap">
                <span style={{ color: author.deleted ? theme.textMuted : theme.text }} className="text-[12.5px] font-semibold">{author.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[11px]" title={fmtDateTime(c.createdAt)}>{fmtRelative(c.createdAt)}</span>
                {c.editedAt && (
                  <span style={{ color: theme.textMuted }} className="text-[11px] italic" title={`Изменено ${fmtDateTime(c.editedAt)}`}>изменено {fmtRelative(c.editedAt)}</span>
                )}
                {mine && editingId !== c.id && (
                  <span className="ml-auto flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => { setEditingId(c.id); setEditText(c.body); }} style={{ color: theme.textMuted }}><Pencil size={12} /></button>
                    <button onClick={() => remove(c.id)} style={{ color: theme.danger }}><Trash2 size={12} /></button>
                  </span>
                )}
              </div>

              {editingId === c.id ? (
                <div className="flex items-center gap-2 mt-1">
                  <input value={editText} onChange={(e) => setEditText(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") saveEdit(c.id); if (e.key === "Escape") setEditingId(null); }}
                    autoFocus style={inputStyle(theme)} className="flex-1 rounded-lg px-2.5 py-1.5 text-[13px] outline-none" />
                  <button onClick={() => saveEdit(c.id)} style={{ color: theme.success }}><Check size={15} /></button>
                  <button onClick={() => setEditingId(null)} style={{ color: theme.textMuted }}><X size={15} /></button>
                </div>
              ) : (
                <p style={{ color: theme.text }} className="text-[13px] leading-snug break-words whitespace-pre-wrap">{c.body}</p>
              )}
            </div>
          </div>
        );
      })}

      {comments.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px]">Комментариев пока нет. Начните обсуждение.</p>}

      {readOnly ? (
        <p style={{ color: theme.textMuted }} className="text-[12px] mt-4">Доступ только на просмотр — комментировать нельзя.</p>
      ) : (
        <div className="flex items-end gap-2 mt-4">
          {/* Те же клавиши, что в чек-листе и отчёте: Enter отправляет,
              Ctrl+Enter переносит строку. Раньше здесь было
              однострочное поле, и абзац в комментарий было не
              вставить — Enter отправлял на первой же строке. */}
          <MultilineField theme={theme} value={text} onChange={setText} onSubmit={send}
            placeholder="Написать комментарий. Ctrl+Enter — отправить, Enter — новая строка"
            className="flex-1 rounded-lg px-3 py-2 text-[13px] outline-none" />
          <button onClick={send} style={{ background: theme.accent, color: theme.accentText }} className="rounded-lg p-2.5 shrink-0"><Send size={15} /></button>
        </div>
      )}
    </div>
  );
}

/* --------------------------------------------------------------- файлы */

function FilesTab({ theme, task, directory, files, setFiles, readOnly, onError }) {
  // Окно предпросмотра — то же, что в переписке. Один компонент на всё
  // приложение: иначе набор форматов и правила открытия разойдутся.
  const [preview, setPreview] = useState(null);
  const inputRef = useRef();
  const [uploading, setUploading] = useState(false);
  const [renamingId, setRenamingId] = useState(null);
  const [renameText, setRenameText] = useState("");

  const upload = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const created = await api.uploadAttachment(task.id, file);
      setFiles((prev) => upsertById(prev, created));
    } catch (e) {
      onError(e.message);
    } finally {
      setUploading(false);
    }
  };

  const rename = async (id) => {
    const title = renameText.trim();
    if (!title) return;
    try {
      const updated = await api.renameAttachment(id, title);
      setFiles((prev) => upsertById(prev, updated));
      setRenamingId(null);
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteAttachment(id);
      setFiles((prev) => prev.filter((f) => f.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {files.map((f) => {
        const author = resolveUser(directory, f.authorId);
        const isImage = f.mime?.startsWith("image/");
        return (
          <div key={f.id} style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-xl p-2.5 mb-2 group">
            <div className="flex items-center gap-2">
              {isImage ? (
                <button onClick={() => setPreview(f)} className="shrink-0" title="Посмотреть">
                  <AuthImage path={`/attachments/${f.id}/content`} alt={f.title}
                    className="w-10 h-10 rounded-lg object-cover" theme={theme} />
                </button>
              ) : (
                <span style={{ background: theme.surface, color: theme.textMuted }} className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"><Paperclip size={16} /></span>
              )}

              <div className="min-w-0 flex-1">
                {renamingId === f.id ? (
                  <div className="flex items-center gap-1.5">
                    <input value={renameText} onChange={(e) => setRenameText(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") rename(f.id); if (e.key === "Escape") setRenamingId(null); }}
                      autoFocus style={inputStyle(theme)} className="flex-1 rounded-lg px-2 py-1 text-[12.5px] outline-none" />
                    <button onClick={() => rename(f.id)} style={{ color: theme.success }}><Check size={14} /></button>
                    <button onClick={() => setRenamingId(null)} style={{ color: theme.textMuted }}><X size={14} /></button>
                  </div>
                ) : (
                  <div style={{ color: theme.text }} className="text-[12.5px] font-medium truncate">{f.title || f.filename}</div>
                )}
                <div style={{ color: theme.textMuted }} className="text-[11px] truncate">
                  {fmtSize(f.size)} · {author.fullName} · {fmtRelative(f.createdAt)}
                  {f.editedAt && <span title={`Изменено ${fmtDateTime(f.editedAt)}`}> · изменено</span>}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Предпросмотр в окне, а не в новой вкладке: вкладка
                    уводит из задачи, а посмотреть вложение обычно нужно
                    не отрываясь от неё. Открываются и офисные форматы —
                    таблицы и docx разбираются на месте. */}
                <button onClick={() => setPreview(f)} style={{ color: theme.textMuted }}
                  title="Посмотреть в окне"><ExternalLink size={14} /></button>
                <button onClick={() => downloadFile(`/attachments/${f.id}/content?download=1`, f.filename)}
                  style={{ color: theme.textMuted }} title="Скачать"><Download size={14} /></button>
                {f.canEdit && (
                  <>
                    <button onClick={() => { setRenamingId(f.id); setRenameText(f.title || f.filename); }} style={{ color: theme.textMuted }} title="Переименовать"><Pencil size={13} /></button>
                    <button onClick={() => remove(f.id)} style={{ color: theme.danger }} title="Удалить"><Trash2 size={13} /></button>
                  </>
                )}
              </div>
            </div>
          </div>
        );
      })}

      {files.length === 0 && <p style={{ color: theme.textMuted }} className="text-[13px] mb-3">Файлов нет.</p>}

      {!readOnly && (
        <>
          <input ref={inputRef} type="file" className="hidden" onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
          <button onClick={() => inputRef.current?.click()} disabled={uploading} style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
            className="w-full flex items-center justify-center gap-1.5 text-[12.5px] font-medium rounded-lg py-2.5 mt-2 disabled:opacity-50">
            <Upload size={14} /> {uploading ? "Загружаем…" : "Загрузить файл"}
          </button>
        </>
      )}

      {/* Окно предпросмотра — внутри корневого элемента вкладки.
          Снаружи оно оказывалось вторым узлом рядом с ним, а return
          отдаёт только один: отсюда и «Expected ) but found {». */}
      {preview && (
        <FilePreview theme={theme} title={preview.title} filename={preview.filename}
          mime={preview.mime} path={`/attachments/${preview.id}/content`}
          pdfPath={`/attachments/${preview.id}/pdf`}
          downloadPath={`/attachments/${preview.id}/content?download=1`}
          onClose={() => setPreview(null)} />
      )}
    </div>
  );
}

/* --------------------------------------------------------------- связи */

// У связи два конца, и читается она с них по-разному. Раньше подпись
// бралась одна и та же в обе стороны — из-за этого и подзадача, и её
// родитель показывались как «Подзадача», что бессмысленно.
const LINK_KINDS = {
  blocks: {
    out: "Блокирует", in: "Заблокирована задачей",
    hint: "пока блокирующая задача не завершена, эту закрыть нельзя",
  },
  relates: {
    out: "Связана с", in: "Связана с",
    hint: "задачи касаются одного вопроса",
  },
  subtask: {
    // Направление: from — родитель, to — часть работы.
    out: "Подзадача", in: "Родительская задача",
    hint: "часть более крупной работы",
  },
};

// Короткий кусок описания вокруг найденного слова — чтобы по строке
// было видно, за что задача попала в список.
function excerpt(text, q, around = 28) {
  const src = (text || "").replace(/\s+/g, " ").trim();
  const low = src.toLowerCase();
  const at = low.indexOf(q);
  if (at < 0) return "";
  // У отдельных символов нижний регистр длиннее самого символа (турецкое
  // «İ» превращается в два), и тогда позиция в приведённой строке не
  // совпадает с позицией в исходной. Случай редкий, поэтому не считаем
  // смещение, а просто показываем начало описания.
  const from = low.length === src.length ? Math.max(0, at - around) : 0;
  const to = Math.min(src.length, from + q.length + around * 2);
  return (from > 0 ? "…" : "") + src.slice(from, to) + (to < src.length ? "…" : "");
}

function LinksTab({ theme, task, links, setLinks, canEdit, onError, onOpenTask }) {
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState("relates");
  const [found, setFound] = useState([]);
  const [searching, setSearching] = useState(false);

  // Поиск задач для связывания идёт по уже загруженной доске, а не
  // отдельным запросом: связывают почти всегда внутри одного проекта,
  // а серверный поиск по всем доступным задачам — отдельная работа.
  //
  // Искать только по названию было мало: в переписке задачу называют
  // номером входящего документа, а условия работы живут в описании.
  // Поэтому ищем по названию, описанию и входящему номеру — тому же
  // набору, по которому работает поиск в списках задач.
  useEffect(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) { setFound([]); return; }
    setSearching(true);
    // Ответ на устаревший запрос отбрасывается: два запроса могут
    // вернуться не в том порядке, в каком ушли, и тогда в списке
    // оказывались совпадения для уже стёртой строки поиска.
    let dead = false;
    const timer = setTimeout(async () => {
      try {
        const all = await api.tasks(task.boardId);
        if (dead) return;
        const hit = (t) => [t.title, t.description, t.incomingNumber]
          .some((v) => (v || "").toLowerCase().includes(q));
        setFound(all
          .filter((t) => t.id !== task.id && hit(t))
          .filter((t) => !links.some((l) => l.toTask === t.id || l.fromTask === t.id))
          .slice(0, 6));
      } catch (e) {
        if (!dead) onError(e.message);
      } finally {
        if (!dead) setSearching(false);
      }
    }, 300);
    return () => { dead = true; clearTimeout(timer); };
  }, [query, task.id, task.boardId, links, onError]);

  const add = async (toTask) => {
    try {
      const created = await api.createTaskLink(task.id, toTask, kind);
      setLinks((prev) => [...prev, created]);
      setAdding(false);
      setQuery("");
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = async (id) => {
    try {
      await api.deleteTaskLink(id);
      setLinks((prev) => prev.filter((l) => l.id !== id));
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <div>
      {links.map((l) => {
        // Направление важно: «блокирует» и «заблокирована» — это одна
        // строка, прочитанная с разных концов.
        const outgoing = l.fromTask === task.id;
        const info = LINK_KINDS[l.kind] || LINK_KINDS.relates;
        const label = outgoing ? info.out : info.in;
        // Незакрытая блокирующая задача — причина, по которой эту
        // нельзя завершить. Показываем это явно, а не оставляем
        // человека гадать над отказом сервера.
        const blocking = l.kind === "blocks" && !outgoing && !l.completed;
        return (
          <div key={l.id} style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
            className="rounded-xl p-2.5 mb-1.5 flex items-center gap-2 group">
            <span className="mono text-[9.5px] uppercase px-1.5 py-0.5 rounded shrink-0"
              style={{
                background: blocking ? theme.danger : theme.surface,
                color: blocking ? "#fff" : theme.textMuted,
              }}
              title={info.hint}>
              {label}
            </span>
            <button onClick={() => onOpenTask && onOpenTask(l.toTask === task.id ? l.fromTask : l.toTask)}
              className="flex-1 min-w-0 text-left">
              <span style={{
                color: theme.text,
                textDecoration: l.completed ? "line-through" : "none",
                opacity: l.completed ? 0.65 : 1,
              }} className="text-[12.5px] truncate block">
                {l.title}
              </span>
            </button>
            {canEdit && (
              <button onClick={() => remove(l.id)} style={{ color: theme.danger }}
                className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                <X size={13} />
              </button>
            )}
          </div>
        );
      })}

      {links.length === 0 && (
        <p style={{ color: theme.textMuted }} className="text-[13px] mb-3">Связей нет.</p>
      )}

      {canEdit && !adding && (
        <button onClick={() => setAdding(true)}
          style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
          className="w-full flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-[12.5px] font-medium mt-2">
          <Plus size={14} /> Связать с задачей
        </button>
      )}

      {adding && (
        <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
          className="rounded-xl p-2.5 mt-2">
          <div className="flex gap-1.5 mb-2">
            {Object.entries(LINK_KINDS).map(([k, v]) => (
              <button key={k} onClick={() => setKind(k)} title={v.hint}
                style={{
                  background: kind === k ? theme.accent : theme.surface,
                  color: kind === k ? theme.accentText : theme.text,
                  border: `1px solid ${theme.border}`,
                }}
                className="flex-1 rounded-lg py-1.5 text-[11.5px] font-medium">
                {v.out}
              </button>
            ))}
          </div>
          <input value={query} onChange={(e) => setQuery(e.target.value)} autoFocus
            placeholder="Название, описание или входящий номер (от двух символов)"
            style={inputStyle(theme)}
            className="w-full rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none mb-1.5" />

          {searching && (
            <p style={{ color: theme.textMuted }} className="text-[12px] py-1">Ищем…</p>
          )}
          {found.map((t) => {
            // Если нашли не по названию, показываем, что именно
            // совпало: иначе в списке оказывается задача с посторонним
            // на вид названием и непонятно, почему она здесь.
            const q = query.trim().toLowerCase();
            const inTitle = (t.title || "").toLowerCase().includes(q);
            const inNumber = (t.incomingNumber || "").toLowerCase().includes(q);
            const hint = inTitle ? "" : inNumber
              ? `вх. № ${t.incomingNumber}`
              : excerpt(t.description, q);
            return (
              <button key={t.id} onClick={() => add(t.id)}
                className="w-full text-left px-2 py-1.5 rounded-lg hover:opacity-80">
                <span style={{ color: theme.text }} className="block text-[12.5px] truncate">
                  {t.title}
                </span>
                {hint && (
                  <span style={{ color: theme.textMuted }} className="block text-[11px] truncate">
                    {hint}
                  </span>
                )}
              </button>
            );
          })}
          {!searching && query.trim().length >= 2 && found.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[12px] py-1">
              Ничего не найдено в этом проекте.
            </p>
          )}

          <button onClick={() => { setAdding(false); setQuery(""); }}
            style={{ color: theme.textMuted }} className="text-[12px] mt-1.5">
            Отмена
          </button>
        </div>
      )}
    </div>
  );
}

/* ----------------------------------------------------- поручение задачи */

// Смена исполнителей без захода в форму редактирования.
//
// Поручение — самостоятельное действие: условия задачи не меняются,
// меняется только то, кто её делает. Раньше ради этого приходилось
// открывать форму со всеми полями сразу, где ничего не стоит задеть
// срок или описание.
//
// Сохраняется одним патчем `assignees` — сервер сам разберётся, кого
// добавили, а кого сняли, и разошлёт уведомления назначенным.
/* ------------------------------------------------------- срок задачи */

// Отдельное окно для срока — как «Поручить» для исполнителей.
//
// Перенос даты случается часто и сам по себе: согласовали новый срок —
// поставили. Ради этого открывать форму задачи со всеми полями значит
// каждый раз рисковать задеть чужую правку описания или снять
// исполнителя, а на карточке при этом не видно, что именно изменилось.
function DueDateModal({ theme, task, onClose, onSaved, onError }) {
  const [date, setDate] = useState(task.dueDate || "");
  const [busy, setBusy] = useState(false);

  // Приоритет «Установлен срок» без даты теряет смысл — это тот же
  // запрет, что в форме задачи.
  const datedPriority = task.priority === "dated";

  const save = async (value) => {
    setBusy(true);
    try {
      // Пустая строка снимает срок, отсутствие поля — оставляет как
      // было. Передать null нельзя: сервер понимает его как «не
      // менять», и «Снять срок» ничего бы не делал.
      onSaved(await api.updateTask(task.id, { dueDate: value || "" }));
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  // Частые сдвиги — от сегодняшнего дня, а не от прежнего срока:
  // «через неделю» люди отсчитывают от разговора, а не от даты,
  // которая уже прошла.
  const shift = (days) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="task-due">
      <ModalHeader theme={theme} title="Срок исполнения"
        subtitle={`«${task.title}»`} onClose={onClose} />

      <div className="flex flex-wrap gap-1.5 mb-3">
        {[["Сегодня", 0], ["Завтра", 1], ["Через неделю", 7], ["Через месяц", 30]].map(([label, d]) => (
          <button key={label} onClick={() => setDate(shift(d))}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="rounded-full px-2.5 py-1 text-[11.5px]">{label}</button>
        ))}
      </div>

      <Field label="Дата" theme={theme}
        hint={datedPriority
          ? "У задачи приоритет «Установлен срок» — снять дату нельзя, только перенести"
          : (task.dueDate ? `Сейчас: ${fmtDate(task.dueDate)}` : "Срок не задан")}>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <div className="flex gap-2 mt-4">
        {task.dueDate && !datedPriority && (
          <button onClick={() => save("")} disabled={busy}
            style={{ color: theme.danger, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 py-2.5 text-[13px] font-medium disabled:opacity-50"
            title="Оставить задачу без срока">
            Снять срок
          </button>
        )}
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={() => save(date)} disabled={busy || !date}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">
          {busy ? "Сохраняем…" : "Сохранить"}
        </button>
      </div>
    </Modal>
  );
}

function AssignModal({ theme, task, directory, team, teamGroups = [], currentUser, onClose, onSaved, onError }) {
  const [ids, setIds] = useState(task.assignees || []);
  const [busy, setBusy] = useState(false);

  // Кандидаты и «чужие» — по тому же правилу, что в форме задачи
  // (lib/assignees.js): раньше списки в двух окнах расходились.
  const candidates = assigneeCandidates({
    team, assigned: task.assignees || [], currentUserId: currentUser?.id,
  });
  const outside = outsideTeam({ team, assigned: task.assignees || [] });

  const toggle = (id) => setIds((prev) =>
    (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const save = async () => {
    setBusy(true);
    try {
      onSaved(await api.updateTask(task.id, { assignees: ids }));
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const chosen = ids.map((id) => resolveUser(directory, id));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="task-assign">
      <ModalHeader theme={theme} title="Поручить задачу"
        subtitle={`«${task.title}»`} onClose={onClose} />

      {/* Выбранные — сверху и вне групп: снять человека должно быть так
          же просто, как назначить, не разыскивая его по группам. */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {chosen.length === 0 && (
          <span style={{ color: theme.textMuted }} className="text-[12.5px]">Исполнители не назначены</span>
        )}
        {chosen.map((u) => (
          <button key={u.id} onClick={() => toggle(u.id)}
            style={{ background: theme.surfaceAlt, color: theme.text }}
            className="flex items-center gap-1.5 pr-2 rounded-full text-[12px]"
            title="Убрать из исполнителей">
            <Avatar user={u} size={22} theme={theme} />
            {u.fullName}
            <X size={12} style={{ color: theme.textMuted }} />
          </button>
        ))}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t pt-2 max-h-[46vh] overflow-y-auto mb-3">
        <AssigneePicker theme={theme} directory={directory}
          candidates={candidates} groups={teamGroups}
          selected={ids} onToggle={toggle} onChange={setIds} outside={outside} />
      </div>

      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={save} disabled={busy}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">
          {busy ? "Сохраняем…" : "Поручить"}
        </button>
      </div>
    </Modal>
  );
}
