import React, { useMemo, useState } from "react";
import { Eye, EyeOff, KeyRound } from "lucide-react";

import { api } from "../lib/api.js";
import { Modal, ModalHeader, PasswordRules, inputStyle } from "../lib/ui.jsx";
import { checkPassword } from "../lib/password.js";

// Смена собственного пароля.
//
// Требования показываются списком и отмечаются по мере набора, а не
// высыпаются ошибкой после нажатия «Сохранить»: «пароль слишком
// простой» без подробностей заставляет угадывать, чего не хватило.
//
// Текущий пароль спрашивается обязательно — это защита от чужой
// незакрытой вкладки: иначе любой, кто сел за компьютер, меняет пароль
// и владелец больше не входит. Проверяет его сервер, здесь поле просто
// обязательное.
export default function PasswordModal({ theme, onClose, onDone, onError }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [repeat, setRepeat] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [touched, setTouched] = useState(false);

  const check = useMemo(() => checkPassword(next), [next]);
  const sameAsCurrent = Boolean(next) && next === current;
  const mismatch = Boolean(repeat) && repeat !== next;
  const canSave = Boolean(current) && check.valid && !mismatch
    && Boolean(repeat) && !sameAsCurrent && !busy;

  const save = async () => {
    if (!canSave) { setTouched(true); return; }
    setBusy(true);
    try {
      // Сервер гасит все сессии и тут же выдаёт этому устройству новую
      // пару токенов — api.changePassword её сохраняет, поэтому
      // текущая работа не прерывается.
      await api.changePassword(current, next);
      onDone("Пароль изменён. На остальных устройствах выполнен выход");
      onClose();
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const field = (label, value, setValue, props = {}) => (
    <div className="mb-3">
      <label style={{ color: theme.textMuted }}
        className="text-[11.5px] font-medium uppercase tracking-wide">{label}</label>
      <input type={show ? "text" : "password"} value={value} autoComplete="off"
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && save()}
        style={inputStyle(theme)}
        className="w-full mt-1 rounded-lg px-2.5 py-2 text-[13px] outline-none"
        {...props} />
    </div>
  );

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="password">
      <ModalHeader theme={theme} title="Смена пароля" onClose={onClose}
        subtitle="Остальные устройства после смены разлогинятся" />

      {field("Текущий пароль", current, setCurrent, { autoFocus: true })}
      {field("Новый пароль", next, setNext)}
      {field("Новый пароль ещё раз", repeat, setRepeat)}

      <button onClick={() => setShow((v) => !v)} style={{ color: theme.textMuted }}
        className="flex items-center gap-1.5 text-[12px] mb-3">
        {show ? <EyeOff size={13} /> : <Eye size={13} />}
        {show ? "Скрыть пароли" : "Показать пароли"}
      </button>

      <div className="mb-3">
        <PasswordRules theme={theme} value={next} />
      </div>

      {/* Ошибка показывается по ходу набора: ждать нажатия кнопки,
          чтобы сообщить про короткий пароль, незачем. */}
      {(check.error || mismatch || sameAsCurrent || (touched && !current)) && (
        <p style={{ color: theme.danger }} className="text-[12px] mb-3">
          {!current && touched ? "Укажите текущий пароль"
            : sameAsCurrent ? "Новый пароль совпадает с текущим"
            : mismatch ? "Повтор не совпадает с новым паролем"
            : check.error}
        </p>
      )}

      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={save} disabled={busy}
          style={{
            background: canSave ? theme.accent : theme.surfaceAlt,
            color: canSave ? theme.accentText : theme.textMuted,
            border: `1px solid ${theme.border}`,
          }}
          className="flex-1 flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-[13px] font-semibold">
          <KeyRound size={14} /> {busy ? "Сохраняем…" : "Сменить пароль"}
        </button>
      </div>

      <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-3 leading-relaxed">
        Русские буквы подходят: «Пароль12» — восемь символов и три типа.
      </p>
    </Modal>
  );
}
