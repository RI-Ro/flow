// Перевод JSX в обычный JS для проверок без сборщика.
//
// Интерфейс здесь не собирается целиком: нужен один кадр разметки,
// чтобы пройтись по нему и поискать то, чего глазом не увидеть, —
// NaN в координате, «undefined» в цвете, пустой путь. Транспилятор
// берётся из node_modules, а если его нет — проверка честно
// пропускается, а не падает.
import fs from "fs";
import path from "path";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const SRC = path.join(import.meta.dirname, "..", "..", "src");
const OUT = path.join(import.meta.dirname, "build");

export async function loadTypescript() {
  for (const name of ["typescript", "esbuild"]) {
    try {
      return { name, mod: require(name) };
    } catch { /* ищем дальше */ }
  }
  return null;
}

const FILES = [
  ["lib/format.js", "format.mjs"],
  ["lib/charts.jsx", "charts.mjs"],
  ["components/System.jsx", "system.mjs"],
];

// Подмена импортов: настоящие react, lucide-react и api.js в этой
// проверке не нужны — нужна разметка, а не работающее приложение.
const REWRITE = [
  [/from "react"/g, 'from "../react.mjs"'],
  [/from "lucide-react"/g, 'from "../icons.mjs"'],
  [/from "\.\/format\.js"/g, 'from "./format.mjs"'],
  [/from "\.\.\/lib\/format\.js"/g, 'from "./format.mjs"'],
  [/from "\.\.\/lib\/charts\.jsx"/g, 'from "./charts.mjs"'],
  [/from "\.\.\/lib\/api\.js"/g, 'from "../api.mjs"'],
];

export async function build() {
  const found = await loadTypescript();
  if (!found) return null;
  fs.mkdirSync(OUT, { recursive: true });

  for (const [from, to] of FILES) {
    const code = fs.readFileSync(path.join(SRC, from), "utf8");
    let js;
    if (found.name === "typescript") {
      const ts = found.mod;
      const out = ts.transpileModule(code, {
        fileName: from, reportDiagnostics: true,
        compilerOptions: {
          jsx: ts.JsxEmit.React, module: ts.ModuleKind.ESNext,
          target: ts.ScriptTarget.ES2020,
        },
      });
      if (out.diagnostics?.length) {
        for (const d of out.diagnostics) {
          console.log("✗", from, ts.flattenDiagnosticMessageText(d.messageText, "\n"));
        }
        throw new Error("JSX не разбирается");
      }
      js = out.outputText;
    } else {
      js = found.mod.transformSync(code, { loader: "jsx", format: "esm" }).code;
    }
    for (const [re, sub] of REWRITE) js = js.replace(re, sub);
    fs.writeFileSync(path.join(OUT, to), js);
  }
  return OUT;
}
