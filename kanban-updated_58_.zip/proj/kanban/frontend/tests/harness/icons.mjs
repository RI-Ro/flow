// Значки заменяются пустышками: нас интересует разметка графиков.
const stub = (name) => function Icon(props) { return { type: "icon:" + name, props: props || {}, children: [] }; };
export const Activity = stub("Activity"), AlertTriangle = stub("AlertTriangle"),
  Clock = stub("Clock"), Database = stub("Database"), HardDrive = stub("HardDrive"),
  Layers = stub("Layers"), RefreshCw = stub("RefreshCw"), Server = stub("Server"),
  Timer = stub("Timer"), Users = stub("Users"), Zap = stub("Zap"),
  ChevronDown = stub("ChevronDown"), ChevronRight = stub("ChevronRight"),
  Gauge = stub("Gauge");
