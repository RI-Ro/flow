export const api = { systemState: async () => ({}) };
