// Минимальный React для одного прохода отрисовки: хуки отдают начальные
// значения, элементы собираются в дерево. Эффекты не выполняются —
// нам нужна разметка первого кадра, а не жизненный цикл.
let hookState = [];
let hookIdx = 0;

export function useState(init) {
  const i = hookIdx++;
  if (!(i in hookState)) hookState[i] = typeof init === "function" ? init() : init;
  return [hookState[i], (v) => { hookState[i] = typeof v === "function" ? v(hookState[i]) : v; }];
}
export function useMemo(fn) { return fn(); }
export function useRef(v) { return { current: v }; }
export function useCallback(fn) { return fn; }
export function useEffect() {}
export function createElement(type, props, ...children) {
  const kids = children.flat(Infinity).filter((c) => c != null && c !== false);
  // children передаются и свойством — так делает React, и без этого
  // компонент-обёртка (например, раздел дашборда) не видит вложенного.
  const merged = { ...(props || {}) };
  if (kids.length) merged.children = kids.length === 1 ? kids[0] : kids;
  return { type, props: merged, children: kids };
}
export const Fragment = "fragment";
export function resetHooks(seed = []) { hookState = seed.slice(); hookIdx = 0; }

// Каждый компонент получает своё состояние хуков: иначе вложенный
// компонент продолжал бы читать состояние родителя по тем же индексам.
export function renderComponent(type, props, seed = []) {
  const savedState = hookState;
  const savedIdx = hookIdx;
  hookState = seed.slice();
  hookIdx = 0;
  try {
    return type(props || {});
  } finally {
    hookState = savedState;
    hookIdx = savedIdx;
  }
}
export default { createElement, Fragment, useState, useMemo, useRef, useCallback, useEffect };
