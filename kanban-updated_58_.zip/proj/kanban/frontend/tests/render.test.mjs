// Проверка разметки дашборда «Состояние системы».
//
// Запуск:
//   node tests/render.test.mjs                 — на выдуманных данных
//   node tests/render.test.mjs sample.json     — на настоящем ответе
//
// Что проверяется. Компоненты отрисовываются один раз на заготовке
// вместо React (tests/harness), и по полученному дереву обходятся все
// атрибуты. Ищется то, чего на глаз не увидеть: NaN в координате —
// линия просто исчезает; «undefined» в цвете — элемент красится
// наследованным; путь без координат — пустая панель. Отдельно
// прогоняются вырожденные данные: ни одной точки, одна точка, все нули,
// одинаковое время, значения на девять порядков друг от друга.
//
// Это не замена взгляду на экран: проверка не знает, красиво ли
// получилось. Она знает, что ничего не сломано.

import fs from "fs";
import path from "path";
import { build } from "./harness/build.mjs";
import { resetHooks, renderComponent } from "./harness/react.mjs";

const out = await build();
if (!out) {
  console.log("· ни typescript, ни esbuild не найдены (npm install) — проверка пропущена");
  process.exit(0);
}
const { TimeChart, Sparkline, Gauge, thresholdColor } = await import(path.join(out, "charts.mjs"));
const { seriesColor } = await import(path.join(out, "format.mjs"));
const System = (await import(path.join(out, "system.mjs"))).default;

const THEMES = [
  { name: "тёмная", dark: true, surface: "#131318", surfaceAlt: "#1c1c23", border: "#26262f",
    text: "#f2f2f5", textMuted: "#8b8b96", accent: "#c8ff2d", accentText: "#0a0a0c",
    success: "#7ee787", warning: "#ffd166", danger: "#ff6b81", info: "#7c5cff" },
  { name: "светлая", dark: false, surface: "#ffffff", surfaceAlt: "#eef1f6", border: "#e4e7ec",
    text: "#15171c", textMuted: "#6b7280", accent: "#4f46e5", accentText: "#ffffff",
    success: "#059669", warning: "#b45309", danger: "#dc2626", info: "#4f46e5" },
];

// Настоящий ответ сервера, если его подложили, иначе выдуманный ряд:
// проверка должна работать и без доступа к живому серверу.
const argv = process.argv[2];
const sample = argv && fs.existsSync(argv) ? JSON.parse(fs.readFileSync(argv, "utf8")) : null;
const payload = sample || fakePayload();

function fakePayload() {
  const t0 = Date.now() - 60 * 60 * 1000;
  const points = [...Array(40)].map((_, i) => {
    const wave = (k) => Math.abs(Math.sin((i + k) / 5)) * (k + 1);
    return {
      t: t0 + i * 90_000,
      rps: wave(3), rps2xx: wave(2), rps3xx: wave(0) / 9, rps4xx: wave(1) / 4, rps5xx: wave(0) / 30,
      avg: wave(1) / 900, p50: wave(1) / 1800, p95: wave(2) / 300, p99: wave(3) / 120,
      inFlight: Math.round(wave(1)), bytesPerSec: wave(4) * 40_000,
      wsEvents: wave(2) / 3, wsConns: Math.round(wave(2)), wsUsers: Math.round(wave(1)),
      dbTxPerSec: wave(2), dbAvg: wave(1) / 700, dbP95: wave(2) / 250, dbErrors: 0,
      poolTotal: 9, poolAcquired: Math.round(wave(1)), poolIdle: 8, poolMax: 40, poolWaits: 0,
      commits: wave(3), rollbacks: wave(0) / 50, blksHit: wave(5) * 90, blksRead: wave(1) / 5,
      cacheHit: 99.4 + wave(0) / 9, tupReturned: wave(6) * 300, tupFetched: wave(4) * 120,
      deadlocks: 0, connsActive: 1, connsIdle: 8, connsIdleTx: 0,
      longestQuery: wave(0) / 20, longestTx: 0, idleInTx: 0, locksWaiting: 0,
    };
  });
  const last = points[points.length - 1];
  return {
    at: new Date().toISOString(), uptimeSeconds: 3600 * 7 + 42, windowSeconds: 3600,
    stepSeconds: 90, historySeconds: 3600, sampleStep: 10,
    summary: {
      rps: last.rps, errShare: 0.4, clientErrShare: 3.1, avg: last.avg, p50: last.p50,
      p95: last.p95, p99: last.p99, inFlight: 1, slowPerMin: 0.4, bytesPerSec: last.bytesPerSec,
      wsConns: 3, wsUsers: 2, dbTxPerSec: last.dbTxPerSec, dbAvg: last.dbAvg, dbP95: last.dbP95,
      dbErrors: 0, poolAcquired: 2, poolMax: 40, poolUsage: 5, poolWaits: 0,
      dbSizeBytes: 10_779_671, cacheHit: 99.8, connections: 9, maxConnections: 100,
      rollbackShare: 0.2, longestQuery: 0.04, longestTx: 0, idleInTx: 0, locksWaiting: 0, deadlocks: 0,
    },
    points,
    routes: [
      { method: "GET", route: "/api/boards/:boardID/tasks", requests: 812, rps: 1.4, avg: 0.0042, p95: 0.0068, p99: 0.011, errors: 0, errShare: 0 },
      { method: "GET", route: "/api/me", requests: 410, rps: 0.7, avg: 0.0007, p95: 0.001, p99: 0.002, errors: 3, errShare: 0.7 },
    ],
    slow: [{ at: new Date().toISOString(), method: "GET", route: "/api/tasks", status: 200, seconds: 0.74 }],
    tables: [
      { table: "tasks", sizeBytes: 4_800_000, liveRows: 15_000, deadRows: 1200, deadShare: 7.4, vacuumAge: 86_400, seqScans: 12, idxScans: 90_000 },
      { table: "comments", sizeBytes: 900_000, liveRows: 4000, deadRows: 0, deadShare: 0, vacuumAge: 0, seqScans: 3, idxScans: 1200 },
    ],
    entities: { users: 18, users_active: 18, boards: 3, tasks: 15, tasks_open: 15, tasks_overdue: 3, comments: 1, sessions: 4 },
    statuses: { 200: 3791, 401: 74, 404: 150, 500: 2 },
    wsKinds: { task: 120, comment: 44 },
    events: { login: 8 },
  };
}

let bad = 0;
const fail = (m) => { console.log("✗ " + m); bad++; };

const NUMERIC = ["x", "y", "x1", "x2", "y1", "y2", "cx", "cy", "r"];
function audit(node, label, stats) {
  if (node == null || typeof node !== "object") {
    if (typeof node === "string") {
      stats.text++;
      if (/NaN|undefined|Infinity|\[object/.test(node)) fail(`${label}: текст «${node}»`);
    }
    return;
  }
  if (Array.isArray(node)) { node.forEach((n) => audit(n, label, stats)); return; }
  if (typeof node.type === "function") {
    audit(renderComponent(node.type, node.props), label, stats);
    return;
  }
  stats.nodes++;
  const p = node.props || {};
  for (const k of NUMERIC) {
    if (p[k] != null && !Number.isFinite(Number(p[k]))) fail(`${label}: <${node.type} ${k}="${p[k]}">`);
  }
  if (typeof p.d === "string") {
    stats.paths = (stats.paths || 0) + 1;
    if (/NaN|Infinity|undefined/.test(p.d)) fail(`${label}: путь ${p.d.slice(0, 50)}`);
    if (!/^[Mm]/.test(p.d.trim())) fail(`${label}: путь не начинается с M: ${p.d.slice(0, 40)}`);
    if ((p.d.match(/-?\d+(\.\d+)?(e-?\d+)?/g) || []).length < 2) {
      fail(`${label}: путь без координат: ${p.d}`);
    }
  }
  for (const [k, v] of Object.entries(p.style || {})) {
    if (typeof v === "string" && /NaN|undefined/.test(v)) fail(`${label}: style.${k}=${v}`);
  }
  if (typeof p.className === "string" && /undefined|NaN/.test(p.className)) {
    fail(`${label}: className=${p.className}`);
  }
  if (node.type === "table") stats.tables++;
  if (node.type === "svg") stats.charts++;
  (node.children || []).forEach((c) => audit(c, label, stats));
  if (p.children) audit(p.children, label, stats);
}


// Обёртка для одиночных панелей: тот же обход, но со своим счётчиком.
function auditChart(tree, label) {
  const stats = { nodes: 0, text: 0, tables: 0, charts: 0, paths: 0 };
  audit(tree, label, stats);
  return stats;
}

const SERIES = [
  { key: "rps2xx", label: "2xx" }, { key: "rps4xx", label: "4xx" }, { key: "rps5xx", label: "5xx" },
];


const cases = [
  ["настоящие данные", payload.points],
  ["одна точка", payload.points.slice(0, 1)],
  ["две точки", payload.points.slice(0, 2)],
  ["пусто", []],
  ["все нули", payload.points.map((p) => Object.fromEntries(Object.entries(p).map(([k, v]) => [k, k === "t" ? v : 0])))],
  ["одинаковое время", payload.points.map((p) => ({ ...p, t: payload.points[0].t }))],
  ["огромные значения", payload.points.map((p) => ({ ...p, rps2xx: 1e9, rps4xx: 0, rps5xx: 1e-9 }))],
];

for (const theme of THEMES) {
  const mode = theme.name;
  for (const [name, pts] of cases) {
    for (const stacked of [false, true]) {
      resetHooks();
      const tree = TimeChart({ theme, points: pts, series: SERIES, format: "rps", stacked, height: 150 });
      const seen = auditChart(tree, `${mode}/${name}/${stacked ? "накопит." : "линии"}`);
      if (pts.length >= 2 && seen.paths === 0) {
        fail(`${mode}/${name}: при ${pts.length} точках не нарисовано ни одного пути`);
      }
    }
  }
  // Спарклайн и датчик, включая вырожденные входы.
  for (const [v, m] of [[3, 40], [0, 40], [40, 40], [5, 0], [NaN, 40]]) {
    resetHooks();
    auditChart(Gauge({ theme, value: v, max: m, label: "тест", thresholds: [[0, "ok"], [70, "warn"], [90, "bad"]] }),
      `${mode}/датчик ${v}/${m}`);
  }
  for (const pts of [payload.points, payload.points.slice(0, 1), []]) {
    resetHooks();
    const t = Sparkline({ points: pts, field: "rps", color: seriesColor(theme, 0), height: 22 });
    if (t) auditChart(t, `${mode}/спарклайн(${pts.length})`);
  }
  // Пороговые цвета обязаны переключаться и быть настоящими цветами.
  const steps = [[0, "ok"], [1, "warn"], [5, "bad"]];
  const cols = [0, 0.5, 2, 9].map((v) => thresholdColor(theme, v, steps));
  if (new Set(cols).size !== 3) fail(`${mode}: пороги дали цвета ${cols.join(",")}`);
  for (const c of cols) if (!/^#[0-9a-f]{3,8}$/i.test(c)) fail(`${mode}: порог вернул не цвет: ${c}`);
}

// ── страница целиком ────────────────────────────────────────────────
//
// Данные подставляются прямо в состояние: эффекты в заготовке не
// выполняются, а проверить нужно именно разметку с готовым ответом —
// плитки, таблицы, полосы и графики вместе. Порядок значений повторяет
// порядок вызовов useState в System.jsx.
for (const theme of THEMES) {
  for (const [name, data] of [["с данными", payload], ["без данных", null]]) {
    const seed = [
      "1h",                                    // выбранный период
      30,                                      // автообновление, с
      data,                                    // ответ сервера
      false,                                   // идёт запрос
      "",                                      // текст ошибки
      data ? Date.now() : null,                // время обновления
      { app: true, db: true, objects: true },  // раскрытые разделы
    ];
    resetHooks();
    const tree = renderComponent(System, { theme, onError: () => {} }, seed);
    const stats = { nodes: 0, text: 0, tables: 0, charts: 0, paths: 0 };
    audit(tree, `${theme.name}/${name}`, stats);
    console.log(`  ${theme.name}/${name}: узлов ${stats.nodes}, графиков ${stats.charts}, таблиц ${stats.tables}`);
    if (data) {
      if (stats.charts < 10) fail(`${theme.name}: графиков ${stats.charts}, ожидалось больше десяти`);
      if (stats.tables < 3) fail(`${theme.name}: таблиц ${stats.tables}, ожидалось три`);
    }
  }
}

// Накопительный график: верхняя линия не должна выходить за поле.
// Проверяем по самим координатам путей — иначе «вылезло наверх»
// обнаруживается только глазами и только если смотреть внимательно.
resetHooks();
{
  const tree = TimeChart({ theme: THEMES[0], points: payload.points, series: SERIES, stacked: true, height: 150 });
  let minY = Infinity;
  let maxY = -Infinity;
  const paths = [];
  const collect = (n) => {
    if (n == null || typeof n !== "object") return;
    if (Array.isArray(n)) { n.forEach(collect); return; }
    if (typeof n.type === "function") { collect(renderComponent(n.type, n.props)); return; }
    if (typeof n.props?.d === "string") paths.push(n.props.d);
    (n.children || []).forEach(collect);
  };
  collect(tree);
  for (const d of paths) {
    for (const m of d.matchAll(/[ML] (-?[\d.]+) (-?[\d.]+)/g)) {
      const y = Number(m[2]);
      if (Number.isFinite(y)) { minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
    }
  }
  if (paths.length === 0) fail("накопительный график не нарисовал ни одного пути");
  if (minY < 7.9) fail(`накопительный график вылез вверх: y=${minY} при верхнем отступе 8`);
  if (maxY > 150.1) fail(`накопительный график вылез вниз: y=${maxY} при высоте 150`);
}

console.log(bad === 0
  ? `разметка дашборда: всё чисто${sample ? " (на настоящем ответе сервера)" : ""}`
  : `ошибок: ${bad}`);
process.exit(bad ? 1 : 0);
