// Проверка чисел и осей графиков.
//
// Запуск: node tests/format.test.mjs — без установки зависимостей, на
// одном Node. Так она работает и там, где собрать интерфейс нечем.
//
// Проверяется то, в чём ошибка не видна глазом: подписи делений оси
// (верхнее деление обязано покрывать данные — иначе линия уходит за
// поле), единицы времени, разряды в больших числах, вырожденные входы
// вроде пустых данных и бесконечности.

import {
  FORMATS, fmtBytes, fmtDur, fmtNum, fmtPct, fmtSec, fmtTime, niceTicks, seriesColor,
} from "../src/lib/format.js";
import fs from "fs";
import path from "path";

let bad = 0;
const eq = (got, want, what) => {
  if (got !== want) { console.log(`✗ ${what}: получено «${got}», ожидалось «${want}»`); bad++; }
};

eq(fmtSec(0), "0", "fmtSec(0)");
eq(fmtSec(0.0000005), "1 мкс", "fmtSec субмикросекунда");
eq(fmtSec(0.0007), "700 мкс", "fmtSec 0.7мс");
eq(fmtSec(0.0075), "7.5 мс", "fmtSec 7.5мс");
eq(fmtSec(0.475), "475 мс", "fmtSec 475мс");
eq(fmtSec(2.5), "2.50 с", "fmtSec 2.5с");
eq(fmtSec(600), "10 мин", "fmtSec 10мин");
eq(fmtBytes(0), "0 Б", "fmtBytes 0");
eq(fmtBytes(1024), "1.0 КБ", "fmtBytes 1К");
eq(fmtBytes(10779671), "10.3 МБ", "fmtBytes 10МБ");
eq(fmtPct(99.8029, 2), "99.80 %", "fmtPct");
eq(fmtDur(45), "45 с", "fmtDur сек");
eq(fmtDur(3600), "1 ч 0 мин", "fmtDur час");
eq(fmtDur(90000), "1 дн 1 ч", "fmtDur сутки");
eq(fmtNum(0), "0", "fmtNum 0");
eq(fmtNum(0.0286, 2), "0,03", "fmtNum с цифрами");
eq(fmtNum(12345), "12.3 тыс.", "fmtNum компактно");
eq(fmtNum(12345, 0), "12\u202f345", "fmtNum точно, с разрядами");
eq(fmtNum(2.5, 2), "2,50", "fmtNum запятая в дроби");
eq(fmtNum(15, 0), "15", "fmtNum целое");
eq(FORMATS.rps(2.5), "2.50/с", "FORMATS.rps");

// Деления оси: только 1/2/5×10^n, ноль первым, последнее не ниже max.
for (const max of [0.0007, 0.42, 1, 7, 64.59, 1024, 10779671]) {
  const t = niceTicks(max, 4);
  if (t[0] !== 0) { console.log("✗ ось не с нуля:", max, t); bad++; }
  if (t[t.length - 1] < max) { console.log("✗ ось не покрывает max:", max, t); bad++; }
  if (t.length < 2 || t.length > 7) { console.log("✗ делений", t.length, "для", max, t); bad++; }
  const step = t[1] - t[0];
  const m = step / Math.pow(10, Math.floor(Math.log10(step)));
  if (![1, 2, 5, 10].some((x) => Math.abs(x - m) < 1e-9)) {
    console.log("✗ некрасивый шаг", step, "для", max); bad++;
  }
}
// Вырожденные случаи: всё нулевое, отрицательное, NaN
for (const v of [0, -5, NaN, Infinity]) {
  const t = niceTicks(v, 4);
  if (!Array.isArray(t) || t.length < 2 || t.some((x) => !Number.isFinite(x))) {
    console.log("✗ niceTicks на", v, "дал", t); bad++;
  }
}
// Палитра: фиксированный порядок, цикл по модулю, разные наборы по теме
const dark = [...Array(9)].map((_, i) => seriesColor({ dark: true }, i));
const light = [...Array(9)].map((_, i) => seriesColor({ dark: false }, i));
if (dark[0] === light[0]) { console.log("✗ палитры тем совпадают"); bad++; }
if (dark[7] !== dark[0] || dark[8] !== dark[1]) { console.log("✗ цикл палитры сбит"); bad++; }
if (new Set(dark.slice(0, 7)).size !== 7) { console.log("✗ цвета повторяются"); bad++; }

// Прогон на настоящем ответе сервера: ни одного «NaN» и «undefined».
// Второй проход — на настоящем ответе сервера, если он есть:
//   node tests/format.test.mjs ответ.json
// либо файл tests/sample.json. Без него проверка пропускается: она
// полезная, но не обязательная.
const check = (s, what) => {
  if (/NaN|undefined|Infinity/.test(String(s))) { console.log(`✗ ${what} → ${s}`); bad++; }
};

const sample = process.argv[2] || path.join(import.meta.dirname, "sample.json");
const d = fs.existsSync(sample) ? JSON.parse(fs.readFileSync(sample, "utf8")) : null;
if (d) {
  for (const [k, v] of Object.entries(d.summary)) {
    check(fmtNum(v), `summary.${k} fmtNum`);
    check(fmtSec(v), `summary.${k} fmtSec`);
    check(fmtBytes(v), `summary.${k} fmtBytes`);
    check(fmtPct(v), `summary.${k} fmtPct`);
  }
  for (const pt of d.points) {
    for (const [k, v] of Object.entries(pt)) check(fmtNum(v), `point.${k}`);
  }
  for (const r of d.routes) {
    check(fmtSec(r.p95) + fmtSec(r.avg) + fmtNum(r.requests, 0), "route");
  }
  for (const t of d.tables) {
    check(fmtBytes(t.sizeBytes) + fmtDur(t.vacuumAge) + fmtPct(t.deadShare), "table");
  }
  check(fmtDur(d.uptimeSeconds), "uptime");
} else {
  console.log("· sample.json нет — проверка на настоящем ответе пропущена");
}
check(fmtTime(Date.now()), "fmtTime");

console.log(bad === 0 ? "форматирование и оси: всё верно" : `ошибок: ${bad}`);
process.exit(bad ? 1 : 0);
