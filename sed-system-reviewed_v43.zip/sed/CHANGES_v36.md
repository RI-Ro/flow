# CHANGES_v36 — четвёртая итерация правок

> ⚠️ Проверено статически (нет Go-тулчейна и сети). Перед деплоем:
> `go build ./... && go test ./...`, `npm ci && npm run build`.
> Миграции применяются автоматически (goose): 0006–0009 после 0001–0005.

## Миграции
- `0008_user_basis.sql` — `users.basis` (основание учётной записи).
- `0009_signature_63fz.sql` — `document_signatures`: `signer_login`, `signed_ip`,
  `user_agent`, `document_hash` (расширенная фиксация подписи).
- Обновлён `migrations_psql/all_in_one.sql` (в т.ч. `default_controller` теперь
  прямо в `CREATE TYPE role_code`).

## 1. Входящие номера — как рассылка/согласование
Список документов: компактный кликабельный счётчик «N вх.» → модалка
`IncomingModal` (номер, подразделение, дата регистрации). Журнал: компактная
раскрываемая ячейка `PeopleCell`.

## 2. Печать/маркировка (не работала при включении bake_into_pdf)
- Экранная маркировка (overlay на canvas) теперь рисуется ВСЕГДА и не зависит
  от вжигания в PDF; предпросмотр отдаёт исходный файл, штампы — overlay.
  Включение `bake_into_pdf` больше не ломает просмотр.
- Рендер pdfcpu сделан устойчивым (`render_pdfcpu.go`): при ошибке шрифта штамп
  наносится повторно без `fontname` (Helvetica), проблемный штамп пропускается —
  одна ошибка шрифта больше НЕ обрушивает всю маркировку. Вжигание используется
  только при выдаче на печать.
  Примечание: для кириллицы в ПЕЧАТИ нужен рабочий TTF в `marking.font_file`/
  `font_name`; без него латиница/цифры печатаются, кириллица — нет, но сбоя нет.

## 3. Убрана запись «подпись не требуется…» из истории (мультиподпись)
`signing.go`: прочие этапы подписи удаляются полностью (без фильтра по статусу);
плюс одноразовая очистка старых записей истории с этой фразой при подписании.

## 4. Типы связи
Связанный, В ответ на, Отменяет, Приложение, В дополнение (`in_addition`).
Легаси `in_pursuance_of` («Во исполнение») сохранён только для отображения
старых связей. Backend `links.go` + frontend `DocumentTabs`.

## 5. Автопредвыбор контролёров по умолчанию при создании
Цепочка исправна: `GET /api/default-controllers` + эффект предвыбора на форме
создания (галочка «на контроле» + предзаполнение). Наиболее вероятная причина,
почему не срабатывало — отсутствовало значение enum `default_controller`;
добавлено прямо в `CREATE TYPE role_code` в `all_in_one.sql` (надёжнее ALTER).

## 6. Поле «Основание» у пользователя
`users.basis` + сервис `CreateUser`/`UpdateUser` + `ListUsers` + формы создания
и редактирования пользователя в админке.

## 7. Расширенная фиксация подписи (63-ФЗ)
`signing.go`: при подписи фиксируются логин подписанта, тип и время, фактический
IP (с учётом прокси/NAT — X-Forwarded-For/X-Real-IP, helper `clientIP`),
user-agent и SHA-256 содержимого документа. Отпечаток подписи усилен (включает
хэш документа, личность, номер, время, IP). Новый эндпоинт
`GET /api/documents/:id/signatures`; данные показываются в истории (блок
«Данные о подписи (ФЗ-63)»).

## 8. Шрифты — локально (self-hosted)
Убран Google Fonts CDN из `index.html`; подключены `@fontsource/manrope` и
`@fontsource/jetbrains-mono` (импорты в `main.jsx`). Шрифты собираются в бандл и
раздаются вашим сервером; подтягиваются при `npm ci` (не с внешнего ресурса в
рантайме).

## Изменённые/новые файлы
Backend: migrations/0008_*, 0009_*, migrations_psql/all_in_one.sql,
marking/render_pdfcpu.go, service/{signing,admin}.go,
http/handlers/{documents,approval,admin,links,clientip(new),prints}.go,
http/router.go.
Frontend: index.html, src/main.jsx, package.json,
components/{DocumentTabs,DocumentViewer}.jsx,
pages/{DocumentsListPage,RegistryPage,AdminPage,CreateDocumentPage,DocumentDetailPage}.jsx,
api/client.js.
