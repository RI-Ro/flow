import React, { useState, useEffect, useCallback, useMemo } from 'react'
import { api } from '../api/client'
import PersonPicker from '../components/PersonPicker'

const ALL_ROLES = ['author', 'approver_hierarchy', 'approver_cross_dept', 'signer', 'executor', 'clerk', 'chief', 'controller', 'default_controller', 'printer', 'admin']
const ROLE_LABELS = {
  author: 'Автор (создаёт документы)',
  approver_hierarchy: 'Согласующий по иерархии',
  approver_cross_dept: 'Согласующий межведомственный',
  signer: 'Подписант (право подписи)',
  executor: 'Исполнитель поручений',
  clerk: 'Канцелярия/дежурный (приём и рассылка)',
  chief: 'Руководитель подразделения',
  controller: 'Контролёр (контроль исполнения)',
  default_controller: 'Контролёр по умолчанию (авто-контроль всех документов)',
  printer: 'Печать (скачивание на печать + регистрация)',
  admin: 'Администратор системы',
}

function buildTree(depts) {
  const byId = {}; const roots = []
  depts.forEach((d) => { byId[d.id] = { ...d, children: [] } })
  depts.forEach((d) => {
    if (d.parent_id && byId[d.parent_id]) byId[d.parent_id].children.push(byId[d.id])
    else roots.push(byId[d.id])
  })
  const sortRec = (n) => { n.children.sort((a, b) => a.name.localeCompare(b.name)); n.children.forEach(sortRec) }
  roots.sort((a, b) => a.name.localeCompare(b.name)); roots.forEach(sortRec)
  return roots
}

export default function AdminPage() {
  const [depts, setDepts] = useState([])
  const [users, setUsers] = useState([])
  const [sel, setSel] = useState(null) // {type:'dept'|'user', id}
  const [expanded, setExpanded] = useState({})
  const [dragOverId, setDragOverId] = useState(null)
  const [rootOver, setRootOver] = useState(false)
  const [creating, setCreating] = useState(null)
  const [query, setQuery] = useState('')
  const [toast, setToast] = useState(null)
  const [loading, setLoading] = useState(false)

  const flash = (msg, type = 'ok') => { setToast({ msg, type }); setTimeout(() => setToast(null), 2600) }

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [d, u] = await Promise.all([api.adminListDepartments(), api.adminListUsers()])
      setDepts(d.departments || [])
      setUsers(u.users || [])
    } catch (e) { flash(e.message, 'err') } finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const tree = useMemo(() => buildTree(depts), [depts])
  const usersByDept = useMemo(() => {
    const m = {}; users.forEach((u) => { const k = u.department_id || 0; (m[k] = m[k] || []).push(u) })
    Object.values(m).forEach((arr) => arr.sort((a, b) => a.full_name.localeCompare(b.full_name)))
    return m
  }, [users])

  const selDept = sel?.type === 'dept' ? depts.find((d) => d.id === sel.id) : null
  const selUser = sel?.type === 'user' ? users.find((u) => u.id === sel.id) : null
  const toggle = (id) => setExpanded((e) => ({ ...e, [id]: e[id] === false ? true : false }))

  // Поиск по ФИО, должности, логину, названию/префиксу подразделения.
  const deptNameById = useMemo(() => Object.fromEntries(depts.map((d) => [d.id, d.name])), [depts])
  const q = query.trim().toLowerCase()
  const foundDepts = q ? depts.filter((d) => [d.name, d.outgoing_prefix, d.numbering_prefix].some((v) => (v || '').toLowerCase().includes(q))) : []
  const foundUsers = q ? users.filter((u) => [u.full_name, u.position, u.login, deptNameById[u.department_id]].some((v) => (v || '').toLowerCase().includes(q))) : []

  const onDrop = async (payload, targetDeptId) => {
    try {
      if (payload.type === 'user') {
        await api.adminMoveUser(payload.id, targetDeptId)
        flash('Пользователь перемещён')
      } else if (payload.type === 'dept') {
        if (payload.id === targetDeptId) return
        await api.adminMoveDepartment(payload.id, targetDeptId)
        flash('Подразделение перемещено')
      }
      await load()
    } catch (e) { flash(e.message, 'err') }
  }
  const onDropRoot = async (e) => {
    e.preventDefault(); setRootOver(false)
    let payload; try { payload = JSON.parse(e.dataTransfer.getData('text/plain')) } catch { return }
    if (payload.type !== 'dept') { flash('Корнем может стать только подразделение', 'err'); return }
    try { await api.adminMoveDepartment(payload.id, 0); flash('Сделано корневым'); await load() } catch (e2) { flash(e2.message, 'err') }
  }

  const saveDept = async (id, f) => { try { await api.adminUpdateDepartment(id, f); flash('Сохранено'); await load() } catch (e) { flash(e.message, 'err') } }
  const deleteDept = async (id) => {
    if (!confirm('Удалить подразделение? Действие необратимо.')) return
    try { await api.adminDeleteDepartment(id); flash('Удалено'); setSel(null); await load() } catch (e) { flash(e.message, 'err') }
  }
  const createDept = async (f) => { try { await api.adminCreateDepartment(f); flash('Создано'); setCreating(null); await load() } catch (e) { flash(e.message, 'err') } }
  const saveUser = async (id, f) => { try { await api.adminUpdateUser(id, f); flash('Сохранено'); await load() } catch (e) { flash(e.message, 'err') } }
  const createUser = async (f) => { try { await api.adminCreateUser(f); flash('Создано'); setCreating(null); await load() } catch (e) { flash(e.message, 'err') } }
  const setPassword = async (id, password) => { try { await api.adminSetUserPassword(id, password); flash('Пароль изменён') } catch (e) { flash(e.message, 'err') } }
  const setUserRoles = async (id, departmentId, roles) => {
    // admin — глобальная роль (department_id=0), остальные — по выбранному
    // подразделению. Раньше всё сохранялось одним scope, из-за чего роль
    // администратора не назначалась корректно.
    const adminChecked = roles.includes('admin')
    const perDept = roles.filter((r) => r !== 'admin')
    try {
      await api.adminSetUserRoles(id, 0, adminChecked ? ['admin'] : [])
      if (departmentId) await api.adminSetUserRoles(id, departmentId, perDept)
      flash('Роли сохранены'); await load()
    } catch (e) { flash(e.message, 'err') }
  }
  const setUserDepartments = async (id, sets) => { try { await api.adminSetUserDepartments(id, sets); flash('Доп. подразделения сохранены'); await load() } catch (e) { flash(e.message, 'err') } }

  return (
    <div className="p-6 max-w-[120rem] mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-display text-xl font-semibold">Администрирование</h1>
          <div className="text-text-secondary text-xs">Оргструктура и пользователи · перетаскивайте узлы и людей мышью</div>
        </div>
        <div className="flex gap-2 items-center">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск: ФИО, должность, подразделение…"
            className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-64"
          />
          <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={load}>{loading ? 'Обновление…' : '⟳ Обновить'}</button>
          <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={() => { setCreating({ kind: 'dept', parentId: 0 }); setSel(null) }}>+ Подразделение</button>
          <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={() => { setCreating({ kind: 'user' }); setSel(null) }}>+ Пользователь</button>
        </div>
      </div>

      <div className="grid gap-4" style={{ gridTemplateColumns: 'minmax(360px, 1.4fr) 1fr' }}>
        {/* Дерево */}
        <div className="bg-surface border border-border rounded-lg p-3 overflow-auto" style={{ maxHeight: '78vh' }}>
          <div
            className={'text-xs text-text-secondary px-2 py-1.5 rounded-md mb-1.5 border border-dashed border-border ' + (rootOver ? 'bg-accent/10 outline outline-1 outline-accent' : '')}
            onDragOver={(e) => { e.preventDefault(); setRootOver(true) }}
            onDragLeave={() => setRootOver(false)}
            onDrop={onDropRoot}
          >
            ⤒ Отпустите подразделение здесь, чтобы сделать его корневым
          </div>
          {q ? (
            <div>
              <div className="text-text-secondary text-xs px-2 py-1">Подразделения ({foundDepts.length}):</div>
              {foundDepts.map((d) => (
                <div key={'d' + d.id} className="px-2 py-1.5 rounded-md hover:bg-surface-alt cursor-pointer text-sm flex items-center gap-2"
                  onClick={() => { setSel({ type: 'dept', id: d.id }); setCreating(null) }}>
                  <span className="font-medium">{d.name}</span>
                  <span className="text-[11px] px-1.5 rounded-full border border-border text-text-secondary">{d.outgoing_prefix}</span>
                </div>
              ))}
              <div className="text-text-secondary text-xs px-2 py-1 mt-2">Пользователи ({foundUsers.length}):</div>
              {foundUsers.map((u) => (
                <div key={'u' + u.id} className="px-2 py-1 rounded hover:bg-surface-alt cursor-pointer text-[13px] flex items-center gap-1.5"
                  onClick={() => { setSel({ type: 'user', id: u.id }); setCreating(null) }}>
                  <span className="opacity-60">👤</span>
                  <span>{u.full_name}</span>
                  {u.position && <span className="text-text-secondary">· {u.position}</span>}
                  {u.department_id && <span className="text-text-secondary">· {deptNameById[u.department_id]}</span>}
                </div>
              ))}
              {foundDepts.length === 0 && foundUsers.length === 0 && <div className="text-text-secondary text-sm p-3">Ничего не найдено.</div>}
            </div>
          ) : (
          <>
          {tree.length === 0 && <div className="text-text-secondary p-3 text-sm">Нет подразделений. Создайте первое.</div>}
          {tree.map((n) => (
            <DeptNode key={n.id} node={n} depth={0} usersByDept={usersByDept} sel={sel}
              onSelect={(s) => { setSel(s); setCreating(null) }} onDrop={onDrop}
              expanded={expanded} toggle={toggle} dragOverId={dragOverId} setDragOverId={setDragOverId} />
          ))}
          {(usersByDept[0] || []).length > 0 && (
            <div className="mt-2">
              <div className="text-text-secondary text-xs px-2 py-1">Без подразделения:</div>
              {(usersByDept[0] || []).map((u) => <UserRow key={u.id} user={u} depth={0} sel={sel} onSelect={(s) => { setSel(s); setCreating(null) }} />)}
            </div>
          )}
          </>
          )}
        </div>

        {/* Редактор / создание */}
        <div className="flex flex-col gap-3">
          {creating?.kind === 'dept' && <CreateDeptForm parentId={creating.parentId} depts={depts} onCreate={createDept} onCancel={() => setCreating(null)} />}
          {creating?.kind === 'user' && <CreateUserForm depts={depts} initialDept={creating.departmentId} onCreate={createUser} onCancel={() => setCreating(null)} />}
          {!creating && selDept && <DeptEditor dept={selDept} onSave={saveDept} onDelete={deleteDept} onCreateChild={(pid) => setCreating({ kind: 'dept', parentId: pid })} onAddUser={(did) => { setCreating({ kind: 'user', departmentId: did }); setSel(null) }} />}
          {!creating && selUser && <UserEditor user={selUser} depts={depts} onSave={saveUser} onPassword={setPassword} onRoles={setUserRoles} onDepartments={setUserDepartments} />}
          {!creating && !selDept && !selUser && (
            <div className="bg-surface border border-border rounded-lg p-4 text-text-secondary text-sm">
              Выберите подразделение или пользователя слева, либо создайте новый элемент.
              <ul className="mt-2 list-disc pl-5 space-y-1">
                <li>Перетащите <b>пользователя</b> на подразделение — переместить в него.</li>
                <li>Перетащите <b>подразделение</b> на другое — сделать вложенным (с поддеревом).</li>
                <li>Перетащите подразделение в зону сверху — сделать корневым.</li>
              </ul>
            </div>
          )}
          {/* #4 — Группы адресатов рассылки */}
          <RecipientGroupsManager flash={flash} />
          {/* #6 — категории документов */}
          <CategoriesManager flash={flash} />
        </div>
      </div>

      {toast && (
        <div className={'fixed bottom-4 left-1/2 -translate-x-1/2 px-4 py-2.5 rounded-md z-50 shadow-lg text-white ' + (toast.type === 'err' ? 'bg-danger' : 'bg-success')}>
          {toast.msg}
        </div>
      )}
    </div>
  )
}

function DeptNode({ node, depth, usersByDept, sel, onSelect, onDrop, expanded, toggle, dragOverId, setDragOverId }) {
  const isOver = dragOverId === 'dept:' + node.id
  const users = usersByDept[node.id] || []
  const isExpanded = expanded[node.id] !== false

  const onDragStart = (e) => { e.stopPropagation(); e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'dept', id: node.id })); e.dataTransfer.effectAllowed = 'move' }
  const onDragOver = (e) => { e.preventDefault(); e.stopPropagation(); setDragOverId('dept:' + node.id) }
  const onDragLeave = (e) => { e.stopPropagation(); setDragOverId((cur) => (cur === 'dept:' + node.id ? null : cur)) }
  const onDropH = (e) => {
    e.preventDefault(); e.stopPropagation(); setDragOverId(null)
    let payload; try { payload = JSON.parse(e.dataTransfer.getData('text/plain')) } catch { return }
    onDrop(payload, node.id)
  }
  const selected = sel?.type === 'dept' && sel.id === node.id

  return (
    <div style={{ marginLeft: depth ? 14 : 0 }}>
      <div
        className={'flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-grab hover:bg-surface-alt ' + (selected ? 'bg-accent/15 outline outline-1 outline-accent ' : '') + (isOver ? 'outline outline-2 outline-dashed outline-accent bg-accent/5' : '')}
        draggable onDragStart={onDragStart} onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDropH}
        onClick={() => onSelect({ type: 'dept', id: node.id })}
      >
        <span className="w-4 text-center text-text-secondary select-none" onClick={(e) => { e.stopPropagation(); toggle(node.id) }}>
          {(node.children.length || users.length) ? (isExpanded ? '▾' : '▸') : '·'}
        </span>
        <span className="font-medium text-sm">{node.name}</span>
        {node.numbering_prefix && <span className="text-[11px] px-1.5 rounded-full border border-border text-text-secondary" title="numbering_prefix">{node.numbering_prefix}</span>}
        <span className="text-[11px] px-1.5 rounded-full border border-border text-text-secondary" title="outgoing_prefix">{node.outgoing_prefix}</span>
        {!node.is_active && <span className="text-[11px] px-1.5 rounded-full border border-border text-warning">неактивно</span>}
        {users.length > 0 && <span className="text-text-secondary text-xs">· {users.length}</span>}
      </div>
      {isExpanded && (
        <div>
          {users.map((u) => <UserRow key={u.id} user={u} depth={depth + 1} sel={sel} onSelect={onSelect} />)}
          {node.children.map((ch) => (
            <DeptNode key={ch.id} node={ch} depth={depth + 1} usersByDept={usersByDept} sel={sel}
              onSelect={onSelect} onDrop={onDrop} expanded={expanded} toggle={toggle} dragOverId={dragOverId} setDragOverId={setDragOverId} />
          ))}
        </div>
      )}
    </div>
  )
}

function UserRow({ user, depth, sel, onSelect }) {
  const onDragStart = (e) => { e.stopPropagation(); e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'user', id: user.id })); e.dataTransfer.effectAllowed = 'move' }
  const isSel = sel?.type === 'user' && sel.id === user.id
  return (
    <div className={'flex items-center gap-1.5 px-2 py-1 rounded cursor-grab text-[13px] hover:bg-surface-alt ' + (isSel ? 'bg-accent/15 ' : '') + (user.is_active ? '' : 'opacity-50')}
      style={{ marginLeft: 14 + depth * 6 }} draggable onDragStart={onDragStart} onClick={() => onSelect({ type: 'user', id: user.id })}>
      <span className="opacity-60">👤</span>
      <span>{user.full_name}</span>
      {user.position && <span className="text-text-secondary">· {user.position}</span>}
      {user.roles?.includes('admin') && <span className="text-[11px] px-1.5 rounded-full border border-border text-accent">admin</span>}
    </div>
  )
}

const inputCls = 'w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm'
const labelCls = 'block text-xs text-text-secondary mt-2 mb-1'

function DeptEditor({ dept, onSave, onDelete, onCreateChild, onAddUser }) {
  const [f, setF] = useState({ name: '', outgoing_prefix: '', numbering_prefix: '', city: '', is_active: true })
  useEffect(() => { if (dept) setF({ name: dept.name, outgoing_prefix: dept.outgoing_prefix, numbering_prefix: dept.numbering_prefix || '', city: dept.city || '', is_active: dept.is_active }) }, [dept])
  if (!dept) return null
  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Подразделение #{dept.id}</h3>
        <span className="text-text-secondary text-xs">пользователей: {dept.user_count}</span>
      </div>
      <label className={labelCls}>Название</label>
      <input className={inputCls} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <label className={labelCls}>Префикс (outgoing_prefix) — уникальный код</label>
      <input className={inputCls} value={f.outgoing_prefix} onChange={(e) => setF({ ...f, outgoing_prefix: e.target.value })} />
      <label className={labelCls}>Иерархический префикс нумерации (напр. 1/2/3/44)</label>
      <input className={inputCls} value={f.numbering_prefix} onChange={(e) => setF({ ...f, numbering_prefix: e.target.value })} />
      <label className={labelCls}>Город</label>
      <input className={inputCls} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} placeholder="напр. Москва" />
      <label className="flex items-center gap-2 mt-3 text-sm">
        <input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} /> Активно
      </label>
      <div className="flex gap-2 mt-4 flex-wrap">
        <button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium" onClick={() => onSave(dept.id, f)}>Сохранить</button>
        <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={() => onCreateChild(dept.id)}>+ Подразделение внутрь</button>
        <button className="px-3 py-1.5 rounded-md border border-accent text-accent text-sm" onClick={() => onAddUser(dept.id)}>+ Пользователь сюда</button>
        <button className="px-3 py-1.5 rounded-md bg-danger text-white text-sm ml-auto" onClick={() => onDelete(dept.id)}>Удалить</button>
      </div>
    </div>
  )
}

// DeptMulti — компактный мультивыбор подразделений с поиском (#6). Выбранные
// показываются чипами с крестиком; поиск фильтрует выпадающий список. Не
// занимает много места даже при большом числе подразделений.
function DeptMulti({ label, hint, depts, selected, onChange }) {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const toggle = (id) => onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id])
  const byId = React.useMemo(() => Object.fromEntries(depts.map((d) => [d.id, d])), [depts])
  const ql = q.trim().toLowerCase()
  const matches = depts.filter(
    (d) => !selected.includes(d.id) && (ql === '' || d.name.toLowerCase().includes(ql) || (d.city || '').toLowerCase().includes(ql)),
  )
  return (
    <div className="mt-2">
      <label className={labelCls}>{label}</label>
      {hint && <div className="text-[11px] text-text-secondary mb-1">{hint}</div>}
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-1">
          {selected.map((id) => (
            <span key={id} className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full border border-accent text-accent">
              {byId[id]?.name || `#${id}`}
              <button type="button" className="hover:text-danger" onClick={() => toggle(id)}>×</button>
            </span>
          ))}
        </div>
      )}
      <div className="relative">
        <input
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true) }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder="Поиск подразделения…"
          className="w-full px-2 py-1 rounded-md border border-border bg-surface-alt text-sm"
        />
        {open && matches.length > 0 && (
          <div className="absolute z-10 mt-1 w-full max-h-44 overflow-auto bg-surface border border-border rounded-md shadow-lg">
            {matches.slice(0, 50).map((d) => (
              <button
                key={d.id}
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => { toggle(d.id); setQ('') }}
                className="w-full text-left px-2 py-1.5 text-sm hover:bg-surface-alt"
              >
                {d.name}{d.city ? <span className="text-text-secondary"> · {d.city}</span> : null}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function UserEditor({ user, depts, onSave, onPassword, onRoles, onDepartments }) {
  const [f, setF] = useState({ login: '', full_name: '', position: '', basis: '', department_id: 0, numbering_department_id: 0, is_active: true })
  const [pwd, setPwd] = useState('')
  const [roles, setRoles] = useState([])
  const [vis, setVis] = useState([]); const [acq, setAcq] = useState([]); const [asg, setAsg] = useState([]); const [inc, setInc] = useState([]); const [rdr, setRdr] = useState([])
  useEffect(() => {
    if (user) {
      setF({ login: user.login, full_name: user.full_name, position: user.position || '', basis: user.basis || '', department_id: user.department_id || 0, numbering_department_id: user.numbering_department_id || 0, is_active: user.is_active })
      setRoles(user.roles || []); setVis(user.visible_departments || []); setAcq(user.acquaint_departments || []); setAsg(user.assign_departments || []); setInc(user.incoming_departments || []); setRdr(user.redirect_departments || []); setPwd('')
    }
  }, [user])
  if (!user) return null
  const toggleRole = (r) => setRoles((rs) => (rs.includes(r) ? rs.filter((x) => x !== r) : [...rs, r]))
  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h3 className="font-semibold">Пользователь #{user.id}</h3>
      <label className={labelCls}>ФИО</label>
      <input className={inputCls} value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
      <label className={labelCls}>Должность (для штампа подписи)</label>
      <input className={inputCls} value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} />
      <label className={labelCls}>Основание</label>
      <input className={inputCls} value={f.basis} onChange={(e) => setF({ ...f, basis: e.target.value })} placeholder="напр. приказ № 123 от 01.01.2026" />
      <label className={labelCls}>Логин</label>
      <input className={inputCls} value={f.login} onChange={(e) => setF({ ...f, login: e.target.value })} />
      <label className={labelCls}>Основное подразделение</label>
      <select className={inputCls} value={f.department_id} onChange={(e) => setF({ ...f, department_id: Number(e.target.value) })}>
        <option value={0}>— не задано —</option>
        {depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
      </select>
      <label className={labelCls}>Подразделение для нумерации (по умолчанию — как основное)</label>
      <select className={inputCls} value={f.numbering_department_id} onChange={(e) => setF({ ...f, numbering_department_id: Number(e.target.value) })}>
        <option value={0}>— как основное —</option>
        {depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
      </select>
      <label className="flex items-center gap-2 mt-3 text-sm">
        <input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} /> Активен
      </label>
      <div className="mt-3"><button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium" onClick={() => onSave(user.id, f)}>Сохранить</button></div>

      <div className="border-t border-border my-4" />
      <div className="text-xs text-text-secondary mb-1.5">Роли (по выбранному выше подразделению; admin — глобально).</div>
      <div className="flex flex-wrap gap-1.5">
        {ALL_ROLES.map((r) => (
          <label key={r} title={r} className={'text-[11px] px-2 py-0.5 rounded-full border border-border cursor-pointer ' + (roles.includes(r) ? 'text-accent border-accent' : 'text-text-secondary')}>
            <input type="checkbox" className="mr-1" checked={roles.includes(r)} onChange={() => toggleRole(r)} />{ROLE_LABELS[r] || r}
          </label>
        ))}
      </div>
      <button className="mt-2.5 px-3 py-1 rounded-md border border-border text-xs" onClick={() => onRoles(user.id, f.department_id || 0, roles)}>Сохранить роли</button>
      <div className="text-[11px] text-text-secondary mt-1">«Администратор» сохраняется глобально; остальные роли — по основному подразделению.</div>

      <div className="border-t border-border my-4" />
      <div className="text-xs text-text-secondary">Дополнительные подразделения (расширяют права вне основной иерархии).</div>
      <DeptMulti label="Видимость исходящих" hint="видит подписанные исходящие этих подразделений" depts={depts} selected={vis} onChange={setVis} />
      <DeptMulti label="Видимость входящих" hint="видит входящие документы, полученные этими подразделениями" depts={depts} selected={inc} onChange={setInc} />
      <DeptMulti label="Ознакомление" hint="может знакомить сотрудников этих подразделений (и ниже)" depts={depts} selected={acq} onChange={setAcq} />
      <DeptMulti label="Поручения" hint="может давать поручения сотрудникам этих подразделений (и ниже)" depts={depts} selected={asg} onChange={setAsg} />
      <DeptMulti label="Донаправление входящих" hint="в какие подразделения пользователь может донаправить (переслать) входящий документ" depts={depts} selected={rdr} onChange={setRdr} />
      <button className="mt-2.5 px-3 py-1 rounded-md border border-border text-xs" onClick={() => onDepartments(user.id, { visible_departments: vis, acquaint_departments: acq, assign_departments: asg, incoming_departments: inc, redirect_departments: rdr })}>Сохранить доп. подразделения</button>

      <div className="border-t border-border my-4" />
      <label className={labelCls}>Новый пароль</label>
      <div className="flex gap-2">
        <input className={inputCls} type="text" value={pwd} onChange={(e) => setPwd(e.target.value)} placeholder="оставьте пустым, чтобы не менять" />
        <button className="px-3 py-1.5 rounded-md border border-border text-sm whitespace-nowrap" disabled={!pwd} onClick={() => { onPassword(user.id, pwd); setPwd('') }}>Задать</button>
      </div>
    </div>
  )
}

function CreateDeptForm({ parentId, depts, onCreate, onCancel }) {
  const [f, setF] = useState({ name: '', outgoing_prefix: '', numbering_prefix: '', city: '', parent_id: parentId || 0 })
  useEffect(() => setF((v) => ({ ...v, parent_id: parentId || 0 })), [parentId])
  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h3 className="font-semibold mb-1">Новое подразделение</h3>
      <label className={labelCls}>Название</label>
      <input className={inputCls} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <label className={labelCls}>Префикс (outgoing_prefix)</label>
      <input className={inputCls} value={f.outgoing_prefix} onChange={(e) => setF({ ...f, outgoing_prefix: e.target.value })} />
      <label className={labelCls}>numbering_prefix (необязательно)</label>
      <input className={inputCls} value={f.numbering_prefix} onChange={(e) => setF({ ...f, numbering_prefix: e.target.value })} />
      <label className={labelCls}>Город</label>
      <input className={inputCls} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} placeholder="напр. Москва" />
      <label className={labelCls}>Родитель</label>
      <select className={inputCls} value={f.parent_id} onChange={(e) => setF({ ...f, parent_id: Number(e.target.value) })}>
        <option value={0}>— корень —</option>
        {depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
      </select>
      <div className="flex gap-2 mt-3">
        <button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium" onClick={() => onCreate(f)}>Создать</button>
        <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={onCancel}>Отмена</button>
      </div>
    </div>
  )
}

function CreateUserForm({ depts, onCreate, onCancel, initialDept }) {
  const [f, setF] = useState({ login: '', password: '', full_name: '', position: '', basis: '', department_id: initialDept || 0 })
  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h3 className="font-semibold mb-1">Новый пользователь</h3>
      <label className={labelCls}>ФИО</label>
      <input className={inputCls} value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
      <label className={labelCls}>Должность</label>
      <input className={inputCls} value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} />
      <label className={labelCls}>Основание</label>
      <input className={inputCls} value={f.basis} onChange={(e) => setF({ ...f, basis: e.target.value })} placeholder="напр. приказ № 123 от 01.01.2026" />
      <label className={labelCls}>Логин</label>
      <input className={inputCls} value={f.login} onChange={(e) => setF({ ...f, login: e.target.value })} />
      <label className={labelCls}>Пароль</label>
      <input className={inputCls} type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
      <label className={labelCls}>Подразделение</label>
      <select className={inputCls} value={f.department_id} onChange={(e) => setF({ ...f, department_id: Number(e.target.value) })}>
        <option value={0}>— не задано —</option>
        {depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
      </select>
      <div className="flex gap-2 mt-3">
        <button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium" onClick={() => onCreate(f)}>Создать</button>
        <button className="px-3 py-1.5 rounded-md border border-border text-sm" onClick={onCancel}>Отмена</button>
      </div>
    </div>
  )
}

// #4 — Управление группами адресатов рассылки. Список групп + создание,
// переименование, удаление и редактирование состава. Состав редактируется через
// PersonPicker (group="recipients") — он несёт корректный department_id (где у
// пользователя роль clerk), что обязательно для получателя рассылки.
function RecipientGroupsManager({ flash }) {
  const [groups, setGroups] = useState([])
  const [openId, setOpenId] = useState(null)
  const [newName, setNewName] = useState('')
  const [members, setMembers] = useState([])
  const [busy, setBusy] = useState(false)

  const load = async () => {
    try { setGroups((await api.listRecipientGroups()).items || []) }
    catch (e) { flash?.(e.message, 'err') }
  }
  useEffect(() => { load() }, [])

  const openGroup = (g) => {
    if (openId === g.id) { setOpenId(null); return }
    setOpenId(g.id)
    setMembers((g.members || []).map((m) => ({
      id: m.user_id,
      full_name: m.full_name,
      position: m.position,
      department_id: m.department_id,
      department_name: m.department_name,
      city: m.city,
    })))
  }

  const create = async () => {
    if (!newName.trim()) return
    setBusy(true)
    try { await api.adminCreateRecipientGroup({ name: newName.trim() }); setNewName(''); await load(); flash?.('Группа создана') }
    catch (e) { flash?.(e.message, 'err') } finally { setBusy(false) }
  }
  const rename = async (g) => {
    const name = prompt('Новое название группы', g.name)
    if (!name) return
    try { await api.adminUpdateRecipientGroup(g.id, { name, description: g.description || '', is_active: g.is_active }); await load(); flash?.('Сохранено') }
    catch (e) { flash?.(e.message, 'err') }
  }
  const remove = async (g) => {
    if (!confirm(`Удалить группу «${g.name}»?`)) return
    try { await api.adminDeleteRecipientGroup(g.id); if (openId === g.id) setOpenId(null); await load(); flash?.('Группа удалена') }
    catch (e) { flash?.(e.message, 'err') }
  }
  const saveMembers = async () => {
    setBusy(true)
    try {
      await api.adminSetRecipientGroupMembers(openId, members.map((m) => ({ user_id: m.id, department_id: m.department_id })))
      await load(); flash?.('Состав сохранён')
    } catch (e) { flash?.(e.message, 'err') } finally { setBusy(false) }
  }

  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h3 className="font-semibold mb-2">Группы адресатов</h3>
      <div className="flex gap-2 mb-3">
        <input className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
          placeholder="Название новой группы (напр. Дежурные)" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium disabled:opacity-60" disabled={busy || !newName.trim()} onClick={create}>Создать</button>
      </div>
      {groups.length === 0 && <div className="text-text-secondary text-sm">Групп пока нет.</div>}
      <ul className="space-y-2">
        {groups.map((g) => (
          <li key={g.id} className="border border-border rounded-md">
            <div className="flex items-center justify-between px-3 py-2">
              <button className="text-left text-sm font-medium" onClick={() => openGroup(g)}>
                {g.name} <span className="text-text-secondary text-xs">({g.member_count})</span>
                {!g.is_active && <span className="text-warning text-xs ml-2">неактивна</span>}
              </button>
              <div className="flex gap-2 text-xs">
                <button className="text-accent" onClick={() => rename(g)}>Переименовать</button>
                <button className="text-danger" onClick={() => remove(g)}>Удалить</button>
              </div>
            </div>
            {openId === g.id && (
              <div className="px-3 pb-3 border-t border-border pt-2">
                <label className="block text-xs text-text-secondary mb-1">Состав группы (получатели рассылки)</label>
                <PersonPicker group="recipients" multiple value={members} onChange={setMembers} />
                <button className="mt-2 px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium disabled:opacity-60" disabled={busy} onClick={saveMembers}>
                  {busy ? 'Сохранение…' : 'Сохранить состав'}
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

// #6 — Управление категориями документов (постоянные/временные и т.д.).
function CategoriesManager({ flash }) {
  const [items, setItems] = useState([])
  const [name, setName] = useState('')
  const [code, setCode] = useState('')
  const load = async () => {
    try { setItems((await api.listCategories()).items || []) } catch (e) { flash?.(e.message, 'err') }
  }
  useEffect(() => { load() }, [])
  const create = async () => {
    if (!name.trim()) return
    try { await api.adminCreateCategory({ name: name.trim(), code: code.trim() }); setName(''); setCode(''); await load(); flash?.('Категория создана') }
    catch (e) { flash?.(e.message, 'err') }
  }
  const rename = async (c) => {
    const n = prompt('Название категории', c.name); if (!n) return
    try { await api.adminUpdateCategory(c.id, { name: n, code: c.code || '', is_active: c.is_active, sort_order: c.sort_order }); await load() }
    catch (e) { flash?.(e.message, 'err') }
  }
  const toggle = async (c) => {
    try { await api.adminUpdateCategory(c.id, { name: c.name, code: c.code || '', is_active: !c.is_active, sort_order: c.sort_order }); await load() }
    catch (e) { flash?.(e.message, 'err') }
  }
  const remove = async (c) => {
    if (!confirm(`Удалить категорию «${c.name}»?`)) return
    try { await api.adminDeleteCategory(c.id); await load(); flash?.('Удалено') }
    catch (e) { flash?.(e.message, 'err') }
  }
  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h3 className="font-semibold mb-2">Категории документов</h3>
      <div className="flex gap-2 mb-3">
        <input className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
          placeholder="Название (напр. Постоянные)" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="w-32 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
          placeholder="код" value={code} onChange={(e) => setCode(e.target.value)} />
        <button className="px-3 py-1.5 rounded-md bg-accent text-white text-sm font-medium disabled:opacity-60"
          disabled={!name.trim()} onClick={create}>Создать</button>
      </div>
      {items.length === 0 && <div className="text-text-secondary text-sm">Категорий пока нет.</div>}
      <ul className="space-y-1">
        {items.map((c) => (
          <li key={c.id} className="flex items-center justify-between px-3 py-2 border border-border rounded-md">
            <span className="text-sm">{c.name}{c.code ? <span className="text-text-secondary text-xs"> · {c.code}</span> : null}{!c.is_active && <span className="text-warning text-xs ml-2">неактивна</span>}</span>
            <div className="flex gap-2 text-xs">
              <button className="text-accent" onClick={() => rename(c)}>Переименовать</button>
              <button className="text-text-secondary" onClick={() => toggle(c)}>{c.is_active ? 'Деактивировать' : 'Активировать'}</button>
              <button className="text-danger" onClick={() => remove(c)}>Удалить</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
