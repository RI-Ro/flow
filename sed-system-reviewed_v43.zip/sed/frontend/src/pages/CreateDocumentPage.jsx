import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import RouteBuilder from '../components/RouteBuilder'
import PersonPicker from '../components/PersonPicker'
import RecipientGroupPicker from '../components/RecipientGroupPicker'

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split('.')[1]))
  } catch (_) {
    return null
  }
}

export default function CreateDocumentPage() {
  const navigate = useNavigate()

  const [title, setTitle] = useState('')
  const [bodySummary, setBodySummary] = useState('')
  const [urgency, setUrgency] = useState('normal')
  const [categoryId, setCategoryId] = useState('') // #6 — обязательная категория
  const [categories, setCategories] = useState([])
  // #2 — «Готовность»: дата обязательна, время НЕОБЯЗАТЕЛЬНО и выбирается
  // (input type=time). Если время не задано — не подставляем ничего.
  const [dueDate, setDueDate] = useState('')
  const [dueTime, setDueTime] = useState('')
  const [file, setFile] = useState(null)

  // Единый упорядоченный маршрут согласования (тип у каждого + порядок).
  const [approvers, setApprovers] = useState([])
  const [sequential, setSequential] = useState(true) // по умолчанию включено
  const [skipApproval, setSkipApproval] = useState(false)
  const [signer, setSigner] = useState([]) // #3 — один или несколько подписантов
  const [recipients, setRecipients] = useState([]) // плановые адресаты рассылки
  const [onControl, setOnControl] = useState(false)
  const [controller, setController] = useState([]) // #4 — несколько контролёров

  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  // #3 — При наличии контролёров «по умолчанию» предвыбираем их и ставим
  // галочку «на контроле». Автор может снять галочку или изменить набор —
  // контролёр добавляется только с его явной санкции (постановка выполняется
  // после создания вызовом setControl).
  useEffect(() => {
    api.listCategories().then((r) => {
      const items = r.items || []
      setCategories(items)
      if (items.length && !categoryId) setCategoryId(String(items[0].id))
    }).catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    let cancelled = false
    api.getDefaultControllers().then((r) => {
      if (cancelled) return
      const items = r.items || []
      if (items.length > 0) {
        setController(items.map((u) => ({
          id: u.id, full_name: u.full_name, position: u.position,
          department_id: u.department_id, department_name: u.department_name, city: u.city,
        })))
        setOnControl(true)
      }
    }).catch(() => {})
    return () => { cancelled = true }
  }, [])

  const currentUserId = (() => {
    const token = localStorage.getItem('sed_token')
    const p = token ? parseJwt(token) : null
    return p?.uid
  })()

  const excludeForApprovers = [currentUserId].filter(Boolean)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')

    if (!file) {
      setError('Прикрепите PDF-файл документа')
      return
    }
    if (!categoryId) {
      setError('Выберите категорию документа')
      return
    }
    if (signer.length === 0) {
      setError('Выберите хотя бы одного подписанта — подпись обязательна')
      return
    }

    // Порядок в approvers = очерёдность. Бэкенд строит зависимости по этому
    // порядку, если включено последовательное согласование.
    const approversPayload = skipApproval
      ? []
      : approvers.map((a) => ({ stage_type: a.stage_type, approver_id: a.id }))

    const route = {
      approvers: approversPayload,
      sequential: skipApproval ? false : sequential,
      signer_ids: signer.map((s) => s.id), // #3 — мультиподпись
    }

    const formData = new FormData()
    formData.append('title', title)
    formData.append('body_summary', bodySummary)
    formData.append('urgency', urgency)
    formData.append('category_id', categoryId)
    if (dueDate) {
      // #2 — «Готовность»: дата обязательна, время НЕОБЯЗАТЕЛЬНО. Если время
      // не задано — НЕ подставляем ничего (шлём только дату, due_datetime не
      // отправляем), чтобы нигде не выводилось искусственное время.
      formData.append('due_date', dueDate)
      if (dueTime) {
        formData.append('due_datetime', new Date(`${dueDate}T${dueTime}`).toISOString())
      }
    }
    formData.append('route', JSON.stringify(route))
    // Плановые адресаты рассылки: применятся автоматически после подписи.
    if (recipients.length > 0) {
      formData.append(
        'recipients',
        JSON.stringify(recipients.map((r) => ({ user_id: r.id, department_id: r.department_id }))),
      )
    }
    formData.append('file', file)

    setSubmitting(true)
    try {
      const res = await api.createDocument(formData)
      // Постановка на контроль сразу при создании (если задано автором).
      if (onControl) {
        try {
          await api.setControl(res.id, true, controller.map((c) => c.id))
        } catch (_) {
          /* контроль вторичен — не блокируем переход */
        }
      }
      navigate(`/document/${res.id}`)
    } catch (err) {
      setError(err.message || 'Не удалось создать документ')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="font-display text-xl font-semibold mb-4">Новый документ</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="bg-surface border border-border rounded-lg p-4 space-y-3">
          <div>
            <label className="block text-sm mb-1">Краткое наименование</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Краткое содержание</label>
            <textarea
              value={bodySummary}
              onChange={(e) => setBodySummary(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Категория <span className="text-danger">*</span></label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt"
            >
              <option value="" disabled>— выберите категорию —</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm mb-1">Срочность</label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt"
              >
                <option value="normal">Обычная</option>
                <option value="urgent">Срочно</option>
                <option value="out_of_turn">Вне очереди</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-1">Готовность</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-md border border-border bg-surface-alt"
                />
                <input
                  type="time"
                  value={dueTime}
                  onChange={(e) => setDueTime(e.target.value)}
                  disabled={!dueDate}
                  title="Время (необязательно)"
                  className="w-28 px-2 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-50"
                />
              </div>
              <p className="text-[11px] text-text-secondary mt-1">Время указывать необязательно.</p>
            </div>
          </div>

          <div>
            <label className="block text-sm mb-1">Файл документа (только PDF)</label>
            <input
              type="file"
              accept="application/pdf"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              required
              className="w-full text-sm"
            />
          </div>
        </div>

        {/* Согласование — единый упорядоченный маршрут */}
        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium text-sm">Согласование</h2>
            <label className="flex items-center gap-2 text-xs text-text-secondary">
              <input type="checkbox" checked={skipApproval} onChange={(e) => setSkipApproval(e.target.checked)} />
              Пропустить согласование (сразу на подпись)
            </label>
          </div>

          {!skipApproval && (
            <div className="space-y-3">
              <RouteBuilder value={approvers} onChange={setApprovers} excludeIds={excludeForApprovers} />
              <label className="flex items-center gap-2 text-xs text-text-secondary">
                <input type="checkbox" checked={sequential} onChange={(e) => setSequential(e.target.checked)} />
                Последовательное согласование — каждый следующий видит документ только после предыдущего
                (если снять — все согласуют параллельно)
              </label>
            </div>
          )}
          {skipApproval && (
            <p className="text-xs text-text-secondary">
              Согласование пропущено. Документ сразу перейдёт на подпись — используйте, если по должности
              согласование не требуется.
            </p>
          )}
        </div>

        {/* Подпись — всегда отдельно и после согласования */}
        <div className="bg-surface border border-border rounded-lg p-4">
          <h2 className="font-medium text-sm mb-1">Подпись</h2>
          <p className="text-xs text-text-secondary mb-2">
            Подпись обязательна и всегда выполняется после того, как согласовали все. Можно указать
            нескольких подписантов — документ подписывает любой из них (достаточно одной подписи).
            В список попадают только пользователи с правом подписи.
          </p>
          <PersonPicker
            group="signing"
            multiple
            value={signer}
            onChange={setSigner}
          />
        </div>

        {/* Рассылка — плановые адресаты, выбираются автором на этапе создания.
            Применятся автоматически после подписания документа. */}
        <div className="bg-surface border border-border rounded-lg p-4">
          <h2 className="font-medium text-sm mb-1">Рассылка (адресаты)</h2>
          <p className="text-xs text-text-secondary mb-2">
            Кому направить документ после подписания. Адресаты получат доступ и уведомление только
            после того, как документ будет подписан. Можно оставить пустым и направить позже.
            Можно добавить группу адресатов целиком.
          </p>
          <RecipientGroupPicker
            value={recipients}
            onChange={setRecipients}
            excludeIds={[currentUserId].filter(Boolean)}
          />
          {recipients.length > 0 && (
            <div className="flex justify-end mb-1">
              <button type="button" onClick={() => setRecipients([])} className="text-xs text-danger hover:underline">
                Очистить всех
              </button>
            </div>
          )}
          <PersonPicker
            group="recipients"
            multiple
            value={recipients}
            onChange={setRecipients}
            excludeIds={[currentUserId].filter(Boolean)}
          />
        </div>

        {/* Контроль */}
        <div className="bg-surface border border-border rounded-lg p-4">
          <label className="flex items-center gap-2 text-sm mb-1">
            <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
            Поставить документ на контроль
          </label>
          <p className="text-xs text-text-secondary mb-2">
            Контролёры получат доступ к документу и уведомление; документ попадёт во вкладку «На контроле».
            Если заданы «контролёры по умолчанию», они предвыбраны и галочка установлена — вы можете
            изменить состав или снять контроль. Контролёров может быть несколько.
          </p>
          {onControl && (
            <div>
              <label className="block text-xs text-text-secondary mb-1">Контролёры</label>
              <PersonPicker
                group="controller"
                multiple
                value={controller}
                onChange={setController}
                excludeIds={[currentUserId].filter(Boolean)}
              />
            </div>
          )}
        </div>

        {error && (
          <div className="text-danger text-sm border border-danger/40 bg-danger/5 rounded-md px-3 py-2">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="px-4 py-2 rounded-md bg-accent text-accent-contrast font-medium disabled:opacity-60"
        >
          {submitting ? 'Создание…' : 'Создать документ'}
        </button>
      </form>
    </div>
  )
}
