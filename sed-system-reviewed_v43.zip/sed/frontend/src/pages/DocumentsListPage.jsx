import React, { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import UrgencyBadge from '../components/UrgencyBadge'
import Pagination from '../components/Pagination'
import PersonPicker from '../components/PersonPicker'
import { fmtDateTime, fmtDate, docYears } from '../utils/format'

const STATUS_LABELS = {
  draft: 'Черновик',
  on_approval_hierarchy: 'Согласование (иерархия)',
  on_approval_cross_dept: 'Согласование (межвед.)',
  on_signing: 'На подписи',
  signed: 'Подписан',
  sent: 'Отправлен',
  in_progress: 'В работе',
  executed: 'Исполнен',
  archived: 'В архиве',
  rejected: 'Отклонён',
}

const STATUS_COLORS = {
  draft: 'text-text-secondary',
  on_approval_hierarchy: 'text-warning',
  on_approval_cross_dept: 'text-warning',
  on_signing: 'text-warning',
  signed: 'text-accent',
  sent: 'text-accent',
  in_progress: 'text-accent-2',
  executed: 'text-success',
  archived: 'text-text-secondary',
  rejected: 'text-danger',
}

const CATEGORY_TITLES = {
  all: 'Все документы',
  awaiting: 'Ожидают регистрации',
  outgoing: 'Исходящие',
  incoming: 'Входящие',
  on_approval: 'На согласовании',
  on_signing: 'На подписи',
  control: 'На контроле',
  executed: 'Исполнено',
  archive: 'Архив',
}

const PAGE_SIZE = 20
const SEARCH_DEBOUNCE_MS = 300

const EMPTY_FILTERS = {
  status: '', urgency: '', onControl: '', number: '', incomingNumber: '', categoryId: '',
  signedFrom: '', signedTo: '', createdFrom: '', createdTo: '', dueFrom: '', dueTo: '',
  author: [], signer: [], controller: [],
}

export default function DocumentsListPage() {
  const { category = 'all' } = useParams()
  const navigate = useNavigate()

  const [page, setPage] = useState(1)
  const [data, setData] = useState({ items: [], total_count: 0, page: 1, page_size: PAGE_SIZE })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const [activeQuery, setActiveQuery] = useState('')
  const [f, setF] = useState(EMPTY_FILTERS)
  const [showFilters, setShowFilters] = useState(false)
  const [counts, setCounts] = useState({})
  const [modalDoc, setModalDoc] = useState(null)
  const [approversDoc, setApproversDoc] = useState(null)
  const [incomingDoc, setIncomingDoc] = useState(null)
  const [archiveYear, setArchiveYear] = useState('') // фильтр года для архива ('' = все)
  const [categories, setCategories] = useState([])

  useEffect(() => { api.listCategories().then((r) => setCategories(r.items || [])).catch(() => {}) }, [])

  const setFilter = (patch) => { setF((prev) => ({ ...prev, ...patch })); setPage(1) }

  useEffect(() => {
    setPage(1)
    setSearchInput('')
    setActiveQuery('')
    setF(EMPTY_FILTERS)
  }, [category])

  useEffect(() => {
    const t = setTimeout(() => {
      setActiveQuery(searchInput.trim())
      setPage(1)
    }, SEARCH_DEBOUNCE_MS)
    return () => clearTimeout(t)
  }, [searchInput])

  const hasAnyFilter = Boolean(
    activeQuery || f.status || f.urgency || f.onControl || f.number || f.incomingNumber || f.categoryId ||
    f.signedFrom || f.signedTo || f.createdFrom || f.createdTo || f.dueFrom || f.dueTo ||
    f.author.length || f.signer.length || f.controller.length
  )

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    // Ограничения, вытекающие из текущей категории (вкладки) — чтобы поиск/
    // фильтр работал В ПРЕДЕЛАХ категории, а не по всей базе.
    const catParams = {}
    if (category === 'control') catParams.onControl = 'true'
    else if (category === 'executed') catParams.status = 'executed'
    else if (category === 'archive') catParams.status = 'archived'
    else if (category === 'on_signing') catParams.status = 'on_signing'
    else if (category === 'on_approval') catParams.status = 'on_approval_hierarchy,on_approval_cross_dept'
    try {
      const res = hasAnyFilter
        ? await api.searchDocuments({
            category, // ограничиваем поиск пределами категории
            q: activeQuery || undefined,
            status: f.status || catParams.status || undefined,
            urgency: f.urgency || undefined,
            onControl: f.onControl || catParams.onControl || undefined,
            number: f.number || undefined,
            incomingNumber: f.incomingNumber || undefined,
            categoryId: f.categoryId || undefined,
            signedFrom: f.signedFrom || undefined,
            signedTo: f.signedTo || undefined,
            createdFrom: f.createdFrom || undefined,
            createdTo: f.createdTo || undefined,
            dueFrom: f.dueFrom || undefined,
            dueTo: f.dueTo || undefined,
            authorId: f.author[0]?.id || undefined,
            signerId: f.signer[0]?.id || undefined,
            controllerId: f.controller[0]?.id || undefined,
            page,
            pageSize: PAGE_SIZE,
          })
        : await api.listDocuments({ category, page, pageSize: PAGE_SIZE, year: category === 'archive' && archiveYear ? archiveYear : undefined })
      setData(res)
      // Доп. реквизиты строк (автор, подписант, дата подписи, вх. номера,
      // счётчик адресатов) подтягиваются пакетно эффектом ниже по всем id.
    } catch (err) {
      setError(err.message || 'Не удалось загрузить список документов')
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, page, activeQuery, f, archiveYear])

  useEffect(() => { load() }, [load])

  // Пакетно подтягиваем счётчики адресатов для текущей страницы (без N+1).
  useEffect(() => {
    const ids = (data.items || []).map((d) => d.id)
    if (!ids.length) { setCounts({}); return }
    let cancelled = false
    api.recipientsCounts(ids).then((r) => { if (!cancelled) setCounts(r.counts || {}) }).catch(() => {})
    return () => { cancelled = true }
  }, [data])

  const resetFilters = () => { setF(EMPTY_FILTERS); setSearchInput(''); setActiveQuery(''); setPage(1) }

  const Field = ({ label, children }) => (
    <div>
      <label className="block text-xs text-text-secondary mb-1">{label}</label>
      {children}
    </div>
  )
  const dateInput = (key) => (
    <input
      type="date"
      value={f[key]}
      onChange={(e) => setFilter({ [key]: e.target.value })}
      className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
    />
  )
  const textInput = (key, ph) => (
    <input
      value={f[key]}
      onChange={(e) => setFilter({ [key]: e.target.value })}
      placeholder={ph}
      className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-40"
    />
  )

  return (
    <div className="p-6 max-w-[120rem] mx-auto">
      <div className="flex items-center justify-between mb-4 gap-4">
        <h1 className="font-display text-xl font-semibold">{CATEGORY_TITLES[category] || 'Документы'}</h1>
        <div className="flex items-center gap-2">
          {category === 'archive' && (
            <select
              value={archiveYear}
              onChange={(e) => { setArchiveYear(e.target.value); setPage(1) }}
              className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
              title="Год архива"
            >
              <option value="">Все годы</option>
              {docYears().map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          )}
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Поиск по названию и содержанию…"
            className="w-72 px-3 py-1.5 rounded-md border border-border bg-surface-alt text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          />
          <button
            onClick={() => setShowFilters((v) => !v)}
            className={`px-3 py-1.5 rounded-md border text-sm ${hasAnyFilter ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}
          >
            Фильтры{hasAnyFilter ? ' •' : ''}
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="mb-4 bg-surface border border-border rounded-lg p-4 grid grid-cols-2 md:grid-cols-4 gap-3 items-start">
          <Field label="Статус">
            <select value={f.status} onChange={(e) => setFilter({ status: e.target.value })}
              className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-full">
              <option value="">Любой</option>
              {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Field>
          <Field label="Категория">
            <select value={f.categoryId} onChange={(e) => setFilter({ categoryId: e.target.value })}
              className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-full">
              <option value="">Любая</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Срочность">
            <select value={f.urgency} onChange={(e) => setFilter({ urgency: e.target.value })}
              className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-full">
              <option value="">Любая</option>
              <option value="normal">Обычная</option>
              <option value="urgent">Срочно</option>
              <option value="out_of_turn">Вне очереди</option>
            </select>
          </Field>
          <Field label="Контроль">
            <select value={f.onControl} onChange={(e) => setFilter({ onControl: e.target.value })}
              className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm w-full">
              <option value="">Любой</option>
              <option value="true">Только на контроле</option>
              <option value="false">Не на контроле</option>
            </select>
          </Field>
          <Field label="Исходящий №">{textInput('number', 'часть номера')}</Field>
          <Field label="Входящий №">{textInput('incomingNumber', 'часть номера')}</Field>
          <Field label="Создан с">{dateInput('createdFrom')}</Field>
          <Field label="Создан по">{dateInput('createdTo')}</Field>
          <Field label="Срок с">{dateInput('dueFrom')}</Field>
          <Field label="Срок по">{dateInput('dueTo')}</Field>
          <Field label="Подписан с">{dateInput('signedFrom')}</Field>
          <Field label="Подписан по">{dateInput('signedTo')}</Field>
          <div className="col-span-2 md:col-span-4 grid grid-cols-1 md:grid-cols-3 gap-3">
            <Field label="Автор"><PersonPicker group="all" multiple={false} value={f.author} onChange={(v) => setFilter({ author: v })} /></Field>
            <Field label="Подписант"><PersonPicker group="signing" multiple={false} value={f.signer} onChange={(v) => setFilter({ signer: v })} /></Field>
            <Field label="Контролёр"><PersonPicker group="all" multiple={false} value={f.controller} onChange={(v) => setFilter({ controller: v })} /></Field>
          </div>
          {hasAnyFilter && (
            <div className="col-span-2 md:col-span-4">
              <button onClick={resetFilters} className="px-3 py-1.5 text-sm text-danger">Сбросить все фильтры</button>
            </div>
          )}
        </div>
      )}

      {hasAnyFilter && <div className="kicker mb-2">// найдено записей: {data.total_count}</div>}

      {error && (
        <div className="mb-4 text-danger text-sm border border-danger/40 bg-danger/5 rounded-md px-3 py-2">{error}</div>
      )}

      {/* Пагинация — сверху (по требованию). */}
      <div className="flex justify-end mb-2">
        <Pagination page={data.page || page} pageSize={data.page_size || PAGE_SIZE} totalCount={data.total_count || 0} onPageChange={setPage} />
      </div>

      <div className="bg-surface border border-border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border">
              <th className="px-3 py-2 font-medium">Срочность</th>
              <th className="px-3 py-2 font-medium">Готовность</th>
              <th className="px-3 py-2 font-medium">№ исх. / дата подписи</th>
              <th className="px-3 py-2 font-medium">№ вх. (подр., рег.)</th>
              <th className="px-3 py-2 font-medium">Подписант</th>
              <th className="px-3 py-2 font-medium">Краткое наименование / содержание</th>
              <th className="px-3 py-2 font-medium">Статус</th>
              <th className="px-3 py-2 font-medium">Автор</th>
              <th className="px-3 py-2 font-medium">Согласующие</th>
              <th className="px-3 py-2 font-medium">Рассылка</th>
              <th className="px-3 py-2 font-medium">Создан</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={11} className="px-4 py-6 text-center text-text-secondary">Загрузка…</td></tr>
            )}
            {!loading && data.items?.length === 0 && (
              <tr><td colSpan={11} className="px-4 py-6 text-center text-text-secondary">
                {hasAnyFilter ? 'Ничего не найдено' : 'В этой категории пока нет документов'}
              </td></tr>
            )}
            {!loading && data.items?.map((doc) => {
              const c = counts[doc.id] || {}
              const rowTone =
                doc.urgency === 'out_of_turn'
                  ? 'row-oot'
                  : doc.urgency === 'urgent'
                  ? 'row-urgent'
                  : 'hover:bg-surface-alt'
              const dueVal = doc.due_datetime || doc.due_date
              const overdue = dueVal && new Date(dueVal) < new Date() && !['executed', 'archived'].includes(doc.status)
              const apr = c.approvers || []
              const aprDone = apr.filter((x) => x.status === 'approved').length
              return (
              <tr key={doc.id}
                className={`border-b border-border last:border-0 cursor-pointer align-top transition-colors ${rowTone}`}
                onClick={() => navigate(`/document/${doc.id}`)}>
                {/* Срочность */}
                <td className="px-3 py-2"><UrgencyBadge urgency={doc.urgency} /></td>
                {/* Готовность (с временем) */}
                <td className="px-3 py-2 whitespace-nowrap">
                  {dueVal ? (
                    <span className={`font-medium ${overdue ? 'text-danger' : doc.urgency === 'out_of_turn' ? 'text-danger' : doc.urgency === 'urgent' ? 'text-warning' : 'text-text-primary'}`}>
                      {doc.due_datetime
                        ? fmtDateTime(doc.due_datetime)
                        : fmtDate(doc.due_date)}
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* № исх. / дата подписи */}
                <td className="px-3 py-2 font-mono text-xs text-text-secondary whitespace-nowrap">
                  <div>{doc.outgoing_number || `#${doc.id}`}</div>
                  {c.signed_at && (
                    <div className="text-[10px]">{fmtDateTime(c.signed_at)}</div>
                  )}
                </td>
                {/* № вх. — компактно: количество, по клику детали (#2) */}
                <td className="px-3 py-2 font-mono text-xs"
                  onClick={(e) => { e.stopPropagation(); if ((c.incoming_numbers || []).length) setIncomingDoc({ doc, inc: c.incoming_numbers }) }}>
                  {(c.incoming_numbers || []).length
                    ? <span className="text-accent hover:underline cursor-pointer">{(c.incoming_numbers || []).length} вх.</span>
                    : <span className="text-text-secondary">—</span>}
                </td>
                {/* Подписант (с должностью) */}
                <td className="px-3 py-2 text-text-secondary text-xs">{c.signer_name || '—'}</td>
                {/* Краткое наименование / содержание */}
                <td className="px-3 py-2">
                  <div className="font-medium text-text-primary">{doc.title}</div>
                  {doc.body_summary && <div className="text-xs text-text-secondary line-clamp-2 max-w-md">{doc.body_summary}</div>}
                </td>
                {/* Статус (цветом) */}
                <td className={`px-3 py-2 font-medium ${STATUS_COLORS[doc.status] || 'text-text-secondary'}`}>{STATUS_LABELS[doc.status] || doc.status}</td>
                {/* Автор (с должностью) */}
                <td className="px-3 py-2 text-text-secondary text-xs">
                  <div>{c.author_name || '—'}</div>
                  {c.department_name && <div className="opacity-70">{c.department_name}</div>}
                </td>
                {/* Согласующие (2/1) — по клику детали со статусом и временем */}
                <td className="px-3 py-2"
                  onClick={(e) => { e.stopPropagation(); if (apr.length) setApproversDoc({ doc, apr }) }}>
                  {apr.length ? (
                    <span className="text-accent hover:underline cursor-pointer">
                      {apr.length} / <span className="text-success font-medium">{aprDone}</span>
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Рассылка (2/1) */}
                <td className="px-3 py-2"
                  onClick={(e) => { e.stopPropagation(); if (c.total) setModalDoc(doc) }}>
                  {c.total !== undefined ? (
                    <span className={`inline-flex items-center gap-1 ${c.total ? 'text-accent hover:underline cursor-pointer' : 'text-text-secondary'}`}>
                      {c.total}{' / '}<span className="text-success font-medium">{c.done}</span>
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Дата создания */}
                <td className="px-3 py-2 text-text-secondary text-xs whitespace-nowrap">{fmtDateTime(doc.created_at)}</td>
              </tr>
            )})}
          </tbody>
        </table>
      </div>

      {modalDoc && <RecipientsModal doc={modalDoc} onClose={() => setModalDoc(null)} />}
      {approversDoc && <ApproversModal data={approversDoc} onClose={() => setApproversDoc(null)} />}
      {incomingDoc && <IncomingModal data={incomingDoc} onClose={() => setIncomingDoc(null)} />}
    </div>
  )
}

// Модалка с детальной информацией об адресатах документа и отметке исполнения.
function RecipientsModal({ doc, onClose }) {
  const [items, setItems] = useState(null)
  const [error, setError] = useState('')
  useEffect(() => {
    let cancelled = false
    api.getRecipients(doc.id)
      .then((r) => { if (!cancelled) setItems((r.items || []).filter((x) => !x.is_planned)) })
      .catch((e) => { if (!cancelled) setError(e.message) })
    return () => { cancelled = true }
  }, [doc.id])
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-surface border border-border rounded-lg p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Адресаты — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        {error && <div className="text-danger text-sm mb-2">{error}</div>}
        {!items && !error && <div className="text-text-secondary text-sm">Загрузка…</div>}
        {items && items.length === 0 && <div className="text-text-secondary text-sm">Документ ещё не направлен адресатам</div>}
        {items && items.length > 0 && (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-text-secondary border-b border-border">
                <th className="py-2 pr-3 font-medium">Получатель</th>
                <th className="py-2 pr-3 font-medium">Подразделение</th>
                <th className="py-2 pr-3 font-medium">Исполнение</th>
                <th className="py-2 font-medium">Отметка</th>
              </tr>
            </thead>
            <tbody>
              {items.map((r) => (
                <tr key={r.user_id} className="border-b border-border last:border-0">
                  <td className="py-2 pr-3">{r.full_name}</td>
                  <td className="py-2 pr-3 text-text-secondary">{r.department_name}</td>
                  <td className="py-2 pr-3">
                    {r.completed_at ? (
                      <span className="text-success">исполнено · {fmtDate(r.completed_at)}</span>
                    ) : (
                      <span className="text-warning">в работе</span>
                    )}
                  </td>
                  <td className="py-2 text-text-secondary">{r.completion_note || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {items && items.length > 0 && (
          <div className="mt-3 text-xs text-text-secondary">
            Всего: {items.length} · исполнили:{' '}
            <span className="text-success">{items.filter((x) => x.completed_at).length}</span>
          </div>
        )}
      </div>
    </div>
  )
}

// Модалка согласующих: ФИО с должностью, статус (цветом) и время согласования.
const APPROVAL_STATUS_LABELS = {
  approved: 'согласовано',
  rejected: 'отклонено',
  pending: 'на согласовании',
  waiting_deps: 'ожидает',
}
const APPROVAL_STATUS_COLORS = {
  approved: 'text-success',
  rejected: 'text-danger',
  pending: 'text-warning',
  waiting_deps: 'text-text-secondary',
}
function IncomingModal({ data, onClose }) {
  const { doc, inc } = data
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-surface border border-border rounded-lg p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Входящие номера — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border">
              <th className="py-2 pr-3 font-medium">Подразделение</th>
              <th className="py-2 pr-3 font-medium">Входящий №</th>
              <th className="py-2 font-medium">Зарегистрирован</th>
            </tr>
          </thead>
          <tbody>
            {(inc || []).map((i, idx) => (
              <tr key={idx} className="border-b border-border last:border-0">
                <td className="py-2 pr-3 text-text-secondary">{i.department || '—'}</td>
                <td className="py-2 pr-3 font-mono">{i.number}</td>
                <td className="py-2 text-text-secondary">{i.registered_at ? fmtDateTime(i.registered_at) : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 text-xs text-text-secondary">Всего входящих номеров: {(inc || []).length}</div>
      </div>
    </div>
  )
}

function ApproversModal({ data, onClose }) {
  const { doc, apr } = data
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-surface border border-border rounded-lg p-5 w-full max-w-2xl max-h-[85vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg font-semibold">Согласующие — {doc.title}</h2>
          <button onClick={onClose} className="text-text-secondary text-xl leading-none">×</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border">
              <th className="py-2 pr-3 font-medium">Согласующий</th>
              <th className="py-2 pr-3 font-medium">Этап</th>
              <th className="py-2 pr-3 font-medium">Статус</th>
              <th className="py-2 font-medium">Время согласования</th>
            </tr>
          </thead>
          <tbody>
            {apr.map((a, i) => (
              <tr key={i} className="border-b border-border last:border-0">
                <td className="py-2 pr-3">{a.name}</td>
                <td className="py-2 pr-3 text-text-secondary">{a.stage_type === 'cross_dept' ? 'межвед.' : 'иерархия'}</td>
                <td className={`py-2 pr-3 font-medium ${APPROVAL_STATUS_COLORS[a.status] || 'text-text-secondary'}`}>
                  {APPROVAL_STATUS_LABELS[a.status] || a.status}
                </td>
                <td className="py-2 text-text-secondary">
                  {a.decided_at ? fmtDateTime(a.decided_at) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 text-xs text-text-secondary">
          Всего: {apr.length} · согласовали:{' '}
          <span className="text-success">{apr.filter((x) => x.status === 'approved').length}</span>
        </div>
      </div>
    </div>
  )
}
