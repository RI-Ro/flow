import React, { useEffect, useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import ThemeSwitcher from './ThemeSwitcher'
import NotificationsBell from './NotificationsBell'
import { useAuth } from '../context/AuthContext'
import { api } from '../api/client'

const CATEGORIES = [
  { id: 'all', label: 'Все документы' },
  { id: 'awaiting', label: 'Ожидают регистрации' },
  { id: 'outgoing', label: 'Исходящие' },
  { id: 'incoming', label: 'Входящие' },
  { id: 'on_approval', label: 'На согласовании' },
  { id: 'on_signing', label: 'На подписи' },
  { id: 'control', label: 'На контроле' },
  { id: 'print_unregistered', label: 'На регистрацию' },
  { id: 'executed', label: 'Исполнено' },
  { id: 'archive', label: 'Архив' },
]

export default function Layout() {
  const { login, doLogout, canCreate, fullName, position, isAdmin } = useAuth()
  const navigate = useNavigate()
  const [brand, setBrand] = useState({ app_name: 'SED', tagline: '// доведение указаний', copyright: '', about: '' })
  const [showAbout, setShowAbout] = useState(false)

  useEffect(() => {
    api.getAppConfig().then(setBrand).catch(() => {})
  }, [])

  return (
    <div className="min-h-screen flex bg-bg text-text-primary font-body">
      <aside className="w-60 shrink-0 border-r border-border bg-surface flex flex-col h-screen sticky top-0">
        <div className="px-4 py-4 border-b border-border shrink-0">
          <div className="font-display font-semibold text-lg tracking-tight">{brand.app_name}</div>
          <div className="kicker">{brand.tagline}</div>
        </div>
        <nav className="flex-1 py-2 overflow-y-auto">
          {canCreate && (
            <NavLink
              to="/document/new"
              className="glow-accent block mx-2 mb-3 px-4 py-2 text-sm rounded-md bg-accent text-accent-contrast text-center font-semibold"
            >
              + Новый документ
            </NavLink>
          )}
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                isActive ? 'bg-accent text-accent-contrast' : 'hover:bg-surface-alt text-text-primary'
              }`
            }
          >
            Дашборд
          </NavLink>
          {CATEGORIES.map((cat) => (
            <NavLink
              key={cat.id}
              to={`/documents/${cat.id}`}
              className={({ isActive }) =>
                `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                  isActive ? 'bg-accent text-accent-contrast' : 'hover:bg-surface-alt text-text-primary'
                }`
              }
            >
              {cat.label}
            </NavLink>
          ))}
          {/* Журналы — в самом низу навигации, после архива. */}
          <NavLink
            to="/registry/outgoing"
            className={({ isActive }) =>
              `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-2 border-t border-border pt-3 ${
                isActive ? 'bg-accent text-accent-contrast' : 'hover:bg-surface-alt text-text-primary'
              }`
            }
          >
            Журналы
          </NavLink>

          {isAdmin && (
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-1 ${
                  isActive ? 'bg-accent text-accent-contrast' : 'hover:bg-surface-alt text-text-primary'
                }`
              }
            >
              Администрирование
            </NavLink>
          )}
        </nav>
        <div className="px-4 py-3 border-t border-border text-xs text-text-secondary shrink-0">
          <div className="font-medium text-text-primary truncate" title={fullName || login}>
            {fullName || login}
          </div>
          {position && <div className="truncate opacity-80" title={position}>{position}</div>}
          <div className="opacity-60 mt-0.5">{login}</div>
          <button
            className="block mt-2 text-danger hover:underline"
            onClick={() => {
              doLogout()
              navigate('/login')
            }}
          >
            Выйти
          </button>
          <button
            className="mt-2 pt-2 border-t border-border text-[11px] opacity-70 leading-snug text-left hover:opacity-100 hover:text-accent w-full"
            onClick={() => setShowAbout(true)}
            title="Справочная информация"
          >
            © {brand.copyright || brand.app_name}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border bg-surface flex items-center justify-end px-4 gap-3 sticky top-0 z-10">
          <NotificationsBell />
          <ThemeSwitcher />
        </header>
        <main className="flex-1 min-w-0">
          <Outlet />
        </main>
      </div>

      {showAbout && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAbout(false)}>
          <div className="bg-surface border border-border rounded-lg w-full max-w-2xl max-h-[85vh] overflow-auto shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-3 border-b border-border sticky top-0 bg-surface">
              <h2 className="font-display text-lg font-semibold">О системе {brand.app_name}</h2>
              <button onClick={() => setShowAbout(false)} className="text-text-secondary text-2xl leading-none hover:text-text-primary">×</button>
            </div>
            <div className="p-5 text-sm text-text-primary whitespace-pre-wrap leading-relaxed">
              {brand.about || 'Справочная информация не задана (branding.about в конфиге).'}
            </div>
            <div className="px-5 pb-4 text-xs text-text-secondary">© {brand.copyright || brand.app_name}</div>
          </div>
        </div>
      )}
    </div>
  )
}
