import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { playEventSound, primeAudio, loadSoundSettings, saveSoundSettings } from '../lib/sound'
import { fmtDateTime } from '../utils/format'

const KIND_LABELS = {
  stage_pending: 'Требуется ваше решение по документу',
  stage_approved: 'Документ согласован',
  stage_rejected: 'Документ отклонён',
  document_signed: 'Документ подписан',
  document_sent: 'Вам направлен документ',
  assignment: 'Вам дано поручение',
  assignment_status_changed: 'Изменён статус поручения',
  control_assigned: 'Вы назначены контролёром',
  acquaintance: 'Вас ознакомили с документом',
  acquainted: 'Ознакомление с документом',
  chat_message: 'Новое сообщение в обсуждении',
  due_soon: 'Приближается срок',
  overdue: 'Просрочен срок',
}

// Короткий звук уведомления через WebAudio — не тянем аудиофайл, генерируем
// «бип» программно. Звук включается пользователем (кнопка), т.к. браузеры
// Старый одиночный beep заменён на модуль lib/sound.js: тоны различаются по
// категории события, настройки хранятся в localStorage и разблокируются на
// первом жесте (primeAudio).

export default function NotificationsBell() {
  const [open, setOpen] = useState(false)
  const [items, setItems] = useState([])
  const [unread, setUnread] = useState(0)
  const [sound, setSound] = useState(loadSoundSettings)
  const soundOn = sound.enabled
  const navigate = useNavigate()
  const ref = useRef(null)
  const wsRef = useRef(null)

  const load = useCallback(async () => {
    try {
      const res = await api.getNotifications({ limit: 50 })
      setItems(res.items || [])
      setUnread(res.unread_count || 0)
    } catch (_) {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  // WS с авто-переподключением: при новом уведомлении обновляем список и
  // (если включено) пищим. Для 1000+ пользователей обрывы соединения
  // неизбежны (рестарты, таймауты балансировщика), поэтому при закрытии
  // сокета переподключаемся с экспоненциальным backoff, а после каждого
  // (пере)подключения делаем refetch — чтобы не потерять уведомления,
  // пришедшие в окно недоступности WS (БД — источник истины, WS — ускоритель).
  useEffect(() => {
    let closedByUs = false
    let retry = 0
    let reconnectTimer = null

    function connect() {
      let ws
      try {
        ws = new WebSocket(api.wsNotificationsURL())
      } catch (_) {
        scheduleReconnect()
        return
      }
      wsRef.current = ws

      ws.onopen = () => {
        retry = 0
        // Догоняем пропущенное за время обрыва.
        load()
      }
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'notification') {
            setUnread((u) => u + 1)
            load()
            playEventSound(msg.kind || 'notification', msg.urgency)
          }
        } catch (_) {
          /* ignore */
        }
      }
      ws.onclose = () => {
        if (!closedByUs) scheduleReconnect()
      }
      ws.onerror = () => {
        try { ws.close() } catch (_) { /* noop */ }
      }
    }

    function scheduleReconnect() {
      retry += 1
      const delay = Math.min(30000, 1000 * 2 ** Math.min(retry, 5)) // 2с..30с
      reconnectTimer = setTimeout(connect, delay)
    }

    // При возврате фокуса/онлайна — форсируем refetch и переподключение,
    // если сокет закрыт (ловит случай «ноутбук вышел из сна»).
    function onFocus() {
      load()
      const s = wsRef.current
      if (!s || s.readyState === WebSocket.CLOSED || s.readyState === WebSocket.CLOSING) {
        clearTimeout(reconnectTimer)
        connect()
      }
    }

    connect()
    window.addEventListener('focus', onFocus)
    window.addEventListener('online', onFocus)

    return () => {
      closedByUs = true
      clearTimeout(reconnectTimer)
      window.removeEventListener('focus', onFocus)
      window.removeEventListener('online', onFocus)
      try { wsRef.current && wsRef.current.close() } catch (_) { /* noop */ }
    }
  }, [load])

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  async function onItemClick(it) {
    if (!it.is_read) {
      try {
        await api.markNotificationRead(it.id)
        setUnread((u) => Math.max(0, u - 1))
        setItems((arr) => arr.map((x) => (x.id === it.id ? { ...x, is_read: true } : x)))
      } catch (_) {
        /* ignore */
      }
    }
    if (it.document_id) {
      setOpen(false)
      navigate(`/document/${it.document_id}`)
    }
  }

  async function markAll() {
    try {
      await api.markAllNotificationsRead()
      setUnread(0)
      setItems((arr) => arr.map((x) => ({ ...x, is_read: true })))
    } catch (_) {
      /* ignore */
    }
  }

  function toggleSound() {
    const next = { ...sound, enabled: !sound.enabled }
    setSound(next)
    saveSoundSettings(next)
    if (next.enabled) playEventSound('notification') // подтверждаем и разблокируем WebAudio
  }

  // Разблокировать звук на первом жесте (события приходят по сети, не из клика).
  useEffect(() => { primeAudio() }, [])

  function fmt(ts) {
    try {
      return fmtDateTime(ts)
    } catch (_) {
      return ts
    }
  }

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((v) => !v)} className="relative px-2 py-1.5 rounded-md hover:bg-surface-alt" title="Уведомления">
        <span className="text-lg">🔔</span>
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 bg-danger text-white text-[10px] rounded-full min-w-4 h-4 px-1 flex items-center justify-center">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-1 w-80 bg-surface border border-border rounded-lg shadow-lg z-30">
          <div className="flex items-center justify-between px-3 py-2 border-b border-border">
            <span className="text-sm font-medium">Уведомления</span>
            <div className="flex items-center gap-2">
              <button onClick={toggleSound} className="text-xs text-text-secondary" title="Звук уведомлений">
                {soundOn ? '🔊' : '🔇'}
              </button>
              <button onClick={markAll} className="text-xs text-accent">
                Прочитать все
              </button>
            </div>
          </div>
          <div className="max-h-96 overflow-auto">
            {items.length === 0 && <div className="px-3 py-6 text-center text-text-secondary text-sm">Нет уведомлений</div>}
            {items.map((it) => (
              <button
                key={it.id}
                onClick={() => onItemClick(it)}
                className={`w-full text-left px-3 py-2 border-b border-border last:border-0 hover:bg-surface-alt ${
                  it.is_read ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-start gap-2">
                  {!it.is_read && <span className="mt-1.5 w-2 h-2 rounded-full bg-accent shrink-0" />}
                  <div className="flex-1">
                    <div className="text-sm">{KIND_LABELS[it.kind] || 'Обновление по документу'}</div>
                    {it.document_title && <div className="text-xs text-text-secondary truncate">{it.document_title}</div>}
                    <div className="text-[10px] text-text-secondary mt-0.5">{fmt(it.created_at)}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
