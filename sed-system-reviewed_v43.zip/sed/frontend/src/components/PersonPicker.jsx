import React, { useState, useEffect, useRef, useCallback } from 'react'
import { api } from '../api/client'

const SEARCH_DEBOUNCE_MS = 250

// PersonPicker — мультивыбор людей для шага маршрута/рассылки с серверным
// поиском. По требованию: участники группы показываются СРАЗУ при открытии
// (до ввода фильтра), чтобы можно было выбрать их одним нажатием; ввод текста
// лишь сужает список. Уже выбранные и исключённые (excludeIds) не предлагаются.
// В выбранном элементе несём department_id — он обязателен для рассылки
// (DB-триггер проверяет роль получателя именно в этом подразделении).
//
// props:
//   group      — 'hierarchy' | 'cross_dept' | 'signing' | 'recipients' | 'all'
//   multiple   — true для списков, false для одиночного (подписант)
//   value      — [{ id, full_name, department_id, department_name }]
//   onChange   — (nextValue) => void
//   excludeIds — id, которые нельзя выбирать (автор, уже выбранные)
//   placeholder
export default function PersonPicker({ group, multiple = true, value = [], onChange, excludeIds = [], placeholder }) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const ref = useRef(null)

  const excluded = new Set([...excludeIds, ...value.map((v) => v.id)])

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  // Загружаем кандидатов при открытии и при изменении запроса. Пустой q
  // возвращает начало списка группы (бэкенд поддерживает ILIKE '%%').
  useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await api.searchCandidates({ group, q: query.trim(), limit: 30 })
        if (!cancelled) setResults(res.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      } finally {
        if (!cancelled) setLoading(false)
      }
    }, query.trim() ? SEARCH_DEBOUNCE_MS : 0)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [query, group, open])

  const pick = useCallback(
    (person) => {
      const item = {
        id: person.id,
        full_name: person.full_name,
        position: person.position,
        department_id: person.department_id,
        department_name: person.department_name,
        city: person.city,
      }
      onChange(multiple ? [...value, item] : [item])
      setQuery('')
      if (!multiple) setOpen(false)
    },
    [multiple, value, onChange],
  )

  const remove = useCallback((id) => onChange(value.filter((v) => v.id !== id)), [value, onChange])

  // Группировка результатов по подразделению. Ключ — id+имя, чтобы один
  // человек с ролью в нескольких подразделениях отображался отдельно.
  const grouped = results
    .filter((r) => !excluded.has(r.id))
    .reduce((acc, r) => {
      const key = r.department_name || 'Без подразделения'
      ;(acc[key] = acc[key] || []).push(r)
      return acc
    }, {})

  return (
    <div className="relative" ref={ref}>
      <div className="flex flex-wrap gap-1.5 mb-1.5">
        {value.map((v) => (
          <span
            key={`${v.id}:${v.department_id || 0}`}
            className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 text-text-primary rounded-full px-2 py-0.5 text-xs"
          >
            {v.full_name}
            {v.department_name && <span className="text-text-secondary">· {v.department_name}</span>}
            <button type="button" onClick={() => remove(v.id)} className="text-danger ml-0.5">
              ×
            </button>
          </span>
        ))}
        {value.length === 0 && <span className="text-xs text-text-secondary">никого не выбрано</span>}
      </div>

      {(multiple || value.length === 0) && (
        <input
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value)
            setOpen(true)
          }}
          placeholder={placeholder || 'Выберите из списка или начните вводить имя…'}
          className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm focus:outline-none focus:ring-2 focus:ring-accent"
        />
      )}

      {open && (
        <div className="absolute z-20 mt-1 w-full max-h-64 overflow-auto bg-surface border border-border rounded-md shadow-lg">
          {loading && <div className="px-3 py-2 text-xs text-text-secondary">Загрузка…</div>}
          {!loading && Object.keys(grouped).length === 0 && (
            <div className="px-3 py-2 text-xs text-text-secondary">
              {query.trim() ? 'Ничего не найдено' : 'В этой группе нет доступных участников'}
            </div>
          )}
          {!loading &&
            Object.entries(grouped).map(([dept, people]) => (
              <div key={dept}>
                <div className="kicker px-3 pt-2 pb-1 sticky top-0 bg-surface">// {dept}</div>
                {people.map((p) => (
                  <button
                    key={`${p.id}:${p.department_id || 0}`}
                    type="button"
                    onClick={() => pick(p)}
                    className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span>{p.full_name}</span>
                    </div>
                    {/* #6 — подразделение, город, должность в строке кандидата */}
                    {(p.position || p.department_name || p.city) && (
                      <div className="text-[11px] text-text-secondary leading-tight">
                        {[p.position, p.department_name, p.city].filter(Boolean).join(' · ')}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            ))}
        </div>
      )}
    </div>
  )
}
