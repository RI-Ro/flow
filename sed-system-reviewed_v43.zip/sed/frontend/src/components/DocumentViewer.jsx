import React, { useEffect, useRef, useState, useCallback } from 'react'
// #8 — LEGACY-сборка pdf.js: транспилирована под старые браузеры (ES5-совместимо),
// в отличие от основной сборки, которая использует современный синтаксис и не
// открывалась у части пользователей. Ниже — надёжная инициализация воркера с
// fallback в безворкерный режим, а при полном отказе рендера — нативный
// просмотрщик браузера (см. состояние fallback).
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf'
import pdfWorker from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url'
import { api } from '../api/client'

try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker
} catch (_) {
  /* окружение без поддержки воркеров — рендер пойдёт в основном потоке */
}

// Просмотрщик без кнопок скачивания/печати (рендер на canvas через pdf.js,
// без тулбара браузера). Масштаб (−/+/сброс), полноэкранный режим, блокировка
// контекстного меню (UX-барьер, не крипто-защита).
//
// МАРКИРОВКА (overlay): штампы приходят через prop `stamps` (см. эндпоинт
// GET /api/documents/:id/marking) и рисуются поверх ПЕРВОЙ страницы по
// конфигурации (позиция-якорь tl/tr/bl/br/c + смещения в пунктах PDF, размер,
// цвет, рамка). Это «дублирование маркировки на фронте», когда бэкенд не
// вжигает штампы в сам PDF (baked=false). Смещения в пунктах переводятся в
// пиксели через масштаб отрисованной страницы.
export default function DocumentViewer({ documentId, marking, stamps = [] }) {
  const [error, setError] = useState('')
  const [numPages, setNumPages] = useState(0)
  const [zoom, setZoom] = useState(1) // множитель к базовому «вписать по ширине»
  const [fullscreen, setFullscreen] = useState(false)
  // Геометрия первой страницы для позиционирования overlay-штампов.
  const [page1, setPage1] = useState(null) // { left, top, width, height, pxPerPt }
  const containerRef = useRef(null)
  const pdfRef = useRef(null)

  const renderAll = useCallback(async (pdf, zoomLevel) => {
    const container = containerRef.current
    if (!container) return
    container.innerHTML = ''
    const width = container.clientWidth || 800
    let firstGeom = null

    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n)
      const unscaled = page.getViewport({ scale: 1 })
      const baseScale = (width - 24) / unscaled.width
      const viewport = page.getViewport({ scale: baseScale * zoomLevel })

      // Обёртка страницы (position:relative) — под canvas и текстовый слой.
      const pageWrap = document.createElement('div')
      pageWrap.className = 'relative mx-auto mb-3'
      pageWrap.style.width = `${viewport.width}px`
      pageWrap.style.height = `${viewport.height}px`
      container.appendChild(pageWrap)

      const canvas = document.createElement('canvas')
      canvas.width = viewport.width
      canvas.height = viewport.height
      canvas.className = 'shadow rounded block'
      const ctx = canvas.getContext('2d')
      pageWrap.appendChild(canvas)
      await page.render({ canvasContext: ctx, viewport }).promise

      // #5 — Текстовый слой поверх canvas: делает текст ВЫДЕЛЯЕМЫМ и КОПИРУЕМЫМ
      // (Ctrl+C), не давая при этом скачать файл. Скачивание/печать по-прежнему
      // недоступны (нет тулбара браузера, печать страницы скрыта).
      try {
        const textContent = await page.getTextContent()
        const textLayerDiv = document.createElement('div')
        textLayerDiv.className = 'sed-text-layer'
        textLayerDiv.style.width = `${viewport.width}px`
        textLayerDiv.style.height = `${viewport.height}px`
        pageWrap.appendChild(textLayerDiv)
        if (typeof pdfjsLib.renderTextLayer === 'function') {
          await pdfjsLib.renderTextLayer({
            textContentSource: textContent,
            container: textLayerDiv,
            viewport,
            textDivs: [],
          }).promise
        } else if (pdfjsLib.TextLayer) {
          const tl = new pdfjsLib.TextLayer({ textContentSource: textContent, container: textLayerDiv, viewport })
          await tl.render()
        }
      } catch (_) {
        /* текстовый слой не критичен для просмотра */
      }

      if (n === 1) {
        firstGeom = {
          left: pageWrap.offsetLeft,
          top: pageWrap.offsetTop,
          width: viewport.width,
          height: viewport.height,
          pxPerPt: viewport.width / unscaled.width,
        }
      }
    }
    setPage1(firstGeom)
  }, [])

  useEffect(() => {
    let cancelled = false
    setError('')
    setNumPages(0)
    setPage1(null)

    api
      .getDocumentFileBlob(documentId)
      .then(async (blob) => {
        if (cancelled) return
        try {
          const buf = await blob.arrayBuffer()
          // #8 — опции совместимости: не полагаемся на eval, используем
          // системные шрифты, не глушим font-face — так рендер устойчивее в
          // разных браузерах.
          const pdf = await pdfjsLib.getDocument({
            data: buf,
            isEvalSupported: false,
            useSystemFonts: true,
            disableFontFace: false,
          }).promise
          if (cancelled) return
          pdfRef.current = pdf
          setNumPages(pdf.numPages)
          await renderAll(pdf, zoom)
        } catch (renderErr) {
          // #8 — НИКАКОГО нативного браузерного просмотрщика в запасе: он даёт
          // панель со скачиванием/печатью и может показать файл без наших
          // штампов. Если pdf.js не смог отрисовать — показываем ошибку.
          if (!cancelled) {
            console.warn('pdf.js render failed:', renderErr)
            setError('Не удалось отобразить документ в защищённом просмотрщике. Обновите браузер до актуальной версии.')
          }
        }
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || 'Не удалось загрузить файл')
      })

    return () => {
      cancelled = true
      if (pdfRef.current) {
        pdfRef.current.destroy?.()
        pdfRef.current = null
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documentId])

  // Перерисовка при смене зума/фуллскрина (документ уже загружен).
  useEffect(() => {
    if (pdfRef.current) renderAll(pdfRef.current, zoom)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zoom, fullscreen])

  const zoomIn = () => setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)))
  const zoomOut = () => setZoom((z) => Math.max(0.5, +(z - 0.25).toFixed(2)))
  const zoomReset = () => setZoom(1)

  const wrapClass = fullscreen
    ? 'fixed inset-0 z-50 bg-surface-alt flex flex-col'
    : 'relative h-full bg-surface-alt border border-border rounded-lg flex flex-col'

  // Позиционирование одного штампа по якорю + смещениям (в пунктах → px).
  const stampStyle = (s) => {
    if (!page1) return { display: 'none' }
    const pp = page1.pxPerPt
    const ax = Math.abs((s.offset_x || 0) * pp)
    const ay = Math.abs((s.offset_y || 0) * pp)
    const borderColor = s.border_color || s.color || '#000'
    // Заливка: явный fill приоритетнее; иначе под рамкой — лёгкий фон, без рамки — прозрачно.
    const bg = s.fill
      ? s.fill
      : (s.border ? 'color-mix(in srgb, var(--color-surface) 78%, transparent)' : 'transparent')
    const base = {
      position: 'absolute',
      maxWidth: `${page1.width * 0.6}px`,
      fontSize: `${Math.max(8, (s.font_size || 9) * pp)}px`,
      lineHeight: 1.25,
      color: s.color || '#000',
      pointerEvents: 'none',
      padding: (s.border || s.fill) ? '3px 6px' : 0,
      border: s.border ? `1px solid ${borderColor}` : 'none',
      borderRadius: (s.border || s.fill) ? '3px' : 0,
      background: bg,
      fontWeight: 600,
    }
    switch (s.position) {
      case 'tl': return { ...base, left: ax, top: ay }
      case 'tr': return { ...base, right: ax, top: ay }
      case 'bl': return { ...base, left: ax, bottom: ay }
      case 'br': return { ...base, right: ax, bottom: ay }
      case 'c':  return { ...base, left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }
      default:   return { ...base, right: ax, bottom: ay }
    }
  }

  // Содержимое штампа: если есть изображение — две колонки (картинка | текст),
  // иначе просто текст.
  const StampBody = ({ s }) => {
    if (s.image) {
      const imgH = Math.max(28, (s.font_size || 9) * (page1?.pxPerPt || 1) * 4)
      return (
        <div className="flex items-center gap-2">
          <img src={s.image} alt="" style={{ height: imgH, width: 'auto', objectFit: 'contain' }} />
          <div style={{ whiteSpace: 'pre-line' }}>{s.text}</div>
        </div>
      )
    }
    return <div style={{ whiteSpace: 'pre-line' }}>{s.text}</div>
  }

  return (
    <div className={wrapClass + ' sed-secure-viewer'} onContextMenu={(e) => e.preventDefault()}>
      {/* #8 — При попытке печати страницы браузером (Ctrl+P) скрываем документ:
          скачивание/печать средствами браузера не должны обходить маркировку и
          контроль экземпляров. Легитимная печать — только через вкладку
          «Печать» (маркированный файл под учётом). */}
      <style>{`
        @media print { .sed-secure-viewer { display: none !important; } }
        .sed-text-layer { position:absolute; left:0; top:0; overflow:hidden; line-height:1;
          opacity:1; z-index:2; }
        .sed-text-layer span, .sed-text-layer br { color:transparent; position:absolute;
          white-space:pre; cursor:text; transform-origin:0% 0%; }
        .sed-text-layer ::selection { background: rgba(0,120,255,0.35); }
      `}</style>
      {/* Панель управления просмотром (масштаб, полный экран) */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-surface/80 shrink-0">
        <button onClick={zoomOut} className="px-2 py-0.5 rounded hover:bg-surface-alt text-sm" title="Уменьшить">
          −
        </button>
        <span className="text-xs text-text-secondary w-12 text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={zoomIn} className="px-2 py-0.5 rounded hover:bg-surface-alt text-sm" title="Увеличить">
          +
        </button>
        <button onClick={zoomReset} className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs" title="Сбросить масштаб">
          100%
        </button>
        <div className="flex-1" />
        <button
          onClick={() => setFullscreen((v) => !v)}
          className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs"
          title={fullscreen ? 'Свернуть' : 'Во весь экран'}
        >
          {fullscreen ? '✕ Свернуть' : '⛶ Во весь экран'}
        </button>
      </div>

      <div className="relative flex-1 overflow-auto">
        {error && <div className="p-4 text-danger text-sm">{error}</div>}
        {!error && numPages === 0 && <div className="p-4 text-text-secondary text-sm">Загрузка документа…</div>}

        {/* Обёртка нужна как контейнер позиционирования overlay-штампов. */}
        {!error && (
        <div className="relative p-3">
          <div ref={containerRef} />
          {/* Overlay-маркировка поверх первой страницы (по конфигурации). */}
          {page1 && stamps && stamps.length > 0 && (
            <div
              className="absolute pointer-events-none"
              style={{
                left: page1.left + 12, // +12 компенсирует p-3 обёртки
                top: page1.top + 12,
                width: page1.width,
                height: page1.height,
              }}
            >
              {stamps.map((s, i) => (
                <div key={i} style={stampStyle(s)}><StampBody s={s} /></div>
              ))}
            </div>
          )}
        </div>
        )}

        {/* Старый текстовый бейдж (входящий/архив) — оставлен как доп. подсказка. */}
        {marking && (!stamps || stamps.length === 0) && (
          <div className="absolute top-2 right-2 bg-surface/90 border border-border rounded-md px-2 py-1 text-[11px] text-text-secondary pointer-events-none max-w-[60%] text-right leading-tight whitespace-pre-line">
            {marking}
          </div>
        )}
      </div>
    </div>
  )
}
