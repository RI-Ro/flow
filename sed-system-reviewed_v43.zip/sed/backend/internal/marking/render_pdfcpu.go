package marking

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"

	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"
	xfont "golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"

	"sed-system/backend/internal/config"
)

// ВЖИГАНИЕ ШТАМПОВ (#5). pdfcpu TextWatermark в этой сборке ОТКАЗЫВАЕТСЯ
// использовать пользовательский кириллический шрифт («LiberationSans
// unsupported»), поэтому векторный текст с кириллицей невозможен. Надёжное
// решение: рисуем ОДИН прозрачный слой РАЗМЕРОМ СО СТРАНИЦУ, на нём — все штампы
// нашим TTF (кириллица гарантирована) в точных координатах (как overlay в
// браузере: угол рамки на заданном отступе от края), и накладываем слой на PDF
// по центру в масштабе 1:1. Так позиционирование точное и не зависит от того,
// как pdfcpu центрирует/масштабирует картинку.

var (
	fontOnce sync.Once
	sfntFont *opentype.Font
)

var mediaBoxRe = regexp.MustCompile(`/MediaBox\s*\[\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\]`)

func Configure(cfg config.MarkingConfig) {
	fontOnce.Do(func() {
		if cfg.FontFile == "" {
			log.Printf("marking: TTF-шрифт не задан (marking.font_file) — вжигание недоступно")
			return
		}
		data, err := os.ReadFile(cfg.FontFile)
		if err != nil {
			log.Printf("marking: не удалось прочитать шрифт %s: %v", cfg.FontFile, err)
			return
		}
		f, err := opentype.Parse(data)
		if err != nil {
			log.Printf("marking: не удалось разобрать шрифт %s: %v", cfg.FontFile, err)
			return
		}
		sfntFont = f
		log.Printf("marking: шрифт %s готов для вжигания штампов", filepath.Base(cfg.FontFile))
	})
	RenderHook = renderWithPDFCPU
}

func renderWithPDFCPU(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 {
		return original, nil
	}
	if sfntFont == nil {
		return original, fmt.Errorf("шрифт для вжигания не сконфигурирован (marking.font_file)")
	}

	// Размер страницы (в пунктах) из первого MediaBox; фолбэк — A4 портрет.
	pw, ph := 595.28, 841.89
	if m := mediaBoxRe.FindSubmatch(original); m != nil {
		x0, _ := strconv.ParseFloat(string(m[1]), 64)
		y0, _ := strconv.ParseFloat(string(m[2]), 64)
		x1, _ := strconv.ParseFloat(string(m[3]), 64)
		y1, _ := strconv.ParseFloat(string(m[4]), 64)
		if x1-x0 > 10 && y1-y0 > 10 {
			pw, ph = x1-x0, y1-y0
		}
	}

	overlayPNG, err := renderPageOverlay(specs, int(pw+0.5), int(ph+0.5))
	if err != nil {
		return original, fmt.Errorf("render stamps overlay: %w", err)
	}

	tmpDir, err := os.MkdirTemp("", "sed-stamp-")
	if err != nil {
		return original, err
	}
	defer os.RemoveAll(tmpDir)
	imgPath := filepath.Join(tmpDir, "overlay.png")
	if err := os.WriteFile(imgPath, overlayPNG, 0o600); err != nil {
		return original, err
	}

	// Полностраничный слой накладываем по центру в масштабе 1:1.
	desc := "pos:c, offset:0 0, scalefactor:1.0 abs, rotation:0"
	wm, err := api.ImageWatermark(imgPath, desc, true /*onTop*/, false /*update*/, types.POINTS)
	if err != nil {
		return original, fmt.Errorf("build image watermark: %w", err)
	}
	var out bytes.Buffer
	if err := api.AddWatermarks(bytes.NewReader(original), &out, []string{"1"}, wm, nil); err != nil {
		return original, fmt.Errorf("apply overlay: %w", err)
	}
	return out.Bytes(), nil
}

// renderPageOverlay рисует все штампы на прозрачном слое размером со страницу.
// Координаты как в overlay браузера: угол рамки штампа отстоит на (ax, ay) от
// названного угла страницы ВНУТРЬ (ay — вниз для верхних якорей).
func renderPageOverlay(specs []Spec, pageW, pageH int) ([]byte, error) {
	if pageW < 1 || pageH < 1 {
		return nil, fmt.Errorf("bad page size")
	}
	img := image.NewRGBA(image.Rect(0, 0, pageW, pageH)) // прозрачный
	for _, s := range specs {
		if err := drawStamp(img, s, pageW, pageH); err != nil {
			log.Printf("marking: штамп %q пропущен: %v", s.Text, err)
		}
	}
	var out bytes.Buffer
	if err := png.Encode(&out, img); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}

func drawStamp(img *image.RGBA, s Spec, pageW, pageH int) error {
	const padX, padY, border = 6, 4, 1
	fsize := float64(s.FontSize)
	if fsize <= 0 {
		fsize = 9
	}
	face, err := opentype.NewFace(sfntFont, &opentype.FaceOptions{Size: fsize, DPI: 72, Hinting: xfont.HintingFull})
	if err != nil {
		return err
	}
	defer face.Close()
	m := face.Metrics()
	ascent, descent := m.Ascent.Ceil(), m.Descent.Ceil()
	lineH := ascent + descent + 2

	lines := strings.Split(s.Text, "\n")
	maxW := 0
	for _, ln := range lines {
		if w := xfont.MeasureString(face, ln).Ceil(); w > maxW {
			maxW = w
		}
	}
	boxW := maxW + 2*padX + 2*border
	boxH := lineH*len(lines) + 2*padY + 2*border

	ax := absInt(int(s.OffsetX))
	ay := absInt(int(s.OffsetY))
	// Левый-верхний угол рамки на странице.
	var x0, y0 int
	switch s.Position {
	case "tl":
		x0, y0 = ax, ay
	case "tr":
		x0, y0 = pageW-ax-boxW, ay
	case "bl":
		x0, y0 = ax, pageH-ay-boxH
	case "br":
		x0, y0 = pageW-ax-boxW, pageH-ay-boxH
	case "c":
		x0, y0 = (pageW-boxW)/2, (pageH-boxH)/2
	default:
		x0, y0 = pageW-ax-boxW, pageH-ay-boxH
	}

	// Фон (по умолчанию непрозрачный белый — как карточка overlay).
	bg := color.RGBA{255, 255, 255, 255}
	if c, ok := parseHex(s.FillColorHex); ok {
		bg = c
	}
	fillRect(img, x0, y0, x0+boxW, y0+boxH, bg)

	textColor := color.RGBA{0, 0, 0, 255}
	if c, ok := parseHex(s.ColorHex); ok {
		textColor = c
	}
	if s.Border {
		bc := textColor
		if c, ok := parseHex(s.BorderColorHex); ok {
			bc = c
		}
		strokeRect(img, x0, y0, x0+boxW, y0+boxH, border, bc)
	}

	d := &xfont.Drawer{Dst: img, Src: &image.Uniform{textColor}, Face: face}
	for i, ln := range lines {
		baseline := y0 + border + padY + ascent + i*lineH
		d.Dot = fixed.P(x0+border+padX, baseline)
		d.DrawString(ln)
	}
	return nil
}

func fillRect(img *image.RGBA, x0, y0, x1, y1 int, c color.RGBA) {
	if x0 < 0 {
		x0 = 0
	}
	if y0 < 0 {
		y0 = 0
	}
	if x1 > img.Bounds().Dx() {
		x1 = img.Bounds().Dx()
	}
	if y1 > img.Bounds().Dy() {
		y1 = img.Bounds().Dy()
	}
	draw.Draw(img, image.Rect(x0, y0, x1, y1), &image.Uniform{c}, image.Point{}, draw.Src)
}

func strokeRect(img *image.RGBA, x0, y0, x1, y1, t int, c color.RGBA) {
	for i := 0; i < t; i++ {
		for x := x0; x < x1; x++ {
			img.SetRGBA(x, y0+i, c)
			img.SetRGBA(x, y1-1-i, c)
		}
		for y := y0; y < y1; y++ {
			img.SetRGBA(x0+i, y, c)
			img.SetRGBA(x1-1-i, y, c)
		}
	}
}

func parseHex(h string) (color.RGBA, bool) {
	h = strings.TrimSpace(h)
	if len(h) == 7 && h[0] == '#' {
		var r, g, b int
		if _, err := fmt.Sscanf(h, "#%02x%02x%02x", &r, &g, &b); err == nil {
			return color.RGBA{uint8(r), uint8(g), uint8(b), 255}, true
		}
	}
	return color.RGBA{}, false
}

func absInt(v int) int {
	if v < 0 {
		return -v
	}
	return v
}
