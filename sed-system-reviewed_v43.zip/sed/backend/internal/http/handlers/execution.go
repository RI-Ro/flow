package handlers

import (
	"strings"
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

type ExecutionHandler struct {
	pool *pgxpool.Pool
	exec *service.ExecutionService
	hub  *ws.Hub
}

func NewExecutionHandler(pool *pgxpool.Pool, exec *service.ExecutionService, hub *ws.Hub) *ExecutionHandler {
	return &ExecutionHandler{pool: pool, exec: exec, hub: hub}
}

type completeRequest struct {
	Note string `json:"note"`
}

// Complete POST /api/documents/:id/complete — получатель отмечает исполнение
// своей части. Когда отметились все получатели, документ -> executed.
func (h *ExecutionHandler) Complete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор документа")
	}
	var req completeRequest
	_ = c.BodyParser(&req)
	// #6 — отчёт о выполнении обязателен.
	if strings.TrimSpace(req.Note) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите отчёт о выполнении (обязательное поле)")
	}

	var becameExecuted bool
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		b, err := h.exec.MarkCompleted(c.Context(), tx, docID, userID, req.Note)
		if err != nil {
			return err
		}
		becameExecuted = b
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrNotRecipient):
			return fiber.NewError(fiber.StatusForbidden, "вы не являетесь получателем этого документа")
		case errors.Is(txErr, service.ErrAlreadyDone):
			return fiber.NewError(fiber.StatusConflict, "отметка об исполнении уже проставлена")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		default:
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить исполнение")
		}
	}
	return c.JSON(fiber.Map{"executed": becameExecuted})
}

