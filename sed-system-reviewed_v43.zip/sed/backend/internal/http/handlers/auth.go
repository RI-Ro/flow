package handlers

import (
	"errors"
	"log"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
)

type AuthHandler struct {
	pool *pgxpool.Pool
	auth *service.AuthService
}

func NewAuthHandler(pool *pgxpool.Pool, auth *service.AuthService) *AuthHandler {
	return &AuthHandler{pool: pool, auth: auth}
}

type loginRequest struct {
	Login    string `json:"login"`
	Password string `json:"password"`
}

func (h *AuthHandler) Login(c *fiber.Ctx) error {
	var req loginRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.Login == "" || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "login and password required")
	}

	ctx := c.Context()
	tx, err := h.pool.Begin(ctx)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "db error")
	}
	defer tx.Rollback(ctx)

	userID, login, isAdmin, err := h.auth.Login(ctx, tx, req.Login, req.Password)
	if err != nil {
		if errors.Is(err, service.ErrInvalidCredentials) {
			return fiber.NewError(fiber.StatusUnauthorized, "неверный логин или пароль")
		}
		// Реальная причина (SQL/схема) уходит в лог сервера, клиенту — общий
		// текст. Без этого лога 500 на логине невозможно диагностировать.
		log.Printf("auth login failed for %q: %v", req.Login, err)
		return fiber.NewError(fiber.StatusInternalServerError, "auth error")
	}
	if err := tx.Commit(ctx); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "db error")
	}

	token, err := h.auth.IssueToken(userID, login, isAdmin)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "token error")
	}

	return c.JSON(fiber.Map{
		"token":   token,
		"user_id": userID,
		"login":   login,
	})
}

// Me GET /api/me — текущий пользователь и его роли (для гейтинга UI: кнопки
// «Новый документ» и т.п. показываются только при наличии соответствующей роли).
func (h *AuthHandler) Me(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)

	var roles []string
	var fullName, position string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT coalesce(full_name,''), coalesce(position,'') FROM users WHERE id=$1`, userID).Scan(&fullName, &position); e != nil {
			return e
		}
		rows, err := tx.Query(c.Context(), `SELECT DISTINCT role::text FROM user_roles WHERE user_id=$1`, userID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r string
			if err := rows.Scan(&r); err != nil {
				return err
			}
			roles = append(roles, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить профиль")
	}
	if roles == nil {
		roles = []string{}
	}
	return c.JSON(fiber.Map{
		"user_id": userID, "login": login, "full_name": fullName, "position": position,
		"is_admin": isAdmin, "roles": roles,
		// Производные флаги для удобства фронта.
		"can_create": isAdmin || contains(roles, "author"),
	})
}

func contains(ss []string, v string) bool {
	for _, s := range ss {
		if s == v {
			return true
		}
	}
	return false
}
// ТЕКУЩИЙ токен ещё валиден (эндпоинт под JWTAuth). Фронт вызывает его
// проактивно, поэтому активная сессия не «протухает» на ровном месте, а на
// истёкшем токене клиент уходит на вход (401 обрабатывается на фронте).
func (h *AuthHandler) Refresh(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	token, err := h.auth.IssueToken(userID, login, isAdmin)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "token error")
	}
	return c.JSON(fiber.Map{"token": token, "user_id": userID, "login": login})
}
