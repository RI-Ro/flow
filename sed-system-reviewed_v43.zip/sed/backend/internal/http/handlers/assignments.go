package handlers

import (
	"fmt"
	"errors"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

var errForbiddenAssign = errors.New("forbidden assign")
var errForbiddenAcquaint = errors.New("forbidden acquaint")

// AssignmentsHandler — поручения (резолюции) по документу.
type AssignmentsHandler struct {
	pool *pgxpool.Pool
	hub  *ws.Hub
}

func NewAssignmentsHandler(pool *pgxpool.Pool, hub *ws.Hub) *AssignmentsHandler {
	return &AssignmentsHandler{pool: pool, hub: hub}
}

type assignmentRow struct {
	ID           int64   `json:"id"`
	AuthorName   string  `json:"author_name"`
	AuthorID     int64   `json:"author_id"`
	AssigneeID   int64   `json:"assignee_id"`
	AssigneeName string  `json:"assignee_name"`
	Text         string  `json:"text"`
	DueDate      *string `json:"due_date,omitempty"`
	Status       string  `json:"status"`
	ResultNote   *string `json:"result_note,omitempty"`
	CreatedAt    string  `json:"created_at"`
	CompletedAt  *string `json:"completed_at,omitempty"`
	CompletedBy  *string `json:"completed_by_name,omitempty"`
}

// List GET /api/documents/:id/assignments
func (h *AssignmentsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var items []assignmentRow
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Доступ к документу проверяется RLS через выборку самого документа.
		var ok bool
		if err := tx.QueryRow(c.Context(), `SELECT EXISTS(SELECT 1 FROM documents WHERE id=$1)`, docID).Scan(&ok); err != nil {
			return err
		}
		if !ok {
			return pgx.ErrNoRows
		}
		rows, err := tx.Query(c.Context(), `
			SELECT a.id, au.full_name, a.author_id, a.assignee_id, asg.full_name, a.text,
			       to_char(a.due_date,'YYYY-MM-DD'), a.status, a.result_note,
			       to_char(a.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(a.completed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       cb.full_name
			FROM assignments a
			JOIN users au ON au.id = a.author_id
			JOIN users asg ON asg.id = a.assignee_id
			LEFT JOIN users cb ON cb.id = a.completed_by
			WHERE a.document_id = $1
			ORDER BY a.created_at`, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r assignmentRow
			if err := rows.Scan(&r.ID, &r.AuthorName, &r.AuthorID, &r.AssigneeID, &r.AssigneeName, &r.Text,
				&r.DueDate, &r.Status, &r.ResultNote, &r.CreatedAt, &r.CompletedAt, &r.CompletedBy); err != nil {
				return err
			}
			items = append(items, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить поручения")
	}
	return c.JSON(fiber.Map{"items": items})
}

type createAssignmentRequest struct {
	AssigneeID   int64  `json:"assignee_id"`
	ControllerID int64  `json:"controller_id"`
	Text         string `json:"text"`
	DueDate      string `json:"due_date"`
}

// Create POST /api/documents/:id/assignments — дать поручение. Ответственному
// открывается доступ к документу (грант) и шлётся уведомление.
func (h *AssignmentsHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req createAssignmentRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.AssigneeID == 0 || req.Text == "" {
		return fiber.NewError(fiber.StatusBadRequest, "ответственный и текст обязательны")
	}

	var newID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Право поручать: автор/подписант — кому угодно; остальные — только в
		// своём подразделении и вниз по иерархии (включая ознакомленных ими).
		if !isAdmin {
			allowed, err := service.CanAssignTo(c.Context(), tx, docID, userID, req.AssigneeID)
			if err != nil {
				return err
			}
			if !allowed {
				// Дополнительно разрешаем поручать тем, кого этот пользователь
				// ознакомил с документом (дежурный/канцелярия).
				var acq bool
				if err := tx.QueryRow(c.Context(), `
					SELECT EXISTS(SELECT 1 FROM document_acquaintances
						WHERE document_id=$1 AND user_id=$2 AND acquainted_by=$3)`,
					docID, req.AssigneeID, userID).Scan(&acq); err != nil {
					return err
				}
				if !acq {
					return errForbiddenAssign
				}
			}
		}
		var dueDate *string
		if req.DueDate != "" {
			dueDate = &req.DueDate
		}
		var controllerID *int64
		if req.ControllerID != 0 {
			controllerID = &req.ControllerID
		}
		if err := tx.QueryRow(c.Context(), `
			INSERT INTO assignments (document_id, author_id, assignee_id, controller_id, text, due_date, status)
			VALUES ($1, $2, $3, $4, $5, $6::date, 'in_progress')
			RETURNING id`, docID, userID, req.AssigneeID, controllerID, req.Text, dueDate).Scan(&newID); err != nil {
			return err
		}
		// Доступ ответственному к документу (переиспользуем document_access).
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_access (document_id, user_id, access_reason)
			VALUES ($1, $2, 'executor') ON CONFLICT DO NOTHING`, docID, req.AssigneeID); err != nil {
			return err
		}
		// Авто-ознакомление: если ответственный ещё не ознакомлен — заводим
		// запись ознакомления (документ становится ему «открыт» и попадает в
		// его список ознакомления). acquainted_by = автор поручения.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_acquaintances (document_id, user_id, acquainted_by)
			VALUES ($1, $2, $3) ON CONFLICT (document_id, user_id) DO NOTHING`,
			docID, req.AssigneeID, userID); err != nil {
			return err
		}
		// Уведомление ответственному.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO notifications (user_id, document_id, kind, payload)
			VALUES ($1, $2, 'assignment', '{}')`, req.AssigneeID, docID); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		if txErr == errForbiddenAssign {
			return fiber.NewError(fiber.StatusForbidden, "вы можете давать поручения только сотрудникам своего подразделения и ниже по иерархии")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать поручение")
	}
	h.hub.NotifyUsers([]int64{req.AssigneeID}, docID, "assignment")
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID})
}

type updateAssignmentRequest struct {
	Status     string `json:"status"`
	ResultNote string `json:"result_note"`
}

// Update PATCH /api/assignments/:id — сменить статус/добавить результат.
// Менять может ответственный, автор поручения или контролёр.
func (h *AssignmentsHandler) Update(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	aID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req updateAssignmentRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	valid := map[string]bool{"open": true, "in_progress": true, "done": true, "cancelled": true}
	if !valid[req.Status] {
		return fiber.NewError(fiber.StatusBadRequest, "некорректный статус")
	}

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID, assigneeID, documentID int64
		var oldStatus string
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, assignee_id, document_id, status FROM assignments WHERE id=$1`, aID).
			Scan(&authorID, &assigneeID, &documentID, &oldStatus); err != nil {
			return err
		}
		// Статус поручения может менять ТОЛЬКО автор поручения или исполнитель.
		allowed := isAdmin || userID == authorID || userID == assigneeID
		if !allowed {
			return errForbidden
		}
		// #4 — При переводе в «выполнено» комментарий о результате ОБЯЗАТЕЛЕН,
		// фиксируем КТО (completed_by) и КОГДА (completed_at) выполнил.
		if req.Status == "done" && strings.TrimSpace(req.ResultNote) == "" {
			return errResultNoteRequired
		}
		if req.Status == "done" {
			if _, err := tx.Exec(c.Context(), `
				UPDATE assignments SET status='done', result_note=$1, completed_at=now(), completed_by=$2
				WHERE id=$3`, req.ResultNote, userID, aID); err != nil {
				return err
			}
		} else {
			// Не «выполнено» — снимаем отметку исполнения (в т.ч. при возврате
			// в работу/отмене), результат сохраняем, если передан.
			if _, err := tx.Exec(c.Context(), `
				UPDATE assignments SET status=$1, result_note=NULLIF($2,''), completed_at=NULL, completed_by=NULL
				WHERE id=$3`, req.Status, req.ResultNote, aID); err != nil {
				return err
			}
		}
		// Фиксация факта изменения статуса: кто, когда, старое→новое значение.
		if oldStatus != req.Status {
			histComment := fmt.Sprintf("поручение #%d: %s → %s", aID, statusLabelAssign(oldStatus), statusLabelAssign(req.Status))
			if req.Status == "done" && strings.TrimSpace(req.ResultNote) != "" {
				histComment += ". Результат: " + req.ResultNote
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_history (document_id, actor_id, event_type, comment)
				VALUES ($1, $2, 'assignment_status_changed', $3)`,
				documentID, userID, histComment); err != nil {
				return err
			}
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errResultNoteRequired) {
			return fiber.NewError(fiber.StatusBadRequest, "укажите комментарий о результате выполнения поручения")
		}
		if errors.Is(txErr, errForbidden) {
			return fiber.NewError(fiber.StatusForbidden, "изменять статус поручения может только его автор или исполнитель")
		}
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "поручение не найдено")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось обновить поручение")
	}
	return c.SendStatus(fiber.StatusOK)
}

var errForbidden = errors.New("forbidden")
var errResultNoteRequired = errors.New("result note required")
var errControllerRole = errors.New("controller must have controller role")
var errArchiveForbidden = errors.New("archive forbidden")
var errNotExecuted = errors.New("not executed")
var errAlreadyArchived = errors.New("already archived")
var errAssignmentLocked = errors.New("assignment locked (done)")

// statusLabelAssign — человекочитаемая подпись статуса поручения (для истории).
func statusLabelAssign(s string) string {
	switch s {
	case "open":
		return "Открыто"
	case "in_progress":
		return "В работе"
	case "done":
		return "Выполнено"
	case "cancelled":
		return "Отменено"
	}
	return s
}

// Edit PUT /api/assignments/:id — изменить текст и срок поручения.
// #8 — Право: автор поручения или исполнитель. Запрещено после статуса done.
func (h *AssignmentsHandler) Edit(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	aID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Text    string `json:"text"`
		DueDate string `json:"due_date"`
	}
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Text) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите текст поручения")
	}
	var dueDate any
	if req.DueDate != "" {
		dueDate = req.DueDate
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID, assigneeID, documentID int64
		var status string
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, assignee_id, document_id, status FROM assignments WHERE id=$1`, aID).
			Scan(&authorID, &assigneeID, &documentID, &status); err != nil {
			return err
		}
		if !isAdmin && userID != authorID {
			return errForbidden
		}
		if status == "done" {
			return errAssignmentLocked
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE assignments SET text=$1, due_date=$2::date WHERE id=$3`, req.Text, dueDate, aID); err != nil {
			return err
		}
		_, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'assignment_status_changed', $3)`,
			documentID, userID, fmt.Sprintf("поручение #%d изменено", aID))
		return err
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errForbidden):
			return fiber.NewError(fiber.StatusForbidden, "изменять поручение может только тот, кто его дал")
		case errors.Is(txErr, errAssignmentLocked):
			return fiber.NewError(fiber.StatusConflict, "выполненное поручение изменить нельзя")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "поручение не найдено")
		default:
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить поручение")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/assignments/:id — удалить поручение.
// #8 — Право: автор поручения или исполнитель. Запрещено после статуса done.
func (h *AssignmentsHandler) Delete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	aID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID, assigneeID, documentID int64
		var status string
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, assignee_id, document_id, status FROM assignments WHERE id=$1`, aID).
			Scan(&authorID, &assigneeID, &documentID, &status); err != nil {
			return err
		}
		if !isAdmin && userID != authorID {
			return errForbidden
		}
		if status == "done" {
			return errAssignmentLocked
		}
		if _, err := tx.Exec(c.Context(), `DELETE FROM assignments WHERE id=$1`, aID); err != nil {
			return err
		}
		_, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'assignment_status_changed', $3)`,
			documentID, userID, fmt.Sprintf("поручение #%d удалено", aID))
		return err
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errForbidden):
			return fiber.NewError(fiber.StatusForbidden, "удалять поручение может только тот, кто его дал")
		case errors.Is(txErr, errAssignmentLocked):
			return fiber.NewError(fiber.StatusConflict, "выполненное поручение удалить нельзя")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "поручение не найдено")
		default:
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить поручение")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}
