package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

type NotificationsHandler struct {
	pool *pgxpool.Pool
}

func NewNotificationsHandler(pool *pgxpool.Pool) *NotificationsHandler {
	return &NotificationsHandler{pool: pool}
}

// List GET /api/notifications?only_unread=false&limit=50 — центр уведомлений.
// Возвращает уведомления текущего пользователя (RLS notifications_select уже
// ограничивает выборку своими), новые сверху, с флагом is_read — так центр
// показывает и непрочитанные, и прочитанные (по требованию "с возможностью
// просмотра прочитанных").
func (h *NotificationsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	onlyUnread := c.Query("only_unread") == "true"
	limit := 50
	if v := c.Query("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 200 {
			limit = n
		}
	}

	type item struct {
		ID         int64   `json:"id"`
		Kind       string  `json:"kind"`
		DocumentID *int64  `json:"document_id,omitempty"`
		DocTitle   *string `json:"document_title,omitempty"`
		IsRead     bool    `json:"is_read"`
		CreatedAt  string  `json:"created_at"`
	}
	var items []item
	var unreadCount int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM notifications WHERE user_id=$1 AND is_read=false`, userID).Scan(&unreadCount); err != nil {
			return err
		}
		q := `
			SELECT n.id, n.kind, n.document_id, d.title, n.is_read,
			       to_char(n.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM notifications n
			LEFT JOIN documents d ON d.id = n.document_id
			WHERE n.user_id = $1`
		if onlyUnread {
			q += ` AND n.is_read = false`
		}
		q += ` ORDER BY n.created_at DESC LIMIT $2`
		rows, err := tx.Query(c.Context(), q, userID, limit)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it item
			if err := rows.Scan(&it.ID, &it.Kind, &it.DocumentID, &it.DocTitle, &it.IsRead, &it.CreatedAt); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить уведомления")
	}
	return c.JSON(fiber.Map{"items": items, "unread_count": unreadCount})
}

// MarkRead POST /api/notifications/:id/read — отметить одно прочитанным.
func (h *NotificationsHandler) MarkRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// RLS notifications_update гарантирует, что пометить можно только своё.
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2`, id, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить прочитанным")
	}
	return c.SendStatus(fiber.StatusOK)
}

// MarkAllRead POST /api/notifications/read-all — отметить все прочитанными.
func (h *NotificationsHandler) MarkAllRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false`, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить все прочитанными")
	}
	return c.SendStatus(fiber.StatusOK)
}
