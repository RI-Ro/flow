package handlers

import (
	"fmt"
	"strings"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

// AcquaintanceHandler — ознакомление сотрудников с документом. По ТЗ: документ
// направлен дежурному/канцелярии, а они могут ОЗНАКОМИТЬ пользователей из
// административно заданных им подразделений (user_acquaint_departments). Этим
// же пользователям можно давать поручения (см. assignments.CanAssignTo +
// document_acquaintances).
type AcquaintanceHandler struct {
	pool *pgxpool.Pool
	hub  *ws.Hub
}

func NewAcquaintanceHandler(pool *pgxpool.Pool, hub *ws.Hub) *AcquaintanceHandler {
	return &AcquaintanceHandler{pool: pool, hub: hub}
}

// Candidates GET /api/acquaint-candidates?q= — пользователи, которых текущий
// пользователь ВПРАВЕ ознакомить (из его user_acquaint_departments).
func (h *AcquaintanceHandler) Candidates(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	q := c.Query("q")
	docID, _ := strconv.ParseInt(c.Query("document_id"), 10, 64)
	type item struct {
		ID             int64  `json:"id"`
		FullName       string `json:"full_name"`
		DepartmentID   int64  `json:"department_id"`
		DepartmentName string `json:"department_name"`
	}
	var items []item
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			WITH RECURSIVE roots AS (
				SELECT department_id AS id FROM user_acquaint_departments WHERE user_id = $1
				UNION
				-- #6 — руководитель (chief) и дежурный/канцелярия (clerk)
				-- видят кандидатов своего поддерева.
				SELECT u.primary_department_id FROM users u
				WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
				  AND EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = $1 AND ur.role IN ('chief','clerk'))
			),
			subtree AS (
				SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
				UNION ALL
				SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
			)
			SELECT u.id, u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       u.primary_department_id, coalesce(d.name,'')
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.is_active = true AND u.id <> $1
			  AND u.primary_department_id IN (SELECT id FROM subtree)
			  AND u.full_name ILIKE '%' || $2 || '%'
			  -- #2 — исключаем тех, кто УЖЕ видит документ (автор, согласующий,
			  -- подписант, получатель, ознакомленный, контролёр и т.д. — у всех
			  -- есть строка document_access), чтобы не ознакамливать повторно.
			  AND ($3 = 0 OR NOT EXISTS (
			        SELECT 1 FROM document_access da WHERE da.document_id = $3 AND da.user_id = u.id))
			ORDER BY u.full_name
			LIMIT 30`, userID, q, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it item
			if err := rows.Scan(&it.ID, &it.FullName, &it.DepartmentID, &it.DepartmentName); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить кандидатов на ознакомление")
	}
	return c.JSON(fiber.Map{"items": items})
}

// List GET /api/documents/:id/acquaintances — кто ознакомлен.
func (h *AcquaintanceHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type item struct {
		UserID    int64  `json:"user_id"`
		FullName  string `json:"full_name"`
		ByName    string `json:"acquainted_by_name"`
		CreatedAt string `json:"created_at"`
	}
	var items []item
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT a.user_id, u.full_name, b.full_name,
			       to_char(a.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_acquaintances a
			JOIN users u ON u.id = a.user_id
			JOIN users b ON b.id = a.acquainted_by
			WHERE a.document_id = $1
			ORDER BY a.created_at`, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it item
			if err := rows.Scan(&it.UserID, &it.FullName, &it.ByName, &it.CreatedAt); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить ознакомления")
	}
	return c.JSON(fiber.Map{"items": items})
}

type acquaintRequest struct {
	UserIDs []int64 `json:"user_ids"`
}

// Create POST /api/documents/:id/acquaint — ознакомить пользователей.
// Права: актор должен быть получателем документа (дежурный/канцелярия) и
// каждый ознакамливаемый — из его user_acquaint_departments. Ознакомленному
// выдаётся доступ к документу и уведомление.
func (h *AcquaintanceHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req acquaintRequest
	if err := c.BodyParser(&req); err != nil || len(req.UserIDs) == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "нужно указать хотя бы одного пользователя")
	}
	var notified []int64
	var acquaintNames []string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// #7 — Ознакамливать вправе не только получатель рассылки: любой, кто
		// ИМЕЕТ ДОСТУП к документу (автор, согласующий, подписант, контролёр,
		// получатель, ознакомленный, руководитель по видимости и т.д.). КОГО
		// именно можно ознакомить — ограничивает CanAcquaint ниже (по правам).
		if !isAdmin {
			var hasAccess bool
			if err := tx.QueryRow(c.Context(), `
				SELECT EXISTS(SELECT 1 FROM document_access
					WHERE document_id=$1 AND user_id=$2)`,
				docID, userID).Scan(&hasAccess); err != nil {
				return err
			}
			if !hasAccess {
				return errForbiddenAcquaint
			}
		}
		for _, uid := range req.UserIDs {
			// Проверяем право ознакомить именно этого пользователя: своё
			// подразделение и ниже по иерархии ∪ заданные подразделения
			// ознакомления (та же логика, что и в выборке кандидатов).
			if !isAdmin {
				allowed, err := service.CanAcquaint(c.Context(), tx, userID, uid)
				if err != nil {
					return err
				}
				if !allowed {
					return errForbiddenAcquaint
				}
			}
			// #2 — Не ознакамливаем тех, кто УЖЕ видит документ (по любой
			// причине): если есть строка document_access — пропускаем.
			var alreadyHasAccess bool
			if err := tx.QueryRow(c.Context(), `
				SELECT EXISTS(SELECT 1 FROM document_access WHERE document_id=$1 AND user_id=$2)`, docID, uid).Scan(&alreadyHasAccess); err != nil {
				return err
			}
			if alreadyHasAccess {
				continue
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_acquaintances (document_id, user_id, acquainted_by)
				VALUES ($1, $2, $3) ON CONFLICT (document_id, user_id) DO NOTHING`, docID, uid, userID); err != nil {
				return err
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO document_access (document_id, user_id, access_reason)
				VALUES ($1, $2, 'acquaintance') ON CONFLICT DO NOTHING`, docID, uid); err != nil {
				return err
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload)
				VALUES ($1, $2, 'acquaintance', '{}')`, uid, docID); err != nil {
				return err
			}
			notified = append(notified, uid)
			// Снимок ФИО и должности для понятной записи в истории (#5).
			var fio, pos string
			if err := tx.QueryRow(c.Context(),
				`SELECT coalesce(full_name,''), coalesce(position,'') FROM users WHERE id=$1`, uid).Scan(&fio, &pos); err != nil {
				return err
			}
			if fio == "" {
				fio = fmt.Sprintf("Пользователь #%d", uid)
			}
			if pos != "" {
				acquaintNames = append(acquaintNames, fmt.Sprintf("%s (%s)", fio, pos))
			} else {
				acquaintNames = append(acquaintNames, fio)
			}
		}
		// История: перечисляем ФИО и должность добавленных для ознакомления (#5).
		// Если никого нового не добавили (все уже имели доступ) — историю не пишем.
		if len(acquaintNames) == 0 {
			return nil
		}
		histComment := "добавлены для ознакомления: " + strings.Join(acquaintNames, ", ")
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'acquainted', $3)`,
			docID, userID, histComment); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		if txErr == errForbiddenAcquaint {
			return fiber.NewError(fiber.StatusForbidden, "вы можете ознакамливать только пользователей из назначенных вам подразделений (или, будучи руководителем, из своего подразделения) и только по документам, к которым у вас есть доступ")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выполнить ознакомление")
	}
	h.hub.NotifyUsers(notified, docID, "acquaintance")
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"acquainted": len(notified)})
}
