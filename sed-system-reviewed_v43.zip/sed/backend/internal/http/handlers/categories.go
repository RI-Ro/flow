package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// CategoriesHandler — справочник категорий документов (#6). Список доступен всем
// аутентифицированным (для форм и фильтров), CRUD — только администратору.
type CategoriesHandler struct {
	pool *pgxpool.Pool
}

func NewCategoriesHandler(pool *pgxpool.Pool) *CategoriesHandler {
	return &CategoriesHandler{pool: pool}
}

type categoryItem struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Code      string `json:"code"`
	IsActive  bool   `json:"is_active"`
	SortOrder int    `json:"sort_order"`
}

func (h *CategoriesHandler) requireAdmin(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return nil
}

// List GET /api/categories — список категорий. Неактивные видит только админ.
func (h *CategoriesHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	var items []categoryItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		where := "WHERE is_active = true"
		if isAdmin {
			where = ""
		}
		rows, err := tx.Query(c.Context(),
			`SELECT id, name, coalesce(code,''), is_active, sort_order FROM document_categories `+where+
				` ORDER BY sort_order, name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it categoryItem
			if err := rows.Scan(&it.ID, &it.Name, &it.Code, &it.IsActive, &it.SortOrder); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить категории")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Create POST /api/admin/categories — создать категорию (admin).
func (h *CategoriesHandler) Create(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	var req struct {
		Name      string `json:"name"`
		Code      string `json:"code"`
		SortOrder int    `json:"sort_order"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название категории")
	}
	if req.SortOrder == 0 {
		req.SortOrder = 100
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO document_categories (name, code, sort_order)
			VALUES ($1, NULLIF($2,''), $3) RETURNING id`, req.Name, req.Code, req.SortOrder).Scan(&id)
	})
	if txErr != nil {
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "категория с таким названием/кодом уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать категорию")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

// Update PATCH /api/admin/categories/:id — изменить категорию (admin).
func (h *CategoriesHandler) Update(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Name      string `json:"name"`
		Code      string `json:"code"`
		IsActive  bool   `json:"is_active"`
		SortOrder int    `json:"sort_order"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название категории")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE document_categories SET name=$2, code=NULLIF($3,''), is_active=$4, sort_order=$5 WHERE id=$1`,
			id, req.Name, req.Code, req.IsActive, req.SortOrder)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "категория не найдена")
		}
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "категория с таким названием/кодом уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить категорию")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/admin/categories/:id — удалить категорию (admin).
// Если категория используется документами — блокируем удаление (деактивируйте).
func (h *CategoriesHandler) Delete(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		var used int
		if err := tx.QueryRow(c.Context(), `SELECT count(*) FROM documents WHERE category_id=$1`, id).Scan(&used); err != nil {
			return err
		}
		if used > 0 {
			return errCategoryInUse
		}
		_, err := tx.Exec(c.Context(), `DELETE FROM document_categories WHERE id=$1`, id)
		return err
	})
	if txErr != nil {
		if txErr == errCategoryInUse {
			return fiber.NewError(fiber.StatusConflict, "категория используется документами — удаление невозможно, деактивируйте её")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить категорию")
	}
	return c.SendStatus(fiber.StatusOK)
}
