package handlers

import (
	"net"
	"strings"

	"github.com/gofiber/fiber/v2"
)

// clientIP определяет ФАКТИЧЕСКИЙ IP клиента с учётом обратных прокси/NAT (#8,
// 63-ФЗ). Порядок предпочтения:
//  1. X-Forwarded-For — первый (левый) адрес в цепочке = исходный клиент;
//  2. X-Real-IP — типичный заголовок nginx;
//  3. c.IP() — адрес прямого соединения (когда прокси нет).
//
// Значение используется только для юридической фиксации факта подписи; доверять
// заголовкам можно, если прокси их проставляет и очищает клиентские (стандартная
// настройка nginx: proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for).
func clientIP(c *fiber.Ctx) string {
	if xff := c.Get("X-Forwarded-For"); xff != "" {
		// Может быть список "client, proxy1, proxy2" — берём первый непустой.
		for _, part := range strings.Split(xff, ",") {
			ip := strings.TrimSpace(part)
			if ip != "" {
				return normalizeIP(ip)
			}
		}
	}
	if xr := strings.TrimSpace(c.Get("X-Real-IP")); xr != "" {
		return normalizeIP(xr)
	}
	return normalizeIP(c.IP())
}

// normalizeIP срезает порт (если есть) и валидирует адрес; при неуспехе
// возвращает исходную строку (лучше зафиксировать «как есть», чем потерять).
func normalizeIP(s string) string {
	if host, _, err := net.SplitHostPort(s); err == nil {
		s = host
	}
	return s
}
