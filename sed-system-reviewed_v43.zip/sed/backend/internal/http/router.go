package http

import (
	"context"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/gofiber/contrib/websocket"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/config"
	"sed-system/backend/internal/http/handlers"
	appmw "sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/marking"
	"sed-system/backend/internal/repository"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

// NewRouter собирает все зависимости (репозитории, сервисы, хендлеры) и
// регистрирует маршруты. Простой ручной DI без фреймворка — достаточно
// для размера этого сервиса и не прячет граф зависимостей.
func NewRouter(cfg config.Config, fileCfg config.FileConfig, pool *pgxpool.Pool) *fiber.App {
	app := fiber.New(fiber.Config{
		AppName:      "sed-backend",
		ErrorHandler: jsonErrorHandler,
		// Разрешаем загрузку крупных PDF (до 64 МБ). При превышении Fiber вернёт
		// 413 — обрабатываем понятным сообщением в jsonErrorHandler.
		BodyLimit: 64 * 1024 * 1024,
	})

	// ВАЖЕН ПОРЯДОК: CORS первым, до recover/logger. Иначе при панике или
	// ошибке ответ уходит без CORS-заголовков, и браузер показывает
	// "CORS error", маскируя реальную 500-ку — типичная ловушка при отладке.
	app.Use(cors.New(cors.Config{
		AllowOrigins: cfg.AllowedOrigins, // напр. "http://localhost:5173,http://127.0.0.1:5173"
		AllowMethods: "GET,POST,PUT,PATCH,DELETE,OPTIONS",
		AllowHeaders: "Origin, Content-Type, Accept, Authorization",
	}))
	app.Use(recover.New())
	app.Use(logger.New())

	// Access-лог в файл (по аналогии с nginx/apache), если задан каталог.
	// Формат combined-подобный: time ip "METHOD url" status bytes dur "login".
	// Пишем В ДОБАВЛЕНИЕ к консольному logger выше. Ротацию оставляем внешним
	// средствам (logrotate) — открываем файл в режиме append.
	if dir := fileCfg.AccessLog.Dir; dir != "" {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			log.Printf("[warn] access-log: не удалось создать каталог %s: %v", dir, err)
		} else {
			logPath := filepath.Join(dir, "access.log")
			f, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
			if err != nil {
				log.Printf("[warn] access-log: не удалось открыть %s: %v", logPath, err)
			} else {
				log.Printf("access-лог запросов пишется в %s", logPath)
				app.Use(logger.New(logger.Config{
					Output: f,
					// ${login} берём из locals (проставляется в JWT-middleware).
					Format:     `${time} ${ip} "${method} ${url}" ${status} ${bytesSent} ${latency} "${locals:login}"` + "\n",
					TimeFormat: "2006-01-02T15:04:05Z07:00",
					TimeZone:   "Local",
				}))
			}
		}
	}

	authSvc := service.NewAuthService(cfg.JWTSecret, cfg.JWTTTL)
	accessSvc := service.NewAccessService()
	approvalSvc := service.NewApprovalService(accessSvc)
	numberingSvc := service.NewNumberingService()
	statusSvc := service.NewStatusService()
	signingSvc := service.NewSigningService(numberingSvc)
	documentsSvc := service.NewDocumentsService(accessSvc, approvalSvc)
	incomingSvc := service.NewIncomingService(numberingSvc)
	markingDataSvc := service.NewMarkingDataService()
	// Вжигание штампов в сам PDF (pdfcpu) включается секцией
	// marking.bake_into_pdf.enabled: true (полноценная секция с параметрами:
	// шрифт, цвет/размер/позиция по умолчанию, отступ, прозрачность — как у
	// остальных штампов). По умолчанию выключено: штампы рисуются overlay-слоем
	// на фронте по той же конфигурации. Даже при enabled, если pdfcpu не смог
	// нанести штамп, фронт покажет overlay (см. IsBaking()).
	if fileCfg.Marking.Bake.Enabled {
		marking.Configure(fileCfg.Marking)
	}
	sendSvc := service.NewSendService(accessSvc)
	executionSvc := service.NewExecutionService()

	docsRepo := repository.NewDocumentsRepo()
	hub := ws.NewHub(pool)
	// Redis pub/sub для межинстансной доставки WS (если задан адрес). Канал
	// по умолчанию — sed_events. Пустой redis_addr = одно-инстансный режим.
	channel := fileCfg.Realtime.EventsChannel
	if channel == "" {
		channel = "sed_events"
	}
	hub.EnableRedis(context.Background(), fileCfg.Realtime.RedisAddr, channel)

	authHandler := handlers.NewAuthHandler(pool, authSvc)
	docsHandler := handlers.NewDocumentsHandler(pool, docsRepo, incomingSvc, markingDataSvc, fileCfg.Marking, cfg.PageSize, cfg.PageSizeMax)
	docCreateHandler := handlers.NewDocumentCreateHandler(pool, documentsSvc, hub)
	approvalHandler := handlers.NewApprovalHandler(pool, approvalSvc, statusSvc, signingSvc, hub)
	usersHandler := handlers.NewUsersHandler(pool)
	sendHandler := handlers.NewSendHandler(pool, sendSvc, hub)
	executionHandler := handlers.NewExecutionHandler(pool, executionSvc, hub)
	dashboardHandler := handlers.NewDashboardHandler(pool)
	notificationsHandler := handlers.NewNotificationsHandler(pool)
	registryHandler := handlers.NewRegistryHandler(pool)
	linksHandler := handlers.NewLinksHandler(pool)
	assignmentsHandler := handlers.NewAssignmentsHandler(pool, hub)
	acquaintHandler := handlers.NewAcquaintanceHandler(pool, hub)
	chatHandler := handlers.NewChatHandler(pool, hub)
	adminHandler := handlers.NewAdminHandler(pool, service.NewAdminService())
	groupsHandler := handlers.NewGroupsHandler(pool)
	categoriesHandler := handlers.NewCategoriesHandler(pool)

	api := app.Group("/api")
	// Публичный конфиг брендинга (название системы + подзаголовок) — доступен
	// до авторизации, чтобы страница входа тоже показывала настроенное имя.
	appName := fileCfg.Branding.AppName
	tagline := fileCfg.Branding.Tagline
	copyright := fileCfg.Branding.Copyright
	about := fileCfg.Branding.About
	api.Get("/app-config", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"app_name": appName, "tagline": tagline, "copyright": copyright, "about": about})
	})
	api.Post("/auth/login", authHandler.Login)

	protected := api.Group("", appmw.JWTAuth(authSvc))
	protected.Post("/auth/refresh", authHandler.Refresh)
	protected.Get("/me", authHandler.Me)

	// --- Администрирование (только для admin; проверка внутри хендлеров) ---
	admin := protected.Group("/admin")
	admin.Get("/departments", adminHandler.ListDepartments)
	admin.Post("/departments", adminHandler.CreateDepartment)
	admin.Patch("/departments/:id", adminHandler.UpdateDepartment)
	admin.Patch("/departments/:id/parent", adminHandler.MoveDepartment)
	admin.Delete("/departments/:id", adminHandler.DeleteDepartment)
	admin.Get("/users", adminHandler.ListUsers)
	admin.Post("/users", adminHandler.CreateUser)
	admin.Patch("/users/:id", adminHandler.UpdateUser)
	admin.Patch("/users/:id/department", adminHandler.MoveUser)
	admin.Patch("/users/:id/departments", adminHandler.SetUserDepartments)
	admin.Patch("/users/:id/password", adminHandler.SetUserPassword)
	admin.Patch("/users/:id/roles", adminHandler.SetUserRoles)
	// #4 — Группы адресатов рассылки (CRUD только admin).
	admin.Post("/recipient-groups", groupsHandler.Create)
	admin.Patch("/recipient-groups/:id", groupsHandler.Update)
	admin.Delete("/recipient-groups/:id", groupsHandler.Delete)
	admin.Put("/recipient-groups/:id/members", groupsHandler.SetMembers)
	// #6 — категории документов (CRUD только admin).
	admin.Post("/categories", categoriesHandler.Create)
	admin.Patch("/categories/:id", categoriesHandler.Update)
	admin.Delete("/categories/:id", categoriesHandler.Delete)
	protected.Get("/documents", docsHandler.List)
	protected.Post("/documents", docCreateHandler.Create)
	// /documents/search ДО /documents/:id — иначе роутер примет "search" за
	// значение параметра :id (статичный сегмент должен матчиться первым).
	protected.Get("/documents/search", docsHandler.Search)
	protected.Get("/documents/:id", docsHandler.Get)
	protected.Get("/documents/:id/file", docsHandler.GetFile)
	protected.Get("/documents/:id/marking", docsHandler.GetMarking)
	protected.Get("/documents/:id/stages", docsHandler.GetStages)
	protected.Post("/documents/:id/stages/:stageId/decide", approvalHandler.Decide)
	protected.Post("/documents/:id/send", sendHandler.Send)
	protected.Post("/documents/:id/complete", executionHandler.Complete)
	protected.Get("/documents/:id/recipients", sendHandler.Recipients)
	protected.Delete("/documents/:id/recipients/:recipientId", sendHandler.DeleteRecipient)
	protected.Get("/documents/:id/history", docsHandler.History)
	protected.Get("/documents/:id/views", docsHandler.Views)
	protected.Post("/documents/:id/control", docsHandler.SetControl)
	protected.Post("/documents/:id/archive", docsHandler.Archive)
	protected.Get("/documents/:id/controllers", docsHandler.Controllers)
	protected.Get("/documents/:id/signatures", docsHandler.Signatures)
	protected.Get("/default-controllers", docsHandler.DefaultControllers)
	protected.Get("/documents/:id/my-roles", docsHandler.MyRoles)
	protected.Patch("/documents/:id", docCreateHandler.Update)
	protected.Patch("/documents/:id/file", docCreateHandler.ReplaceFile)
	protected.Delete("/documents/:id", docCreateHandler.Delete)
	protected.Patch("/documents/:id/route", docCreateHandler.UpdateRoute)
	protected.Put("/documents/:id/signers", docCreateHandler.UpdateSigners)
	protected.Patch("/documents/:id/planned-recipients", docCreateHandler.UpdatePlannedRecipients)
	protected.Get("/dashboard/stats", dashboardHandler.Stats)
	protected.Get("/registry/archive/years", registryHandler.ArchiveYears)
	protected.Get("/registry/archive/:year", registryHandler.ArchiveByYear)
	protected.Get("/registry/:kind", registryHandler.List)
	protected.Get("/registry/:kind/export", registryHandler.Export)
	protected.Get("/recipients-counts", sendHandler.RecipientsCounts)
	protected.Get("/documents/:id/copies", docsHandler.Copies)

	// Печать: скачивание на печать (только роль printer, только маркированный
	// PDF), реестр скачиваний и регистрация распечатанного экземпляра.
	printsHandler := handlers.NewPrintsHandler(pool, markingDataSvc, fileCfg.Marking)
	protected.Post("/documents/:id/print", printsHandler.Download)
	protected.Get("/documents/:id/prints", printsHandler.List)
	protected.Patch("/documents/:id/prints/:printId/register", printsHandler.Register)
	protected.Get("/documents/:id/links", linksHandler.List)
	protected.Post("/documents/:id/links", linksHandler.Create)
	protected.Delete("/documents/:id/links/:linkId", linksHandler.Delete)
	protected.Get("/documents/:id/assignments", assignmentsHandler.List)
	protected.Post("/documents/:id/assignments", assignmentsHandler.Create)
	protected.Patch("/assignments/:id", assignmentsHandler.Update)
	protected.Put("/assignments/:id", assignmentsHandler.Edit)
	protected.Delete("/assignments/:id", assignmentsHandler.Delete)
	protected.Get("/documents/:id/acquaintances", acquaintHandler.List)
	protected.Post("/documents/:id/acquaint", acquaintHandler.Create)
	protected.Get("/acquaint-candidates", acquaintHandler.Candidates)
	protected.Get("/documents/:id/chat", chatHandler.History)
	protected.Post("/documents/:id/chat", chatHandler.Post)
	protected.Get("/chat/attachments/:aid", chatHandler.Attachment)
	protected.Patch("/chat/messages/:mid", chatHandler.EditMessage)
	protected.Delete("/chat/messages/:mid", chatHandler.DeleteMessage)
	protected.Get("/notifications", notificationsHandler.List)
	protected.Post("/notifications/:id/read", notificationsHandler.MarkRead)
	protected.Post("/notifications/read-all", notificationsHandler.MarkAllRead)
	protected.Get("/users", usersHandler.List)
	protected.Get("/users/candidates", usersHandler.Candidates)
	protected.Get("/departments", usersHandler.Departments)
	// #4 — Список групп адресатов (с составом) для формы рассылки.
	protected.Get("/recipient-groups", groupsHandler.List)
	protected.Get("/categories", categoriesHandler.List)

	// WebSocket: /ws/documents/:id/chat?token=...
	app.Use("/ws", func(c *fiber.Ctx) error {
		if websocket.IsWebSocketUpgrade(c) {
			return c.Next()
		}
		return fiber.ErrUpgradeRequired
	})
	app.Get("/ws/documents/:id/chat", websocket.New(ws.ChatWSHandler(hub, authSvc)))
	app.Get("/ws/notifications", websocket.New(ws.NotificationsWSHandler(hub, authSvc)))

	app.Get("/healthz", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"status": "ok"})
	})

	// --- Раздача статики фронтенда (SPA) одним приложением, без nginx ---
	// Явный обработчик (надёжнее filesystem-middleware и логируется): для
	// каждого GET-пути, не относящегося к /api|/ws|/healthz, отдаём файл из
	// каталога сборки, а если файла нет — index.html (клиентский роутинг).
	// Регистрируется ПОСЛЕ всех /api и /ws — они имеют приоритет.
	if dir := fileCfg.Static.Dir; dir != "" {
		absDir, _ := filepath.Abs(dir)
		indexPath := filepath.Join(dir, "index.html")
		if _, err := os.Stat(indexPath); err != nil {
			log.Printf("[warn] статика: %s не найден (%v) — проверьте static.dir/STATIC_DIR", indexPath, err)
		} else {
			log.Printf("статика фронтенда раздаётся из %s", absDir)
		}
		app.Get("/*", func(c *fiber.Ctx) error {
			p := c.Path()
			if strings.HasPrefix(p, "/api") || strings.HasPrefix(p, "/ws") || p == "/healthz" {
				return fiber.ErrNotFound
			}
			// Защита от path traversal: чистим путь и приклеиваем к каталогу.
			rel := filepath.Clean("/" + strings.TrimPrefix(p, "/"))
			candidate := filepath.Join(dir, rel)
			if st, err := os.Stat(candidate); err == nil && !st.IsDir() {
				return c.SendFile(candidate, false)
			}
			// Файл не найден — SPA-fallback на index.html.
			return c.SendFile(indexPath, false)
		})
	} else {
		log.Println("статика фронтенда отключена (static.dir пуст) — режим только API")
	}

	return app
}

func jsonErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	message := "внутренняя ошибка сервера"
	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		message = fe.Message
	}
	// Понятные пояснения для типовых кодов (файл слишком большой и т.п.).
	switch code {
	case fiber.StatusRequestEntityTooLarge:
		message = "файл слишком большой (превышен лимит загрузки 64 МБ)"
	case fiber.StatusUnsupportedMediaType:
		message = "неподдерживаемый тип файла (принимается только PDF)"
	case fiber.StatusUnauthorized:
		if message == "" || message == "Unauthorized" {
			message = "требуется вход в систему (сессия истекла)"
		}
	case fiber.StatusRequestTimeout, fiber.StatusServiceUnavailable:
		if message == "" {
			message = "сервис временно недоступен, повторите попытку"
		}
	}
	return c.Status(code).JSON(fiber.Map{"error": message})
}
