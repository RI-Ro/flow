package config

// MarkingConfig описывает конфигурацию нанесения штампов на PDF (грузится из
// config.yaml, секция marking). Рендер выполняется на Go (см. пакет marking),
// значения-плейсхолдеры в Lines подставляются во время нанесения.
type MarkingConfig struct {
	// FontFile — путь к TTF-шрифту с поддержкой кириллицы (обязателен для
	// корректного нанесения русскоязычных штампов; core-шрифты PDF кириллицу
	// не отображают). Напр. /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf.
	// Пусто — рендер использует Helvetica (только латиница/цифры).
	FontFile string `yaml:"font_file"`
	// FontName — имя шрифта в pdfcpu после установки (обычно совпадает с именем
	// файла без расширения, напр. "DejaVuSans").
	FontName string `yaml:"font_name"`

	// PrintFilenameTemplate — шаблон имени файла при выдаче на печать (#6b).
	// Плейсхолдеры: {title}, {number}, {instance}, {copy}, {time}, {downloader}.
	// Пусто — используется значение по умолчанию (см. handler prints).
	PrintFilenameTemplate string `yaml:"print_filename_template"`

	// Bake — параметры ВЖИГАНИЯ штампов в сам PDF (pdfcpu). Раньше было
	// булево bake_into_pdf; теперь это полноценная секция с настройками, как у
	// остальных штампов. enabled=false — штампы не вжигаются в файл (рисуются
	// overlay-слоем на фронте по той же конфигурации). enabled=true — вжигание
	// в файл; при печати это обязательно (иначе выдача запрещена).
	Bake BakeConfig `yaml:"bake_into_pdf"`

	SignatureStamp     StampConfig `yaml:"signature_stamp"`     // 5) сведения о подписи
	RegistrationNumber StampConfig `yaml:"registration_number"` // 1) исходящий номер
	IncomingStamp      StampConfig `yaml:"incoming_stamp"`      // 2) входящий номер (отметка о получении)
	InstanceStamp      StampConfig `yaml:"instance_stamp"`      // 3) экземпляр
	ArchiveStamp       StampConfig `yaml:"archive_stamp"`       // 4) факт переноса в архив
	PrintStamp         StampConfig `yaml:"print_stamp"`         // 6) регистрация распечатанного экземпляра
}

// BakeConfig — настройки процесса вжигания штампов в PDF. Значения-«по
// умолчанию» применяются к штампу, если у него самого параметр не задан.
type BakeConfig struct {
	Enabled bool `yaml:"enabled"`
	// FontFile/FontName — шрифт для вжигания (кириллица). Если пусто — берутся
	// из marking.font_file/font_name (верхний уровень).
	FontFile string `yaml:"font_file"`
	FontName string `yaml:"font_name"`
	// Глобальные значения по умолчанию для штампов при вжигании:
	DefaultColor    string  `yaml:"default_color"`     // цвет текста, если у штампа не задан (#rrggbb)
	DefaultFontSize float64 `yaml:"default_font_size"` // размер шрифта по умолчанию
	DefaultPosition string  `yaml:"default_position"`  // позиция по умолчанию (top_right и т.п.)
	Margin          float64 `yaml:"margin"`            // отступ штампов от края страницы
	Opacity         float64 `yaml:"opacity"`           // прозрачность штампов 0..1 (0/пусто = 1.0)
}

type StampConfig struct {
	Enabled  bool     `yaml:"enabled"`
	Position string   `yaml:"position"` // top_left|top_right|bottom_left|bottom_right|center
	OffsetX  float64  `yaml:"offset_x"`
	OffsetY  float64  `yaml:"offset_y"`
	Page     string   `yaml:"page"` // on_first|on_last|on_all
	FontSize float64  `yaml:"font_size"`
	Color    string   `yaml:"color"`
	Border   bool     `yaml:"border"`
	// BorderColor — цвет рамки штампа "#rrggbb". Пусто = цвет текста (Color).
	BorderColor string `yaml:"border_color"`
	// FillColor — цвет заливки (фона) штампа "#rrggbb". Пусто = без заливки
	// (прозрачно; если задан border — лёгкий фон под рамкой).
	FillColor string `yaml:"fill_color"`
	// ImageFile — путь к изображению (напр. факсимиле подписи/печать). Если
	// задан, штамп рисуется в две колонки: слева изображение, справа текст.
	ImageFile string   `yaml:"image_file"`
	Lines     []string `yaml:"lines"`
}

// LifecycleConfig — правила жизненного цикла документа.
type LifecycleConfig struct {
	AutoArchiveExecutedNextYear bool   `yaml:"auto_archive_executed_next_year"`
	ArchiveCheckCron            string `yaml:"archive_check_cron"`
}

// RealtimeConfig — параметры WS-сервиса (отдельный бинарник cmd/realtime).
type RealtimeConfig struct {
	Addr          string `yaml:"addr"`
	EventsChannel string `yaml:"events_channel"`
	RedisAddr     string `yaml:"redis_addr"` // "host:port"; пусто = одно-инстансный режим
}
