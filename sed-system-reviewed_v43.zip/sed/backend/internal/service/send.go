package service

import (
	"time"
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5"
)

// RecipientInfo — элемент списка рассылки (вкладка "Рассылка").
type RecipientInfo struct {
	ID             int64      `json:"id"` // id строки document_recipients (для удаления)
	UserID         int64      `json:"user_id"`
	FullName       string     `json:"full_name"`
	DepartmentID   int64      `json:"department_id"`
	DepartmentName string     `json:"department_name"`
	IsPlanned      bool       `json:"is_planned"`
	Viewed         bool       `json:"viewed"` // получатель уже открыл документ (есть входящий экземпляр)
	SentAt         time.Time  `json:"sent_at"`
	CompletedAt    *time.Time `json:"completed_at,omitempty"`
	CompletionNote string     `json:"completion_note,omitempty"`
}

var ErrDocumentNotSigned = errors.New("документ должен быть подписан перед направлением")
var ErrNoRecipients = errors.New("нужно указать хотя бы одного получателя")
var ErrForbiddenSend = errors.New("направлять документ может только автор или подписант")

type SendService struct {
	access *AccessService
}

func NewSendService(access *AccessService) *SendService {
	return &SendService{access: access}
}

// Recipient — один адресат рассылки.
type Recipient struct {
	UserID       int64
	DepartmentID int64
}

// Send направляет документ списку получателей (рассылка). Работает и для
// первичного направления (из статуса 'signed'), и для ДО-направления (из
// 'sent'/'in_progress' — добавить новых адресатов к уже разосланному).
// Получатель обязан иметь роль clerk (канцелярия) — это проверяет DB-триггер
// check_recipient_role. Доступ к документу открывается получателю сразу, но в
// категорию "Входящие" он попадёт только при статусе sent и далее (см.
// repository.List), т.е. "видно только после подписи".
// Возвращает id получателей, которым реально отправлено (для уведомлений).
func (s *SendService) Send(ctx context.Context, tx pgx.Tx, documentID, senderID int64, recipients []Recipient) ([]int64, error) {
	var status string
	if err := tx.QueryRow(ctx, `SELECT status FROM documents WHERE id = $1`, documentID).Scan(&status); err != nil {
		return nil, fmt.Errorf("lookup document status: %w", err)
	}
	// Первичное направление — из signed. До-направление — из sent/in_progress.
	// Донаправление после ИСПОЛНЕНИЯ всеми — из executed (документ снова
	// становится «отправлен»).
	if status != "signed" && status != "sent" && status != "in_progress" && status != "executed" {
		return nil, ErrDocumentNotSigned
	}

	// Если явный список получателей пуст — активируем ПЛАНОВЫХ адресатов,
	// выбранных автором на этапе создания (is_planned=true). Это делает
	// сценарий "создал документ с рассылкой → подписал → отправил" рабочим
	// без повторного ручного выбора получателей (исправление ошибки
	// «нужно указать хотя бы одного получателя» после создания).
	if len(recipients) == 0 {
		rows, err := tx.Query(ctx, `
			SELECT recipient_user_id, recipient_department_id
			FROM document_recipients
			WHERE document_id = $1 AND is_planned = true`, documentID)
		if err != nil {
			return nil, fmt.Errorf("load planned recipients: %w", err)
		}
		defer rows.Close()
		for rows.Next() {
			var r Recipient
			if err := rows.Scan(&r.UserID, &r.DepartmentID); err != nil {
				return nil, err
			}
			recipients = append(recipients, r)
		}
		if err := rows.Err(); err != nil {
			return nil, err
		}
	}
	if len(recipients) == 0 {
		return nil, ErrNoRecipients
	}

	var notified []int64
	var sentNames []string // ФИО (должность) активированных получателей — для истории
	for _, r := range recipients {
		// Активируем получателя: если он был плановым (is_planned=true) —
		// снимаем флаг; если новый — вставляем как активного. Уже активные
		// (is_planned=false) не переактивируются повторно (WHERE в DO UPDATE),
		// поэтому до-направление и повторные вызовы идемпотентны и не шлют
		// дубль-уведомлений. RowsAffected>0 == "получатель только что активирован".
		tag, err := tx.Exec(ctx, `
			INSERT INTO document_recipients (document_id, recipient_user_id, recipient_department_id, is_planned, added_by)
			VALUES ($1, $2, $3, false, $4)
			ON CONFLICT (document_id, recipient_user_id)
			DO UPDATE SET is_planned = false,
			              recipient_department_id = EXCLUDED.recipient_department_id
			WHERE document_recipients.is_planned = true`, documentID, r.UserID, r.DepartmentID, senderID)
		if err != nil {
			return nil, fmt.Errorf("insert recipient %d: %w", r.UserID, err)
		}
		if tag.RowsAffected() == 0 {
			continue // уже был активным получателем — пропускаем
		}
		if err := s.access.grant(ctx, tx, documentID, r.UserID, "recipient"); err != nil {
			return nil, err
		}
		// Снимок ФИО+должности активированного получателя — для истории (#5b).
		var fio, pos string
		_ = tx.QueryRow(ctx, `SELECT coalesce(full_name,''), coalesce(position,'') FROM users WHERE id=$1`, r.UserID).Scan(&fio, &pos)
		if fio == "" {
			fio = fmt.Sprintf("Пользователь #%d", r.UserID)
		}
		if pos != "" {
			sentNames = append(sentNames, fmt.Sprintf("%s (%s)", fio, pos))
		} else {
			sentNames = append(sentNames, fio)
		}
		_, err = tx.Exec(ctx, `
			INSERT INTO notifications (user_id, document_id, kind, payload)
			VALUES ($1, $2, 'document_sent', '{}')`, r.UserID, documentID)
		if err != nil {
			return nil, fmt.Errorf("insert notification: %w", err)
		}
		notified = append(notified, r.UserID)
	}

	// Перевод в 'sent' при первичном направлении (из signed) и при
	// ДОНАПРАВЛЕНИИ после исполнения всеми (из executed — документ снова
	// «отправлен» новым адресатам).
	// Текст для истории с конкретными адресатами (#5b). Если ничего не
	// активировано (все уже были получателями) — общий текст.
	who := strings.Join(sentNames, ", ")
	if status == "signed" || status == "executed" {
		if _, err := tx.Exec(ctx, `UPDATE documents SET status = 'sent' WHERE id = $1`, documentID); err != nil {
			return nil, fmt.Errorf("update status to sent: %w", err)
		}
		base := "направлен адресатам"
		if status == "executed" {
			base = "донаправлен после исполнения"
		}
		comment := base
		if who != "" {
			comment = base + ": " + who
		}
		_, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'sent', $3::doc_status, 'sent', $4)`,
			documentID, senderID, status, comment)
		if err != nil {
			return nil, fmt.Errorf("insert history: %w", err)
		}
	} else {
		// До-направление — статус не меняем, только фиксируем событие.
		comment := "донаправлены адресаты"
		if who != "" {
			comment = "донаправлены адресаты: " + who
		}
		_, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'resent', $3)`, documentID, senderID, comment)
		if err != nil {
			return nil, fmt.Errorf("insert history: %w", err)
		}
	}

	return notified, nil
}

// ListRecipients возвращает список рассылки документа (кому направлено, кто
// отметил исполнение) — для вкладки "Рассылка" в карточке.
func (s *SendService) ListRecipients(ctx context.Context, tx pgx.Tx, documentID int64) ([]RecipientInfo, error) {
	rows, err := tx.Query(ctx, `
		SELECT r.id, r.recipient_user_id,
		       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
		       r.recipient_department_id, d.name,
		       r.is_planned,
		       EXISTS(SELECT 1 FROM document_incoming_instances i
		              WHERE i.document_id = r.document_id AND i.receiving_department_id = r.recipient_department_id),
		       r.created_at, r.completed_at, coalesce(r.completion_note, '')
		FROM document_recipients r
		JOIN users u ON u.id = r.recipient_user_id
		JOIN departments d ON d.id = r.recipient_department_id
		WHERE r.document_id = $1
		ORDER BY r.created_at`, documentID)
	if err != nil {
		return nil, fmt.Errorf("list recipients: %w", err)
	}
	defer rows.Close()
	var out []RecipientInfo
	for rows.Next() {
		var ri RecipientInfo
		if err := rows.Scan(&ri.ID, &ri.UserID, &ri.FullName, &ri.DepartmentID, &ri.DepartmentName,
			&ri.IsPlanned, &ri.Viewed, &ri.SentAt, &ri.CompletedAt, &ri.CompletionNote); err != nil {
			return nil, err
		}
		out = append(out, ri)
	}
	return out, rows.Err()
}
