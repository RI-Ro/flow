package service

import (
	"context"

	"github.com/jackc/pgx/v5"
)

// IsAuthorOrSigner возвращает true, если пользователь — автор документа ИЛИ его
// подписант (назначенный на этап stage_type='signing', либо уже подписавший).
// Используется для прав на связи и направление документа.
func IsAuthorOrSigner(ctx context.Context, tx pgx.Tx, documentID, userID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM documents d WHERE d.id = $1 AND d.author_id = $2
			UNION ALL
			SELECT 1 FROM approval_stages s
			  WHERE s.document_id = $1 AND s.stage_type = 'signing' AND s.approver_id = $2
			UNION ALL
			SELECT 1 FROM document_signatures sig
			  WHERE sig.document_id = $1 AND sig.signer_id = $2
		)`, documentID, userID).Scan(&ok)
	return ok, err
}

// CanAcquaint проверяет, может ли actor ознакомить targetUser. По ТЗ правило
// ЕДИНОЕ для всех (включая автора/подписанта): ознакомить можно ТОЛЬКО
// сотрудников подразделений, явно назначенных пользователю в админке
// (user_acquaint_departments), и подразделений НИЖЕ них по иерархии. Своё
// подразделение по умолчанию НЕ даёт такого права — его тоже нужно указать
// в админке. Если список пуст, ознакомить нельзя никого.
func CanAcquaint(ctx context.Context, tx pgx.Tx, actorID, targetUserID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		WITH RECURSIVE roots AS (
			SELECT department_id AS id FROM user_acquaint_departments WHERE user_id = $1
			UNION
			-- #6 — руководитель подразделения (chief) И дежурный/канцелярия
			-- (clerk) вправе ознакамливать сотрудников СВОЕГО подразделения и
			-- ниже по иерархии (без явного user_acquaint_departments).
			SELECT u.primary_department_id FROM users u
			WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
			  AND EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = $1 AND ur.role IN ('chief','clerk'))
		),
		subtree AS (
			SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
			UNION ALL
			SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
		)
		SELECT EXISTS (
			SELECT 1 FROM users u
			WHERE u.id = $2 AND u.primary_department_id IN (SELECT id FROM subtree)
		)`, actorID, targetUserID).Scan(&ok)
	return ok, err
}

// CanAssignTo проверяет право дать поручение assignee по документу.
// Правила:
//   - автор и подписант: могут поручать ВСЕМ, кому направлен документ
//     (получателям), а также сотрудникам своего подразделения и вниз по иерархии;
//   - остальные: только сотрудникам своего подразделения и вниз по иерархии.
// (Плюс отдельно в хендлере — тем, кого пользователь сам ознакомил.)
func CanAssignTo(ctx context.Context, tx pgx.Tx, documentID, actorID, assigneeID int64) (bool, error) {
	// Дать поручение можно ТОЛЬКО пользователю с ролью «исполнитель поручений»
	// (executor) из подразделений, назначенных актору в админке
	// (user_assign_departments) и ниже по иерархии, ЛИБО — если актор дежурный
	// (clerk) или руководитель (chief) — из его собственного подразделения и
	// ниже. Если ни то, ни другое — поручать нельзя.
	var ok bool
	err := tx.QueryRow(ctx, `
		WITH RECURSIVE roots AS (
			SELECT department_id AS id FROM user_assign_departments WHERE user_id = $1
			UNION
			SELECT u.primary_department_id FROM users u
			WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
			  AND EXISTS (SELECT 1 FROM user_roles r WHERE r.user_id=$1 AND r.role IN ('chief','clerk'))
		),
		subtree AS (
			SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
			UNION ALL
			SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
		)
		SELECT EXISTS (
			SELECT 1 FROM users u
			WHERE u.id = $2
			  AND u.primary_department_id IN (SELECT id FROM subtree)
			  AND EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id AND ur.role = 'executor')
		)`, actorID, assigneeID).Scan(&ok)
	return ok, err
}
