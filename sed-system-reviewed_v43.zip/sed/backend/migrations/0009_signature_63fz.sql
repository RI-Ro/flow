-- +goose Up
-- #8 — Расширенная фиксация факта подписания (63-ФЗ): логин подписанта на
-- момент подписи, фактический IP-адрес (с учётом прокси/NAT — X-Forwarded-For/
-- X-Real-IP), user-agent и хэш содержимого документа (привязка подписи к
-- конкретному файлу). Время подписи уже фиксируется (signed_at), тип — в
-- signature_type, отпечаток — в signature_hash.
ALTER TABLE document_signatures ADD COLUMN IF NOT EXISTS signer_login TEXT;
ALTER TABLE document_signatures ADD COLUMN IF NOT EXISTS signed_ip TEXT;
ALTER TABLE document_signatures ADD COLUMN IF NOT EXISTS user_agent TEXT;
ALTER TABLE document_signatures ADD COLUMN IF NOT EXISTS document_hash TEXT;

-- +goose Down
ALTER TABLE document_signatures DROP COLUMN IF EXISTS document_hash;
ALTER TABLE document_signatures DROP COLUMN IF EXISTS user_agent;
ALTER TABLE document_signatures DROP COLUMN IF EXISTS signed_ip;
ALTER TABLE document_signatures DROP COLUMN IF EXISTS signer_login;
