-- +goose Up
-- #2 — Персональный список подразделений, в которые пользователь вправе
-- ДОНАПРАВИТЬ (переслать) входящий документ. Список уникален для каждого
-- пользователя, управляется администратором. Используется при направлении
-- документа получателем-неавтором: цели ограничиваются этим списком.
CREATE TABLE IF NOT EXISTS user_redirect_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX IF NOT EXISTS idx_user_redirect_dept ON user_redirect_departments(department_id);

-- +goose Down
DROP TABLE IF EXISTS user_redirect_departments;
