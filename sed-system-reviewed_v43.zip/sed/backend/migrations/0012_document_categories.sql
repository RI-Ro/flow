-- +goose Up
-- #6 — Справочник КАТЕГОРИЙ документов (постоянные, временные и т.д.) и
-- обязательный атрибут категории у документа. Управляется из админки.
CREATE TABLE IF NOT EXISTS document_categories (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    code TEXT UNIQUE,                 -- машинный код (необязательно)
    is_active BOOL NOT NULL DEFAULT TRUE,
    sort_order INT NOT NULL DEFAULT 100,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Базовые категории.
INSERT INTO document_categories (name, code, sort_order) VALUES
    ('Постоянные', 'permanent', 10),
    ('Временные',  'temporary', 20)
ON CONFLICT (name) DO NOTHING;

-- Атрибут категории у документа. Заполняем существующие документы первой
-- категорией, затем делаем NOT NULL (обязательный атрибут).
ALTER TABLE documents ADD COLUMN IF NOT EXISTS category_id BIGINT REFERENCES document_categories(id);
UPDATE documents SET category_id = (SELECT id FROM document_categories ORDER BY sort_order, id LIMIT 1)
    WHERE category_id IS NULL;
ALTER TABLE documents ALTER COLUMN category_id SET NOT NULL;
CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category_id);

-- +goose Down
DROP INDEX IF EXISTS idx_documents_category;
ALTER TABLE documents DROP COLUMN IF EXISTS category_id;
DROP TABLE IF EXISTS document_categories;
