-- +goose Up
-- #4 — Кто именно отметил исполнение поручения (для фиксации факта «кто и когда
-- выполнил»; «когда» уже есть в completed_at, текст — в result_note).
ALTER TABLE assignments ADD COLUMN IF NOT EXISTS completed_by BIGINT REFERENCES users(id);

-- +goose Down
ALTER TABLE assignments DROP COLUMN IF EXISTS completed_by;
