-- +goose Up
-- #7 — «Основание» для учётной записи пользователя (напр. приказ №…, распоряжение).
ALTER TABLE users ADD COLUMN IF NOT EXISTS basis TEXT;

-- +goose Down
ALTER TABLE users DROP COLUMN IF EXISTS basis;
