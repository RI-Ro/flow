-- +goose Up
-- #1 — Кто добавил (донаправил) получателя. Нужен, чтобы дежурный мог удалить
-- ИМЕННО своего донаправленного адресата (до первого просмотра адресатом).
ALTER TABLE document_recipients ADD COLUMN IF NOT EXISTS added_by BIGINT REFERENCES users(id);

-- +goose Down
ALTER TABLE document_recipients DROP COLUMN IF EXISTS added_by;
