// Модуль предназначен для панели администратора: список учётных записей, создание, изменение, блокировка, сброс пароля,
// удаление с передачей дел преемнику.

import React, { useCallback, useEffect, useState } from "react";
import {
  Search, Plus, Pencil, Trash2, KeyRound, RotateCcw, ShieldCheck, User as UserIcon,
  ChevronLeft, ChevronRight, Check, Ban,
} from "lucide-react";
import { api } from "../lib/api.js";
import { fmtDate } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, ConfirmDialog, PasswordInput, PasswordRules, inputStyle } from "../lib/ui.jsx";
import { PASSWORD_RULE, checkPassword } from "../lib/password.js";

const PAGE_SIZE = 20;

// Функция tone предназначена для получения стиля капсулы статуса: цвет текста и фон с прозрачностью 12 %.
const tone = (c) => ({ background: `${c}1f`, color: c });

// Компонент Admin предназначен для управления учётными записями пользователей (только роль admin).
export default function Admin({ theme, currentUser, onClose, onError, onInfo, onDirectoryChanged }) {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);   // объект пользователя или "new"
  const [resetting, setResetting] = useState(null);
  const [confirm, setConfirm] = useState(null);
  // Состояние диалога выбора преемника: при удалении пользователя с объектами во владении сервер требует преемника (409 need_successor).
  const [successorFor, setSuccessorFor] = useState(null);

  const load = useCallback(async (targetPage = page, q = query) => {
    setLoading(true);
    try {
      const data = await api.adminUsers({ limit: PAGE_SIZE, offset: (targetPage - 1) * PAGE_SIZE, q });
      setItems(data.items);
      setTotal(data.total);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [page, query, onError]);

  useEffect(() => { load(page, query); }, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  // Поиск выполняется с задержкой, чтобы не отправлять запрос на каждое нажатие клавиши.
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(1, query); }, 350);
    return () => clearTimeout(t);
  }, [query]); // eslint-disable-line react-hooks/exhaustive-deps

  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const afterChange = () => {
    load(page, query);
    onDirectoryChanged();
  };

  // Функция deleteUser предназначена для удаления учётной записи (офбординг): сервер снимает весь доступ (членства в проектах,
  // диаграммах и досках, точечный доступ, назначения, замещения); задачи без исполнителя не переназначаются.
  const deleteUser = async (u, successorId) => {
    try {
      await api.adminDeleteUser(u.id, successorId);
      setSuccessorFor(null);
      onInfo(successorId
        ? `${u.fullName} удалён, его проекты переданы преемнику`
        : `Учётная запись ${u.fullName} удалена, доступ снят`);
      afterChange();
    } catch (e) {
      if (e.code === "need_successor") {
        setSuccessorFor(u);
      } else {
        onError(e.message);
      }
    }
  };

  const remove = (u) => setConfirm({
    title: "Удалить учётную запись?",
    message: `${u.fullName} потеряет вход и весь доступ: проекты, задачи, замещения. `
      + "Из задач, где он исполнитель, он будет снят — владельцу и редакторам проекта придёт "
      + "уведомление, чтобы назначить другого. Если он владеет проектами, следующим шагом "
      + "нужно будет выбрать, кому их передать. Имя останется в истории; учётную запись можно "
      + "восстановить, но доступ придётся выдать заново.",
    confirmLabel: "Удалить",
    onConfirm: () => { setConfirm(null); deleteUser(u); },
  });

  const restore = async (u) => {
    try {
      await api.adminRestoreUser(u.id);
      onInfo(`${u.fullName} восстановлен. Доступ к проектам нужно выдать заново.`);
      afterChange();
    } catch (e) {
      onError(e.message);
    }
  };

  const toggleActive = async (u) => {
    try {
      await api.adminUpdateUser(u.id, { isActive: !u.isActive });
      onInfo(u.isActive ? `${u.fullName} заблокирован, сессии завершены` : `${u.fullName} разблокирован`);
      afterChange();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" padded={false} geometryKey="admin-users">
      <div className="px-6 pt-5 pb-4">
        <ModalHeader theme={theme} title="Управление пользователями"
          subtitle="Создание, правка, блокировка и удаление учётных записей"
          onClose={onClose}
          extra={
            <button onClick={() => setEditing("new")} className="btn-primary !py-[7px] !px-4 !text-[13px]">
              <Plus size={15} /> Добавить
            </button>
          } />
        <div className="relative">
          <Search size={15} style={{ color: theme.textMuted }} className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Имя, должность, телефон или почта"
            aria-label="Поиск сотрудников"
            style={inputStyle(theme)} className="w-full pl-10 pr-4 py-2 rounded-full text-[14px] outline-none" />
        </div>
      </div>

      <div style={{ borderColor: theme.border, color: theme.textMuted }}
        className="border-t flex items-center gap-3 px-6 pt-3 pb-1.5 text-[12px] font-medium">
        <span className="flex-1">Сотрудник</span>
        <span>Действия</span>
      </div>
      <div className="max-h-[55vh] overflow-y-auto px-3 pb-2">
        {loading && <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8">Загружаем…</p>}

        {!loading && items.map((u, i) => {
          const isSelf = u.id === currentUser.id;
          return (
            <div key={u.id} style={{ opacity: u.deleted ? 0.65 : 1 }}
              className="group relative rounded-2xl px-3 py-2.5 flex items-center gap-3 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
              {i > 0 && (
                <span style={{ background: theme.border }}
                  className="absolute top-0 left-[60px] right-3 h-px group-hover:opacity-0" aria-hidden />
              )}
              <Avatar user={u} size={36} theme={theme} />

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span style={{ color: theme.text, textDecoration: u.deleted ? "line-through" : "none" }} className="text-[14px] font-semibold truncate">
                    {u.fullName}
                  </span>
                  {u.role === "admin" && (
                    <span title="Администратор системы" style={tone(theme.accent)} className="pill !px-2 !leading-[18px]">
                      <ShieldCheck size={12} /> админ
                    </span>
                  )}
                  {isSelf && (
                    <span style={{ background: theme.surfaceAlt, color: theme.textMuted, boxShadow: `inset 0 0 0 1px ${theme.border}` }}
                      className="pill !px-2 !leading-[18px]">это вы</span>
                  )}
                  {u.deleted ? (
                    <span style={tone(theme.danger)} className="pill !px-2 !leading-[18px]">удалён</span>
                  ) : !u.isActive ? (
                    <span style={tone(theme.warning)} className="pill !px-2 !leading-[18px]">заблокирован</span>
                  ) : u.sessions > 0 ? (
                    <span style={tone(theme.success)} className="pill !px-2 !leading-[18px] tabular-nums" title="Активных сессий">
                      сессий: {u.sessions}
                    </span>
                  ) : null}
                </div>
                <div style={{ color: theme.textMuted }} className="text-[13px] leading-[18px] truncate mt-0.5">
                  {u.email}{u.position ? ` · ${u.position}` : ""}{u.phone ? ` · ${u.phone}` : ""}
                  {u.createdAt && <span className="tabular-nums"> · с {fmtDate(u.createdAt)}</span>}
                </div>
              </div>

              <div className="flex items-center gap-0.5 shrink-0">
                {u.deleted ? (
                  <button onClick={() => restore(u)} className="btn-pill !py-1 !px-3 !text-[13px]"
                    title="Восстановить учётную запись">
                    <RotateCcw size={14} /> Вернуть
                  </button>
                ) : (
                  <>
                    <button onClick={() => setEditing(u)} className="btn-icon"
                      aria-label={`Редактировать: ${u.fullName}`} title="Редактировать">
                      <Pencil size={16} />
                    </button>
                    <button onClick={() => setResetting(u)} className="btn-icon"
                      aria-label={`Задать новый пароль: ${u.fullName}`} title="Задать новый пароль">
                      <KeyRound size={16} />
                    </button>
                    {/* Блокировка и удаление собственной записи недоступны. */}
                    {!isSelf && (
                      <>
                        <button onClick={() => toggleActive(u)}
                          className={`btn-icon ${u.isActive ? "hover:!text-[var(--t-warning)]" : "hover:!text-[var(--t-success)]"}`}
                          aria-label={u.isActive ? `Заблокировать: ${u.fullName}` : `Разблокировать: ${u.fullName}`}
                          title={u.isActive ? "Заблокировать (завершит все сессии)" : "Разблокировать"}>
                          {u.isActive ? <Ban size={16} /> : <Check size={16} />}
                        </button>
                        <button onClick={() => remove(u)} className="btn-icon hover:!text-[var(--t-danger)]"
                          aria-label={`Удалить: ${u.fullName}`} title="Удалить">
                          <Trash2 size={16} />
                        </button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })}

        {!loading && items.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8">Никого не найдено.</p>
        )}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t px-6 py-3 flex items-center justify-between">
        <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">Всего: {total}</span>
        {pages > 1 && (
          <div className="flex items-center gap-2">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
              className="btn-pill !py-1 !px-3 !text-[13px] disabled:opacity-40 disabled:cursor-default">
              <ChevronLeft size={14} /> Назад
            </button>
            <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums px-1">{page} из {pages}</span>
            <button onClick={() => setPage((p) => Math.min(pages, p + 1))} disabled={page === pages}
              className="btn-pill !py-1 !px-3 !text-[13px] disabled:opacity-40 disabled:cursor-default">
              Далее <ChevronRight size={14} />
            </button>
          </div>
        )}
      </div>

      {editing && (
        <UserForm theme={theme} user={editing === "new" ? null : editing} currentUser={currentUser}
          onClose={() => setEditing(null)}
          onSaved={(msg) => { setEditing(null); onInfo(msg); afterChange(); }}
          onError={onError} />
      )}

      {resetting && (
        <PasswordForm theme={theme} user={resetting} onClose={() => setResetting(null)}
          onSaved={(msg) => { setResetting(null); onInfo(msg); afterChange(); }} onError={onError} />
      )}

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
      {successorFor && (
        <SuccessorDialog theme={theme} user={successorFor}
          onCancel={() => setSuccessorFor(null)}
          onConfirm={(successorId) => deleteUser(successorFor, successorId)}
          onError={onError} />
      )}
    </Modal>
  );
}

// Компонент UserForm предназначен для создания и изменения учётной записи.
function UserForm({ theme, user, currentUser, onClose, onSaved, onError }) {
  const isNew = !user;
  const [form, setForm] = useState({
    email: user?.email || "",
    fullName: user?.fullName || "",
    position: user?.position || "",
    phone: user?.phone || "",
    role: user?.role || "member",
    password: "",
  });
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const isSelf = user && user.id === currentUser.id;

  const submit = async () => {
    if (!form.email.includes("@") || !form.fullName.trim()) {
      onError("Нужны корректный адрес почты и имя");
      return;
    }
    // Требование к паролю совпадает с серверным (см. lib/password.js): восемь символов и три типа символов из четырёх.
    if (isNew && !checkPassword(form.password).valid) {
      onError(checkPassword(form.password).error || PASSWORD_RULE);
      return;
    }
    setBusy(true);
    try {
      if (isNew) {
        await api.adminCreateUser({
          email: form.email.trim(), password: form.password, fullName: form.fullName.trim(),
          position: form.position.trim(), phone: form.phone.trim(), role: form.role,
        });
        onSaved(`Учётная запись ${form.fullName.trim()} создана`);
      } else {
        await api.adminUpdateUser(user.id, {
          email: form.email.trim(), fullName: form.fullName.trim(),
          position: form.position.trim(), phone: form.phone.trim(), role: form.role,
        });
        onSaved("Изменения сохранены");
      }
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="admin-user-form">
      <ModalHeader theme={theme} title={isNew ? "Новый пользователь" : "Редактирование"} onClose={onClose} />

      <Field label="ФИО" theme={theme}>
        <input value={form.fullName} onChange={(e) => set("fullName", e.target.value)} autoFocus
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" placeholder="Иванов Иван" />
      </Field>
      <Field label="Электронная почта" theme={theme}>
        <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" placeholder="name@team.dev" />
      </Field>
      <Field label="Должность" theme={theme}>
        <input value={form.position} onChange={(e) => set("position", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
      </Field>
      <Field label="Телефон" theme={theme}>
        <input value={form.phone} onChange={(e) => set("phone", e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" placeholder="+7 900 000-00-00" />
      </Field>

      {isNew && (
        <Field label="Пароль" theme={theme} hint="Сообщите его пользователю лично — он сможет сменить пароль сам.">
          <PasswordInput theme={theme} value={form.password} onChange={(e) => set("password", e.target.value)}
            className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
          <div className="mt-2"><PasswordRules theme={theme} value={form.password} /></div>
        </Field>
      )}

      <Field label="Роль в системе" theme={theme}
        hint={isSelf
          ? "Снять права у себя нельзя, если вы единственный администратор."
          : "Администратор управляет всеми учётными записями. Роли на досках задаются отдельно, в настройках каждого проекта."}>
        <div className="segmented w-full" role="group" aria-label="Роль в системе">
          {[["member", "Участник", UserIcon], ["admin", "Администратор", ShieldCheck]].map(([value, label, Icon]) => (
            <button key={value} onClick={() => set("role", value)} aria-pressed={form.role === value}
              className="flex-1 flex items-center justify-center gap-1.5">
              <Icon size={14} /> {label}
            </button>
          ))}
        </div>
      </Field>

      <button onClick={submit} disabled={busy}
        className="btn-primary w-full !py-2.5 disabled:opacity-50 disabled:cursor-default mt-2">
        {busy ? "Сохраняем…" : isNew ? "Создать" : "Сохранить"}
      </button>
    </Modal>
  );
}

// Компонент PasswordForm предназначен для установки пароля пользователя администратором.
function PasswordForm({ theme, user, onClose, onSaved, onError }) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!checkPassword(password).valid) {
      onError(checkPassword(password).error || PASSWORD_RULE);
      return;
    }
    setBusy(true);
    try {
      await api.adminResetPassword(user.id, password);
      onSaved(`Пароль изменён, все сессии ${user.fullName} завершены`);
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="admin-password">
      <ModalHeader theme={theme} title="Новый пароль" subtitle={user.fullName} onClose={onClose} />
      <Field label="Пароль" theme={theme}
        hint="Все текущие сессии пользователя будут завершены — ему потребуется войти заново.">
        <PasswordInput theme={theme} value={password} onChange={(e) => setPassword(e.target.value)} autoFocus
          onKeyDown={(e) => e.key === "Enter" && submit()}
          className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
        <div className="mt-2"><PasswordRules theme={theme} value={password} /></div>
      </Field>
      <button onClick={submit} disabled={busy}
        className="btn-primary w-full !py-2.5 disabled:opacity-50 disabled:cursor-default mt-2">
        {busy ? "Сохраняем…" : "Задать пароль"}
      </button>
    </Modal>
  );
}

// Компонент SuccessorDialog предназначен для выбора преемника при удалении пользователя, владеющего проектами, диаграммами,
// досками или групповыми чатами: без владельца объект нельзя удалить или передать.
function SuccessorDialog({ theme, user, onCancel, onConfirm, onError }) {
  const [people, setPeople] = useState([]);
  const [successorId, setSuccessorId] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.directory()
      .then((list) => setPeople(list
        .filter((u) => !u.deleted && u.id !== user.id)
        .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"))))
      .catch((e) => onError(e.message));
  }, [user.id, onError]);

  return (
    <Modal theme={theme} onClose={onCancel} width="max-w-md">
      <ModalHeader theme={theme} title="Кому передать проекты?"
        subtitle={`${user.fullName} владеет проектами — у них должен остаться владелец`}
        onClose={onCancel} />
      <Field theme={theme} label="Преемник">
        <select value={successorId} onChange={(e) => setSuccessorId(e.target.value)}
          style={inputStyle(theme)} className="w-full px-3 py-2 rounded-xl text-[14px] outline-none">
          <option value="">Выберите сотрудника…</option>
          {people.map((u) => (
            <option key={u.id} value={u.id}>{u.fullName}{u.position ? ` — ${u.position}` : ""}</option>
          ))}
        </select>
      </Field>
      <p style={{ color: theme.textMuted }} className="text-[13px] mt-2 mb-5">
        Преемник станет владельцем всех проектов, диаграмм, досок и групповых чатов сотрудника.
      </p>
      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="btn-pill">
          Отмена
        </button>
        <button disabled={!successorId || busy}
          onClick={async () => { setBusy(true); await onConfirm(successorId); setBusy(false); }}
          style={{ background: theme.danger, color: "#fff", borderColor: "transparent", opacity: successorId && !busy ? 1 : 0.5 }}
          className="btn-pill !font-semibold transition-[filter] hover:brightness-110 disabled:cursor-default">
          Передать и удалить
        </button>
      </div>
    </Modal>
  );
}
