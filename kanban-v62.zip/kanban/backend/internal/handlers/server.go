// Модуль предназначен для сборки HTTP-приложения Fiber: создание Server, подключение метрик, middleware,
// регистрация всех маршрутов API и раздача собранного фронтенда.

package handlers

import (
	"path/filepath"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/fiber/v2/middleware/requestid"
	"github.com/gofiber/websocket/v2"
	"github.com/google/uuid"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/database"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/metrics"
	mw "github.com/example/kanban/internal/middleware"
	"github.com/example/kanban/internal/realtime"
	"github.com/example/kanban/internal/storage"
)

// Тип Server предназначен для хранения зависимостей обработчиков: конфигурация, БД, токены, хранилище, хаб, метрики.
type Server struct {
	cfg   *config.Config
	db    *database.DB
	auth  *auth.Manager
	files *storage.Local
	hub   *realtime.Hub
	// Метрики и опрос БД; значение nil отключает измерения.
	metrics *metrics.Registry
	pgStats *metrics.PGCollector
	// История показаний для встроенного дашборда администратора.
	samples *metrics.Sampler
}

// Функция New предназначена для создания Server.
func New(cfg *config.Config, db *database.DB, am *auth.Manager, files *storage.Local, hub *realtime.Hub) *Server {
	return &Server{cfg: cfg, db: db, auth: am, files: files, hub: hub}
}

// Метод WithMetrics предназначен для подключения сбора метрик после создания пула соединений.
func (s *Server) WithMetrics(reg *metrics.Registry, pg *metrics.PGCollector,
	sampler *metrics.Sampler) *Server {

	s.metrics = reg
	s.pgStats = pg
	s.samples = sampler
	if reg == nil {
		return s
	}

	// Состояние пула регистрируется датчиками, считываемыми при выдаче метрик.
	reg.Gauge("kanban_db_pool_total", func() float64 { return float64(s.db.Stats().TotalConns()) })
	reg.Gauge("kanban_db_pool_acquired", func() float64 { return float64(s.db.Stats().AcquiredConns()) })
	reg.Gauge("kanban_db_pool_idle", func() float64 { return float64(s.db.Stats().IdleConns()) })
	reg.Gauge("kanban_db_pool_max", func() float64 { return float64(s.db.Stats().MaxConns()) })
	// Число запросов, ожидавших соединение; рост показывает недостаточный размер пула.
	reg.Gauge("kanban_db_pool_empty_acquires", func() float64 {
		return float64(s.db.Stats().EmptyAcquireCount())
	})
	reg.Gauge("kanban_ws_users", func() float64 { return float64(s.hub.ConnectedUsers()) })
	reg.Gauge("kanban_ws_connections", func() float64 { return float64(s.hub.Connections()) })

	s.db.SetObserver(func(op string, d time.Duration, failed bool) {
		reg.DBQuery(op, d, failed)
	})
	s.hub.SetObserver(func(kind string) { reg.WSEvent(kind) })
	return s
}

// Метод App предназначен для сборки Fiber-приложения. Prefork включается настройкой; процессы prefork имеют раздельные
// списки WebSocket, счётчики лимита и опрос напоминаний (первое устраняется Redis, третье — блокировкой БД).
func (s *Server) App() *fiber.App {
	app := fiber.New(fiber.Config{
		AppName:               s.cfg.AppName,
		DisableStartupMessage: false,

		// Число процессов задаётся через GOMAXPROCS в main.
		Prefork: s.cfg.Prefork,

		// Адрес клиента берётся из X-Forwarded-For только от доверенных прокси (TrustedProxies); иначе лимит частоты считается по адресу прокси.
		ProxyHeader:             proxyHeader(s.cfg.TrustedProxies),
		EnableTrustedProxyCheck: len(s.cfg.TrustedProxies) > 0,
		TrustedProxies:          s.cfg.TrustedProxies,
		BodyLimit:               int(s.cfg.MaxUploadBytes) + (2 << 20),
		ReadTimeout:             s.cfg.ReadTimeout,
		WriteTimeout:            s.cfg.WriteTimeout, // с запасом на отдачу больших файлов
		IdleTimeout:             s.cfg.IdleTimeout,
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			if fe, ok := err.(*fiber.Error); ok {
				return httpx.JSON(c, fe.Code, httpx.ErrorBody{Error: fe.Message, Code: "http_error"})
			}
			return httpx.Fail(c, err)
		},
	})

	app.Use(requestid.New())
	// Ответы API сжимаются gzip (быстрый уровень): JSON со списками задач уменьшается в 5–10 раз. Не сжимаются WebSocket,
	// запросы с Range и выдача файлов (они уже сжаты или отдаются потоком); раздача фронтенда использует предсжатые файлы.
	app.Use(compress.New(compress.Config{
		Level: compress.LevelBestSpeed,
		Next: func(c *fiber.Ctx) bool {
			p := c.Path()
			return !strings.HasPrefix(p, "/api") || p == "/api/ws" || c.Get("Range") != "" ||
				strings.Contains(p, "/file") || strings.Contains(p, "/avatar") || strings.Contains(p, "/pdf")
		},
	}))
	app.Use(recover.New(recover.Config{EnableStackTrace: !s.cfg.IsProduction()}))
	app.Use(logger.New(logger.Config{
		Format: "${time} ${status} ${latency} ${method} ${path} reqid=${locals:requestid}\n",
	}))
	app.Use(cors.New(cors.Config{
		AllowOrigins:     joinOrigins(s.cfg.AllowedOrigins),
		AllowMethods:     "GET,POST,PATCH,PUT,DELETE,OPTIONS",
		AllowHeaders:     "Authorization,Content-Type,X-Request-Id,X-Timezone",
		ExposeHeaders:    "X-Request-Id",
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// Измерение каждого запроса; middleware стоит после recover и logger и до маршрутов, чтобы учитывать отказы лимита и ошибки аутентификации.
	if s.metrics != nil {
		app.Use(func(c *fiber.Ctx) error {
			// Запросы к /metrics не измеряются.
			if c.Path() == "/metrics" {
				return c.Next()
			}
			start := time.Now()
			s.metrics.RequestStarted()
			err := c.Next()
			s.metrics.RequestEnded()

			route := c.Route().Path
			if route == "" || route == "/*" {
				// Статика и клиентские маршруты получают единую метку маршрута.
				route = "static"
			}
			status := c.Response().StatusCode()
			if err != nil {
				// При ошибке обработчика код ответа берётся из ошибки.
				if fe, ok := err.(*fiber.Error); ok {
					status = fe.Code
				} else {
					status = fiber.StatusInternalServerError
				}
			}
			// strings.Clone необходим: Fiber возвращает метод как строку поверх буфера запроса.
			s.metrics.Request(strings.Clone(c.Method()), route, status,
				time.Since(start), len(c.Response().Body()))
			return err
		})

		// Выдача метрик без аутентификации; доступ ограничивается на уровне сети.
		app.Get("/metrics", func(c *fiber.Ctx) error {
			c.Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
			out := s.metrics.Render()
			if s.pgStats != nil {
				out += s.pgStats.Text()
			}
			return c.SendString(out)
		})
	}

	app.Get("/healthz", func(c *fiber.Ctx) error {
		stat := s.db.Stats()
		return httpx.JSON(c, fiber.StatusOK, fiber.Map{
			"status":        "ok",
			"wsConnections": s.hub.ConnectedUsers(),
			"dbConnsInUse":  stat.AcquiredConns(),
			"dbConnsIdle":   stat.IdleConns(),
			"dbConnsTotal":  stat.TotalConns(),
			"dbConnsMax":    stat.MaxConns(),
		})
	})

	api := app.Group("/api")

	// Публичные настройки интерфейса из конфигурации (название, видеозвонки, групповая почта); без авторизации, секретов нет.
	api.Get("/public-config", func(c *fiber.Ctx) error {
		return httpx.JSON(c, fiber.StatusOK, fiber.Map{
			"appName":               s.cfg.AppName,
			"videoCalls":            s.cfg.VideoCalls,
			"groupEmail":            s.cfg.GroupEmail,
			"allowSelfRegistration": s.cfg.AllowSelfRegistration,
		})
	})

	// Публичные маршруты. Вход и регистрация ограничены жёстко (защита от перебора паролей). Обновление сессии и выход
	// ограничены мягко: за одним адресом (NAT, обратный прокси) работает много людей, и отказ в обновлении
	// выглядел бы для них как внезапный выход из системы.
	loginLimit := limiter.New(limiter.Config{
		Max:          60,
		Expiration:   time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
	})
	sessionLimit := limiter.New(limiter.Config{
		Max:          3000,
		Expiration:   time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
	})
	api.Post("/auth/register", loginLimit, s.Register)
	api.Post("/auth/login", loginLimit, s.Login)
	api.Post("/auth/refresh", sessionLimit, s.Refresh)
	api.Post("/auth/logout", sessionLimit, s.Logout)

	// WebSocket аутентифицируется отдельно (wsAuth): токен передаётся параметром запроса.
	api.Get("/ws", s.wsAuth, websocket.New(s.wsHandler, websocket.Config{
		HandshakeTimeout: 10 * time.Second,
	}))

	// Остальные маршруты API: access-токен и общий лимит частоты по IP.
	private := api.Group("", limiter.New(limiter.Config{
		Max:          s.cfg.RateLimitPerMin,
		Expiration:   time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
	}), mw.Auth(s.auth))

	private.Get("/me", s.Me)
	private.Patch("/me", s.UpdateMe)
	private.Post("/me/password", s.ChangePassword)

	private.Get("/users", s.Directory)
	private.Get("/team", s.GetTeam)
	private.Put("/team", s.SetTeam)
	// Группы команды для выбора исполнителей.
	private.Get("/team/groups", s.ListTeamGroups)
	private.Put("/team/groups", s.SaveTeamGroups)

	private.Get("/notifications", s.ListNotifications)
	private.Post("/notifications/:id/read", s.ReadNotification)
	private.Post("/notifications/read-all", s.ReadAllNotifications)
	// Настройки категорий уведомлений.
	private.Get("/preferences/:key", s.GetPreference)
	private.Put("/preferences/:key", s.SetPreference)
	private.Get("/notification-prefs", s.GetNotificationPrefs)
	private.Put("/notification-prefs", s.SetNotificationPref)

	// Напоминания.
	private.Get("/reminders", s.ListReminders)
	private.Post("/reminders", s.CreateReminder)
	private.Patch("/reminders/:reminderID", s.UpdateReminder)
	private.Delete("/reminders/:reminderID", s.DeleteReminder)
	// Перенос сработавшего напоминания.
	private.Post("/reminders/:reminderID/snooze", s.SnoozeReminder)
	// Журнал сработавших напоминаний: показ при входе и подтверждение.
	private.Get("/reminder-alerts", s.ListReminderAlerts)
	private.Post("/reminder-alerts/:alertID/ack", s.AckReminderAlert)

	boards := private.Group("/boards")
	boards.Get("/", s.ListBoards)
	boards.Post("/", s.CreateBoard)
	boards.Get("/:boardID", s.GetBoard)
	boards.Patch("/:boardID", s.UpdateBoard)
	boards.Delete("/:boardID", s.DeleteBoard)
	boards.Post("/:boardID/background", s.UploadBackground)
	boards.Get("/:boardID/background", s.GetBackground)
	boards.Delete("/:boardID/background", s.DeleteBackground)
	boards.Put("/:boardID/members", s.SetMembers)
	boards.Get("/:boardID/columns", s.ListColumns)
	boards.Put("/:boardID/columns", s.SaveColumns)
	boards.Get("/:boardID/tasks", s.ListTasks)
	boards.Post("/:boardID/tasks", s.CreateTask)

	// Диаграммы: собственные сущности и права.
	charts := private.Group("/charts")
	charts.Get("/", s.ListCharts)
	charts.Post("/", s.CreateChart)
	charts.Get("/:chartID", s.GetChart)
	charts.Patch("/:chartID", s.UpdateChart)
	charts.Delete("/:chartID", s.DeleteChart)
	charts.Put("/:chartID/members", s.SetChartMembers)
	// Приглашения участников.
	charts.Post("/:chartID/invite", s.InviteToChart)
	charts.Get("/:chartID/items", s.ListChartItems)
	charts.Post("/:chartID/items", s.CreateChartItem)
	charts.Patch("/:chartID/items/:itemID", s.UpdateChartItem)
	charts.Delete("/:chartID/items/:itemID", s.DeleteChartItem)
	// Обсуждение и файлы этапа.
	charts.Get("/:chartID/items/:itemID/comments", s.ListChartComments)
	charts.Get("/:chartID/items/:itemID/activity", s.ListChartActivity)
	charts.Post("/:chartID/items/:itemID/comments", s.AddChartComment)
	charts.Delete("/:chartID/items/:itemID/comments/:commentID", s.DeleteChartComment)
	charts.Post("/:chartID/items/:itemID/files", s.UploadChartFile)
	charts.Delete("/:chartID/items/:itemID/files/:fileID", s.DeleteChartFile)
	private.Get("/chart-files/:fileID", s.DownloadChartFile)
	private.Get("/chart-files/:fileID/pdf", s.PreviewChartFile)

	// Совместные доски; фигуры изменяются по одной.
	wb := private.Group("/whiteboards")
	wb.Get("/", s.ListWhiteboards)
	wb.Post("/", s.CreateWhiteboard)
	wb.Get("/:wbID", s.GetWhiteboard)
	wb.Patch("/:wbID", s.UpdateWhiteboard)
	wb.Delete("/:wbID", s.DeleteWhiteboard)
	wb.Put("/:wbID/members", s.SetWhiteboardMembers)
	wb.Post("/:wbID/invite", s.InviteToWhiteboard)
	wb.Get("/:wbID/shapes", s.ListShapes)
	wb.Post("/:wbID/shapes", s.CreateShape)
	wb.Patch("/:wbID/shapes/:shapeID", s.UpdateShape)
	wb.Delete("/:wbID/shapes/:shapeID", s.DeleteShape)
	wb.Post("/:wbID/clear", s.ClearWhiteboard)
	wb.Post("/:wbID/shapes/:shapeID/order", s.ReorderShape)

	// Значки досок.
	private.Get("/board-icons", s.ListBoardIcons)
	private.Post("/board-icons", s.UploadBoardIcon)
	private.Get("/board-icons/:iconID/file", s.DownloadBoardIcon)
	private.Delete("/board-icons/:iconID", s.DeleteBoardIcon)

	// Отметки о просмотре.
	private.Post("/views", s.MarkSeen)
	// Присутствие пользователей.
	private.Get("/presence", s.Presence)

	// Чаты.
	private.Get("/chats", s.ListChats)
	private.Post("/chats", s.CreateChat)
	chats := private.Group("/chats/:chatID")
	chats.Patch("/", s.RenameChat)
	chats.Post("/members", s.AddChatMember)
	chats.Delete("/members/:userID", s.RemoveChatMember)
	chats.Get("/messages", s.ListMessages)
	chats.Post("/messages", s.SendMessage)
	chats.Post("/files", s.UploadChatFile)
	chats.Post("/read", s.MarkChatRead)
	chats.Delete("/", s.DeleteChat)
	chats.Post("/clear", s.ClearChat)
	chats.Post("/avatar", s.SetChatAvatar)
	chats.Get("/avatar", s.DownloadChatAvatar)
	chats.Get("/polls", s.ListPolls)
	chats.Post("/polls", s.CreatePoll)
	private.Post("/poll-options/:optionID/vote", s.Vote)
	private.Post("/polls/:pollID/close", s.ClosePoll)
	private.Get("/messages/:messageID/file", s.DownloadChatFile)
	private.Get("/messages/:messageID/pdf", s.PreviewChatFile)
	private.Patch("/messages/:messageID", s.EditMessage)
	private.Delete("/messages/:messageID", s.DeleteMessage)

	private.Get("/inbox", s.Inbox)
	// Сводный список доступных задач.
	private.Get("/tasks", s.AllTasks)

	tasks := private.Group("/tasks/:taskID")
	tasks.Get("/", s.GetTask)
	tasks.Patch("/", s.UpdateTask)
	tasks.Delete("/", s.DeleteTask)
	tasks.Post("/move", s.MoveTask)
	tasks.Post("/copy", s.CopyTask)
	// Перенос задачи в другой проект; путь /transfer, так как /move перемещает карточку между колонками.
	tasks.Post("/transfer", s.TransferTask)
	// Готовность к сдаче.
	tasks.Post("/ready", s.SetTaskReady)
	tasks.Post("/complete", s.CompleteTask)
	// Отметка исполнителя о своей части.
	tasks.Post("/assignment", s.CompleteAssignment)
	tasks.Get("/links", s.ListTaskLinks)
	tasks.Post("/links", s.CreateTaskLink)
	tasks.Post("/steps", s.CreateStep)
	tasks.Patch("/steps/:stepID", s.RenameStep)
	tasks.Post("/steps/:stepID/toggle", s.ToggleStep)
	tasks.Delete("/steps/:stepID", s.DeleteStep)
	tasks.Patch("/report", s.SetReport)
	tasks.Get("/comments", s.ListComments)
	tasks.Post("/comments", s.CreateComment)
	tasks.Get("/attachments", s.ListAttachments)
	tasks.Post("/attachments", s.UploadAttachment)
	tasks.Get("/activity", s.ListActivity)
	tasks.Put("/grants", s.SetGrants)

	private.Patch("/comments/:id", s.UpdateComment)
	private.Delete("/comments/:id", s.DeleteComment)

	private.Get("/attachments/:id/content", s.DownloadAttachment)
	// PDF-версия вложения.
	private.Get("/attachments/:id/pdf", s.PreviewAttachment)
	private.Patch("/attachments/:id", s.RenameAttachment)
	private.Delete("/attachments/:id", s.DeleteAttachment)

	// Администрирование учётных записей: RequireAdmin проверяет права запросом к БД на каждый вызов.
	private.Get("/calendar", s.Calendar)

	private.Get("/dashboard", s.Dashboard)
	private.Get("/dashboard/users/:userID/tasks", s.DashboardUserTasks)
	private.Get("/dashboard/tasks", s.DashboardTasks)

	private.Get("/delegations", s.ListDelegations)
	// Действующие замещения сотрудников.
	private.Get("/delegations/active", s.ActiveDelegations)
	private.Post("/delegations", s.CreateDelegation)
	private.Delete("/delegations/:id", s.DeleteDelegation)

	private.Get("/templates", s.ListTemplates)
	private.Post("/templates", s.CreateTemplate)
	private.Delete("/templates/:id", s.DeleteTemplate)
	private.Post("/templates/:id/apply", s.ApplyTemplate)

	private.Delete("/links/:id", s.DeleteTaskLink)

	// Панель «Доступы»: права проверяют SQL-функции миграции 0027.
	access := private.Group("/access")
	access.Get("/users/:userID", s.AccessOverview)
	access.Get("/boards", s.AccessManageableBoards)
	access.Get("/matrix/:userID", s.AccessMatrix)
	access.Put("/:kind<regex(charts|whiteboards)>/:objectID/members/:userID", s.SetObjectAccess)
	access.Delete("/:kind<regex(charts|whiteboards)>/:objectID/members/:userID", s.RevokeObjectAccess)
	access.Put("/boards/:boardID/members/:userID", s.SetBoardAccess)
	access.Delete("/boards/:boardID/members/:userID", s.RevokeBoardAccess)
	access.Put("/tasks/:taskID/grants/:userID", s.SetTaskAccess)
	access.Delete("/tasks/:taskID/grants/:userID", s.RevokeTaskAccess)

	admin := private.Group("/admin", s.RequireAdmin)
	admin.Get("/users", s.AdminListUsers)
	admin.Post("/users", s.AdminCreateUser)
	admin.Patch("/users/:userID", s.AdminUpdateUser)
	admin.Delete("/users/:userID", s.AdminDeleteUser)
	admin.Post("/users/:userID/restore", s.AdminRestoreUser)
	admin.Post("/users/:userID/password", s.AdminResetPassword)
	admin.Get("/system", s.AdminSystem)
	// Копирование доступа коллеги (онбординг).
	admin.Post("/users/:userID/copy-access", s.AdminCopyAccess)

	// Раздача собранного фронтенда регистрируется после маршрутов API. Неизвестные пути возвращают index.html для клиентской маршрутизации.
	if s.cfg.StaticDir != "" {
		static := newStaticServer(s.cfg.StaticDir)
		app.Use(func(c *fiber.Ctx) error {
			if strings.HasPrefix(c.Path(), "/api") {
				return c.Next()
			}
			if ok, err := static.handle(c); ok || err != nil {
				return err
			}
			return c.Next()
		})

		indexFile := filepath.Join(s.cfg.StaticDir, "index.html")
		app.Use(func(c *fiber.Ctx) error {
			// Неизвестный путь внутри /api возвращает ошибку, а не HTML.
			if strings.HasPrefix(c.Path(), "/api") {
				return httpx.Fail(c, httpx.ErrNotFound)
			}
			if c.Method() != fiber.MethodGet {
				return httpx.Fail(c, httpx.ErrNotFound)
			}
			// index.html отдаётся тем же путём с предсжатием и ETag.
			c.Path("/index.html")
			if ok, err := static.handle(c); ok || err != nil {
				return err
			}
			return c.SendFile(indexFile)
		})
	}

	return app
}

// Метод uid предназначен для получения идентификатора пользователя из контекста запроса.
func (s *Server) uid(c *fiber.Ctx) uuid.UUID { return mw.UserID(c) }

// Функция param предназначена для разбора UUID из параметра маршрута.
func param(c *fiber.Ctx, name string) (uuid.UUID, error) {
	return httpx.UUIDParam(c, name)
}

// Функция joinOrigins предназначена для объединения списка источников CORS в строку.
func joinOrigins(origins []string) string {
	out := ""
	for i, o := range origins {
		if i > 0 {
			out += ","
		}
		out += o
	}
	return out
}

// Функция proxyHeader предназначена для включения разбора X-Forwarded-For только при непустом списке доверенных прокси.
func proxyHeader(trusted []string) string {
	if len(trusted) == 0 {
		return ""
	}
	return fiber.HeaderXForwardedFor
}
