// Модуль предназначен для раздачи собранного фронтенда: выбор предсжатого варианта (.br, .gz) по Accept-Encoding,
// ETag с ответом 304, долгий кэш для файлов с хешем в имени и no-cache для index.html.

package handlers

import (
	"crypto/sha1"
	"encoding/hex"
	"mime"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/gofiber/fiber/v2"
)

// Тип staticEntry предназначен для описания файла в кэше раздачи: путь, ETag и тип содержимого.
type staticEntry struct {
	path, etag, ctype string
	mod               int64
	size              int64
}

// Тип staticServer предназначен для раздачи файлов каталога с кэшем метаданных (ETag считается один раз на версию файла).
type staticServer struct {
	root  string
	mu    sync.RWMutex
	cache map[string]staticEntry
}

// Функция newStaticServer предназначена для создания раздачи файлов каталога root.
func newStaticServer(root string) *staticServer {
	return &staticServer{root: root, cache: map[string]staticEntry{}}
}

// Метод lookup предназначен для получения метаданных файла; запись обновляется при изменении времени или размера.
func (s *staticServer) lookup(full string) (staticEntry, bool) {
	st, err := os.Stat(full)
	if err != nil || st.IsDir() {
		return staticEntry{}, false
	}
	s.mu.RLock()
	e, ok := s.cache[full]
	s.mu.RUnlock()
	if ok && e.mod == st.ModTime().UnixNano() && e.size == st.Size() {
		return e, true
	}
	data, err := os.ReadFile(full)
	if err != nil {
		return staticEntry{}, false
	}
	sum := sha1.Sum(data)
	e = staticEntry{
		path: full, mod: st.ModTime().UnixNano(), size: st.Size(),
		etag: `"` + hex.EncodeToString(sum[:8]) + `"`,
	}
	s.mu.Lock()
	s.cache[full] = e
	s.mu.Unlock()
	return e, true
}

// Функция acceptsEncoding предназначена для проверки, что клиент принимает кодировку (с учётом q=0).
func acceptsEncoding(header, enc string) bool {
	for _, part := range strings.Split(header, ",") {
		fields := strings.Split(strings.TrimSpace(part), ";")
		if strings.TrimSpace(fields[0]) != enc {
			continue
		}
		for _, f := range fields[1:] {
			f = strings.ReplaceAll(strings.TrimSpace(f), " ", "")
			if f == "q=0" || f == "q=0.0" {
				return false
			}
		}
		return true
	}
	return false
}

// Метод handle предназначен для обработки GET/HEAD-запроса файла; возвращает false, если файла нет (тогда работает возврат index.html).
func (s *staticServer) handle(c *fiber.Ctx) (bool, error) {
	if c.Method() != fiber.MethodGet && c.Method() != fiber.MethodHead {
		return false, nil
	}
	rel := filepath.Clean("/" + c.Path())
	if rel == "/" {
		rel = "/index.html"
	}
	full := filepath.Join(s.root, rel)
	if !strings.HasPrefix(full, filepath.Clean(s.root)) {
		return false, nil
	}
	base, ok := s.lookup(full)
	if !ok {
		return false, nil
	}

	// Предсжатый вариант: brotli предпочтительнее gzip.
	send, enc := base, ""
	ae := c.Get(fiber.HeaderAcceptEncoding)
	if acceptsEncoding(ae, "br") {
		if e, ok := s.lookup(full + ".br"); ok {
			send, enc = e, "br"
		}
	}
	if enc == "" && acceptsEncoding(ae, "gzip") {
		if e, ok := s.lookup(full + ".gz"); ok {
			send, enc = e, "gzip"
		}
	}

	ctype := mime.TypeByExtension(filepath.Ext(full))
	if ctype == "" {
		ctype = "application/octet-stream"
	}
	c.Set(fiber.HeaderVary, "Accept-Encoding")
	c.Set(fiber.HeaderETag, send.etag)
	// Файлы /assets/ содержат хеш в имени и не меняются; остальные (index.html, значки) проверяются при каждой загрузке.
	if strings.HasPrefix(rel, "/assets/") {
		c.Set(fiber.HeaderCacheControl, "public, max-age=31536000, immutable")
	} else {
		c.Set(fiber.HeaderCacheControl, "no-cache")
	}
	if c.Get(fiber.HeaderIfNoneMatch) == send.etag {
		return true, c.SendStatus(fiber.StatusNotModified)
	}
	if enc != "" {
		c.Set(fiber.HeaderContentEncoding, enc)
	}
	c.Set(fiber.HeaderContentType, ctype)
	data, err := os.ReadFile(send.path)
	if err != nil {
		return false, nil
	}
	if c.Method() == fiber.MethodHead {
		return true, nil
	}
	return true, c.Send(data)
}
