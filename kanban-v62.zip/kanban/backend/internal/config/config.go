// Модуль предназначен для загрузки конфигурации приложения из значений по умолчанию,
// config.yaml и переменных окружения (приоритет по возрастанию) и для проверки обязательных параметров.

package config

import (
	"crypto/rand"
	"fmt"
	"log/slog"
	"os"
	"strconv"
	"strings"
	"time"
)

// Тип Config предназначен для хранения всех параметров приложения.
type Config struct {
	Addr            string
	DatabaseURL     string
	JWTSecret       []byte
	AccessTTL       time.Duration
	RefreshTTL      time.Duration
	// Окно допуска повторного предъявления уже обменянного refresh-токена (гонка вкладок, потерянный ответ).
	RefreshReuseGrace time.Duration
	AllowedOrigins  []string
	UploadDir       string
	// Каталог временных файлов конвертации документов в PDF; отделён от UploadDir.
	ConvertDir string
	MaxUploadBytes  int64
	RateLimitPerMin int
	// Признак разрешения самостоятельной регистрации.
	AllowSelfRegistration bool
	// Каталог собранного фронтенда; при заданном значении сервер отдаёт статику и API на одном порту.
	StaticDir string
	// Адреса обратных прокси, которым доверяется заголовок X-Forwarded-For.
	TrustedProxies []string

	// Возможности, управляемые конфигурацией: видеовызовы (кнопки «Видеозвонок» и «Видеоконференция»).
	VideoCalls bool
	// Массовая почтовая рассылка участникам задачи.
	GroupEmail bool
	// Название приложения в интерфейсе и в заголовке вкладки.
	AppName string
	Env             string

	// Размер пула соединений с БД и число соединений, удерживаемых в простое.
	DBPoolSize    int
	DBMinIdle     int
	StatementCache bool

	// Таймауты HTTP-сервера.
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
	IdleTimeout  time.Duration

	// Prefork: несколько процессов на одном порту. Требует общей шины событий (Redis),
	// так как соединения WebSocket, счётчики лимита и опрос напоминаний у процессов раздельные.
	Prefork bool

	// Метрики Prometheus на /metrics. Адрес открыт без токена и ограничивается на уровне прокси.
	Metrics bool
	// Число процессов prefork; 0 означает число ядер.
	PreforkWorkers int

	// Адрес Redis в формате host:port; пустое значение отключает общую шину.
	RedisAddr     string
	RedisPassword string
	RedisDB       int
	// Канал публикации событий; разделяет установки, использующие один Redis.
	RedisChannel string
}

// Функция Load предназначена для сборки конфигурации: значения по умолчанию, затем config.yaml,
// затем переменные окружения. Пустой путь означает поиск ./config.yaml без обязательности файла.
func Load(explicitPath string) (*Config, error) {
	c := &Config{
		Addr:            env("APP_ADDR", ":8080"),
		DatabaseURL:     os.Getenv("DATABASE_URL"),
		JWTSecret:       []byte(os.Getenv("JWT_SECRET")),
		AccessTTL:       envDuration("ACCESS_TTL", time.Hour),
		RefreshTTL:      envDuration("REFRESH_TTL", 720*time.Hour),
		RefreshReuseGrace: envDuration("REFRESH_REUSE_GRACE", 96*time.Hour),
		AllowedOrigins:  strings.Split(env("ALLOWED_ORIGINS", "http://localhost:5173"), ","),
		UploadDir:       env("UPLOAD_DIR", defaultUploadDir),
		ConvertDir:      env("CONVERT_DIR", defaultConvertDir),
		MaxUploadBytes:  int64(envInt("MAX_UPLOAD_MB", 25)) << 20,
		RateLimitPerMin: envInt("RATE_LIMIT_PER_MIN", 600),
		Metrics:               envBool("METRICS_ENABLED", true),
		AllowSelfRegistration: envBool("ALLOW_SELF_REGISTRATION", false),
		StaticDir:             env("STATIC_DIR", ""),
		TrustedProxies:        splitList(env("TRUSTED_PROXIES", "")),
		VideoCalls:            envBool("FEATURE_VIDEO_CALLS", true),
		GroupEmail:            envBool("FEATURE_GROUP_EMAIL", true),
		AppName:               env("APP_NAME", "Команда"),
		Env:             env("APP_ENV", "development"),
		DBPoolSize:      envInt("DB_POOL_SIZE", 40),
		DBMinIdle:       envInt("DB_MIN_IDLE", 8),
		StatementCache:  envBool("DB_STATEMENT_CACHE", true),
		ReadTimeout:     envDuration("READ_TIMEOUT", 60*time.Second),
		WriteTimeout:    envDuration("WRITE_TIMEOUT", 120*time.Second),
		IdleTimeout:     envDuration("IDLE_TIMEOUT", 120*time.Second),

		Prefork:        envBool("PREFORK", false),
		PreforkWorkers: envInt("PREFORK_WORKERS", 0),
		RedisAddr:      env("REDIS_ADDR", ""),
		RedisPassword:  env("REDIS_PASSWORD", ""),
		RedisDB:        envInt("REDIS_DB", 0),
		RedisChannel:   env("REDIS_CHANNEL", "kanban:events"),
	}

	// Файл применяется до проверок обязательных параметров, чтобы его значения учитывались наравне с окружением.
	// Явно переданный путь (флаг --config) приоритетнее; при пустом пути определяется функциями configPath и explicitConfigPath.
	path, explicit := explicitPath, true
	if path == "" {
		path, explicit = configPath(), explicitConfigPath()
	}
	fc, ferr := loadFile(path, explicit)
	if ferr != nil {
		return nil, ferr
	}
	c.applyFile(fc)

	// Значения по умолчанию для среды разработки; в production отсутствие параметров является ошибкой.

	if c.DatabaseURL == "" {
		if c.IsProduction() {
			return nil, fmt.Errorf("DATABASE_URL не задан")
		}
		c.DatabaseURL = defaultDatabaseURL
		slog.Warn("DATABASE_URL не задан, используется значение по умолчанию",
			"url", defaultDatabaseURL)
	}

	// Prefork без Redis допустим, но события WebSocket дойдут не до всех пользователей; выводится предупреждение.
	if c.Prefork && c.RedisAddr == "" {
		slog.Warn("включён prefork без Redis: события WebSocket будут доходить " +
			"только до части пользователей. Укажите redis.addr в конфигурации")
	}

	if len(c.JWTSecret) < 32 {
		if c.IsProduction() {
			return nil, fmt.Errorf("JWT_SECRET не задан или короче 32 байт")
		}
		// Временный ключ создаётся случайно при каждом запуске; сессии сбрасываются при перезапуске.
		secret := make([]byte, 48)
		if _, err := rand.Read(secret); err != nil {
			return nil, fmt.Errorf("не удалось сгенерировать временный JWT_SECRET: %w", err)
		}
		c.JWTSecret = secret
		slog.Warn("JWT_SECRET не задан — сгенерирован временный ключ. " +
			"Все сессии будут сброшены при перезапуске. " +
			"Для постоянного ключа: openssl rand -base64 48")
	}

	if c.UploadDir == "" {
		c.UploadDir = defaultUploadDir
	}
	if c.ConvertDir == "" {
		c.ConvertDir = defaultConvertDir
	}

	return c, nil
}

// Константы defaultDatabaseURL, defaultUploadDir и defaultConvertDir задают значения по умолчанию для локального запуска.
const (
	defaultDatabaseURL = "postgres://app_user:change_me_user@localhost:5432/kanban?sslmode=disable"
	defaultUploadDir   = "./var/uploads"
	defaultConvertDir  = "./var/convert"
)

// Метод IsProduction предназначен для проверки режима production.
func (c *Config) IsProduction() bool { return c.Env == "production" }

// Функция env предназначена для чтения строковой переменной окружения со значением по умолчанию.
func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

// Функция splitList предназначена для разбора списка через запятую без пустых элементов.
func splitList(v string) []string {
	out := []string{}
	for _, part := range strings.Split(v, ",") {
		if p := strings.TrimSpace(part); p != "" {
			out = append(out, p)
		}
	}
	return out
}

// Функция envBool предназначена для чтения логической переменной окружения со значением по умолчанию.
func envBool(k string, def bool) bool {
	switch strings.ToLower(os.Getenv(k)) {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	}
	return def
}

// Функция envInt предназначена для чтения целочисленной переменной окружения со значением по умолчанию.
func envInt(k string, def int) int {
	if v, err := strconv.Atoi(os.Getenv(k)); err == nil {
		return v
	}
	return def
}

// Функция envDuration предназначена для чтения длительности из переменной окружения со значением по умолчанию.
func envDuration(k string, def time.Duration) time.Duration {
	if v, err := time.ParseDuration(os.Getenv(k)); err == nil {
		return v
	}
	return def
}

// Функция configPath предназначена для определения пути к config.yaml: флаг --config,
// переменная CONFIG_FILE, затем ./config.yaml.
func configPath() string {
	for i, arg := range os.Args {
		if arg == "--config" || arg == "-config" {
			if i+1 < len(os.Args) {
				return os.Args[i+1]
			}
		}
		if v, ok := strings.CutPrefix(arg, "--config="); ok {
			return v
		}
	}
	if v := os.Getenv("CONFIG_FILE"); v != "" {
		return v
	}
	return "config.yaml"
}

// Функция explicitConfigPath предназначена для определения, указан ли путь явно; для явного пути отсутствие файла является ошибкой.
func explicitConfigPath() bool {
	for _, arg := range os.Args {
		if arg == "--config" || arg == "-config" || strings.HasPrefix(arg, "--config=") {
			return true
		}
	}
	return os.Getenv("CONFIG_FILE") != ""
}
