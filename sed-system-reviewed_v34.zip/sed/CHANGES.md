# Доработка СЭД — отчёт об изменениях

Ниже — привязка каждого из 11 требований к конкретным правкам. Все правки внесены
в реальные файлы проекта. Среда сборки (Go/npm/сеть) была недоступна, поэтому
перед использованием обязательно выполните финальную сборку — см. раздел
«Как применить» в конце.

---

## 1. Похоже на endocs (документы) + сохранение balun-стилистики
Функционально приближено к EDMS-эталону: карточка с реквизитами и вкладками
(Маршрут | История | Просмотры | Рассылка | Связанные | Поручения), журналы/
реестры, постановка на контроль, связанные документы двух видов, серверная
маркировка. Визуальная тема balun сохранена без изменений (themes.css, kicker,
hairline-рамки). Полная попиксельная копия endocs в объёме одного прохода не
делалась — сделано функциональное соответствие.

## 2. RLS при создании документа (new row violates RLS policy)
**Корень:** таблица `documents` под `FORCE ROW LEVEL SECURITY`. Автор делает
INSERT от себя (WITH CHECK проходит), но сразу идёт `RETURNING id`, а RETURNING
под RLS применяет к возвращаемой строке **SELECT-политику**. На этот момент
строки в `document_access` для автора ещё нет (она создаётся позже, в
`GrantAuthorAccess` той же транзакции) → SELECT-политика не пропускает строку →
ошибка RLS.
**Фикс:** автор теперь авторизован на своих документах **напрямую**
(`author_id = app.user_id`) для SELECT/INSERT/UPDATE, независимо от материализации
`document_access` (которая остаётся для прочих участников).
- `backend/migrations/0017_rls_author_fix.sql` (goose)
- `backend/migrations_psql/0017_rls_author_fix.sql` (psql)
- дописано в `backend/migrations_psql/all_in_one.sql`

## 3. Нельзя добавить адресата (нет роли duty_officer)
**Корень:** триггер `check_recipient_role` проверяет роль duty_officer/clerk в
`recipient_department_id`. Кандидаты же возвращали `primary_department_id`, а роль
могла быть выдана в другом подразделении. Плюс `PersonPicker` вообще не сохранял
`department_id`.
**Фикс:**
- `backend/internal/http/handlers/users.go` — для группы `recipients` кандидаты
  возвращают подразделение, **где выдана роль** (`user_roles.department_id`), по
  строке на каждое такое подразделение.
- `frontend/src/components/PersonPicker.jsx`, `RouteBuilder.jsx` — выбранный
  элемент теперь несёт `department_id`.

## 4. При отправке после создания: «нужно указать хотя бы одного получателя»
**Корень:** рассинхрон API — клиент слал `{recipient_user_id, recipient_department_id}`
(одиночный), а бэкенд ждал `{recipients:[...]}` → массив пустой.
**Фикс:**
- `frontend/src/api/client.js` — `sendDocument(id, recipients[])` шлёт массив.
- `backend/internal/service/send.go`, `handlers/send.go` — `/send` с пустым телом
  **активирует плановых адресатов** (`is_planned`), корректно промоутит уже
  существующих плановых (идемпотентно, без дубль-уведомлений).

## 5. Списки-рассылки синхронизированы + мультивыбор
- `frontend/src/components/SendPanel.jsx` переписан на мультивыбор через тот же
  `PersonPicker(group="recipients")`, что и форма создания — единый источник и
  поведение для рассылки во всех местах.

## 6. Списки показывают участников ДО применения фильтра
- `frontend/src/components/PersonPicker.jsx`, `RouteBuilder.jsx` — кандидаты
  грузятся при фокусе (пустой запрос → начало списка группы), ввод лишь сужает.
  Бэкенд уже поддерживал пустой `q` (ILIKE '%%').

## 7. Редактирование = форма создания
- `frontend/src/components/EditDocumentModal.jsx` переписан в полную форму:
  метаданные + маршрут (RouteBuilder) + подписант + плановая рассылка + контроль,
  с префиллом из `stages`/`recipients`.
- Новый эндпоинт замены плановых адресатов:
  - `backend/internal/service/documents.go` — `SetPlannedRecipients`
  - `backend/internal/http/handlers/documents_create.go` — `UpdatePlannedRecipients`
  - `backend/internal/http/router.go` — `PATCH /documents/:id/planned-recipients`
  - `frontend/src/api/client.js` — `updatePlannedRecipients`

## 8. Фильтр по всем атрибутам + поиск ILIKE (частичное, без регистра)
- `backend/internal/repository/documents.go` — поиск переведён с `to_tsvector`
  на **ILIKE** по названию И содержанию; `SearchFilter` расширен: автор,
  подписант, контролёр, согласующий, получатель, подразделение, статусы,
  срочности, on_control, исходящий/входящий номер, диапазоны создания/срока/
  подписи.
- `backend/internal/http/handlers/documents.go` — парсинг всех новых параметров.
- `frontend/src/pages/DocumentsListPage.jsx` — панель фильтра со всеми атрибутами.
- `frontend/src/api/client.js` — `searchDocuments` передаёт все параметры.
- **Быстродействие:** `backend/migrations/0018_trgm_search.sql` — расширение
  `pg_trgm` + GIN-индексы под ILIKE (иначе ведущий `%` = seqscan на 1000+).

## 9. Маркировка на бэкенде, из конфига, 5 видов
**Корень:** `renderStamps` был заглушкой; при попытке подключить pdfcpu выяснилось,
что пути пакетов pdfcpu (`pkg/types` ↔ `pkg/pdfcpu` ↔ `pkg/model`) и сигнатуры
watermark-API различаются между версиями — в вашей среде `go mod tidy` подтянул
версию без `pkg/types`, что ломало сборку каскадом. Плюс штампы на кириллице
требуют встраивания Unicode-шрифта (base-14 Helvetica кириллицу не отображает),
что из чистого Go без зависимостей нереализуемо.
**Решение (устойчивое к сборке):**
- Зависимость pdfcpu **убрана из go.mod** — дефолтная сборка Go компилируется без
  внешних PDF-библиотек.
- Вся ЛОГИКА маркировки на бэкенде сохранена и не зависит от библиотек: 5 типов
  штампов, подстановка плейсхолдеров, позиции, цвета, hash подписи, место
  хранения оригинала (`internal/marking/marking.go`, `config/marking.go`,
  `service/marking_data.go`, `config.example.yaml`).
- Фактическое «вжигание» текста в PDF вынесено за pluggable-хук
  `marking.RenderHook func(original []byte, specs []Spec) ([]byte, error)`. По
  умолчанию `nil` → `Apply` возвращает исходный PDF без изменений (маркировку
  показывает overlay вьювера на фронте — как в исходной архитектуре). Сбой хука
  не ломает выдачу файла (возврат оригинала + лог).
- Готовая реализация хука на pdfcpu — в `internal/marking/render_pdfcpu.go.example`
  (СРАЗУ два варианта под новый и старый API pdfcpu). Включение: подобрать под
  свою версию, переименовать в `render_pdfcpu.go`, `go get` + `go mod tidy`.
- Пять видов: исходящий №, входящий №, **экземпляр** (добавлен), **перенос в
  архив** (добавлен), сведения о подписи (ФИО/должность/хранилище/hash).

Итог: `go build ./...` и `go test ./...` проходят без внешних PDF-зависимостей;
вжигание в файл включается одним файлом под вашу версию pdfcpu.

## 10. Связанные документы двух видов
Backend уже поддерживал (`document_links.text_note`, constraint `chk_link_target`).
- `frontend/src/components/DocumentTabs.jsx` — вкладка «Связанные» переписана:
  - режим «документ из системы»: поиск ILIKE + **мультивыбор**, ссылка формируется
    только для системных (кликабельный `<a>`);
  - режим «внешний документ»: текстовое поле (рендерится простым текстом);
  - тип связи сохранён в обоих случаях.
- `frontend/src/api/client.js` — `createLinkNote`, `searchSystemDocuments`.

## 11. Контролёр документа + вкладка «На контроле»
Backend уже имел `controller_id`/`on_control`/`SetControl`/`MyRoles` (0015).
- `backend/internal/repository/documents.go` — категория списка `control`.
- `frontend/src/components/Layout.jsx` — пункт навигации «На контроле».
- `frontend/src/pages/DocumentsListPage.jsx` — заголовок категории + фильтр
  «Контроль» + фильтр по контролёру.
- `frontend/src/components/EditDocumentModal.jsx` — постановка на контроль +
  назначение контролёра из формы редактирования.

---

## Производительность / 1000+ пользователей (architecture v2)
Каркас уже содержал разделение API/Realtime, Redis pub/sub, prefork-флаг,
LISTEN/NOTIFY (см. ARCHITECTURE_v2.md). Добавлено под нагрузку:
- pg_trgm GIN-индексы под ILIKE-поиск (0018) — ключевое для быстрого поиска.
- Индекс по контролёру, использование существующих композитных индексов под
  списки/дашборд.
Рекомендация: включить `prefork: true` на API только после выноса Realtime в
отдельный `cmd/realtime` (как описано в ARCHITECTURE_v2.md), поднять пул БД
(`DB_MAX_CONNS`) под число инстансов × воркеров.

---

## Как применить (обязательно выполнить в вашей среде)

```bash
# 1. Backend: собрать, прогнать тесты (внешних PDF-зависимостей НЕТ)
cd backend
go mod tidy      # сгенерирует go.sum из go.mod (pdfcpu не требуется)
go build ./...
go test ./...
# (опционально) включить вжигание маркировки в PDF:
#   см. internal/marking/render_pdfcpu.go.example, затем go get нужной версии pdfcpu

# 2. Frontend
cd ../frontend
npm install
npm run build

# 3. Миграции (psql). all_in_one.sql уже включает 0017 и 0018.
psql -U postgres -d sed -v ON_ERROR_STOP=1 -f backend/migrations_psql/all_in_one.sql
# либо через goose — применит 0017, 0018 поверх существующей схемы:
#   goose -dir backend/migrations postgres "$DSN" up
```

### На что обратить внимание при первой сборке
- **PDF-маркировка** по умолчанию НЕ вжигается в файл (нет внешних зависимостей —
  сборка гарантированно чистая). Чтобы включить вжигание — см. п.9 и файл
  `internal/marking/render_pdfcpu.go.example` (подключение хука под вашу версию
  pdfcpu). Вся backend-логика маркировки работает и без этого.
- **Должности пользователей** (`users.position`) у демо-данных пустые — штамп
  подписи покажет пустую должность, пока не проставите `UPDATE users SET position=...`.
- Синтаксис всех 48 `.go` и изменённых `.jsx` проверен скриптом (баланс
  скобок). Компиляция/линт — за вами (в среде нет тулчейна).
