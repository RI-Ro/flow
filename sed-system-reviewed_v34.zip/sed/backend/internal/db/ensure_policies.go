package db

import (
	"context"
	"log"

	"github.com/jackc/pgx/v5/pgxpool"
)

// canonicalPoliciesSQL — единственно верный набор RLS-политик для трёх таблиц
// с FORCE ROW LEVEL SECURITY. Применяется на КАЖДОМ старте (EnsureCanonicalPolicies)
// как страховка: если конкретная БД была развёрнута ранее (goose уже пометил
// версии 1..N применёнными) и переиспользуется, новые миграции с исправленной
// политикой не накатятся — а этот код всё равно приведёт политики к нужному
// виду. Идемпотентно.
//
// notifications INSERT — WITH CHECK (true): уведомления создаёт ТОЛЬКО серверный
// код, часто для другого пользователя; публичного эндпоинта нет. Это надёжно
// исключает "new row violates row-level security policy for table notifications".
const canonicalPoliciesSQL = `
DROP POLICY IF EXISTS documents_access_policy ON documents;
DROP POLICY IF EXISTS documents_select ON documents;
DROP POLICY IF EXISTS documents_insert ON documents;
DROP POLICY IF EXISTS documents_update ON documents;
DROP POLICY IF EXISTS documents_delete ON documents;
CREATE POLICY documents_select ON documents FOR SELECT USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR (documents.outgoing_number IS NOT NULL AND documents.author_department_id IN (
        SELECT uvd.department_id FROM user_visible_departments uvd
        WHERE uvd.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint))
  OR EXISTS (SELECT 1 FROM document_incoming_instances dii
             JOIN user_incoming_departments uid ON uid.department_id = dii.receiving_department_id
             WHERE dii.document_id = documents.id
               AND uid.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY documents_insert ON documents FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY documents_update ON documents FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY documents_delete ON documents FOR DELETE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

DROP POLICY IF EXISTS chat_access_policy ON chat_messages;
DROP POLICY IF EXISTS chat_select ON chat_messages;
DROP POLICY IF EXISTS chat_insert ON chat_messages;
DROP POLICY IF EXISTS chat_update ON chat_messages;
DROP POLICY IF EXISTS chat_delete ON chat_messages;
CREATE POLICY chat_select ON chat_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
          AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY chat_insert ON chat_messages FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  AND EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
              AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint));
CREATE POLICY chat_update ON chat_messages FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY chat_delete ON chat_messages FOR DELETE USING (true);

DROP POLICY IF EXISTS notifications_owner_policy ON notifications;
DROP POLICY IF EXISTS notifications_select ON notifications;
DROP POLICY IF EXISTS notifications_insert ON notifications;
DROP POLICY IF EXISTS notifications_update ON notifications;
DROP POLICY IF EXISTS notifications_delete ON notifications;
CREATE POLICY notifications_select ON notifications FOR SELECT USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY notifications_insert ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY notifications_update ON notifications FOR UPDATE USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);
CREATE POLICY notifications_delete ON notifications FOR DELETE USING (true);
`

// EnsureCanonicalPolicies приводит RLS-политики к каноническому виду на старте.
// НЕ ФАТАЛЬНО: если роль подключения не является владельцем таблиц и не может
// пересоздавать политики, ошибка только логируется, старт продолжается (на
// чистом развёртывании политики уже верны из миграции 0002_rls).
func EnsureCanonicalPolicies(ctx context.Context, pool *pgxpool.Pool) {
	if _, err := pool.Exec(ctx, canonicalPoliciesSQL); err != nil {
		log.Printf("[warn] не удалось привести RLS-политики к каноническому виду: %v\n"+
			"       (это некритично, если БД развёрнута с нуля миграцией 0002_rls; иначе "+
			"убедитесь, что роль подключения — владелец таблиц)", err)
		return
	}
	log.Println("RLS-политики приведены к каноническому виду")
}
