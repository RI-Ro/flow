package db

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// New открывает пул соединений к PostgreSQL.
func New(ctx context.Context, dsn string) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("parse dsn: %w", err)
	}
	// Разумные дефолты пула для веб-бэкенда среднего размера нагрузки.
	cfg.MaxConns = 20
	cfg.MinConns = 2

	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("create pool: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, fmt.Errorf("ping db: %w", err)
	}
	return pool, nil
}

// WithUserTx открывает транзакцию и выставляет app.user_id / app.is_admin
// сессионными переменными для этой транзакции — это то, на чём строятся
// все RLS-политики (documents_access_policy, chat_access_policy,
// notifications_owner_policy). Обязателен для КАЖДОГО запроса, читающего
// или изменяющего защищённые RLS таблицы — как из HTTP-хендлеров, так и
// из WebSocket-хаба (см. internal/ws/hub.go).
func WithUserTx(ctx context.Context, pool *pgxpool.Pool, userID int64, isAdmin bool, fn func(tx pgx.Tx) error) error {
	// Явно берём ОДНО соединение из пула на весь запрос. Это критично для
	// RLS: set_config и последующие запросы обязаны идти по одному и тому же
	// физическому соединению, иначе сессионная переменная app.user_id не
	// видна запросу, и WITH CHECK политики падает. Захват conn гарантирует
	// это независимо от внутреннего поведения пула.
	conn, err := pool.Acquire(ctx)
	if err != nil {
		return fmt.Errorf("acquire conn: %w", err)
	}
	defer conn.Release()

	tx, err := conn.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback(ctx) // no-op если Commit уже прошёл

	// Выставляем контекст RLS. ВАЖНО: без параметров ($1) — параметризованный
	// запрос идёт по extended-протоколу как prepared statement, и LOCAL-эффект
	// set_config при этом ненадёжен. Простой строковый запрос применяет
	// настройку немедленно. Значения безопасны: userID — int64, isAdmin —
	// bool (не пользовательский ввод), инъекция невозможна.
	setSQL := fmt.Sprintf(
		"SELECT set_config('app.user_id', '%d', true), set_config('app.is_admin', '%t', true)",
		userID, isAdmin)
	if _, err := tx.Exec(ctx, setSQL); err != nil {
		return fmt.Errorf("set rls context: %w", err)
	}

	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// WithAdminTx открывает транзакцию с app.is_admin=true (и app.user_id=0) —
// для фоновых/системных задач (авто-архив), которым нужен обход RLS. Не
// использовать в обработке пользовательских запросов: там всегда WithUserTx
// с реальным userID.
func WithAdminTx(ctx context.Context, pool *pgxpool.Pool, fn func(tx pgx.Tx) error) error {
	tx, err := pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin admin tx: %w", err)
	}
	defer tx.Rollback(ctx)

	if _, err := tx.Exec(ctx, "SELECT set_config('app.user_id', '0', true)"); err != nil {
		return fmt.Errorf("set app.user_id: %w", err)
	}
	if _, err := tx.Exec(ctx, "SELECT set_config('app.is_admin', 'true', true)"); err != nil {
		return fmt.Errorf("set app.is_admin: %w", err)
	}
	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
