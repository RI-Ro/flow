package db

import (
	"database/sql"
	"fmt"

	"github.com/pressly/goose/v3"

	// stdlib-адаптер pgx для database/sql — goose работает через *sql.DB.
	_ "github.com/jackc/pgx/v5/stdlib"
)

// Migrate применяет все миграции из dir при старте приложения. Делать это
// в самом бэкенде надёжнее, чем полагаться на внешний goose-образ в
// docker-compose: гарантированно та же версия goose, что в go.mod, и
// понятные ошибки в общем логе сервиса, а не в отдельном контейнере.
// Идемпотентно: уже применённые миграции goose пропускает по своей
// таблице версий.
func Migrate(dsn, dir string) error {
	sqlDB, err := sql.Open("pgx", dsn)
	if err != nil {
		return fmt.Errorf("open db for migrate: %w", err)
	}
	defer sqlDB.Close()

	goose.SetDialect("postgres")
	if err := goose.Up(sqlDB, dir); err != nil {
		return fmt.Errorf("goose up: %w", err)
	}
	return nil
}
