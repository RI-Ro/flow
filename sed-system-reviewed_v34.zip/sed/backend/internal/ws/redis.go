package ws

import (
	"context"
	"encoding/json"
	"log"

	"github.com/redis/go-redis/v9"
)

// redisBridge связывает локальный Hub с Redis pub/sub, чтобы события
// (сообщения чата, уведомления) доставлялись клиентам НА ЛЮБОМ инстансе, а не
// только на том, куда попал вызов Broadcast. Без этого горизонтальное
// масштабирование WS невозможно: клиент висит на одном инстансе, а событие
// сгенерировалось на другом.
//
// Схема: каждый инстанс публикует событие в общий канал; каждый инстанс
// подписан на этот канал и, получив событие, рассылает его СВОИМ локальным
// клиентам нужной комнаты. Событие несёт имя комнаты и полезную нагрузку.
type redisBridge struct {
	rdb     *redis.Client
	channel string
	hub     *Hub
}

// roomEvent — то, что летает через Redis между инстансами.
type roomEvent struct {
	Room    string          `json:"room"`
	Payload json.RawMessage `json:"payload"`
}

// newRedisBridge создаёт клиент Redis и подписывается на канал. Если addr
// пустой — возвращает nil (Redis отключён, Hub работает in-memory на одном
// инстансе). Ошибку подключения не считаем фатальной: WS деградирует до
// одно-инстансного режима, приложение продолжает работать.
func newRedisBridge(ctx context.Context, addr, channel string, hub *Hub) *redisBridge {
	if addr == "" {
		return nil
	}
	rdb := redis.NewClient(&redis.Options{Addr: addr})
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Printf("ws: redis недоступен (%v) — WS работает в одно-инстансном режиме", err)
		return nil
	}
	b := &redisBridge{rdb: rdb, channel: channel, hub: hub}
	go b.subscribe(ctx)
	log.Printf("ws: redis pub/sub включён, канал %q", channel)
	return b
}

// publish отправляет событие комнаты в Redis, откуда его получат все
// инстансы (включая текущий — он тоже подписан, поэтому доставит локальным
// клиентам в subscribe, а не напрямую).
func (b *redisBridge) publish(room string, payload []byte) {
	ev := roomEvent{Room: room, Payload: payload}
	data, err := json.Marshal(ev)
	if err != nil {
		return
	}
	if err := b.rdb.Publish(context.Background(), b.channel, data).Err(); err != nil {
		log.Printf("ws: redis publish failed: %v", err)
	}
}

// subscribe читает канал и раздаёт события локальным клиентам.
func (b *redisBridge) subscribe(ctx context.Context) {
	sub := b.rdb.Subscribe(ctx, b.channel)
	ch := sub.Channel()
	for msg := range ch {
		var ev roomEvent
		if err := json.Unmarshal([]byte(msg.Payload), &ev); err != nil {
			continue
		}
		b.hub.deliverLocal(ev.Room, ev.Payload)
	}
}
