package ws

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"sync"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
)

// Hub держит соединения, сгруппированные по "комнатам":
//   - "doc:{id}"   — чат конкретного документа
//   - "user:{id}"  — персональные уведомления пользователя
//
// Перед подпиской на комнату doc:{id} ОБЯЗАТЕЛЬНО проверяем document_access
// в транзакции с выставленным app.user_id — то есть тот же RLS-контур, что
// и у REST API, применяется и здесь (требование ТЗ: "чат и уведомления ...
// обязательно RLS").
type Hub struct {
	pool *pgxpool.Pool

	mu    sync.RWMutex
	rooms map[string]map[*Client]bool

	redis *redisBridge // nil = одно-инстансный режим (без Redis)
}

func NewHub(pool *pgxpool.Pool) *Hub {
	return &Hub{
		pool:  pool,
		rooms: make(map[string]map[*Client]bool),
	}
}

// EnableRedis подключает Redis pub/sub для межинстансной доставки WS-событий.
// addr пустой — режим одного инстанса (Redis не используется). Вызывать один
// раз при старте, до приёма соединений.
func (h *Hub) EnableRedis(ctx context.Context, addr, channel string) {
	h.redis = newRedisBridge(ctx, addr, channel, h)
}

type Client struct {
	UserID  int64
	IsAdmin bool
	Send    chan []byte
}

func (h *Hub) Subscribe(room string, c *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.rooms[room] == nil {
		h.rooms[room] = make(map[*Client]bool)
	}
	h.rooms[room][c] = true
}

func (h *Hub) Unsubscribe(room string, c *Client) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if clients, ok := h.rooms[room]; ok {
		delete(clients, c)
		if len(clients) == 0 {
			delete(h.rooms, room)
		}
	}
}

// Broadcast рассылает payload в комнату. Если включён Redis — публикует
// событие туда, и оно вернётся во ВСЕ инстансы (включая текущий) через
// подписку, где будет роздано локальным клиентам. Если Redis выключен —
// раздаёт напрямую локальным клиентам.
func (h *Hub) Broadcast(room string, payload any) {
	data, err := json.Marshal(payload)
	if err != nil {
		log.Printf("ws: marshal broadcast payload: %v", err)
		return
	}
	if h.redis != nil {
		h.redis.publish(room, data)
		return
	}
	h.deliverLocal(room, data)
}

// deliverLocal раздаёт уже сериализованный payload клиентам ЭТОГО инстанса.
// Вызывается либо напрямую из Broadcast (без Redis), либо из подписки Redis
// (с Redis) — во втором случае payload пришёл от любого инстанса.
func (h *Hub) deliverLocal(room string, data []byte) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for c := range h.rooms[room] {
		select {
		case c.Send <- data:
		default:
			// клиент не успевает читать — не блокируем хаб, отбрасываем
			log.Printf("ws: dropping message for slow client user=%d room=%s", c.UserID, room)
		}
	}
}

// NotifyUsers рассылает push-уведомление в персональные комнаты
// "user:{id}" каждого из перечисленных пользователей. Вызывается ПОСЛЕ
// коммита транзакции, вставившей строки в notifications — так дольше
// открытое сетевое I/O (доставка по WS) никогда не удерживает соединение
// с БД и не увеличивает время транзакции. Те, кто сейчас не в сети,
// увидят непрочитанное уведомление при следующем заходе (таблица
// notifications — источник истины, WS — только ускоритель).
func (h *Hub) NotifyUsers(userIDs []int64, documentID int64, kind string) {
	if len(userIDs) == 0 {
		return
	}
	// Подставляем срочность документа — фронт по ней выбирает более
	// продолжительный/привлекающий звук для срочных и внеочередных.
	urgency := "normal"
	_ = db.WithUserTx(context.Background(), h.pool, 0, true, func(tx pgx.Tx) error {
		return tx.QueryRow(context.Background(), `SELECT urgency::text FROM documents WHERE id=$1`, documentID).Scan(&urgency)
	})
	for _, uid := range userIDs {
		room := fmt.Sprintf("user:%d", uid)
		h.Broadcast(room, map[string]any{
			"type":        "notification",
			"kind":        kind,
			"document_id": documentID,
			"urgency":     urgency,
		})
	}
}

// CanAccessDocument — та же проверка, что делает RLS-политика documents_access_policy,
// выполняется явной транзакцией перед тем, как подписать клиента на комнату документа.
func (h *Hub) CanAccessDocument(ctx context.Context, userID int64, isAdmin bool, documentID int64) (bool, error) {
	var ok bool
	err := db.WithUserTx(ctx, h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM documents WHERE id = $1)`, documentID).Scan(&ok)
	})
	return ok, err
}

// PersistChatMessage сохраняет сообщение чата внутри RLS-транзакции
// (chat_messages тоже под RLS — см. миграцию 0005) и возвращает вставленную строку.
func (h *Hub) PersistChatMessage(ctx context.Context, userID int64, isAdmin bool, documentID int64, text string) (int64, error) {
	var id int64
	err := db.WithUserTx(ctx, h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `
			INSERT INTO chat_messages (document_id, author_id, text)
			VALUES ($1, $2, $3) RETURNING id`, documentID, userID, text).Scan(&id)
	})
	return id, err
}

// AuthorName возвращает ФИО пользователя (для подписи сообщений чата).
// Ошибку не пробрасываем — при сбое просто вернём пустую строку.
func (h *Hub) AuthorName(ctx context.Context, userID int64, isAdmin bool) string {
	var name string
	_ = db.WithUserTx(ctx, h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1`, userID).Scan(&name)
	})
	return name
}
