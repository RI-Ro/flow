package ws

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/gofiber/contrib/websocket"
	"sed-system/backend/internal/service"
)

type inboundMessage struct {
	Type string `json:"type"` // "chat_message"
	Text string `json:"text"`
}

type outboundMessage struct {
	Type       string `json:"type"`
	DocumentID int64  `json:"document_id"`
	MessageID  int64  `json:"id,omitempty"`
	AuthorID   int64  `json:"author_id,omitempty"`
	AuthorName string `json:"author_name,omitempty"`
	Text       string `json:"text,omitempty"`
	CreatedAt  string `json:"created_at,omitempty"`
}

// ChatWSHandler обрабатывает соединение вида /ws/documents/:id/chat.
// Аутентификация — JWT передаётся как query-параметр token (браузерный
// WebSocket API не позволяет кастомные заголовки на handshake).
func ChatWSHandler(hub *Hub, auth *service.AuthService) func(*websocket.Conn) {
	return func(conn *websocket.Conn) {
		defer conn.Close()

		tokenStr := conn.Query("token")
		claims, err := auth.ParseToken(tokenStr)
		if err != nil {
			conn.WriteJSON(fiberError("unauthorized"))
			return
		}

		var documentID int64
		if _, err := fmt.Sscanf(conn.Params("id"), "%d", &documentID); err != nil {
			conn.WriteJSON(fiberError("invalid document id"))
			return
		}

		ctx := context.Background()
		allowed, err := hub.CanAccessDocument(ctx, claims.UserID, claims.IsAdmin, documentID)
		if err != nil || !allowed {
			conn.WriteJSON(fiberError("forbidden"))
			return
		}

		client := &Client{UserID: claims.UserID, IsAdmin: claims.IsAdmin, Send: make(chan []byte, 32)}
		room := fmt.Sprintf("doc:%d", documentID)
		hub.Subscribe(room, client)
		defer hub.Unsubscribe(room, client)

		// Имя автора резолвим один раз на соединение (автор = владелец токена),
		// чтобы живые сообщения сразу показывали ФИО без доп. запросов на фронте.
		authorName := hub.AuthorName(ctx, claims.UserID, claims.IsAdmin)

		done := make(chan struct{})
		go writePump(conn, client, done)

		for {
			_, raw, err := conn.ReadMessage()
			if err != nil {
				close(done)
				return
			}
			var in inboundMessage
			if err := json.Unmarshal(raw, &in); err != nil {
				continue
			}
			if in.Type != "chat_message" || in.Text == "" {
				continue
			}
			// Персистентность И проверка RLS происходят вместе внутри
			// PersistChatMessage — тот же контур доступа, что и в REST.
			msgID, err := hub.PersistChatMessage(ctx, claims.UserID, claims.IsAdmin, documentID, in.Text)
			if err != nil {
				log.Printf("ws: persist chat message: %v", err)
				continue
			}
			hub.Broadcast(room, outboundMessage{
				Type:       "chat_message",
				DocumentID: documentID,
				MessageID:  msgID,
				AuthorID:   claims.UserID,
				AuthorName: authorName,
				Text:       in.Text,
				CreatedAt:  time.Now().Format(time.RFC3339),
			})
		}
	}
}

// NotificationsWSHandler обрабатывает соединение /ws/notifications —
// персональный канал пользователя (комната "user:{id}"), куда push'ится
// событие сразу после того, как для него активировался этап согласования,
// документ подписан, отправлен и т.д. (см. ApprovalHandler/SendHandler,
// вызывающие hub.NotifyUsers ПОСЛЕ коммита транзакции).
func NotificationsWSHandler(hub *Hub, auth *service.AuthService) func(*websocket.Conn) {
	return func(conn *websocket.Conn) {
		defer conn.Close()

		tokenStr := conn.Query("token")
		claims, err := auth.ParseToken(tokenStr)
		if err != nil {
			conn.WriteJSON(fiberError("unauthorized"))
			return
		}

		client := &Client{UserID: claims.UserID, IsAdmin: claims.IsAdmin, Send: make(chan []byte, 32)}
		room := fmt.Sprintf("user:%d", claims.UserID)
		hub.Subscribe(room, client)
		defer hub.Unsubscribe(room, client)

		done := make(chan struct{})
		go writePump(conn, client, done)

		// Канал уведомлений однонаправленный (сервер -> клиент) — читаем
		// входящие фреймы только чтобы вовремя заметить закрытие соединения.
		for {
			if _, _, err := conn.ReadMessage(); err != nil {
				close(done)
				return
			}
		}
	}
}

func writePump(conn *websocket.Conn, client *Client, done chan struct{}) {
	for {
		select {
		case msg := <-client.Send:
			if err := conn.WriteMessage(websocket.TextMessage, msg); err != nil {
				return
			}
		case <-done:
			return
		}
	}
}

func fiberError(msg string) map[string]string {
	return map[string]string{"type": "error", "message": msg}
}
