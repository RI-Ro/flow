package handlers

import (
	"errors"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/config"
	"sed-system/backend/internal/marking"
	"sed-system/backend/internal/repository"
	"sed-system/backend/internal/service"
)

type DocumentsHandler struct {
	pool        *pgxpool.Pool
	repo        *repository.DocumentsRepo
	incoming    *service.IncomingService
	markingData *service.MarkingDataService
	markingCfg  config.MarkingConfig
	pageSize    int
	pageMax     int
}

func NewDocumentsHandler(pool *pgxpool.Pool, repo *repository.DocumentsRepo, incoming *service.IncomingService, markingData *service.MarkingDataService, markingCfg config.MarkingConfig, pageSize, pageMax int) *DocumentsHandler {
	return &DocumentsHandler{pool: pool, repo: repo, incoming: incoming, markingData: markingData, markingCfg: markingCfg, pageSize: pageSize, pageMax: pageMax}
}

// List GET /api/documents?category=on_approval&page=2&department_id=4
func (h *DocumentsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	category := repository.Category(c.Query("category", "all"))
	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}
	deptID, _ := strconv.ParseInt(c.Query("department_id", "0"), 10, 64)

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Если подразделение не задано явно — берём основное подразделение
		// пользователя. Иначе категория «Исходящие» (фильтр по
		// author_department_id) оказывалась пустой (deptID=0 не совпадает ни
		// с одним документом) — из-за этого у автора не отображались исходящие.
		if deptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
				return e
			}
		}
		year, _ := strconv.Atoi(c.Query("year"))
		res, err := h.repo.List(c.Context(), tx, category, userID, deptID, page, pageSize, year)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to list documents")
	}
	return c.JSON(result)
}

// GetMarking GET /api/documents/:id/marking — вычисленные штампы для overlay
// на фронте (текст с подставленными плейсхолдерами, позиция, цвет, размер,
// рамка). Поле baked=true, если бэкенд уже вжигает штампы в PDF (тогда фронт
// overlay не рисует). Данные считаются по той же логике, что и вжигание.
func (h *DocumentsHandler) GetMarking(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверяем, что документ виден текущему пользователю (RLS) — иначе
		// не отдаём его реквизиты маркировки.
		var one int
		if err := tx.QueryRow(c.Context(), `SELECT 1 FROM documents WHERE id=$1`, id).Scan(&one); err != nil {
			return err
		}
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, ph); err != nil {
			return err
		}
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to compute marking")
	}

	specs := marking.ComputeSpecs(h.markingCfg, placeholders)
	stamps := make([]fiber.Map, 0, len(specs))
	for _, s := range specs {
		stamps = append(stamps, fiber.Map{
			"text":         s.Text,
			"position":     s.Position, // tl/tr/bl/br/c
			"offset_x":     s.OffsetX,
			"offset_y":     s.OffsetY,
			"font_size":    s.FontSize,
			"color":        s.ColorHex,
			"border":       s.Border,
			"border_color": s.BorderColorHex,
			"fill":         s.FillColorHex,
			// Факсимиле/печать как data-URL — для двухколоночного штампа
			// (слева изображение, справа текст).
			"image": marking.ImageDataURL(s.ImageFile),
		})
	}
	return c.JSON(fiber.Map{"stamps": stamps, "baked": marking.IsBaking(h.markingCfg)})
}

// Get GET /api/documents/:id
func (h *DocumentsHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var doc any
	var marking *service.IncomingMarking
	var myCopy *int
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		d, err := h.repo.GetByID(c.Context(), tx, id)
		if err != nil {
			return err
		}
		doc = d

		// Регистрация во "входящих" при отображении получателем — по ТЗ:
		// "при отображении полученного документа должна фиксироваться
		// информация об экземпляре и наноситься доп. маркировка". Не
		// критично для показа документа, поэтому ошибку здесь не считаем
		// фатальной для всего запроса — только логируем через возврат err
		// наверх было бы избыточно строго; но раз транзакция общая, пусть
		// падает вместе с остальным (согласованность важнее отказоустойчивости
		// в рамках одного запроса).
		m, err := h.incoming.RegisterView(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		marking = m

		// Журнал просмотров. Дедупликация: не создаём новую запись, если тот
		// же пользователь открывал этот документ в последние 10 секунд.
		// Это убирает дубли от повторного рендера (React StrictMode в dev
		// вызывает эффекты дважды) и быстрых повторных запросов, но сохраняет
		// историю реально разных обращений.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_views (document_id, viewer_id)
			SELECT $1, $2
			WHERE NOT EXISTS (
				SELECT 1 FROM document_views
				WHERE document_id = $1 AND viewer_id = $2
				  AND viewed_at > now() - interval '10 seconds'
			)`, id, userID); err != nil {
			return err
		}
		// #9 — Номер экземпляра выдаётся при ПЕРВОМ ОЗНАКОМЛЕНИИ (просмотре)
		// КАЖДОМУ уникальному пользователю, реально открывшему документ, — вне
		// зависимости от того, ПОЧЕМУ он его видит (автор, согласующий,
		// подписант, получатель, исполнитель, ознакомленный, руководитель по
		// иерархии/видимости и т.д.). Раньше руководителю (chief_of_dept)
		// экземпляр не присваивался — по требованию это исправлено: экземпляр
		// есть у каждого уникального просмотра. Причину (reason) берём из
		// document_access (для наглядности в реестре экземпляров); если явной
		// строки доступа нет (напр. admin) — помечаем 'view'. Номер по-прежнему
		// НЕ резервируется заранее — только по факту открытия.
		var copyReason *string
		_ = tx.QueryRow(c.Context(), `
			SELECT access_reason FROM document_access
			WHERE document_id=$1 AND user_id=$2
			ORDER BY granted_at LIMIT 1`, id, userID).Scan(&copyReason)
		reason := "view"
		if copyReason != nil && *copyReason != "" {
			reason = *copyReason
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_copies (document_id, user_id, copy_number, reason)
			SELECT $1, $2, COALESCE(MAX(copy_number),0)+1, $3
			FROM document_copies WHERE document_id = $1
			ON CONFLICT (document_id, user_id) DO NOTHING`, id, userID, reason); err != nil {
			return err
		}
		// Номер экземпляра текущего пользователя (Экз. №), если выдан.
		var cn int32
		if e := tx.QueryRow(c.Context(), `SELECT copy_number FROM document_copies WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&cn); e == nil {
			v := int(cn)
			myCopy = &v
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			// 404 независимо от того, документ не существует или скрыт RLS —
			// не раскрываем факт существования документа без доступа.
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get document")
	}
	return c.JSON(fiber.Map{"document": doc, "incoming_marking": marking, "my_copy_number": myCopy})
}

// Copies GET /api/documents/:id/copies — реестр экземпляров документа: у кого
// какой номер экземпляра (Экз. №), за что выдан и когда. Виден всем, у кого
// есть доступ к документу (RLS на document_copies нет, но выборка идёт только
// после проверки доступа к самому документу через GetByID под RLS).
func (h *DocumentsHandler) Copies(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type copyItem struct {
		CopyNumber int    `json:"copy_number"`
		UserID     int64  `json:"user_id"`
		FullName   string `json:"full_name"`
		Reason     string `json:"reason"`
		AssignedAt string `json:"assigned_at"`
	}
	var items []copyItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверка доступа к документу (иначе RLS вернёт ErrNoRows → 404).
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT c.copy_number, c.user_id,
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       c.reason, to_char(c.assigned_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_copies c JOIN users u ON u.id = c.user_id
			WHERE c.document_id = $1
			ORDER BY c.copy_number`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it copyItem
			if err := rows.Scan(&it.CopyNumber, &it.UserID, &it.FullName, &it.Reason, &it.AssignedAt); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get copies")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Search GET /api/documents/search?q=...&page=1&page_size=20
func (h *DocumentsHandler) Search(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}

	filter := repository.SearchFilter{
		Category:       c.Query("category"),
		UserID:         userID,
		Query:          c.Query("q"),
		DueFrom:        c.Query("due_from"),
		DueTo:          c.Query("due_to"),
		CreatedFrom:    c.Query("created_from"),
		CreatedTo:      c.Query("created_to"),
		SignedFrom:     c.Query("signed_from"),
		SignedTo:       c.Query("signed_to"),
		Number:         c.Query("number"),
		IncomingNumber: c.Query("incoming_number"),
		OnControl:      c.Query("on_control"),
	}
	parseID := func(name string) int64 {
		if v := c.Query(name); v != "" {
			id, _ := strconv.ParseInt(v, 10, 64)
			return id
		}
		return 0
	}
	filter.AuthorID = parseID("author_id")
	filter.SignerID = parseID("signer_id")
	filter.ControllerID = parseID("controller_id")
	filter.ApproverID = parseID("approver_id")
	filter.RecipientID = parseID("recipient_id")
	filter.DepartmentID = parseID("department_id")
	if v := c.Query("status"); v != "" {
		filter.Statuses = splitCSV(v)
	}
	if v := c.Query("urgency"); v != "" {
		filter.Urgencies = splitCSV(v)
	}

	// Категория задаёт контекст поиска — если она есть, пустой набор фильтров
	// допустим (просто применяется ограничение категории).
	catScoped := filter.Category != "" && filter.Category != "all"
	empty := !catScoped && filter.Query == "" && filter.AuthorID == 0 && filter.SignerID == 0 &&
		filter.ControllerID == 0 && filter.ApproverID == 0 && filter.RecipientID == 0 &&
		filter.DepartmentID == 0 && len(filter.Statuses) == 0 && len(filter.Urgencies) == 0 &&
		filter.OnControl == "" && filter.DueFrom == "" && filter.DueTo == "" &&
		filter.CreatedFrom == "" && filter.CreatedTo == "" &&
		filter.SignedFrom == "" && filter.SignedTo == "" &&
		filter.Number == "" && filter.IncomingNumber == ""
	if empty {
		return fiber.NewError(fiber.StatusBadRequest, "укажите хотя бы один фильтр")
	}

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Для категории «Исходящие» нужно подразделение пользователя.
		if filter.Category == string(repository.CategoryOutgoing) && filter.DeptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&filter.DeptID); e != nil {
				return e
			}
		}
		res, err := h.repo.Search(c.Context(), tx, filter, page, pageSize)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to search documents")
	}
	return c.JSON(result)
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		p := strings.TrimSpace(part)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// GetStages GET /api/documents/:id/stages
func (h *DocumentsHandler) GetStages(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var stages any
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Явно проверяем видимость документа по RLS перед выдачей маршрута —
		// approval_stages не защищена собственной RLS-политикой (см. комментарий
		// в repository.ListStages), поэтому проверка здесь обязательна.
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		s, err := h.repo.ListStages(c.Context(), tx, id)
		if err != nil {
			return err
		}
		stages = s
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get stages")
	}
	return c.JSON(fiber.Map{"items": stages})
}

// GetFile GET /api/documents/:id/file — отдаёт PDF только для просмотра
// (inline), без возможности скачивания через отдельный "download"-эндпоинт.
func (h *DocumentsHandler) GetFile(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var content []byte
	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// document_files не имеет собственной RLS-политики, но JOIN на
		// documents гарантирует, что мы не отдадим файл документа, невидимого
		// по RLS текущему пользователю (documents.id IN (...) сработает как
		// фильтр даже внутри JOIN, т.к. RLS применяется к каждой строке documents).
		if err := tx.QueryRow(c.Context(), `
			SELECT f.content FROM document_files f
			JOIN documents d ON d.id = f.document_id
			WHERE f.document_id = $1`, id).Scan(&content); err != nil {
			return err
		}
		// Собираем данные для маркировки (номера, подпись, получение).
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		// Подразделение смотрящего — для отметки о получении.
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, ph); err != nil {
			return err
		}
		// Владелец экземпляра (ФИО, подразделение) + номер экземпляра ИМЕННО
		// текущего пользователя (document_copies). Вызывается ПОСЛЕ
		// CollectIncoming, чтобы перекрыть устаревший ярлык из вх. инстанса
		// (он отставал на 1). Так номер в маркировке совпадёт с «Экз. №» сверху.
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "file not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get file")
	}

	// Накладываем штампы из конфига на КОПИЮ (оригинал в БД неизменен).
	// Если маркировка упала (напр. кривой PDF) — отдаём оригинал, чтобы не
	// ломать просмотр; ошибку логируем.
	marked, err := marking.Apply(content, h.markingCfg, placeholders)
	if err != nil {
		log.Printf("marking failed for doc %d: %v", id, err)
		marked = content
	}

	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", "inline")
	c.Set("X-Content-Type-Options", "nosniff")
	// Ограничиваем встраивание/кэширование на уровне браузера — это UX-барьер,
	// не криптографическая защита; абсолютной защиты от скриншота/печати
	// браузера не даёт ни одна веб-система.
	c.Set("Cache-Control", "no-store")
	c.Set("Content-Security-Policy", "frame-ancestors 'self'")
	return c.Send(marked)
}

// History GET /api/documents/:id/history — журнал событий документа
// (вкладка "История документа").
func (h *DocumentsHandler) History(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type event struct {
		EventType  string  `json:"event_type"`
		ActorName  *string `json:"actor_name,omitempty"`
		FromStatus *string `json:"from_status,omitempty"`
		ToStatus   *string `json:"to_status,omitempty"`
		Comment    *string `json:"comment,omitempty"`
		CreatedAt  string  `json:"created_at"`
	}
	var items []event
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT h.event_type, u.full_name, h.from_status::text, h.to_status::text, h.comment,
			       to_char(h.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_history h
			LEFT JOIN users u ON u.id = h.actor_id
			WHERE h.document_id = $1
			ORDER BY h.created_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var e event
			if err := rows.Scan(&e.EventType, &e.ActorName, &e.FromStatus, &e.ToStatus, &e.Comment, &e.CreatedAt); err != nil {
				return err
			}
			items = append(items, e)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load history")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Views GET /api/documents/:id/views — журнал просмотров (вкладка "История
// просмотров").
func (h *DocumentsHandler) Views(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type view struct {
		ViewerName string `json:"viewer_name"`
		ViewedAt   string `json:"viewed_at"`
	}
	var items []view
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		// Первый просмотр КАЖДОГО пользователя (DISTINCT ON по viewer_id,
		// берём самую раннюю запись). ФИО с должностью.
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT ON (v.viewer_id)
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       to_char(v.viewed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_views v JOIN users u ON u.id = v.viewer_id
			WHERE v.document_id = $1
			ORDER BY v.viewer_id, v.viewed_at ASC
			LIMIT 500`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var vw view
			if err := rows.Scan(&vw.ViewerName, &vw.ViewedAt); err != nil {
				return err
			}
			items = append(items, vw)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load views")
	}
	return c.JSON(fiber.Map{"items": items})
}

// SetControl POST /api/documents/:id/control — поставить/снять документ с
// контроля и назначить контролёров. Тело:
// { "on_control": true, "controller_ids": [4,7] }  (или старое "controller_id": 4).
// #4 — контролёров может быть несколько. Все они сохраняются в
// document_controllers; documents.controller_id = первый (для дашборда/реестра).
func (h *DocumentsHandler) SetControl(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	var req struct {
		OnControl     bool    `json:"on_control"`
		ControllerID  int64   `json:"controller_id"`  // обратная совместимость
		ControllerIDs []int64 `json:"controller_ids"` // #4
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid body")
	}
	// Собираем итоговый набор контролёров (дедуп, без нулей).
	seen := map[int64]bool{}
	var ctlIDs []int64
	for _, cid := range append(req.ControllerIDs, req.ControllerID) {
		if cid != 0 && !seen[cid] {
			seen[cid] = true
			ctlIDs = append(ctlIDs, cid)
		}
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Контролёром можно назначить только пользователя с ролью controller
		// или default_controller из подразделения автора либо вышестоящего.
		if !isAdmin {
			for _, cid := range ctlIDs {
				var okCtl bool
				if err := tx.QueryRow(c.Context(), `
					SELECT EXISTS(
					  SELECT 1 FROM users u
					  JOIN user_roles ur ON ur.user_id = u.id AND ur.role IN ('controller','default_controller')
					  WHERE u.id = $1
					    AND u.primary_department_id IN (
					      SELECT dc.ancestor_id FROM department_closure dc
					      JOIN documents d ON d.id = $2
					      WHERE dc.descendant_id = d.author_department_id
					    )
					)`, cid, id).Scan(&okCtl); err != nil {
					return err
				}
				if !okCtl {
					return errControllerRole
				}
			}
		}
		// Основной контролёр (первый) — в documents.controller_id.
		var primary *int64
		if req.OnControl && len(ctlIDs) > 0 {
			primary = &ctlIDs[0]
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE documents SET on_control=$1, controller_id=$2 WHERE id=$3`,
			req.OnControl, primary, id); err != nil {
			return err
		}
		// Полный набор контролёров — в document_controllers (перезаписываем).
		if _, err := tx.Exec(c.Context(), `DELETE FROM document_controllers WHERE document_id=$1`, id); err != nil {
			return err
		}
		// История: постановка/снятие с контроля.
		evt := "removed_from_control"
		if req.OnControl {
			evt = "put_on_control"
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type)
			VALUES ($1, $2, $3)`, id, userID, evt); err != nil {
			return err
		}
		if req.OnControl {
			for _, cid := range ctlIDs {
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_controllers (document_id, user_id)
					VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_access (document_id, user_id, access_reason)
					VALUES ($1, $2, 'controller') ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				_, _ = tx.Exec(c.Context(), `
					INSERT INTO notifications (user_id, document_id, kind, payload)
					VALUES ($1, $2, 'control_assigned', '{}')`, cid, id)
			}
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errControllerRole) {
			return fiber.NewError(fiber.StatusUnprocessableEntity, "контролёром может быть только пользователь с ролью «контролёр» (или «контролёр по умолчанию») из подразделения автора или вышестоящего")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить контроль")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Controllers GET /api/documents/:id/controllers — список контролёров документа
// (для префилла формы редактирования и отображения в карточке). Доступ через
// RLS: сначала проверяем доступ к документу.
func (h *DocumentsHandler) Controllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type ctl struct {
		UserID         int64  `json:"user_id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.id IN (
			   SELECT user_id FROM document_controllers WHERE document_id=$1
			   UNION
			   SELECT controller_id FROM documents WHERE id=$1 AND controller_id IS NOT NULL
			)
			ORDER BY u.full_name`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.UserID, &x.FullName, &x.Position, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров")
	}
	return c.JSON(fiber.Map{"items": items})
}

// DefaultControllers GET /api/default-controllers — активные пользователи с
// ролью default_controller. Форма создания использует их для ПРЕДВЫБОРА
// контролёров (галочка «на контроле» предустановлена, но автор может изменить
// или снять — контролёр добавляется только с санкции автора).
func (h *DocumentsHandler) DefaultControllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	type ctl struct {
		ID             int64  `json:"id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentID   int64  `json:"department_id"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(u.primary_department_id,0), coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			JOIN user_roles ur ON ur.user_id = u.id AND ur.role = 'default_controller'
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.is_active = true
			ORDER BY u.full_name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.ID, &x.FullName, &x.Position, &x.DepartmentID, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров по умолчанию")
	}
	return c.JSON(fiber.Map{"items": items})
}

// MyRoles GET /api/documents/:id/my-roles — в каких качествах текущий
// пользователь участвует в документе. Фронт по этому ответу показывает/скрывает
// вкладки (не участник согласования не видит вкладку маршрута и т.д.).
func (h *DocumentsHandler) MyRoles(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	res := fiber.Map{
		"is_author":     false,
		"is_approver":   false,
		"is_signer":     false,
		"is_controller": false,
		"is_recipient":  false,
		"is_printer":    false,
		"is_admin":      isAdmin,
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID int64
		var controllerID *int64
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, controller_id FROM documents WHERE id=$1`, id).Scan(&authorID, &controllerID); err != nil {
			return err
		}
		res["is_author"] = authorID == userID
		// #4 — контролёров может быть несколько (document_controllers);
		// controller_id хранит основного. Проверяем оба источника.
		isCtl := controllerID != nil && *controllerID == userID
		if !isCtl {
			var cnt int
			if err := tx.QueryRow(c.Context(),
				`SELECT count(*) FROM document_controllers WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&cnt); err != nil {
				return err
			}
			isCtl = cnt > 0
		}
		res["is_controller"] = isCtl

		// Согласующий или подписант — по этапам маршрута.
		var approverCnt, signerCnt int
		if err := tx.QueryRow(c.Context(), `
			SELECT
			  count(*) FILTER (WHERE stage_type IN ('hierarchy','cross_dept')),
			  count(*) FILTER (WHERE stage_type = 'signing')
			FROM approval_stages WHERE document_id=$1 AND approver_id=$2`, id, userID).
			Scan(&approverCnt, &signerCnt); err != nil {
			return err
		}
		res["is_approver"] = approverCnt > 0
		res["is_signer"] = signerCnt > 0

		// Получатель рассылки.
		var recipCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM document_recipients WHERE document_id=$1 AND recipient_user_id=$2`, id, userID).
			Scan(&recipCnt); err != nil {
			return err
		}
		res["is_recipient"] = recipCnt > 0

		// Роль печати — глобально по user_roles (в любом подразделении).
		var printerCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM user_roles WHERE user_id=$1 AND role='printer'`, userID).
			Scan(&printerCnt); err != nil {
			return err
		}
		res["is_printer"] = printerCnt > 0 || isAdmin
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load roles")
	}
	return c.JSON(res)
}
