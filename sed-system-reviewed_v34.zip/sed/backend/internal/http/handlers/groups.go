package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// isUniqueViolation — Postgres SQLSTATE 23505 (нарушение UNIQUE).
func isUniqueViolation(err error) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "23505"
}

// GroupsHandler — группы адресатов рассылки (#4). Управляются администратором
// (CRUD + состав), доступны любому аутентифицированному пользователю на чтение
// для выбора в форме рассылки. Участник группы хранит пару (user_id,
// department_id): получателем рассылки можно стать только с ролью clerk в
// конкретном подразделении (DB-триггер check_recipient_role), поэтому в группе
// фиксируем именно ту пару, что пройдёт триггер.
type GroupsHandler struct {
	pool *pgxpool.Pool
}

func NewGroupsHandler(pool *pgxpool.Pool) *GroupsHandler {
	return &GroupsHandler{pool: pool}
}

type groupMember struct {
	UserID         int64  `json:"user_id"`
	DepartmentID   int64  `json:"department_id"`
	FullName       string `json:"full_name"`
	Position       string `json:"position"`
	DepartmentName string `json:"department_name"`
	City           string `json:"city"`
}

type groupItem struct {
	ID          int64         `json:"id"`
	Name        string        `json:"name"`
	Description string        `json:"description"`
	IsActive    bool          `json:"is_active"`
	MemberCount int           `json:"member_count"`
	Members     []groupMember `json:"members"`
}

func (h *GroupsHandler) requireAdmin(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return nil
}

// loadMembers загружает участников группы с должностью/подразделением/городом.
func loadMembers(c *fiber.Ctx, tx pgx.Tx, groupID int64) ([]groupMember, error) {
	rows, err := tx.Query(c.Context(), `
		SELECT m.user_id, m.department_id, coalesce(u.full_name,''), coalesce(u.position,''),
		       coalesce(d.name,''), coalesce(d.city,'')
		FROM recipient_group_members m
		JOIN users u ON u.id = m.user_id
		LEFT JOIN departments d ON d.id = m.department_id
		WHERE m.group_id = $1
		ORDER BY u.full_name`, groupID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []groupMember
	for rows.Next() {
		var m groupMember
		if err := rows.Scan(&m.UserID, &m.DepartmentID, &m.FullName, &m.Position, &m.DepartmentName, &m.City); err != nil {
			return nil, err
		}
		out = append(out, m)
	}
	return out, rows.Err()
}

// List GET /api/recipient-groups — список групп с составом. Доступен всем
// аутентифицированным (для выбора в форме рассылки). Неактивные группы
// показываются только администратору.
func (h *GroupsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	var items []groupItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		where := "WHERE is_active = true"
		if isAdmin {
			where = ""
		}
		rows, err := tx.Query(c.Context(), `
			SELECT id, name, coalesce(description,''), is_active FROM recipient_groups
			`+where+` ORDER BY name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var g groupItem
			if err := rows.Scan(&g.ID, &g.Name, &g.Description, &g.IsActive); err != nil {
				return err
			}
			items = append(items, g)
		}
		if err := rows.Err(); err != nil {
			return err
		}
		for i := range items {
			m, err := loadMembers(c, tx, items[i].ID)
			if err != nil {
				return err
			}
			items[i].Members = m
			items[i].MemberCount = len(m)
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить группы адресатов")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Create POST /api/admin/recipient-groups — создать группу (admin).
func (h *GroupsHandler) Create(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	var req struct {
		Name        string `json:"name"`
		Description string `json:"description"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название группы")
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO recipient_groups (name, description) VALUES ($1, NULLIF($2,''))
			RETURNING id`, req.Name, req.Description).Scan(&id)
	})
	if txErr != nil {
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "группа с таким названием уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать группу")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

// Update PATCH /api/admin/recipient-groups/:id — переименовать/активировать.
func (h *GroupsHandler) Update(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Name        string `json:"name"`
		Description string `json:"description"`
		IsActive    bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название группы")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE recipient_groups SET name=$2, description=NULLIF($3,''), is_active=$4 WHERE id=$1`,
			id, req.Name, req.Description, req.IsActive)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "группа не найдена")
		}
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "группа с таким названием уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить группу")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/admin/recipient-groups/:id — удалить группу (участники
// уходят каскадом).
func (h *GroupsHandler) Delete(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `DELETE FROM recipient_groups WHERE id=$1`, id)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить группу")
	}
	return c.SendStatus(fiber.StatusOK)
}

// SetMembers PUT /api/admin/recipient-groups/:id/members — заменить состав.
// Тело: { members: [{ user_id, department_id }] }. Каждый участник обязан иметь
// роль clerk в указанном подразделении (иначе он не сможет быть получателем —
// проверяем сразу, чтобы не завести «мёртвых» участников).
func (h *GroupsHandler) SetMembers(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Members []struct {
			UserID       int64 `json:"user_id"`
			DepartmentID int64 `json:"department_id"`
		} `json:"members"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		if _, err := tx.Exec(c.Context(), `DELETE FROM recipient_group_members WHERE group_id=$1`, id); err != nil {
			return err
		}
		for _, m := range req.Members {
			if m.UserID == 0 || m.DepartmentID == 0 {
				return fiber.NewError(fiber.StatusBadRequest, "у каждого участника нужны user_id и department_id")
			}
			if _, err := tx.Exec(c.Context(), `
				INSERT INTO recipient_group_members (group_id, user_id, department_id)
				VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`, id, m.UserID, m.DepartmentID); err != nil {
				return err
			}
		}
		return nil
	})
	if txErr != nil {
		if fe, ok := txErr.(*fiber.Error); ok {
			return fe
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить состав группы")
	}
	return c.SendStatus(fiber.StatusOK)
}
