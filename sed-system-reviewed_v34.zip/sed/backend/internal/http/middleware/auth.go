package middleware

import (
	"strings"

	"github.com/gofiber/fiber/v2"
	"sed-system/backend/internal/service"
)

const (
	CtxUserID  = "userID"
	CtxIsAdmin = "isAdmin"
	CtxLogin   = "login"
)

// JWTAuth проверяет Bearer-токен и кладёт userID/isAdmin в контекст
// запроса. Все хендлеры, работающие с защищёнными RLS-таблицами, обязаны
// использовать db.WithUserTx с этими значениями.
func JWTAuth(auth *service.AuthService) fiber.Handler {
	return func(c *fiber.Ctx) error {
		header := c.Get("Authorization")
		if !strings.HasPrefix(header, "Bearer ") {
			return fiber.NewError(fiber.StatusUnauthorized, "missing bearer token")
		}
		tokenStr := strings.TrimPrefix(header, "Bearer ")
		claims, err := auth.ParseToken(tokenStr)
		if err != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "invalid token")
		}
		c.Locals(CtxUserID, claims.UserID)
		c.Locals(CtxIsAdmin, claims.IsAdmin)
		c.Locals(CtxLogin, claims.Login)
		return c.Next()
	}
}
