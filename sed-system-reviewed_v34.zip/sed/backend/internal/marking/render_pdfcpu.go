package marking

import (
	"bytes"
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"sync"

	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"

	"sed-system/backend/internal/config"
)

// Реальное нанесение штампов на PDF через pdfcpu (чистый Go, без cgo).
//
// КИРИЛЛИЦА: core-шрифты PDF (Helvetica и пр.) кириллицу не отображают,
// поэтому для русскоязычных штампов НУЖЕН TTF-шрифт с кириллицей. Путь к нему
// задаётся в config.yaml (marking.font_file); шрифт one-time устанавливается в
// pdfcpu и используется по имени (marking.font_name). Если шрифт не задан/не
// установился — падать нельзя (документ должен открываться), поэтому в этом
// случае используется Helvetica (латиница/цифры отрисуются, кириллица — нет),
// а в лог пишется предупреждение.

var (
	fontOnce sync.Once
	fontName string // имя установленного шрифта; "" => Helvetica
)

// Configure подключает реальный рендер штампов. Вызывается один раз из main
// после загрузки конфигурации. Устанавливает кириллический шрифт (если задан)
// и присваивает marking.RenderHook.
func Configure(cfg config.MarkingConfig) {
	fontOnce.Do(func() {
		// Имя шрифта берём из конфига в любом случае — это позволяет на Windows
		// (где автоматическая установка через InstallFonts может не сработать)
		// установить шрифт ОДИН раз вручную командой `pdfcpu fonts install
		// DejaVuSans.ttf` и просто указать font_name в config.yaml.
		if cfg.FontName != "" {
			fontName = cfg.FontName
		} else if cfg.FontFile != "" {
			base := filepath.Base(cfg.FontFile)
			fontName = strings.TrimSuffix(base, filepath.Ext(base))
		}
		// Если задан файл — пробуем автоматически установить (Linux/Docker).
		if cfg.FontFile != "" {
			if err := api.InstallFonts([]string{cfg.FontFile}); err != nil {
				log.Printf("marking: авто-установка шрифта %s не удалась: %v. "+
					"Если вы на Windows — установите шрифт один раз командой "+
					"`pdfcpu fonts install <path>` и укажите marking.font_name; "+
					"иначе кириллица в штампах не отобразится.", cfg.FontFile, err)
			} else {
				log.Printf("marking: шрифт %q установлен и будет использован для штампов", fontName)
			}
		}
		if fontName == "" {
			log.Printf("marking: шрифт не задан — кириллица в штампах не отобразится (укажите marking.font_name/font_file)")
		}
	})

	RenderHook = renderWithPDFCPU
}

func renderWithPDFCPU(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 {
		return original, nil
	}
	buf := make([]byte, len(original))
	copy(buf, original)

	for _, s := range specs {
		desc := buildWatermarkDesc(s)
		wm, err := api.TextWatermark(s.Text, desc, true /*onTop*/, false /*update*/, types.POINTS)
		if err != nil {
			return original, fmt.Errorf("build watermark: %w", err)
		}
		var out bytes.Buffer
		// Наносим на первую страницу; для «на всех» передайте nil вместо {"1"}.
		if err := api.AddWatermarks(bytes.NewReader(buf), &out, []string{"1"}, wm, nil); err != nil {
			return original, fmt.Errorf("apply watermark: %w", err)
		}
		buf = out.Bytes()
	}
	return buf, nil
}

// buildWatermarkDesc собирает строку-описание watermark на мини-языке pdfcpu.
func buildWatermarkDesc(s Spec) string {
	parts := []string{
		fmt.Sprintf("pos:%s", s.Position),
		fmt.Sprintf("offset:%d %d", int(s.OffsetX), int(s.OffsetY)),
		fmt.Sprintf("points:%d", s.FontSize),
		fmt.Sprintf("fillcolor:%s", s.Color),
		"scalefactor:1 abs",
		"rotation:0",
		"opacity:1",
	}
	if fontName != "" {
		parts = append(parts, fmt.Sprintf("fontname:%s", fontName))
	}
	if s.Border {
		// ВАЖНО: pdfcpu ждёт ЧИСЛОВУЮ ширину рамки. "border:on" приводит к
		// strconv.ParseFloat("on") и падению маркировки — задаём ширину 1pt.
		parts = append(parts, "border:1")
	}
	return strings.Join(parts, ", ")
}
