package marking

import "testing"

func TestSubstitute(t *testing.T) {
	ph := Placeholders{
		"signer_fio":      "Смирнов А.А.",
		"signer_position": "Начальник управления",
		"outgoing_number": "Исх-5-2026/ЭД",
	}
	cases := []struct{ in, want string }{
		{"Подписал: {signer_fio}", "Подписал: Смирнов А.А."},
		{"Должность: {signer_position}", "Должность: Начальник управления"},
		{"Рег. №: {outgoing_number}", "Рег. №: Исх-5-2026/ЭД"},
		{"нет плейсхолдеров", "нет плейсхолдеров"},
		{"неизвестный {missing}", "неизвестный {missing}"}, // отсутствующий оставляем как есть
	}
	for _, c := range cases {
		if got := substitute(c.in, ph); got != c.want {
			t.Errorf("substitute(%q) = %q, want %q", c.in, got, c.want)
		}
	}
}

func TestHexToPDFColor(t *testing.T) {
	cases := []struct{ in, want string }{
		{"#000000", "0.000 0.000 0.000"},
		{"#ffffff", "1.000 1.000 1.000"},
		{"#1a5fb4", "0.102 0.373 0.706"},
		{"bad", "0 0 0"},
	}
	for _, c := range cases {
		if got := hexToPDFColor(c.in); got != c.want {
			t.Errorf("hexToPDFColor(%q) = %q, want %q", c.in, got, c.want)
		}
	}
}

func TestPositionToAnchor(t *testing.T) {
	m := map[string]string{"top_left": "tl", "bottom_right": "br", "center": "c", "unknown": "br"}
	for in, want := range m {
		if got := positionToAnchor(in); got != want {
			t.Errorf("positionToAnchor(%q) = %q, want %q", in, got, want)
		}
	}
}
