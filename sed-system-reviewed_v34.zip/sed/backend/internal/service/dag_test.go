package service

import (
	"reflect"
	"sort"
	"testing"
)

func sortedIDs(ids []int64) []int64 {
	out := append([]int64{}, ids...)
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}

func TestReadyStages_NoDependencies(t *testing.T) {
	stages := []StageDep{
		{ID: 1, Status: "waiting_deps"},
		{ID: 2, Status: "waiting_deps"},
	}
	got := sortedIDs(ReadyStages(stages))
	want := []int64{1, 2}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
}

func TestReadyStages_LinearChain(t *testing.T) {
	// 1 -> 2 -> 3 (2 зависит от 1, 3 зависит от 2)
	stages := []StageDep{
		{ID: 1, Status: "approved"},
		{ID: 2, Status: "waiting_deps", DependsOn: []int64{1}},
		{ID: 3, Status: "waiting_deps", DependsOn: []int64{2}},
	}
	got := ReadyStages(stages)
	want := []int64{2} // 3 ждёт 2, который ещё не approved
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
}

func TestReadyStages_Diamond(t *testing.T) {
	// 1 и 2 параллельно, 3 зависит от ОБОИХ (диамант)
	stages := []StageDep{
		{ID: 1, Status: "approved"},
		{ID: 2, Status: "pending"}, // ещё не approved
		{ID: 3, Status: "waiting_deps", DependsOn: []int64{1, 2}},
	}
	got := ReadyStages(stages)
	if len(got) != 0 {
		t.Errorf("stage 3 не должен быть готов, пока stage 2 не approved; got %v", got)
	}

	stages[1].Status = "approved"
	got = ReadyStages(stages)
	want := []int64{3}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("после approve обоих родителей got %v, want %v", got, want)
	}
}

func TestReadyStages_AlreadyPendingIsIgnored(t *testing.T) {
	// Этап уже pending (активирован ранее) — не должен повторно попадать в ready.
	stages := []StageDep{
		{ID: 1, Status: "approved"},
		{ID: 2, Status: "pending", DependsOn: []int64{1}},
	}
	got := ReadyStages(stages)
	if len(got) != 0 {
		t.Errorf("pending-этап не должен считаться ready повторно; got %v", got)
	}
}

func TestReadyStages_RejectedDependencyBlocksForever(t *testing.T) {
	stages := []StageDep{
		{ID: 1, Status: "rejected"},
		{ID: 2, Status: "waiting_deps", DependsOn: []int64{1}},
	}
	got := ReadyStages(stages)
	if len(got) != 0 {
		t.Errorf("отклонённая зависимость не должна активировать этап; got %v", got)
	}
}

func TestReadyStages_MixedParallelAndSequential(t *testing.T) {
	// Смешанный маршрут: 1 и 2 параллельно независимы; 3 зависит только от 1;
	// 4 зависит от 2 и 3.
	stages := []StageDep{
		{ID: 1, Status: "approved"},
		{ID: 2, Status: "waiting_deps"},
		{ID: 3, Status: "waiting_deps", DependsOn: []int64{1}},
		{ID: 4, Status: "waiting_deps", DependsOn: []int64{2, 3}},
	}
	got := sortedIDs(ReadyStages(stages))
	want := []int64{2, 3} // 2 не имеет зависимостей вовсе, 3 — зависимость approved
	if !reflect.DeepEqual(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
}
