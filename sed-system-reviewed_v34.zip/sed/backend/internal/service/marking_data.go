package service

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"sed-system/backend/internal/marking"
)

type MarkingDataService struct{}

func NewMarkingDataService() *MarkingDataService { return &MarkingDataService{} }

// fmtStamp — единый формат даты-времени для штампов и интерфейса:
// "22:00:04 21.07.2026 г." (время, затем дата).
func fmtStamp(t time.Time) string {
	return t.Format("15:04:05 02.01.2006") + " г."
}

// Collect собирает данные для штампов документа: исходящий номер, подписанта
// (ФИО + должность + время подписи), место хранения, отпечаток. Если документ
// ещё не подписан — соответствующие ключи не заполняются.
func (s *MarkingDataService) Collect(ctx context.Context, tx pgx.Tx, documentID int64) (marking.Placeholders, error) {
	ph := marking.Placeholders{}
	// {document_id} — доступен всегда (напр. для пути в хранилище).
	ph[marking.KeyDocumentID] = fmt.Sprintf("%d", documentID)
	var outgoingNumber *string
	var archivedAt *time.Time
	if err := tx.QueryRow(ctx, `SELECT outgoing_number, archived_at FROM documents WHERE id=$1`, documentID).Scan(&outgoingNumber, &archivedAt); err != nil {
		return ph, err
	}
	if outgoingNumber != nil {
		ph[marking.KeyOutgoingNumber] = *outgoingNumber
	}
	// Факт переноса в архив (штамп 4).
	if archivedAt != nil {
		ph[marking.KeyArchivedAt] = fmtStamp(*archivedAt)
		ph[marking.KeyArchiveYear] = archivedAt.Format("2006")
	}

	// ФИО и должность берём ИЗ СНИМКА на момент подписи (signer_fio/
	// signer_position в document_signatures), а не из текущего профиля —
	// должность пользователя могла измениться после подписания.
	var snapFIO, snapPos, curFIO, curPos, storage, hash *string
	var signedAt *time.Time
	err := tx.QueryRow(ctx, `
		SELECT ds.signer_fio, ds.signer_position, u.full_name, u.position,
		       ds.storage_resource, ds.signature_hash, ds.signed_at
		FROM document_signatures ds
		JOIN users u ON u.id = ds.signer_id
		WHERE ds.document_id = $1
		ORDER BY ds.signed_at DESC
		LIMIT 1`, documentID).Scan(&snapFIO, &snapPos, &curFIO, &curPos, &storage, &hash, &signedAt)
	if err == nil {
		fio := curFIO
		if snapFIO != nil && *snapFIO != "" {
			fio = snapFIO
		}
		pos := curPos
		if snapPos != nil && *snapPos != "" {
			pos = snapPos
		}
		if fio != nil {
			ph[marking.KeySignerFIO] = *fio
		}
		if pos != nil {
			ph[marking.KeySignerPosition] = *pos
		}
		if storage != nil {
			ph[marking.KeyStorage] = *storage
		}
		if hash != nil {
			ph[marking.KeySignHash] = *hash // полный хэш, без усечения
		}
		if signedAt != nil {
			ph[marking.KeySignTime] = fmtStamp(*signedAt)
			ph[marking.KeySignDate] = signedAt.Format("02.01.2006")
		}
	} else if err != pgx.ErrNoRows {
		return ph, fmt.Errorf("collect signature: %w", err)
	}
	return ph, nil
}

// CollectOwner добавляет в маркировку данные ВЛАДЕЛЬЦА экземпляра (для штампа
// «Экз. №»): его ФИО, подразделение и личный номер экземпляра. Используется при
// выдаче на печать, чтобы на копии было видно, чей это экземпляр.
func (s *MarkingDataService) CollectOwner(ctx context.Context, tx pgx.Tx, documentID, userID int64, ph marking.Placeholders) error {
	var fio, dept string
	var copyNum *int
	if err := tx.QueryRow(ctx, `
		SELECT u.full_name, coalesce(d.name,''), c.copy_number
		FROM users u
		LEFT JOIN departments d ON d.id = u.primary_department_id
		LEFT JOIN document_copies c ON c.document_id = $2 AND c.user_id = u.id
		WHERE u.id = $1`, userID, documentID).Scan(&fio, &dept, &copyNum); err != nil {
		return fmt.Errorf("collect owner: %w", err)
	}
	ph[marking.KeyOwnerFIO] = fio
	ph[marking.KeyOwnerDept] = dept
	if copyNum != nil {
		ph[marking.KeyInstanceLabel] = fmt.Sprintf("Экз. № %d", *copyNum)
		ph[marking.KeyPrintCopy] = fmt.Sprintf("%d", *copyNum)
	}
	return nil
}

// CollectIncoming дополняет ph сведениями о входящем экземпляре для
// подразделения смотрящего (штамп "ПОЛУЧЕНО"). Если экземпляра нет — ph не
// меняется.
func (s *MarkingDataService) CollectIncoming(ctx context.Context, tx pgx.Tx, documentID, viewerDeptID int64, ph marking.Placeholders) error {
	if viewerDeptID == 0 {
		return nil
	}
	var incNumber, instLabel, deptName, receivedBy *string
	var receivedAt *time.Time
	err := tx.QueryRow(ctx, `
		SELECT i.incoming_number, i.instance_label, dep.name, u.full_name, i.first_viewed_at
		FROM document_incoming_instances i
		JOIN departments dep ON dep.id = i.receiving_department_id
		LEFT JOIN users u ON u.id = i.received_by
		WHERE i.document_id = $1 AND i.receiving_department_id = $2
		LIMIT 1`, documentID, viewerDeptID).Scan(&incNumber, &instLabel, &deptName, &receivedBy, &receivedAt)
	if err == pgx.ErrNoRows {
		return nil
	}
	if err != nil {
		return fmt.Errorf("collect incoming: %w", err)
	}
	if incNumber != nil {
		ph[marking.KeyIncomingNumber] = *incNumber
	}
	if instLabel != nil {
		ph[marking.KeyInstanceLabel] = *instLabel
	}
	if deptName != nil {
		ph[marking.KeyReceivingDept] = *deptName
	}
	if receivedBy != nil {
		ph[marking.KeyReceivedBy] = *receivedBy
	}
	if receivedAt != nil {
		ph[marking.KeyReceivedTime] = fmtStamp(*receivedAt)
	}
	return nil
}
