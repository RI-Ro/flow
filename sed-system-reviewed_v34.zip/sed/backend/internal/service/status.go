package service

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

type StatusService struct{}

func NewStatusService() *StatusService { return &StatusService{} }

// StageCounts — сколько этапов каждого статуса у каждого типа этапа
// (stage_type -> status -> count). Вынесено в отдельный тип, чтобы
// DeriveStatus была чистой функцией, тестируемой без БД.
type StageCounts map[string]map[string]int

// DeriveStatus выводит статус документа из состояния его этапов.
// Порядок приоритета: rejected > hierarchy > cross_dept > signing.
// Пустая строка означает "все этапы согласования и подписи пройдены —
// дальнейший переход (signed/sent) выполняет другой сервис (SigningService/
// SendService), здесь статус трогать не нужно, чтобы не затереть его".
func DeriveStatus(counts StageCounts) string {
	notApproved := func(t string) int {
		total := 0
		for status, n := range counts[t] {
			if status != "approved" {
				total += n
			}
		}
		return total
	}
	hasRejected := func(t string) bool { return counts[t]["rejected"] > 0 }

	switch {
	case hasRejected("hierarchy") || hasRejected("cross_dept") || hasRejected("signing"):
		return "rejected"
	case notApproved("hierarchy") > 0:
		return "on_approval_hierarchy"
	case notApproved("cross_dept") > 0:
		return "on_approval_cross_dept"
	case notApproved("signing") > 0:
		return "on_signing"
	default:
		return ""
	}
}

// Recompute читает состояние этапов документа, вызывает чистую DeriveStatus
// и, если статус изменился, обновляет documents + пишет запись в
// document_history. Вызывается после каждого Decide() по этапу.
func (s *StatusService) Recompute(ctx context.Context, tx pgx.Tx, documentID int64) (string, error) {
	rows, err := tx.Query(ctx, `SELECT stage_type, status FROM approval_stages WHERE document_id = $1`, documentID)
	if err != nil {
		return "", fmt.Errorf("query stages: %w", err)
	}
	defer rows.Close()

	counts := StageCounts{"hierarchy": {}, "cross_dept": {}, "signing": {}}
	for rows.Next() {
		var stageType, status string
		if err := rows.Scan(&stageType, &status); err != nil {
			return "", err
		}
		if counts[stageType] == nil {
			counts[stageType] = map[string]int{}
		}
		counts[stageType][status]++
	}
	if err := rows.Err(); err != nil {
		return "", err
	}

	newStatus := DeriveStatus(counts)
	if newStatus == "" {
		return "", nil
	}

	var currentStatus string
	if err := tx.QueryRow(ctx, `SELECT status FROM documents WHERE id = $1`, documentID).Scan(&currentStatus); err != nil {
		return "", fmt.Errorf("lookup current status: %w", err)
	}
	if currentStatus == newStatus {
		return currentStatus, nil
	}

	if _, err := tx.Exec(ctx, `UPDATE documents SET status = $1 WHERE id = $2`, newStatus, documentID); err != nil {
		return "", fmt.Errorf("update status: %w", err)
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, event_type, from_status, to_status)
		VALUES ($1, 'status_changed', $2, $3)`, documentID, currentStatus, newStatus)
	if err != nil {
		return "", fmt.Errorf("insert history: %w", err)
	}
	return newStatus, nil
}
