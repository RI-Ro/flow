package service

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)

type NumberingService struct{}

func NewNumberingService() *NumberingService { return &NumberingService{} }

// FormatNumber — чистая функция форматирования номера (тестируется без БД).
// kind: "outgoing" -> "ИСХ-...", "incoming" -> "ВХ-...".
// Формат: {label}-{pathPrefix}-{value}/{year}. pathPrefix — префикс
// подразделения из БД (иерархический numbering_prefix, напр. "9/8/7", либо,
// если он пуст, краткий код outgoing_prefix, напр. "ГУ").
// Примеры: ИСХ-9/8/7-231/2026, ИСХ-ГУ-231/2026, ВХ-9/8/7-21/2026.
func FormatNumber(kind string, value, year int, pathPrefix string) string {
	label := "ИСХ"
	if kind == "incoming" {
		label = "ВХ"
	}
	if pathPrefix != "" {
		return fmt.Sprintf("%s-%s-%d/%d", label, pathPrefix, value, year)
	}
	return fmt.Sprintf("%s-%d/%d", label, value, year)
}

func (s *NumberingService) next(ctx context.Context, tx pgx.Tx, departmentID int64, seqType string) (string, error) {
	year := time.Now().Year()
	var value int
	err := tx.QueryRow(ctx, `
		INSERT INTO numbering_sequences (department_id, year, seq_type, last_value)
		VALUES ($1, $2, $3, 1)
		ON CONFLICT (department_id, year, seq_type)
		DO UPDATE SET last_value = numbering_sequences.last_value + 1
		RETURNING last_value`, departmentID, year, seqType).Scan(&value)
	if err != nil {
		return "", fmt.Errorf("next %s seq: %w", seqType, err)
	}

	// pathPrefix ДОЛЖЕН быть уникальным на подразделение, иначе номера разных
	// подразделений совпадут (напр. "ИСХ-1000-2026/SED" у двух отделов) и
	// нарушат UNIQUE(outgoing_number). Берём numbering_prefix, а если он пуст —
	// откатываемся на outgoing_prefix (он UNIQUE по подразделению).
	var pathPrefix string
	if err := tx.QueryRow(ctx, `
		SELECT coalesce(NULLIF(numbering_prefix,''), outgoing_prefix)
		FROM departments WHERE id = $1`, departmentID).Scan(&pathPrefix); err != nil {
		return "", fmt.Errorf("lookup department prefix: %w", err)
	}

	return FormatNumber(seqType, value, year, pathPrefix), nil
}

// NextOutgoing атомарно выдаёт следующий номер в последовательности
// (department_id, year, 'outgoing') через INSERT ... ON CONFLICT DO UPDATE,
// без блокировок уровня приложения и без гонок при параллельных подписаниях.
// Формат: Исх-{N}-{year}/{PREFIX}
func (s *NumberingService) NextOutgoing(ctx context.Context, tx pgx.Tx, departmentID int64) (string, error) {
	return s.next(ctx, tx, departmentID, "outgoing")
}

// NextIncoming — аналогично, но для журнала входящих конкретного
// подразделения-получателя. Формат: Вх-{N}-{year}/{PREFIX}
func (s *NumberingService) NextIncoming(ctx context.Context, tx pgx.Tx, departmentID int64) (string, error) {
	return s.next(ctx, tx, departmentID, "incoming")
}
