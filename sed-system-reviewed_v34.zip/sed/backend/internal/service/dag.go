package service

// StageDep — минимальное описание этапа для расчёта готовности к активации:
// его текущий статус и список этапов, от которых он зависит.
type StageDep struct {
	ID        int64
	Status    string // waiting_deps | pending | approved | rejected
	DependsOn []int64
}

// ReadyStages возвращает ID этапов в статусе waiting_deps, у которых ВСЕ
// зависимости approved. Это чистое зеркало SQL-запроса в
// ApprovalService.Decide (JOIN approval_stage_dependencies ... NOT EXISTS
// ...) — вынесено отдельной функцией, чтобы протестировать семантику DAG
// (линейные цепочки, диамант, параллельные ветки) без поднятия БД.
// Реальный источник истины в проде — SQL-запрос в approval.go; эта функция
// существует для юнит-тестирования алгоритма, а не как замена SQL.
func ReadyStages(stages []StageDep) []int64 {
	byID := make(map[int64]StageDep, len(stages))
	for _, s := range stages {
		byID[s.ID] = s
	}

	var ready []int64
	for _, s := range stages {
		if s.Status != "waiting_deps" {
			continue
		}
		allApproved := true
		for _, depID := range s.DependsOn {
			dep, ok := byID[depID]
			if !ok || dep.Status != "approved" {
				allApproved = false
				break
			}
		}
		if allApproved {
			ready = append(ready, s.ID)
		}
	}
	return ready
}
