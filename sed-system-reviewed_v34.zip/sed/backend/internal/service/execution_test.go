package service

import "testing"

func TestAllRecipientsDone(t *testing.T) {
	cases := []struct {
		name             string
		total, completed int
		want             bool
	}{
		{"нет получателей", 0, 0, false},
		{"один не отметился", 1, 0, false},
		{"один отметился", 1, 1, true},
		{"двое из трёх", 3, 2, false},
		{"все трое", 3, 3, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := AllRecipientsDone(tc.total, tc.completed); got != tc.want {
				t.Errorf("AllRecipientsDone(%d,%d)=%v, want %v", tc.total, tc.completed, got, tc.want)
			}
		})
	}
}
