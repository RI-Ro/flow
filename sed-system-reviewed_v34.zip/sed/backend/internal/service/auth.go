package service

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/jackc/pgx/v5"
	"golang.org/x/crypto/bcrypt"
)

var ErrInvalidCredentials = errors.New("invalid login or password")

type AuthService struct {
	secret []byte
	ttl    time.Duration
}

func NewAuthService(secret string, ttl time.Duration) *AuthService {
	return &AuthService{secret: []byte(secret), ttl: ttl}
}

type Claims struct {
	UserID  int64  `json:"uid"`
	Login   string `json:"login"`
	IsAdmin bool   `json:"is_admin"`
	jwt.RegisteredClaims
}

// Login проверяет логин/пароль (bcrypt) в отдельной, не-RLS транзакции
// (аутентификация выполняется ДО того, как у нас есть app.user_id; строка
// users не защищена RLS, т.к. поиск идёт по login, а не по id текущего
// пользователя).
func (s *AuthService) Login(ctx context.Context, tx pgx.Tx, login, password string) (int64, string, bool, error) {
	var id int64
	var hash string
	var isAdmin bool
	err := tx.QueryRow(ctx, `
		SELECT u.id, u.password_hash, EXISTS(
			SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id AND ur.role = 'admin'
		)
		FROM users u WHERE u.login = $1 AND u.is_active = true`, login).Scan(&id, &hash, &isAdmin)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, "", false, ErrInvalidCredentials
		}
		return 0, "", false, fmt.Errorf("lookup user: %w", err)
	}
	if err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)); err != nil {
		return 0, "", false, ErrInvalidCredentials
	}
	return id, login, isAdmin, nil
}

func (s *AuthService) IssueToken(userID int64, login string, isAdmin bool) (string, error) {
	claims := Claims{
		UserID:  userID,
		Login:   login,
		IsAdmin: isAdmin,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(s.ttl)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(s.secret)
}

func (s *AuthService) ParseToken(tokenStr string) (*Claims, error) {
	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return s.secret, nil
	})
	if err != nil || !token.Valid {
		return nil, fmt.Errorf("invalid token: %w", err)
	}
	return claims, nil
}
