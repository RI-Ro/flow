package service

import (
	"reflect"
	"testing"
)

func mkRoleOK(m map[int64][]string) func(int64, string) bool {
	stageRole := map[string]string{"hierarchy": "approver_hierarchy", "cross_dept": "approver_cross_dept"}
	return func(uid int64, stageType string) bool {
		need := stageRole[stageType]
		for _, r := range m[uid] {
			if r == need {
				return true
			}
		}
		return false
	}
}
func mkSignerOK(m map[int64][]string) func(int64) bool {
	return func(uid int64) bool {
		for _, r := range m[uid] {
			if r == "signer" {
				return true
			}
		}
		return false
	}
}

func TestValidateRoute_NoSigner(t *testing.T) {
	if err := ValidateRoute(RouteInput{SignerIDs: nil}, 1, mkRoleOK(nil), mkSignerOK(nil)); err != ErrNoSigner {
		t.Errorf("ожидали ErrNoSigner, got %v", err)
	}
}

func TestValidateRoute_SelfApproval(t *testing.T) {
	roles := map[int64][]string{2: {"approver_hierarchy"}, 9: {"signer"}}
	in := RouteInput{Approvers: []ApproverInput{{StageType: "hierarchy", ApproverID: 1}}, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != ErrSelfApproval {
		t.Errorf("ожидали ErrSelfApproval, got %v", err)
	}
}

func TestValidateRoute_Duplicate(t *testing.T) {
	roles := map[int64][]string{2: {"approver_hierarchy"}, 9: {"signer"}}
	in := RouteInput{Approvers: []ApproverInput{
		{StageType: "hierarchy", ApproverID: 2},
		{StageType: "hierarchy", ApproverID: 2},
	}, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != ErrDuplicateApprover {
		t.Errorf("ожидали ErrDuplicateApprover, got %v", err)
	}
}

func TestValidateRoute_WrongApproverRole(t *testing.T) {
	roles := map[int64][]string{2: {"signer"}, 9: {"signer"}}
	in := RouteInput{Approvers: []ApproverInput{{StageType: "hierarchy", ApproverID: 2}}, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != ErrApproverWrongRole {
		t.Errorf("ожидали ErrApproverWrongRole, got %v", err)
	}
}

func TestValidateRoute_SignerWrongRole(t *testing.T) {
	roles := map[int64][]string{2: {"approver_hierarchy"}, 9: {"approver_cross_dept"}}
	in := RouteInput{Approvers: []ApproverInput{{StageType: "hierarchy", ApproverID: 2}}, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != ErrSignerWrongRole {
		t.Errorf("ожидали ErrSignerWrongRole, got %v", err)
	}
}

func TestValidateRoute_OK_SkipApproval(t *testing.T) {
	roles := map[int64][]string{9: {"signer"}}
	in := RouteInput{Approvers: nil, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != nil {
		t.Errorf("пропуск согласования должен быть валиден, got %v", err)
	}
}

func TestBuildStages_SignatureLastDependsOnAll(t *testing.T) {
	in := RouteInput{Approvers: []ApproverInput{
		{StageType: "hierarchy", ApproverID: 2},
		{StageType: "cross_dept", ApproverID: 3},
	}, Sequential: false, SignerIDs: []int64{9}}
	stages := BuildStages(in)
	if len(stages) != 3 {
		t.Fatalf("ожидали 3 этапа, got %d", len(stages))
	}
	sign := stages[len(stages)-1]
	if sign.StageType != "signing" || sign.ApproverID != 9 {
		t.Errorf("последний этап — подпись подписанта 9, got %+v", sign)
	}
	if !reflect.DeepEqual(sign.DependsOnIdx, []int{0, 1}) {
		t.Errorf("подпись зависит от всех согласующих [0 1], got %v", sign.DependsOnIdx)
	}
}

func TestBuildStages_Sequential(t *testing.T) {
	in := RouteInput{Approvers: []ApproverInput{
		{StageType: "hierarchy", ApproverID: 2},
		{StageType: "hierarchy", ApproverID: 3},
	}, Sequential: true, SignerIDs: []int64{9}}
	stages := BuildStages(in)
	if !reflect.DeepEqual(stages[1].DependsOnIdx, []int{0}) {
		t.Errorf("Sequential: второй зависит от первого, got %v", stages[1].DependsOnIdx)
	}
}

func TestBuildStages_SkipApproval_SignImmediate(t *testing.T) {
	stages := BuildStages(RouteInput{Approvers: nil, SignerIDs: []int64{9}})
	if len(stages) != 1 || stages[0].StageType != "signing" {
		t.Fatalf("без согласующих только подпись, got %+v", stages)
	}
	if len(stages[0].DependsOnIdx) != 0 {
		t.Errorf("подпись без согласующих активна сразу, got %v", stages[0].DependsOnIdx)
	}
}
