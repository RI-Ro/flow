package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var (
	ErrNotRecipient   = errors.New("пользователь не является получателем документа")
	ErrAlreadyDone    = errors.New("отметка об исполнении уже проставлена")
	ErrDocumentNotSent = errors.New("документ ещё не направлен получателям")
)

type ExecutionService struct{}

func NewExecutionService() *ExecutionService { return &ExecutionService{} }

// AllRecipientsDone — чистая функция: все ли получатели отметили исполнение.
// Вынесена ради юнит-теста без БД. total — сколько получателей всего,
// completed — сколько с проставленным completed_at.
func AllRecipientsDone(total, completed int) bool {
	return total > 0 && total == completed
}

// MarkCompleted проставляет отметку об исполнении текущему получателю. Если
// после этого все получатели документа отметились — документ переходит в
// 'executed' и фиксируется executed_at (для авто-архива в следующем году).
// Возвращает признак того, что документ стал executed.
func (s *ExecutionService) MarkCompleted(ctx context.Context, tx pgx.Tx, documentID, userID int64, note string) (becameExecuted bool, err error) {
	// Проверяем, что пользователь — получатель и ещё не отметился.
	var alreadyDone bool
	err = tx.QueryRow(ctx, `
		SELECT completed_at IS NOT NULL
		FROM document_recipients
		WHERE document_id = $1 AND recipient_user_id = $2`, documentID, userID).Scan(&alreadyDone)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return false, ErrNotRecipient
		}
		return false, fmt.Errorf("lookup recipient: %w", err)
	}
	if alreadyDone {
		return false, ErrAlreadyDone
	}

	_, err = tx.Exec(ctx, `
		UPDATE document_recipients
		SET completed_at = now(), completion_note = $3
		WHERE document_id = $1 AND recipient_user_id = $2`, documentID, userID, note)
	if err != nil {
		return false, fmt.Errorf("mark completed: %w", err)
	}

	// Считаем total/completed одним запросом.
	var total, completed int
	err = tx.QueryRow(ctx, `
		SELECT count(*), count(completed_at)
		FROM document_recipients WHERE document_id = $1`, documentID).Scan(&total, &completed)
	if err != nil {
		return false, fmt.Errorf("count recipients: %w", err)
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'execution_marked', $3)`, documentID, userID, note)
	if err != nil {
		return false, fmt.Errorf("insert history: %w", err)
	}

	if !AllRecipientsDone(total, completed) {
		return false, nil
	}

	// Все отметились -> документ исполнен.
	_, err = tx.Exec(ctx, `
		UPDATE documents SET status = 'executed', executed_at = now() WHERE id = $1`, documentID)
	if err != nil {
		return false, fmt.Errorf("set executed: %w", err)
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, to_status)
		VALUES ($1, $2, 'executed', 'executed')`, documentID, userID)
	if err != nil {
		return false, fmt.Errorf("insert executed history: %w", err)
	}
	return true, nil
}

// ArchiveExecutedFromPreviousYears переводит в 'archived' все документы,
// исполненные в предыдущих годах (executed_at.year < текущий год). Идемпотентно.
// Вызывается фоновой задачей раз в сутки (см. config lifecycle.archive_check_cron).
// Выполняется в отдельной admin-транзакции (RLS обходится через app.is_admin).
// ArchiveExecutedFromPreviousYears переводит в 'archived' все исполненные
// документы, у которых с даты исполнения прошло более 14 дней. Задержка нужна
// на случай, если исполненный документ потребуется дослать (из архива дослать
// уже нельзя). Имя метода сохранено для совместимости с планировщиком.
func (s *ExecutionService) ArchiveExecutedFromPreviousYears(ctx context.Context, tx pgx.Tx) (int64, error) {
	tag, err := tx.Exec(ctx, `
		UPDATE documents
		SET status = 'archived', archived_at = now()
		WHERE status = 'executed'
		  AND executed_at IS NOT NULL
		  AND executed_at < now() - interval '14 days'`)
	if err != nil {
		return 0, fmt.Errorf("auto archive: %w", err)
	}
	return tag.RowsAffected(), nil
}
