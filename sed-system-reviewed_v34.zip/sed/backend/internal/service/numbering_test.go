package service

import "testing"

func TestFormatNumber(t *testing.T) {
	cases := []struct {
		name   string
		kind   string
		value  int
		year   int
		prefix string // префикс подразделения (numbering_prefix или outgoing_prefix)
		want   string
	}{
		{"outgoing no prefix", "outgoing", 231, 2026, "", "ИСХ-231/2026"},
		{"outgoing hierarchical prefix", "outgoing", 231, 2026, "9/8/7", "ИСХ-9/8/7-231/2026"},
		{"outgoing code prefix", "outgoing", 231, 2026, "ГУ", "ИСХ-ГУ-231/2026"},
		{"incoming hierarchical", "incoming", 21, 2026, "9/8/7", "ВХ-9/8/7-21/2026"},
		{"incoming code", "incoming", 21, 2026, "ГУ", "ВХ-ГУ-21/2026"},
		{"unknown kind defaults to outgoing label", "unknown", 5, 2026, "", "ИСХ-5/2026"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := FormatNumber(tc.kind, tc.value, tc.year, tc.prefix)
			if got != tc.want {
				t.Errorf("FormatNumber(%q, %d, %d, %q) = %q, want %q", tc.kind, tc.value, tc.year, tc.prefix, got, tc.want)
			}
		})
	}
}
