package service

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// NotifyDocumentEvent — единая точка уведомлений о ЛЮБОМ изменении документа
// (направление на согласование, согласование, отклонение, направление на
// подпись, подпись, направление адресатам, правка и т.д.).
//
// Заинтересованные пользователи = все, у кого есть доступ к документу
// (document_access): автор, согласующие, подписант, контролёр, получатели
// рассылки, ознакомленные, исполнители поручений. Это автоматически учитывает
// и статус, и видимость (доступ выдаётся ровно тогда, когда роль становится
// релевантной). Актору (инициатору события) уведомление не создаётся.
//
// Функция ВСТАВЛЯЕТ персистентные строки в notifications (их читает «колокол»
// на фронте) и возвращает id получателей, чтобы вызывающий код разослал им
// realtime-пинг через ws.Hub. Вызывать внутри той же транзакции, что и само
// изменение, — тогда уведомления консистентны с новым состоянием.
func NotifyDocumentEvent(ctx context.Context, tx pgx.Tx, documentID int64, kind string, actorID int64, payloadJSON string) ([]int64, error) {
	if payloadJSON == "" {
		payloadJSON = "{}"
	}
	// 1) Список заинтересованных берём ОТДЕЛЬНЫМ SELECT из document_access
	//    (на этой таблице нет RLS). Это принципиально: нельзя получить их через
	//    INSERT ... RETURNING, потому что под FORCE RLS RETURNING применяет к
	//    возвращаемым строкам SELECT-политику notifications (видно только свои),
	//    а мы создаём уведомления ДЛЯ ДРУГИХ пользователей — RETURNING падал бы
	//    с "new row violates row-level security policy for table notifications".
	rows, err := tx.Query(ctx, `
		SELECT DISTINCT user_id FROM document_access
		WHERE document_id = $1 AND user_id <> $2`, documentID, actorID)
	if err != nil {
		return nil, fmt.Errorf("collect notify recipients: %w", err)
	}
	var recipients []int64
	for rows.Next() {
		var uid int64
		if err := rows.Scan(&uid); err != nil {
			rows.Close()
			return nil, err
		}
		recipients = append(recipients, uid)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(recipients) == 0 {
		return nil, nil
	}

	// 2) Вставляем уведомления БЕЗ RETURNING (SELECT-политика не применяется).
	//    unnest($1::bigint[]) разворачивает список получателей.
	if _, err := tx.Exec(ctx, `
		INSERT INTO notifications (user_id, document_id, kind, payload)
		SELECT uid, $2::bigint, $3::text, $4::jsonb
		FROM unnest($1::bigint[]) AS uid`,
		recipients, documentID, kind, payloadJSON); err != nil {
		return nil, fmt.Errorf("notify document event: %w", err)
	}
	return recipients, nil
}
