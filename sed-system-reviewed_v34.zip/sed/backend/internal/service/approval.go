package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var ErrStageNotPending = errors.New("stage is not in pending status")
var ErrForbiddenApprover = errors.New("user is not the approver for this stage")

type ApprovalService struct {
	access *AccessService
}

func NewApprovalService(access *AccessService) *ApprovalService {
	return &ApprovalService{access: access}
}

// StageInput описывает этап при создании маршрута; DependsOnIdx — индексы
// (в пределах этого же запроса на создание) этапов, от которых зависит
// активация данного этапа. Это и даёт "гибкую очерёдность": можно
// выразить последовательные, параллельные и смешанные маршруты одной моделью.
type StageInput struct {
	StageType    string
	ApproverID   int64
	DisplayOrder int
	DependsOnIdx []int
}

// CreateRoute создаёт этапы согласования и их зависимости одной транзакцией,
// затем активирует (переводит в pending) все этапы без зависимостей.
// AddApproverAfter вставляет ДОПОЛНИТЕЛЬНОГО согласующего в цепочку сразу
// ПОСЛЕ уже пройденного этапа afterStageID (реализует «донаправление»:
// согласующий одобряет и направляет на доп. согласование новому пользователю).
// В DAG: новый этап зависит от afterStageID (только что approved → активен);
// все этапы, что зависели от afterStageID (следующий согласующий/подпись),
// теперь зависят и от нового — то есть новый согласующий встаёт в очередь
// ПЕРЕД ними. Возвращает id нового этапа.
func (s *ApprovalService) AddApproverAfter(ctx context.Context, tx pgx.Tx, documentID, afterStageID, newApproverID int64, stageType string) (int64, error) {
	if stageType != "hierarchy" && stageType != "cross_dept" {
		stageType = "hierarchy"
	}
	var baseOrder int
	if err := tx.QueryRow(ctx, `SELECT display_order FROM approval_stages WHERE id=$1`, afterStageID).Scan(&baseOrder); err != nil {
		return 0, fmt.Errorf("lookup base stage: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET display_order = display_order + 1
		WHERE document_id=$1 AND display_order > $2`, documentID, baseOrder); err != nil {
		return 0, fmt.Errorf("shift orders: %w", err)
	}
	var newID int64
	if err := tx.QueryRow(ctx, `
		INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, status)
		VALUES ($1, $2::stage_type, $3, $4, 'waiting_deps')
		RETURNING id`, documentID, stageType, newApproverID, baseOrder+1).Scan(&newID); err != nil {
		return 0, fmt.Errorf("insert added stage: %w", err)
	}
	// Этапы, ранее зависевшие от afterStageID, перецепляем на новый этап...
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stage_dependencies SET depends_on_stage_id = $1
		WHERE depends_on_stage_id = $2 AND stage_id <> $1`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("repoint deps: %w", err)
	}
	// ...а новый этап зависит от afterStageID.
	if _, err := tx.Exec(ctx, `
		INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
		VALUES ($1, $2) ON CONFLICT DO NOTHING`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("insert new dep: %w", err)
	}
	if _, err := s.activateStage(ctx, tx, documentID, newID); err != nil {
		return 0, err
	}
	return newID, nil
}

// ApproveAndAddApprover — «согласовать и направить на доп. согласование».
// Согласующий stageID одобряет свой этап И вставляет нового согласующего
// newApproverID сразу после себя (см. AddApproverAfter). В историю пишется
// факт донаправления. Возвращает id нового согласующего (для уведомления).
func (s *ApprovalService) ApproveAndAddApprover(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID, newApproverID int64, stageType, comment string) (int64, error) {
	var approverID int64
	var status string
	if err := tx.QueryRow(ctx, `SELECT approver_id, status FROM approval_stages WHERE id=$1 AND document_id=$2`,
		stageID, documentID).Scan(&approverID, &status); err != nil {
		return 0, fmt.Errorf("lookup stage: %w", err)
	}
	if approverID != actingUserID {
		return 0, ErrForbiddenApprover
	}
	if status != "pending" {
		return 0, ErrStageNotPending
	}
	if newApproverID == actingUserID {
		return 0, ErrSelfApproval
	}
	// Одобряем текущий этап (без авто-активации нижестоящих — их «перехватит»
	// новый этап внутри AddApproverAfter).
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET status='approved', decided_at=now(), comment=$2 WHERE id=$1`,
		stageID, comment); err != nil {
		return 0, fmt.Errorf("approve stage: %w", err)
	}
	newID, err := s.AddApproverAfter(ctx, tx, documentID, stageID, newApproverID, stageType)
	if err != nil {
		return 0, err
	}
	// История: и факт согласования, и факт донаправления (с ФИО нового).
	var newName string
	_ = tx.QueryRow(ctx, `SELECT full_name FROM users WHERE id=$1`, newApproverID).Scan(&newName)
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'stage_approved', $3),
		       ($1, $2, 'approver_added', $4)`,
		documentID, actingUserID, comment,
		fmt.Sprintf("направлено на дополнительное согласование: %s", newName)); err != nil {
		return 0, fmt.Errorf("insert history: %w", err)
	}
	_ = newID
	return newApproverID, nil
}

// Возвращает ID согласующих, чьи этапы активировались сразу — им нужно
// отправить push-уведомление после коммита (см. Decide).
func (s *ApprovalService) CreateRoute(ctx context.Context, tx pgx.Tx, documentID int64, stages []StageInput) ([]int64, error) {
	ids := make([]int64, len(stages))
	for i, st := range stages {
		var id int64
		err := tx.QueryRow(ctx, `
			INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, status)
			VALUES ($1, $2::stage_type, $3, $4, 'waiting_deps')
			RETURNING id`, documentID, st.StageType, st.ApproverID, st.DisplayOrder).Scan(&id)
		if err != nil {
			return nil, fmt.Errorf("insert stage %d: %w", i, err)
		}
		ids[i] = id
	}

	for i, st := range stages {
		for _, depIdx := range st.DependsOnIdx {
			_, err := tx.Exec(ctx, `
				INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
				VALUES ($1, $2)`, ids[i], ids[depIdx])
			if err != nil {
				return nil, fmt.Errorf("insert dependency for stage %d: %w", i, err)
			}
		}
	}

	var notified []int64
	for i, st := range stages {
		if len(st.DependsOnIdx) == 0 {
			approver, err := s.activateStage(ctx, tx, documentID, ids[i])
			if err != nil {
				return nil, err
			}
			notified = append(notified, approver)
		}
	}
	return notified, nil
}

func (s *ApprovalService) activateStage(ctx context.Context, tx pgx.Tx, documentID, stageID int64) (int64, error) {
	var approverID int64
	err := tx.QueryRow(ctx, `
		UPDATE approval_stages SET status = 'pending'
		WHERE id = $1
		RETURNING approver_id`, stageID).Scan(&approverID)
	if err != nil {
		return 0, fmt.Errorf("activate stage %d: %w", stageID, err)
	}
	if err := s.access.GrantStageApproverAccess(ctx, tx, documentID, approverID); err != nil {
		return 0, err
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO notifications (user_id, document_id, kind, payload)
		VALUES ($1, $2, 'stage_pending', '{}')`, approverID, documentID)
	if err != nil {
		return 0, err
	}
	return approverID, nil
}

// Decide фиксирует решение согласующего (approve/reject) и, при
// подтверждении, активирует все этапы, для которых этот этап был
// последней недостающей зависимостью (топологическое "продвижение" DAG).
// Возвращает stage_type решённого этапа и ID пользователей, чьи этапы
// только что активировались — вызывающий код (handler) рассылает им
// push-уведомление через WebSocket ПОСЛЕ коммита транзакции (Hub не
// участвует в транзакции БД намеренно, чтобы не держать соединение
// открытым на время сетевой отправки).
func (s *ApprovalService) Decide(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID int64, approve bool, comment string) (string, []int64, error) {
	var approverID int64
	var status, stageType string
	err := tx.QueryRow(ctx, `SELECT approver_id, status, stage_type FROM approval_stages WHERE id = $1 AND document_id = $2`,
		stageID, documentID).Scan(&approverID, &status, &stageType)
	if err != nil {
		return "", nil, fmt.Errorf("lookup stage: %w", err)
	}
	if approverID != actingUserID {
		return "", nil, ErrForbiddenApprover
	}
	if status != "pending" {
		return "", nil, ErrStageNotPending
	}

	newStatus := "approved"
	if !approve {
		newStatus = "rejected"
	}
	_, err = tx.Exec(ctx, `
		UPDATE approval_stages SET status = $1, decided_at = now(), comment = $2 WHERE id = $3`,
		newStatus, comment, stageID)
	if err != nil {
		return "", nil, fmt.Errorf("update stage: %w", err)
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, $3, $4)`, documentID, actingUserID,
		map[bool]string{true: "stage_approved", false: "stage_rejected"}[approve], comment)
	if err != nil {
		return "", nil, fmt.Errorf("insert history: %w", err)
	}

	if !approve {
		return stageType, nil, nil
	}

	// Находим все этапы, зависящие от этого, у которых ВСЕ зависимости approved.
	rows, err := tx.Query(ctx, `
		SELECT s.id
		FROM approval_stage_dependencies d
		JOIN approval_stages s ON s.id = d.stage_id
		WHERE d.depends_on_stage_id = $1
		  AND s.status = 'waiting_deps'
		  AND NOT EXISTS (
		      SELECT 1 FROM approval_stage_dependencies d2
		      JOIN approval_stages s2 ON s2.id = d2.depends_on_stage_id
		      WHERE d2.stage_id = s.id AND s2.status <> 'approved'
		  )`, stageID)
	if err != nil {
		return "", nil, fmt.Errorf("find ready stages: %w", err)
	}
	var readyIDs []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return "", nil, err
		}
		readyIDs = append(readyIDs, id)
	}
	rows.Close()

	var notified []int64
	for _, id := range readyIDs {
		approver, err := s.activateStage(ctx, tx, documentID, id)
		if err != nil {
			return "", nil, err
		}
		notified = append(notified, approver)
	}
	return stageType, notified, nil
}

// AllApproved проверяет, что все этапы документа в статусе approved
// (используется перед переводом документа on_signing -> signed и т.д.)
func (s *ApprovalService) AllApproved(ctx context.Context, tx pgx.Tx, documentID int64) (bool, error) {
	var pendingCount int
	err := tx.QueryRow(ctx, `
		SELECT count(*) FROM approval_stages
		WHERE document_id = $1 AND status <> 'approved'`, documentID).Scan(&pendingCount)
	if err != nil {
		return false, err
	}
	return pendingCount == 0, nil
}
