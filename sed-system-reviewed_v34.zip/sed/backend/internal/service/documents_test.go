package service

import "testing"

func TestIsPDF(t *testing.T) {
	cases := []struct {
		name    string
		content []byte
		want    bool
	}{
		{"valid pdf header", []byte("%PDF-1.7\n...rest of file..."), true},
		{"valid pdf header minimal version", []byte("%PDF-1.4"), true},
		{"empty content", []byte{}, false},
		{"plain text disguised as pdf by extension only", []byte("this is not a pdf"), false},
		{"png magic bytes", []byte{0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A}, false},
		{"pdf signature not at start", []byte("garbage%PDF-1.7"), false},
		{"html masquerading as pdf (common upload trick)", []byte("<html><body>fake</body></html>"), false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := isPDF(tc.content)
			if got != tc.want {
				t.Errorf("isPDF(%q) = %v, want %v", tc.content, got, tc.want)
			}
		})
	}
}

func TestCreateDocumentInput_RejectsNonPDF(t *testing.T) {
	// Regression guard: DocumentsService.Create должен отклонять контент без
	// корректного PDF-заголовка ДО любых INSERT в БД (isPDF — самая первая
	// проверка в Create). Здесь фиксируем именно этот контракт через прямой
	// вызов isPDF на тех же данных, что передавались бы в CreateDocumentInput.
	in := CreateDocumentInput{FileContent: []byte("not a real pdf")}
	if isPDF(in.FileContent) {
		t.Fatal("ожидали, что не-PDF содержимое будет отклонено isPDF")
	}
}
