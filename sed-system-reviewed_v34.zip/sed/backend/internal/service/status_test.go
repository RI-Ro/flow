package service

import "testing"

func TestDeriveStatus(t *testing.T) {
	cases := []struct {
		name   string
		counts StageCounts
		want   string
	}{
		{
			name:   "no stages at all -> все approved (пусто) -> терминально",
			counts: StageCounts{"hierarchy": {}, "cross_dept": {}, "signing": {}},
			want:   "",
		},
		{
			name: "один этап hierarchy pending",
			counts: StageCounts{
				"hierarchy": {"pending": 1}, "cross_dept": {}, "signing": {},
			},
			want: "on_approval_hierarchy",
		},
		{
			name: "hierarchy approved, cross_dept pending",
			counts: StageCounts{
				"hierarchy": {"approved": 1}, "cross_dept": {"pending": 1}, "signing": {},
			},
			want: "on_approval_cross_dept",
		},
		{
			name: "hierarchy и cross_dept approved, signing waiting_deps",
			counts: StageCounts{
				"hierarchy": {"approved": 2}, "cross_dept": {"approved": 1}, "signing": {"waiting_deps": 1},
			},
			want: "on_signing",
		},
		{
			name: "всё approved -> терминально (подписание вне зоны ответственности этой функции)",
			counts: StageCounts{
				"hierarchy": {"approved": 1}, "cross_dept": {"approved": 1}, "signing": {"approved": 1},
			},
			want: "",
		},
		{
			name: "rejected в hierarchy побеждает всё остальное",
			counts: StageCounts{
				"hierarchy": {"approved": 1, "rejected": 1}, "cross_dept": {}, "signing": {},
			},
			want: "rejected",
		},
		{
			name: "rejected в cross_dept, hierarchy уже approved",
			counts: StageCounts{
				"hierarchy": {"approved": 1}, "cross_dept": {"rejected": 1}, "signing": {},
			},
			want: "rejected",
		},
		{
			name: "rejected в signing — самый поздний этап",
			counts: StageCounts{
				"hierarchy": {"approved": 1}, "cross_dept": {"approved": 1}, "signing": {"rejected": 1},
			},
			want: "rejected",
		},
		{
			name: "параллельные согласующие одного типа: один approved, один pending",
			counts: StageCounts{
				"hierarchy": {"approved": 1, "pending": 1}, "cross_dept": {}, "signing": {},
			},
			want: "on_approval_hierarchy",
		},
		{
			name: "документ без cross_dept вообще — сразу к signing после hierarchy",
			counts: StageCounts{
				"hierarchy": {"approved": 1}, "signing": {"pending": 1},
			},
			want: "on_signing",
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := DeriveStatus(tc.counts)
			if got != tc.want {
				t.Errorf("DeriveStatus(%+v) = %q, want %q", tc.counts, got, tc.want)
			}
		})
	}
}
