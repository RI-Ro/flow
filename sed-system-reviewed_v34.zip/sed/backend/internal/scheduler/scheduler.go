// Package scheduler запускает периодические фоновые задачи (авто-архив).
// Используется простой ticker вместо внешней cron-библиотеки: задача одна и
// выполняется раз в сутки, полноценный cron-парсер здесь избыточен.
package scheduler

import (
	"context"
	"log"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/service"
)

type Scheduler struct {
	pool *pgxpool.Pool
	exec *service.ExecutionService
}

func New(pool *pgxpool.Pool, exec *service.ExecutionService) *Scheduler {
	return &Scheduler{pool: pool, exec: exec}
}

// StartAutoArchive запускает суточный цикл авто-архива в фоне. Возвращается
// сразу; цикл живёт до отмены ctx. Первый прогон — через minuteAfterStart,
// чтобы не нагружать старт приложения, далее — раз в 24 часа. Задача
// идемпотентна, поэтому точное время не критично (при нескольких инстансах
// API её должен запускать только ОДИН — см. примечание ниже).
//
// ВАЖНО при горизонтальном масштабировании: если инстансов API несколько,
// планировщик должен работать лишь на одном, иначе архивацию выполнят все
// разом. Варианты: (1) отдельный воркер-процесс; (2) advisory-lock в БД
// (pg_try_advisory_lock) — задача выполняется только тем, кто взял лок.
// Здесь используем advisory-lock как самый простой безопасный способ.
func (s *Scheduler) StartAutoArchive(ctx context.Context) {
	go func() {
		// Небольшая задержка перед первым прогоном.
		select {
		case <-ctx.Done():
			return
		case <-time.After(1 * time.Minute):
		}
		s.runArchiveOnce(ctx)

		ticker := time.NewTicker(24 * time.Hour)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				s.runArchiveOnce(ctx)
			}
		}
	}()
}

const archiveAdvisoryLockKey = 4823710 // произвольный уникальный ключ для pg_advisory_lock

func (s *Scheduler) runArchiveOnce(ctx context.Context) {
	// Берём advisory-lock: если другой инстанс уже выполняет архивацию —
	// пропускаем (lock не взят). Так задача выполняется ровно одним инстансом.
	err := db.WithAdminTx(ctx, s.pool, func(tx pgx.Tx) error {
		var got bool
		if err := tx.QueryRow(ctx, `SELECT pg_try_advisory_xact_lock($1)`, archiveAdvisoryLockKey).Scan(&got); err != nil {
			return err
		}
		if !got {
			return nil // другой инстанс уже занимается — не дублируем
		}
		n, err := s.exec.ArchiveExecutedFromPreviousYears(ctx, tx)
		if err != nil {
			return err
		}
		if n > 0 {
			log.Printf("auto-archive: перемещено в архив документов: %d", n)
		}
		return nil
	})
	if err != nil {
		log.Printf("auto-archive failed: %v", err)
	}
}
