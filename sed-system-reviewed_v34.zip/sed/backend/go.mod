module sed-system/backend

go 1.22

require (
	github.com/gofiber/fiber/v2 v2.52.5
	github.com/gofiber/contrib/websocket v1.3.2
	github.com/jackc/pgx/v5 v5.6.0
	github.com/golang-jwt/jwt/v5 v5.2.1
	golang.org/x/crypto v0.24.0
	github.com/google/uuid v1.6.0
	github.com/pressly/goose/v3 v3.20.0
	gopkg.in/yaml.v3 v3.0.1
	github.com/xuri/excelize/v2 v2.8.1
	github.com/redis/go-redis/v9 v9.6.1
	github.com/pdfcpu/pdfcpu v0.8.1
)
