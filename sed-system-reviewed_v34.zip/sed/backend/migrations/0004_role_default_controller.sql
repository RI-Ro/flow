-- +goose NO TRANSACTION
-- +goose Up
-- Новая роль «контролёр по умолчанию» (default_controller). Отдельная миграция
-- без транзакции: PostgreSQL не позволяет ADD VALUE к enum и его использование
-- в одной транзакции, а goose по умолчанию оборачивает миграцию в транзакцию.
-- IF NOT EXISTS делает шаг идемпотентным.
ALTER TYPE role_code ADD VALUE IF NOT EXISTS 'default_controller';

-- +goose Down
-- Значение enum удалить нельзя (PostgreSQL не поддерживает DROP VALUE).
-- Down намеренно пустой — роль остаётся, но перестаёт использоваться.
SELECT 1;
