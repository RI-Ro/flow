-- +goose Up
-- ============================================================================
-- RLS-политики — сразу в финальном (каноническом) виде. FORCE RLS включён для
-- трёх таблиц: documents, chat_messages, notifications. Никаких последующих
-- «чинящих» миграций: политики определены здесь один раз и правильно.
--
-- Ключевые моменты, из-за которых раньше были повторяющиеся ошибки:
--   * Для FORCE RLS + INSERT нужен WITH CHECK (иначе "new row violates RLS").
--   * notifications INSERT: уведомление создаёт СЕРВЕРНЫЙ код ДЛЯ ДРУГОГО
--     пользователя (автор→согласующему, подписант→всем заинтересованным).
--     Публичного эндпоинта создания уведомлений нет. Поэтому INSERT
--     БЕЗУСЛОВНО разрешён (WITH CHECK true) — это надёжно исключает ошибку
--     "new row violates row-level security policy for table notifications"
--     независимо от того, как выставлена сессионная переменная в конкретном
--     пути. Чтение по-прежнему строго ограничено своими (notifications_select).
--   * DELETE на chat_messages/notifications разрешён (USING true) для каскада
--     ON DELETE при удалении документа (прямых hard-delete эндпоинтов нет).
-- ============================================================================

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents FORCE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages FORCE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications FORCE ROW LEVEL SECURITY;

-- --------------------------------------------------------------- documents ---
CREATE POLICY documents_select ON documents FOR SELECT USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR (documents.outgoing_number IS NOT NULL AND documents.author_department_id IN (
        SELECT uvd.department_id FROM user_visible_departments uvd
        WHERE uvd.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint))
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_insert ON documents FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_update ON documents FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = documents.id
             AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY documents_delete ON documents FOR DELETE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

-- ------------------------------------------------------------ chat_messages ---
CREATE POLICY chat_select ON chat_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
          AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint)
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY chat_insert ON chat_messages FOR INSERT WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  AND EXISTS (SELECT 1 FROM document_access da WHERE da.document_id = chat_messages.document_id
              AND da.user_id = NULLIF(current_setting('app.user_id', true), '')::bigint));

CREATE POLICY chat_update ON chat_messages FOR UPDATE USING (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  author_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY chat_delete ON chat_messages FOR DELETE USING (true);

-- ------------------------------------------------------------ notifications ---
CREATE POLICY notifications_select ON notifications FOR SELECT USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

-- INSERT безусловно разрешён (см. заголовок файла).
CREATE POLICY notifications_insert ON notifications FOR INSERT WITH CHECK (true);

CREATE POLICY notifications_update ON notifications FOR UPDATE USING (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE)
  WITH CHECK (
  user_id = NULLIF(current_setting('app.user_id', true), '')::bigint
  OR NULLIF(current_setting('app.is_admin', true), '')::bool IS TRUE);

CREATE POLICY notifications_delete ON notifications FOR DELETE USING (true);

-- +goose Down
DROP POLICY IF EXISTS documents_select ON documents;
DROP POLICY IF EXISTS documents_insert ON documents;
DROP POLICY IF EXISTS documents_update ON documents;
DROP POLICY IF EXISTS documents_delete ON documents;
DROP POLICY IF EXISTS chat_select ON chat_messages;
DROP POLICY IF EXISTS chat_insert ON chat_messages;
DROP POLICY IF EXISTS chat_update ON chat_messages;
DROP POLICY IF EXISTS chat_delete ON chat_messages;
DROP POLICY IF EXISTS notifications_select ON notifications;
DROP POLICY IF EXISTS notifications_insert ON notifications;
DROP POLICY IF EXISTS notifications_update ON notifications;
DROP POLICY IF EXISTS notifications_delete ON notifications;
ALTER TABLE notifications NO FORCE ROW LEVEL SECURITY;
ALTER TABLE notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages NO FORCE ROW LEVEL SECURITY;
ALTER TABLE chat_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE documents NO FORCE ROW LEVEL SECURITY;
ALTER TABLE documents DISABLE ROW LEVEL SECURITY;
