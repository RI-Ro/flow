-- +goose Up
-- ============================================================================
-- Ревью v34.
--   #4 несколько контролёров у документа (document_controllers).
--   #5 расширение видимости ВХОДЯЩИХ документов по подразделениям
--      (user_incoming_departments) — аналогично user_visible_departments для
--      исходящих. Клауза в RLS-политике documents_select добавляется в
--      ensure_policies.go (применяется на старте) и в all_in_one.sql.
-- documents.controller_id сохраняется как «основной» контролёр (для дашборда/
-- реестра и обратной совместимости) — им становится первый из выбранных.
-- ============================================================================

CREATE TABLE IF NOT EXISTS document_controllers (
    document_id BIGINT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (document_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_document_controllers_user ON document_controllers(user_id);

CREATE TABLE IF NOT EXISTS user_incoming_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX IF NOT EXISTS idx_user_incoming_dept ON user_incoming_departments(department_id);

-- +goose Down
DROP TABLE IF EXISTS user_incoming_departments;
DROP TABLE IF EXISTS document_controllers;
