-- +goose Up
-- ============================================================================
-- Ревью v33. Изменения по замечаниям:
--   #5  город подразделения (departments.city)
--   #4  группы адресатов рассылки (recipient_groups + members)
-- Остальные пункты ревью — только код (без изменения схемы) либо покрыты
-- уже существующими таблицами (document_copies для #9, document_signatures для
-- множественной подписи #3, document_acquaintances для #11).
-- ============================================================================

-- #5 — Город подразделения. Выводится в списках согласования/подписи/рассылки
-- рядом с ФИО и должностью (см. #6).
ALTER TABLE departments ADD COLUMN IF NOT EXISTS city TEXT;

-- #4 — Группы адресатов рассылки («дежурные», «группа технической поддержки»…).
-- Управляются из админки. Участник группы несёт department_id: получателем
-- рассылки можно стать только с ролью clerk в конкретном подразделении
-- (DB-триггер check_recipient_role), поэтому в группе храним именно ту пару
-- (пользователь, подразделение), что пройдёт триггер при добавлении в рассылку.
CREATE TABLE IF NOT EXISTS recipient_groups (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    is_active BOOL NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recipient_group_members (
    group_id BIGINT NOT NULL REFERENCES recipient_groups(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (group_id, user_id, department_id)
);
CREATE INDEX IF NOT EXISTS idx_recipient_group_members_group ON recipient_group_members(group_id);

-- +goose Down
DROP TABLE IF EXISTS recipient_group_members;
DROP TABLE IF EXISTS recipient_groups;
ALTER TABLE departments DROP COLUMN IF EXISTS city;
