-- +goose Up
-- Демо-данные для локального запуска/разработки. Пароль всех демо-пользователей:
-- "password123" (bcrypt). В production сиды заменяются реальной оргструктурой
-- через консоль администрирования.

INSERT INTO departments (id, parent_id, name, outgoing_prefix, numbering_prefix) VALUES
  (1, NULL, 'Главное управление', 'ГУ',   '1'),
  (2, 1,    'Департамент цифровизации', 'ЭД', '1/2'),
  (3, 1,    'Департамент финансов', 'ФИН',  '1/3'),
  (4, 2,    'Отдел разработки', 'РАЗР',     '1/2/4');
SELECT setval('departments_id_seq', 4, true);

INSERT INTO department_closure (ancestor_id, descendant_id, depth) VALUES
  (1,1,0), (2,2,0), (3,3,0), (4,4,0),
  (1,2,1), (1,3,1), (1,4,2),
  (2,4,1);

INSERT INTO users (id, login, password_hash, full_name, position, primary_department_id, numbering_department_id) VALUES
  (1, 'author1',   '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Иванов И.И. (автор)',            'Специалист отдела разработки',              4, 4),
  (2, 'chief1',     '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Петров П.П. (нач. отдела)',      'Начальник отдела разработки',               4, 4),
  (3, 'crossdept1', '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Сидоров С.С. (согласование ФИН)','Главный специалист департамента финансов',  3, 3),
  (4, 'signer1',    '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Смирнов А.А. (подписант)',       'Заместитель руководителя',                  1, 1),
  (5, 'duty1',      '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Кузнецов К.К. (дежурный)',       'Дежурный по департаменту',                  2, 2),
  (6, 'clerk1',     '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6', 'Морозова М.М. (канцелярия)',     'Делопроизводитель канцелярии',              1, 1);
SELECT setval('users_id_seq', 6, true);

INSERT INTO user_roles (user_id, department_id, role) VALUES
  (1, 4, 'author'),
  (2, 4, 'approver_hierarchy'),
  (2, 4, 'chief'),
  (3, 3, 'approver_cross_dept'),
  (4, 1, 'signer'),
  (5, 2, 'clerk'),
  (6, 1, 'clerk');

-- +goose Down
DELETE FROM user_roles;
DELETE FROM users;
DELETE FROM department_closure;
DELETE FROM departments;
