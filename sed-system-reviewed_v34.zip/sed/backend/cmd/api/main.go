package main

import (
	"context"
	"flag"
	"log"

	"sed-system/backend/internal/config"
	"sed-system/backend/internal/db"
	apphttp "sed-system/backend/internal/http"
	"sed-system/backend/internal/scheduler"
	"sed-system/backend/internal/service"
)

func main() {
	// --config путь к YAML-конфигу. Приоритет: флаг > env CONFIG_FILE > ./config.yaml.
	configPath := flag.String("config", "", "путь к файлу конфигурации (YAML)")
	flag.Parse()

	cfg, fileCfg := config.LoadWithFilePath(*configPath)

	ctx := context.Background()

	// Миграции применяем сами, из бэкенда, до открытия пула для работы —
	// одна версия goose (из go.mod), понятные ошибки в общем логе.
	if err := db.Migrate(cfg.DatabaseURL, cfg.MigrationsDir); err != nil {
		log.Fatalf("migrate: %v", err)
	}

	pool, err := db.New(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("db connect: %v", err)
	}
	defer pool.Close()

	// Страховка: приводим RLS-политики к каноническому виду на старте (на
	// случай переиспользуемой БД, где goose уже пометил версии применёнными и
	// не накатит исправленную политику). НЕ фатально.
	db.EnsureCanonicalPolicies(ctx, pool)

	app := apphttp.NewRouter(cfg, fileCfg, pool)

	// Фоновый авто-архив исполненных документов прошлых лет (если включено).
	if fileCfg.Lifecycle.AutoArchiveExecutedNextYear {
		execSvc := service.NewExecutionService()
		sched := scheduler.New(pool, execSvc)
		sched.StartAutoArchive(ctx)
		log.Printf("auto-archive scheduler started")
	}

	log.Printf("sed-backend listening on %s", cfg.HTTPAddr)
	if err := app.Listen(cfg.HTTPAddr); err != nil {
		log.Fatalf("server error: %v", err)
	}
}
