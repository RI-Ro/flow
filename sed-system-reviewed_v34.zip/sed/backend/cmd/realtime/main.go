// Command realtime — отдельный stateful WS-сервис (чат + уведомления),
// вынесенный из API согласно ARCHITECTURE_v2.md. Держит только WebSocket-
// соединения; вся тяжёлая бизнес-логика — в API-сервисе. Оба сервиса общаются
// через Redis pub/sub (общий Hub с EnableRedis), поэтому событие,
// сгенерированное любым инстансом API, доходит до клиента на этом сервисе.
//
// Зачем отдельно: API можно масштабировать горизонтально и включать prefork
// (stateless), а WS-соединения держит лёгкий realtime, который тоже
// масштабируется, когда транспорт — Redis. См. ARCHITECTURE_v2.md.
package main

import (
	"context"
	"log"

	"github.com/gofiber/contrib/websocket"
	"github.com/gofiber/fiber/v2"

	"sed-system/backend/internal/config"
	"sed-system/backend/internal/db"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

func main() {
	cfg, fileCfg := config.LoadWithFile()

	ctx := context.Background()
	pool, err := db.New(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("db connect: %v", err)
	}
	defer pool.Close()

	// Тот же Hub, что и в API, но здесь он ОБЯЗАН работать через Redis —
	// иначе realtime не увидит события, сгенерированные в API-процессе.
	hub := ws.NewHub(pool)
	channel := fileCfg.Realtime.EventsChannel
	if channel == "" {
		channel = "sed_events"
	}
	if fileCfg.Realtime.RedisAddr == "" {
		log.Println("ВНИМАНИЕ: realtime без Redis (realtime.redis_addr пуст) — события из API-сервиса доходить НЕ будут. Задайте redis_addr.")
	}
	hub.EnableRedis(ctx, fileCfg.Realtime.RedisAddr, channel)

	authSvc := service.NewAuthService(cfg.JWTSecret, cfg.JWTTTL)

	app := fiber.New()
	app.Get("/healthz", func(c *fiber.Ctx) error { return c.SendString("ok") })
	app.Get("/ws/documents/:id/chat", websocket.New(ws.ChatWSHandler(hub, authSvc)))
	app.Get("/ws/notifications", websocket.New(ws.NotificationsWSHandler(hub, authSvc)))

	addr := fileCfg.Realtime.Addr
	if addr == "" {
		addr = ":8081"
	}
	log.Printf("sed-realtime listening on %s", addr)
	if err := app.Listen(addr); err != nil {
		log.Fatalf("realtime server error: %v", err)
	}
}
