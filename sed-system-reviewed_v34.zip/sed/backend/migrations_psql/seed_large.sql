-- ============================================================================
-- seed_large.sql — крупный демонстрационный набор: >=400 подразделений и 1000
-- пользователей с ролями. Запуск (после базовых миграций 0001..0003):
--   psql "$DATABASE_URL" -f migrations_psql/seed_large.sql
-- Параметры можно переопределить:  -v ndept=500 -v nusers=2000
-- Пароль всех пользователей — "password123" (bcrypt-хеш ниже, как в демо).
-- Идемпотентность: повторный прогон чистит ранее созданные этим скриптом
-- записи (login LIKE 'lu%' и подразделения с outgoing_prefix LIKE 'LD%').
-- ============================================================================

-- Количество задаётся КОНСТАНТАМИ в DECLARE ниже (v_ndept/v_nusers): psql-
-- подстановка :var внутри dollar-quoted блока ненадёжна между версиями.

-- Очистка предыдущего большого сида (только его данные). Пользователей —
-- первыми (на них ссылаются подразделения через primary/numbering dept).
DELETE FROM user_roles ur USING users u
  WHERE ur.user_id = u.id AND u.login LIKE 'lu%';
DELETE FROM users WHERE login LIKE 'lu%';
-- Подразделения удаляем ЛИСТЬЯ-ПЕРВЫМИ (по убыванию id: дети создаются после
-- родителей и имеют больший id), иначе parent_id ON DELETE RESTRICT не даст
-- удалить родителя при живом ребёнке. Closure снимается каскадом.
DO $cleanup$
DECLARE r record;
BEGIN
  FOR r IN SELECT id FROM departments WHERE outgoing_prefix LIKE 'LD%' ORDER BY id DESC LOOP
    DELETE FROM departments WHERE id = r.id;
  END LOOP;
END
$cleanup$;

DO $seed$
DECLARE
  v_ndept   int := 420;    -- >= 400 подразделений (правьте здесь)
  v_nusers  int := 1000;   -- 1000 пользователей (правьте здесь)
  v_hash    text := '$2b$12$NrtSBd6wvEBlsTfiqrrG1ORTmN5V4SpNXwlcYLXUAMBhY5WhQGpL6';
  v_dept_id   bigint[];   -- ordinal -> real id
  v_dept_pref text[];     -- ordinal -> numbering_prefix
  i         int;
  p_ord     int;
  new_id    bigint;
  uid       bigint;
  d_ord     int;
  d_id      bigint;
  v_pref    text;
BEGIN
  IF v_ndept  IS NULL OR v_ndept  < 1 THEN v_ndept  := 420;  END IF;
  IF v_nusers IS NULL OR v_nusers < 1 THEN v_nusers := 1000; END IF;

  -- ---- Подразделения: тернарное дерево (каждый узел ~3 ребёнка) -----------
  FOR i IN 1..v_ndept LOOP
    IF i = 1 THEN
      INSERT INTO departments (parent_id, name, outgoing_prefix, numbering_prefix)
      VALUES (NULL, 'Подразделение LD-1', 'LD1', '1')
      RETURNING id INTO new_id;
      v_dept_id[1]   := new_id;
      v_dept_pref[1] := '1';
      INSERT INTO department_closure (ancestor_id, descendant_id, depth)
      VALUES (new_id, new_id, 0);
    ELSE
      p_ord := (i - 2) / 3 + 1;                 -- родитель (ordinal), всегда < i
      v_pref := v_dept_pref[p_ord] || '/' || i::text;
      INSERT INTO departments (parent_id, name, outgoing_prefix, numbering_prefix)
      VALUES (v_dept_id[p_ord], 'Подразделение LD-' || i, 'LD' || i, v_pref)
      RETURNING id INTO new_id;
      v_dept_id[i]   := new_id;
      v_dept_pref[i] := v_pref;
      -- closure: все предки родителя + сам узел
      INSERT INTO department_closure (ancestor_id, descendant_id, depth)
      SELECT dc.ancestor_id, new_id, dc.depth + 1
      FROM department_closure dc WHERE dc.descendant_id = v_dept_id[p_ord]
      UNION ALL SELECT new_id, new_id, 0;
    END IF;
  END LOOP;

  -- ---- Пользователи (распределяем по подразделениям по кругу) -------------
  FOR i IN 1..v_nusers LOOP
    d_ord := ((i - 1) % v_ndept) + 1;
    d_id  := v_dept_id[d_ord];
    INSERT INTO users (login, password_hash, full_name, position,
                       primary_department_id, numbering_department_id)
    VALUES ('lu' || i, v_hash, 'Пользователь № ' || i, 'Сотрудник',
            d_id, d_id)
    RETURNING id INTO uid;

    -- Базовая роль — автор в своём подразделении.
    INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'author');
    -- Разнообразные роли по модулю (детерминированно).
    IF i % 5  = 0 THEN
      INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'approver_hierarchy');
      INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'chief');
    END IF;
    IF i % 7  = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'signer'); END IF;
    IF i % 6  = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'clerk'); END IF;
    IF i % 9  = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'approver_cross_dept'); END IF;
    IF i % 11 = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'controller'); END IF;
    IF i % 13 = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, d_id, 'executor'); END IF;
    -- Немного глобальных администраторов (department_id = NULL).
    IF i % 200 = 0 THEN INSERT INTO user_roles (user_id, department_id, role) VALUES (uid, NULL, 'admin'); END IF;
  END LOOP;

  RAISE NOTICE 'seed_large: создано % подразделений и % пользователей', v_ndept, v_nusers;
END
$seed$;
