-- Самодостаточный сброс демо-пользователей. Применять, если авторизация
-- выдаёт 401 (пользователей нет или хеш повреждён при переносе).
-- Пароль у всех: password123. Хеш генерируется ПРЯМО в Postgres через
-- pgcrypto, поэтому не зависит от того, как строка пережила копирование/оболочку.
--
--   psql -U postgres -d sed -v ON_ERROR_STOP=1 -f reset_demo_users.sql

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Убедимся, что подразделения и дежурные узлы для FK существуют (на случай,
-- если seed вообще не применялся). ON CONFLICT — идемпотентность.
INSERT INTO departments (id, parent_id, name, outgoing_prefix) VALUES
  (1, NULL, 'Главное управление', 'ГУ'),
  (2, 1, 'Департамент цифровизации', 'ЭД'),
  (3, 1, 'Департамент финансов', 'ФИН'),
  (4, 2, 'Отдел разработки', 'РАЗР')
ON CONFLICT (id) DO NOTHING;
SELECT setval('departments_id_seq', GREATEST((SELECT max(id) FROM departments), 1), true);

INSERT INTO department_closure (ancestor_id, descendant_id, depth) VALUES
  (1,1,0),(2,2,0),(3,3,0),(4,4,0),(1,2,1),(1,3,1),(1,4,2),(2,4,1)
ON CONFLICT DO NOTHING;

INSERT INTO duty_hierarchy (id, parent_id, name) VALUES
  (1, NULL, 'Дежурная служба ГУ'),
  (2, 1, 'Дежурная служба департамента ЭД')
ON CONFLICT (id) DO NOTHING;
SELECT setval('duty_hierarchy_id_seq', GREATEST((SELECT max(id) FROM duty_hierarchy), 1), true);
INSERT INTO duty_closure (ancestor_id, descendant_id, depth) VALUES
  (1,1,0),(2,2,0),(1,2,1)
ON CONFLICT DO NOTHING;

-- Пользователи. Хеш = crypt('password123', gen_salt('bf', 12)) — настоящий
-- bcrypt, сгенерированный сервером. ON CONFLICT обновляет хеш и is_active,
-- чтобы починить в т.ч. уже существующих, но «сломанных» пользователей.
INSERT INTO users (id, login, password_hash, full_name, primary_department_id, numbering_department_id, duty_node_id, is_active) VALUES
  (1, 'author1',   crypt('password123', gen_salt('bf', 12)), 'Иванов И.И. (автор)',            4, 4, NULL, true),
  (2, 'chief1',    crypt('password123', gen_salt('bf', 12)), 'Петров П.П. (нач. отдела)',      4, 4, NULL, true),
  (3, 'crossdept1',crypt('password123', gen_salt('bf', 12)), 'Сидоров С.С. (согл. ФИН)',       3, 3, NULL, true),
  (4, 'signer1',   crypt('password123', gen_salt('bf', 12)), 'Смирнов А.А. (подписант)',       1, 1, NULL, true),
  (5, 'duty1',     crypt('password123', gen_salt('bf', 12)), 'Кузнецов К.К. (дежурный)',       2, 2, 2,    true),
  (6, 'clerk1',    crypt('password123', gen_salt('bf', 12)), 'Морозова М.М. (канцелярия)',     1, 1, NULL, true)
ON CONFLICT (id) DO UPDATE
  SET password_hash = EXCLUDED.password_hash,
      is_active = true,
      login = EXCLUDED.login;
SELECT setval('users_id_seq', GREATEST((SELECT max(id) FROM users), 1), true);

INSERT INTO user_roles (user_id, department_id, role) VALUES
  (1, 4, 'author'),
  (2, 4, 'approver_hierarchy'),
  (2, 4, 'chief'),
  (3, 3, 'approver_cross_dept'),
  (4, 1, 'signer'),
  (5, 2, 'clerk'),
  (6, 1, 'clerk')
ON CONFLICT DO NOTHING;

-- Контроль: должно вернуть 6 строк, все is_active=t, hash_len=60.
SELECT login, is_active, length(password_hash) AS hash_len,
       (password_hash = crypt('password123', password_hash)) AS password_ok
FROM users ORDER BY id;
