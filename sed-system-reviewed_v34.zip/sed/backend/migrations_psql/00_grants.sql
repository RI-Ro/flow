-- Права для роли приложения (sed). Выполнять от суперпользователя (postgres)
-- ОДИН раз после создания БД и роли, ДО применения остальных миграций
-- (или после — GRANT на будущие объекты покрывает ALTER DEFAULT PRIVILEGES).
--
--   psql -U postgres -d sed -v ON_ERROR_STOP=1 -f 00_grants.sql
--
-- Роль sed должна существовать: CREATE ROLE sed LOGIN PASSWORD 'sed';

GRANT USAGE, CREATE ON SCHEMA public TO sed;

-- Права на уже существующие объекты.
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO sed;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO sed;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO sed;

-- Права на объекты, которые будут созданы В БУДУЩЕМ (напр. если миграции
-- применяет postgres, а работает sed) — иначе после каждой новой таблицы
-- права пришлось бы выдавать заново.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO sed;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO sed;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO sed;
