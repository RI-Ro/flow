# Изменения (итерация 28)

## 1. «Все документы» — на первом месте и вкладка по умолчанию
В боковом меню категория «Все документы» перемещена наверх; вход и корневой
маршрут ведут на /documents/all. (frontend Layout.jsx, App.jsx, LoginPage.jsx)

## 2. Персональные номера экземпляров (у каждого — свой)
Новая таблица document_copies (id, document_id, user_id, copy_number, reason,
assigned_at; UNIQUE(document_id,user_id), UNIQUE(document_id,copy_number)).
Номер выдаётся ОДИН раз на пользователя при получении доступа, монотонно, в
порядке вовлечения: автор/исполнитель — №1, затем согласующие и подписант,
затем получатели, ознакомленные и т.д. Супервайзерский доступ руководителя
(chief_of_dept) экземпляром НЕ считается.
- Присвоение: AccessService.AssignCopyNumber, вызывается из grant() для всех
  причин, кроме chief_of_dept.
- Показ: в карточке документа — бейдж «Экз. № N» текущего пользователя
  (my_copy_number из GET /documents/:id), плюс вкладка «Экземпляры» со всем
  реестром (GET /documents/:id/copies) — номер, ФИО, причина, время.
Номера видны всем участникам, но каждый видит и свой (в шапке).

## 3. Крупный seed: 420 подразделений и 1000 пользователей
Новый файл backend/migrations_psql/seed_large.sql:
- строит дерево из 420 подразделений (тернарное, корректный department_closure
  и иерархический numbering_prefix);
- создаёт 1000 пользователей (login lu1..lu1000, пароль "password123"),
  распределяет по подразделениям, назначает роли (author всем; по модулю —
  approver_hierarchy+chief, signer, clerk, approver_cross_dept, controller,
  executor; несколько глобальных admin);
- идемпотентен: повторный прогон чистит свои данные (login lu%, outgoing_prefix
  LD%), причём подразделения удаляются листьями-первыми (ON DELETE RESTRICT на
  parent_id).
Запуск после базовых миграций: psql "$DATABASE_URL" -f migrations_psql/seed_large.sql
Объём меняется правкой констант v_ndept/v_nusers в DECLARE (psql :var внутри
dollar-quote ненадёжен, поэтому константы).

Схема изменилась (document_copies) — развёртывание с нуля. all_in_one.sql
перегенерирован. Проверка: Go/БД/фронт не собираются в среде; баланс скобок
Go/JS/SQL, dollar-quote и YAML — ок. Перед деплоем: go build ./... && go test ./...
и npm run build.
