# Изменения (итерация 32)

## bake_into_pdf — полноценная секция настроек (а не булево)
Причина, почему не запускалось/не работало: секция marking.bake_into_pdf уже
была преобразована в структуру BakeConfig (с параметрами), но router.go всё ещё
ссылался на СТАРОЕ булево поле fileCfg.Marking.BakeIntoPDF — это ошибка
компиляции (undefined). Исправлено: router использует fileCfg.Marking.Bake.Enabled.

Теперь bake_into_pdf — секция с параметрами, как у остальных штампов:
  bake_into_pdf:
    enabled: false            # вжигать ли штампы в сам PDF
    font_file: ""             # шрифт для вжигания (пусто = marking.font_file)
    font_name: ""             # имя шрифта (пусто = marking.font_name)
    default_color: "#000000"  # цвет текста по умолчанию для штампов
    default_font_size: 9      # размер шрифта по умолчанию
    default_position: "top_right"  # позиция по умолчанию
    margin: 24                # отступ штампов от края (pt)
    opacity: 1.0              # прозрачность 0..1

Эти значения применяются как ДЕФОЛТЫ к каждому штампу, если у него самого
параметр не задан (buildSpec: font_size/color/position/opacity/margin). У каждого
конкретного штампа (signature/instance/incoming/archive/registration) параметры
задаются индивидуально, как и раньше.

Тумблер также доступен через env MARKING_BAKE=true|1|on.

Проверка: баланс скобок Go/YAML — ок; в коде не осталось ссылок на старое поле
BakeIntoPDF; сигнатуры Apply/IsBaking/buildSpec/ComputeSpecs согласованы, Configure
вызывается из router при Bake.Enabled. Перед деплоем: go build ./... && go test ./...
