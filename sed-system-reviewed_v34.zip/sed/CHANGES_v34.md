# CHANGES_v34 — вторая итерация правок по замечаниям

> ⚠️ Проверено статически (в среде нет Go-тулчейна и сети). Перед деплоем:
> `go build ./... && go test ./...`, `npm ci && npm run build`.
> Миграции применяются автоматически (goose) при старте; порядок 0006 после 0001–0005.

## Миграция БД
`backend/migrations/0006_review_v34.sql` (+ идемпотентно в `migrations_psql/all_in_one.sql`):
- `document_controllers(document_id, user_id, assigned_at)` — несколько контролёров у документа (#4).
- `user_incoming_departments(user_id, department_id)` — расширение видимости входящих (#5).

## 1. Групповая рассылка на формах создания и изменения
Раньше выбор групп был только в детальном просмотре. Теперь:
- Новый переиспользуемый компонент `frontend/src/components/RecipientGroupPicker.jsx`
  (выбор группы, показ количества и состава, «Добавить всех»).
- Подключён на форме **создания** (`CreateDocumentPage.jsx`) и **редактирования**
  (`EditDocumentModal.jsx`) рядом с ручным выбором получателей + кнопка «Очистить всех».
- Панель направления в детальном просмотре (`SendPanel.jsx`) — как и раньше.

## 2. Время готовности — полностью необязательно, без подстановки 23:59
- Форма создания и редактирования: если время не задано, `due_datetime` НЕ отправляется
  (шлём только `due_date`). Значение 23:59 больше не подставляется.
- В списках/журнале/карточке при отсутствии времени выводится только дата
  (логика `due_datetime ? fmtDateTime : fmtDate` уже это обеспечивает).
- В форме редактирования старые документы со значением ровно 23:59 показывают пустое
  поле времени (чтобы при пересохранении время убиралось) — обратная совместимость.

## 3. Контролёр по умолчанию — только с санкции автора (без авто-контроля)
- Убрана серверная автопостановка на контроль (`applyDefaultControl` удалён из `service/documents.go`).
- Новый эндпоинт `GET /api/default-controllers` — активные пользователи с ролью `default_controller`.
- Форма создания: при загрузке подтягивает контролёров по умолчанию, **предвыбирает** их и
  ставит галочку «на контроле». Автор может снять галочку или изменить набор — постановка
  выполняется явным вызовом `setControl` после создания.

## 4. Несколько контролёров
- `SetControl` принимает `controller_ids: []` (обратная совместимость с `controller_id`),
  сохраняет всех в `document_controllers`; `documents.controller_id` = первый (для дашборда/реестра).
- Допуск роли расширен: `controller` **и** `default_controller`; группа кандидатов «controller» — тоже.
- `MyRoles` (`is_controller`) и дашборд «на контроле у меня» учитывают `document_controllers`.
- Новый эндпоинт `GET /api/documents/:id/controllers`.
- Фронт: мультивыбор контролёров на формах создания, редактирования и во вкладке «Контроль»;
  во вкладке показывается список контролёров. `api.setControl` принимает массив id.

## 5. Видимость входящих документов (аналогично исходящим)
- RLS-политика `documents_select` (в `internal/db/ensure_policies.go` и `all_in_one.sql`) дополнена:
  пользователь видит документ, если у документа есть входящий экземпляр
  (`document_incoming_instances`) в одном из его подразделений «видимости входящих».
- Бэкенд: `user_incoming_departments` добавлена в whitelist наборов, в `ListUsers`
  (поле `incoming_departments`) и в `SetUserDepartments`.
- Админка (`AdminPage.jsx`): новое поле «Видимость входящих» рядом с «Видимость исходящих».

## Список изменённых/новых файлов
- backend/migrations/0006_review_v34.sql (new)
- backend/migrations_psql/all_in_one.sql
- backend/internal/db/ensure_policies.go
- backend/internal/service/documents.go
- backend/internal/service/admin.go
- backend/internal/http/handlers/documents.go
- backend/internal/http/handlers/admin.go
- backend/internal/http/handlers/dashboard.go
- backend/internal/http/handlers/users.go
- backend/internal/http/router.go
- frontend/src/components/RecipientGroupPicker.jsx (new)
- frontend/src/components/EditDocumentModal.jsx
- frontend/src/components/DocumentTabs.jsx
- frontend/src/components/SendPanel.jsx
- frontend/src/pages/CreateDocumentPage.jsx
- frontend/src/pages/AdminPage.jsx
- frontend/src/api/client.js
