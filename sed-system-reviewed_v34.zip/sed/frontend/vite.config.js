import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Dev-прокси: все /api и /ws идут на бэкенд через тот же origin (localhost:5173),
// поэтому браузер вообще не делает cross-origin запросов и CORS не участвует —
// самый надёжный способ убрать CORS-проблемы в разработке.
//
// Чтобы это работало, фронтенд должен обращаться к ОТНОСИТЕЛЬНЫМ путям
// (/api/...), а не к http://localhost:8080. Это включается, если НЕ задавать
// VITE_API_URL (см. client.js: API_URL по умолчанию пустой -> относительные URL).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:8080',
        changeOrigin: true,
      },
      '/ws': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:8080',
        changeOrigin: true,
        ws: true, // проксируем и WebSocket (чат, уведомления)
      },
    },
  },
})
