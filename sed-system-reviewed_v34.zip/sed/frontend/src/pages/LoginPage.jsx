import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import ThemeSwitcher from '../components/ThemeSwitcher'

export default function LoginPage() {
  const { doLogin } = useAuth()
  const navigate = useNavigate()
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await doLogin(login, password)
      navigate('/documents/all')
    } catch (err) {
      setError(err.message || 'Не удалось войти')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg text-text-primary font-body">
      <div className="absolute top-4 right-4">
        <ThemeSwitcher />
      </div>
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-surface border border-border rounded-lg p-6 shadow-sm"
      >
        <h1 className="font-display text-xl font-semibold mb-1">СЭД</h1>
        <p className="text-sm text-text-secondary mb-5">Система доведения указаний</p>

        <label className="block text-sm mb-1" htmlFor="login">
          Логин
        </label>
        <input
          id="login"
          value={login}
          onChange={(e) => setLogin(e.target.value)}
          className="w-full mb-3 px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
          autoComplete="username"
          required
        />

        <label className="block text-sm mb-1" htmlFor="password">
          Пароль
        </label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-4 px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
          autoComplete="current-password"
          required
        />

        {error && <div className="text-danger text-sm mb-3">{error}</div>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 rounded-md bg-accent text-accent-contrast font-medium disabled:opacity-60"
        >
          {loading ? 'Вход…' : 'Войти'}
        </button>
      </form>
    </div>
  )
}
