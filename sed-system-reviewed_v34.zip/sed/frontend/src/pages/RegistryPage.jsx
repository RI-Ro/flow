import React, { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import UrgencyBadge from '../components/UrgencyBadge'
import { fmtDateTime, fmtDate, docYears } from '../utils/format'

const KIND_TABS = [
  { id: 'outgoing', label: 'Исходящие' },
  { id: 'incoming', label: 'Входящие' },
  { id: 'control', label: 'На контроле' },
  { id: 'all', label: 'Сводный' },
]
const STATUS_LABELS = {
  draft: 'Черновик', on_approval_hierarchy: 'Согласование', on_approval_cross_dept: 'Согласование',
  on_signing: 'На подписи', signed: 'Подписан', sent: 'Направлен', in_progress: 'В работе',
  executed: 'Исполнен', archived: 'Архив', rejected: 'Отклонён',
}
const STATUS_COLORS = {
  draft: 'text-text-secondary', on_approval_hierarchy: 'text-warning', on_approval_cross_dept: 'text-warning',
  on_signing: 'text-warning', signed: 'text-accent', sent: 'text-accent', in_progress: 'text-accent-2',
  executed: 'text-success', archived: 'text-text-secondary', rejected: 'text-danger',
}
// Подсветка всей строки: срочно — оттенок оранжевого, вне очереди — оттенок красного.
const ROW_TONE = {
  urgent: 'row-urgent',
  out_of_turn: 'row-oot',
}

// Журнал/реестр документов: официальная таблица со всеми реквизитами —
// исходящий номер с датой подписи, все входящие номера (по подразделениям, с
// датой регистрации), краткое содержание, согласующие с датами, рассылка с
// ФИО/должностью/подразделением. Выгрузка в Excel.
export default function RegistryPage() {
  const { kind = 'outgoing' } = useParams()
  const navigate = useNavigate()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const now = new Date().getFullYear()
  const [year, setYear] = useState('') // '' = все годы
  const YEARS = docYears()

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const res = await api.getRegistry(kind, year)
      setRows(res.items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [kind, year])

  useEffect(() => { load() }, [load])

  return (
    <div className="p-4 w-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display text-xl font-semibold">Журналы документов</h1>
        <div className="flex items-center gap-2">
          <select
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
          >
            <option value="">Все годы</option>
            {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <button
            onClick={() => api.downloadRegistryCsv(kind, year).catch((e) => setError(e.message))}
            className="px-3 py-1.5 rounded-md border border-border text-sm hover:bg-surface-alt"
          >
            Выгрузить в Excel
          </button>
        </div>
      </div>

      <div className="flex gap-1 mb-4 border-b border-border">
        {KIND_TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => navigate(`/registry/${t.id}`)}
            className={`px-4 py-2 text-sm border-b-2 -mb-px ${
              t.id === kind ? 'border-accent text-accent' : 'border-transparent text-text-secondary'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      <div className="bg-surface border border-border rounded-lg overflow-x-auto">
        <table className="w-full text-sm align-top">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border">
              <th className="px-3 py-2 font-medium">Срочность</th>
              <th className="px-3 py-2 font-medium">Готовность</th>
              <th className="px-3 py-2 font-medium">№ исх. / дата подписи</th>
              <th className="px-3 py-2 font-medium">№ вх. (подразделение, регистрация)</th>
              <th className="px-3 py-2 font-medium">Подписант</th>
              <th className="px-3 py-2 font-medium">Краткое наименование / содержание</th>
              <th className="px-3 py-2 font-medium">Статус</th>
              <th className="px-3 py-2 font-medium">Автор</th>
              <th className="px-3 py-2 font-medium">Согласующие</th>
              <th className="px-3 py-2 font-medium">Рассылка</th>
              <th className="px-3 py-2 font-medium">Печать / учёт в журнале</th>
              <th className="px-3 py-2 font-medium">Создан</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={12} className="px-3 py-6 text-center text-text-secondary">Загрузка…</td></tr>
            )}
            {!loading && rows.length === 0 && (
              <tr><td colSpan={12} className="px-3 py-6 text-center text-text-secondary">Журнал пуст</td></tr>
            )}
            {!loading && rows.map((r) => (
              <tr
                key={r.id}
                onClick={() => navigate(`/document/${r.id}`)}
                className={`border-b border-border last:border-0 cursor-pointer align-top transition-colors ${ROW_TONE[r.urgency] || 'hover:bg-surface-alt'}`}
              >
                {/* Срочность */}
                <td className="px-3 py-2"><UrgencyBadge urgency={r.urgency} /></td>
                {/* Готовность (с временем) */}
                <td className="px-3 py-2 text-xs whitespace-nowrap">
                  {r.due_datetime ? fmtDateTime(r.due_datetime) : fmtDate(r.due_date)}
                </td>
                {/* № исх. / дата подписи */}
                <td className="px-3 py-2 font-mono text-xs">
                  {r.outgoing_number || '—'}
                  {r.signed_at && <div className="text-text-secondary">{fmtDateTime(r.signed_at)}</div>}
                </td>
                {/* № вх. (подразделение, регистрация) */}
                <td className="px-3 py-2 text-xs">
                  {(r.incoming_numbers || []).length === 0 && '—'}
                  {(r.incoming_numbers || []).map((i, idx) => (
                    <div key={idx} className="font-mono">
                      {i.number}
                      <span className="text-text-secondary font-sans"> — {i.department}{i.registered_at ? `, ${fmtDateTime(i.registered_at)}` : ''}</span>
                    </div>
                  ))}
                </td>
                {/* Подписант */}
                <td className="px-3 py-2 text-text-secondary text-xs">{r.signer_name || '—'}</td>
                {/* Краткое наименование / содержание */}
                <td className="px-3 py-2 max-w-[34rem]">
                  <div className="font-medium text-text-primary">{r.title}</div>
                  {r.body_summary && <div className="text-text-secondary text-xs line-clamp-2">{r.body_summary}</div>}
                </td>
                {/* Статус (цветом) */}
                <td className={`px-3 py-2 font-medium ${STATUS_COLORS[r.status] || 'text-text-secondary'}`}>{STATUS_LABELS[r.status] || r.status}</td>
                {/* Автор */}
                <td className="px-3 py-2 text-text-secondary text-xs">{r.author_name}</td>
                {/* Согласующие */}
                <td className="px-3 py-2 text-text-secondary text-xs">
                  {(r.approvers || []).length === 0 && '—'}
                  {(r.approvers || []).map((a, idx) => (
                    <div key={idx}>
                      {a.fio}{a.position ? ` (${a.position})` : ''}
                      {a.decided_at && <span className="opacity-70"> — {fmtDateTime(a.decided_at)}</span>}
                    </div>
                  ))}
                </td>
                {/* Рассылка */}
                <td className="px-3 py-2 text-text-secondary text-xs max-w-[28rem]">
                  {(r.recipients || []).length === 0 && '—'}
                  {(r.recipients || []).map((rc, idx) => (
                    <div key={idx}>{rc.fio}{rc.position ? `, ${rc.position}` : ''}{rc.department ? `, ${rc.department}` : ''}</div>
                  ))}
                </td>
                {/* Печать / учёт в журнале */}
                <td className="px-3 py-2 text-text-secondary text-xs max-w-[26rem]">
                  {(r.prints || []).length === 0 && '—'}
                  {(r.prints || []).map((p, idx) => (
                    <div key={idx}>
                      Экз. № {p.instance || '—'} · Копия № {p.copy} · {p.fio} · распечатано {fmtDateTime(p.printed_at)}
                      {p.reg_at
                        ? ` · журнал «${p.reg_journal}» № ${p.reg_number} от ${fmtDateTime(p.reg_at)}`
                        : ' · не зарегистрирован'}
                    </div>
                  ))}
                </td>
                {/* Создан */}
                <td className="px-3 py-2 text-text-secondary text-xs whitespace-nowrap">{fmtDateTime(r.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
