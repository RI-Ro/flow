import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'

const STATUS_LABELS = {
  draft: 'Черновики',
  on_approval_hierarchy: 'Согласование (иерархия)',
  on_approval_cross_dept: 'Согласование (межвед.)',
  on_signing: 'На подписи',
  signed: 'Подписаны',
  sent: 'Отправлены',
  in_progress: 'В работе',
  executed: 'Исполнены',
  archived: 'В архиве',
  rejected: 'Отклонены',
}
const URGENCY_LABELS = { normal: 'Обычные', urgent: 'Срочные', out_of_turn: 'Вне очереди' }

function StatCard({ label, value, accent, onClick }) {
  const clickable = typeof onClick === 'function'
  return (
    <div
      onClick={onClick}
      className={`text-left bg-surface border border-border rounded-lg p-4 ${
        clickable ? 'cursor-pointer hover:bg-surface-alt hover:border-accent/40 transition' : ''
      }`}
    >
      <div className="text-3xl font-semibold" style={accent ? { color: accent } : undefined}>
        {value}
      </div>
      <div className="text-sm text-text-secondary mt-1">{label}</div>
    </div>
  )
}

export default function DashboardPage() {
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    api.getDashboardStats().then(setStats).catch((e) => setError(e.message))
  }, [])

  if (error) return <div className="p-6 text-danger">{error}</div>
  if (!stats) return <div className="p-6 text-text-secondary">Загрузка…</div>

  const my = stats.my_actions || {}
  const statusMap = Object.fromEntries((stats.by_status || []).map((x) => [x.key, x.count]))
  const urgencyMap = Object.fromEntries((stats.by_urgency || []).map((x) => [x.key, x.count]))
  const total = Object.values(statusMap).reduce((s, v) => s + (v || 0), 0)
  const control = stats.on_control || {}

  // Категории соответствуют вкладкам навигации и списку /documents/:category.
  // Значения — реальные счётчики (не стрелка): статус-категории берём из
  // by_status, контроль и входящие/исходящие — из отдельных счётчиков.
  // Исходящие берём из точного backend-счётчика outgoing_total (документы моего
  // подразделения с исходящим номером), а НЕ из суммы видимых sent-статусов —
  // иначе у чисто-входящего пользователя карточка была бы ошибочно ненулевой.
  const outgoingCount = stats.outgoing_total || 0
  const onApprovalCount = (statusMap.on_approval_hierarchy || 0) + (statusMap.on_approval_cross_dept || 0)
  const CATEGORIES = [
    { id: 'outgoing', label: 'Исходящие', accent: 'var(--color-accent)', value: outgoingCount },
    { id: 'incoming', label: 'Входящие', accent: 'var(--color-accent-2)', value: stats.incoming_total || 0 },
    { id: 'on_approval', label: 'На согласовании', accent: 'var(--color-warning)', value: onApprovalCount },
    { id: 'on_signing', label: 'На подписи', accent: 'var(--color-accent)', value: statusMap.on_signing || 0 },
    { id: 'control', label: 'На контроле', accent: 'var(--color-danger)', value: control.total || 0 },
    { id: 'executed', label: 'Исполнено', value: statusMap.executed || 0 },
    { id: 'archive', label: 'Архив', value: statusMap.archived || 0 },
  ]

  return (
    <div className="p-6 max-w-[120rem] mx-auto">
      <h1 className="font-display text-xl font-semibold mb-1">Дашборд</h1>
      <div className="kicker mb-4">// всего документов: {total}</div>

      {/* Требует моего действия */}
      <h2 className="text-sm font-medium mb-2">Требует моего действия</h2>
      <div className="grid grid-cols-5 gap-3 mb-6">
        <StatCard label="На согласовании" value={my.on_approval || 0} accent="var(--color-warning)" onClick={() => navigate('/documents/on_approval')} />
        <StatCard label="На подписи" value={my.on_signing || 0} accent="var(--color-accent)" onClick={() => navigate('/documents/on_signing')} />
        <StatCard label="На исполнении" value={my.on_execution || 0} accent="var(--color-accent-2)" onClick={() => navigate('/documents/incoming')} />
        <StatCard label="На моём контроле" value={my.on_control || 0} accent="var(--color-danger)" onClick={() => navigate('/documents/control')} />
        <StatCard label="Просрочено" value={my.overdue || 0} accent="var(--color-danger)" />
      </div>

      {/* Разделы — все активные ссылки на категории */}
      <h2 className="text-sm font-medium mb-2">Разделы</h2>
      <div className="grid grid-cols-4 gap-3 mb-6">
        {CATEGORIES.map((cat) => (
          <StatCard
            key={cat.id}
            label={cat.label}
            value={cat.value || 0}
            accent={cat.accent}
            onClick={() => navigate(`/documents/${cat.id}`)}
          />
        ))}
      </div>

      {/* По статусам — только статистика, без переходов */}
      <h2 className="text-sm font-medium mb-2">По статусам</h2>
      <div className="grid grid-cols-4 gap-3 mb-6">
        {Object.entries(STATUS_LABELS).map(([key, label]) => (
          <StatCard key={key} label={label} value={statusMap[key] || 0} />
        ))}
      </div>

      {/* По срочности */}
      <h2 className="text-sm font-medium mb-2">По срочности</h2>
      <div className="grid grid-cols-3 gap-3">
        {Object.entries(URGENCY_LABELS).map(([key, label]) => (
          <StatCard
            key={key}
            label={label}
            value={urgencyMap[key] || 0}
            accent={
              key === 'out_of_turn'
                ? 'var(--color-urgency-outofturn)'
                : key === 'urgent'
                ? 'var(--color-urgency-urgent)'
                : undefined
            }
          />
        ))}
      </div>
    </div>
  )
}
