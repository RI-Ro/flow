import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import Layout from './components/Layout'
import LoginPage from './pages/LoginPage'
import DocumentsListPage from './pages/DocumentsListPage'
import DocumentDetailPage from './pages/DocumentDetailPage'
import CreateDocumentPage from './pages/CreateDocumentPage'
import DashboardPage from './pages/DashboardPage'
import RegistryPage from './pages/RegistryPage'
import AdminPage from './pages/AdminPage'
import NotFound from './components/NotFound'

function RequireAuth({ children }) {
  const { authed } = useAuth()
  if (!authed) return <Navigate to="/login" replace />
  return children
}

// Доступ к разделу администрирования — только для роли admin.
function RequireAdmin({ children }) {
  const { isAdmin, me } = useAuth()
  if (me === null) return null // профиль ещё грузится
  if (!isAdmin) return <Navigate to="/documents/all" replace />
  return children
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            element={
              <RequireAuth>
                <Layout />
              </RequireAuth>
            }
          >
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/registry/:kind" element={<RegistryPage />} />
            <Route path="/documents/:category" element={<DocumentsListPage />} />
            <Route path="/document/new" element={<CreateDocumentPage />} />
            <Route path="/document/:id" element={<DocumentDetailPage />} />
            <Route path="/admin" element={<RequireAdmin><AdminPage /></RequireAdmin>} />
            <Route path="/" element={<Navigate to="/documents/all" replace />} />
            <Route path="*" element={<NotFound title="404 Oops! Страница не найдена." />} />
          </Route>
        </Routes>
      </AuthProvider>
    </ThemeProvider>
  )
}
