import React, { createContext, useContext, useEffect, useState } from 'react'

// 10 тем в стиле balun: 5 тёмных + 5 светлых, дефолт — balun (тёмная).
export const THEMES = [
  { id: 'balun', label: 'Balun', dark: true },
  { id: 'midnight', label: 'Midnight', dark: true },
  { id: 'carbon', label: 'Carbon', dark: true },
  { id: 'graphite-neon', label: 'Graphite', dark: true },
  { id: 'ember', label: 'Ember', dark: true },
  { id: 'light', label: 'Light', dark: false },
  { id: 'paper', label: 'Paper', dark: false },
  { id: 'mint', label: 'Mint', dark: false },
  { id: 'frost', label: 'Frost', dark: false },
  { id: 'rose', label: 'Rose', dark: false },
]

const ThemeContext = createContext(null)

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(localStorage.getItem('sed_theme') || 'balun')

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
    localStorage.setItem('sed_theme', theme)
  }, [theme])

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
