import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { api, setToken, clearToken, isAuthenticated } from '../api/client'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [authed, setAuthed] = useState(isAuthenticated())
  const [login, setLoginName] = useState(localStorage.getItem('sed_login') || '')
  const [me, setMe] = useState(null) // { roles, is_admin, can_create, full_name }

  const doLogin = useCallback(async (loginValue, password) => {
    const res = await api.login(loginValue, password)
    setToken(res.token)
    localStorage.setItem('sed_login', res.login)
    setLoginName(res.login)
    setAuthed(true)
  }, [])

  const doLogout = useCallback(() => {
    clearToken()
    localStorage.removeItem('sed_login')
    setMe(null)
    setAuthed(false)
  }, [])

  // Профиль с ролями — для гейтинга UI (кнопки создания и т.п.).
  useEffect(() => {
    if (!authed) { setMe(null); return }
    let stop = false
    api.getMe().then((r) => { if (!stop) setMe(r) }).catch(() => {})
    return () => { stop = true }
  }, [authed])

  // Проактивно продлеваем сессию, пока пользователь работает: обновляем токен
  // при запуске и далее каждые 20 минут. Это устраняет «протухание» активной
  // сессии. Если refresh не удался (токен уже истёк) — request() уже увёл на
  // /login через обработку 401, поэтому здесь просто молча выходим.
  useEffect(() => {
    if (!authed) return
    let stop = false
    const refresh = async () => {
      try {
        const res = await api.refreshToken()
        if (!stop && res?.token) setToken(res.token)
      } catch (_) { /* 401 обрабатывается в request() */ }
    }
    refresh()
    const iv = setInterval(refresh, 20 * 60 * 1000)
    return () => { stop = true; clearInterval(iv) }
  }, [authed])

  return (
    <AuthContext.Provider value={{
      authed, login, doLogin, doLogout,
      me,
      fullName: me?.full_name || '',
      position: me?.position || '',
      roles: me?.roles || [],
      isAdmin: !!me?.is_admin,
      canCreate: !!me?.can_create,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
