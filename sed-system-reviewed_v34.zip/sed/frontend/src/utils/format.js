// Единый формат даты-времени в интерфейсе: "22:00:04 21.07.2026 г."
// (время, затем дата). Используется во всех списках и карточках.
function pad(n) {
  return String(n).padStart(2, '0')
}

export function fmtDateTime(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  if (isNaN(d.getTime())) return typeof ts === 'string' ? ts : '—'
  const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
  const date = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`
  return `${time} ${date} г.`
}

// Только дата (без времени): "21.07.2026 г."
export function fmtDate(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  if (isNaN(d.getTime())) return typeof ts === 'string' ? ts : '—'
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} г.`
}

// Годы для фильтров архива/журнала: от текущего года вниз до 2026 (первый год
// системы). Новые годы (2027, 2028…) появляются автоматически с их наступлением.
export function docYears() {
  const now = new Date().getFullYear()
  const start = 2026
  const end = Math.max(now, start)
  const out = []
  for (let y = end; y >= start; y--) out.push(y)
  return out
}
