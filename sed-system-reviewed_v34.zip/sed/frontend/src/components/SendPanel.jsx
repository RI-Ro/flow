import React, { useState, useEffect } from 'react'
import { api } from '../api/client'
import PersonPicker from './PersonPicker'

// Направление документа рассылке. Мультивыбор получателей через PersonPicker
// (group="recipients"). Дополнительно (#4) — выбор ГРУППЫ адресатов: при выборе
// группы показываем количество и состав участников и добавляем их всех к
// получателям одним нажатием. Кнопка «Очистить всех» убирает всех выбранных.
// Получателем может быть только дежурный/канцелярия; участники группы уже
// несут корректное department_id (где выдана роль), поэтому DB-триггер проходит.
export default function SendPanel({ documentId, onSent, plannedHint, excludeIds = [] }) {
  const [recipients, setRecipients] = useState([])
  const [groups, setGroups] = useState([])
  const [selectedGroup, setSelectedGroup] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api.listRecipientGroups().then((r) => setGroups(r.items || [])).catch(() => setGroups([]))
  }, [])

  const activeGroup = groups.find((g) => String(g.id) === String(selectedGroup))
  const excludeSet = new Set([...(excludeIds || []), ...recipients.map((r) => r.id)])

  function addGroup() {
    if (!activeGroup) return
    const additions = (activeGroup.members || [])
      .filter((m) => !excludeSet.has(m.user_id))
      .map((m) => ({
        id: m.user_id,
        full_name: m.full_name,
        position: m.position,
        department_id: m.department_id,
        department_name: m.department_name,
        city: m.city,
      }))
    const merged = [...recipients]
    for (const a of additions) if (!merged.some((r) => r.id === a.id)) merged.push(a)
    setRecipients(merged)
  }

  async function handleSend() {
    setBusy(true)
    setError('')
    try {
      await api.sendDocument(
        documentId,
        recipients.map((r) => ({ user_id: r.id, department_id: r.department_id })),
      )
      setSent(true)
      onSent?.()
    } catch (err) {
      setError(err.message || 'Не удалось отправить документ')
    } finally {
      setBusy(false)
    }
  }

  if (sent) {
    return (
      <div className="bg-surface border border-border rounded-lg p-4 text-sm text-success">
        Документ направлен получателям
      </div>
    )
  }

  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h2 className="font-medium text-sm mb-2">Направить документ</h2>
      <p className="text-xs text-text-secondary mb-3">
        Получателями могут быть только дежурные и сотрудники канцелярии. Можно выбрать нескольких или
        добавить группу адресатов.
        {plannedHint ? ' Оставьте поле пустым, чтобы направить плановым адресатам, выбранным при создании.' : ''}
      </p>

      {/* #4 — Выбор группы адресатов */}
      {groups.length > 0 && (
        <div className="mb-3 border border-border rounded-md p-2 bg-surface-alt/40">
          <label className="block text-xs text-text-secondary mb-1">Группа адресатов</label>
          <div className="flex gap-2">
            <select
              value={selectedGroup}
              onChange={(e) => setSelectedGroup(e.target.value)}
              className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
            >
              <option value="">— выберите группу —</option>
              {groups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.member_count})
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={addGroup}
              disabled={!activeGroup || activeGroup.member_count === 0}
              className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-50"
            >
              Добавить всех
            </button>
          </div>
          {activeGroup && (
            <div className="mt-2 text-xs text-text-secondary">
              Участников: {activeGroup.member_count}
              {activeGroup.members?.length > 0 && (
                <ul className="mt-1 max-h-28 overflow-auto space-y-0.5">
                  {activeGroup.members.map((m) => (
                    <li key={`${m.user_id}:${m.department_id}`}>
                      {m.full_name}
                      {(m.position || m.department_name || m.city) && (
                        <span className="opacity-70"> · {[m.position, m.department_name, m.city].filter(Boolean).join(' · ')}</span>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-text-secondary">Получатели ({recipients.length})</span>
        {recipients.length > 0 && (
          <button
            type="button"
            onClick={() => setRecipients([])}
            className="text-xs text-danger hover:underline"
          >
            Очистить всех
          </button>
        )}
      </div>
      <PersonPicker
        group="recipients"
        multiple
        value={recipients}
        onChange={setRecipients}
        excludeIds={excludeIds}
        placeholder="Выберите получателей…"
      />
      {error && <div className="text-danger text-xs my-2">{error}</div>}
      <button
        onClick={handleSend}
        disabled={busy}
        className="w-full mt-2 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-60"
      >
        {busy ? 'Отправка…' : recipients.length > 0 ? `Направить (${recipients.length})` : 'Направить плановым адресатам'}
      </button>
    </div>
  )
}
