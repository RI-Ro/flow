import React, { useEffect, useRef, useState, useCallback } from 'react'
import { api } from '../api/client'
import { playEventSound } from '../lib/sound'
import { fmtDateTime } from '../utils/format'

// Обсуждение документа. Сообщения ПЕРСИСТЯТСЯ в БД (chat_messages); при открытии
// карточки история подгружается через REST, живые сообщения приходят по WS.
// Показываем автора и дату; поддерживаются вложения (files[]).
export default function ChatPanel({ documentId, currentUserId }) {
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const [files, setFiles] = useState([])
  const [connected, setConnected] = useState(false)
  const [sending, setSending] = useState(false)
  const wsRef = useRef(null)
  const listRef = useRef(null)
  const fileRef = useRef(null)

  // Слить сообщение по id без дублей (WS может продублировать REST-ответ).
  const mergeMessage = useCallback((m) => {
    setMessages((prev) => {
      if (m.id && prev.some((x) => x.id === m.id)) return prev
      return [...prev, m]
    })
  }, [])

  // История из БД при открытии.
  useEffect(() => {
    let cancelled = false
    api.getChatHistory(documentId)
      .then((r) => { if (!cancelled) setMessages(r.items || []) })
      .catch(() => {})
    return () => { cancelled = true }
  }, [documentId])

  // WS с авто-переподключением.
  useEffect(() => {
    let closedByUs = false
    let retry = 0
    let timer = null

    function connect() {
      let ws
      try { ws = new WebSocket(api.wsURL(documentId)) } catch (_) { schedule(); return }
      wsRef.current = ws
      ws.onopen = () => { retry = 0; setConnected(true) }
      ws.onclose = () => { setConnected(false); if (!closedByUs) schedule() }
      ws.onerror = () => { try { ws.close() } catch (_) { /* noop */ } }
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'chat_message') {
            mergeMessage(msg)
            if (msg.author_id && msg.author_id !== currentUserId) playEventSound('chat_message')
          } else if (msg.type === 'chat_updated') {
            api.getChatHistory(documentId).then((r) => setMessages(r.items || [])).catch(() => {})
          }
        } catch (_) { /* игнорируем */ }
      }
    }
    function schedule() {
      retry += 1
      timer = setTimeout(connect, Math.min(15000, 1000 * 2 ** Math.min(retry, 4)))
    }
    connect()
    return () => {
      closedByUs = true
      clearTimeout(timer)
      try { wsRef.current && wsRef.current.close() } catch (_) { /* noop */ }
    }
  }, [documentId, currentUserId, mergeMessage])

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight })
  }, [messages])

  const send = useCallback(async () => {
    if ((!text.trim() && files.length === 0) || sending) return
    setSending(true)
    try {
      if (files.length > 0) {
        // С вложениями — только через REST (WS не носит бинарные файлы).
        await api.postChatMessage(documentId, text.trim(), files)
        setFiles([])
        if (fileRef.current) fileRef.current.value = ''
        setText('')
        // Всегда перечитываем историю: WS-эхо не содержит вложений, поэтому
        // полагаться на него нельзя (иначе появлялось «пустое» сообщение).
        setMessages((await api.getChatHistory(documentId)).items || [])
      } else if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'chat_message', text: text.trim() }))
        setText('')
      } else {
        // WS закрыт — отправляем через REST, чтобы сообщение не потерялось.
        await api.postChatMessage(documentId, text.trim(), [])
        setText('')
        setMessages((await api.getChatHistory(documentId)).items || [])
      }
    } catch (e) {
      alert(e.message || 'Не удалось отправить сообщение')
    } finally {
      setSending(false)
    }
  }, [text, files, sending, connected, documentId])

  function fmt(ts) {
    try { return fmtDateTime(ts) }
    catch (_) { return ts }
  }

  return (
    <div className="bg-surface border border-border rounded-lg flex flex-col h-full min-h-0">
      <div className="px-3 py-2 border-b border-border flex items-center justify-between">
        <h2 className="font-medium text-sm">Обсуждение</h2>
        <span className={`text-[10px] ${connected ? 'text-success' : 'text-text-secondary'}`}>
          {connected ? '● на связи' : '○ не в сети'}
        </span>
      </div>

      <div ref={listRef} className="flex-1 min-h-0 overflow-auto p-3 space-y-2">
        {messages.length === 0 && <div className="text-text-secondary text-xs">Сообщений пока нет</div>}
        {messages.map((m, i) => {
          const mine = m.author_id === currentUserId
          return (
            <div key={m.id || i} className={`flex flex-col ${mine ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[85%] rounded-lg px-2.5 py-1.5 text-sm ${mine ? 'bg-accent/15 border border-accent/30' : 'bg-surface-alt border border-border'}`}>
                {!mine && <div className="text-[11px] text-text-secondary mb-0.5">{m.author_name || `Пользователь #${m.author_id}`}</div>}
                {m.deleted ? (
                  <div className="italic text-text-secondary">сообщение удалено</div>
                ) : (
                  <>
                    {m.text && <div className="whitespace-pre-wrap break-words">{m.text}</div>}
                    {(m.attachments || []).map((a) => (
                      <button
                        key={a.id}
                        onClick={() => api.downloadChatAttachment(a.id, a.file_name).catch((e) => alert(e.message))}
                        className="mt-1 flex items-center gap-1 text-xs text-accent hover:underline"
                      >
                        📎 {a.file_name} <span className="text-text-secondary">({Math.max(1, Math.round((a.size_bytes || 0) / 1024))} КБ)</span>
                      </button>
                    ))}
                  </>
                )}
              </div>
              <div className="text-[10px] text-text-secondary mt-0.5 flex items-center gap-1.5">
                <span>{fmt(m.created_at)}</span>
                {m.edited_at && !m.deleted && <span>· изменено {fmt(m.edited_at)}</span>}
                {mine && !m.deleted && (
                  <>
                    <button
                      className="text-accent hover:underline"
                      onClick={() => {
                        const nt = prompt('Изменить сообщение:', m.text || '')
                        if (nt && nt.trim() && nt.trim() !== m.text) {
                          api.editChatMessage(m.id, nt.trim())
                            .then(() => api.getChatHistory(documentId).then((r) => setMessages(r.items || [])))
                            .catch((e) => alert(e.message))
                        }
                      }}
                    >править</button>
                    <button
                      className="text-danger hover:underline"
                      onClick={() => {
                        if (confirm('Удалить сообщение?')) {
                          api.deleteChatMessage(m.id)
                            .then(() => api.getChatHistory(documentId).then((r) => setMessages(r.items || [])))
                            .catch((e) => alert(e.message))
                        }
                      }}
                    >удалить</button>
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <div className="border-t border-border p-2">
        {files.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-1">
            {files.map((f, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 bg-surface-alt border border-border rounded px-1.5 py-0.5 text-[11px]">
                {f.name}
                <button className="text-danger" onClick={() => setFiles(files.filter((_, i) => i !== idx))}>×</button>
              </span>
            ))}
          </div>
        )}
        <div className="flex items-end gap-1.5">
          <button
            onClick={() => fileRef.current?.click()}
            className="px-2 py-1.5 rounded-md border border-border text-sm"
            title="Прикрепить файл"
          >📎</button>
          <input
            ref={fileRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => setFiles([...files, ...Array.from(e.target.files || [])])}
          />
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
            rows={1}
            placeholder="Сообщение…"
            className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm resize-none"
          />
          <button
            onClick={send}
            disabled={sending || (!text.trim() && files.length === 0)}
            className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm disabled:opacity-60"
          >→</button>
        </div>
      </div>
    </div>
  )
}
