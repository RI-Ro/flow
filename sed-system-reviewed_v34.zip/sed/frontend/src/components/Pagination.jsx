import React from 'react'

export default function Pagination({ page, pageSize, totalCount, onPageChange }) {
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize))
  if (totalPages <= 1) return null

  const from = (page - 1) * pageSize + 1
  const to = Math.min(page * pageSize, totalCount)

  return (
    <div className="flex items-center justify-between border-t border-border pt-3 mt-3 text-sm text-text-secondary">
      <span>
        {from}–{to} из {totalCount}
      </span>
      <div className="flex gap-1">
        <button
          className="px-3 py-1 rounded-md border border-border disabled:opacity-40 hover:bg-surface-alt"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
        >
          Назад
        </button>
        <span className="px-3 py-1 text-text-primary">
          {page} / {totalPages}
        </span>
        <button
          className="px-3 py-1 rounded-md border border-border disabled:opacity-40 hover:bg-surface-alt"
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
        >
          Вперёд
        </button>
      </div>
    </div>
  )
}
