import React, { useState, useEffect } from 'react'
import { api } from './../api/client'

// RecipientGroupPicker — блок выбора ГРУППЫ адресатов рассылки (#1/#4).
// Показывает выпадающий список групп с количеством участников, при выборе —
// состав, и кнопку «Добавить всех» (добавляет участников к переданному списку
// получателей value через onChange). Используется на формах создания и
// редактирования документа рядом с PersonPicker(group="recipients"), а также в
// панели направления. Дедуплицирует по id и учитывает excludeIds.
export default function RecipientGroupPicker({ value = [], onChange, excludeIds = [] }) {
  const [groups, setGroups] = useState([])
  const [selectedGroup, setSelectedGroup] = useState('')

  useEffect(() => {
    api.listRecipientGroups().then((r) => setGroups(r.items || [])).catch(() => setGroups([]))
  }, [])

  if (groups.length === 0) return null

  const activeGroup = groups.find((g) => String(g.id) === String(selectedGroup))
  const excludeSet = new Set([...(excludeIds || []), ...value.map((r) => r.id)])

  function addGroup() {
    if (!activeGroup) return
    const additions = (activeGroup.members || [])
      .filter((m) => !excludeSet.has(m.user_id))
      .map((m) => ({
        id: m.user_id,
        full_name: m.full_name,
        position: m.position,
        department_id: m.department_id,
        department_name: m.department_name,
        city: m.city,
      }))
    const merged = [...value]
    for (const a of additions) if (!merged.some((r) => r.id === a.id)) merged.push(a)
    onChange(merged)
  }

  return (
    <div className="mb-2 border border-border rounded-md p-2 bg-surface-alt/40">
      <label className="block text-xs text-text-secondary mb-1">Группа адресатов</label>
      <div className="flex gap-2">
        <select
          value={selectedGroup}
          onChange={(e) => setSelectedGroup(e.target.value)}
          className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
        >
          <option value="">— выберите группу —</option>
          {groups.map((g) => (
            <option key={g.id} value={g.id}>
              {g.name} ({g.member_count})
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={addGroup}
          disabled={!activeGroup || activeGroup.member_count === 0}
          className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-50"
        >
          Добавить всех
        </button>
      </div>
      {activeGroup && (
        <div className="mt-2 text-xs text-text-secondary">
          Участников: {activeGroup.member_count}
          {activeGroup.members?.length > 0 && (
            <ul className="mt-1 max-h-28 overflow-auto space-y-0.5">
              {activeGroup.members.map((m) => (
                <li key={`${m.user_id}:${m.department_id}`}>
                  {m.full_name}
                  {(m.position || m.department_name || m.city) && (
                    <span className="opacity-70"> · {[m.position, m.department_name, m.city].filter(Boolean).join(' · ')}</span>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
