import React, { useEffect, useState } from 'react'
import { api } from '../api/client'
import RouteBuilder from './RouteBuilder'
import PersonPicker from './PersonPicker'
import RecipientGroupPicker from './RecipientGroupPicker'

// Полноценная форма редактирования — аналогична форме создания документа:
// метаданные + маршрут согласования + подписант + плановая рассылка +
// контроль. Бэкенд разрешает менять метаданные/маршрут только пока
// согласование не началось (иначе 409); рассылку — пока документ не разослан.
// Соответствующие ошибки показываем пользователю.
export default function EditDocumentModal({ doc, onClose, onSaved, currentUserId }) {
  const [title, setTitle] = useState(doc.title || '')
  const [bodySummary, setBodySummary] = useState(doc.body_summary || '')
  const [urgency, setUrgency] = useState(doc.urgency || 'normal')
  // #2 — «Готовность»: раздельные дата (обязательно) и время (необязательно).
  // Из имеющегося due_datetime вытягиваем локальные дату и время; если время
  // ровно 23:59 (значение по умолчанию) — поле времени оставляем пустым.
  const initLocal = doc.due_datetime ? new Date(doc.due_datetime).toLocaleString('sv') : '' // "YYYY-MM-DD HH:mm:ss"
  const initialDate = initLocal ? initLocal.slice(0, 10) : (doc.due_date ? doc.due_date.slice(0, 10) : '')
  const initialTime = initLocal ? initLocal.slice(11, 16) : ''
  const [dueDate, setDueDate] = useState(initialDate)
  const [dueTime, setDueTime] = useState(initialTime === '23:59' ? '' : initialTime)
  const [newFile, setNewFile] = useState(null)

  const [approvers, setApprovers] = useState([])
  const [sequential, setSequential] = useState(true)
  const [skipApproval, setSkipApproval] = useState(false)
  const [signer, setSigner] = useState([])
  const [recipients, setRecipients] = useState([])

  const [onControl, setOnControl] = useState(!!doc.on_control)
  const [controller, setController] = useState([]) // #4 — несколько контролёров (грузим из API)

  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const editable = ['draft', 'on_approval_hierarchy', 'on_approval_cross_dept', 'on_signing', 'rejected'].includes(doc.status)

  // Префилл маршрута/подписанта/рассылки из текущего состояния документа.
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const [stagesRes, recRes, ctlRes] = await Promise.all([
          api.getStages(doc.id).catch(() => ({ items: [] })),
          api.getRecipients(doc.id).catch(() => ({ items: [] })),
          api.getDocumentControllers(doc.id).catch(() => ({ items: [] })),
        ])
        if (cancelled) return
        const stages = stagesRes.items || stagesRes || []
        const appr = stages
          .filter((s) => s.stage_type === 'hierarchy' || s.stage_type === 'cross_dept')
          .sort((a, b) => (a.display_order || 0) - (b.display_order || 0))
          .map((s) => ({
            id: s.approver_id,
            full_name: s.approver_name,
            department_name: '',
            stage_type: s.stage_type,
          }))
        // #3 — подписантов может быть несколько (несколько signing-этапов).
        const signStages = stages.filter((s) => s.stage_type === 'signing')
        setApprovers(appr)
        setSkipApproval(appr.length === 0)
        setSigner(
          signStages.map((s) => ({
            id: s.approver_id,
            full_name: s.approver_name,
            department_name: s.approver_department,
          })),
        )
        const planned = (recRes.items || []).filter((r) => r.is_planned)
        setRecipients(
          planned.map((r) => ({
            id: r.user_id,
            full_name: r.full_name,
            department_id: r.department_id,
            department_name: r.department_name,
          })),
        )
        // #4 — контролёров может быть несколько.
        setController(
          (ctlRes.items || []).map((cn) => ({
            id: cn.user_id,
            full_name: cn.full_name,
            position: cn.position,
            department_name: cn.department_name,
            city: cn.city,
          })),
        )
      } finally {
        if (!cancelled) setLoaded(true)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [doc.id])

  async function save() {
    setBusy(true)
    setError('')
    try {
      // 1) Метаданные. Готовность: время НЕОБЯЗАТЕЛЬНО — если не задано, время
      // не подставляем (due_datetime = null), выводиться будет только дата.
      const dueIso = dueDate && dueTime ? new Date(`${dueDate}T${dueTime}`).toISOString() : null
      await api.updateDocument(doc.id, {
        title,
        body_summary: bodySummary,
        urgency,
        due_date: dueDate || null,
        due_datetime: dueIso,
      })
      // 2) Маршрут + подписанты (только если можно и есть хотя бы один).
      if (editable && signer.length > 0) {
        await api.updateRoute(doc.id, {
          approvers: skipApproval ? [] : approvers.map((a) => ({ stage_type: a.stage_type, approver_id: a.id })),
          sequential: skipApproval ? false : sequential,
          signer_ids: signer.map((s) => s.id),
        })
      }
      // 3) Плановая рассылка.
      await api.updatePlannedRecipients(doc.id, recipients)
      // 4) Контроль.
      await api.setControl(doc.id, onControl, controller.map((c) => c.id))
      // 5) Замена файла оригинала (если выбран новый) — сбрасывает согласование.
      if (newFile) {
        await api.replaceDocumentFile(doc.id, newFile)
      }
      onSaved?.()
      onClose()
    } catch (e) {
      setError(e.message || 'Не удалось сохранить изменения')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-surface border border-border rounded-lg p-5 w-full max-w-2xl max-h-[90vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="font-display text-lg font-semibold mb-3">Изменить документ</h2>

        {!editable && (
          <div className="mb-3 text-xs text-warning border border-warning/40 bg-warning/5 rounded-md px-3 py-2">
            Согласование уже началось — метаданные и маршрут заморожены. Доступны только рассылка и контроль.
          </div>
        )}

        <div className="space-y-4">
          {/* Метаданные */}
          <div className="bg-surface-alt/40 border border-border rounded-lg p-3 space-y-3">
            <div>
              <label className="block text-sm mb-1">Краткое наименование</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                disabled={!editable}
                className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-60"
              />
            </div>
            <div>
              <label className="block text-sm mb-1">Краткое содержание</label>
              <textarea
                value={bodySummary}
                onChange={(e) => setBodySummary(e.target.value)}
                rows={3}
                disabled={!editable}
                className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-60"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm mb-1">Срочность</label>
                <select
                  value={urgency}
                  onChange={(e) => setUrgency(e.target.value)}
                  disabled={!editable}
                  className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-60"
                >
                  <option value="normal">Обычная</option>
                  <option value="urgent">Срочно</option>
                  <option value="out_of_turn">Вне очереди</option>
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">Готовность</label>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    disabled={!editable}
                    className="flex-1 px-3 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-60"
                  />
                  <input
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    disabled={!editable || !dueDate}
                    title="Время (необязательно)"
                    className="w-24 px-2 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-50"
                  />
                </div>
              </div>
            </div>

            {/* Замена файла оригинала (до подписи). Сбрасывает согласование. */}
            <div className="mt-3">
              <label className="block text-sm mb-1">Заменить файл документа (PDF)</label>
              <input
                type="file"
                accept="application/pdf"
                disabled={!editable}
                onChange={(e) => setNewFile(e.target.files?.[0] || null)}
                className="w-full text-sm file:mr-3 file:px-3 file:py-1.5 file:rounded-md file:border-0 file:bg-accent file:text-accent-contrast disabled:opacity-60"
              />
              {newFile && (
                <div className="text-xs text-warning mt-1">
                  Файл будет заменён. Если согласование начато — оно будет сброшено и начнётся заново.
                </div>
              )}
            </div>
          </div>

          {/* Согласование */}
          {editable && loaded && (
            <div className="bg-surface-alt/40 border border-border rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-sm">Согласование</h3>
                <label className="flex items-center gap-2 text-xs text-text-secondary">
                  <input type="checkbox" checked={skipApproval} onChange={(e) => setSkipApproval(e.target.checked)} />
                  Пропустить (сразу на подпись)
                </label>
              </div>
              {!skipApproval && (
                <div className="space-y-2">
                  <RouteBuilder value={approvers} onChange={setApprovers} excludeIds={[currentUserId].filter(Boolean)} />
                  <label className="flex items-center gap-2 text-xs text-text-secondary">
                    <input type="checkbox" checked={sequential} onChange={(e) => setSequential(e.target.checked)} />
                    Последовательное согласование
                  </label>
                </div>
              )}
            </div>
          )}

          {/* Подпись */}
          {editable && loaded && (
            <div className="bg-surface-alt/40 border border-border rounded-lg p-3">
              <h3 className="font-medium text-sm mb-1">Подпись</h3>
              <p className="text-xs text-text-secondary mb-1">
                Можно указать нескольких подписантов — достаточно одной подписи.
              </p>
              <PersonPicker
                group="signing"
                multiple
                value={signer}
                onChange={setSigner}
              />
            </div>
          )}

          {/* Рассылка */}
          {loaded && (
            <div className="bg-surface-alt/40 border border-border rounded-lg p-3">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-medium text-sm">Рассылка (плановые адресаты)</h3>
                {recipients.length > 0 && (
                  <button type="button" onClick={() => setRecipients([])} className="text-xs text-danger hover:underline">
                    Очистить всех
                  </button>
                )}
              </div>
              <RecipientGroupPicker value={recipients} onChange={setRecipients} excludeIds={[currentUserId].filter(Boolean)} />
              <PersonPicker group="recipients" multiple value={recipients} onChange={setRecipients} />
            </div>
          )}

          {/* Контроль */}
          {loaded && (
            <div className="bg-surface-alt/40 border border-border rounded-lg p-3">
              <label className="flex items-center gap-2 text-sm mb-2">
                <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
                Поставить на контроль
              </label>
              {onControl && (
                <div>
                  <label className="block text-xs text-text-secondary mb-1">Контролёры (можно несколько)</label>
                  <PersonPicker group="controller" multiple value={controller} onChange={setController} />
                </div>
              )}
            </div>
          )}

          {error && <div className="text-danger text-sm">{error}</div>}
        </div>

        <div className="flex justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-3 py-1.5 rounded-md border border-border text-sm">
            Отмена
          </button>
          <button
            onClick={save}
            disabled={busy || !title || !loaded}
            className="px-3 py-1.5 rounded-md bg-accent text-accent-contrast text-sm font-medium disabled:opacity-60"
          >
            {busy ? 'Сохранение…' : 'Сохранить'}
          </button>
        </div>
      </div>
    </div>
  )
}
