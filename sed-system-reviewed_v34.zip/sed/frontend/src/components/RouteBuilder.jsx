import React, { useState, useCallback } from 'react'
import { api } from '../api/client'

const SEARCH_DEBOUNCE_MS = 250
const STAGE_LABELS = {
  hierarchy: 'По иерархии',
  cross_dept: 'Между подразделениями',
}

// RouteBuilder — конструктор маршрута согласования с настраиваемой
// очерёдностью. В отличие от жёсткого «сначала иерархия, потом межвед», здесь
// единый упорядоченный список: у каждого согласующего свой тип, а порядок
// задаёт пользователь (стрелки вверх/вниз). Иерархия может стоять после
// межведомственного согласования — как требуется.
//
// value: [{ id, full_name, department_name, stage_type }]  (порядок = очерёдность)
// onChange: (nextValue) => void
// excludeIds: id, которые нельзя выбирать (автор)
export default function RouteBuilder({ value = [], onChange, excludeIds = [] }) {
  const [query, setQuery] = useState('')
  const [stageType, setStageType] = useState('hierarchy')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)

  const chosenIds = new Set(value.map((v) => v.id))
  const excluded = new Set([...excludeIds, ...chosenIds])

  // Поиск кандидатов по выбранному типу этапа (роль-фильтр на сервере).
  // Список показывается СРАЗУ при открытии (пустой q = начало списка группы),
  // ввод текста лишь сужает — чтобы согласующего можно было выбрать нажатием.
  React.useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await api.searchCandidates({ group: stageType, q: query.trim(), limit: 30 })
        if (!cancelled) setResults(res.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      } finally {
        if (!cancelled) setLoading(false)
      }
    }, query.trim() ? SEARCH_DEBOUNCE_MS : 0)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [query, stageType, open])

  const add = useCallback(
    (person) => {
      onChange([
        ...value,
        {
          id: person.id,
          full_name: person.full_name,
          department_id: person.department_id,
          department_name: person.department_name,
          stage_type: stageType,
        },
      ])
      setQuery('')
      setResults([])
    },
    [value, onChange, stageType],
  )

  const remove = useCallback((id) => onChange(value.filter((v) => v.id !== id)), [value, onChange])

  const move = useCallback(
    (idx, dir) => {
      const next = [...value]
      const j = idx + dir
      if (j < 0 || j >= next.length) return
      ;[next[idx], next[j]] = [next[j], next[idx]]
      onChange(next)
    },
    [value, onChange],
  )

  // Группировка результатов поиска по подразделению.
  const grouped = results
    .filter((r) => !excluded.has(r.id))
    .reduce((acc, r) => {
      const key = r.department_name || 'Без подразделения'
      ;(acc[key] = acc[key] || []).push(r)
      return acc
    }, {})

  return (
    <div>
      {/* Текущий маршрут — упорядоченный список */}
      {value.length > 0 && (
        <ol className="mb-3 space-y-1.5">
          {value.map((v, idx) => (
            <li
              key={v.id}
              className="flex items-center gap-2 bg-surface-alt border border-border rounded-md px-2 py-1.5 text-sm"
            >
              <span className="kicker w-6 text-center">{idx + 1}</span>
              <div className="flex flex-col">
                <div className="flex flex-col leading-none">
                  <span className="flex-1">
                    {v.full_name}
                    {v.department_name && (
                      <span className="text-text-secondary"> · {v.department_name}</span>
                    )}
                  </span>
                </div>
              </div>
              <span className="ml-auto text-[10px] px-1.5 py-0.5 rounded-full border border-border text-text-secondary">
                {STAGE_LABELS[v.stage_type]}
              </span>
              <div className="flex items-center gap-0.5">
                <button
                  type="button"
                  onClick={() => move(idx, -1)}
                  disabled={idx === 0}
                  className="px-1 text-text-secondary disabled:opacity-30"
                  title="Выше"
                >
                  ↑
                </button>
                <button
                  type="button"
                  onClick={() => move(idx, 1)}
                  disabled={idx === value.length - 1}
                  className="px-1 text-text-secondary disabled:opacity-30"
                  title="Ниже"
                >
                  ↓
                </button>
                <button type="button" onClick={() => remove(v.id)} className="px-1 text-danger" title="Убрать">
                  ×
                </button>
              </div>
            </li>
          ))}
        </ol>
      )}

      {/* Добавление нового согласующего: тип + поиск */}
      <div className="flex gap-2 relative">
        <select
          value={stageType}
          onChange={(e) => {
            setStageType(e.target.value)
            setResults([])
          }}
          className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
          title="Тип согласования"
        >
          <option value="hierarchy">По иерархии</option>
          <option value="cross_dept">Между подразделениями</option>
        </select>
        <div className="flex-1 relative">
          <input
            value={query}
            onFocus={() => setOpen(true)}
            onChange={(e) => {
              setQuery(e.target.value)
              setOpen(true)
            }}
            onBlur={() => setTimeout(() => setOpen(false), 150)}
            placeholder="Начните вводить имя согласующего…"
            className="w-full px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          />
          {open && (
            <div className="absolute z-20 mt-1 w-full max-h-64 overflow-auto bg-surface border border-border rounded-md shadow-lg">
              {loading && <div className="px-3 py-2 text-xs text-text-secondary">Загрузка…</div>}
              {!loading && Object.keys(grouped).length === 0 && (
                <div className="px-3 py-2 text-xs text-text-secondary">
                  {query.trim() ? 'Ничего не найдено' : 'Нет доступных согласующих этого типа'}
                </div>
              )}
              {!loading &&
                Object.entries(grouped).map(([dept, people]) => (
                  <div key={dept}>
                    <div className="kicker px-3 pt-2 pb-1 sticky top-0 bg-surface">// {dept}</div>
                    {people.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onMouseDown={() => add(p)}
                        className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt"
                      >
                        {p.full_name}
                      </button>
                    ))}
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
      <p className="kicker mt-1.5">
        // порядок в списке = очерёдность согласования. Иерархия и межвед. можно чередовать как угодно.
      </p>
    </div>
  )
}
