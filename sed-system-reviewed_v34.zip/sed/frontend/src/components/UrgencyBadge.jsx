import React from 'react'

const LABELS = {
  normal: 'Обычная',
  urgent: 'Срочно',
  out_of_turn: 'Вне очереди',
}

const COLOR_VARS = {
  normal: 'var(--color-urgency-normal)',
  urgent: 'var(--color-urgency-urgent)',
  out_of_turn: 'var(--color-urgency-outofturn)',
}

export default function UrgencyBadge({ urgency }) {
  const color = COLOR_VARS[urgency] || COLOR_VARS.normal
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border"
      style={{ color, borderColor: color, backgroundColor: 'transparent' }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {LABELS[urgency] || urgency}
    </span>
  )
}
