import React from 'react'
import { useNavigate } from 'react-router-dom'

// Иллюстрация «документ не найден» — самостоятельно нарисованный SVG на тему
// документов (лист с загнутым углом, строки текста, лупа, знак «нет доступа»).
// Использует CSS-переменные темы, поэтому подстраивается под любую тему.
export function NotFoundArt({ className = '' }) {
  return (
    <svg viewBox="0 0 320 260" className={className} role="img"
         aria-label="Документ не найден" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="nf-page" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--color-surface)" />
          <stop offset="1" stopColor="var(--color-surface-alt)" />
        </linearGradient>
      </defs>

      {/* мягкая тень-подложка */}
      <ellipse cx="160" cy="232" rx="96" ry="12" fill="var(--color-accent)" opacity="0.08" />

      {/* задний лист */}
      <g transform="rotate(-8 120 120)">
        <rect x="70" y="52" width="120" height="150" rx="8"
              fill="url(#nf-page)" stroke="var(--color-border)" strokeWidth="2" />
      </g>

      {/* передний лист с загнутым углом */}
      <g>
        <path d="M120 40 h84 a8 8 0 0 1 8 8 v150 a8 8 0 0 1 -8 8 h-96 a8 8 0 0 1 -8 -8 V64 z"
              fill="url(#nf-page)" stroke="var(--color-border)" strokeWidth="2" />
        <path d="M120 40 l20 20 h-20 z" fill="var(--color-surface-alt)"
              stroke="var(--color-border)" strokeWidth="2" />
        {/* строки текста */}
        <rect x="120" y="78" width="70" height="7" rx="3.5" fill="var(--color-border)" opacity="0.7" />
        <rect x="120" y="94" width="82" height="7" rx="3.5" fill="var(--color-border)" opacity="0.55" />
        <rect x="120" y="110" width="60" height="7" rx="3.5" fill="var(--color-border)" opacity="0.55" />
        <rect x="120" y="126" width="82" height="7" rx="3.5" fill="var(--color-border)" opacity="0.4" />
        <rect x="120" y="142" width="48" height="7" rx="3.5" fill="var(--color-border)" opacity="0.4" />
      </g>

      {/* лупа */}
      <g transform="translate(150 150)">
        <circle cx="40" cy="40" r="34" fill="var(--color-accent)" opacity="0.10" />
        <circle cx="40" cy="40" r="34" fill="none" stroke="var(--color-accent)" strokeWidth="6" />
        <line x1="64" y1="64" x2="92" y2="92" stroke="var(--color-accent)"
              strokeWidth="10" strokeLinecap="round" />
        {/* знак «нет» внутри лупы */}
        <circle cx="40" cy="40" r="17" fill="none" stroke="var(--color-danger)" strokeWidth="4" />
        <line x1="28" y1="52" x2="52" y2="28" stroke="var(--color-danger)" strokeWidth="4" strokeLinecap="round" />
      </g>

      {/* крупная 404 водяным знаком */}
      <text x="160" y="30" textAnchor="middle"
            fontFamily="var(--font-display, ui-sans-serif)" fontSize="26" fontWeight="700"
            fill="var(--color-accent)" opacity="0.85">404</text>
    </svg>
  )
}

// NotFound — полноэкранный блок «404» для отсутствующего/недоступного документа
// либо любого несуществующего маршрута.
export default function NotFound({
  title = '404 Oops! Документ не найден или доступ к нему запрещен.',
  showBack = true,
}) {
  const navigate = useNavigate()
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8 gap-4">
      <NotFoundArt className="w-64 h-52" />
      <h1 className="font-display text-xl font-semibold text-text-primary max-w-md">{title}</h1>
      <div className="flex gap-2 mt-2">
        {showBack && (
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 rounded-md border border-border text-sm hover:bg-surface-alt"
          >
            ← Назад
          </button>
        )}
        <button
          onClick={() => navigate('/documents/all')}
          className="px-4 py-2 rounded-md bg-accent text-accent-contrast text-sm font-semibold"
        >
          К списку документов
        </button>
      </div>
    </div>
  )
}
