import React, { useState, useRef, useEffect } from 'react'
import { useTheme, THEMES } from '../context/ThemeContext'

const SWATCH = {
  balun: ['#0c0f0b', '#b6ff3c'],
  midnight: ['#0a0d16', '#5b7fff'],
  carbon: ['#0a0a0a', '#35e6d6'],
  'graphite-neon': ['#0e0c14', '#b479ff'],
  ember: ['#120d0a', '#ff8a3c'],
  light: ['#f5f6fb', '#4a5cff'],
  paper: ['#f7f1e6', '#b4780f'],
  mint: ['#f2faf4', '#1f9e5c'],
  frost: ['#f0f6fb', '#1c8fd1'],
  rose: ['#fbf3f6', '#c23b7a'],
}

const darkCount = THEMES.filter((t) => t.dark).length
const lightCount = THEMES.length - darkCount

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  const current = THEMES.find((t) => t.id === theme) || THEMES[0]

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 px-2.5 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
      >
        <span className="flex rounded-full overflow-hidden border border-border w-4 h-4 shrink-0">
          <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[current.id]?.[0] }} />
          <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[current.id]?.[1] }} />
        </span>
        {current.label}
      </button>

      {open && (
        <div className="absolute right-0 mt-1 w-56 bg-surface border border-border rounded-md shadow-lg z-20 p-1.5">
          <div className="kicker px-2 py-1">
            // {darkCount} dark · {lightCount} light
          </div>
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setTheme(t.id)
                setOpen(false)
              }}
              className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm hover:bg-surface-alt ${
                t.id === theme ? 'bg-surface-alt' : ''
              }`}
            >
              <span className="flex rounded-full overflow-hidden border border-border w-4 h-4 shrink-0">
                <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[t.id]?.[0] }} />
                <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[t.id]?.[1] }} />
              </span>
              <span className="flex-1 text-left">{t.label}</span>
              <span className="text-[10px] text-text-secondary">{t.dark ? 'dark' : 'light'}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
