# Ревью и план правок СЭД

Разбор по каждому замечанию: корневая причина + конкретная правка. Для двух
багов «не работает» правка уже вынесена в готовые файлы (см. ниже) — их можно
применять сразу. Остальное — патчи «уровня ревью»: я не мог собрать Go / поднять
Postgres в этой среде, поэтому диффы выверены по чтению кода, но не
скомпилированы; помечаю уверенность у каждого пункта.

Уже приложено в репозитории:
- `backend/migrations_psql/0018_fix_delete_policies.sql` — чинит удаление
  документов и правку/удаление комментариев (пункты 2 и 8).
- `testdata_generator.sql` (в корне) — генератор тестовых документов (пункт 13).

---

## 2 + 8. Не работает удаление документа и правка/удаление комментариев/файлов — **ГОТОВО (высокая уверенность)**

Один корень у обоих. Таблицы `documents`, `chat_messages` объявлены с
`FORCE ROW LEVEL SECURITY`, но политики заведены только на часть команд:

| Таблица | SELECT | INSERT | UPDATE | DELETE |
|---|---|---|---|---|
| `documents` | ✔ | ✔ | ✔ | **нет** |
| `chat_messages` | ✔ | ✔ | **нет** | **нет** |

При включённом RLS отсутствие политики = запрет. Поэтому:
- `handlers/documents_create.go → Delete` выполняет `DELETE FROM documents …`,
  который под RLS не затрагивает ни одной строки. Ошибки нет, приходит `200`,
  но документ остаётся — «удаление не работает».
- `handlers/chat.go → EditMessage/DeleteMessage` делают `UPDATE chat_messages …`
  (правка текста и мягкое удаление через `deleted_at`). UPDATE-политики нет →
  `RowsAffected()==0` → `403 «можно редактировать только своё сообщение»`.

Про «файлы»: вложения (`chat_attachments`) удаляются каскадом при мягком
удалении сообщения, но само сообщение не удаляется из-за той же причины —
после починки chat UPDATE удаление вложений заработает. Отдельной RLS у
`chat_attachments` нет, дополнительная политика не нужна.

Правка — миграция `0018_fix_delete_policies.sql`: добавляет
`documents_delete`, `chat_update`, `chat_delete`. Бизнес-ограничение «удалять
можно только до подписи» уже корректно живёт в сервисном слое (`Delete`
пропускает только `draft`/`rejected`), его трогать не нужно (см. п.8 ниже про
уточнение статусов).

Применение:
```bash
psql "$DATABASE_URL" -f backend/migrations_psql/0018_fix_delete_policies.sql
# либо через goose как обычную миграцию
```

### Уточнение к п.8 «удалить можно только до подписи»
Текущий `Delete` разрешает удаление в статусах `draft` и `rejected`. По ТЗ
«до подписи» — это ещё и `on_approval_hierarchy`, `on_approval_cross_dept`,
`on_signing` (пока подписи фактически нет). Поменять один список статусов:

```go
// handlers/documents_create.go, func Delete
deletable := map[string]bool{
    "draft": true, "rejected": true,
    "on_approval_hierarchy": true, "on_approval_cross_dept": true,
    "on_signing": true,
}
if !deletable[status] && !isAdmin {
    return errForbiddenDelete
}
```
Признак «есть подпись» надёжнее проверять по `document_signatures`, а не по
статусу (на случай гонок): `SELECT NOT EXISTS(SELECT 1 FROM document_signatures WHERE document_id=$1)`.

---

## 1. Колонки списка документов + цвета + формат «2/1» для согласующих — **средняя уверенность (нужен бэкенд-агрегат + фронт)**

Требуемый порядок колонок:
> Срочность, Срок исполнения, № исх./дата подписи, № вх. (подразделение,
> регистрация), Подписант, Заголовок/содержание, Статус, Автор, Согласующие,
> Рассылка, Дата создания.

Сейчас в `pages/DocumentsListPage.jsx` колонки другие, а данные по строке
(автор, подписант, вх. номера, дата подписи) подтягиваются отдельным вызовом
`GET /recipients-counts` (`handlers/send.go → RecipientsCounts`). Там же удобно
добавить агрегат согласующих. Цвета статуса/срочности уже есть
(`STATUS_COLORS`, `UrgencyBadge`, тонирование строки по срочности).

### 1a. Бэкенд: добавить агрегат согласующих в `RecipientsCounts`
В `send.go` в блоке «Доп. реквизиты» дописать в SELECT json согласующих со
статусом и временем решения (для формата `всего/согласовано` и всплывающих
деталей):

```sql
-- добавить ещё одну колонку в тот же SELECT ... FROM documents d ...
coalesce((
  SELECT json_agg(json_build_object(
           'name', u.full_name,
           'position', coalesce(u.position,''),
           'stage_type', s.stage_type,
           'status', s.status,
           'decided_at', to_char(s.decided_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'))
         ORDER BY s.display_order)
  FROM approval_stages s JOIN users u ON u.id = s.approver_id
  WHERE s.document_id = d.id AND s.stage_type IN ('hierarchy','cross_dept')
), '[]') AS approvers
```
и посчитать `approvers_total` / `approvers_approved` (либо на фронте из массива).
Просканировать новое поле в `brows.Scan(...)` и положить в `entry["approvers"]`.

### 1b. Фронт: новый порядок колонок + «2/1»
Замена `<thead>` и тела строки в `DocumentsListPage.jsx`. Ключевой момент —
согласующие в формате `2/1` (по аналогии с уже сделанными адресатами):

```jsx
// helper для формата "всего/готово"
const ratio = (arr, doneKey='status', doneVal='approved') => {
  const total = arr?.length || 0
  const done = (arr || []).filter(x => x[doneKey] === doneVal).length
  return { total, done }
}
```

```jsx
<thead>
  <tr className="text-left text-text-secondary border-b border-border">
    <th className="px-3 py-2 font-medium">Срочность</th>
    <th className="px-3 py-2 font-medium">Срок исполнения</th>
    <th className="px-3 py-2 font-medium">№ исх. / дата подписи</th>
    <th className="px-3 py-2 font-medium">№ вх. (подр., рег.)</th>
    <th className="px-3 py-2 font-medium">Подписант</th>
    <th className="px-3 py-2 font-medium">Заголовок / содержание</th>
    <th className="px-3 py-2 font-medium">Статус</th>
    <th className="px-3 py-2 font-medium">Автор</th>
    <th className="px-3 py-2 font-medium">Согласующие</th>
    <th className="px-3 py-2 font-medium">Рассылка</th>
    <th className="px-3 py-2 font-medium">Создан</th>
  </tr>
</thead>
```
Ячейка согласующих (клик — открыть модалку с деталями статуса/времени, как у
адресатов):
```jsx
<td className="px-3 py-2"
    onClick={(e) => { e.stopPropagation(); setApproversDoc(doc) }}>
  {(() => {
    const a = counts[doc.id]?.approvers || []
    const { total, done } = ratio(a)
    return total ? (
      <span className="text-accent hover:underline cursor-pointer">
        {total} / <span className="text-success font-medium">{done}</span>
      </span>
    ) : <span className="text-text-secondary">—</span>
  })()}
</td>
```
Ячейка рассылки — вынести из совмещённой в отдельную (адресаты остаются как
сейчас — `total / done` с модалкой). Модалка адресатов уже есть (`setModalDoc`),
для согласующих сделать такую же `ApproversModal` с колонками
Согласующий (с должностью) · Статус (цветом) · Время согласования.

Срочность цветом — переиспользовать `UrgencyBadge`. Статус цветом — уже есть
`STATUS_COLORS[doc.status]`.

---

## 3. Права на поручения (+ авто-ознакомление) — **средняя уверенность**

Сейчас `service.CanAssignTo` (в `service/permissions.go`) разрешает поручать
«в своём подразделении и вниз по иерархии» (рекурсивный subtree) + автор/
подписант — получателям + в хендлере отдельно «кого сам ознакомил». Не хватает
**«+ заданные конкретные подразделения»** (кейс главного дежурного, который вне
иерархии, но следит за всеми дежурными).

### 3a. Таблица «дополнительных подразделений для поручений»
По аналогии с уже существующей `user_acquaint_departments` завести
`user_assign_departments` (миграция):
```sql
CREATE TABLE IF NOT EXISTS user_assign_departments (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id BIGINT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id));
```

### 3b. Расширить `CanAssignTo`
Добавить в дизъюнкцию проверку по заданным подразделениям (и их поддеревьям):
```sql
-- внутри inSubtree() расширить набор корней:
WITH RECURSIVE roots AS (
    SELECT primary_department_id AS id FROM users WHERE id = $1
    UNION
    SELECT department_id FROM user_assign_departments WHERE user_id = $1
),
subtree AS (
    SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
    UNION ALL
    SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
)
SELECT EXISTS (SELECT 1 FROM users u
    WHERE u.id = $2 AND u.primary_department_id IN (SELECT id FROM subtree));
```

### 3c. Авто-ознакомление после поручения
В `handlers/assignments.go → Create`, после вставки поручения и до commit,
если ответственный ещё не ознакомлен — вставить запись ознакомления
(документ станет ему «открыт» и в списке ознакомления):
```go
if _, err := tx.Exec(c.Context(), `
    INSERT INTO document_acquaintances (document_id, user_id, acquainted_by)
    VALUES ($1, $2, $3)
    ON CONFLICT (document_id, user_id) DO NOTHING`, docID, req.AssigneeID, userID); err != nil {
    return err
}
```
Доступ к документу уже выдаётся строкой `document_access … 'executor'` — это
корректно «открывает» документ; ознакомление добавляем именно как факт для
списка ознакомления и уведомления.

---

## 4. Права на ознакомление — **средняя уверенность**

Зеркально п.3, но для ознакомления и таблицы `user_acquaint_departments`
(она уже есть в схеме). Проверить `handlers/acquaintance.go → Candidates/Create`:
кандидаты и право ознакамливать должны считаться как
`своё подразделение + поддерево ∪ user_acquaint_departments(+поддеревья)`.
Если сейчас `Candidates` берёт только subtree основного подразделения —
добавить UNION по `user_acquaint_departments` (тем же рекурсивным CTE, что в 3b,
только из таблицы ознакомления). Кейс канцелярии (вне иерархии, но ознакамливает
исполнителей) закрывается именно этой таблицей.

---

## 5. Дашборд: у Кузнецова показываются «Исходящие», хотя есть только входящие; ссылка на исх. не открывается — **высокая уверенность**

Причина во фронте (`pages/DashboardPage.jsx`). «Исходящие» считаются так:
```js
const outgoingCount = signed + sent + in_progress + executed + archived
```
Эти счётчики берутся из `by_status`, а `by_status` под RLS считает **все
видимые** пользователю документы, включая **входящие** экземпляры дежурного
(они как раз в статусах `sent`/`in_progress`). Поэтому у Кузнецова, у которого
только входящие, «Исходящие» ненулевые, а переход в `/documents/outgoing`
(фильтр по `author_department_id = его основное подразделение`) даёт пусто —
«не открывается».

Правильно считать исходящие как «документы, автором/исходящим подразделением
которых является пользователь», а не «любой видимый sent-документ». Даёт
отдельный счётчик на бэкенде.

### 5a. Бэкенд (`handlers/dashboard.go`)
Добавить точный счётчик исходящих (документы своего исходящего подразделения,
у которых есть исходящий номер), рядом с `incoming_total`:
```go
var outgoingTotal int64
if err := tx.QueryRow(c.Context(), `
    SELECT count(*) FROM documents
    WHERE author_department_id = (SELECT primary_department_id FROM users WHERE id=$1)
      AND outgoing_number IS NOT NULL
      AND status <> 'archived'`, userID).Scan(&outgoingTotal); err != nil {
    return err
}
result["outgoing_total"] = outgoingTotal
```

### 5b. Фронт (`DashboardPage.jsx`)
```js
{ id: 'outgoing', label: 'Исходящие', accent: 'var(--color-accent)',
  value: stats.outgoing_total || 0 },
```
и убрать самодельный `outgoingCount`. Тогда у чисто-входящего пользователя
«Исходящие» = 0 и карточка либо скрывается, либо ведёт в пустой (но валидный)
список. Дополнительно можно прятать карточку при `value===0` для ролей без
права исходящих.

Также стоит проверить категорию `outgoing` в `repository/documents.go → List`:
она должна фильтровать по `author_department_id` текущего пользователя И
`outgoing_number IS NOT NULL`, иначе список и счётчик разойдутся.

---

## 6. Срок исполнения — с выбором времени — **высокая уверенность (в основном фронт)**

Бэкенд уже готов: в `documents` есть `due_datetime timestamptz`, `Create`/
`Update` принимают `due_datetime`, репозиторий его хранит. Не хватает ввода
времени на фронте и показа времени в списке.

### 6a. Создание/редактирование (`pages/CreateDocumentPage.jsx`, `components/EditDocumentModal.jsx`)
Заменить `<input type="date">` на `datetime-local` и слать `due_datetime`:
```jsx
<input type="datetime-local" value={dueDatetime}
       onChange={(e) => setDueDatetime(e.target.value)} />
// при сабмите:
form.append('due_datetime', dueDatetime ? new Date(dueDatetime).toISOString() : '')
// due_date можно не слать — бэкенд возьмёт дату из due_datetime; либо слать
// обе: form.append('due_date', dueDatetime ? dueDatetime.slice(0,10) : '')
```
Мелочь на бэкенде: если пришёл `due_datetime`, а `due_date` пуст — выставлять
`due_date := date(due_datetime)`, чтобы фильтры/просрочка по `due_date`
продолжали работать. Это одна строка в `Create`/`Update` сервиса.

### 6b. Показ времени в списке
В `DocumentsListPage.jsx` для колонки срока использовать `due_datetime`:
```jsx
{doc.due_datetime
  ? new Date(doc.due_datetime).toLocaleString('ru-RU',
      { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' })
  : (doc.due_date ? new Date(doc.due_date).toLocaleDateString('ru-RU') : '—')}
```
Убедиться, что `repository.List` отдаёт `due_datetime` в JSON (в `domain.Document`
поле есть; проверить, что оно в SELECT списка).

---

## 7. Везде добавлять должность в скобках — **средняя уверенность**

Паттерн уже применён в `RecipientsCounts` для автора:
`full_name || ' (' || position || ')'`. Нужно распространить на всех
участников. Ввести единый SQL-фрагмент/хелпер:
```sql
-- SQL: имя с должностью
u.full_name || CASE WHEN coalesce(u.position,'')<>''
                    THEN ' (' || u.position || ')' ELSE '' END
```
Пройтись по местам, где формируется имя пользователя, и применить его:
- согласующие/подписант: `handlers/documents.go → GetStages`, `service/approval.go`
  (там `ApproverName`; добавить `ApproverPosition`, поле в `domain.ApprovalStage`
  уже есть — просто заполнять);
- получатели: `handlers/send.go → Recipients`;
- поручения: `handlers/assignments.go → List` (ответственный/контролёр);
- ознакомление: `handlers/acquaintance.go → List/Candidates`;
- история/просмотры: `handlers/documents.go → History/Views`;
- чат: `handlers/chat.go → History` (автор сообщения).

Фронтовый вариант: если у объектов есть `position`, собирать
`` `${name}${position ? ` (${position})` : ''}` `` в общем хелпере
`fio(u)` и использовать во всех местах отображения, чтобы не дублировать.

---

## 9. Изменение документа до подписи (в т.ч. во время согласования) с заменой файла и сбросом согласований — **средняя уверенность, есть подводные камни**

`service.DocumentsService.Update` уже:
- разрешает правку в `draft/on_approval_*/on_signing/rejected` (это верно);
- при наличии решённых этапов сбрасывает маршрут и пишет `route_restarted`.

Не хватает / есть баги:

1. **Замена файла.** `Update` меняет только метаданные, файл не трогает.
   Нужно принимать новый PDF (multipart) и обновлять `document_files`
   (там `UNIQUE(document_id)` — делать `UPDATE`, не `INSERT`). Хендлер `Update`
   сейчас `BodyParser(JSON)`; для файла его нужно перевести на multipart, как
   `Create`, либо добавить отдельный `PATCH /documents/:id/file`.

   ```go
   sum := sha256.Sum256(content)
   if _, err := tx.Exec(ctx, `
       UPDATE document_files
          SET content=$1, sha256=$2, size_bytes=$3, uploaded_by=$4, uploaded_at=now()
        WHERE document_id=$5`, content, hex.EncodeToString(sum[:]), len(content), actorID, documentID); err != nil {
       return err
   }
   // history: 'file_replaced'
   ```
   Факт изменения уже фиксируется записью `edited` в `document_history` —
   добавить ещё `file_replaced` при замене файла.

2. **Баг в сбросе этапов (DAG).** Сейчас сброс делает
   `UPDATE approval_stages SET status='pending' … WHERE document_id=$1` — ставит
   **все** этапы в `pending` разом, ломая последовательные зависимости (должно
   быть: этапы без незакрытых зависимостей → `pending`, остальные →
   `waiting_deps`). Правильнее переиспользовать существующий механизм запуска
   маршрута: сбросить все в `waiting_deps` и вызвать активацию корней
   (`approval.ActivateReadyStages`/аналог из `service/approval.go`, который уже
   умеет это в `CreateRoute`). Псевдо:
   ```go
   tx.Exec(ctx, `UPDATE approval_stages
       SET status='waiting_deps', decided_at=NULL, comment=NULL
       WHERE document_id=$1`)
   // затем активировать этапы без незакрытых зависимостей (как в CreateRoute)
   notified, _ := s.approval.ActivateInitialStages(ctx, tx, documentID)
   ```

3. **Баг в вычислении нового статуса.** Тот же блок сравнивает
   `firstType` со строками `"approval_hierarchy"/"approval_cross_dept"`, тогда
   как enum `stage_type` = `hierarchy/cross_dept/signing`. Условия никогда не
   срабатывают → всегда `on_signing`. Исправить кейсы на `hierarchy`/`cross_dept`.

4. **Сброс доступа согласующих.** При смене файла/сбросе маршрута ранее
   выданный `document_access(access_reason='approval_stage')` можно оставить —
   но лучше пересчитать через `access.RecomputeApprovalAccess`, чтобы снятые
   из маршрута согласующие теряли доступ.

5. **Уведомления.** После рестарта уведомить заново активированных согласующих
   (см. п.12) — использовать `notified` из активации.

---

## 10. Маркировка: `DejaVuSans is unsupported` — **средняя уверенность (нельзя проверить без сборки pdfcpu)**

Симптом: pdfcpu при построении watermark с `fontname:DejaVuSans` ругается
«unsupported», хотя `pdfcpu fonts list` показывает его в Userfonts. Типичные
причины в pdfcpu 0.8.x:

1. **Шрифт есть на диске в пользовательском каталоге, но не загружен в память
   текущего процесса.** `api.InstallFonts` регистрирует шрифт и в in-memory
   реестре, и на диске. Если в конкретном запуске задан только `font_name` без
   `font_file` (или `InstallFonts` не вызывался, т.к. `FontFile==""`), а каталог
   пользовательских шрифтов процесса отличается от того, где лежит `.gob` —
   имя не резолвится. В коде (`marking/render_pdfcpu.go`) `Configure` вызывает
   `InstallFonts` только если `FontFile != ""`. Убедиться, что в `config.yaml`
   `marking.font_file` реально указывает на существующий файл в контейнере
   (в Dockerfile нужен пакет `fonts-dejavu-core`), и что путь совпадает с
   `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf`.

2. **Каталог pdfcpu-конфига не писабельный/непостоянный.** `InstallFonts`
   пишет в `XDG_CONFIG_HOME`/`~/.config/pdfcpu/fonts`. В контейнере под
   non-root пользователем HOME может быть `/` без прав записи — установка
   «удаётся частично», а при следующем чтении шрифт не находится. Решение:
   явно задать писабельный каталог и устанавливать шрифт на старте:
   ```dockerfile
   ENV XDG_CONFIG_HOME=/app/.config
   RUN apt-get update && apt-get install -y --no-install-recommends fonts-dejavu-core \
       && mkdir -p /app/.config/pdfcpu/fonts
   ```
   и всегда вызывать `InstallFonts([]string{cfg.FontFile})` (не только при
   непустом `font_name`), логируя результат — что сейчас код и делает, но
   зависит от `FontFile`.

3. **Надёжнее — вшить шрифт в бинарь.** Убрать зависимость от системного пути:
   ```go
   //go:embed assets/DejaVuSans.ttf
   var dejaVu []byte
   // на старте: записать во временный файл и InstallFonts по нему,
   // либо использовать pdfcpu font API для регистрации из io.Reader,
   // затем fontName = "DejaVuSans".
   ```
   Это делает маркировку детерминированной независимо от окружения.

Практический шаг диагностики на боевой машине:
```bash
XDG_CONFIG_HOME=/app/.config pdfcpu fonts list   # видит ли процесс шрифт под тем же HOME
```
Если под тем же `XDG_CONFIG_HOME`, что и у сервиса, шрифта нет — значит сервис
и CLI смотрят в разные каталоги; выровнять env (вариант 2/3).

---

## 11. Пагинацию — наверх — **высокая уверенность (фронт)**

В `DocumentsListPage.jsx` блок `<Pagination …>` сейчас после `</table>`.
Перенести его над таблицей (или продублировать сверху и снизу). Минимально —
вынести из нижнего `<div className="px-4 pb-3">` и поставить сразу после
панели фильтров, до `<div className="bg-surface border …">`:
```jsx
<div className="flex justify-end mb-2">
  <Pagination page={data.page || page} pageSize={data.page_size || PAGE_SIZE}
              totalCount={data.total_count || 0} onPageChange={setPage} />
</div>
{/* далее таблица */}
```
Аналогично проверить `RegistryPage.jsx` и другие списки, если требование
«везде».

---

## 12. Переработать систему уведомлений — **дизайн + средняя уверенность**

Сейчас уведомления создаются точечно и разрозненно (в `Create` — `stage_pending`
активированным; в `send`/`assignments` — свои строки; `hub.NotifyUsers` шлёт
WS). Нет единого места, где на каждое изменение документа уведомляются **все
заинтересованные** с учётом статуса и видимости.

Предлагаемая переработка — единый нотификатор:

1. **Определить «заинтересованных» одним запросом.** Для документа это
   объединение: автор; согласующие/подписант (из `approval_stages`); получатели
   рассылки (`document_recipients`, `is_planned=false`); контролёр
   (`documents.controller_id`); руководители подразделения-автора (chief);
   ознакомленные (`document_acquaintances`); исполнители поручений
   (`assignments.assignee_id`). Всё это уже отражено в `document_access` — то
   есть «заинтересованные» ≈ `SELECT user_id FROM document_access WHERE
   document_id=$1`, что удобно и уже учитывает видимость.

2. **Единая функция** `notify.Emit(ctx, tx, documentID, kind, actorID, payload)`:
   - берёт получателей из `document_access` (минус сам актор),
   - вставляет строки `notifications` пакетно
     (`INSERT ... SELECT user_id, $doc, $kind, $payload FROM document_access
       WHERE document_id=$doc AND user_id<>$actor`),
   - шлёт WS через `hub.NotifyUsers(ids, doc, kind)`.

3. **Вызывать её из всех переходов** жизненного цикла, добавив осмысленные
   `kind`:
   - `route_sent_to_approval` (создание/пересборка маршрута),
   - `stage_approved` / `stage_rejected` (в `handlers/approval.go → Decide`),
   - `sent_to_signing` (когда все согласования пройдены),
   - `document_signed` (в `service/signing.go`),
   - `sent_to_recipients` / `document_received` (в `send`),
   - `assignment_created`, `acquaint_requested`, `edited`/`route_restarted`.
   Для адресности можно фильтровать получателей по роли в переходе (например,
   `stage_pending` — только следующему согласующему), но базовый инвариант:
   любое изменение → уведомление всем в `document_access`.

4. **Payload и дедуп.** В `payload jsonb` класть `{event, actor_id, from_status,
   to_status, stage_id?}` для человекочитаемого текста на фронте
   (`NotificationsBell.jsx`). Опционально — не плодить дубли: частичный
   уникальный индекс/`ON CONFLICT` по `(user_id, document_id, kind)` среди
   непрочитанных.

5. **RLS.** Вставка в `notifications` уже разрешена политикой
   `notifications_insert` (WITH CHECK пропускает при заданном `app.user_id`),
   так что пакетная вставка «другим пользователям» проходит — ломать ничего не
   нужно.

Это убирает текущую разрозненность и гарантирует «каждое изменение уведомляет
всех заинтересованных с учётом статуса и видимости».

---

## 13. Генератор тестовых данных — **ГОТОВО**

Файл `testdata_generator.sql` в корне. Наполняет БД документами во всех
статусах и срочностях с полным обвесом: файл-оригинал (валидный минимальный
PDF), этапы согласования (иерархия → межвед → подпись) с зависимостями и
статусами, согласованными с общим статусом документа; подписи; исходящие
номера и даты подписи; рассылку и входящие экземпляры (получатели — только
duty/clerk, чтобы проходил триггер `check_recipient_role`); поручения с
авто-ознакомлением; чат; историю; уведомления; `document_access` для всех
участников; синхронизацию `numbering_sequences`.

Запуск:
```bash
psql "$DATABASE_URL" -v ndocs=60 -f testdata_generator.sql
```
Идемпотентно: перед генерацией удаляет ранее созданные им документы (префикс
`[TD]` в `title`). Требует роль-владельца/суперпользователя (использует
`SET row_security = off` для обхода FORCE RLS на время наполнения).

---

## Сводка по приоритету

| # | Замечание | Где | Уверенность | Статус |
|---|---|---|---|---|
| 2,8 | RLS delete/update | миграция 0018 | высокая | **готово** |
| 13 | Генератор данных | testdata_generator.sql | — | **готово** |
| 5 | Дашборд «исходящие» | dashboard.go + DashboardPage | высокая | патч в ревью |
| 11 | Пагинация наверх | DocumentsListPage | высокая | патч в ревью |
| 6 | Срок со временем | Create/Edit + List | высокая | патч в ревью |
| 8 | Удаление «до подписи» | documents_create.go | высокая | патч в ревью |
| 1 | Колонки + «2/1» | send.go + DocumentsListPage | средняя | патч в ревью |
| 7 | Должности везде | много мест | средняя | паттерн в ревью |
| 3,4 | Права поручений/ознакомления | permissions.go + миграция | средняя | патч в ревью |
| 9 | Правка до подписи + файл | service/documents.go | средняя | патч в ревью |
| 12 | Переработка уведомлений | новый notify + вызовы | дизайн | план в ревью |
| 10 | Маркировка/шрифт | render_pdfcpu.go + Dockerfile | средняя | 3 варианта |

Всё, что помечено «патч в ревью», я не компилировал в этой среде (нет Go
toolchain / БД / сети для модулей). Диффы выверены по коду; при применении
прогнать `go build ./...`, `go test ./...` и e2e на демо-стенде.
