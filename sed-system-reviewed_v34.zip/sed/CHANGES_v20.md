# Изменения (итерация 20) — НАСТОЯЩАЯ причина notifications RLS

Спасибо за наводку — да, это тот же класс бага, что был с созданием документа.

## Причина
`NotifyDocumentEvent` делал `INSERT INTO notifications ... RETURNING user_id`.
Под FORCE RLS **RETURNING применяет к возвращаемым строкам SELECT-политику**.
Уведомления создаются ДЛЯ ДРУГИХ пользователей (получателей), а
`notifications_select` разрешает видеть только свои (user_id = app.user_id).
Поэтому RETURNING по чужим строкам падал с
"new row violates row-level security policy for table notifications" —
независимо от WITH CHECK (он-то как раз был правильным). Именно поэтому
WITH CHECK (true) не помогал: проблема была не в WITH CHECK, а в RETURNING.

## Исправление
`NotifyDocumentEvent` переписан:
  1. получателей берём ОТДЕЛЬНЫМ SELECT из document_access (на ней нет RLS);
  2. вставляем уведомления БЕЗ RETURNING (unnest массива получателей);
  3. список получателей возвращаем из шага 1 (для WS-пинга).
Так SELECT-политика notifications к вставке больше не применяется.

Проверено, что других INSERT ... RETURNING под FORCE RLS, возвращающих «чужие»
строки, нет:
  * documents ... RETURNING id — автор видит свои (author_id = app.user_id) → ок;
  * chat_messages ... RETURNING id — автор имеет доступ (document_access) → ок;
  * notifications — единственное место с RETURNING, исправлено.

Остальные вставки уведомлений (approval/send/signing/acquaintance/assignments/
documents) RETURNING не используют и с WITH CHECK (true) проходят.

## Итог
После пересборки и перезапуска бэкенда подпись, направление и правка перестанут
падать с ошибкой notifications RLS. Это устойчиво к состоянию БД (не зависит от
того, применились новые миграции или нет).

Проверка: Go/БД в этой среде не собираются; баланс скобок ок. Перед деплоем:
go build ./... && go test ./...
