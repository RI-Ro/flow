# Изменения (итерация 23) — единое приложение без nginx

## Одно приложение: API + WebSocket + статика
Бэкенд теперь сам раздаёт собранную статику фронтенда (SPA) — nginx и отдельный
frontend-сервис больше не нужны. Всё обслуживается одним процессом на одном
порту (8080).

- Роутер: после всех /api и /ws подключается filesystem-middleware с
  NotFoundFile=index.html (SPA-fallback для клиентского роутинга React Router).
  Next пропускает /api, /ws, /healthz — чтобы несуществующие /api/* давали
  корректный JSON-404, а не index.html. (internal/http/router.go)
- Порядок регистрации гарантирует приоритет API/WS над статикой.

## Путь к статике — в конфиге
Новая секция конфига:
```
static:
  dir: ""      # путь к собранной статике (Vite dist). Пусто = режим "только API".
```
env-override: STATIC_DIR. (internal/config/yaml.go, config.example.yaml)
Если dir пуст — приложение работает как раньше (только API), фронт можно
обслуживать отдельно.

## Docker — единый образ
- backend/Dockerfile переписан в мультистейдж: (1) node собирает фронт
  (npm run build → dist), (2) go собирает бэкенд, (3) финальный образ содержит
  бинарник + миграции + статику (/app/static), STATIC_DIR=/app/static.
  Контекст сборки — КОРЕНЬ репозитория.
- docker-compose.yml: вместо backend+frontend теперь один сервис `app`
  (context: ., dockerfile: backend/Dockerfile), порт 8080. Postgres как прежде.
- Добавлен .dockerignore (node_modules, dist, .git и т.п.).
- Фронт шлёт относительные /api и /ws (VITE_API_URL не задаётся) — тот же
  origin, что и статика; WebSocket строится из window.location.host.

frontend/Dockerfile оставлен для опционального dev-режима (vite dev server),
в проде не используется.

## Запуск
docker compose up --build     # поднимет postgres + app; UI на http://localhost:8080
Локально без Docker:
  cd frontend && npm run build
  # в config.yaml: static.dir: "../frontend/dist"  (или STATIC_DIR=...)
  cd backend && go run ./cmd/api

Проверка: Go/БД в этой среде не собираются; баланс скобок и YAML — ок,
импорты выверены (net/http как nethttp, т.к. пакет называется http). Перед
деплоем: go build ./... && go test ./...
