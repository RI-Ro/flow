// По умолчанию API_URL пустой -> запросы идут на относительные пути
// (/api/..., /ws/...), которые Vite dev-proxy направляет на бэкенд через
// тот же origin. Так браузер не делает cross-origin запросов и CORS не
// участвует вообще. Если нужно бить в API напрямую (напр. в проде, когда
// фронт и API на разных доменах) — задайте VITE_API_URL.
const API_URL = import.meta.env.VITE_API_URL || ''

function getToken() {
  return localStorage.getItem('sed_token')
}

// wsBase возвращает абсолютный origin для WebSocket. new WebSocket() требует
// абсолютный ws://|wss:// URL — относительный путь не примет. Если API_URL
// задан (прямой режим) — берём его; иначе (режим Vite-прокси) строим из
// текущего window.location, чтобы WS шёл на тот же origin (5173) и Vite
// проксировал его на бэкенд.
function wsBase() {
  if (API_URL) return API_URL.replace(/^http/, 'ws')
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${proto}://${window.location.host}`
}

async function request(path, options = {}) {
  const token = getToken()
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  }
  if (token) headers.Authorization = `Bearer ${token}`

  const res = await fetch(`${API_URL}${path}`, { ...options, headers })
  if (res.status === 401) {
    // Токен истёк/недействителен — не оставляем пользователя в подвешенном
    // состоянии с непонятными ошибками: чистим токен и уводим на вход.
    try { localStorage.removeItem('sed_token') } catch (_) { /* noop */ }
    if (!location.pathname.startsWith('/login')) location.assign('/login')
    throw new Error('Сессия истекла, войдите заново')
  }
  if (!res.ok) {
    let message = `Ошибка ${res.status}`
    try {
      const body = await res.json()
      if (body.error) message = body.error
    } catch (_) {
      /* тело не JSON — оставляем дефолтное сообщение */
    }
    // Статус нужен вызывающему коду, чтобы различать 409/422 и т.п.
    const err = new Error(message)
    err.status = res.status
    throw err
  }
  const contentType = res.headers.get('content-type') || ''
  if (contentType.includes('application/json')) return res.json()
  return res.blob()
}

export const api = {
  login: (login, password) =>
    request('/api/auth/login', { method: 'POST', body: JSON.stringify({ login, password }) }),
  // Проактивное обновление токена, чтобы активная сессия не истекала.
  refreshToken: () => request('/api/auth/refresh', { method: 'POST' }),
  getMe: () => request('/api/me'),
  getAppConfig: () => request('/api/app-config'),
  getDocumentMarking: (id) => request(`/api/documents/${id}/marking`),

  listUsers: () => request('/api/users'),

  // Серверный поиск кандидатов для шага маршрута. group: hierarchy|cross_dept|signing.
  // Возвращает пустой список, пока q пустой (защита от загрузки 300-500 человек).
  searchCandidates: ({ group, q, departmentId, limit = 20 } = {}) => {
    const params = new URLSearchParams({ group, q: q || '', limit: String(limit) })
    if (departmentId) params.set('department_id', String(departmentId))
    return request(`/api/users/candidates?${params.toString()}`)
  },

  listDepartments: () => request('/api/departments'),

  // multipart/form-data: без Content-Type — браузер сам проставит boundary.
  createDocument: async (formData) => {
    const token = getToken()
    const res = await fetch(`${API_URL}/api/documents`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try {
        const body = await res.json()
        if (body.error) message = body.error
      } catch (_) {
        /* тело не JSON */
      }
      throw new Error(message)
    }
    return res.json()
  },

  listDocuments: ({ category = 'all', page = 1, pageSize, departmentId, year } = {}) => {
    const params = new URLSearchParams({ category, page: String(page) })
    if (pageSize) params.set('page_size', String(pageSize))
    if (departmentId) params.set('department_id', String(departmentId))
    if (year) params.set('year', String(year))
    return request(`/api/documents?${params.toString()}`)
  },

  // Возвращает { document, incoming_marking }; incoming_marking заполнен,
  // только если текущий пользователь — зарегистрированный получатель.
  getDocument: (id) => request(`/api/documents/${id}`),
  getCopies: (id) => request(`/api/documents/${id}/copies`),
  // Печать
  getPrints: (id) => request(`/api/documents/${id}/prints`),
  registerPrint: (id, printId, body) => request(`/api/documents/${id}/prints/${printId}/register`, { method: 'PATCH', body: JSON.stringify(body) }),
  printDownloadURL: (id) => `/api/documents/${id}/print`,
  // downloadPrint: POST на печать, получает МАРКИРОВАННЫЙ PDF (blob) и
  // инициирует скачивание файла в браузере. Возвращает Error при отказе.
  // #11 — диагностика: почему документ не выдаётся на печать.
  printDiagnostics: (id) => request(`/api/documents/${id}/print-diagnostics`),
  downloadPrint: async (id, copyId) => {
    const token = getToken()
    const url = copyId ? `/api/documents/${id}/print?copy_id=${copyId}` : `/api/documents/${id}/print`
    const res = await fetch(url, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) {
      let msg = 'Не удалось выдать документ на печать'
      try { const j = await res.json(); msg = j.error || j.message || msg } catch { /* ignore */ }
      throw new Error(msg)
    }
    const blob = await res.blob()
    const dlUrl = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = dlUrl
    a.download = `document-${id}-print.pdf`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(dlUrl)
  },

  // Направление рассылке. recipients: [{ user_id, department_id }].
  // Пустой массив -> бэкенд активирует плановых адресатов (выбранных при создании).
  sendDocument: (id, recipients = []) =>
    request(`/api/documents/${id}/send`, {
      method: 'POST',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({
          user_id: Number(r.user_id ?? r.id),
          department_id: Number(r.department_id),
        })),
      }),
    }),

  getStages: (id) => request(`/api/documents/${id}/stages`),

  getMyRoles: (id) => request(`/api/documents/${id}/my-roles`),
  getDashboardStats: () => request('/api/dashboard/stats'),

  // #26 — specialMarkId добавлен последним параметром: журнал фильтруется и
  // по особой отметке, как остальные списки.
  getRegistry: (kind, year, q, categoryId, specialMarkId) => {
    const p = new URLSearchParams()
    if (year) p.set('year', year)
    if (q) p.set('q', q)
    if (categoryId) p.set('category_id', categoryId)
    if (specialMarkId) p.set('special_mark_id', specialMarkId)
    const qs = p.toString()
    return request(`/api/registry/${kind}${qs ? `?${qs}` : ''}`)
  },
  downloadRegistryCsv: async (kind, year, q, categoryId, specialMarkId) => {
    const token = localStorage.getItem('sed_token')
    const p = new URLSearchParams()
    if (year) p.set('year', year)
    if (q) p.set('q', q)
    if (categoryId) p.set('category_id', categoryId)
    if (specialMarkId) p.set('special_mark_id', specialMarkId)
    const qs = p.toString()
    const res = await fetch(`${API_URL}/api/registry/${kind}/export${qs ? `?${qs}` : ''}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) throw new Error(`Ошибка ${res.status}`)
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `registry_${kind}${year ? `_${year}` : ''}.xlsx`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  },
  getLinks: (id) => request(`/api/documents/${id}/links`),
  deleteLink: (id, linkId) => request(`/api/documents/${id}/links/${linkId}`, { method: 'DELETE' }),
  // Связь с системным документом (мультивыбор делается на фронте по одному вызову на документ).
  createLink: (id, targetDocumentId, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ target_document_id: Number(targetDocumentId), link_type: linkType }),
    }),
  // Связь-заметка на несистемный (бумажный/внешний) документ.
  createLinkNote: (id, textNote, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ text_note: textNote, link_type: linkType }),
    }),
  // Поиск системных документов для связывания (частичное совпадение, ILIKE).
  // #20 — Поиск документа для связи: по НАЗВАНИЮ или по НОМЕРУ (исх./вх.) в
  // одном поле. Раньше уходил только `q`, то есть по названию и содержанию, и
  // найти документ по входящему номеру было нельзя. Параметр `any` — это одно
  // условие «ИЛИ» на сервере; отправить ту же строку в q, number и
  // incoming_number было нельзя, они объединяются через «И».
  searchSystemDocuments: (q) =>
    request(`/api/documents/search?any=${encodeURIComponent(q)}&page=1&page_size=10`),

  getAssignments: (id) => request(`/api/documents/${id}/assignments`),
  createAssignment: (id, { assigneeId, controllerId, text, dueDate }) =>
    request(`/api/documents/${id}/assignments`, {
      method: 'POST',
      body: JSON.stringify({
        assignee_id: Number(assigneeId),
        controller_id: controllerId ? Number(controllerId) : 0,
        text,
        due_date: dueDate || '',
      }),
    }),
  updateAssignment: (id, status, resultNote) =>
    request(`/api/assignments/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status, result_note: resultNote || '' }),
    }),
  editAssignment: (id, text, dueDate) =>
    request(`/api/assignments/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ text, due_date: dueDate || '' }),
    }),
  deleteAssignment: (id) => request(`/api/assignments/${id}`, { method: 'DELETE' }),

  getNotifications: ({ onlyUnread = false, limit = 50 } = {}) =>
    request(`/api/notifications?only_unread=${onlyUnread}&limit=${limit}`),
  markNotificationRead: (id) => request(`/api/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: () => request('/api/notifications/read-all', { method: 'POST' }),
  // #2 — уведомления-будильники: требующие подтверждения и «отложить».
  getAlarmNotifications: () => request('/api/notifications/alarms'),
  snoozeNotification: (id, minutes) =>
    request(`/api/notifications/${id}/snooze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ minutes }),
    }),

  // Расширенный поиск/фильтр по ВСЕМ атрибутам документа. Любой параметр опционален.
  searchDocuments: (f = {}) => {
    const params = new URLSearchParams({ page: String(f.page || 1) })
    const set = (k, v) => { if (v !== undefined && v !== null && v !== '') params.set(k, String(v)) }
    set('category', f.category)
    set('q', f.q)
    set('author_id', f.authorId)
    set('signer_id', f.signerId)
    set('controller_id', f.controllerId)
    set('approver_id', f.approverId)
    set('recipient_id', f.recipientId)
    set('department_id', f.departmentId)
    set('status', f.status)
    set('on_control', f.onControl)
    set('number', f.number)
    set('incoming_number', f.incomingNumber)
    set('category_id', f.categoryId)
    // --- Группа D ---
    set('content', f.content)              // #4 — поиск по содержимому PDF
    set('special_mark_id', f.specialMarkId) // #26 — особая отметка
    set('participant_id', f.participantId)  // #28 — любое участие в документе
    set('signed_from', f.signedFrom)
    set('signed_to', f.signedTo)
    set('created_from', f.createdFrom)
    set('created_to', f.createdTo)
    set('due_from', f.dueFrom)
    set('due_to', f.dueTo)
    set('page_size', f.pageSize)
    return request(`/api/documents/search?${params.toString()}`)
  },
  getHistory: (id) => request(`/api/documents/${id}/history`),
  // #13 — getViews убран: просмотры входят в getCopies (first_view_at,
  // last_view_at, view_count).
  // #17 — счётчики для подписей вкладок.
  getDocumentCounts: (id) => request(`/api/documents/${id}/counts`),
  // #41 — количество документов по категориям бокового меню.
  getCategoryCounts: () => request('/api/documents/category-counts'),
  // #10 — метрики состояния системы для админ-дашборда.
  getAdminMetrics: () => request('/api/admin/metrics'),

  // --- Группа D: поиск и фильтры ------------------------------------------
  // #28 — люди для фильтров: без ограничения иерархией, включая уволенных.
  getFilterPeople: ({ role, q, limit = 20 } = {}) => {
    const params = new URLSearchParams({ limit: String(limit) })
    if (role) params.set('role', role)
    if (q) params.set('q', q)
    return request(`/api/users/filter-candidates?${params.toString()}`)
  },
  // #26 — справочник особых отметок.
  getSpecialMarks: () => request('/api/special-marks'),
  createSpecialMark: (body) =>
    request('/api/admin/special-marks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  updateSpecialMark: (id, body) =>
    request(`/api/admin/special-marks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  deleteSpecialMark: (id) => request(`/api/admin/special-marks/${id}`, { method: 'DELETE' }),
  // #4 — прогресс фоновой индексации содержимого PDF (для прелоадера).
  getSearchIndexStatus: () => request('/api/search/index-status'),
  // #3 — личные настройки интерфейса на сервере (состояние фильтров).
  getPreference: (key) => request(`/api/preferences/${encodeURIComponent(key)}`),
  savePreference: (key, value) =>
    request(`/api/preferences/${encodeURIComponent(key)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(value),
    }),
  deletePreference: (key) => request(`/api/preferences/${encodeURIComponent(key)}`, { method: 'DELETE' }),
  getRecipients: (id) => request(`/api/documents/${id}/recipients`),
  deleteRecipient: (id, recipientId) => request(`/api/documents/${id}/recipients/${recipientId}`, { method: 'DELETE' }),
  // Пакетные счётчики адресатов для страницы списка (без N+1).
  recipientsCounts: (ids = []) =>
    ids.length ? request(`/api/recipients-counts?ids=${ids.join(',')}`) : Promise.resolve({ counts: {} }),
  // Ознакомление.
  getAcquaintances: (id) => request(`/api/documents/${id}/acquaintances`),
  acquaintCandidates: (q = '', documentId) =>
    request(`/api/acquaint-candidates?q=${encodeURIComponent(q)}${documentId ? `&document_id=${documentId}` : ''}`),
  acquaint: (id, userIds = []) =>
    request(`/api/documents/${id}/acquaint`, {
      method: 'POST',
      body: JSON.stringify({ user_ids: userIds.map(Number) }),
    }),
  completeDocument: (id, note) =>
    request(`/api/documents/${id}/complete`, { method: 'POST', body: JSON.stringify({ note }) }),
  updateDocument: (id, patch) =>
    request(`/api/documents/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),

  // Замена PDF-оригинала до подписи (multipart). Сбрасывает согласование.
  replaceDocumentFile: async (id, file) => {
    const token = getToken()
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch(`${API_URL}/api/documents/${id}/file`, {
      method: 'PATCH',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: fd,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) message = b.error } catch (_) { /* noop */ }
      throw new Error(message)
    }
    return true
  },
  deleteDocument: (id) => request(`/api/documents/${id}`, { method: 'DELETE' }),
  updateRoute: (id, route) =>
    request(`/api/documents/${id}/route`, { method: 'PATCH', body: JSON.stringify(route) }),
  updateSigners: (id, signerIds) =>
    request(`/api/documents/${id}/signers`, { method: 'PUT', body: JSON.stringify({ signer_ids: signerIds }) }),
  updatePlannedRecipients: (id, recipients) =>
    request(`/api/documents/${id}/planned-recipients`, {
      method: 'PATCH',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({ user_id: Number(r.id), department_id: Number(r.department_id) })),
      }),
    }),
  // #4 — контролёров может быть несколько. Принимаем массив id или один id.
  setControl: (id, onControl, controllers) => {
    const arr = Array.isArray(controllers)
      ? controllers.map(Number).filter(Boolean)
      : (controllers ? [Number(controllers)] : [])
    return request(`/api/documents/${id}/control`, {
      method: 'POST',
      body: JSON.stringify({ on_control: onControl, controller_ids: arr }),
    })
  },
  getDocumentControllers: (id) => request(`/api/documents/${id}/controllers`),
  getDocumentSignatures: (id) => request(`/api/documents/${id}/signatures`),
  getDefaultControllers: () => request('/api/default-controllers'),
  archiveDocument: (id) => request(`/api/documents/${id}/archive`, { method: 'POST' }),

  // Файл отдаётся только через авторизованный запрос (Authorization header),
  // не по прямой ссылке с токеном в query — иначе токен утекает в логи
  // прокси/браузера. Компонент вьювера сам создаёт object URL из blob.
  getDocumentFileBlob: (id) => request(`/api/documents/${id}/file`),

  decideStage: (documentId, stageId, approve, comment, extra) =>
    request(`/api/documents/${documentId}/stages/${stageId}/decide`, {
      method: 'POST',
      body: JSON.stringify({ approve, comment, ...(extra || {}) }),
    }),

  // Обсуждение документа.
  getChatHistory: (id) => request(`/api/documents/${id}/chat`),
  postChatMessage: async (id, text, files = []) => {
    const fd = new FormData()
    fd.append('text', text || '')
    for (const f of files) fd.append('files', f)
    const token = getToken()
    const res = await fetch(`${API_URL}/api/documents/${id}/chat`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: fd,
    })
    if (!res.ok) {
      let m = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) m = b.error } catch (_) { /* noop */ }
      throw new Error(m)
    }
    return res.json()
  },
  downloadChatAttachment: async (aid, fileName) => {
    const token = getToken()
    const res = await fetch(`${API_URL}/api/chat/attachments/${aid}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) throw new Error('Не удалось скачать вложение')
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = fileName || 'attachment'
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  },
  editChatMessage: (mid, text) =>
    request(`/api/chat/messages/${mid}`, { method: 'PATCH', body: JSON.stringify({ text }) }),
  deleteChatMessage: (mid) => request(`/api/chat/messages/${mid}`, { method: 'DELETE' }),

  wsURL: (documentId) => {
    const token = getToken()
    return `${wsBase()}/ws/documents/${documentId}/chat?token=${encodeURIComponent(token || '')}`
  },

  wsNotificationsURL: () => {
    const token = getToken()
    return `${wsBase()}/ws/notifications?token=${encodeURIComponent(token || '')}`
  },

  // --- Администрирование (только для роли admin; сервер проверяет права) ---
  adminListDepartments: () => request('/api/admin/departments'),
  adminCreateDepartment: (body) => request('/api/admin/departments', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateDepartment: (id, body) => request(`/api/admin/departments/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminMoveDepartment: (id, parentId) => request(`/api/admin/departments/${id}/parent`, { method: 'PATCH', body: JSON.stringify({ parent_id: parentId }) }),
  adminDeleteDepartment: (id) => request(`/api/admin/departments/${id}`, { method: 'DELETE' }),
  adminListUsers: () => request('/api/admin/users'),
  adminCreateUser: (body) => request('/api/admin/users', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateUser: (id, body) => request(`/api/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminMoveUser: (id, departmentId) => request(`/api/admin/users/${id}/department`, { method: 'PATCH', body: JSON.stringify({ department_id: departmentId }) }),
  adminSetUserPassword: (id, password) => request(`/api/admin/users/${id}/password`, { method: 'PATCH', body: JSON.stringify({ password }) }),
  adminSetUserRoles: (id, departmentId, roles) => request(`/api/admin/users/${id}/roles`, { method: 'PATCH', body: JSON.stringify({ department_id: departmentId, roles }) }),
  adminSetUserDepartments: (id, sets) => request(`/api/admin/users/${id}/departments`, { method: 'PATCH', body: JSON.stringify(sets) }),

  // #4 — Группы адресатов рассылки.
  listRecipientGroups: () => request('/api/recipient-groups'),
  // #6 — категории документов
  listCategories: () => request('/api/categories'),
  adminCreateCategory: (body) => request('/api/admin/categories', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateCategory: (id, body) => request(`/api/admin/categories/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminDeleteCategory: (id) => request(`/api/admin/categories/${id}`, { method: 'DELETE' }),
  adminCreateRecipientGroup: (body) => request('/api/admin/recipient-groups', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateRecipientGroup: (id, body) => request(`/api/admin/recipient-groups/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminDeleteRecipientGroup: (id) => request(`/api/admin/recipient-groups/${id}`, { method: 'DELETE' }),
  adminSetRecipientGroupMembers: (id, members) => request(`/api/admin/recipient-groups/${id}/members`, { method: 'PUT', body: JSON.stringify({ members }) }),
}

export function setToken(token) {
  localStorage.setItem('sed_token', token)
}

export function clearToken() {
  localStorage.removeItem('sed_token')
}

export function isAuthenticated() {
  return !!getToken()
}
