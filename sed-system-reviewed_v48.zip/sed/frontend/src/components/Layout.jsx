import React, { useCallback, useEffect, useRef, useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import Icon from './Icon'
import ThemeSwitcher from './ThemeSwitcher'
import NotificationsBell from './NotificationsBell'
import AlarmNotifications from './AlarmNotifications'
import { useAuth } from '../context/AuthContext'
import { api } from '../api/client'

const CATEGORIES = [
  { id: 'all', label: 'Все документы' },
  { id: 'awaiting', label: 'Ожидают регистрации' },
  { id: 'outgoing', label: 'Исходящие' },
  { id: 'incoming', label: 'Входящие' },
  { id: 'on_approval', label: 'На согласовании' },
  { id: 'on_signing', label: 'На подписи' },
  { id: 'control', label: 'На контроле' },
  { id: 'print_unregistered', label: 'На регистрацию' },
  { id: 'executed', label: 'Исполнено' },
  { id: 'archive', label: 'Архив', noCount: true },
]

export default function Layout() {
  const { login, doLogout, canCreate, fullName, position, isAdmin } = useAuth()
  const navigate = useNavigate()
  const [brand, setBrand] = useState({ app_name: 'SED', tagline: '// доведение указаний', copyright: '', about: '' })
  const [showAbout, setShowAbout] = useState(false)
  // #19 — выпадающее меню профиля
  const [userMenu, setUserMenu] = useState(false)
  const userMenuRef = useRef(null)
  // #41 — количество документов по категориям
  const [counts, setCounts] = useState({})
  // #42 — свёрнутое боковое меню («гамбургер»). Запоминаем выбор: если
  // пользователь работает на небольшом экране, он свернул меню один раз и не
  // должен делать это при каждом входе. localStorage может быть недоступен
  // (приватный режим, запрет на данные сайта), поэтому в try/catch.
  const [navCollapsed, setNavCollapsed] = useState(() => {
    try {
      return localStorage.getItem('sed_nav_collapsed') === '1'
    } catch (_) {
      return false
    }
  })
  const toggleNav = () => {
    setNavCollapsed((v) => {
      const next = !v
      try {
        localStorage.setItem('sed_nav_collapsed', next ? '1' : '0')
      } catch (_) {
        /* не критично: просто не запомнится между сессиями */
      }
      return next
    })
  }

  useEffect(() => {
    api.getAppConfig().then(setBrand).catch(() => {})
  }, [])

  // #41 — Счётчики документов по категориям.
  //
  // Требование: числа должны обновляться САМИ, а не только при клике на
  // раздел, чтобы было видно появление новых входящих и реагировать на них.
  // Поэтому три источника обновления:
  //   1) при входе;
  //   2) по приходу уведомления (событие 'sed:notification' рассылает колокол,
  //      который держит WebSocket) — это мгновенная реакция на реальное
  //      изменение, без опроса;
  //   3) периодический опрос раз в 60 с — страховка на случай обрыва WS и на
  //      изменения, по которым уведомление не приходит (например, коллега
  //      зарегистрировал входящий).
  // Плюс обновление при возврате на вкладку браузера: пока вкладка скрыта,
  // опрашивать сервер незачем — это тысячи бесполезных запросов при 1000
  // пользователей с открытой, но неактивной вкладкой.
  const loadCounts = useCallback(() => {
    if (typeof document !== 'undefined' && document.hidden) return
    api.getCategoryCounts().then((r) => setCounts(r.counts || {})).catch(() => {})
  }, [])

  useEffect(() => {
    loadCounts()
    const timer = setInterval(loadCounts, 60000)
    window.addEventListener('sed:notification', loadCounts)
    window.addEventListener('focus', loadCounts)
    document.addEventListener('visibilitychange', loadCounts)
    return () => {
      clearInterval(timer)
      window.removeEventListener('sed:notification', loadCounts)
      window.removeEventListener('focus', loadCounts)
      document.removeEventListener('visibilitychange', loadCounts)
    }
  }, [loadCounts])

  // Закрытие меню профиля по клику вне него.
  useEffect(() => {
    function onDown(e) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) setUserMenu(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [])

  return (
    <div className="min-h-screen flex bg-bg text-text-primary font-body">
      {/* #42 — Сворачиваемое боковое меню. В свёрнутом виде оно убирается
          полностью (а не превращается в полоску с иконками): пункты здесь
          текстовые, и узкая полоска с обрезанными подписями была бы хуже, чем
          её отсутствие. Рабочая зона при этом занимает всю ширину. */}
      <aside
        className={`${
          navCollapsed ? 'w-0 overflow-hidden border-r-0' : 'w-60 border-r'
        } shrink-0 border-border bg-surface flex flex-col h-screen sticky top-0 transition-[width] duration-150`}
      >
        <div className="px-4 py-4 border-b border-border shrink-0">
          <div className="font-display font-semibold text-lg tracking-tight">{brand.app_name}</div>
          <div className="kicker">{brand.tagline}</div>
        </div>
        <nav className="flex-1 py-2 overflow-y-auto">
          {canCreate && (
            <NavLink
              to="/document/new"
              className="glow-accent block mx-2 mb-3 px-4 py-2 text-sm rounded-md bg-accent text-accent-contrast text-center font-semibold"
            >
              + Новый документ
            </NavLink>
          )}
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                isActive ? 'nav-active' : 'hover:bg-surface-alt text-text-primary'
              }`
            }
          >
            Дашборд
          </NavLink>
          {CATEGORIES.map((cat) => {
            // #41 — Счётчик у каждой категории, кроме архива: он растёт
            // неограниченно, и его количество ни о чём не говорит (журналы
            // сюда не входят — они ниже отдельной ссылкой).
            const n = cat.noCount ? undefined : counts[cat.id]
            return (
            <NavLink
              key={cat.id}
              to={`/documents/${cat.id}`}
              className={({ isActive }) =>
                `flex items-center gap-2 px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                  isActive ? 'nav-active' : 'hover:bg-surface-alt text-text-primary'
                }`
              }
            >
              <span className="flex-1 truncate">{cat.label}</span>
              {n > 0 && (
                <span className="shrink-0 min-w-5 px-1.5 text-[11px] leading-5 text-center rounded-full bg-surface-alt text-text-secondary">
                  {n > 999 ? '999+' : n}
                </span>
              )}
            </NavLink>
          )})}
          {/* Журналы — в самом низу навигации, после архива. */}
          <NavLink
            to="/registry/outgoing"
            className={({ isActive }) =>
              `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-2 border-t border-border pt-3 ${
                isActive ? 'nav-active' : 'hover:bg-surface-alt text-text-primary'
              }`
            }
          >
            Журналы
          </NavLink>

          {isAdmin && (
            <>
              <NavLink
                to="/admin"
                className={({ isActive }) =>
                  `block px-4 py-2 text-sm rounded-md mx-2 mb-1 mt-1 ${
                    isActive ? 'nav-active' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                Администрирование
              </NavLink>
              {/* #10 — техническое состояние системы: метрики, очередь
                  индексации, пул БД. Отдельно от админки, т.к. это не
                  управление справочниками, а наблюдение за системой. */}
              <NavLink
                to="/admin/metrics"
                className={({ isActive }) =>
                  `block px-4 py-2 text-sm rounded-md mx-2 mb-1 ${
                    isActive ? 'nav-active' : 'hover:bg-surface-alt text-text-primary'
                  }`
                }
              >
                Состояние системы
              </NavLink>
            </>
          )}
        </nav>
        {/* #19 — Блок пользователя (ФИО, должность, логин, «Выйти») переехал в
            выпадающее меню в правом верхнем углу. Здесь в подвале бокового
            меню остаётся только «©» со справкой о системе: место внизу
            сайдбара нужно под навигацию, а профиль по привычке ищут справху
            справа, рядом с колоколом и темой. */}
        <div className="px-4 py-3 border-t border-border shrink-0">
          <button
            className="text-[11px] text-text-secondary opacity-70 leading-snug text-left hover:opacity-100 hover:text-accent w-full"
            onClick={() => setShowAbout(true)}
            title="Справочная информация"
          >
            © {brand.copyright || brand.app_name}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border bg-surface flex items-center px-4 gap-3 sticky top-0 z-10">
          {/* #42 — «гамбургер»: скрыть/показать боковое меню */}
          <button
            onClick={toggleNav}
            className="px-2 py-1.5 rounded-md hover:bg-surface-alt"
            title={navCollapsed ? 'Показать меню' : 'Скрыть меню'}
            aria-label={navCollapsed ? 'Показать меню' : 'Скрыть меню'}
            aria-expanded={!navCollapsed}
          >
            <Icon name="menu" size={18} />
          </button>
          {/* В свёрнутом состоянии название системы уезжает вместе с меню,
              поэтому показываем его здесь — иначе непонятно, где находишься. */}
          {navCollapsed && (
            <span className="font-display font-semibold tracking-tight">{brand.app_name}</span>
          )}
          <div className="flex-1" />
          <NotificationsBell />
          <ThemeSwitcher />
          {/* #19 — профиль пользователя: выпадающее меню справа сверху */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenu((v) => !v)}
              className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-surface-alt max-w-56"
              title={fullName || login}
            >
              <Icon name="user" size={18} />
              <span className="text-sm truncate">{fullName || login}</span>
              <Icon name="chevron-down" size={14} />
            </button>
            {userMenu && (
              <div className="absolute right-0 mt-1 w-64 surface-1 shadow-lg z-30">
                <div className="px-3 py-2 border-b border-border">
                  <div className="text-sm font-medium truncate" title={fullName || login}>
                    {fullName || login}
                  </div>
                  {position && (
                    <div className="text-xs text-text-secondary truncate" title={position}>
                      {position}
                    </div>
                  )}
                  <div className="text-[11px] text-text-secondary opacity-70 mt-0.5">{login}</div>
                </div>
                <button
                  className="w-full text-left px-3 py-2 text-sm hover:bg-surface-alt"
                  onClick={() => {
                    setUserMenu(false)
                    setShowAbout(true)
                  }}
                >
                  О системе
                </button>
                <button
                  className="w-full text-left px-3 py-2 text-sm text-danger hover:bg-surface-alt border-t border-border"
                  onClick={() => {
                    doLogout()
                    navigate('/login')
                  }}
                >
                  Выйти
                </button>
              </div>
            )}
          </div>
        </header>
        <main className="flex-1 min-w-0">
          <Outlet />
        </main>
      </div>

      {showAbout && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAbout(false)}>
          <div className="surface-1 w-full max-w-2xl max-h-[85vh] overflow-auto shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-3 border-b border-border sticky top-0 bg-surface">
              <h2 className="font-display text-lg font-semibold">О системе {brand.app_name}</h2>
              <button onClick={() => setShowAbout(false)} className="text-text-secondary text-2xl leading-none hover:text-text-primary">×</button>
            </div>
            <div className="p-5 text-sm text-text-primary whitespace-pre-wrap leading-relaxed">
              {brand.about || 'Справочная информация не задана (branding.about в конфиге).'}
            </div>
            <div className="px-5 pb-4 text-xs text-text-secondary">© {brand.copyright || brand.app_name}</div>
          </div>
        </div>
      )}

      {/* #2 — Блокирующее окно уведомлений, которые нельзя пропустить.
          Монтируется в Layout, а не на отдельной странице: будильник должен
          срабатывать в любом разделе системы. Само окно рисуется только когда
          есть что показать. */}
      <AlarmNotifications />
    </div>
  )
}
