import React, { useState, useEffect, useCallback, useRef } from 'react'
import Icon from './Icon'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import PersonPicker from './PersonPicker'
import SendPanel from './SendPanel'
import { fmtDateTime } from '../utils/format'

const COPY_REASON_LABELS = {
  author: 'Автор (оригинал)',
  approver_hierarchy: 'Согласование',
  approver_cross_dept: 'Согласование',
  approval_stage: 'Согласование/подпись',
  signer: 'Подпись',
  recipient: 'Получатель',
  executor: 'Исполнитель',
  acquaintance: 'Ознакомление',
  chief_of_dept: 'Руководитель подразделения',
  controller: 'Контролёр',
  clerk: 'Канцелярия',
  view: 'Просмотр',
}
const LINK_TYPE_LABELS = {
  related: 'Связанный',
  reply_to: 'В ответ на',
  annuls: 'Отменяет',
  appendix: 'Приложение',
  in_addition: 'В дополнение',
  in_pursuance_of: 'Во исполнение', // легаси-значение (для отображения старых связей)
}

// Типы связи, доступные при СОЗДАНИИ (порядок как в требовании).
const LINK_TYPE_OPTIONS = [
  ['related', 'Связанный'],
  ['reply_to', 'В ответ на'],
  ['annuls', 'Отменяет'],
  ['appendix', 'Приложение'],
  ['in_addition', 'В дополнение'],
]

const STATUS_LABELS = {
  created: 'Создан',
  edited: 'Изменён',
  file_replaced: 'Заменён файл документа',
  stage_approved: 'Согласовано',
  stage_rejected: 'Отклонено',
  approved: 'Согласовано',
  rejected: 'Отклонено',
  signed: 'Подписано',
  sent: 'Разослано',
  document_sent: 'Разослано',
  approver_added: 'Направлено на доп. согласование',
  resent: 'Донаправлено',
  recipient_removed: 'Удалён адресат',
  route_restarted: 'Согласование начато заново',
  route_changed: 'Изменён маршрут согласования',
  status_changed: 'Смена статуса',
  received: 'Получено',
  completed: 'Исполнено',
  executed: 'Исполнено',
  execution_marked: 'Отметка об исполнении',
  incoming_registered: 'Присвоен входящий номер',
  put_on_control: 'Поставлен на контроль',
  removed_from_control: 'Снят с контроля',
  control_assigned: 'Назначен контролёр',
  assignment_created: 'Дано поручение',
  assignment: 'Дано поручение',
  assignment_completed: 'Поручение исполнено',
  assignment_status_changed: 'Изменён статус поручения',
  acquainted: 'Ознакомление',
  acquaintance: 'Ознакомление',
  archived: 'Передан в архив',
}

// Технологические события маршрута/служебные — пользователю не показываем
// (они шумят и не несут смысла для человека). Показываем только значимые.
// Скрываем только ТЕХНИЧЕСКИЕ события (перестроение маршрута, выдача/отзыв
// доступа). #33 — отметка об исполнении и факт исполнения документа являются
// значимыми событиями и теперь показываются в истории.
const ASSIGNMENT_STATUS_LABELS = { open: 'Новое', in_progress: 'В работе', done: 'Выполнено', cancelled: 'Отменено' }

const HIDDEN_HISTORY_EVENTS = new Set(['route_rebuilt', 'access_granted', 'access_revoked', 'route_restart'])

function fmt(dt) {
  if (!dt) return ''
  try { return fmtDateTime(dt) } catch { return dt }
}

// Вкладки карточки документа: Маршрут | История | Просмотры | Рассылка.
// Рассылка включает кнопку "Отметить исполнение" для текущего получателя.
export default function DocumentTabs({
  documentId,
  currentUserId,
  routeSlot,
  decisionSlot, // #15 — блок решения (согласовать/подписать) отдельной вкладкой
  chatSlot, // #38 — обсуждение отдельной вкладкой
  onChanged,
  docStatus,
  doc,
  patchDoc,
  tab: tabProp, // #40 — активная вкладка снаружи (хранится в адресе страницы)
  onTabChange,
}) {
  // #40 — Вкладка управляется СНАРУЖИ, если переданы tab/onTabChange: тогда
  // она лежит в адресе страницы и не теряется ни при обновлении данных, ни при
  // настоящей перезагрузке. Внутреннее состояние остаётся запасным вариантом,
  // чтобы компонент можно было использовать и без внешнего управления.
  const [tabState, setTabState] = useState('route')
  const controlled = typeof onTabChange === 'function'
  const tab = (controlled ? tabProp : tabState) || 'route'
  const setTab = controlled ? onTabChange : setTabState
  const [counts, setCounts] = useState(null) // #17 — числа в подписях вкладок
  const [stages, setStages] = useState(null) // нужны, чтобы знать, ждут ли решения
  const [roles, setRoles] = useState(null)
  const [history, setHistory] = useState(null)
  const [sigs, setSigs] = useState(null) // #8 — данные о подписи (63-ФЗ)
  const [recipients, setRecipients] = useState(null)
  const [copies, setCopies] = useState(null)
  const [prints, setPrints] = useState(null)
  const [regForm, setRegForm] = useState({})
  const [links, setLinks] = useState(null)
  const [linkMode, setLinkMode] = useState('system') // 'system' | 'external'
  const [linkDocs, setLinkDocs] = useState([]) // мультивыбор системных документов
  const [linkSearch, setLinkSearch] = useState('')
  const [linkSearchResults, setLinkSearchResults] = useState([])
  const [linkNote, setLinkNote] = useState('') // текст для несистемного документа
  const [linkType, setLinkType] = useState('related')
  const [assignments, setAssignments] = useState(null)
  const [asgAssignees, setAsgAssignees] = useState([]) // мультивыбор ответственных
  const [asgText, setAsgText] = useState('')
  const [asgDue, setAsgDue] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [printDiag, setPrintDiag] = useState(null) // #11 — результат проверки готовности к печати
  const [execModal, setExecModal] = useState(false) // #10 — модалка отметки исполнения
  const [error, setError] = useState('')

  const loadTab = useCallback(async (t) => {
    setError('')
    try {
      if (t === 'history' && !history) setHistory((await api.getHistory(documentId)).items || [])
      if (t === 'history' && sigs === null) setSigs((await api.getDocumentSignatures(documentId)).items || [])
      if (t === 'copies' && !copies) setCopies((await api.getCopies(documentId)).items || [])
      if (t === 'prints') setPrints((await api.getPrints(documentId)).items || [])
      if (t === 'recipients') setRecipients((await api.getRecipients(documentId)).items || [])
      if (t === 'links') setLinks((await api.getLinks(documentId)).items || [])
      if (t === 'assignments') setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    }
  }, [documentId, history, sigs])


  useEffect(() => {
    api.getMyRoles(documentId).then(setRoles).catch(() => setRoles(null))
    // Получателей грузим сразу: от них зависит доступность вкладок «Рассылка»
    // и «Ознакомление» (canAcquaint = я получатель).
    api.getRecipients(documentId).then((r) => setRecipients(r.items || [])).catch(() => {})
    // #17 — счётчики: один дешёвый запрос вместо загрузки всех вкладок.
    api.getDocumentCounts(documentId).then(setCounts).catch(() => setCounts(null))
    // #15 — этапы нужны ЗДЕСЬ, чтобы решить, показывать ли вкладку решения и
    // открывать ли её сразу. ApprovalPanel грузит их для себя сам, но он
    // смонтирован только когда его вкладка активна.
    api.getStages(documentId).then((r) => setStages(r.items || [])).catch(() => setStages([]))
  }, [documentId])

  // #15 — от пользователя ждут решения: его этап согласования/подписи активен.
  const myPendingStage = (stages || []).find(
    (s) => s.status === 'pending' && s.approver_id === currentUserId
  )
  const needsMyDecision = !!myPendingStage
  const myDecisionLabel = myPendingStage?.stage_type === 'signing' ? '● Подписать' : '● Согласовать'

  // Если решения ждут — открываем вкладку решения, иначе маршрут. Делаем это
  // один раз, после загрузки этапов, и только пока пользователь сам не
  // переключил вкладку (иначе мы бы перебивали его выбор).
  const autoTabDoneRef = useRef(false)
  // Если вкладка задана в адресе явно (?tab=...), автовыбор не применяем:
  // пользователь уже сказал, что хочет открыть, в том числе перезагрузкой
  // страницы или ссылкой от коллеги (#40).
  const hasExplicitTab = controlled && !!tabProp
  useEffect(() => {
    if (stages === null || autoTabDoneRef.current) return
    autoTabDoneRef.current = true
    if (hasExplicitTab) return
    if (stages.some((s) => s.status === 'pending' && s.approver_id === currentUserId)) {
      setTab('decision')
    }
    // setTab в управляемом режиме меняет идентичность на каждый рендер, но
    // повторный запуск исключён флагом autoTabDoneRef.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stages, currentUserId, hasExplicitTab])

  async function markComplete() {
    setBusy(true); setError('')
    try {
      await api.completeDocument(documentId, note)
      setNote('')
      setExecModal(false)
      setRecipients((await api.getRecipients(documentId)).items || [])
      onChanged?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const myRecipient = recipients?.find((r) => r.user_id === currentUserId)

  // Участие пользователя определяет, какие вкладки показывать. Базовые
  // (маршрут/история/просмотры/связанные) видят все с доступом к документу.
  // Рассылка и поручения — только участникам (автор, подписант, получатель,
  // контролёр), чтобы не показывать посторонним лишние управляющие вкладки.
  // Роли берём из /my-roles (надёжный источник). Пока не загрузились —
  // показываем базовые вкладки. Рассылка/поручения — только участникам.
  const isParticipant = roles
    ? roles.is_author || roles.is_controller || roles.is_signer || roles.is_approver || roles.is_recipient || roles.is_admin
    : false
  const isApprovalParticipant = roles
    ? roles.is_author || roles.is_approver || roles.is_signer || roles.is_admin
    : true

  // Права управления: связи и направление — только автор/подписант.
  const canManage = !!(roles && (roles.is_author || roles.is_signer || roles.is_admin))
  const canRedirect = !!(roles && roles.can_redirect) // #7 — дежурный донаправляет
  const canSend = (canManage || canRedirect) && ['signed', 'sent', 'in_progress', 'executed'].includes(docStatus)
  // #6/#7 — Ознакомление и поручения доступны ПО ПРАВАМ (не по факту рассылки):
  // canAcquaint/canAssign приходят из /my-roles. Показываем вкладки любому, у
  // кого есть доступ к документу и соответствующее право (даже если он просто
  // ознакомлен). Конкретный список кандидатов ограничивает бэкенд.
  const canAcquaint = !!(roles && roles.can_acquaint)
  const canAssign = !!(roles && roles.can_assign)
  const isAssignee = !!(roles && roles.is_assignee) // #1 — исполнитель видит поручения
  // #10 — отметить исполнение вправе получатель, ещё не отметивший свою часть.
  const canExecute = !!(myRecipient && !myRecipient.completed_at)

  // Порядок вкладок (#15, #38, #39):
  //   * #15 — «Согласование/Подпись» вынесено в ПЕРВУЮ отдельную вкладку:
  //     решение по документу — главное действие, за которым сюда приходят, а
  //     кнопки были спрятаны внутри вкладки «Маршрут» ниже схемы маршрута.
  //     Вкладка показывается только тому, от кого сейчас ждут решения.
  //   * #38 — «Обсуждение» стало отдельной вкладкой (раньше переписка висела
  //     сбоку от карточки и на узких экранах уезжала вниз).
  //   * #39 — «История» ушла последней: это архивная справка, а не рабочая
  //     вкладка, и она занимала второе место.
  //   * #13 — вкладки «Просмотры» больше нет, её данные в «Экземплярах».
  //
  // #17 — в подписях вкладок стоят счётчики: сколько экземпляров, сообщений,
  // файлов, поручений. Раньше узнать это можно было только открыв вкладку.
  const TABS = [
    ...(needsMyDecision ? [{ id: 'decision', label: myDecisionLabel }] : []),
    ...(isApprovalParticipant ? [{ id: 'route', label: 'Маршрут' }] : []),
    ...(isParticipant ? [{ id: 'recipients', label: 'Рассылка', count: recipients?.length }] : []),
    ...(canExecute ? [{ id: 'execution', label: 'Исполнение' }] : []),
    ...(canAssign || isParticipant || isAssignee
      ? [{ id: 'assignments', label: 'Поручения', count: counts?.assignments }]
      : []),
    ...(canAcquaint ? [{ id: 'acquaint', label: 'Ознакомление' }] : []),
    { id: 'chat', label: 'Обсуждение', count: counts?.messages },
    { id: 'copies', label: 'Экземпляры', count: counts?.copies },
    { id: 'prints', label: 'Печать', count: counts?.prints },
    { id: 'links', label: 'Связанные', count: counts?.links },
    { id: 'control', label: doc?.on_control ? 'На контроле ●' : 'Контроль' },
    { id: 'history', label: 'История' },
  ]

  // #40 — Вкладка из адреса может быть недоступна этому пользователю (ссылка
  // от коллеги с другими правами, или решения от вас уже не ждут). Тогда
  // показываем первую доступную, а не пустоту. Набор вкладок зависит от
  // ролей, которые приходят асинхронно, поэтому пока TABS пуст — не трогаем.
  const activeTab = TABS.some((t) => t.id === tab) ? tab : TABS[0]?.id || tab

  // Данные вкладки грузим по ФАКТИЧЕСКИ открытой вкладке (#40).
  useEffect(() => { loadTab(activeTab) }, [activeTab, loadTab])

  // Поиск системных документов для связывания (ILIKE, частичное совпадение).
  useEffect(() => {
    if (linkMode !== 'system' || !linkSearch.trim()) { setLinkSearchResults([]); return }
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const res = await api.searchSystemDocuments(linkSearch.trim())
        if (!cancelled) setLinkSearchResults((res.items || []).filter((d) => String(d.id) !== String(documentId)))
      } catch (_) { if (!cancelled) setLinkSearchResults([]) }
    }, 300)
    return () => { cancelled = true; clearTimeout(t) }
  }, [linkSearch, linkMode, documentId])

  const pickLinkDoc = (d) => {
    if (linkDocs.some((x) => x.id === d.id)) return
    setLinkDocs([...linkDocs, { id: d.id, title: d.title, number: d.outgoing_number || `#${d.id}` }])
    setLinkSearch('')
    setLinkSearchResults([])
  }

  async function addLink() {
    setBusy(true); setError('')
    try {
      if (linkMode === 'system') {
        if (linkDocs.length === 0) return
        // Мультивыбор: одна связь на каждый выбранный системный документ.
        for (const d of linkDocs) {
          await api.createLink(documentId, d.id, linkType)
        }
        setLinkDocs([])
      } else {
        if (!linkNote.trim()) return
        await api.createLinkNote(documentId, linkNote.trim(), linkType)
        setLinkNote('')
      }
      setLinks((await api.getLinks(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function addAssignment() {
    if (asgAssignees.length === 0 || !asgText) return
    setBusy(true); setError('')
    try {
      // По одному поручению на каждого выбранного ответственного — так можно
      // раздать одно поручение сразу нескольким людям/группам.
      for (const person of asgAssignees) {
        await api.createAssignment(documentId, { assigneeId: person.id, text: asgText, dueDate: asgDue })
      }
      setAsgAssignees([]); setAsgText(''); setAsgDue('')
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const [doneModal, setDoneModal] = useState(null) // #4 — {id} выполняемого поручения
  const [doneNote, setDoneNote] = useState('')

  async function changeAssignmentStatus(id, status) {
    // #4 — «выполнено» требует обязательного комментария — через модалку.
    if (status === 'done') {
      setDoneNote('')
      setDoneModal({ id })
      return
    }
    setBusy(true); setError('')
    try {
      await api.updateAssignment(id, status)
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  async function submitDone() {
    if (!doneNote.trim()) { setError('Укажите комментарий о результате выполнения'); return }
    setBusy(true); setError('')
    try {
      await api.updateAssignment(doneModal.id, 'done', doneNote.trim())
      setDoneModal(null); setDoneNote('')
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  // #8 — редактирование/удаление поручения (нельзя после «выполнено»).
  const [editAsg, setEditAsg] = useState(null) // {id, text, due_date}
  async function submitEditAsg() {
    if (!editAsg.text.trim()) { setError('Укажите текст поручения'); return }
    setBusy(true); setError('')
    try {
      await api.editAssignment(editAsg.id, editAsg.text.trim(), editAsg.due_date || '')
      setEditAsg(null)
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  async function deleteAsg(id) {
    if (!confirm('Удалить поручение?')) return
    setBusy(true); setError('')
    try {
      await api.deleteAssignment(id)
      setAssignments((await api.getAssignments(documentId)).items || [])
    } catch (e) { setError(e.message) } finally { setBusy(false) }
  }

  return (
    <div className="surface-1 overflow-hidden flex flex-col h-full">
      <div className="flex flex-wrap border-b border-border shrink-0 gap-x-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-2.5 py-2 text-xs whitespace-nowrap ${
              activeTab === t.id ? 'border-b-2 border-accent text-text-primary' : 'text-text-secondary'
            } ${t.id === 'decision' ? 'text-warning font-medium' : ''}`}
          >
            {t.label}
            {/* #17 — количество рядом с подписью вкладки. Ноль не показываем:
                «Поручения 0» — это шум, пустая вкладка и так об этом скажет. */}
            {t.count > 0 && (
              <span className="ml-1 px-1 rounded bg-surface-alt text-[10px] text-text-secondary">
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="p-3 flex-1 min-h-0 overflow-auto">
        {error && <div className="text-danger text-xs mb-2">{error}</div>}

        {/* #15 — решение по документу: первая вкладка, открывается сразу */}
        {activeTab === 'decision' && decisionSlot}
        {activeTab === 'route' && routeSlot}
        {/* #38 — обсуждение отдельной вкладкой, во всю высоту панели */}
        {activeTab === 'chat' && <div className="h-full min-h-0">{chatSlot}</div>}
        {activeTab === 'control' && (
          <ControlTab
            documentId={documentId}
            doc={doc}
            canManage={canManage}
            patchDoc={patchDoc}
          />
        )}

        {activeTab === 'history' && (
          <ol className="space-y-1.5 text-sm">
            {(history || []).filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).map((e, i) => (
              <li key={i} className="flex justify-between border-b border-border last:border-0 pb-1.5">
                <span>
                  {STATUS_LABELS[e.event_type] || e.event_type}
                  {e.actor_name && <span className="text-text-secondary"> — {e.actor_name}</span>}
                  {e.comment && <span className="text-text-secondary"> «{e.comment}»</span>}
                </span>
                <span className="kicker whitespace-nowrap ml-2">{fmt(e.created_at)}</span>
              </li>
            ))}
            {history && history.filter((e) => !HIDDEN_HISTORY_EVENTS.has(e.event_type)).length === 0 && (
              <div className="text-text-secondary text-xs">Событий нет</div>
            )}
            {/* #8 — Данные о факте подписания (63-ФЗ) */}
            {sigs && sigs.length > 0 && (
              <li className="block pt-2">
                <div className="text-xs font-medium mb-1">Данные о подписи (Федеральный закон «Об электронной подписи» от 06.04.2011 № 63-ФЗ)</div>
                {sigs.map((s, i) => (
                  <div key={i} className="text-[11px] text-text-secondary border border-border rounded-md p-2 mb-1 space-y-0.5">
                    <div>{s.signer_fio}{s.signer_position ? `, ${s.signer_position}` : ''}</div>
                    <div>Тип: {s.signature_type} · {fmt(s.signed_at)}</div>
                    {s.signature_hash && <div className="break-all">Отпечаток подписи: {s.signature_hash}</div>}
                    {s.document_hash && <div className="break-all">Хэш документа (SHA-256): {s.document_hash}</div>}
                  </div>
                ))}
              </li>
            )}
          </ol>
        )}

        {/* #13 — вкладка «Просмотры» удалена, её данные здесь: номер
            экземпляра присваивается ровно при первом просмотре, поэтому два
            списка одних и тех же людей приходилось сопоставлять глазами. */}
        {activeTab === 'copies' && (
          <div>
            <div className="text-text-secondary text-xs mb-2">
              Экземпляры документа: №1 — у автора (оригинал), далее по порядку получения
              (согласование, подпись, получатели, ознакомленные). Для каждого экземпляра
              показан первый и последний просмотр и их количество.
            </div>
            <ol className="space-y-1.5 text-sm">
              {(copies || []).map((c) => (
                <li key={c.copy_number} className="border-b border-border last:border-0 pb-1.5">
                  <div className="flex items-center justify-between">
                    <span>
                      <span className="kicker mr-2">Экз. № {c.copy_number}</span>
                      {c.full_name}
                      <span className="text-text-secondary"> · {COPY_REASON_LABELS[c.reason] || c.reason}</span>
                    </span>
                    <span className="kicker whitespace-nowrap ml-2">{fmt(c.assigned_at)}</span>
                  </div>
                  <div className="text-[11px] text-text-secondary mt-0.5">
                    {c.view_count > 0 ? (
                      <>
                        Просмотров: {c.view_count} · первый {fmt(c.first_view_at)}
                        {c.view_count > 1 && <> · последний {fmt(c.last_view_at)}</>}
                      </>
                    ) : (
                      'Ещё не открывал документ'
                    )}
                  </div>
                </li>
              ))}
              {copies && copies.length === 0 && <div className="text-text-secondary text-xs">Экземпляры ещё не выданы</div>}
            </ol>
          </div>
        )}

        {activeTab === 'prints' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="text-text-secondary text-xs max-w-[70%]">
                Скачивание «на печать» доступно только с ролью «Печать» и выдаёт ТОЛЬКО маркированный PDF.
                После печати обязательно зарегистрируйте экземпляр в бумажном журнале (за других ставить нельзя).
              </div>
              {roles?.is_printer && (
                <div className="flex items-center gap-2">
                  <button
                    className="btn btn-primary font-medium whitespace-nowrap"
                    onClick={async () => {
                      setPrintDiag(null)
                      try { await api.downloadPrint(documentId); setPrints((await api.getPrints(documentId)).items || []) }
                      catch (e) {
                        setError(e.message || 'Не удалось скачать на печать')
                        // #11 — сразу показываем ТОЧНУЮ причину отказа.
                        try { setPrintDiag(await api.printDiagnostics(documentId)) } catch (_) { /* noop */ }
                      }
                    }}
                  >
                    Скачать на печать
                  </button>
                  <button
                    className="px-2 py-1.5 rounded-md border border-border text-xs whitespace-nowrap"
                    title="Проверить, почему документ не выдаётся на печать"
                    onClick={async () => {
                      setError('')
                      try { setPrintDiag(await api.printDiagnostics(documentId)) }
                      catch (e) { setError(e.message) }
                    }}
                  >
                    Проверить готовность
                  </button>
                </div>
              )}
            </div>
            {printDiag && (
              <div className="mb-3 border border-border rounded-md p-3 text-xs">
                <div className="font-medium mb-1">
                  {printDiag.ready_for_print
                    ? 'Документ готов к выдаче на печать'
                    : 'Документ НЕ готов к выдаче на печать — причины ниже'}
                </div>
                <ul className="space-y-0.5">
                  {(printDiag.checks || []).map((ch, i) => (
                    <li key={i} className={ch.ok ? 'text-success' : 'text-danger'}>
                      {ch.ok ? '✓' : '✗'} {ch.name}{ch.info ? `: ${ch.info}` : ''}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <ul className="space-y-2 text-sm">
              {(prints || []).map((p) => {
                const mine = p.user_id === currentUserId
                const f = regForm[p.id] || { reg_journal: '', reg_number: '' }
                return (
                  <li key={p.id} className="border border-border rounded-md p-2">
                    <div className="flex items-center justify-between">
                      <span>
                        <span className="kicker mr-2">Экз. № {p.instance_number || '—'} · Копия № {p.copy_number}</span>
                        {p.full_name}
                      </span>
                      <span className="kicker">скачано {fmt(p.printed_at)}</span>
                    </div>
                    {p.reg_at ? (
                      <div className="mt-1 flex items-center gap-2 flex-wrap">
                        <span className="text-success text-xs">
                          Зарегистрировано: журнал «{p.reg_journal}», № {p.reg_number}, {fmt(p.reg_at)} · {p.registrant_fio}
                        </span>
                        {mine && (
                          <button className="px-2 py-0.5 rounded border border-border text-xs"
                            onClick={() => setRegForm((s) => ({ ...s, [p.id]: { reg_journal: p.reg_journal || '', reg_number: p.reg_number || '', edit: true } }))}>
                            Изменить
                          </button>
                        )}
                      </div>
                    ) : null}
                    {mine && (!p.reg_at || (regForm[p.id] && regForm[p.id].edit)) ? (
                      <div className="mt-2 flex flex-wrap gap-2 items-end">
                        <input className="px-2 py-1 rounded border border-border bg-surface-alt text-xs" placeholder="Журнал"
                          value={f.reg_journal} onChange={(e) => setRegForm((s) => ({ ...s, [p.id]: { ...f, reg_journal: e.target.value } }))} />
                        <input className="px-2 py-1 rounded border border-border bg-surface-alt text-xs" placeholder="Рег. №"
                          value={f.reg_number} onChange={(e) => setRegForm((s) => ({ ...s, [p.id]: { ...f, reg_number: e.target.value } }))} />
                        <button className="px-2 py-1 rounded-md border border-accent text-accent text-xs"
                          disabled={!f.reg_journal || !f.reg_number}
                          onClick={async () => {
                            try { await api.registerPrint(documentId, p.id, { reg_journal: f.reg_journal, reg_number: f.reg_number }); setRegForm((s) => ({ ...s, [p.id]: undefined })); setPrints((await api.getPrints(documentId)).items || []) }
                            catch (e) { setError(e.message || 'Не удалось сохранить отметку') }
                          }}>
                          {p.reg_at ? 'Сохранить изменения' : 'Отметить регистрацию'}
                        </button>
                      </div>
                    ) : (!p.reg_at && !mine) ? (
                      <div className="text-warning text-xs mt-1">Не зарегистрировано (регистрирует только тот, кто скачал)</div>
                    ) : null}
                  </li>
                )
              })}
              {prints && prints.length === 0 && <div className="text-text-secondary text-xs">Документ ещё не скачивали на печать</div>}
            </ul>
          </div>
        )}

        {activeTab === 'recipients' && (
          <div>
            <ul className="space-y-1.5 text-sm mb-3">
              {(recipients || []).map((r) => (
                <li key={r.user_id} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  <span>
                    {r.full_name}
                    {r.department_name && <span className="text-text-secondary"> · {r.department_name}</span>}
                    {r.incoming_number && <span className="kicker ml-1">{r.incoming_number}</span>}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className={r.completed_at ? 'text-success text-xs' : 'text-text-secondary text-xs'}>
                      {r.completed_at ? `исполнено ${fmt(r.completed_at)}` : (r.viewed ? 'просмотрено' : 'ожидает')}
                    </span>
                    {canSend && !r.viewed && !r.completed_at && (
                      <button
                        title="Удалить получателя (пока не просмотрел)"
                        className="text-danger hover:text-danger/80 text-sm px-1"
                        onClick={async () => {
                          if (!confirm(`Удалить получателя «${r.full_name}»?`)) return
                          try { await api.deleteRecipient(documentId, r.id); setRecipients((await api.getRecipients(documentId)).items || []) }
                          catch (e) { alert(e.message || 'Не удалось удалить получателя') }
                        }}
                      >
                        <Icon name="close" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
              {recipients && recipients.length === 0 && (
                <div className="text-text-secondary text-xs">Документ ещё не направлен</div>
              )}
            </ul>

            {/* Направление рассылке — автор/подписант, во вкладке «Рассылка»,
                с учётом уже показанных выше адресатов. */}
            {canSend && (
              <div className="border-t border-border pt-3 mb-3">
                <SendPanel
                  documentId={documentId}
                  plannedHint={docStatus === 'signed'}
                  excludeIds={(recipients || []).map((r) => r.user_id)}
                  onSent={async () => {
                    setRecipients((await api.getRecipients(documentId)).items || [])
                    onChanged?.()
                  }}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === 'execution' && canExecute && (
          <div>
            <p className="text-sm mb-3">
              Отметьте исполнение своей части документа. Отметка фиксируется в истории и учитывается
              в статусе исполнения.
            </p>
            <button
              onClick={() => { setNote(''); setExecModal(true) }}
              className="px-4 py-2 rounded-md bg-success text-white text-sm font-medium"
            >
              Отметить исполненным
            </button>
          </div>
        )}
        {activeTab === 'execution' && !canExecute && (
          <div className="text-sm text-text-secondary">
            {myRecipient?.completed_at ? 'Ваша часть уже отмечена как исполненная.' : 'Отметка об исполнении недоступна.'}
          </div>
        )}

        {/* #10 — модальное окно отметки об исполнении (по аналогии с подписью). */}
        {execModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setExecModal(false)}>
            <div className="surface-1 p-5 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-display text-base font-semibold mb-2">Отметка об исполнении</h3>
              <p className="text-xs text-text-secondary mb-3">
                Подтвердите исполнение своей части документа. При необходимости добавьте комментарий.
              </p>
              <label className="block text-xs text-text-secondary mb-1">Отчёт о выполнении (обязательно)</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="Например: «Исполнено, ответ направлен исх. №…»"
                className="w-full mb-3 field"
              />
              {error && <div className="text-danger text-xs mb-2">{error}</div>}
              <div className="flex justify-end gap-2">
                <button onClick={() => setExecModal(false)} className="btn btn-secondary">
                  Отмена
                </button>
                <button
                  onClick={markComplete}
                  disabled={busy || !note.trim()}
                  className="px-3 py-1.5 rounded-md bg-success text-white text-sm font-medium disabled:opacity-60"
                >
                  {busy ? 'Отметка…' : 'Отметить исполненным'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* #4 — модалка отметки о выполнении поручения (обязательный комментарий). */}
        {doneModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setDoneModal(null)}>
            <div className="surface-1 p-5 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-display text-base font-semibold mb-2">Отметка о выполнении поручения</h3>
              <p className="text-xs text-text-secondary mb-2">Комментарий о результате обязателен. Будет зафиксировано, кто и когда выполнил.</p>
              <label className="block text-xs text-text-secondary mb-1">Результат выполнения</label>
              <textarea
                value={doneNote}
                onChange={(e) => setDoneNote(e.target.value)}
                rows={3}
                placeholder="Например: «Исполнено, ответ направлен исх. №…»"
                className="w-full mb-3 field"
              />
              {error && <div className="text-danger text-xs mb-2">{error}</div>}
              <div className="flex justify-end gap-2">
                <button onClick={() => setDoneModal(null)} className="btn btn-secondary">Отмена</button>
                <button onClick={submitDone} disabled={busy} className="px-3 py-1.5 rounded-md bg-success text-white text-sm font-medium disabled:opacity-60">
                  {busy ? 'Сохранение…' : 'Выполнено'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* #8 — модалка редактирования поручения */}
        {editAsg && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setEditAsg(null)}>
            <div className="surface-1 p-5 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <h3 className="font-display text-base font-semibold mb-2">Изменить поручение</h3>
              <label className="block text-xs text-text-secondary mb-1">Текст поручения</label>
              <input value={editAsg.text} onChange={(e) => setEditAsg({ ...editAsg, text: e.target.value })}
                className="w-full mb-2 field" />
              <label className="block text-xs text-text-secondary mb-1">Срок</label>
              <input type="date" value={editAsg.due_date ? String(editAsg.due_date).slice(0,10) : ''}
                onChange={(e) => setEditAsg({ ...editAsg, due_date: e.target.value })}
                className="mb-3 field" />
              {error && <div className="text-danger text-xs mb-2">{error}</div>}
              <div className="flex justify-end gap-2">
                <button onClick={() => setEditAsg(null)} className="btn btn-secondary">Отмена</button>
                <button onClick={submitEditAsg} disabled={busy} className="btn btn-primary disabled:opacity-60">Сохранить</button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'acquaint' && canAcquaint && (
          <div>
            <p className="text-xs text-text-secondary mb-2">
              Ознакомление сотрудников с документом. Кандидаты — из административно назначенных вам
              подразделений.
            </p>
            <AcquaintBlock
              documentId={documentId}
              onDone={async () => {
                setRecipients((await api.getRecipients(documentId)).items || [])
                onChanged?.()
              }}
            />
          </div>
        )}

        {activeTab === 'links' && (
          <div className="p-1">
            <ul className="space-y-1.5 text-sm mb-3">
              {(links || []).map((l, i) => (
                <li key={i} className="flex items-center justify-between border-b border-border last:border-0 pb-1.5">
                  {l.document_id ? (
                    // Системный документ — кликабельная ссылка.
                    <Link to={`/document/${l.document_id}`} className="text-accent hover:underline">
                      <span className="kicker mr-1">{l.number}</span>
                      {l.title}
                    </Link>
                  ) : (
                    // Несистемный (внешний/бумажный) документ — простой текст.
                    <span className="text-text-primary">
                      <span className="kicker mr-1">внешний</span>
                      {l.text_note}
                    </span>
                  )}
                  <div className="flex items-center gap-2 ml-2">
                    <span className="text-xs text-text-secondary whitespace-nowrap">
                      {LINK_TYPE_LABELS[l.link_type] || l.link_type}
                      {l.document_id ? (l.direction === 'incoming' ? ' ↩' : ' ↪') : ''}
                    </span>
                    {l.direction !== 'incoming' && (
                      <button
                        title="Удалить связь"
                        className="text-danger hover:text-danger/80 text-sm px-1"
                        onClick={async () => {
                          if (!confirm('Удалить связь?')) return
                          try { await api.deleteLink(documentId, l.link_id); setLinks((await api.getLinks(documentId)).items || []) }
                          catch (e) { alert(e.message || 'Не удалось удалить связь') }
                        }}
                      >
                        <Icon name="close" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
              {links && links.length === 0 && (
                <div className="text-text-secondary text-xs">Связанных документов нет</div>
              )}
            </ul>

            <div className="border-t border-border pt-2 space-y-2">
              {!canManage && (
                <div className="text-xs text-text-secondary">Добавлять связи может только автор или подписант.</div>
              )}
              {canManage && (
              <>
              {/* Переключатель вида связи */}
              <div className="flex gap-1 text-xs">
                <button type="button" onClick={() => setLinkMode('system')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'system' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Документ из системы
                </button>
                <button type="button" onClick={() => setLinkMode('external')}
                  className={`px-2 py-1 rounded-md border ${linkMode === 'external' ? 'border-accent text-accent' : 'border-border text-text-secondary'}`}>
                  Внешний документ
                </button>
              </div>

              {linkMode === 'system' && (
                <div className="relative">
                  {linkDocs.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-1">
                      {linkDocs.map((d) => (
                        <span key={d.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                          <span className="kicker">{d.number}</span>{d.title}
                          <button type="button" className="text-danger ml-0.5" onClick={() => setLinkDocs(linkDocs.filter((x) => x.id !== d.id))}>×</button>
                        </span>
                      ))}
                    </div>
                  )}
                  <input
                    value={linkSearch}
                    onChange={(e) => setLinkSearch(e.target.value)}
                    placeholder="Поиск документа по названию/номеру…"
                    className="field w-full"
                  />
                  {linkSearchResults.length > 0 && (
                    <div className="absolute z-20 mt-1 w-full max-h-48 overflow-auto bg-surface border border-border rounded-md shadow-lg">
                      {linkSearchResults.map((d) => (
                        <button key={d.id} type="button" onClick={() => pickLinkDoc(d)}
                          className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                          <span className="kicker mr-1">{d.outgoing_number || `#${d.id}`}</span>{d.title}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {linkMode === 'external' && (
                <input
                  value={linkNote}
                  onChange={(e) => setLinkNote(e.target.value)}
                  placeholder="Реквизиты внешнего документа (напр. «Приказ № 12 от 01.03.2025»)"
                  className="field w-full"
                />
              )}

              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="block text-xs text-text-secondary mb-1">Тип связи</label>
                  <select value={linkType} onChange={(e) => setLinkType(e.target.value)}
                    className="field w-full">
                    {LINK_TYPE_OPTIONS.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <button onClick={addLink}
                  disabled={busy || (linkMode === 'system' ? linkDocs.length === 0 : !linkNote.trim())}
                  className="btn btn-primary disabled:opacity-60">
                  Связать
                </button>
              </div>
              </>
              )}
            </div>
          </div>
        )}

        {activeTab === 'assignments' && (
          <div className="p-4">
            <div className="space-y-2 mb-4">
              {(assignments || []).map((a) => (
                <div key={a.id} className="border border-border rounded-md p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="text-sm">{a.text}</div>
                      <div className="text-xs text-text-secondary mt-1">
                        Ответственный: {a.assignee_name}
                        {a.due_date && ` · срок ${fmtDateTime(a.due_date)}`}
                      </div>
                      {/* #4 — автор поручения и время его постановки */}
                      <div className="text-xs text-text-secondary">
                        Поставлено: {a.author_name}{a.created_at ? ` · ${fmtDateTime(a.created_at)}` : ''}
                      </div>
                      {/* #4 — факт исполнения: кто, когда, результат */}
                      {a.status === 'done' && (
                        <div className="text-xs mt-1 text-success">
                          Выполнено{a.completed_by_name ? `: ${a.completed_by_name}` : ''}
                          {a.completed_at ? ` · ${fmtDateTime(a.completed_at)}` : ''}
                        </div>
                      )}
                      {a.result_note && (
                        <div className="text-xs mt-1 text-text-secondary">Результат: {a.result_note}</div>
                      )}
                    </div>
                    {/* #30 — менять статус может ТОЛЬКО автор поручения или его
                        исполнитель; остальным показываем статус без управления. */}
                    {(a.author_id === currentUserId || a.assignee_id === currentUserId) ? (
                      <select
                        value={a.status}
                        onChange={(e) => changeAssignmentStatus(a.id, e.target.value)}
                        disabled={busy}
                        className="text-xs px-2 py-1 rounded border border-border bg-surface-alt"
                      >
                        {a.status === 'open' && <option value="open">Новое</option>}
                        <option value="in_progress">В работе</option>
                        <option value="done">Выполнено</option>
                        <option value="cancelled">Отменено</option>
                      </select>
                    ) : (
                      <span className="text-xs px-2 py-1 rounded border border-border text-text-secondary">
                        {ASSIGNMENT_STATUS_LABELS[a.status] || a.status}
                      </span>
                    )}
                    {/* #7 — изменять/удалять поручение может только тот, кто дал; после «выполнено» — нельзя */}
                    {a.status !== 'done' && a.author_id === currentUserId && (
                      <div className="flex gap-1 ml-1">
                        <button title="Изменить" className="text-xs px-1.5 py-1 rounded border border-border"
                          onClick={() => setEditAsg({ id: a.id, text: a.text, due_date: a.due_date || '' })}><Icon name="edit" /></button>
                        <button title="Удалить" className="text-xs px-1.5 py-1 rounded border border-danger/40 text-danger"
                          onClick={() => deleteAsg(a.id)}><Icon name="trash" /></button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {assignments && assignments.length === 0 && (
                <div className="text-sm text-text-secondary">Поручений нет</div>
              )}
            </div>

            {(canAssign || isParticipant) && (
            <div className="border-t border-border pt-3 space-y-2">
              <div className="text-xs text-text-secondary">Новое поручение</div>
              <input
                value={asgText}
                onChange={(e) => setAsgText(e.target.value)}
                placeholder="Текст поручения"
                className="field w-full"
              />
              <PersonPicker
                group="assignees"
                multiple
                value={asgAssignees}
                onChange={setAsgAssignees}
                excludeIds={[currentUserId].filter(Boolean)}
              />
              <div className="flex gap-2 items-center">
                <input
                  type="date"
                  value={asgDue}
                  onChange={(e) => setAsgDue(e.target.value)}
                  className="field w-full"
                />
                <button
                  onClick={addAssignment}
                  disabled={busy || asgAssignees.length === 0 || !asgText}
                  className="btn btn-primary disabled:opacity-60"
                >
                  Дать поручение{asgAssignees.length > 1 ? ` (${asgAssignees.length})` : ''}
                </button>
              </div>
            </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// AcquaintBlock — ознакомление сотрудников с документом. Кандидаты — только из
// административно назначенных текущему пользователю подразделений (бэкенд
// /acquaint-candidates фильтрует). Мультивыбор.
function AcquaintBlock({ documentId, onDone }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [picked, setPicked] = useState([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [list, setList] = useState([])

  useEffect(() => {
    api.getAcquaintances(documentId).then((r) => setList(r.items || [])).catch(() => {})
  }, [documentId])

  useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      try {
        const r = await api.acquaintCandidates(q.trim(), documentId)
        if (!cancelled) setResults(r.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      }
    }, q.trim() ? 250 : 0)
    return () => { cancelled = true; clearTimeout(t) }
  }, [q, open])

  async function submit() {
    if (picked.length === 0) return
    setBusy(true); setError('')
    try {
      await api.acquaint(documentId, picked.map((p) => p.id))
      setPicked([])
      setOpen(false)
      setList((await api.getAcquaintances(documentId)).items || [])
      onDone?.()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const pickedIds = new Set(picked.map((p) => p.id))

  return (
    <div className="border-t border-border pt-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs text-text-secondary">Ознакомление</p>
        <button onClick={() => setOpen((v) => !v)} className="text-xs text-accent">
          {open ? 'Скрыть' : 'Ознакомить сотрудников'}
        </button>
      </div>

      {list.length > 0 && (
        <ul className="text-xs text-text-secondary mb-2 space-y-0.5">
          {list.map((a) => (
            <li key={a.user_id}>
              {a.full_name} <span className="opacity-70">— ознакомил {a.acquainted_by_name}</span>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div>
          {picked.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-1">
              {picked.map((p) => (
                <span key={p.id} className="inline-flex items-center gap-1 bg-accent/15 border border-accent/40 rounded-full px-2 py-0.5 text-xs">
                  {p.full_name}
                  <button type="button" className="text-danger ml-0.5" onClick={() => setPicked(picked.filter((x) => x.id !== p.id))}>×</button>
                </span>
              ))}
            </div>
          )}
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск сотрудника для ознакомления…"
            className="field mb-1"
          />
          <div className="max-h-40 overflow-auto border border-border rounded-md mb-2">
            {results.filter((r) => !pickedIds.has(r.id)).length === 0 && (
              <div className="px-3 py-2 text-xs text-text-secondary">
                {q.trim() ? 'Ничего не найдено' : 'Нет доступных для ознакомления сотрудников'}
              </div>
            )}
            {results.filter((r) => !pickedIds.has(r.id)).map((r) => (
              <button key={r.id} type="button"
                onClick={() => { setPicked([...picked, r]); setQ('') }}
                className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt">
                {r.full_name}
                {r.department_name && <span className="text-text-secondary text-xs ml-2">{r.department_name}</span>}
              </button>
            ))}
          </div>
          {error && <div className="text-danger text-xs mb-1">{error}</div>}
          <button onClick={submit} disabled={busy || picked.length === 0}
            className="btn btn-primary w-full justify-center disabled:opacity-60">
            {busy ? 'Ознакомление…' : `Ознакомить (${picked.length})`}
          </button>
        </div>
      )}
    </div>
  )
}

// ControlTab — постановка/снятие с контроля и выбор/смена контролёров (#4).
// Автор (canManage) может менять; остальные видят статус и список контролёров.
function ControlTab({ documentId, doc, canManage, patchDoc }) {
  const [onControl, setOnControl] = useState(!!doc?.on_control)
  const [controller, setController] = useState([]) // #4 — несколько контролёров
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)

  // Грузим текущих контролёров документа.
  useEffect(() => {
    let cancelled = false
    api.getDocumentControllers(documentId).then((r) => {
      if (cancelled) return
      setController((r.items || []).map((cn) => ({
        id: cn.user_id, full_name: cn.full_name, position: cn.position,
        department_name: cn.department_name, city: cn.city,
      })))
    }).catch(() => {})
    return () => { cancelled = true }
  }, [documentId])

  async function save() {
    setBusy(true); setError(''); setSaved(false)
    try {
      await api.setControl(documentId, onControl, controller.map((c) => c.id))
      setSaved(true)
      patchDoc?.({
        on_control: onControl,
        controller_id: controller[0]?.id || null,
        controller_name: controller[0]?.full_name || null,
      })
    } catch (e) {
      setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  if (!canManage) {
    return (
      <div className="p-1 text-sm">
        {doc?.on_control ? (
          <div className="text-danger">
            ● Документ на контроле
            {controller.length > 0 && (
              <span className="text-text-secondary"> — контролёры: {controller.map((c) => c.full_name).join(', ')}</span>
            )}
          </div>
        ) : (
          <div className="text-text-secondary">Документ не на контроле</div>
        )}
      </div>
    )
  }

  return (
    <div className="p-1 space-y-3">
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
        Документ на контроле
      </label>
      {onControl && (
        <div>
          <label className="block text-xs text-text-secondary mb-1">Контролёры (можно несколько)</label>
          <PersonPicker group="controller" multiple value={controller} onChange={setController} />
        </div>
      )}
      {error && <div className="text-danger text-xs">{error}</div>}
      {saved && <div className="text-success text-xs">Сохранено</div>}
      <button onClick={save} disabled={busy}
        className="btn btn-primary disabled:opacity-60">
        {busy ? 'Сохранение…' : 'Сохранить'}
      </button>
    </div>
  )
}
