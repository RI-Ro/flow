import React from 'react'

// #35 — Единый набор ИКОНОК-SVG вместо юникод-глифов (✎ 🗑 ⛶ ▸ ▾ × ↑ ↓ 🔔 …).
// Юникод-символы рисуются шрифтом операционной системы: на части машин и
// браузеров нужного глифа просто нет, и пользователь видит пустой квадрат или
// ничего. Inline-SVG рисуется самим браузером и выглядит одинаково везде,
// наследует цвет через currentColor и масштабируется размером шрифта.
//
// Использование: <Icon name="edit" />  либо <Icon name="chevron-down" size={14} />
const PATHS = {
  edit: <path d="M4 20h4L19 9l-4-4L4 16v4z M14 6l4 4" />,
  trash: <path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13M10 11v6M14 11v6" />,
  close: <path d="M5 5l14 14M19 5L5 19" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  'chevron-down': <path d="M6 9l6 6 6-6" />,
  'chevron-right': <path d="M9 6l6 6-6 6" />,
  'chevron-up': <path d="M6 15l6-6 6 6" />,
  'arrow-up': <path d="M12 19V5M6 11l6-6 6 6" />,
  'arrow-down': <path d="M12 5v14M6 13l6 6 6-6" />,
  'arrow-left': <path d="M19 12H5M11 6l-6 6 6 6" />,
  'arrow-right': <path d="M5 12h14M13 6l6 6-6 6" />,
  fullscreen: <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />,
  bell: <path d="M18 16V11a6 6 0 10-12 0v5l-2 3h16l-2-3zM10 22h4" />,
  'volume-on': <path d="M4 9v6h4l5 4V5L8 9H4zM17 9a4 4 0 010 6" />,
  'volume-off': <path d="M4 9v6h4l5 4V5L8 9H4zM17 10l4 4M21 10l-4 4" />,
  paperclip: <path d="M20 11l-8.5 8.5a4.5 4.5 0 01-6.4-6.4L13 5a3 3 0 014.2 4.2l-7.8 7.8a1.5 1.5 0 01-2.1-2.1l7.3-7.3" />,
  user: <path d="M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0" />,
  search: <path d="M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3" />,
  reset: <path d="M4 12a8 8 0 108-8 8 8 0 00-5.7 2.4L4 9M4 4v5h5" />,
  // #42 — «гамбургер» для скрытия бокового меню
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  dot: <circle cx="12" cy="12" r="5" />,
}

export default function Icon({ name, size = 16, className = '', title, strokeWidth = 1.8 }) {
  const d = PATHS[name]
  if (!d) return null
  const filled = name === 'dot'
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke={filled ? 'none' : 'currentColor'}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`inline-block shrink-0 align-[-0.15em] ${className}`}
      aria-hidden={title ? undefined : true}
      role={title ? 'img' : undefined}
													focusable="false"
    >
      {title ? <title>{title}</title> : null}
      {d}
    </svg>
  )
}
