import React, { useEffect, useRef, useState, useCallback } from 'react'
import Icon from '../components/Icon'
// #8 — LEGACY-сборка pdf.js: транспилирована под старые браузеры (ES5-совместимо),
// в отличие от основной сборки, которая использует современный синтаксис и не
// открывалась у части пользователей. Ниже — надёжная инициализация воркера с
// fallback в безворкерный режим, а при полном отказе рендера — нативный
// просмотрщик браузера (см. состояние fallback).
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf'
import pdfWorker from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url'
import { api } from '../api/client'

try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker
} catch (_) {
  /* окружение без поддержки воркеров — рендер пойдёт в основном потоке */
}

// Просмотрщик без кнопок скачивания/печати (рендер на canvas через pdf.js,
// без тулбара браузера). Масштаб (−/+/сброс), полноэкранный режим, блокировка
// контекстного меню (UX-барьер, не крипто-защита).
//
// МАРКИРОВКА (overlay): штампы приходят через prop `stamps` (см. эндпоинт
// GET /api/documents/:id/marking) и рисуются поверх ПЕРВОЙ страницы по
// конфигурации (позиция-якорь tl/tr/bl/br/c + смещения в пунктах PDF, размер,
// цвет, рамка). Это «дублирование маркировки на фронте», когда бэкенд не
// вжигает штампы в сам PDF (baked=false). Смещения в пунктах переводятся в
// пиксели через масштаб отрисованной страницы.
export default function DocumentViewer({ documentId, marking, stamps = [] }) {
  const [error, setError] = useState('')
  const [numPages, setNumPages] = useState(0)
  const [zoom, setZoom] = useState(1) // множитель к базовому «вписать по ширине»
  const [fullscreen, setFullscreen] = useState(false)
  // Геометрия первой страницы для позиционирования overlay-штампов.
  const [page1, setPage1] = useState(null) // { left, top, width, height, pxPerPt }
  const containerRef = useRef(null)
  // #23 — ссылки для ЖИВОГО измерения геометрии первой страницы: штампы должны
  // пересчитываться при зуме, полноэкранном режиме и ресайзе окна, а не один
  // раз после отрисовки (иначе маркировка «съезжает» до перезагрузки).
  const overlayHostRef = useRef(null)
  const firstPageRef = useRef(null)
  const firstPagePtWidthRef = useRef(0)
  const pdfRef = useRef(null)
  // #12 — Текст страниц, извлечённый pdf.js. Нужен для кнопки «Копировать
  // текст»: она работает даже если пользователь не умеет/не может выделить
  // прозрачный текстовый слой мышью.
  const pageTextsRef = useRef([])
  const [copyNote, setCopyNote] = useState('')

  const renderAll = useCallback(async (pdf, zoomLevel) => {
    const container = containerRef.current
    if (!container) return
    container.innerHTML = ''
    const width = container.clientWidth || 800
    let firstGeom = null

    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n)
      const unscaled = page.getViewport({ scale: 1 })
      const baseScale = (width - 24) / unscaled.width
      const viewport = page.getViewport({ scale: baseScale * zoomLevel })

      // Обёртка страницы (position:relative) — под canvas и текстовый слой.
      const pageWrap = document.createElement('div')
      pageWrap.className = 'relative mx-auto mb-3'
      pageWrap.style.width = `${viewport.width}px`
      pageWrap.style.height = `${viewport.height}px`
      container.appendChild(pageWrap)

      const canvas = document.createElement('canvas')
      canvas.width = viewport.width
      canvas.height = viewport.height
      canvas.className = 'shadow rounded block'
      const ctx = canvas.getContext('2d')
      pageWrap.appendChild(canvas)
      await page.render({ canvasContext: ctx, viewport }).promise

      // #5 — Текстовый слой поверх canvas: делает текст ВЫДЕЛЯЕМЫМ и КОПИРУЕМЫМ
      // (Ctrl+C), не давая при этом скачать файл. Скачивание/печать по-прежнему
      // недоступны (нет тулбара браузера, печать страницы скрыта).
      try {
        const textContent = await page.getTextContent()
        // #12 — сохраняем «плоский» текст страницы для кнопки копирования.
        pageTextsRef.current[n - 1] = (textContent.items || [])
          .map((it) => (it.str || '') + (it.hasEOL ? '\n' : ''))
          .join('')
        const textLayerDiv = document.createElement('div')
        textLayerDiv.className = 'sed-text-layer'
        textLayerDiv.style.width = `${viewport.width}px`
        textLayerDiv.style.height = `${viewport.height}px`
        pageWrap.appendChild(textLayerDiv)
        if (typeof pdfjsLib.renderTextLayer === 'function') {
          await pdfjsLib.renderTextLayer({
            textContentSource: textContent,
            container: textLayerDiv,
            viewport,
            textDivs: [],
          }).promise
        } else if (pdfjsLib.TextLayer) {
          const tl = new pdfjsLib.TextLayer({ textContentSource: textContent, container: textLayerDiv, viewport })
          await tl.render()
        }
      } catch (_) {
        /* текстовый слой не критичен для просмотра */
      }

      if (n === 1) {
        firstPageRef.current = pageWrap
        firstPagePtWidthRef.current = unscaled.width
        firstGeom = { pending: true }
      }
    }
    // Геометрию берём измерением (см. measurePage1) — после того, как браузер
    // применил размеры. Это и даёт корректную привязку при любом масштабе.
    if (firstGeom) measurePage1()
  }, [])

  // measurePage1 — измеряет положение и размер первой страницы ОТНОСИТЕЛЬНО
  // контейнера overlay. Так не нужно вручную компенсировать внутренние отступы,
  // и значения всегда соответствуют текущему масштабу.
  const measurePage1 = useCallback(() => {
    const wrap = firstPageRef.current
    const host = overlayHostRef.current
    const ptW = firstPagePtWidthRef.current
    if (!wrap || !host || !ptW) return
    const wr = wrap.getBoundingClientRect()
    const hr = host.getBoundingClientRect()
    if (wr.width < 1) return
    setPage1({
      left: wr.left - hr.left,
      top: wr.top - hr.top,
      width: wr.width,
      height: wr.height,
      pxPerPt: wr.width / ptW,
    })
  }, [])

  useEffect(() => {
    let cancelled = false
    setError('')
    setNumPages(0)
    setPage1(null)

    api
      .getDocumentFileBlob(documentId)
      .then(async (blob) => {
        if (cancelled) return
        try {
          const buf = await blob.arrayBuffer()
          // #8 — опции совместимости: не полагаемся на eval, используем
          // системные шрифты, не глушим font-face — так рендер устойчивее в
          // разных браузерах.
          const pdf = await pdfjsLib.getDocument({
            data: buf,
            isEvalSupported: false,
            useSystemFonts: true,
            disableFontFace: false,
          }).promise
          if (cancelled) return
          pdfRef.current = pdf
          setNumPages(pdf.numPages)
          await renderAll(pdf, zoom)
        } catch (renderErr) {
          // #8 — НИКАКОГО нативного браузерного просмотрщика в запасе: он даёт
          // панель со скачиванием/печатью и может показать файл без наших
          // штампов. Если pdf.js не смог отрисовать — показываем ошибку.
          if (!cancelled) {
            console.warn('pdf.js render failed:', renderErr)
            setError('Не удалось отобразить документ в защищённом просмотрщике. Обновите браузер до актуальной версии.')
          }
        }
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || 'Не удалось загрузить файл')
      })

    return () => {
      cancelled = true
      if (pdfRef.current) {
        pdfRef.current.destroy?.()
        pdfRef.current = null
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documentId])

  // Перерисовка при смене зума/фуллскрина (документ уже загружен).
  // #23 — Пересчёт геометрии штампов при ЛЮБОМ изменении размера страницы:
  // зум, полноэкранный режим, ресайз окна, появление/исчезновение полосы
  // прокрутки. Без этого маркировка оставалась на старых координатах.
  useEffect(() => {
    const onResize = () => measurePage1()
    window.addEventListener('resize', onResize)
    let ro = null
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => measurePage1())
      if (containerRef.current) ro.observe(containerRef.current)
    }
    return () => {
      window.removeEventListener('resize', onResize)
      if (ro) ro.disconnect()
    }
  }, [measurePage1])

  useEffect(() => {
    if (pdfRef.current) renderAll(pdfRef.current, zoom)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zoom, fullscreen])

  const zoomIn = () => setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)))
  const zoomOut = () => setZoom((z) => Math.max(0.5, +(z - 0.25).toFixed(2)))
  const zoomReset = () => setZoom(1)

  const wrapClass = fullscreen
    ? 'fixed inset-0 z-50 bg-surface-alt flex flex-col'
    : 'relative h-full bg-surface-alt border border-border rounded-lg flex flex-col'

  // Позиционирование одного штампа по якорю + смещениям (в пунктах → px).
  const stampStyle = (s) => {
    if (!page1) return { display: 'none' }
    const pp = page1.pxPerPt
    const ax = Math.abs((s.offset_x || 0) * pp)
    const ay = Math.abs((s.offset_y || 0) * pp)
    const borderColor = s.border_color || s.color || '#000'
    // Заливка: явный fill приоритетнее; иначе под рамкой — лёгкий фон, без рамки — прозрачно.
    const bg = s.fill
      ? s.fill
      : (s.border ? 'color-mix(in srgb, var(--color-surface) 78%, transparent)' : 'transparent')
    const base = {
      position: 'absolute',
      maxWidth: `${page1.width * 0.6}px`,
      fontSize: `${Math.max(8, (s.font_size || 9) * pp)}px`,
      lineHeight: 1.25,
      color: s.color || '#000',
      pointerEvents: 'none',
      padding: (s.border || s.fill) ? '3px 6px' : 0,
      border: s.border ? `1px solid ${borderColor}` : 'none',
      borderRadius: (s.border || s.fill) ? '3px' : 0,
      background: bg,
      fontWeight: 600,
    }
    switch (s.position) {
      case 'tl': return { ...base, left: ax, top: ay }
      case 'tr': return { ...base, right: ax, top: ay }
      case 'bl': return { ...base, left: ax, bottom: ay }
      case 'br': return { ...base, right: ax, bottom: ay }
      case 'c':  return { ...base, left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }
      default:   return { ...base, right: ax, bottom: ay }
    }
  }

  // Содержимое штампа: если есть изображение — две колонки (картинка | текст),
  // иначе просто текст.
  const StampBody = ({ s }) => {
    if (s.image) {
      const imgH = Math.max(28, (s.font_size || 9) * (page1?.pxPerPt || 1) * 4)
      return (
        <div className="flex items-center gap-2">
          <img src={s.image} alt="" style={{ height: imgH, width: 'auto', objectFit: 'contain' }} />
          <div style={{ whiteSpace: 'pre-line' }}>{s.text}</div>
        </div>
      )
    }
    return <div style={{ whiteSpace: 'pre-line' }}>{s.text}</div>
  }

  // #12 — Копирование текста документа.
  //
  // Причина замечания: контекстное меню в просмотрщике блокировалось ВСЕГДА,
  // поэтому привычный путь «выделить → правый клик → Копировать» не работал, а
  // текстовый слой прозрачный и выделение в нём не видно. Теперь:
  //   * контекстное меню разрешено, КОГДА есть выделение (в нём есть
  //     «Копировать»); без выделения меню по-прежнему скрыто, чтобы не давать
  //     «Сохранить изображение»/«Печать» в обход учёта экземпляров;
  //   * выделение подсвечивается видимым цветом (см. ::selection ниже);
  //   * есть явная кнопка «Копировать текст» — копирует выделение, а если
  //     ничего не выделено, весь распознанный текст документа.
  const allowContextMenu = (e) => {
    const sel = typeof window !== 'undefined' ? String(window.getSelection() || '') : ''
    if (!sel.trim()) e.preventDefault()
  }

  const copyText = async () => {
    const sel = typeof window !== 'undefined' ? String(window.getSelection() || '') : ''
    const text = sel.trim() ? sel : pageTextsRef.current.filter(Boolean).join('\n\n')
    if (!text.trim()) {
      setCopyNote('В документе нет текстового слоя (скан-изображение) — копировать нечего')
      return
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text)
      } else {
        // Fallback для окружений без Clipboard API (например, http без TLS).
        const ta = document.createElement('textarea')
        ta.value = text
        ta.style.position = 'fixed'
        ta.style.opacity = '0'
        document.body.appendChild(ta)
        ta.select()
        document.execCommand('copy')
        document.body.removeChild(ta)
      }
      setCopyNote(sel.trim() ? 'Выделенный текст скопирован' : 'Текст документа скопирован')
    } catch (e) {
      setCopyNote('Не удалось скопировать: ' + (e.message || 'ошибка буфера обмена'))
    }
  }

  useEffect(() => {
    if (!copyNote) return
    const t = setTimeout(() => setCopyNote(''), 4000)
    return () => clearTimeout(t)
  }, [copyNote])

  return (
    <div className={wrapClass + ' sed-secure-viewer'} onContextMenu={allowContextMenu}>
      {/* #8 — При попытке печати страницы браузером (Ctrl+P) скрываем документ:
          скачивание/печать средствами браузера не должны обходить маркировку и
          контроль экземпляров. Легитимная печать — только через вкладку
          «Печать» (маркированный файл под учётом). */}
      <style>{`
        @media print { .sed-secure-viewer { display: none !important; } }
        .sed-text-layer { position:absolute; left:0; top:0; overflow:hidden; line-height:1;
          opacity:1; z-index:2; }
        .sed-text-layer span, .sed-text-layer br { color:transparent; position:absolute;
          white-space:pre; cursor:text; transform-origin:0% 0%; }
        /* #12 — выделение в прозрачном текстовом слое должно быть ВИДНО.
           Селектор ".sed-text-layer ::selection" срабатывал только на
           внуков и на самих span'ах не работал. */
        .sed-text-layer span::selection, .sed-text-layer::selection { background: rgba(0,120,255,0.35); }
        .sed-text-layer span::-moz-selection { background: rgba(0,120,255,0.35); }
      `}</style>
      {/* Панель управления просмотром (масштаб, полный экран) */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-surface/80 shrink-0">
        <button onClick={zoomOut} className="px-2 py-0.5 rounded hover:bg-surface-alt text-sm" title="Уменьшить">
          <Icon name="minus" />
        </button>
        <span className="text-xs text-text-secondary w-12 text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={zoomIn} className="px-2 py-0.5 rounded hover:bg-surface-alt text-sm" title="Увеличить">
          <Icon name="plus" />
        </button>
        <button onClick={zoomReset} className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs" title="Сбросить масштаб">
          100%
        </button>
        {/* #12 — явное копирование текста документа */}
        <button
          onClick={copyText}
          className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs"
          title="Скопировать выделенный текст, либо весь текст документа"
        >
          Копировать текст
        </button>
        {copyNote && <span className="text-[11px] text-text-secondary">{copyNote}</span>}
        <div className="flex-1" />
        <button
          onClick={() => setFullscreen((v) => !v)}
          className="px-2 py-0.5 rounded hover:bg-surface-alt text-xs"
          title={fullscreen ? 'Свернуть' : 'Во весь экран'}
        >
          {fullscreen ? <><Icon name="close" /> Свернуть</> : <><Icon name="fullscreen" /> Во весь экран</>}
        </button>
      </div>

      <div className="relative flex-1 overflow-auto">
        {error && <div className="p-4 text-danger text-sm">{error}</div>}
        {!error && numPages === 0 && <div className="p-4 text-text-secondary text-sm">Загрузка документа…</div>}

        {/* Обёртка нужна как контейнер позиционирования overlay-штампов. */}
        {!error && (
        <div className="relative p-3" ref={overlayHostRef}>
          <div ref={containerRef} />
          {/* Overlay-маркировка поверх первой страницы (по конфигурации). */}
          {page1 && stamps && stamps.length > 0 && (
            <div
              className="absolute pointer-events-none"
              style={{
                left: page1.left,
                top: page1.top,
                width: page1.width,
                height: page1.height,
              }}
            >
              {stamps.map((s, i) => (
                <div key={i} style={stampStyle(s)}><StampBody s={s} /></div>
              ))}
            </div>
          )}
        </div>
        )}

        {/* Старый текстовый бейдж (входящий/архив) — оставлен как доп. подсказка. */}
        {marking && (!stamps || stamps.length === 0) && (
          <div className="absolute top-2 right-2 bg-surface/90 border border-border rounded-md px-2 py-1 text-[11px] text-text-secondary pointer-events-none max-w-[60%] text-right leading-tight whitespace-pre-line">
            {marking}
          </div>
        )}
      </div>
    </div>
  )
}
