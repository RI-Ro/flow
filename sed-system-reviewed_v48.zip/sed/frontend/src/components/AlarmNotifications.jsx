import React, { useCallback, useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Icon from './Icon'
import { api } from '../api/client'
import { playEventSound, primeAudio } from '../lib/sound'
import { fmtDateTime } from '../utils/format'

// #2 — УВЕДОМЛЕНИЯ-«БУДИЛЬНИКИ».
//
// Часть уведомлений нельзя пропустить: пришло на согласование, дали поручение,
// направили документ, истёк срок. Они показываются МОДАЛЬНЫМ окном поверх
// интерфейса со звуковым сигналом, который повторяется, пока окно открыто.
//
// Закрыть окно можно только осознанным действием:
//   * «Открыть документ» — уведомление отмечается прочитанным и выполняется
//     переход к документу;
//   * «Прочитать» — отмечается прочитанным и остаётся в колоколе;
//   * «Отложить» — ровно 5, 15 или 30 минут (список приходит с сервера,
//     произвольные значения сервер отклоняет).
//
// Кнопки «закрыть» (×) и закрытия по клику на фон здесь намеренно НЕТ: иначе
// окно закрывалось бы случайным кликом и смысл будильника пропадал. Esc тоже
// не закрывает.
//
// Какие именно виды событий — будильники, решает сервер (requires_ack,
// настройка notifications.alarm_kinds). Фронт их не угадывает.

// Период повторного сигнала по умолчанию (сервер может прислать свой —
// notifications.repeat_seconds).
const DEFAULT_REPEAT_MS = 20000

export default function AlarmNotifications() {
  const [items, setItems] = useState([])
  const [snoozeOptions, setSnoozeOptions] = useState([5, 15, 30])
  const [repeatMs, setRepeatMs] = useState(DEFAULT_REPEAT_MS)
  const [busy, setBusy] = useState(false)
  const navigate = useNavigate()
  // id уведомлений, по которым уже звучал сигнал — чтобы один и тот же
  // будильник не пищал заново на каждом опросе.
  const soundedRef = useRef(new Set())

  const load = useCallback(async () => {
    try {
      const res = await api.getAlarmNotifications()
      const list = res.items || []
      if (Array.isArray(res.snooze_minutes) && res.snooze_minutes.length > 0) {
        setSnoozeOptions(res.snooze_minutes)
      }
      if (res.repeat_seconds > 0) setRepeatMs(res.repeat_seconds * 1000)
      setItems(list)
      // Звук — только для новых (ещё не озвученных) уведомлений.
      const fresh = list.find((it) => !soundedRef.current.has(it.id))
      if (fresh) {
        list.forEach((it) => soundedRef.current.add(it.id))
        playEventSound(fresh.kind || 'notification', { alarm: true })
      }
    } catch (_) {
      /* сеть/сессия — модалку не показываем, колокол сам перечитает */
    }
  }, [])

  useEffect(() => {
    primeAudio()
    load()
  }, [load])

  // Периодический опрос: нужен не для «живости» (её даёт WebSocket в колоколе),
  // а чтобы будильник ВЕРНУЛСЯ, когда истечёт время «отложить» — события при
  // этом не происходит, и прислать его некому.
  useEffect(() => {
    const t = setInterval(load, 60000)
    return () => clearInterval(t)
  }, [load])

  // Повторный сигнал, пока окно открыто и не обработано.
  useEffect(() => {
    if (items.length === 0 || repeatMs <= 0) return undefined
    const t = setInterval(() => playEventSound(items[0].kind || 'notification', { alarm: true }), repeatMs)
    return () => clearInterval(t)
  }, [items, repeatMs])

  // Новое уведомление по WebSocket — перечитываем будильники сразу, не ожидая
  // следующего опроса. Колокол держит своё соединение; здесь слушаем общее
  // событие окна, которое он рассылает (см. NotificationsBell).
  useEffect(() => {
    function onNotification() {
      load()
    }
    window.addEventListener('sed:notification', onNotification)
    return () => window.removeEventListener('sed:notification', onNotification)
  }, [load])

  const current = items[0]
  if (!current) return null

  async function act(fn) {
    if (busy) return
    setBusy(true)
    try {
      await fn()
      // Убираем обработанное из очереди локально — следующий будильник
      // (если есть) покажется сразу, без ожидания опроса.
      setItems((arr) => arr.filter((x) => x.id !== current.id))
    } catch (_) {
      /* ошибку показываем тем, что окно осталось открытым */
    } finally {
      setBusy(false)
    }
  }

  const markRead = () => act(() => api.markNotificationRead(current.id))
  const openDoc = () =>
    act(async () => {
      await api.markNotificationRead(current.id)
      if (current.document_id) navigate(`/document/${current.document_id}`)
    })
  const snooze = (minutes) => act(() => api.snoozeNotification(current.id, minutes))

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div
        className="w-full max-w-lg bg-surface border-2 border-danger rounded-lg shadow-2xl"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="alarm-title"
      >
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
          <span className="text-danger">
            <Icon name="bell" size={20} />
          </span>
          <span id="alarm-title" className="font-medium">
            Требует внимания
          </span>
          {items.length > 1 && (
            <span className="ml-auto text-xs text-text-secondary">
              ещё {items.length - 1}
            </span>
          )}
        </div>

        <div className="px-4 py-4">
          {/* Текст приходит с сервера в едином виде (#7) — здесь он не
              собирается из вида события. */}
          <div className="text-sm leading-relaxed">{current.text}</div>
          <div className="text-[11px] text-text-secondary mt-2">
            {fmtDateTime(current.created_at)}
          </div>
        </div>

        <div className="px-4 py-3 border-t border-border flex flex-wrap items-center gap-2">
          {current.document_id && (
            <button
              onClick={openDoc}
              disabled={busy}
              className="btn btn-primary disabled:opacity-50"
            >
              Открыть документ
            </button>
          )}
          <button
            onClick={markRead}
            disabled={busy}
            className="btn btn-secondary hover:bg-surface-alt disabled:opacity-50"
          >
            Прочитать
          </button>
          <div className="flex items-center gap-1 ml-auto">
            <span className="text-xs text-text-secondary mr-1">Отложить:</span>
            {snoozeOptions.map((m) => (
              <button
                key={m}
                onClick={() => snooze(m)}
                disabled={busy}
                className="px-2 py-1 rounded-md border border-border text-xs hover:bg-surface-alt disabled:opacity-50"
              >
                {m} мин
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
