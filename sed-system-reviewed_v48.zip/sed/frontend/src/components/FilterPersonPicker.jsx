import React, { useCallback, useEffect, useRef, useState } from 'react'
import Icon from './Icon'
import { api } from '../api/client'

// #28 — ВЫБОР ЧЕЛОВЕКА ДЛЯ ФИЛЬТРА.
//
// Это не PersonPicker. Тот отвечает на вопрос «кого можно НАЗНАЧИТЬ» и потому
// ограничен ролью, иерархией подразделений и только действующими
// сотрудниками — для форм создания и маршрута это правильно.
//
// В фильтре вопрос другой: «по кому искать уже существующие документы». Там
// ограничения вредны:
//   * подписант мог быть из другого подразделения — иначе документ по нему не
//     найти;
//   * автором может быть сам пользователь (в PersonPicker он исключён, потому
//     что себя нельзя назначить согласующим);
//   * уволенные сотрудники обязаны остаться в списке — подписанные ими
//     документы никуда не исчезли.
//
// Поэтому здесь свой эндпоинт (/api/users/filter-candidates) и своя разметка:
// уволенные помечаются явно, чтобы было понятно, почему человека нет в других
// списках.
export default function FilterPersonPicker({ role, value, onChange, placeholder = 'ФИО…' }) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function onDown(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [])

  const search = useCallback(async (q) => {
    setLoading(true)
    try {
      const res = await api.getFilterPeople({ role, q })
      setItems(res.items || [])
    } catch (_) {
      setItems([])
    } finally {
      setLoading(false)
    }
  }, [role])

  // Задержка перед запросом: иначе на каждую введённую букву уходит запрос.
  useEffect(() => {
    if (!open) return undefined
    const t = setTimeout(() => search(query), 250)
    return () => clearTimeout(t)
  }, [open, query, search])

  const label = value ? value.full_name : ''

  return (
    <div className="relative" ref={ref}>
      <div className="flex items-center gap-1">
        <input
          value={open ? query : label}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setOpen(true)}
          placeholder={placeholder}
          className="field w-full"
        />
        {value && (
          <button
            type="button"
            onClick={() => { onChange(null); setQuery('') }}
            className="px-1 text-text-secondary hover:text-danger"
            title="Очистить"
          >
            <Icon name="close" size={14} />
          </button>
        )}
      </div>

      {open && (
        <div className="absolute z-20 left-0 right-0 mt-1 bg-surface border border-border rounded-md shadow-lg max-h-56 overflow-auto">
          {loading && <div className="px-2 py-1.5 text-xs text-text-secondary">Поиск…</div>}
          {!loading && items.length === 0 && (
            <div className="px-2 py-1.5 text-xs text-text-secondary">Никого не найдено</div>
          )}
          {items.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => { onChange(p); setOpen(false); setQuery('') }}
              className="w-full text-left px-2 py-1.5 text-sm hover:bg-surface-alt"
            >
              <span className={p.is_active ? '' : 'text-text-secondary'}>{p.full_name}</span>
              {p.position && <span className="text-text-secondary text-xs"> · {p.position}</span>}
              {p.department_name && <span className="text-text-secondary text-xs"> · {p.department_name}</span>}
              {!p.is_active && (
                <span className="ml-1 text-[10px] text-warning">уволен</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
