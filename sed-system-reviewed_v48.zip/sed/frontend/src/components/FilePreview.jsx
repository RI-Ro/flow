import React, { useEffect, useRef, useState } from 'react'
import Icon from './Icon'

// #32 — ПРЕДПРОСМОТР ФАЙЛА ДО СОХРАНЕНИЯ.
//
// Раньше выбранный PDF никак не показывался: пользователь узнавал, что
// приложил не тот файл или не ту его версию, только после создания документа —
// а документ уже ушёл на согласование, и исправлять приходилось заменой файла
// со сбросом маршрута.
//
// Здесь файл открывается прямо из браузера, не загружаясь на сервер: из File
// делается blob-URL и отдаётся во встроенный просмотрщик (<object>). Это не
// pdf.js-просмотрщик карточки документа: там нужны маркировка и запрет
// скачивания, а здесь файл и так лежит у пользователя на диске — показать его
// средствами браузера и дешевле, и надёжнее.
//
// blob-URL обязательно освобождается (revokeObjectURL): иначе каждый выбор
// файла оставлял бы копию PDF в памяти вкладки до её закрытия.
export default function FilePreview({ file, className = '' }) {
  const [url, setUrl] = useState('')
  const [open, setOpen] = useState(false)
  const urlRef = useRef('')

  useEffect(() => {
    // Освобождаем предыдущий URL при любой смене файла.
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current)
      urlRef.current = ''
    }
    if (!file) {
      setUrl('')
      setOpen(false)
      return undefined
    }
    const u = URL.createObjectURL(file)
    urlRef.current = u
    setUrl(u)
    // Новый файл — сворачиваем предпросмотр: пользователь сам решит смотреть.
    setOpen(false)
    return () => {
      if (urlRef.current) {
        URL.revokeObjectURL(urlRef.current)
        urlRef.current = ''
      }
    }
  }, [file])

  if (!file) return null

  const sizeMB = file.size / (1024 * 1024)
  const isPDF = file.type === 'application/pdf' || /\.pdf$/i.test(file.name)

  return (
    <div className={`mt-2 border border-border rounded-md ${className}`}>
      <div className="flex items-center gap-2 px-2 py-1.5 text-xs">
        <Icon name="paperclip" size={14} />
        <span className="truncate flex-1" title={file.name}>
          {file.name}
        </span>
        <span className="text-text-secondary whitespace-nowrap">
          {sizeMB < 0.1 ? `${Math.max(1, Math.round(file.size / 1024))} КБ` : `${sizeMB.toFixed(1)} МБ`}
        </span>
        {isPDF && (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="text-accent whitespace-nowrap"
          >
            {open ? 'Скрыть' : 'Посмотреть'}
          </button>
        )}
      </div>

      {/* Не-PDF до сервера не доходит (бэкенд принимает только PDF), поэтому
          предупреждаем здесь, пока ошибку легко исправить. */}
      {!isPDF && (
        <div className="px-2 pb-1.5 text-[11px] text-danger">
          Это не PDF — документ принимается только в формате PDF.
        </div>
      )}

      {open && isPDF && (
        <div className="border-t border-border">
          <object data={url} type="application/pdf" className="w-full h-80">
            {/* Фолбэк, если встроенного просмотрщика PDF в браузере нет. */}
            <div className="p-3 text-xs text-text-secondary">
              Встроенный просмотрщик PDF недоступен в этом браузере.{' '}
              <a href={url} target="_blank" rel="noreferrer" className="text-accent">
                Открыть файл в новой вкладке
              </a>
            </div>
          </object>
        </div>
      )}
    </div>
  )
}
