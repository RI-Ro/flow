import React, { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '../api/client'
import Icon from '../components/Icon'

// #10 — Технический дашборд состояния системы («как grafana+prometheus»).
//
// Страница ПЛОТНАЯ намеренно: смысл такого экрана в том, чтобы одним взглядом
// увидеть всё состояние системы, не скроллясь и не переключая вкладки. Поэтому
// числа мелкие и в сетке, а не крупные карточки с воздухом, как на личном
// дашборде.
//
// Графики нарисованы ИНЛАЙНОВЫМ SVG, без библиотек. Причина не только в
// отсутствии сети для npm install: спарклайн и горизонтальная шкала — это
// десяток строк path/rect, а recharts/chart.js тянут за собой несколько сотен
// килобайт и собственную систему тем, которую пришлось бы ещё и приводить к
// токенам проекта.

const STATUS_LABELS = {
  draft: 'Черновики',
  on_approval_hierarchy: 'Согласование (иерархия)',
  on_approval_cross_dept: 'Согласование (межвед.)',
  on_signing: 'На подписи',
  signed: 'Подписаны',
  sent: 'Отправлены',
  in_progress: 'В работе',
  executed: 'Исполнены',
  archived: 'В архиве',
  rejected: 'Отклонены',
}

// Цвет статуса — смысловой, а не «следующий из палитры»: отклонённое красным,
// ожидающее жёлтым, завершённое зелёным. Иначе на составной полосе цвета
// ничего не сообщают.
const STATUS_COLORS = {
  draft: 'var(--color-text-secondary)',
  on_approval_hierarchy: 'var(--color-warning)',
  on_approval_cross_dept: 'var(--color-warning)',
  on_signing: 'var(--color-accent-2)',
  signed: 'var(--color-accent-2)',
  sent: 'var(--color-accent)',
  in_progress: 'var(--color-accent)',
  executed: 'var(--color-success)',
  archived: 'var(--color-text-secondary)',
  rejected: 'var(--color-danger)',
}

const ASSIGNMENT_LABELS = {
  open: 'Открыты',
  in_progress: 'В работе',
  done: 'Исполнены',
  completed: 'Исполнены',
  cancelled: 'Отменены',
  canceled: 'Отменены',
}

const STAGE_STATUS_LABELS = {
  pending: 'Ожидает',
  approved: 'Согласовано',
  rejected: 'Отклонено',
  skipped: 'Пропущено',
  blocked: 'Заблокировано',
}

const STAGE_TYPE_LABELS = {
  hierarchy: 'по иерархии',
  cross_dept: 'межведомственное',
  signing: 'подпись',
}

const INDEX_LABELS = {
  indexed: 'Проиндексировано',
  pending: 'В очереди',
  empty: 'Без текста (скан)',
  failed: 'Ошибки',
}

const INDEX_COLORS = {
  indexed: 'var(--color-success)',
  pending: 'var(--color-warning)',
  empty: 'var(--color-text-secondary)',
  failed: 'var(--color-danger)',
}

const REFRESH_MS = 30000

function fmtInt(n) {
  // Разряды неразрывным пробелом: «60 007» читается с одного взгляда, а
  // «60007» на мелком шрифте приходится пересчитывать глазами.
  if (n === null || n === undefined) return '—'
  return Number(n).toLocaleString('ru-RU').replace(/\s/g, ' ')
}

function fmtBytes(n) {
  if (!n) return '0 МБ'
  return `${(n / 1048576).toFixed(1)} МБ`
}

function fmtUptime(sec) {
  if (!sec && sec !== 0) return '—'
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  if (d > 0) return `${d} д ${h} ч ${m} мин`
  if (h > 0) return `${h} ч ${m} мин`
  return `${m} мин ${sec % 60} с`
}

function fmtDay(iso) {
  if (!iso) return ''
  const [, mm, dd] = iso.split('-')
  return `${dd}.${mm}`
}

// Panel — секция дашборда. Рамка + заголовок + необязательная подпись справа
// (её используем под пояснение «откуда цифра»).
function Panel({ title, hint, right, children, className = '' }) {
  return (
    <div className={`surface-1 p-3 ${className}`}>
      <div className="flex items-baseline gap-2 mb-2">
        <h2 className="text-sm font-medium shrink-0">{title}</h2>
        {hint ? <span className="kicker truncate">{hint}</span> : null}
        {right ? <div className="ml-auto shrink-0">{right}</div> : null}
      </div>
      {children}
    </div>
  )
}

// Tile — одно число. Компактнее StatCard личного дашборда: здесь их двадцать,
// а не пять.
function Tile({ label, value, sub, color, danger }) {
  return (
    <div className="bg-surface-alt border border-border rounded-md px-2.5 py-2 min-w-0">
      <div
        className={`font-display text-2xl leading-tight font-semibold tabular-nums truncate ${danger ? 'text-danger' : ''}`}
        style={!danger && color ? { color } : undefined}
        title={String(value)}
      >
        {value}
      </div>
      <div className="text-[11px] leading-tight text-text-secondary mt-0.5">{label}</div>
      {sub ? <div className="kicker mt-0.5 truncate">{sub}</div> : null}
    </div>
  )
}

// Sparkline — спарклайн «создано документов по дням» (инлайн SVG).
//
// viewBox в условных единицах + preserveAspectRatio="none": так график
// растягивается на всю ширину панели при любом размере окна, и нам не нужно
// измерять контейнер через ResizeObserver.
function Sparkline({ points, height = 64 }) {
  const data = points || []
  if (data.length === 0) return <div className="text-text-secondary text-xs">нет данных</div>
  const w = 300
  const h = 100
  const max = Math.max(1, ...data.map((p) => p.count))
  const step = data.length > 1 ? w / (data.length - 1) : w
  const coords = data.map((p, i) => [i * step, h - (p.count / max) * (h - 6) - 3])
  const line = coords.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ')
  const area = `${line} L${w},${h} L0,${h} Z`
  const peak = data.reduce((best, p) => (p.count > best.count ? p : best), data[0])
  return (
    <div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        preserveAspectRatio="none"
        width="100%"
        height={height}
        className="block"
        role="img"
        aria-label="Создано документов по дням"
      >
        <path d={area} fill="var(--color-accent)" opacity="0.14" />
        <path d={line} fill="none" stroke="var(--color-accent)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="flex justify-between kicker mt-1">
        <span>{fmtDay(data[0].day)}</span>
        <span>
          макс {fmtInt(peak.count)} ({fmtDay(peak.day)})
        </span>
        <span>{fmtDay(data[data.length - 1].day)}</span>
      </div>
    </div>
  )
}

// StackedBar — составная полоса распределения (статусы документов, состояние
// индексации). Нагляднее столбиков: сразу видна доля каждой части в целом.
function StackedBar({ parts, total }) {
  const sum = total || parts.reduce((s, p) => s + p.count, 0)
  if (!sum) return <div className="h-2.5 rounded bg-surface-alt" />
  return (
    <div className="flex h-2.5 rounded overflow-hidden bg-surface-alt">
      {parts
        .filter((p) => p.count > 0)
        .map((p) => (
          <div
            key={p.key}
            style={{ width: `${(p.count / sum) * 100}%`, background: p.color }}
            title={`${p.label}: ${fmtInt(p.count)}`}
          />
        ))}
    </div>
  )
}

// BarList — горизонтальные полосы с подписями и числами. Основной способ
// показать разрез «по статусам»: читается как таблица, но доли видны сразу.
function BarList({ rows, max }) {
  const top = max || Math.max(1, ...rows.map((r) => r.count))
  if (rows.length === 0) return <div className="text-text-secondary text-xs">нет данных</div>
  return (
    <div className="space-y-1">
      {rows.map((r) => (
        <div key={r.key} className="flex items-center gap-2 text-xs">
          <span className="w-44 shrink-0 truncate text-text-secondary" title={r.label}>
            {r.label}
          </span>
          <span className="flex-1 h-2 rounded bg-surface-alt overflow-hidden">
            <span
              className="block h-full rounded"
              style={{ width: `${(r.count / top) * 100}%`, background: r.color || 'var(--color-accent)' }}
            />
          </span>
          <span className="w-16 shrink-0 text-right tabular-nums">{fmtInt(r.count)}</span>
        </div>
      ))}
    </div>
  )
}

// Meter — шкала «занято из максимума» для пула соединений и прогресса
// индексации. Цвет переключается по порогам: администратору нужна не точная
// доля, а ответ «всё ли в порядке».
function Meter({ value, max, label, invert }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0
  let color = 'var(--color-success)'
  if (invert) {
    if (pct > 50) color = 'var(--color-warning)'
    if (pct > 85) color = 'var(--color-danger)'
  } else if (pct < 100) {
    color = 'var(--color-warning)'
  }
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-text-secondary truncate">{label}</span>
        <span className="tabular-nums shrink-0">{pct.toFixed(0)}%</span>
      </div>
      <div className="h-2 rounded bg-surface-alt overflow-hidden">
        <div className="h-full rounded" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  )
}

export default function AdminDashboardPage() {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [lastAt, setLastAt] = useState(null)
  // Защита от наложения ответов: при автообновлении раз в 30 секунд медленный
  // предыдущий ответ может прийти после нового и «откатить» показания назад.
  const seqRef = useRef(0)

  const load = useCallback(() => {
    const seq = ++seqRef.current
    setLoading(true)
    api
      .getAdminMetrics()
      .then((d) => {
        if (seq !== seqRef.current) return
        setData(d)
        setError('')
        setLastAt(new Date())
      })
      .catch((e) => {
        if (seq !== seqRef.current) return
        setError(e.message)
      })
      .finally(() => {
        if (seq === seqRef.current) setLoading(false)
      })
  }, [])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    if (!autoRefresh) return undefined
    const t = setInterval(load, REFRESH_MS)
    return () => clearInterval(t)
  }, [autoRefresh, load])

  if (!data && error) return <div className="p-6 text-danger">{error}</div>
  if (!data) return <div className="p-6 text-text-secondary">Загрузка метрик…</div>

  const docs = data.documents || {}
  const people = data.people || {}
  const loadInfo = data.load || {}
  const idx = data.indexer || {}
  const asg = data.assignments || {}
  const stages = data.stages || {}
  const prints = data.prints || {}
  const rls = data.rls_scoped || {}
  const rt = data.runtime || {}
  const pool = data.db_pool || {}

  const statusMap = Object.fromEntries((docs.by_status || []).map((x) => [x.key, x.count]))
  const statusRows = Object.keys(STATUS_LABELS).map((key) => ({
    key,
    label: STATUS_LABELS[key],
    count: statusMap[key] || 0,
    color: STATUS_COLORS[key],
  }))
  const onApproval = (statusMap.on_approval_hierarchy || 0) + (statusMap.on_approval_cross_dept || 0)

  const indexRows = ['indexed', 'pending', 'empty', 'failed'].map((key) => ({
    key,
    label: INDEX_LABELS[key],
    count: idx[key] || 0,
    color: INDEX_COLORS[key],
  }))

  const asgRows = (asg.by_status || []).map((x) => ({
    key: x.key || '—',
    label: ASSIGNMENT_LABELS[x.key] || x.key || 'без статуса',
    count: x.count,
    color: x.key === 'done' || x.key === 'completed' ? 'var(--color-success)' : 'var(--color-accent)',
  }))

  const stageRows = (stages.by_status || []).map((x) => ({
    key: `${x.status}/${x.stage_type}`,
    label: `${STAGE_STATUS_LABELS[x.status] || x.status} · ${STAGE_TYPE_LABELS[x.stage_type] || x.stage_type}`,
    count: x.count,
    color: x.status === 'pending' ? 'var(--color-warning)' : x.status === 'rejected' ? 'var(--color-danger)' : 'var(--color-success)',
  }))

  // «Не зарегистрировано в бумажном журнале» — ключевая цифра блока печати:
  // распечатанный, но не внесённый в журнал экземпляр считается утраченным
  // из учёта, поэтому она подсвечивается красным при любом значении > 0.
  const unregPct = prints.d30 > 0 ? Math.round((prints.d30_unregistered / prints.d30) * 100) : 0

  return (
    <div className="p-4 max-w-[140rem] mx-auto">
      {/* --- Шапка: заголовок, время снятия, управление автообновлением --- */}
      <div className="flex items-center flex-wrap gap-3 mb-3">
        <div>
          <h1 className="font-display text-xl font-semibold leading-tight">Состояние системы</h1>
          <div className="kicker">// метрики СЭД, обновление раз в {REFRESH_MS / 1000} с</div>
        </div>
        <div className="ml-auto flex items-center gap-3 text-xs">
          <span className="text-text-secondary tabular-nums">
            снято: {lastAt ? lastAt.toLocaleTimeString('ru-RU') : '—'}
          </span>
          <label className="flex items-center gap-1.5 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="accent-[var(--color-accent)]"
            />
            <span>автообновление</span>
          </label>
          <button
            type="button"
            onClick={load}
            disabled={loading}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-border hover:bg-surface-alt disabled:opacity-50"
          >
            <Icon name="reset" size={13} />
            обновить
          </button>
        </div>
      </div>

      {/* Ошибка обновления НЕ затирает уже показанные цифры: при автообновлении
          разовый сбой сети иначе превращал бы всю страницу в сообщение. */}
      {error ? (
        <div className="mb-3 text-xs text-danger border border-danger/40 rounded-md px-3 py-2">
          Последнее обновление не удалось: {error}. Показаны данные от{' '}
          {lastAt ? lastAt.toLocaleTimeString('ru-RU') : '—'}.
        </div>
      ) : null}

      {/* --- Ключевые числа --- */}
      <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-2 mb-3">
        <Tile label="Всего документов" value={fmtInt(docs.total)} color="var(--color-accent)" />
        <Tile label="На согласовании" value={fmtInt(onApproval)} color="var(--color-warning)" />
        <Tile label="На подписи" value={fmtInt(statusMap.on_signing || 0)} color="var(--color-accent-2)" />
        <Tile label="В работе" value={fmtInt(statusMap.in_progress || 0)} />
        <Tile label="Исполнено" value={fmtInt(statusMap.executed || 0)} color="var(--color-success)" />
        <Tile label="В архиве" value={fmtInt(statusMap.archived || 0)} />
        <Tile
          label="Пользователей"
          value={fmtInt(people.users_active)}
          sub={`всего ${fmtInt(people.users_total)} · с ролями ${fmtInt(people.users_with_roles)}`}
        />
        <Tile
          label="Подразделений"
          value={fmtInt(people.departments_active)}
          sub={`всего ${fmtInt(people.departments_total)}`}
        />
      </div>

      {/* --- Нагрузка + распределение по статусам --- */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 mb-3">
        <Panel
          title="Создано документов"
          hint="// по document_access(author)"
          className="xl:col-span-2"
          right={
            <div className="flex gap-2">
              <span className="text-xs text-text-secondary">
                7 дней: <b className="text-text-primary tabular-nums">{fmtInt(loadInfo.created_7d)}</b>
              </span>
              <span className="text-xs text-text-secondary">
                30 дней: <b className="text-text-primary tabular-nums">{fmtInt(loadInfo.created_30d)}</b>
              </span>
            </div>
          }
        >
          <Sparkline points={loadInfo.per_day} />
        </Panel>

        <Panel title="По статусам" hint={`Всего ${fmtInt(docs.total)}`}>
          <StackedBar
            parts={statusRows}
            total={docs.total}
          />
          <div className="mt-2">
            <BarList rows={statusRows} />
          </div>
        </Panel>
      </div>

      {/* --- Очередь индексации, пул БД + процесс --- */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 mb-3">
        <Panel
          title="Индексация содержимого PDF"
          hint="// document_file_text"
          right={
            <span className={`text-xs tabular-nums ${idx.complete ? 'text-success' : 'text-warning'}`}>
              {idx.complete ? 'очередь пуста' : `${fmtInt(idx.pending)} в очереди`}
            </span>
          }
        >
          <Meter value={idx.percent || 0} max={100} label={`обработано ${idx.percent || 0}% из ${fmtInt(idx.total)}`} />
          <div className="mt-2">
            <StackedBar parts={indexRows} total={idx.total} />
          </div>
          <div className="mt-2">
            <BarList rows={indexRows} />
          </div>
          {idx.failed > 0 ? (
            <div className="kicker text-danger mt-2">
              // есть неудачные: поиск по содержимому неполный
            </div>
          ) : null}
        </Panel>

        <Panel title="Пул соединений PostgreSQL" hint="// pgxpool.Stat()">
          <Meter value={pool.total || 0} max={pool.max || 1} label={`занято пулом ${fmtInt(pool.total)} из ${fmtInt(pool.max)}`} invert />
          <div className="grid grid-cols-3 gap-2 mt-2">
            <Tile label="Занято" value={fmtInt(pool.acquired)} />
            <Tile label="Простаивает" value={fmtInt(pool.idle)} />
            <Tile label="Создаётся" value={fmtInt(pool.constructing)} />
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2">
            <Tile label="Захватов" value={fmtInt(pool.acquires)} />
            <Tile
              label="Ждали соединения"
              value={fmtInt(pool.empty_acquires)}
              danger={pool.empty_acquires > 0}
              sub="пул был пуст"
            />
            <Tile label="Отменено" value={fmtInt(pool.canceled_acquires)} />
          </div>
          <div className="kicker mt-2">
            // суммарное ожидание: {Number(pool.acquire_wait_seconds || 0).toFixed(2)} с
          </div>
        </Panel>

        <Panel title="Процесс бэкенда" hint={`// ${rt.go_version || ''}`}>
          <div className="grid grid-cols-2 gap-2">
            <Tile label="Аптайм" value={fmtUptime(rt.uptime_seconds)} color="var(--color-accent-2)" />
            <Tile label="Горутин" value={fmtInt(rt.goroutines)} />
            <Tile label="Heap" value={fmtBytes(rt.heap_bytes)} sub={`sys ${fmtBytes(rt.sys_bytes)}`} />
            <Tile label="Циклов GC" value={fmtInt(rt.gc_cycles)} sub={`CPU ${fmtInt(rt.num_cpu)}`} />
          </div>
          <div className="kicker mt-2 truncate" title={data.generated_at}>
            // срез снят сервером: {data.generated_at}
          </div>
        </Panel>
      </div>

      {/* --- Поручения, этапы маршрута, печать --- */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 mb-3">
        <Panel
          title="Поручения"
          hint="// assignments (без RLS — цифры общесистемные)"
          right={
            asg.overdue > 0 ? (
              <span className="text-xs text-danger">просрочено {fmtInt(asg.overdue)}</span>
            ) : (
              <span className="text-xs text-success">просрочек нет</span>
            )
          }
        >
          <div className="grid grid-cols-2 gap-2 mb-2">
            <Tile label="Всего поручений" value={fmtInt(asg.total)} />
            <Tile label="Просрочено" value={fmtInt(asg.overdue)} danger={asg.overdue > 0} sub="срок прошёл, не исполнено" />
          </div>
          <BarList rows={asgRows} />
        </Panel>

        <Panel
          title="Этапы согласования и подписания"
          hint="// approval_stages (без RLS)"
          right={<span className="text-xs text-text-secondary">ожидает решения: {fmtInt(stages.pending)}</span>}
        >
          <BarList rows={stageRows} />
        </Panel>

        <Panel
          title="Выдачи на печать"
          hint="// document_prints"
          right={
            prints.d30_unregistered > 0 ? (
              <span className="text-xs text-danger">{unregPct}% без журнала</span>
            ) : (
              <span className="text-xs text-success">все учтены</span>
            )
          }
        >
          <div className="grid grid-cols-2 gap-2">
            <Tile label="За 7 дней" value={fmtInt(prints.d7)} />
            <Tile
              label="Из них без журнала"
              value={fmtInt(prints.d7_unregistered)}
              danger={prints.d7_unregistered > 0}
            />
            <Tile label="За 30 дней" value={fmtInt(prints.d30)} />
            <Tile
              label="Из них без журнала"
              value={fmtInt(prints.d30_unregistered)}
              danger={prints.d30_unregistered > 0}
            />
          </div>
          <div className="mt-2">
            <Meter
              value={prints.d30_unregistered || 0}
              max={prints.d30 || 1}
              label="не зарегистрировано в бумажном журнале за 30 дней"
              invert
            />
          </div>
          <div className="kicker mt-2">
            // за всё время: {fmtInt(prints.total)} выдач, без журнала {fmtInt(prints.unregistered)}
          </div>
        </Panel>
      </div>

      {/* --- Блок с оговоркой про RLS ---
          Отдельная панель, а не тайлы вместе с остальными: эти два числа
          считаются под RLS текущего администратора (обхода RLS для роли admin
          в системе нет), то есть они НЕ общесистемные. Смешивать их с
          общесистемными цифрами выше означало бы показать администратору
          заниженное значение без всякого предупреждения. */}
      <Panel
        title="Просрочка и контроль по документам"
        hint="// documents под RLS — НЕ общесистемные цифры"
        right={<span className="text-xs text-warning">ограничено правами доступа</span>}
      >
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <Tile
            label="Просроченные документы"
            value={fmtInt(rls.overdue_documents)}
            danger={rls.overdue_documents > 0}
          />
          <Tile label="Документы на контроле" value={fmtInt(rls.on_control_documents)} color="var(--color-warning)" />
        </div>
        <div className="text-[11px] text-text-secondary mt-2 leading-snug">
          {rls.note ||
            'Считается под RLS текущего администратора: видны только доступные ему документы, а не все в системе.'}
        </div>
      </Panel>
    </div>
  )
}
