import React, { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import Icon from '../components/Icon'
import { fmtDateTime, fmtDate, docYears } from '../utils/format'

const KIND_TABS = [
  { id: 'outgoing', label: 'Исходящие' },
  { id: 'incoming', label: 'Входящие' },
  { id: 'printed_outgoing', label: 'Распечатанные исходящие' },
  { id: 'printed_incoming', label: 'Распечатанные входящие' },
  { id: 'control', label: 'На контроле' },
  { id: 'all', label: 'Сводный' },
]
const STATUS_LABELS = {
  draft: 'Черновик', on_approval_hierarchy: 'Согласование', on_approval_cross_dept: 'Согласование',
  on_signing: 'На подписи', signed: 'Подписан', sent: 'Направлен', in_progress: 'В работе',
  executed: 'Исполнен', archived: 'Архив', rejected: 'Отклонён',
}
const STATUS_COLORS = {
  draft: 'text-text-secondary', on_approval_hierarchy: 'text-warning', on_approval_cross_dept: 'text-warning',
  on_signing: 'text-warning', signed: 'text-accent', sent: 'text-accent', in_progress: 'text-accent-2',
  executed: 'text-success', archived: 'text-text-secondary', rejected: 'text-danger',
}
// Подсветка всей строки: срочно — оттенок оранжевого, вне очереди — оттенок красного.
// Журнал/реестр документов: официальная таблица со всеми реквизитами —
// исходящий номер с датой подписи, все входящие номера (по подразделениям, с
// датой регистрации), краткое содержание, согласующие с датами, рассылка с
// ФИО/должностью/подразделением. Выгрузка в Excel.
// PeopleCell — компактная ячейка журнала для длинных списков (согласующие,
// рассылка, печать). Показывает количество; полный список раскрывается по клику
// (native <details>), поэтому колонка не «распухает» по ширине и высоте (#7).
function PeopleCell({ count, items, label = 'чел.' }) {
  if (!count) return <span>—</span>
  return (
    <details className="w-40">
      <summary className="cursor-pointer select-none text-accent">{count} {label}</summary>
      <div className="mt-1 space-y-0.5 max-h-48 overflow-auto">{items}</div>
    </details>
  )
}

export default function RegistryPage() {
  const { kind = 'outgoing' } = useParams()
  const isPrinted = kind === 'printed_outgoing' || kind === 'printed_incoming'
  const navigate = useNavigate()
  const [rows, setRows] = useState([])
  // #9 — сколько всего документов подходит под журнал (сервер отдаёт порцией)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const now = new Date().getFullYear()
  const [year, setYear] = useState('') // '' = все годы
  const [searchInput, setSearchInput] = useState('')
  const [query, setQuery] = useState('') // применённый поиск (debounce)
  const [categoryId, setCategoryId] = useState('') // #6 — фильтр по категории
  // #26 — фильтр по особой отметке: требование «участвует во всех фильтрах».
  const [specialMarkId, setSpecialMarkId] = useState('')
  const [marks, setMarks] = useState([])
  const [categories, setCategories] = useState([])
  const YEARS = docYears()

  useEffect(() => { api.listCategories().then((r) => setCategories(r.items || [])).catch(() => {}) }, [])
  // #26 — справочник особых отметок для фильтра журнала.
  useEffect(() => { api.getSpecialMarks().then((r) => setMarks(r.items || [])).catch(() => {}) }, [])

  useEffect(() => {
    const t = setTimeout(() => setQuery(searchInput.trim()), 350)
    return () => clearTimeout(t)
  }, [searchInput])

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const res = await api.getRegistry(kind, year, query, categoryId, specialMarkId)
      setRows(res.items || [])
      setTotal(res.total_count ?? (res.items || []).length)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [kind, year, query, categoryId, specialMarkId])

  useEffect(() => { load() }, [load])

  return (
    <div className="p-4 w-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display text-xl font-semibold">Журналы документов</h1>
        <div className="flex items-center gap-2">
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Поиск: наименование, номер, автор…"
            className="field w-64"
          />
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="field"
          >
            <option value="">Все категории</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          {/* #26 — особая отметка */}
          <select
            value={specialMarkId}
            onChange={(e) => setSpecialMarkId(e.target.value)}
            className="field"
          >
            <option value="">Все особые отметки</option>
            {marks.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <select
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="field"
          >
            <option value="">Все годы</option>
            {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <button
            onClick={() => api.downloadRegistryCsv(kind, year, query, categoryId, specialMarkId).catch((e) => setError(e.message))}
            className="btn btn-secondary hover:bg-surface-alt"
          >
            Выгрузить в Excel
          </button>
        </div>
      </div>

      <div className="flex gap-1 mb-4 border-b border-border">
        {KIND_TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => navigate(`/registry/${t.id}`)}
            className={`px-4 py-2 text-sm border-b-2 -mb-px ${
              t.id === kind ? 'border-accent text-accent' : 'border-transparent text-text-secondary'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      {/* #9 — сколько записей показано и сколько их всего. Журнал отдаётся
          порцией (LIMIT 2000), поэтому без этой строки нельзя было понять,
          видишь ты весь журнал или его начало. */}
      <div className="kicker mb-2">
        Показано {rows.length} из {total}
        {total > rows.length && ' — показано не всё, уточните фильтры или выгрузите журнал в Excel'}
      </div>

      <div className="surface-1 overflow-x-auto">
        <table className="w-full text-sm align-top">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border thead-sticky">
              <th className="px-3 py-2 font-medium">Готовность</th>
              <th className="px-3 py-2 font-medium">№ исх. / дата подписи</th>
              <th className="px-3 py-2 font-medium">№ вх. (подразделение, регистрация)</th>
              <th className="px-3 py-2 font-medium">Подписант</th>
              <th className="px-3 py-2 font-medium">Краткое наименование / содержание</th>
              <th className="px-3 py-2 font-medium">Статус</th>
              <th className="px-3 py-2 font-medium">Автор</th>
              <th className="px-3 py-2 font-medium">Согласующие</th>
              <th className="px-3 py-2 font-medium">Рассылка</th>
              <th className="px-3 py-2 font-medium">Печать / учёт в журнале</th>
              {isPrinted && <th className="px-3 py-2 font-medium">Скачиваний</th>}
              {isPrinted && <th className="px-3 py-2 font-medium">Зарегистрировано</th>}
              {isPrinted && <th className="px-3 py-2 font-medium">Печатали (чел.)</th>}
              {isPrinted && <th className="px-3 py-2 font-medium">Последняя печать</th>}
              {/* #17 — комментарии и вложения: видно из журнала */}
              <th className="px-3 py-2 font-medium" title="Комментарии и вложенные файлы">Обсуждение</th>
              <th className="px-3 py-2 font-medium">Создан</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={13} className="px-3 py-6 text-center text-text-secondary">Загрузка…</td></tr>
            )}
            {!loading && rows.length === 0 && (
              <tr><td colSpan={13} className="px-3 py-6 text-center text-text-secondary">Журнал пуст</td></tr>
            )}
            {!loading && rows.map((r) => (
              <tr
                key={r.id}
                onClick={() => navigate(`/document/${r.id}`)}
                className="border-b border-border last:border-0 cursor-pointer align-top row-hover"
              >
                {/* Готовность (с временем) */}
                <td className="px-3 py-2 text-xs whitespace-nowrap nums">
                  {r.due_datetime ? fmtDateTime(r.due_datetime) : fmtDate(r.due_date)}
                </td>
                {/* № исх. / дата подписи */}
                <td className="px-3 py-2 font-mono text-xs">
                  {r.outgoing_number || '—'}
                  {r.signed_at && <div className="text-text-secondary">{fmtDateTime(r.signed_at)}</div>}
                </td>
                {/* № вх. — компактно (кол-во + раскрытие) */}
                <td className="px-3 py-2 text-xs align-top">
                  <PeopleCell
                    count={(r.incoming_numbers || []).length}
                    label="вх."
                    items={(r.incoming_numbers || []).map((i, idx) => (
                      <div key={idx} className="font-mono">
                        {i.number}
                        <span className="text-text-secondary font-sans"> — {i.department}{i.registered_at ? `, ${fmtDateTime(i.registered_at)}` : ''}</span>
                      </div>
                    ))}
                  />
                </td>
                {/* Подписант */}
                <td className="px-3 py-2 text-text-secondary text-xs">{r.signer_name || '—'}</td>
                {/* Краткое наименование / содержание */}
                <td className="px-3 py-2 max-w-[34rem]">
                  <div className="font-medium text-text-primary">{r.title}</div>
                  {r.body_summary && <div className="text-text-secondary text-xs line-clamp-2">{r.body_summary}</div>}
                </td>
                {/* Статус (цветом) */}
                <td className={`px-3 py-2 font-medium ${STATUS_COLORS[r.status] || 'text-text-secondary'}`}>{STATUS_LABELS[r.status] || r.status}</td>
                {/* Автор */}
                <td className="px-3 py-2 text-text-secondary text-xs">{r.author_name}</td>
                {/* Согласующие — компактно (число + раскрытие) */}
                <td className="px-3 py-2 text-text-secondary text-xs align-top">
                  <PeopleCell
                    count={(r.approvers || []).length}
                    items={(r.approvers || []).map((a, idx) => (
                      <div key={idx}>
                        {a.fio}{a.position ? ` (${a.position})` : ''}
                        {a.decided_at && <span className="opacity-70"> — {fmtDateTime(a.decided_at)}</span>}
                      </div>
                    ))}
                  />
                </td>
                {/* Рассылка — компактно */}
                <td className="px-3 py-2 text-text-secondary text-xs align-top">
                  <PeopleCell
                    count={(r.recipients || []).length}
                    items={(r.recipients || []).map((rc, idx) => (
                      <div key={idx}>{rc.fio}{rc.position ? `, ${rc.position}` : ''}{rc.department ? `, ${rc.department}` : ''}</div>
                    ))}
                  />
                </td>
                {/* Печать / учёт в журнале — компактно */}
                <td className="px-3 py-2 text-text-secondary text-xs align-top">
                  <PeopleCell
                    count={(r.prints || []).length}
                    label="записей"
                    items={(r.prints || []).map((p, idx) => (
                      <div key={idx}>
                        Экз. № {p.instance || '—'} · Копия № {p.copy} · {p.fio} · распечатано {fmtDateTime(p.printed_at)}
                        {p.reg_at
                          ? ` · журнал «${p.reg_journal}» № ${p.reg_number} от ${fmtDateTime(p.reg_at)}`
                          : ' · не зарегистрирован'}
                      </div>
                    ))}
                  />
                </td>
                {/* #8 — метрики печати (только на вкладках распечатанных) */}
                {isPrinted && <td className="px-3 py-2 text-xs whitespace-nowrap nums">{r.print_count ?? 0}</td>}
                {isPrinted && <td className="px-3 py-2 text-xs whitespace-nowrap nums">{r.print_reg_count ?? 0} из {r.print_count ?? 0}</td>}
                {isPrinted && <td className="px-3 py-2 text-xs whitespace-nowrap nums">{r.print_users ?? 0}</td>}
                {isPrinted && <td className="px-3 py-2 text-text-secondary text-xs whitespace-nowrap nums">{r.last_printed_at ? fmtDateTime(r.last_printed_at) : '—'}</td>}
                {/* #17 — комментарии / вложения (приходят вместе со строкой журнала) */}
                <td className="px-3 py-2 text-xs whitespace-nowrap nums">
                  {(r.message_count > 0 || r.file_count > 0) ? (
                    <span className="inline-flex items-center gap-2 text-text-secondary">
                      {r.message_count > 0 && (
                        <span className="inline-flex items-center gap-0.5" title={`Комментариев: ${r.message_count}`}>
                          <Icon name="dot" size={8} /> {r.message_count}
                        </span>
                      )}
                      {r.file_count > 0 && (
                        <span className="inline-flex items-center gap-0.5" title={`Вложенных файлов: ${r.file_count}`}>
                          <Icon name="paperclip" size={12} /> {r.file_count}
                        </span>
                      )}
                    </span>
                  ) : <span className="text-text-secondary">—</span>}
                </td>
                {/* Создан */}
                <td className="px-3 py-2 text-text-secondary text-xs whitespace-nowrap nums">{fmtDateTime(r.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
