import React, { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import DocumentViewer from '../components/DocumentViewer'
import ChatPanel from '../components/ChatPanel'
import ApprovalPanel from '../components/ApprovalPanel'
import DocumentTabs from '../components/DocumentTabs'
import EditDocumentModal from '../components/EditDocumentModal'
import NotFound from '../components/NotFound'
import { fmtDateTime, fmtDate } from '../utils/format'

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split('.')[1]))
  } catch (_) {
    return null
  }
}

export default function DocumentDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  // #40 — активная вкладка хранится в АДРЕСЕ (?tab=...). Тогда она сохраняется
  // не только при обновлении данных, но и при настоящей перезагрузке страницы
  // (F5), при переходе «назад/вперёд» и при отправке ссылки коллеге.
  const [searchParams, setSearchParams] = useSearchParams()
  const activeTab = searchParams.get('tab') || ''
  const setActiveTab = useCallback((t) => {
    const next = new URLSearchParams(searchParams)
    if (t) next.set('tab', t)
    else next.delete('tab')
    // replace: переключение вкладки не должно засорять историю браузера —
    // иначе «назад» уводило бы по вкладкам вместо возврата к списку.
    setSearchParams(next, { replace: true })
  }, [searchParams, setSearchParams])
  const [doc, setDoc] = useState(null)
  const [myCopy, setMyCopy] = useState(null)
  const [incomingMarking, setIncomingMarking] = useState(null)
  const [marks, setMarks] = useState({ stamps: [], baked: false })
  const [error, setError] = useState('')
  const [editing, setEditing] = useState(false)
  // #40 — РАЗДЕЛЕНИЕ «первая загрузка» и «обновление».
  //
  // Раньше был один флаг loading, и любое действие во вкладке (отметка
  // исполнения, поручение, связь, постановка на контроль) вызывало
  // onChanged → load() → loading=true → страница возвращала «Загрузка…».
  // При этом ВСЁ поддерево, включая панель вкладок, размонтировалось, и при
  // повторном монтировании активная вкладка сбрасывалась на первую. Внешне
  // это и выглядело как перезагрузка страницы с перебросом на первую вкладку.
  //
  // Теперь «Загрузка…» вместо содержимого показывается только пока документа
  // ещё нет (первый вход). Обновление данных ничего не размонтирует — меняется
  // только неброский индикатор в заголовке.
  const [firstLoad, setFirstLoad] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [roles, setRoles] = useState(null) // #8 — для кнопки «В архив» (автор/подписант)

  const currentUserId = (() => {
    const token = localStorage.getItem('sed_token')
    const payload = token ? parseJwt(token) : null
    return payload?.uid
  })()

  const load = useCallback(async () => {
    setRefreshing(true)
    setError('')
    try {
      // Ответ { document, incoming_marking } — второе поле заполняется
      // бэкендом при регистрации входящего экземпляра (первый просмотр
      // получателем), см. IncomingService.RegisterView.
      const res = await api.getDocument(id)
      setDoc(res.document)
      setIncomingMarking(res.incoming_marking)
      setMyCopy(res.my_copy_number ?? null)
      // Маркировка (штампы по конфигу). Если бэкенд вжигает штампы в PDF —
      // baked=true и overlay на фронте не рисуем.
      api.getDocumentMarking(id).then(setMarks).catch(() => setMarks({ stamps: [], baked: false }))
      api.getMyRoles(id).then(setRoles).catch(() => setRoles(null))
    } catch (err) {
      setError(err.message || 'Документ не найден или недоступен')
    } finally {
      setRefreshing(false)
      setFirstLoad(false)
    }
  }, [id])

  useEffect(() => {
    load()
  }, [load])

  // #16 — Живое обновление открытой карточки: только по событиям про ЭТОТ
  // документ (иначе чужая активность перезагружала бы карточку впустую).
  // Благодаря #40 обновление уже ничего не размонтирует, поэтому активная
  // вкладка при этом не теряется.
  useEffect(() => {
    let timer = null
    function onChanged(e) {
      if (String(e.detail?.document_id) !== String(id)) return
      clearTimeout(timer)
      timer = setTimeout(load, 700)
    }
    window.addEventListener('sed:document_changed', onChanged)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('sed:document_changed', onChanged)
    }
  }, [id, load])

  // Содержимое подменяем ТОЛЬКО когда документа ещё нет. Иначе любое
  // обновление размонтировало бы панель вкладок (#40).
  if (firstLoad && !doc) return <div className="p-6 text-text-secondary">Загрузка…</div>
  // Экран 404 — только если документа нет вовсе. Ошибка при ОБНОВЛЕНИИ уже
  // открытого документа (сеть мигнула, сервер перезапустился) не должна
  // подменять карточку на «не найдено» и терять то, что пользователь делал:
  // она показывается полоской в заголовке (#40).
  if (!doc) {
    if (error) return <NotFound />
    return null
  }

  const preSigned = !['signed', 'sent', 'in_progress', 'executed', 'archived'].includes(doc.status)

  // Маркировка — исходящий номер/место хранения (после подписания) плюс,
  // если применимо, номер входящего экземпляра (после регистрации у
  // получателя). Оба слоя показываются overlay поверх вьювера, не
  // "вшиваются" в сам PDF (см. архитектурную спецификацию, п.4.3).
  const markingLines = []
  if (doc.outgoing_number) {
    markingLines.push(doc.outgoing_number)
    markingLines.push(`СЭД / Архив ${new Date(doc.created_at).getFullYear()}`)
  }
  if (incomingMarking) {
    markingLines.push(`${incomingMarking.incoming_number} · ${incomingMarking.instance_label}`)
  }
  const marking = markingLines.length ? markingLines.join('\n') : null
  // #3 — уведомление о факте фиксации первого ознакомления (показываем, когда
  // получателю зарегистрирован входящий экземпляр — это и есть момент фиксации).
  const firstViewNotice = incomingMarking
    ? `Зафиксирован факт первого ознакомления с документом. Присвоен входящий № ${incomingMarking.incoming_number}${incomingMarking.instance_label ? ` (${incomingMarking.instance_label})` : ''}.`
    : null

  return (
    <div className="h-[calc(100vh-56px)] flex flex-col">
      <div className="px-6 py-4 border-b border-border bg-surface flex items-start justify-between gap-4">
        <div>
          <button className="text-accent text-sm mb-1" onClick={() => navigate(-1)}>
            ← Назад к списку
          </button>
          <h1 className="font-display text-lg font-semibold">
            {doc.title}
            {/* #40 — обновление данных больше не подменяет страницу; вместо
                этого — неброская отметка рядом с заголовком. */}
            {refreshing && (
              <span className="ml-2 text-xs font-normal text-text-secondary align-middle">обновление…</span>
            )}
          </h1>
          {error && (
            <div className="mt-1 text-xs text-danger">
              Не удалось обновить данные: {error}. Показаны последние загруженные.
            </div>
          )}
          <div className="kicker mt-0.5">
            {doc.outgoing_number || `Черновик #${doc.id}`}
            {doc.category_name && ` · категория: ${doc.category_name}`}
            {doc.signed_at && ` · подписан ${fmtDateTime(doc.signed_at)}`}
            {` · создан ${fmtDateTime(doc.created_at)}`}
            {(doc.due_datetime || doc.due_date) &&
              ` · готовность ${doc.due_datetime ? fmtDateTime(doc.due_datetime) : fmtDate(doc.due_date)}`}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {myCopy != null && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-accent/40 bg-accent/10 text-accent" title="Ваш номер экземпляра документа">
              Экз. № {myCopy}
            </span>
          )}
          {doc.on_control && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-danger/40 bg-danger/10 text-danger">
              ● На контроле
            </span>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button onClick={() => setEditing(true)} className="btn btn-secondary">
              Изменить
            </button>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button
              onClick={async () => {
                if (!confirm('Удалить документ безвозвратно?')) return
                try {
                  await api.deleteDocument(doc.id)
                  navigate('/documents/all')
                } catch (e) {
                  alert(e.message)
                }
              }}
              className="btn btn-danger"
            >
              Удалить
            </button>
          )}
          {/* #8 — В архив: автор или подписант, только исполненный документ. */}
          {doc.status === 'executed' && (roles?.is_author || roles?.is_signer) && (
            <button
              onClick={async () => {
                if (!confirm('Направить документ в архив?')) return
                try {
                  await api.archiveDocument(doc.id)
                  await load()
                } catch (e) {
                  alert(e.message)
                }
              }}
              className="btn btn-secondary"
            >
              В архив
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 grid grid-cols-5 gap-4 p-4 min-h-0">
        <div className="col-span-3 min-h-0 flex flex-col gap-2">
          {/* #3 — уведомление о фиксации первого ознакомления */}
          {firstViewNotice && (
            <div className="bg-accent/10 border border-accent/40 text-accent rounded-lg px-3 py-2 text-sm">
              {firstViewNotice}
            </div>
          )}
          {doc.body_summary && (
            <div className="surface-1 p-3 text-sm">
              <div className="label mb-1">Краткое содержание</div>
              <div className="whitespace-pre-wrap">{doc.body_summary}</div>
            </div>
          )}
          <div className="flex-1 min-h-0">
            <DocumentViewer documentId={doc.id} marking={marking} stamps={marks.stamps} />
          </div>
        </div>
        {/* #38 — Обсуждение перенесено В ВКЛАДКУ, поэтому панель вкладок
            занимает всю высоту колонки. Раньше колонка делилась пополам:
            вкладки получали 45% высоты и в них приходилось скроллить даже
            короткий маршрут, а переписка всё равно не помещалась. */}
        <div className="col-span-2 min-h-0 flex flex-col">
          <DocumentTabs
            documentId={doc.id}
            currentUserId={currentUserId}
            docStatus={doc.status}
            doc={doc}
            onChanged={load}
            patchDoc={(p) => setDoc((d) => (d ? { ...d, ...p } : d))}
            routeSlot={
              <ApprovalPanel
                documentId={doc.id}
                currentUserId={currentUserId}
                onChanged={load}
                section="route"
              />
            }
            // #15 — блок решения (согласовать/подписать/отклонить/донаправить)
            // живёт в своей первой вкладке, а не внизу схемы маршрута.
            decisionSlot={
              <ApprovalPanel
                documentId={doc.id}
                currentUserId={currentUserId}
                onChanged={load}
                section="decision"
              />
            }
            chatSlot={<ChatPanel documentId={doc.id} currentUserId={currentUserId} />}
            tab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>
      {editing && (
        <EditDocumentModal
          doc={doc}
          currentUserId={currentUserId}
          onClose={() => setEditing(false)}
          onSaved={load}
        />
      )}
    </div>
  )
}
