# Мониторинг СЭД: Prometheus + Loki + Grafana

Стек наблюдаемости для СЭД: метрики (Prometheus), логи (Loki + promtail),
визуализация и алерты (Grafana). Включается **опционально** — отдельным
compose-файлом, чтобы на машине разработчика не поднимались шесть лишних
контейнеров.

## Запуск

```bash
cd <корень репозитория>
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d
```

Удобно завести алиас, чтобы не писать оба `-f` каждый раз:

```bash
alias dcm='docker compose -f docker-compose.yml -f docker-compose.monitoring.yml'
dcm up -d          # поднять всё вместе с мониторингом
dcm ps             # состояние
dcm logs -f loki   # логи конкретного сервиса
dcm down           # остановить (данные в томах сохранятся)
```

Без второго `-f` поднимается только СЭД — мониторинг не запускается и ничего
не ломает. Это и есть смысл отдельного файла.

Пароль администратора Grafana задаётся переменной окружения (по умолчанию
`admin`):

```bash
GRAFANA_ADMIN_PASSWORD='своё-значение' dcm up -d
```

Либо положить рядом с compose-файлами `.env` со строкой
`GRAFANA_ADMIN_PASSWORD=...` — compose подхватит его автоматически. Файл
`.env` в репозиторий не коммитить.

### Важно про сеть

Отдельная docker-сеть в `docker-compose.monitoring.yml` **не объявлена
намеренно**. При передаче нескольких `-f` compose склеивает файлы в один
проект, поэтому `prometheus` и `app` оказываются в общей сети проекта и видят
друг друга по именам сервисов. Поэтому в конфигах всюду указаны
**внутренние** порты (`app:8080`, `postgres:5432`, `loki:3100`), а не
проброшенные на хост: проброс работает только со стороны хоста.

Из этого следует ограничение: запустить мониторинг отдельным проектом
(`docker compose -f docker-compose.monitoring.yml up`) нельзя — он не найдёт
ни `app`, ни `postgres`.

## Порты

| Сервис | Внутри сети | На хосте | Назначение |
| --- | --- | --- | --- |
| `app` (СЭД) | `app:8080` | 8080 | приложение, `/metrics` |
| `grafana` | `grafana:3000` | **3000** | **дашборды — основная точка входа** |
| `prometheus` | `prometheus:9090` | 9090 | PromQL, вкладки Targets и Alerts |
| `loki` | `loki:3100` | 3100 | API логов (нужен в основном для отладки) |
| `promtail` | `promtail:9080` | — | служебный UI `/targets`, наружу не нужен |
| `postgres-exporter` | `postgres-exporter:9187` | — | метрики СУБД |
| `node-exporter` | `node-exporter:9100` | — | метрики хоста (CPU, память, диск) |

## Где смотреть

* **Grafana — <http://localhost:3000>**, логин `admin`, пароль из
  `GRAFANA_ADMIN_PASSWORD` (по умолчанию `admin`). Дашборд
  **«СЭД — обзор»** в папке **СЭД** открывается сразу после входа.
* Prometheus — <http://localhost:9090>:
  * `/targets` — какие цели опрашиваются и живы ли они;
  * `/alerts` — текущее состояние правил из `alerts.yml`;
  * `/graph` — разовые запросы на PromQL.
* Логи — Grafana → Explore → источник **Loki**. Примеры запросов:

```logql
{job="docker"}                                  # все контейнеры проекта
{job="docker", service="app"}                   # только бэкенд
{job="docker"} | level="error"                  # только ошибки
{job="sed-access-log", status=~"5.."}           # запросы, ответившие 5xx
{job="sed-access-log"} |= "/api/documents"      # поиск по подстроке
```

## Что откуда берётся

| Данные | Источник | Куда идут |
| --- | --- | --- |
| Метрики приложения | бэкенд, `GET /metrics` (пакет `backend/internal/metrics`) | Prometheus, job `sed-backend` |
| Метрики СУБД | `postgres-exporter:9187` | Prometheus, job `postgres` |
| Метрики хоста (диск, CPU, ОЗУ) | `node-exporter:9100` | Prometheus, job `node` |
| Метрики самого мониторинга | `localhost:9090/metrics` | Prometheus, job `prometheus` |
| stdout/stderr контейнеров | docker socket (`docker_sd_configs`) | promtail → Loki |
| Access-лог бэкенда | файл `$ACCESS_LOG_DIR/access.log` | promtail → Loki |

Зачем postgres-exporter, если бэкенд уже отдаёт `sed_db_pool_*`: бэкенд видит
**только свой пул**. Он не знает ни общего числа сессий в СУБД, ни
`max_connections`, ни размера базы. Классический отказ, невидимый без
экспортера: пул бэкенда полупустой, а новые подключения отвергаются, потому
что `max_connections` исчерпали сторонние клиенты.

Зачем node-exporter: при заполнении диска PostgreSQL не «замедляется», а
**перестаёт принимать запись** — СЭД встаёт целиком. Свободное место на ФС не
измеряет ни бэкенд, ни postgres-exporter.

## Файлы

```
deploy/monitoring/
├── prometheus.yml                                  # scrape-конфиг, 4 цели
├── alerts.yml                                      # правила алертов
├── loki-config.yml                                 # Loki, single-binary + filesystem
├── promtail-config.yml                             # сбор docker- и файловых логов
├── README.md
└── grafana/
    ├── dashboards/sed-overview.json                # дашборд «СЭД — обзор»
    └── provisioning/
        ├── datasources/datasources.yml             # Prometheus + Loki
        └── dashboards/dashboards.yml               # подхват дашбордов из каталога

docker-compose.monitoring.yml                       # сами сервисы (в корне репозитория)
```

## Экспортируемые метрики приложения

| Метрика | Тип | Метки |
| --- | --- | --- |
| `sed_http_requests_total` | counter | `method`, `route`, `status` |
| `sed_http_request_duration_seconds` | histogram | `method`, `route` |
| `sed_http_requests_in_flight` | gauge | — |
| `sed_db_pool_connections` | gauge | — (всего соединений) |
| `sed_db_pool_connections_max` | gauge | — (`MaxConns`) |
| `sed_db_pool_connections_state` | gauge | `state` = `acquired`/`idle`/`constructing` |
| `sed_db_pool_acquires_total` | counter | — |
| `sed_db_pool_empty_acquires_total` | counter | — (ждали свободное соединение) |
| `sed_db_pool_canceled_acquires_total` | counter | — |
| `sed_db_pool_acquire_wait_seconds_total` | counter | — |
| `sed_documents` | gauge | `status` |
| `sed_index_queue_length` | gauge | — |
| `sed_index_failed_documents` | gauge | — |
| `sed_process_uptime_seconds` | gauge | — |

Метка `route` — это **шаблон** маршрута (`/api/documents/:id`), а не конкретный
URL. Иначе каждый документ создавал бы отдельный временной ряд, и при 50 000
документов Prometheus получил бы под миллион рядов с учётом бакетов
гистограммы. Запросы, не попавшие ни в один зарегистрированный маршрут
(404, сканеры уязвимостей), сворачиваются в `route="other"`.

Бизнес-метрики `sed_documents`, `sed_index_queue_length` и
`sed_index_failed_documents` **сами себя не заполняют** — пакет `metrics`
намеренно не знает про схему БД и RLS. Их значения нужно периодически
проставлять из прикладного кода:

```go
metrics.SetDocumentsByStatus(map[string]int64{"draft": 10, "on_approval": 4})
metrics.SetIndexQueueLength(int64(st.Pending))
metrics.SetIndexFailed(int64(st.Failed))
```

Пока эти вызовы не добавлены, соответствующие панели дашборда и алерты
`SedIndexQueueGrowing` / `SedIndexFailures` будут пустыми (не ложно-зелёными —
именно пустыми, без данных).

Отдельной гистограммы длительности **запроса к БД**
(`sed_db_query_duration_seconds`) бэкенд сейчас не отдаёт. Панель «Длительность
работы с БД» строится по тому, что есть: среднее время ожидания соединения из
пула и самая долгая открытая транзакция по данным postgres-exporter. Третья
серия на этой панели уже написана под `sed_db_query_duration_seconds` и
заполнится сама, если метрику добавят.

## Алерты

| Алерт | Условие | Severity |
| --- | --- | --- |
| `SedBackendDown` | `up == 0` дольше 1 мин | critical |
| `SedBackendRestarted` | uptime < 2 мин | info |
| `SedHighErrorRate` | >5% 5xx за 5 мин (при >100 запросах) | critical |
| `SedLatencyDegraded` | p95 > 1 с, 10 мин | warning |
| `SedLatencySevere` | p95 > 5 с, 5 мин | critical |
| `SedDBPoolExhausted` | занято >90% пула, 5 мин | warning |
| `SedDBPoolWaiting` | >1 ожидания соединения в секунду, 10 мин | warning |
| `SedPostgresDown` | `pg_up == 0` дольше 1 мин | critical |
| `SedPostgresExporterDown` | экспортер СУБД не отвечает 5 мин | warning |
| `SedPostgresConnectionsLow` | занято >80% `max_connections`, 5 мин | warning |
| `SedPostgresLongTransaction` | транзакция открыта >10 мин | warning |
| `SedDiskFillingUp` | свободно <15% ФС, 10 мин | warning |
| `SedDiskCritical` | свободно <5% ФС, 5 мин | critical |
| `SedDiskWillFillIn24h` | по тренду 6 ч место кончится за сутки | warning |
| `SedHostMemoryPressure` | доступно <10% ОЗУ, 15 мин | warning |
| `SedIndexQueueGrowing` | очередь >500 и растёт час | warning |
| `SedIndexFailures` | +10 ошибок индексации за час | warning |

У каждого правила есть `for`: алерт без выдержки срабатывает на одном
промахнувшемся скрейпе и быстро приучает дежурного игнорировать уведомления.

`alerts.yml` только **вычисляет** алерты. Доставка (почта, Telegram) требует
Alertmanager, которого в этом стеке нет: состояние правил видно в Prometheus →
Alerts и в Grafana. Это осознанное упрощение — Alertmanager добавляется
отдельно, когда появится, куда отправлять.

## Как добавить свой дашборд

1. Собрать панель в UI Grafana (`allowUiUpdates: true` в
   `provisioning/dashboards/dashboards.yml` это разрешает).
2. Dashboard settings → **JSON Model** → скопировать JSON.
3. Сохранить файлом в `deploy/monitoring/grafana/dashboards/<имя>.json`.
4. В JSON обязательно оставить/проставить:
   * **`uid`** — стабильный строковый идентификатор (`"uid": "sed-audit"`).
     Без него при каждом перезапуске создаётся новая копия дашборда;
   * **`"datasource": {"type": "prometheus", "uid": "prometheus"}`** (или
     `"uid": "loki"`) и у панелей, и у каждого target. Эти `uid` жёстко
     заданы в `provisioning/datasources/datasources.yml` — именно поэтому
     дашборд не превращается в «Datasource not found» после пересоздания
     тома Grafana;
   * убрать блок `"__inputs"` и подстановки вида `${DS_PROMETHEUS}`, если
     JSON скачан с grafana.com: провижининг их не раскрывает.
5. Провайдер сканирует каталог раз в 30 с — ждать перезапуска Grafana не
   нужно. Если файл невалиден, Grafana напишет об этом в свой лог:
   `dcm logs grafana | grep -i dashboard`.

Правки дашборда через UI **перетираются файлом** при следующем сканировании —
UI здесь для прототипирования, источник истины — репозиторий.

## Если метрики не собираются

Проверять строго по цепочке, сверху вниз — это быстрее, чем гадать.

**1. Бэкенд вообще отдаёт метрики?**

```bash
curl -s localhost:8080/metrics | head -20
```

Пусто или 404 — проблема не в мониторинге, а в приложении: маршрут `/metrics`
не зарегистрирован.

**2. Что видит Prometheus?**

<http://localhost:9090/targets> — там причина отказа написана словами. Частые
случаи:

| Что в Targets | Причина |
| --- | --- |
| `connection refused` | сервис не поднят, либо указан порт, проброшенный на хост, вместо внутреннего |
| `no such host` | опечатка в имени сервиса, либо мониторинг поднят отдельным проектом и не видит сеть СЭД |
| `context deadline exceeded` | цель отвечает дольше `scrape_timeout` |
| `server returned HTTP status 404` | неверный `metrics_path` |
| цели нет в списке вообще | конфиг не перечитан после правки |

Перечитать конфиг без рестарта (`--web.enable-lifecycle` включён):

```bash
curl -X POST localhost:9090/-/reload
```

**3. Цель `up`, но запрос в Grafana пустой.**

Почти всегда — имя метрики. Проверить, что реально есть:

```bash
curl -s 'localhost:9090/api/v1/label/__name__/values' | tr ',' '\n' | grep sed_
```

Имена метрик postgres-exporter **зависят от его версии** (`pg_stat_activity_count`,
`pg_settings_max_connections` в разных релизах назывались по-разному). Сверить:

```bash
dcm exec postgres-exporter wget -qO- localhost:9187/metrics | grep -E 'activity|max_conn'
```

**4. Панель пуста, хотя метрика есть.** Проверить переменную `$instance`
вверху дашборда: если `relabel_configs` переименовали `instance`, старое
сохранённое значение переменной перестаёт совпадать. Выбрать `All`.

**5. Бизнес-метрики (документы, очередь индексации) пусты.** Это ожидаемо, пока
в прикладном коде не вызываются сеттеры — см. раздел выше.

## Если логи не собираются

**1. Что видит promtail:**

```bash
dcm exec promtail wget -qO- localhost:9080/targets
```

**2. Нет логов контейнеров** (`{job="docker"}` пусто) — обычно недоступен
docker socket. На хостах с SELinux нужен суффикс `:ro,z` в монтировании
`/var/run/docker.sock`; на rootless Docker путь к сокету другой
(`$XDG_RUNTIME_DIR/docker.sock`).

**3. Нет access-лога** (`{job="sed-access-log"}` пусто) — по порядку:

```bash
dcm exec app ls -l /var/log/sed/          # файл вообще создан?
dcm exec promtail ls -l /var/log/sed/     # тот же том виден promtail?
```

Если файла нет у `app` — не задан `ACCESS_LOG_DIR` (он проставляется блоком
`app:` в `docker-compose.monitoring.yml`). Если файл есть у `app`, но не
виден promtail — том `sed_logs` подключён не к обоим сервисам.

**4. Loki отвергает запись.** Смотреть логи promtail: `dcm logs promtail`.
`entry too far behind` означает запись старше `reject_old_samples_max_age`
(неделя) — так бывает при разборе старого файла лога.

**5. Метка `level` всюду `unknown`.** Регулярное выражение в
`promtail-config.yml` рассчитано на префикс `[warn]` (формат `log.Printf`
бэкенда) и на `LOG:`/`ERROR:` PostgreSQL. Если формат строки изменился,
выражение нужно поправить.

## Проверка конфигов без запуска стека

```bash
cd deploy/monitoring
docker run --rm -v "$PWD:/c" --entrypoint promtool prom/prometheus:v2.53.0 \
  check config /c/prometheus.yml
docker run --rm -v "$PWD:/c" --entrypoint promtool prom/prometheus:v2.53.0 \
  check rules /c/alerts.yml
docker run --rm -v "$PWD:/c" grafana/promtail:3.1.1 \
  -config.file=/c/promtail-config.yml -check-syntax
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml config -q
```

## ЧТО НЕ ПРОВЕРЕНО (честно)

Контейнеры в этом окружении **не запускались** — нет сети к реестрам образов.
Проверено только то, что проверяется статически:

* все YAML-файлы (включая `docker-compose.monitoring.yml`) разбираются
  `yaml.safe_load` без ошибок;
* `sed-overview.json` — валидный JSON; у всех 16 панелей есть
  `id`/`type`/`title`/`gridPos`, `id` уникальны, панели не перекрываются по
  сетке, у каждого target есть `refId` и `expr`, у каждого — ссылка на
  источник данных с существующим `uid`;
* имена метрик приложения в дашборде и `alerts.yml` сверены с теми, что
  объявлены в `backend/internal/metrics/metrics.go`;
* имена томов и путей монтирования в `docker-compose.monitoring.yml` сверены
  с путями внутри конфигов.

**Не проверено и требует проверки на живом стенде:**

1. Фактический старт Loki с этим конфигом. Он написан под **Loki 3.x**
   (`schema: v13`, `store: tsdb`). На 2.9.x нужно заменить `tsdb` →
   `boltdb-shipper`, `v13` → `v12`, а ключ `delete_request_store` убрать.
2. Имена метрик **postgres-exporter** (`pg_stat_activity_count`,
   `pg_settings_max_connections`, `pg_stat_activity_max_tx_duration`). Они
   менялись между релизами экспортера; от них зависят три алерта и две
   панели. Сверить сразу после первого запуска (команда — выше).
3. Работа `docker_sd_configs` — зависит от доступности `/var/run/docker.sock`
   внутри контейнера promtail и прав на него (SELinux, rootless Docker).
4. Разбор метки `level` в `promtail-config.yml`: регулярное выражение и
   шаблоны проверялись только по виду строк в исходниках, не на живом потоке.
5. Совместимость `schemaVersion: 39` с конкретной версией Grafana. Дашборд
   писался под Grafana 11.x; тип панели `table` и `transformations`
   исторически менялись чаще остальных.
6. `user: "10001:10001"` у Loki и права на именованный том: при первом
   запуске том создаётся с владельцем root, и Loki может не получить права на
   запись. Если упадёт с `permission denied` — поправить владельца тома.
7. Фактические значения порогов алертов (5% ошибок, p95 1 с, очередь 500,
   15% диска). Это разумные стартовые значения, а не измеренные под реальной
   нагрузкой — их нужно откалибровать по первой неделе эксплуатации.
8. Исключения маршрутов в `SedLatencyDegraded`
   (`/api/documents/:id/print.*`) — шаблон написан по ожидаемому виду
   маршрутов печати; если фактический путь отличается, выражение ничего не
   исключит и алерт будет шумным.
9. Соотнесение retention с объёмом диска: `retention_period: 720h` в Loki и
   `30d` / `8GB` в Prometheus взяты из общих соображений, а не из измеренного
   объёма логов СЭД.
10. Доступ к `/metrics` открыт без аутентификации (Prometheus не умеет
    обновлять JWT), а порт 8080 опубликован на хост — то есть на стенде
    `/metrics` доступен всем, кто дотянется до хоста. На продуктиве маршрут
    обязан быть закрыт на реверс-прокси. То же касается портов 3000/9090/3100.
