package db

import (
	"context"
	"fmt"
	"log"

	"github.com/jackc/pgx/v5/pgxpool"
)

// ============================================================================
// #5 — ПОЧЕМУ АДМИНИСТРАТОР ВИДЕЛ ДОКУМЕНТЫ, КОТОРЫХ НЕ ДОЛЖЕН ВИДЕТЬ.
//
// Настоящая причина оказалась не в самих политиках, а в РОЛИ подключения.
// В docker-compose бэкенд подключался тем же пользователем `sed`, который
// задан в POSTGRES_USER. Официальный образ postgres создаёт POSTGRES_USER
// как SUPERUSER, а для суперпользователя (и для любой роли с BYPASSRLS)
// PostgreSQL ОТКЛЮЧАЕТ Row-Level Security целиком — даже при
// ALTER TABLE ... FORCE ROW LEVEL SECURITY.
//
// То есть RLS в такой конфигурации не работал ни для кого: обычные
// пользователи ничего лишнего не видели лишь потому, что списки
// дополнительно фильтруются в самих SQL-запросах (автор / получатель /
// подписант). У администратора таких прикладных фильтров нет — он получает
// «всё, что разрешает RLS», и поэтому эффект вылез именно на нём.
//
// Проверено на живой БД PostgreSQL 16 (одни и те же политики, один и тот же
// набор данных, разница только в роли подключения):
//
//	роль sed     (superuser): админ видит документ → 1  ← НЕПРАВИЛЬНО
//	роль sed_app (обычная)  : админ видит документ → 0  ← правильно
//	                          автор видит свой документ → 1
//
// Поэтому приложение обязано работать от ОБЫЧНОЙ роли. Эта функция такую
// роль создаёт и выдаёт ей ровно права на данные (без DDL и без владения
// таблицами — владелец остаётся `sed`, иначе FORCE RLS снова обходится).
// ============================================================================

// EnsureAppRole создаёт/обновляет непривилегированную прикладную роль и выдаёт
// ей права на существующие и будущие объекты схемы public.
//
// Вызывается ПРИВИЛЕГИРОВАННЫМ подключением (MIGRATE_DATABASE_URL) на старте,
// до открытия рабочего пула. Идемпотентна. Не фатальна: если прав на CREATE
// ROLE нет (управляемый PostgreSQL), пишем понятное предупреждение — роль
// в таком случае создаётся администратором БД один раз вручную, SQL тот же.
func EnsureAppRole(ctx context.Context, adminPool *pgxpool.Pool, role, password string) error {
	if role == "" {
		return nil
	}
	if password == "" {
		return fmt.Errorf("APP_DB_PASSWORD не задан — роль %s создавать нечем", role)
	}
	// Имя роли подставляется в DDL как идентификатор, параметризовать его
	// нельзя. Поэтому валидируем его по строгому белому списку символов.
	if !validRoleName(role) {
		return fmt.Errorf("недопустимое имя роли %q: разрешены латинские буквы, цифры и _", role)
	}

	var exists bool
	if err := adminPool.QueryRow(ctx,
		`SELECT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = $1)`, role).Scan(&exists); err != nil {
		return fmt.Errorf("проверка роли %s: %w", role, err)
	}

	// Пароль уходит как литерал в DDL, поэтому экранируем кавычки.
	pwLit := quoteLiteral(password)
	if exists {
		if _, err := adminPool.Exec(ctx,
			fmt.Sprintf(`ALTER ROLE %s WITH LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE PASSWORD %s`,
				role, pwLit)); err != nil {
			return fmt.Errorf("обновление роли %s: %w", role, err)
		}
	} else {
		if _, err := adminPool.Exec(ctx,
			fmt.Sprintf(`CREATE ROLE %s WITH LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE PASSWORD %s`,
				role, pwLit)); err != nil {
			return fmt.Errorf("создание роли %s: %w", role, err)
		}
		log.Printf("db: создана прикладная роль %s (без SUPERUSER/BYPASSRLS — обязательное условие работы RLS)", role)
	}

	// Права на данные: только DML. DDL и владение остаются у роли-владельца.
	stmts := []string{
		fmt.Sprintf(`GRANT USAGE ON SCHEMA public TO %s`, role),
		fmt.Sprintf(`GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO %s`, role),
		fmt.Sprintf(`GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO %s`, role),
		// Будущие таблицы/последовательности (следующие миграции) — чтобы не
		// пришлось выдавать права заново после каждого обновления.
		fmt.Sprintf(`ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO %s`, role),
		fmt.Sprintf(`ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO %s`, role),
	}
	for _, s := range stmts {
		if _, err := adminPool.Exec(ctx, s); err != nil {
			return fmt.Errorf("выдача прав роли %s: %w", role, err)
		}
	}
	return nil
}

// WarnIfRLSBypassed проверяет РАБОЧЕЕ подключение: если приложение ходит в БД
// суперпользователем или ролью с BYPASSRLS, то RLS не действует и разграничение
// доступа к документам фактически отсутствует. Пишем это в лог максимально
// заметно — молчаливый обход RLS и был причиной замечания #5.
//
// Возвращает true, если RLS действует (роль обычная).
func WarnIfRLSBypassed(ctx context.Context, pool *pgxpool.Pool) bool {
	var role string
	var super, bypass bool
	err := pool.QueryRow(ctx,
		`SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`).
		Scan(&role, &super, &bypass)
	if err != nil {
		log.Printf("db: не удалось проверить роль подключения (RLS): %v", err)
		return false
	}
	if super || bypass {
		log.Printf("db: ВНИМАНИЕ! Приложение подключено ролью %q (superuser=%v, bypassrls=%v). "+
			"PostgreSQL ОТКЛЮЧАЕТ Row-Level Security для таких ролей, поэтому разграничение "+
			"доступа к документам НЕ РАБОТАЕТ: администратор и любой пользователь получат "+
			"все документы. Укажите в DATABASE_URL обычную роль (см. APP_DB_ROLE и "+
			"docker-compose.yml).", role, super, bypass)
		return false
	}
	log.Printf("db: роль подключения %q — обычная, RLS действует", role)
	return true
}

func validRoleName(s string) bool {
	for i, r := range s {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r == '_':
		case r >= '0' && r <= '9' && i > 0:
		default:
			return false
		}
	}
	return s != ""
}

// quoteLiteral оформляет строку как SQL-литерал с удвоением одинарных кавычек.
func quoteLiteral(s string) string {
	out := make([]rune, 0, len(s)+2)
	out = append(out, '\'')
	for _, r := range s {
		if r == '\'' {
			out = append(out, '\'')
		}
		out = append(out, r)
	}
	out = append(out, '\'')
	return string(out)
}
