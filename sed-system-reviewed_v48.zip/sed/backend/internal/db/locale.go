package db

import (
	"context"
	"log"

	"github.com/jackc/pgx/v5/pgxpool"
)

// WarnIfLocaleCannotFoldCyrillic проверяет, умеет ли база приводить регистр
// кириллицы, и предупреждает, если нет.
//
// Приведение регистра в PostgreSQL (lower/upper/ILIKE) выполняется средствами
// ОС по ctype базы данных. Если база создана в локали C — а так бывает,
// зависит от того, как поднимали сервер, — для кириллицы они не делают
// ничего:
//
//	upper('исх')               → 'исх'
//	'ИСХ-1/2' ILIKE '%исх%'    → false
//
// Проверено на живой PostgreSQL 16 с datcollate=C. В такой установке поиск
// по-русски заглавными буквами не работал бы вовсе.
//
// Сам поиск в системе от локали НЕ зависит: регистр сворачивается своей
// функцией (fold_ru в SQL, search.FoldRU в Go, миграция 0015). Эта проверка
// нужна, чтобы администратор знал о свойстве своей базы: от ctype по-прежнему
// зависят сортировка по алфавиту (ORDER BY ФИО) и сравнение строк.
//
// Не фатально и ничего не меняет — только сообщает.
func WarnIfLocaleCannotFoldCyrillic(ctx context.Context, pool *pgxpool.Pool) bool {
	var collate, ctype string
	if err := pool.QueryRow(ctx,
		`SELECT datcollate, datctype FROM pg_database WHERE datname = current_database()`).
		Scan(&collate, &ctype); err != nil {
		log.Printf("db: не удалось определить локаль базы: %v", err)
		return false
	}

	var folds bool
	if err := pool.QueryRow(ctx, `SELECT upper('и') = 'И'`).Scan(&folds); err != nil {
		log.Printf("db: не удалось проверить приведение регистра: %v", err)
		return false
	}

	if !folds {
		log.Printf("db: ВНИМАНИЕ! База создана в локали collate=%s ctype=%s — "+
			"PostgreSQL не приводит регистр кириллицы (upper('и') не даёт 'И'). "+
			"Поиск в системе от этого не зависит (регистр сворачивается функцией fold_ru), "+
			"но сортировка по алфавиту будет не по-русски. Для новой установки "+
			"создавайте базу с ru_RU.UTF-8 или en_US.UTF-8: "+
			"POSTGRES_INITDB_ARGS=\"--locale=ru_RU.UTF-8\" либо "+
			"CREATE DATABASE … LC_COLLATE='ru_RU.UTF-8' LC_CTYPE='ru_RU.UTF-8'.",
			collate, ctype)
		return false
	}
	return true
}
