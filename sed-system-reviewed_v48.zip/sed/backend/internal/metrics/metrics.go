// Package metrics — экспорт метрик приложения в формате Prometheus
// (text exposition format 0.0.4) БЕЗ внешних зависимостей.
//
// Почему руками, а не prometheus/client_golang: в go.mod этой библиотеки нет,
// а добавить её нельзя — сборочное окружение закрыто от внешних реестров.
// Нужный нам срез возможностей (счётчики, гистограмма, gauge и текстовая
// выдача) занимает ~400 строк, тогда как клиентская библиотека тянет ещё
// десяток модулей (protobuf, procfs, expfmt). Формат 0.0.4 стабилен и
// документирован, поэтому самодельный экспортер совместим и с Prometheus,
// и с Grafana Agent / VictoriaMetrics.
//
// Устройство: все метрики — пакетные переменные, инициализируются при загрузке
// пакета, обновляются без блокировок на горячем пути (atomic), и сериализуются
// только в момент запроса /metrics. Карты серий защищены RWMutex: запись в них
// происходит лишь при появлении НОВОЙ комбинации меток (первый запрос к
// маршруту), дальше идёт чтение под RLock и atomic-инкремент значения.
package metrics

import (
	"errors"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
)

// namespace — общий префикс всех метрик. Префикс обязателен: в одном
// Prometheus живут метрики и самого Prometheus, и экспортеров узла, и
// `http_requests_total` без префикса почти гарантированно столкнётся с чужой
// метрикой с другим набором меток.
const namespace = "sed"

// labelSep — разделитель значений меток внутри ключа карты серий. Байт 0xFF
// невалиден в UTF-8, поэтому он не может встретиться ни в методе, ни в
// шаблоне маршрута, ни в коде ответа — склейка однозначно разбирается обратно.
const labelSep = "\xff"

// maxSeries — страховочный предел числа серий на одну метрику. Это ПОСЛЕДНИЙ
// рубеж от «кардинального взрыва»: основная защита — нормализация метки
// маршрута (см. routeLabel), но если в будущем кто-то добавит метку с
// пользовательским вводом, память не уйдёт в бесконечность, а новые серии
// просто перестанут создаваться.
const maxSeries = 2000

// ---------------------------------------------------------------------------
// Примитивы: scalar, counterVec, gaugeVec, histogramVec
// ---------------------------------------------------------------------------

// scalar — одиночное значение без меток (счётчик или gauge).
//
// divisor нужен для величин, которые НАКАПЛИВАЮТСЯ в целых числах, а отдаются
// в секундах: время ожидания соединения складываем в наносекундах через
// atomic (быстро и без потери точности), а при выдаче делим на 1e9. Хранить
// float64 атомарно пришлось бы через math.Float64bits, что только усложнило бы
// код без выигрыша.
type scalar struct {
	v       atomic.Int64
	name    string
	help    string
	kind    string // "gauge" или "counter"
	divisor float64
}

func newGauge(name, help string) *scalar {
	return &scalar{name: namespace + "_" + name, help: help, kind: "gauge"}
}

func newCounter(name, help string) *scalar {
	return &scalar{name: namespace + "_" + name, help: help, kind: "counter"}
}

// newSecondsCounter — счётчик, который накапливается в наносекундах, а
// отдаётся в секундах (базовая единица Prometheus — всегда секунда).
func newSecondsCounter(name, help string) *scalar {
	return &scalar{name: namespace + "_" + name, help: help, kind: "counter", divisor: 1e9}
}

func (s *scalar) set(v int64) { s.v.Store(v) }

func (s *scalar) add(delta int64) { s.v.Add(delta) }

func (s *scalar) write(b *strings.Builder) {
	writeHead(b, s.name, s.help, s.kind)
	b.WriteString(s.name)
	b.WriteByte(' ')
	v := s.v.Load()
	if s.divisor != 0 {
		b.WriteString(formatFloat(float64(v) / s.divisor))
	} else {
		b.WriteString(strconv.FormatInt(v, 10))
	}
	b.WriteByte('\n')
}

// labeled — общая часть метрик с метками: фиксированный порядок имён меток и
// карта серий по склеенному ключу.
type labeled struct {
	mu     sync.RWMutex
	name   string
	help   string
	labels []string
}

// counterVec — монотонный счётчик с метками.
type counterVec struct {
	labeled
	series map[string]*atomic.Uint64
}

func newCounterVec(name, help string, labels ...string) *counterVec {
	return &counterVec{
		labeled: labeled{name: namespace + "_" + name, help: help, labels: labels},
		series:  make(map[string]*atomic.Uint64),
	}
}

func (c *counterVec) inc(values ...string) {
	key := strings.Join(values, labelSep)

	// Двухфазный доступ: сначала дешёвое чтение под RLock (типичный случай —
	// серия уже существует), и только при промахе берём полный Lock.
	c.mu.RLock()
	p := c.series[key]
	c.mu.RUnlock()
	if p == nil {
		c.mu.Lock()
		if p = c.series[key]; p == nil {
			if len(c.series) >= maxSeries {
				c.mu.Unlock()
				return
			}
			p = new(atomic.Uint64)
			c.series[key] = p
		}
		c.mu.Unlock()
	}
	p.Add(1)
}

func (c *counterVec) write(b *strings.Builder) {
	writeHead(b, c.name, c.help, "counter")
	type row struct {
		key string
		val uint64
	}
	c.mu.RLock()
	keys := make([]string, 0, len(c.series))
	for k := range c.series {
		keys = append(keys, k)
	}
	rows := make([]row, 0, len(keys))
	for _, k := range sortKeys(keys) {
		rows = append(rows, row{k, c.series[k].Load()})
	}
	c.mu.RUnlock()

	for _, r := range rows {
		b.WriteString(c.name)
		writeLabels(b, c.labels, strings.Split(r.key, labelSep), "", "")
		b.WriteByte(' ')
		b.WriteString(strconv.FormatUint(r.val, 10))
		b.WriteByte('\n')
	}
}

// gaugeVec — произвольно меняющееся значение с метками (например, количество
// документов в каждом статусе).
type gaugeVec struct {
	labeled
	series map[string]int64
}

func newGaugeVec(name, help string, labels ...string) *gaugeVec {
	return &gaugeVec{
		labeled: labeled{name: namespace + "_" + name, help: help, labels: labels},
		series:  make(map[string]int64),
	}
}

func (g *gaugeVec) set(value int64, values ...string) {
	key := strings.Join(values, labelSep)
	g.mu.Lock()
	if _, ok := g.series[key]; !ok && len(g.series) >= maxSeries {
		g.mu.Unlock()
		return
	}
	g.series[key] = value
	g.mu.Unlock()
}

// replace полностью заменяет набор серий. Нужно именно замещение, а не
// поштучный set: если статус документа больше не встречается в БД, его серия
// обязана ИСЧЕЗНУТЬ из выдачи. Иначе Prometheus продолжит видеть последнее
// значение как актуальное, и на дашборде навсегда повиснет «на согласовании: 7».
func (g *gaugeVec) replace(values map[string]int64) {
	next := make(map[string]int64, len(values))
	for k, v := range values {
		if len(next) >= maxSeries {
			break
		}
		next[k] = v
	}
	g.mu.Lock()
	g.series = next
	g.mu.Unlock()
}

func (g *gaugeVec) write(b *strings.Builder) {
	writeHead(b, g.name, g.help, "gauge")
	g.mu.RLock()
	keys := make([]string, 0, len(g.series))
	for k := range g.series {
		keys = append(keys, k)
	}
	keys = sortKeys(keys)
	vals := make([]int64, 0, len(keys))
	for _, k := range keys {
		vals = append(vals, g.series[k])
	}
	g.mu.RUnlock()

	for i, k := range keys {
		b.WriteString(g.name)
		writeLabels(b, g.labels, strings.Split(k, labelSep), "", "")
		b.WriteByte(' ')
		b.WriteString(strconv.FormatInt(vals[i], 10))
		b.WriteByte('\n')
	}
}

// histogramVec — гистограмма длительностей с метками.
type histogramVec struct {
	labeled
	bounds   []float64 // верхние границы бакетов в секундах (для метки le)
	boundsNs []int64   // те же границы в наносекундах
	series   map[string]*histogram
}

type histogram struct {
	// buckets — НЕкумулятивные попадания в бакет; кумулятивную сумму считаем
	// при выдаче. Так инкремент стоит один atomic.Add вместо прохода по всем
	// бакетам, а требование формата (bucket'ы кумулятивны) выполняется в
	// медленном пути — в обработчике /metrics.
	buckets []atomic.Uint64
	count   atomic.Uint64
	// sumNs — сумма длительностей в наносекундах; в секунды переводим при выдаче.
	sumNs atomic.Uint64
}

func newHistogramVec(name, help string, bounds []float64, labels ...string) *histogramVec {
	ns := make([]int64, len(bounds))
	for i, b := range bounds {
		ns[i] = int64(b * float64(time.Second))
	}
	return &histogramVec{
		labeled:  labeled{name: namespace + "_" + name, help: help, labels: labels},
		bounds:   bounds,
		boundsNs: ns,
		series:   make(map[string]*histogram),
	}
}

func (h *histogramVec) observe(d time.Duration, values ...string) {
	key := strings.Join(values, labelSep)
	h.mu.RLock()
	s := h.series[key]
	h.mu.RUnlock()
	if s == nil {
		h.mu.Lock()
		if s = h.series[key]; s == nil {
			if len(h.series) >= maxSeries {
				h.mu.Unlock()
				return
			}
			s = &histogram{buckets: make([]atomic.Uint64, len(h.bounds))}
			h.series[key] = s
		}
		h.mu.Unlock()
	}
	// Отрицательной длительности быть не должно, но часы могут прыгнуть назад
	// (NTP), и тогда d < 0 исказило бы сумму. Приводим к нулю.
	ns := d.Nanoseconds()
	if ns < 0 {
		ns = 0
	}
	s.count.Add(1)
	s.sumNs.Add(uint64(ns))
	// Линейный поиск по 12 границам дешевле бинарного на таком размере и не
	// требует ветвлений с индексами.
	for i, bn := range h.boundsNs {
		if ns <= bn {
			s.buckets[i].Add(1)
			return
		}
	}
	// Больше последней границы — попадает только в +Inf, который считается из
	// count при выдаче.
}

func (h *histogramVec) write(b *strings.Builder) {
	writeHead(b, h.name, h.help, "histogram")
	h.mu.RLock()
	keys := make([]string, 0, len(h.series))
	for k := range h.series {
		keys = append(keys, k)
	}
	keys = sortKeys(keys)
	series := make([]*histogram, 0, len(keys))
	for _, k := range keys {
		series = append(series, h.series[k])
	}
	h.mu.RUnlock()

	for i, k := range keys {
		s := series[i]
		lv := strings.Split(k, labelSep)
		var cum uint64
		for j, bound := range h.bounds {
			cum += s.buckets[j].Load()
			b.WriteString(h.name)
			b.WriteString("_bucket")
			writeLabels(b, h.labels, lv, "le", formatFloat(bound))
			b.WriteByte(' ')
			b.WriteString(strconv.FormatUint(cum, 10))
			b.WriteByte('\n')
		}
		// +Inf обязателен и по определению равен общему числу наблюдений.
		total := s.count.Load()
		b.WriteString(h.name)
		b.WriteString("_bucket")
		writeLabels(b, h.labels, lv, "le", "+Inf")
		b.WriteByte(' ')
		b.WriteString(strconv.FormatUint(total, 10))
		b.WriteByte('\n')

		b.WriteString(h.name)
		b.WriteString("_sum")
		writeLabels(b, h.labels, lv, "", "")
		b.WriteByte(' ')
		b.WriteString(formatFloat(float64(s.sumNs.Load()) / float64(time.Second)))
		b.WriteByte('\n')

		b.WriteString(h.name)
		b.WriteString("_count")
		writeLabels(b, h.labels, lv, "", "")
		b.WriteByte(' ')
		b.WriteString(strconv.FormatUint(total, 10))
		b.WriteByte('\n')
	}
}

// ---------------------------------------------------------------------------
// Хелперы сериализации
// ---------------------------------------------------------------------------

func writeHead(b *strings.Builder, name, help, kind string) {
	b.WriteString("# HELP ")
	b.WriteString(name)
	b.WriteByte(' ')
	b.WriteString(escapeHelp(help))
	b.WriteString("\n# TYPE ")
	b.WriteString(name)
	b.WriteByte(' ')
	b.WriteString(kind)
	b.WriteByte('\n')
}

// writeLabels печатает {k="v",...}. extraName/extraValue добавляют последнюю
// пару (нужно для le у гистограммы, где метка обязана идти последней по
// соглашению и так привычнее читать выдачу глазами).
func writeLabels(b *strings.Builder, names, values []string, extraName, extraValue string) {
	if len(names) == 0 && extraName == "" {
		return
	}
	b.WriteByte('{')
	first := true
	for i, n := range names {
		if i >= len(values) {
			break
		}
		if !first {
			b.WriteByte(',')
		}
		first = false
		b.WriteString(n)
		b.WriteString(`="`)
		b.WriteString(escapeLabelValue(values[i]))
		b.WriteByte('"')
	}
	if extraName != "" {
		if !first {
			b.WriteByte(',')
		}
		b.WriteString(extraName)
		b.WriteString(`="`)
		b.WriteString(escapeLabelValue(extraValue))
		b.WriteByte('"')
	}
	b.WriteByte('}')
}

// escapeLabelValue экранирует то, что формат 0.0.4 требует экранировать в
// значении метки: обратный слэш, кавычку и перевод строки. Без этого один
// кривой маршрут сломал бы парсинг ВСЕЙ выдачи, и Prometheus пометил бы
// target'а как down.
func escapeLabelValue(s string) string {
	if !strings.ContainsAny(s, "\\\"\n") {
		return s
	}
	r := strings.NewReplacer("\\", "\\\\", "\"", "\\\"", "\n", "\\n")
	return r.Replace(s)
}

// escapeHelp — в строке HELP значимы только слэш и перевод строки.
func escapeHelp(s string) string {
	if !strings.ContainsAny(s, "\\\n") {
		return s
	}
	r := strings.NewReplacer("\\", "\\\\", "\n", "\\n")
	return r.Replace(s)
}

// formatFloat даёт компактную запись без экспоненты там, где можно: метка
// le="0.005" должна совпадать от скрейпа к скрейпу БАЙТ В БАЙТ, иначе
// Prometheus сочтёт это разными сериями и histogram_quantile сломается.
func formatFloat(f float64) string {
	return strconv.FormatFloat(f, 'g', -1, 64)
}

// sortKeys упорядочивает ключи серий. Детерминированный порядок выдачи не
// требуется форматом, но делает diff двух скрейпов читаемым при отладке
// руками (curl /metrics > a; curl /metrics > b; diff a b).
func sortKeys(keys []string) []string {
	sort.Strings(keys)
	return keys
}

// ---------------------------------------------------------------------------
// Набор метрик приложения
// ---------------------------------------------------------------------------

// durationBuckets — границы бакетов задержки HTTP, секунды.
//
// Подобраны под веб-СЭД, а не взяты «по умолчанию»: основная масса запросов
// (список документов, /me, справочники) укладывается в 5–100 мс, поэтому
// внизу сетка плотная — иначе p50 и p95 схлопнутся в один бакет и перцентили
// станут бесполезными. Сверху оставлены 5/10/30 с: загрузка и перештамповка
// PDF до 64 МБ законно идёт секунды, и без границы 30 с все такие запросы
// попадали бы в +Inf, где histogram_quantile уже не может ничего оценить.
var durationBuckets = []float64{
	0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30,
}

var (
	httpRequests = newCounterVec("http_requests_total",
		"Количество обработанных HTTP-запросов.",
		"method", "route", "status")

	httpDuration = newHistogramVec("http_request_duration_seconds",
		"Длительность обработки HTTP-запроса в секундах.",
		durationBuckets, "method", "route")

	httpInFlight = newGauge("http_requests_in_flight",
		"Количество HTTP-запросов, обрабатываемых прямо сейчас.")

	// --- Пул соединений к PostgreSQL (pgxpool) ---
	dbPoolSize = newGauge("db_pool_connections",
		"Всего соединений в пуле (занятые + простаивающие + создаваемые).")
	dbPoolMax = newGauge("db_pool_connections_max",
		"Настроенный максимум соединений пула (pgxpool MaxConns).")
	dbPoolByState = newGaugeVec("db_pool_connections_state",
		"Соединения пула в разрезе состояния.", "state")
	dbPoolAcquires = newCounter("db_pool_acquires_total",
		"Суммарное число захватов соединения из пула.")
	dbPoolEmptyAcquires = newCounter("db_pool_empty_acquires_total",
		"Число захватов, которым пришлось ждать свободного соединения (пул был пуст).")
	dbPoolCanceledAcquires = newCounter("db_pool_canceled_acquires_total",
		"Число захватов, отменённых контекстом до получения соединения.")
	dbPoolAcquireWait = newSecondsCounter("db_pool_acquire_wait_seconds_total",
		"Суммарное время ожидания соединения из пула, секунды.")

	// --- Бизнес-метрики (заполняются вызовами сеттеров из прикладного кода) ---
	documentsByStatus = newGaugeVec("documents",
		"Количество документов по статусам.", "status")
	indexQueueLength = newGauge("index_queue_length",
		"Документов в очереди на индексацию содержимого PDF (status='pending').")
	indexFailed = newGauge("index_failed_documents",
		"Документов, по которым индексация завершилась ошибкой.")

	processUptime = newGauge("process_uptime_seconds",
		"Время работы процесса с момента старта, секунды.")
)

// startedAt фиксируется при загрузке пакета. Отдельная метрика uptime нужна
// потому, что по графику счётчиков рестарт бэкенда неотличим от просадки
// трафика: счётчики просто обнуляются, и rate() даёт провал без объяснения.
var startedAt = time.Now()

// ---------------------------------------------------------------------------
// HTTP middleware
// ---------------------------------------------------------------------------

var (
	knownRoutesOnce sync.Once
	knownRoutes     map[string]bool
)

// Middleware возвращает Fiber-middleware, учитывающее все HTTP-запросы.
//
// ПОРЯДОК РЕГИСТРАЦИИ ВАЖЕН: подключать нужно ПЕРЕД recover.New(). Тогда
// паника в хендлере превращается recover'ом в обычную ошибку, которая
// возвращается нам из c.Next(), и мы честно учитываем её как 500. Если же
// повесить metrics ПОСЛЕ recover, паника пройдёт сквозь наш кадр стека и
// запрос вообще не попадёт в метрики — то есть ровно самые интересные
// запросы и потеряются.
func Middleware(app *fiber.App) fiber.Handler {
	return func(c *fiber.Ctx) error {
		start := time.Now()
		httpInFlight.add(1)
		err := c.Next()
		httpInFlight.add(-1)

		// Код ответа на этот момент ещё НЕ выставлен, если хендлер вернул
		// ошибку: ErrorHandler приложения вызывается выше по стеку, уже после
		// возврата из middleware. Поэтому при err != nil код берём из самой
		// ошибки — иначе все 4xx/5xx записывались бы как 200.
		status := c.Response().StatusCode()
		if err != nil {
			status = fiber.StatusInternalServerError
			var fe *fiber.Error
			if errors.As(err, &fe) {
				status = fe.Code
			}
		}

		route := routeLabel(app, c)
		method := c.Method()
		httpRequests.inc(method, route, strconv.Itoa(status))
		httpDuration.observe(time.Since(start), method, route)
		return err
	}
}

// routeLabel возвращает значение метки route.
//
// ПОЧЕМУ ШАБЛОН МАРШРУТА, А НЕ КОНКРЕТНЫЙ URL. Метка в Prometheus — это часть
// идентификатора временного ряда: каждое новое значение создаёт ОТДЕЛЬНЫЙ ряд
// со своей историей в TSDB. В СЭД пути почти все параметрические
// (/api/documents/:id, /api/documents/:id/file, .../stages/:stageId/decide).
// Если взять c.Path(), то 50 000 документов дадут 50 000+ рядов на одну
// метрику вместо десятка, а с учётом гистограммы (13 бакетов + sum + count)
// — под миллион рядов. Это кардинальный взрыв: Prometheus раздувается по
// памяти и диску, запросы вида sum(rate(...)) начинают считаться секундами,
// а графики всё равно бесполезны, потому что по одному документу статистики
// нет. Шаблон c.Route().Path даёт ровно то, что нужно для эксплуатации:
// «насколько быстро работает выдача файла документа», а не «насколько быстро
// отдался документ №8431».
//
// Дополнительная тонкость: при 404 Fiber не нашёл маршрута, и c.Route() в
// этом случае возвращает ИСХОДНЫЙ путь запроса вместо шаблона. Это вторая
// дыра для кардинального взрыва — любой сканер уязвимостей, перебирающий
// /wp-admin/..., наплодил бы ряды. Поэтому значение сверяется со списком
// реально зарегистрированных маршрутов, а всё остальное сворачивается в
// route="other".
func routeLabel(app *fiber.App, c *fiber.Ctx) string {
	// Список маршрутов читаем лениво, на первом запросе: Middleware
	// регистрируется ДО объявления маршрутов, на момент его создания
	// app.GetRoutes() ещё пуст.
	knownRoutesOnce.Do(func() {
		knownRoutes = make(map[string]bool)
		// true — не брать записи от app.Use: у них путь "/" и они матчат всё.
		for _, r := range app.GetRoutes(true) {
			knownRoutes[r.Path] = true
		}
	})
	if r := c.Route(); r != nil && knownRoutes[r.Path] {
		return r.Path
	}
	return "other"
}

// ---------------------------------------------------------------------------
// Источник метрик пула БД
// ---------------------------------------------------------------------------

// dbPool — пул, с которого снимаем статистику. atomic.Pointer, а не обычная
// переменная: регистрация идёт на старте из main, а чтение — из горутин
// обработчика /metrics, и race detector справедливо ругался бы на обычное поле.
var dbPool atomic.Pointer[pgxpool.Pool]

// SetDBPool регистрирует пул pgxpool как источник метрик соединений.
// Вызывается один раз при инициализации; nil отключает эти метрики.
func SetDBPool(pool *pgxpool.Pool) { dbPool.Store(pool) }

// collectDBPool обновляет метрики пула.
//
// Снимаем их ПЕРЕД выдачей, а не по таймеру: pool.Stat() — это копия
// внутренних счётчиков, вызов дешёвый и не ходит в БД, так что отдельная
// горутина с тикером была бы лишней сущностью. Главное — значения в ответе
// всегда актуальны на момент скрейпа, а не «не старше 15 секунд».
func collectDBPool() {
	pool := dbPool.Load()
	if pool == nil {
		return
	}
	st := pool.Stat()
	dbPoolSize.set(int64(st.TotalConns()))
	dbPoolMax.set(int64(st.MaxConns()))
	dbPoolByState.replace(map[string]int64{
		"acquired":     int64(st.AcquiredConns()),
		"idle":         int64(st.IdleConns()),
		"constructing": int64(st.ConstructingConns()),
	})
	dbPoolAcquires.set(st.AcquireCount())
	dbPoolEmptyAcquires.set(st.EmptyAcquireCount())
	dbPoolCanceledAcquires.set(st.CanceledAcquireCount())
	dbPoolAcquireWait.set(st.AcquireDuration().Nanoseconds())
}

// ---------------------------------------------------------------------------
// Бизнес-метрики: сеттеры для прикладного кода
// ---------------------------------------------------------------------------

// SetDocumentsByStatus публикует количество документов по статусам.
// Передавайте ПОЛНУЮ карту: отсутствующие статусы исчезают из выдачи, иначе
// на дашборде навсегда зависло бы последнее известное значение.
//
// Запрос в БД делать здесь нельзя (пакет не должен знать про схему и RLS) —
// считайте снаружи, например фоновой задачей раз в минуту:
//
//	SELECT status, count(*) FROM documents GROUP BY status
func SetDocumentsByStatus(counts map[string]int64) {
	documentsByStatus.replace(counts)
}

// SetIndexQueueLength публикует длину очереди индексации содержимого PDF
// (indexer.Status.Pending).
func SetIndexQueueLength(n int64) { indexQueueLength.set(n) }

// SetIndexFailed публикует число документов, по которым индексация упала
// (indexer.Status.Failed): растущее значение означает, что извлечение текста
// сломано, а поиск по содержимому тихо деградирует.
func SetIndexFailed(n int64) { indexFailed.set(n) }

// ---------------------------------------------------------------------------
// Обработчик /metrics
// ---------------------------------------------------------------------------

// Handler отдаёт все метрики в формате Prometheus exposition format 0.0.4.
//
// Маршрут намеренно оставлен без JWT: Prometheus скрейпит его по внутренней
// docker-сети и не умеет обновлять токены. Закрывать его следует на уровне
// сети/реверс-прокси (не публиковать наружу) — так же, как /healthz.
func Handler() fiber.Handler {
	return func(c *fiber.Ctx) error {
		collectDBPool()
		processUptime.set(int64(time.Since(startedAt).Seconds()))

		var b strings.Builder
		// Преаллокация под типичный объём выдачи: экономит ~десяток
		// перевыделений буфера на каждом скрейпе.
		b.Grow(16 * 1024)

		httpRequests.write(&b)
		httpDuration.write(&b)
		httpInFlight.write(&b)

		dbPoolSize.write(&b)
		dbPoolMax.write(&b)
		dbPoolByState.write(&b)
		dbPoolAcquires.write(&b)
		dbPoolEmptyAcquires.write(&b)
		dbPoolCanceledAcquires.write(&b)
		dbPoolAcquireWait.write(&b)

		documentsByStatus.write(&b)
		indexQueueLength.write(&b)
		indexFailed.write(&b)
		processUptime.write(&b)

		// version=0.0.4 в Content-Type — то, по чему Prometheus выбирает
		// текстовый парсер; charset обязателен, иначе кириллица в HELP
		// приедет в интерфейс «кракозябрами».
		c.Set(fiber.HeaderContentType, "text/plain; version=0.0.4; charset=utf-8")
		return c.SendString(b.String())
	}
}
