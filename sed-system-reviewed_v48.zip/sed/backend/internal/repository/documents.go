package repository

import (
	"context"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
	"sed-system/backend/internal/domain"
	"sed-system/backend/internal/search"
)

type DocumentsRepo struct{}

func NewDocumentsRepo() *DocumentsRepo { return &DocumentsRepo{} }

// Category соответствует вкладкам в UI: исходящие/входящие/на согласовании/
// на подписи/исполнено/архив. RLS (document_access) уже ограничивает набор
// строк, доступных пользователю в текущей транзакции — здесь остаётся
// только фильтрация по статусу/направлению и пагинация.
type Category string

const (
	CategoryOutgoing   Category = "outgoing"
	CategoryIncoming   Category = "incoming"
	CategoryAwaiting   Category = "awaiting"
	CategoryOnApproval Category = "on_approval"
	CategoryOnSigning  Category = "on_signing"
	CategoryExecuted   Category = "executed"
	CategoryArchive    Category = "archive"
	CategoryControl    Category = "control"
	CategoryPrintUnreg Category = "print_unregistered"
	CategoryAll        Category = "all"
)

var categoryStatusFilter = map[Category][]domain.Status{
	CategoryOnApproval: {domain.StatusOnApprovalHierarchy, domain.StatusOnApprovalCrossDept},
	CategoryOnSigning:  {domain.StatusOnSigning},
	CategoryExecuted:   {domain.StatusExecuted},
	CategoryArchive:    {domain.StatusArchived},
}

// ============================================================================
// ЕДИНЫЙ НАБОР КОЛОНОК СПИСКОВ.
//
// Раньше список колонок был скопирован в каждую ветку (их семь: исходящие,
// входящие, ожидают регистрации, на контроле, на регистрацию, статусные,
// все) плюс в поиск. При добавлении столбца приходилось править все копии, и
// ошибиться было нечем не защищено: в v44 три ветки остались с 12 колонками
// при 15 приёмниках rows.Scan — эти вкладки падали бы на ровном месте.
//
// Теперь колонки, JOIN'ы и разбор строки заданы ОДИН раз. Добавление столбца
// — правка в двух константах и одной функции, рассинхронизация невозможна.
// ============================================================================

// docListColumns — колонки строки списка. Порядок обязан совпадать с
// scanDocument.
const docListColumns = `
	d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
	d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at,
	coalesce(d.category_id,0), coalesce(cat.name,''), coalesce(cat.color,''),
	coalesce(d.special_mark_id,0), coalesce(sm.name,''), coalesce(sm.color,''),
	coalesce(ch.msg_count,0), coalesce(ch.file_count,0)`

// docListJoins — JOIN'ы, от которых зависят docListColumns.
//
// #17 — комментарии и вложения считаются одним LEFT JOIN LATERAL, а не двумя
// коррелированными подзапросами в SELECT: иначе на каждую строку списка
// (а их до 100) приходилось бы по два отдельных сканирования chat_messages.
const docListJoins = `
	LEFT JOIN document_categories cat ON cat.id = d.category_id
	LEFT JOIN special_marks sm ON sm.id = d.special_mark_id
	LEFT JOIN LATERAL (
	    SELECT count(*) AS msg_count,
	           coalesce(sum((SELECT count(*) FROM chat_attachments a WHERE a.message_id = m.id)), 0) AS file_count
	    FROM chat_messages m
	    WHERE m.document_id = d.id AND m.deleted_at IS NULL
	) ch ON TRUE`

// docListPageSQL собирает запрос страницы списка.
//
// #37 — ПОРЯДОК ОПЕРАЦИЙ ЗДЕСЬ И ЕСТЬ ОПТИМИЗАЦИЯ.
//
// Наивная сборка «SELECT колонки FROM documents <все JOIN> WHERE … ORDER BY …
// LIMIT 20» заставляет PostgreSQL вычислить ВСЕ присоединённые значения для
// каждой строки, подходящей под условие, и только потом отбросить всё, кроме
// 20. Замерено на 60 000 документов: в списке «Исходящие» подзапрос подсчёта
// переписки выполнялся 17 502 раза на один показанный экран.
//
// Поэтому страница формируется в два шага:
//  1. внутренний запрос отбирает ТОЛЬКО нужные 20 строк документов — здесь
//     работают индексы по условию и сортировке;
//  2. внешний присоединяет справочники и считает счётчики — уже для 20 строк.
//
// joinSQL — присоединения, от которых зависит УСЛОВИЕ отбора (например,
// document_recipients для входящих): они обязаны быть внутри, иначе условие
// не к чему применить. docListJoins — только для отдаваемых колонок, поэтому
// снаружи.
func docListPageSQL(joinSQL, whereSQL, tail string) string {
	return `SELECT ` + docListColumns + `
		FROM (
		    SELECT d.* FROM documents d ` + joinSQL + whereSQL + tail + `
		) d ` + docListJoins
}

// scanDocument разбирает строку, выбранную по docListColumns.
func scanDocument(rows pgx.Rows, d *domain.Document) error {
	return rows.Scan(&d.ID, &d.AuthorID, &d.AuthorDepartmentID, &d.Title, &d.BodySummary, &d.Urgency, &d.Status,
		&d.OutgoingNumber, &d.DueDate, &d.DueDatetime, &d.CreatedAt, &d.UpdatedAt,
		&d.CategoryID, &d.CategoryName, &d.CategoryColor,
		&d.SpecialMarkID, &d.SpecialMarkName, &d.SpecialMarkColor,
		&d.MessageCount, &d.FileCount)
}

// collectDocuments вычитывает все строки списка.
func collectDocuments(rows pgx.Rows) ([]domain.Document, error) {
	defer rows.Close()
	var items []domain.Document
	for rows.Next() {
		var d domain.Document
		if err := scanDocument(rows, &d); err != nil {
			return nil, err
		}
		items = append(items, d)
	}
	return items, rows.Err()
}

// ============================================================================
// #41 — УСЛОВИЕ КАТЕГОРИИ В ОДНОМ МЕСТЕ.
//
// Счётчики документов в боковом меню обязаны считать РОВНО то, что потом
// покажет список. Если условие выборки списка и условие счётчика написаны
// отдельно, они неизбежно расходятся при первой же правке, и пользователь
// видит «Входящие 5», открывает — а там 3.
//
// Поэтому условие каждой категории строится здесь, и этим пользуются и
// List, и CategoryCounts.
// ============================================================================

// categoryCountLimit — предел ОГРАНИЧЕННОГО подсчёта для счётчиков меню (#37).
//
// 1000 выбрано так: фронт всё равно показывает «999+» для значений больше 999,
// то есть больший предел никак не влияет на то, что видит пользователь, зато
// прямо влияет на стоимость запроса.
const categoryCountLimit = 1000

// categoryCondition возвращает JOIN'ы и WHERE для категории, а также
// аргументы запроса в том порядке, в каком они пронумерованы ($1, $2, …).
//
// year > 0 имеет смысл только для архива.
func categoryCondition(cat Category, userID, deptID int64, year int) (joinSQL, whereSQL string, args []any) {
	switch cat {
	case CategoryOutgoing:
		// #3 — Исходящие видят: автор; согласующий по иерархии; подписант;
		// а также тот, кто видит документы подразделения-автора (собственное
		// подразделение или назначенная админом «видимость исходящих»).
		// RLS дополнительно ограничивает выборку тем, что пользователь вправе
		// читать. Только документы с присвоенным исходящим номером.
		return "", `
			WHERE d.outgoing_number IS NOT NULL AND d.status <> 'archived' AND (
			     d.author_id = $1
			  OR EXISTS (SELECT 1 FROM approval_stages s
			             WHERE s.document_id = d.id AND s.approver_id = $1 AND s.stage_type = 'hierarchy')
			  OR EXISTS (SELECT 1 FROM approval_stages s
			             WHERE s.document_id = d.id AND s.approver_id = $1 AND s.stage_type = 'signing')
			  OR d.author_department_id = $2
			  OR d.author_department_id IN (SELECT department_id FROM user_visible_departments WHERE user_id = $1)
			)`, []any{userID, deptID}

	case CategoryAwaiting:
		// #6 — «Ожидают регистрации» = входящие, направленные пользователю
		// (получателю) в статусе sent/in_progress, по которым ещё НЕ присвоен
		// входящий номер (нет входящего экземпляра для его подразделения).
		return ` JOIN document_recipients r ON r.document_id = d.id AND r.recipient_user_id = $1 `, `
			WHERE d.status IN ('sent','in_progress')
			  AND NOT EXISTS (SELECT 1 FROM document_incoming_instances i
			                  WHERE i.document_id = d.id
			                    AND i.receiving_department_id = r.recipient_department_id)`, []any{userID}

	case CategoryIncoming:
		// Входящие = документы, направленные текущему пользователю как
		// получателю, по которым УЖЕ присвоен входящий номер (был первый
		// просмотр). Без номера — они в «Ожидают регистрации» (#7).
		return ` JOIN document_recipients r ON r.document_id = d.id AND r.recipient_user_id = $1 `, `
			WHERE d.status IN ('sent','in_progress')
			  AND EXISTS (SELECT 1 FROM document_incoming_instances i
			              WHERE i.document_id = d.id
			                AND i.receiving_department_id = r.recipient_department_id
			                AND i.incoming_number IS NOT NULL)`, []any{userID}

	case CategoryControl:
		// На контроле = документы с on_control=true. RLS уже ограничивает
		// видимость (контролёр получает document_access при постановке на
		// контроль, автор видит свои напрямую).
		return "", ` WHERE d.on_control = true AND d.status <> 'archived'`, nil

	case CategoryPrintUnreg:
		// «На регистрацию» = документы, которые ТЕКУЩИЙ пользователь скачал на
		// печать, но ещё не зарегистрировал в бумажном журнале.
		//
		// EXISTS, а не JOIN с DISTINCT: выдач на печать по одному документу
		// может быть несколько, при JOIN строки размножались и LIMIT/OFFSET
		// работал по выдачам, а не по документам.
		return "", `
			WHERE EXISTS (SELECT 1 FROM document_prints p
			              WHERE p.document_id = d.id AND p.user_id = $1 AND p.reg_at IS NULL)`, []any{userID}
	}

	if statuses, ok := categoryStatusFilter[cat]; ok {
		// pgx не умеет напрямую сериализовать []domain.Status (срез кастомного
		// строкового типа) в enum-массив Postgres — получаем 500. Приводим к
		// []string: параметр уходит как text[], а Postgres сам кастует к
		// doc_status в сравнении status = ANY(...).
		statusStrs := make([]string, len(statuses))
		for i, st := range statuses {
			statusStrs[i] = string(st)
		}
		// Для архива поддерживаем фильтр по году (по дате помещения в
		// архив/исполнения/создания). year=0 — все годы. Префикс d.
		// обязателен: в выборке есть JOIN'ы, где тоже есть created_at.
		//
		// #37 — Условие записано ДИАПАЗОНОМ, а не EXTRACT(YEAR FROM …) = N.
		// EXTRACT по выражению проиндексировать нельзя, и фильтр по году
		// заставлял читать и сортировать все архивные документы: замерено
		// 7500 строк и 7.7 мс на один экран. Диапазон ложится на индекс
		// idx_documents_archive_period — 0.111 мс. Набор документов
		// идентичен, проверено сравнением количеств (7500 = 7500).
		yearFilter := ""
		if cat == CategoryArchive && year > 0 {
			from := strconv.Itoa(year) + "-01-01"
			to := strconv.Itoa(year+1) + "-01-01"
			yearFilter = " AND coalesce(d.archived_at, d.executed_at, d.created_at) >= '" + from +
				"'::timestamptz AND coalesce(d.archived_at, d.executed_at, d.created_at) < '" + to + "'::timestamptz"
		}
		return "", ` WHERE d.status = ANY($1::doc_status[])` + yearFilter, []any{statusStrs}
	}

	// CategoryAll — всё, что видно по RLS.
	return "", ` WHERE d.status <> 'archived'`, nil
}

// CategoryCounts возвращает количество документов в каждой запрошенной
// категории — для счётчиков в боковом меню (#41).
//
// Все категории считаются ОДНИМ запросом: отдельный round-trip на каждую из
// десяти категорий, да ещё с периодическим обновлением у каждого из
// пользователей, — это ровно та нагрузка, которую создавать незачем.
// Параметры у категорий разные, поэтому подзапросы собираются со сдвигом
// нумерации $n.
func (r *DocumentsRepo) CategoryCounts(ctx context.Context, tx pgx.Tx, cats []Category, userID, deptID int64) (map[Category]int64, error) {
	out := make(map[Category]int64, len(cats))
	if len(cats) == 0 {
		return out, nil
	}

	var parts []string
	var args []any
	for _, cat := range cats {
		joinSQL, whereSQL, catArgs := categoryCondition(cat, userID, deptID, 0)
		// Сдвигаем номера параметров подзапроса на количество уже занятых.
		shift := len(args)
		if shift > 0 {
			whereSQL = shiftPlaceholders(whereSQL, shift)
			joinSQL = shiftPlaceholders(joinSQL, shift)
		}
		// #37 — ОГРАНИЧЕННЫЙ подсчёт.
		//
		// Точный count(*) по условию категории читает все подходящие строки.
		// Замерено на 60 000 документов: «Исходящие» — 37 мс. Девять
		// категорий, раз в минуту, у каждого пользователя — это постоянная
		// нагрузка, которая на заявленных объёмах (миллионы и выше) станет
		// секундами на каждое обновление меню.
		//
		// В счётчике меню точность за пределами «много» не нужна: разницу
		// между 4231 и 4232 пользователь не использует, а «999+» сообщает
		// ровно то, что требуется — есть непросмотренное, надо идти в раздел.
		// Поэтому подсчёт останавливается на categoryCountLimit строках:
		// 37 мс → 0.4 мс. Фронт показывает «999+», когда достигнут предел.
		parts = append(parts, `(SELECT count(*) FROM (SELECT 1 FROM documents d `+joinSQL+whereSQL+
			` LIMIT `+strconv.Itoa(categoryCountLimit)+`) c)`)
		args = append(args, catArgs...)
	}

	row := tx.QueryRow(ctx, `SELECT `+strings.Join(parts, ", "))
	if len(args) > 0 {
		row = tx.QueryRow(ctx, `SELECT `+strings.Join(parts, ", "), args...)
	}
	dest := make([]any, len(cats))
	vals := make([]int64, len(cats))
	for i := range vals {
		dest[i] = &vals[i]
	}
	if err := row.Scan(dest...); err != nil {
		return nil, fmt.Errorf("category counts: %w", err)
	}
	for i, cat := range cats {
		out[cat] = vals[i]
	}
	return out, nil
}

// shiftPlaceholders увеличивает номера $1,$2,… на shift. Нужно, чтобы
// независимые условия категорий можно было сложить в один запрос.
//
// Замена делается ОДНИМ проходом регулярным выражением, а не последовательными
// strings.ReplaceAll по каждому номеру. Второй способ выглядит проще, но
// ломается двумя разными способами, и оба проверены тестом:
//   - замена «$1» задевает «$10», превращая его в «$20»;
//   - при проходе по возрастанию результат одной замены попадает под
//     следующую ($1 → $3, затем $3 → $5).
//
// Однопроходная замена не имеет ни той, ни другой проблемы по построению.
func shiftPlaceholders(sql string, shift int) string {
	if shift == 0 {
		return sql
	}
	return placeholderRe.ReplaceAllStringFunc(sql, func(m string) string {
		n, err := strconv.Atoi(m[1:])
		if err != nil {
			return m
		}
		return "$" + strconv.Itoa(n+shift)
	})
}

var placeholderRe = regexp.MustCompile(`\$\d+`)

// List возвращает страницу документов доступных текущему пользователю
// (ограничение уже применено RLS-политикой внутри переданной tx).
// Использует композитный индекс idx_documents_status_created для
// категорий, ограниченных по статусу, либо idx_documents_dept_created
// для "исходящие"/"входящие" (см. ветвление ниже).
func (r *DocumentsRepo) List(ctx context.Context, tx pgx.Tx, cat Category, userID, deptID int64, page, pageSize, year int) (domain.PagedResult[domain.Document], error) {
	if page < 1 {
		page = 1
	}
	offset := (page - 1) * pageSize

	// Условие категории — из общего построителя (см. categoryCondition):
	// список и счётчики в боковом меню обязаны считать одно и то же (#41).
	joinSQL, whereSQL, args := categoryCondition(cat, userID, deptID, year)

	var total int64
	// В count'е docListJoins не участвуют: категория, особая отметка и
	// счётчики переписки на количество строк не влияют и были бы лишней работой.
	if err := tx.QueryRow(ctx, `SELECT count(*) FROM documents d `+joinSQL+whereSQL, args...).Scan(&total); err != nil {
		return domain.PagedResult[domain.Document]{}, err
	}

	// LIMIT/OFFSET идут следующими по порядку параметрами после аргументов
	// условия — поэтому их номера вычисляются, а не пишутся константами.
	limitArg := len(args) + 1
	offsetArg := len(args) + 2
	args = append(args, pageSize, offset)

	rows, err := tx.Query(ctx, docListPageSQL(joinSQL, whereSQL,
		` ORDER BY d.created_at DESC LIMIT $`+strconv.Itoa(limitArg)+` OFFSET $`+strconv.Itoa(offsetArg)), args...)
	if err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("query documents: %w", err)
	}

	items, err := collectDocuments(rows)
	if err != nil {
		return domain.PagedResult[domain.Document]{}, err
	}

	return domain.PagedResult[domain.Document]{
		Items:      items,
		Page:       page,
		PageSize:   pageSize,
		TotalCount: total,
	}, nil
}

// Search выполняет полнотекстовый поиск по title+body_summary через
// to_tsvector('russian', ...), используя GIN-индекс idx_documents_search
// (миграция 0002). RLS применяется как обычно — поиск никогда не вернёт
// документ, невидимый текущему пользователю. Ранжирование через ts_rank,
// пагинация стандартная (LIMIT/OFFSET), т.к. страниц результатов поиска
// обычно немного и глубокий offset здесь не характерен для UX.
// SearchFilter — максимально гибкий набор фильтров по всем атрибутам документа.
// Все поля опциональны; пустые игнорируются.
//
// Текстовые поля (Query, Number, IncomingNumber) ищутся по ЧАСТИЧНОМУ
// совпадению без учёта регистра. Раньше это делалось через ILIKE, но ILIKE
// приводит регистр средствами ОС по ctype базы: в базе с локалью C для
// кириллицы он не делает ничего, и поиск заглавными буквами не работал
// (проверено на живой БД, см. миграцию 0015). Поэтому обе стороны сравнения
// сворачиваются своей функцией: fold_ru() в SQL и search.FoldRU в Go.
// Под эти выражения в 0015 созданы триграммные индексы.
//
// Content (#4) — полнотекстовый поиск по СОДЕРЖИМОМУ PDF: отдельная таблица
// document_file_text, наполняемая фоновым индексатором, GIN по tsvector.
type SearchFilter struct {
	Category       string   // категория-вкладка для ограничения поиска её пределами
	UserID         int64    // текущий пользователь (для incoming)
	DeptID         int64    // подразделение пользователя (для outgoing)
	Query          string   // частичное совпадение (ILIKE) по title + body_summary
	AuthorID       int64    // 0 = любой
	CategoryID     int64    // #6 — 0 = любая категория документа
	SignerID       int64    // 0 = любой (по document_signatures)
	ControllerID   int64    // 0 = любой (контролёр документа)
	ApproverID     int64    // 0 = любой (участник маршрута согласования)
	RecipientID    int64    // 0 = любой (адресат рассылки)
	DepartmentID   int64    // 0 = любое подразделение-автор
	Statuses       []string // пусто = любые
	Urgencies      []string // пусто = любые
	OnControl      string   // "" любой | "true" только на контроле | "false" только не на контроле
	DueFrom        string   // срок исполнения от, YYYY-MM-DD или ""
	DueTo          string   // срок исполнения до, YYYY-MM-DD или ""
	CreatedFrom    string   // дата создания от, YYYY-MM-DD или ""
	CreatedTo      string   // дата создания до, YYYY-MM-DD или ""
	SignedFrom     string   // дата подписания от, YYYY-MM-DD или ""
	SignedTo       string   // дата подписания до, YYYY-MM-DD или ""
	Number         string   // исходящий номер: нормализованное сравнение (#27)
	IncomingNumber string   // входящий номер: нормализованное сравнение (#27)

	// #4 — поиск по содержимому PDF (websearch_to_tsquery по 'russian').
	Content string
	// #26 — особая отметка документа, 0 = любая.
	SpecialMarkID int64
	// #28 — любое участие пользователя в документе: автор ИЛИ подписант ИЛИ
	// согласующий ИЛИ адресат ИЛИ контролёр. Нужен, потому что на практике
	// ищут «документы, с которыми работал такой-то», не зная его роли.
	AnyParticipantID int64
	// #20 — одна строка, совпадение ПО ЛЮБОМУ из: название, краткое
	// содержание, исходящий номер, входящий номер. Нужно для поиска
	// связанного документа: там человек вводит в одно поле то, что помнит, —
	// то название, то номер, — и не должен выбирать, куда это вводить.
	//
	// Отдельное поле, а не повторное использование Query: все остальные
	// условия фильтра объединяются через AND, и отправить одну строку сразу в
	// Query, Number и IncomingNumber означало бы «И название, И исх. номер, И
	// вх. номер», то есть не найти ничего.
	AnyText string
}

func (r *DocumentsRepo) Search(ctx context.Context, tx pgx.Tx, f SearchFilter, page, pageSize int) (domain.PagedResult[domain.Document], error) {
	if page < 1 {
		page = 1
	}
	offset := (page - 1) * pageSize

	// Собираем WHERE динамически. $1.. — позиционные параметры.
	where := []string{"1=1"}
	args := []any{}
	add := func(cond string, val any) {
		args = append(args, val)
		where = append(where, fmt.Sprintf(cond, len(args)))
	}

	// Ограничение по КАТЕГОРИИ (вкладке) — чтобы поиск/фильтр работал строго в
	// пределах категории, а не по всей базе. Совпадает с логикой List.
	switch Category(f.Category) {
	case CategoryOutgoing:
		add("d.author_department_id = $%d", f.DeptID)
		where = append(where, "d.outgoing_number IS NOT NULL")
	case CategoryIncoming:
		add("EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id = d.id AND r.recipient_user_id = $%d AND d.status IN ('sent','in_progress'))", f.UserID)
	case CategoryControl:
		where = append(where, "d.on_control = true")
	case CategoryPrintUnreg:
		add("EXISTS (SELECT 1 FROM document_prints p WHERE p.document_id = d.id AND p.user_id = $%d AND p.reg_at IS NULL)", f.UserID)
	case CategoryOnSigning:
		where = append(where, "d.status = 'on_signing'")
	case CategoryOnApproval:
		where = append(where, "d.status IN ('on_approval_hierarchy','on_approval_cross_dept')")
	case CategoryExecuted:
		where = append(where, "d.status = 'executed'")
	case CategoryArchive:
		where = append(where, "d.status = 'archived'")
	}

	// Архивные документы не должны попадать НИ В ОДИН список/поиск, кроме
	// категории «Архив». Для incoming статус уже сужен выше.
	if Category(f.Category) != CategoryArchive {
		where = append(where, "d.status <> 'archived'")
	}

	if f.Query != "" {
		// Частичное совпадение по названию И краткому содержанию, без учёта
		// регистра. Свёртка регистра — своей функцией с ОБЕИХ сторон: ILIKE
		// здесь не годится, он не приводит регистр кириллицы в базе с локалью
		// C (см. комментарий к SearchFilter). Под fold_ru(title) и
		// fold_ru(body_summary) в миграции 0015 есть триграммные индексы.
		args = append(args, search.FoldRU(f.Query))
		n := len(args)
		where = append(where, fmt.Sprintf(
			"(fold_ru(d.title) LIKE '%%' || $%d || '%%' OR fold_ru(coalesce(d.body_summary,'')) LIKE '%%' || $%d || '%%')", n, n))
	}
	if f.Content != "" {
		// #4 — Поиск по содержимому PDF. Текст проиндексирован заранее
		// (internal/indexer), поэтому здесь только обращение к GIN-индексу.
		// websearch_to_tsquery, а не plainto_tsquery: он понимает кавычки для
		// точной фразы, "-" для исключения и OR — то есть пользователь может
		// искать «"особая отметка" -черновик», не изучая синтаксис tsquery.
		// Поисковая строка сворачивается тем же FoldRU, что и текст при
		// индексации, иначе запрос заглавными буквами не находил бы ничего.
		args = append(args, search.FoldForFTS(f.Content))
		where = append(where, fmt.Sprintf(
			"EXISTS (SELECT 1 FROM document_file_text t WHERE t.document_id = d.id AND t.tsv @@ websearch_to_tsquery('russian', $%d))", len(args)))
	}
	// #20 — «любое совпадение»: название ИЛИ содержание ИЛИ исх. номер ИЛИ
	// вх. номер. Номера сравниваются в нормализованной форме, поэтому
	// «ИСХ-1/2-231/2026» и «исх 1 2 231 2026» находят одно и то же.
	if f.AnyText != "" {
		args = append(args, search.FoldRU(f.AnyText))
		fold := len(args)
		args = append(args, search.NormalizeDocNumber(f.AnyText))
		num := len(args)
		where = append(where, fmt.Sprintf(`(
			   fold_ru(d.title) LIKE '%%' || $%d || '%%'
			OR fold_ru(coalesce(d.body_summary,'')) LIKE '%%' || $%d || '%%'
			OR ($%d <> '' AND normalize_doc_number(d.outgoing_number) LIKE '%%' || $%d || '%%')
			OR ($%d <> '' AND EXISTS (SELECT 1 FROM document_incoming_instances i
			         WHERE i.document_id = d.id
			           AND normalize_doc_number(i.incoming_number) LIKE '%%' || $%d || '%%')))`,
			fold, fold, num, num, num, num))
	}
	if f.AuthorID != 0 {
		add("d.author_id = $%d", f.AuthorID)
	}
	if f.CategoryID != 0 {
		add("d.category_id = $%d", f.CategoryID)
	}
	if f.DepartmentID != 0 {
		add("d.author_department_id = $%d", f.DepartmentID)
	}
	if f.SignerID != 0 {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signer_id = $%d)", f.SignerID)
	}
	if f.ControllerID != 0 {
		add("d.controller_id = $%d", f.ControllerID)
	}
	if f.ApproverID != 0 {
		add("EXISTS (SELECT 1 FROM approval_stages a WHERE a.document_id = d.id AND a.approver_id = $%d)", f.ApproverID)
	}
	if f.RecipientID != 0 {
		add("EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id = d.id AND r.recipient_user_id = $%d)", f.RecipientID)
	}
	if len(f.Statuses) > 0 {
		add("d.status = ANY($%d::doc_status[])", f.Statuses)
	}
	if len(f.Urgencies) > 0 {
		add("d.urgency = ANY($%d::doc_urgency[])", f.Urgencies)
	}
	if f.OnControl == "true" {
		where = append(where, "d.on_control = true")
	} else if f.OnControl == "false" {
		where = append(where, "d.on_control = false")
	}
	if f.DueFrom != "" {
		add("d.due_date >= $%d::date", f.DueFrom)
	}
	if f.DueTo != "" {
		add("d.due_date <= $%d::date", f.DueTo)
	}
	if f.CreatedFrom != "" {
		add("d.created_at >= $%d::date", f.CreatedFrom)
	}
	if f.CreatedTo != "" {
		add("d.created_at < ($%d::date + interval '1 day')", f.CreatedTo)
	}
	// #27 — Номер ищется по НОРМАЛИЗОВАННОЙ форме: из обеих строк выброшены
	// регистр и разделители. Это и даёт поиск «по целиком введённому номеру»:
	// «ИСХ-1/2-231/2026», скопированный из карточки вместе с неразрывным
	// дефисом и пробелами по краям, набранный строчными или через пробелы
	// вместо дефисов — всё находит один и тот же документ.
	if n := search.NormalizeDocNumber(f.Number); n != "" {
		add("normalize_doc_number(d.outgoing_number) LIKE '%%' || $%d || '%%'", n)
	}
	if n := search.NormalizeDocNumber(f.IncomingNumber); n != "" {
		add("EXISTS (SELECT 1 FROM document_incoming_instances i WHERE i.document_id = d.id AND normalize_doc_number(i.incoming_number) LIKE '%%' || $%d || '%%')", n)
	}
	// #26 — особая отметка.
	if f.SpecialMarkID != 0 {
		add("d.special_mark_id = $%d", f.SpecialMarkID)
	}
	// #28 — «любое участие» пользователя в документе, без привязки к роли.
	if f.AnyParticipantID != 0 {
		args = append(args, f.AnyParticipantID)
		n := len(args)
		where = append(where, fmt.Sprintf(`(
			   d.author_id = $%d
			OR d.controller_id = $%d
			OR EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signer_id = $%d)
			OR EXISTS (SELECT 1 FROM approval_stages a WHERE a.document_id = d.id AND a.approver_id = $%d)
			OR EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id = d.id AND r.recipient_user_id = $%d)
			OR EXISTS (SELECT 1 FROM document_acquaintances q WHERE q.document_id = d.id AND q.user_id = $%d))`,
			n, n, n, n, n, n))
	}
	if f.SignedFrom != "" {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signed_at >= $%d::date)", f.SignedFrom)
	}
	if f.SignedTo != "" {
		add("EXISTS (SELECT 1 FROM document_signatures s WHERE s.document_id = d.id AND s.signed_at < ($%d::date + interval '1 day'))", f.SignedTo)
	}

	whereSQL := strings.Join(where, " AND ")

	var total int64
	if err := tx.QueryRow(ctx, "SELECT count(*) FROM documents d WHERE "+whereSQL, args...).Scan(&total); err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("count search: %w", err)
	}

	// Пагинация: добавляем limit/offset как последние параметры.
	args = append(args, pageSize, offset)
	// Колонки и JOIN'ы — те же, что в List (см. docListColumns): расширенный
	// поиск отдаёт строки того же вида, что и обычные списки, и разбирается
	// той же функцией.
	listSQL := docListPageSQL("", " WHERE "+whereSQL,
		fmt.Sprintf(" ORDER BY d.created_at DESC LIMIT $%d OFFSET $%d", len(args)-1, len(args)))

	rows, err := tx.Query(ctx, listSQL, args...)
	if err != nil {
		return domain.PagedResult[domain.Document]{}, fmt.Errorf("search documents: %w", err)
	}
	items, err := collectDocuments(rows)
	if err != nil {
		return domain.PagedResult[domain.Document]{}, err
	}
	return domain.PagedResult[domain.Document]{Items: items, Page: page, PageSize: pageSize, TotalCount: total}, nil
}

func (r *DocumentsRepo) GetByID(ctx context.Context, tx pgx.Tx, id int64) (domain.Document, error) {
	var d domain.Document
	err := tx.QueryRow(ctx, `
		SELECT d.id, d.author_id, d.author_department_id, d.title, coalesce(d.body_summary,''), d.urgency, d.status,
		       d.outgoing_number, d.due_date, d.due_datetime, d.created_at, d.updated_at,
		       coalesce(d.on_control,false), d.controller_id, cu.full_name,
		       coalesce(d.category_id,0), coalesce(cat.name,''), coalesce(cat.color,''),
		       coalesce(d.special_mark_id,0), coalesce(sm.name,''), coalesce(sm.color,''),
		       coalesce(ch.msg_count,0), coalesce(ch.file_count,0),
		       (SELECT max(signed_at) FROM document_signatures WHERE document_id = d.id)
		FROM documents d
		LEFT JOIN users cu ON cu.id = d.controller_id `+docListJoins+`
		WHERE d.id = $1`, id).Scan(
		&d.ID, &d.AuthorID, &d.AuthorDepartmentID, &d.Title, &d.BodySummary, &d.Urgency, &d.Status,
		&d.OutgoingNumber, &d.DueDate, &d.DueDatetime, &d.CreatedAt, &d.UpdatedAt,
		&d.OnControl, &d.ControllerID, &d.ControllerName,
		&d.CategoryID, &d.CategoryName, &d.CategoryColor,
		&d.SpecialMarkID, &d.SpecialMarkName, &d.SpecialMarkColor,
		&d.MessageCount, &d.FileCount, &d.SignedAt)
	// Если строки нет — либо документ не существует, либо (что чаще) он
	// невидим по RLS для текущего app.user_id: pgx вернёт ErrNoRows в обоих
	// случаях, и снаружи это всегда трактуется как 404, а не 403 — так мы
	// не раскрываем факт существования документа пользователю без доступа.
	if err != nil {
		return domain.Document{}, err
	}
	return d, nil
}

// ListStages возвращает маршрут согласования документа для отображения на
// фронте (кто согласовал/на каком этапе сейчас). RLS документа уже
// применена выше по стеку (документ либо виден пользователю, либо этот
// метод не будет вызван), approval_stages собственной RLS-политики не
// имеет — видимость всего маршрута тому, кто видит документ, осознанный
// выбор (иначе нельзя показать прогресс согласования в UI).
func (r *DocumentsRepo) ListStages(ctx context.Context, tx pgx.Tx, documentID int64) ([]domain.ApprovalStage, error) {
	rows, err := tx.Query(ctx, `
		SELECT s.id, s.document_id, s.stage_type, s.approver_id,
		       coalesce(u.full_name,''), coalesce(u.position,''),
		       coalesce(dep.name,''), coalesce(dep.city,''),
		       s.status, s.display_order, s.decided_at,
		       coalesce(s.comment, ''),
		       coalesce(array_agg(d.depends_on_stage_id) FILTER (WHERE d.depends_on_stage_id IS NOT NULL), '{}')
		FROM approval_stages s
		LEFT JOIN users u ON u.id = s.approver_id
		LEFT JOIN departments dep ON dep.id = u.primary_department_id
		LEFT JOIN approval_stage_dependencies d ON d.stage_id = s.id
		WHERE s.document_id = $1
		GROUP BY s.id, u.full_name, u.position, dep.name, dep.city
		ORDER BY s.display_order`, documentID)
	if err != nil {
		return nil, fmt.Errorf("query stages: %w", err)
	}
	defer rows.Close()

	var stages []domain.ApprovalStage
	for rows.Next() {
		var s domain.ApprovalStage
		if err := rows.Scan(&s.ID, &s.DocumentID, &s.StageType, &s.ApproverID,
			&s.ApproverName, &s.ApproverPosition,
			&s.ApproverDepartment, &s.ApproverCity,
			&s.Status, &s.DisplayOrder, &s.DecidedAt, &s.Comment, &s.DependsOn); err != nil {
			return nil, err
		}
		stages = append(stages, s)
	}
	return stages, rows.Err()
}
