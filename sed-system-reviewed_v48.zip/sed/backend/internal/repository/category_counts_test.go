package repository

import "testing"

// #41 — Счётчики всех категорий считаются ОДНИМ запросом, а условия категорий
// имеют каждое свою нумерацию параметров ($1, $2). Чтобы сложить их в один
// SELECT, номера надо сдвинуть — и сделать это в правильном порядке.
//
// Тонкость, из-за которой нужен тест: если идти от МЕНЬШИХ номеров к большим,
// то $1 → $3 попадёт под следующую замену $3 → $5, и номера поедут. Поэтому
// замена идёт от больших к меньшим.
//
// Запуск: go test ./internal/repository/ -run TestShiftPlaceholders
func TestShiftPlaceholders(t *testing.T) {
	cases := []struct {
		name  string
		sql   string
		shift int
		want  string
	}{
		{
			name: "без параметров — без изменений",
			sql:  " WHERE d.on_control = true", shift: 3,
			want: " WHERE d.on_control = true",
		},
		{
			name: "нулевой сдвиг ничего не меняет",
			sql:  "WHERE a = $1 AND b = $2", shift: 0,
			want: "WHERE a = $1 AND b = $2",
		},
		{
			name: "один параметр",
			sql:  "WHERE user_id = $1", shift: 2,
			want: "WHERE user_id = $3",
		},
		{
			// Главный случай: при сдвиге на 2 получается $1→$3 и $2→$4.
			// При наивной замене по возрастанию $1→$3 затем $3→$5 дало бы $5 и $4.
			name: "два параметра не наезжают друг на друга",
			sql:  "WHERE a = $1 AND b = $2", shift: 2,
			want: "WHERE a = $3 AND b = $4",
		},
		{
			name: "повторяющийся параметр сдвигается везде",
			sql:  "WHERE a = $1 OR b = $1 OR c = $2", shift: 1,
			want: "WHERE a = $2 OR b = $2 OR c = $3",
		},
		{
			name: "двузначные номера не путаются с однозначными",
			sql:  "WHERE a = $1 AND b = $10 AND c = $11", shift: 1,
			want: "WHERE a = $2 AND b = $11 AND c = $12",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := shiftPlaceholders(c.sql, c.shift); got != c.want {
				t.Errorf("shiftPlaceholders(%q, %d)\n получили: %q\n ожидали:  %q", c.sql, c.shift, got, c.want)
			}
		})
	}
}

// Условие категории и список обязаны строиться из одного источника, поэтому
// проверяем, что для каждой категории условие вообще выдаётся и количество
// аргументов совпадает с числом использованных параметров. Рассинхронизация
// здесь даёт ошибку «bind message supplies N parameters» уже в рантайме.
func TestCategoryConditionArgsMatchPlaceholders(t *testing.T) {
	cats := []Category{
		CategoryAll, CategoryAwaiting, CategoryOutgoing, CategoryIncoming,
		CategoryOnApproval, CategoryOnSigning, CategoryControl,
		CategoryPrintUnreg, CategoryExecuted, CategoryArchive,
	}
	for _, cat := range cats {
		joinSQL, whereSQL, args := categoryCondition(cat, 42, 7, 0)
		if whereSQL == "" {
			t.Errorf("категория %q: пустое условие — список вернул бы всё подряд", cat)
			continue
		}
		maxPlaceholder := 0
		for _, m := range placeholderRe.FindAllString(joinSQL+whereSQL, -1) {
			n := 0
			for _, ch := range m[1:] {
				n = n*10 + int(ch-'0')
			}
			if n > maxPlaceholder {
				maxPlaceholder = n
			}
		}
		if maxPlaceholder != len(args) {
			t.Errorf("категория %q: в SQL используется $%d, а аргументов передано %d",
				cat, maxPlaceholder, len(args))
		}
	}
}
