package indexer

import "time"

// ConfigInput — то, что приходит из YAML-конфига (секция search). Отдельный
// тип, чтобы пакет indexer не зависел от пакета config: индексатор можно
// запустить и из отдельной утилиты, без разбора конфигурации приложения.
type ConfigInput struct {
	Enabled               *bool
	BatchSize             int
	IntervalSeconds       int
	MaxAttempts           int
	ExtractCommand        []string
	ExtractTimeoutSeconds int
	StaleAfterSeconds     int
	MaxTextBytes          int
	StoreText             *bool
}

// FromConfig накладывает заданные значения на значения по умолчанию.
// Указатели у Enabled/StoreText не случайны: для булевых настроек нужно
// отличать «не задано» (берём default = true) от «задано false».
func FromConfig(in ConfigInput) Config {
	cfg := DefaultConfig()
	if in.Enabled != nil {
		cfg.Enabled = *in.Enabled
	}
	if in.StoreText != nil {
		cfg.StoreText = *in.StoreText
	}
	if in.BatchSize > 0 {
		cfg.BatchSize = in.BatchSize
	}
	if in.IntervalSeconds > 0 {
		cfg.Interval = time.Duration(in.IntervalSeconds) * time.Second
	}
	if in.MaxAttempts > 0 {
		cfg.MaxAttempts = in.MaxAttempts
	}
	if len(in.ExtractCommand) > 0 {
		cfg.ExtractCommand = in.ExtractCommand
	}
	if in.ExtractTimeoutSeconds > 0 {
		cfg.ExtractTimeout = time.Duration(in.ExtractTimeoutSeconds) * time.Second
	}
	if in.StaleAfterSeconds > 0 {
		cfg.StaleAfter = time.Duration(in.StaleAfterSeconds) * time.Second
	}
	if in.MaxTextBytes > 0 {
		cfg.MaxTextBytes = in.MaxTextBytes
	}
	return cfg
}
