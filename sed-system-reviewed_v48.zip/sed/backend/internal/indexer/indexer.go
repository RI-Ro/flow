// Package indexer — фоновая индексация ТЕКСТА содержимого PDF для поиска (#4).
//
// Зачем фоном. Извлечение текста из PDF — это секунды процессорного времени на
// файл. Делать это в момент загрузки документа нельзя (пользователь ждёт), и
// делать в момент поиска нельзя тем более. Поэтому: документ сохраняется сразу,
// а его текст индексируется отдельным процессом; до окончания индексации поиск
// по содержимому честно сообщает, что проиндексировано не всё (см. эндпоинт
// /api/search/index-status и прелоадер на фронте).
//
// Расчёт на большие объёмы (речь шла о порядке 100 млн файлов):
//
//   - Очередь — это сама таблица document_file_text: строка со
//     status='pending' и есть задание. Отдельная таблица-очередь не нужна, а
//     значит нет и расхождения между «есть задание» и «есть документ».
//   - Задания забираются пачками через FOR UPDATE SKIP LOCKED. Это позволяет
//     запускать СКОЛЬКО УГОДНО экземпляров индексатора (разные процессы,
//     разные машины) без распределённых блокировок: каждый берёт свои строки,
//     остальные пропускает.
//   - Выборка очереди идёт по частичному индексу idx_dft_queue, его размер
//     зависит от числа НЕпроиндексированных документов, а не от всех.
//   - Неудачи не блокируют очередь: attempts растёт, и после max_attempts
//     документ перестаёт выбираться. Иначе один «ядовитый» файл крутился бы в
//     очереди вечно, не давая индексироваться остальным.
//   - PDF без текстового слоя (скан) помечается status='empty' и больше не
//     берётся: пытаться снова бессмысленно, пока файл не заменят (замена
//     ставит строку в очередь триггером).
//
// Текст и поисковый вектор считаются ОДИН раз при индексации, а не на каждый
// поисковый запрос, и ищутся через GIN-индекс по tsvector.
package indexer

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log"
	"os/exec"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/search"
)

// Config — параметры индексатора (секция search в config.yaml).
type Config struct {
	// Enabled — запускать ли фоновую индексацию в этом процессе.
	Enabled bool
	// BatchSize — сколько документов берётся за один проход.
	BatchSize int
	// Interval — пауза, когда очередь пуста.
	Interval time.Duration
	// MaxAttempts — после скольких неудач документ перестаёт выбираться.
	MaxAttempts int
	// ExtractCommand — команда извлечения текста. PDF подаётся на stdin,
	// текст ожидается в stdout. По умолчанию pdftotext из poppler-utils.
	ExtractCommand []string
	// ExtractTimeout — ограничение на один файл: без него «тяжёлый» PDF
	// остановил бы всю очередь.
	ExtractTimeout time.Duration
	// StaleAfter — через сколько задание, взятое в работу, считается зависшим
	// и возвращается в очередь. Нужно, потому что воркер может умереть уже
	// после захвата: без возврата такие строки остались бы в 'processing'
	// навсегда. Должно быть заметно больше ExtractTimeout, иначе живое
	// задание отберут у работающего воркера.
	StaleAfter time.Duration
	// MaxTextBytes — сколько текста хранить и индексировать. Нужен предел:
	// в многотомных документах текста бывает десятки мегабайт, а для поиска
	// такой объём избыточен.
	MaxTextBytes int
	// StoreText — хранить ли сам текст (нужен для показа фрагмента). Если
	// false, после расчёта tsvector текст не сохраняется — поиск работает,
	// места занимает меньше.
	StoreText bool
}

// DefaultConfig — значения по умолчанию.
func DefaultConfig() Config {
	return Config{
		Enabled:   true,
		BatchSize: 20,
		Interval:  15 * time.Second,
		// 3 попытки: больше почти никогда не помогает, а очередь тормозит.
		MaxAttempts:    3,
		ExtractCommand: []string{"pdftotext", "-layout", "-q", "-", "-"},
		ExtractTimeout: 60 * time.Second,
		// 10 минут — с большим запасом к ExtractTimeout (минута): задание
		// возвращается в очередь только если воркер действительно умер, а не
		// потому что файл обрабатывается долго.
		StaleAfter:   10 * time.Minute,
		MaxTextBytes: 2 << 20, // 2 МБ текста на документ
		StoreText:    true,
	}
}

type Indexer struct {
	pool *pgxpool.Pool
	cfg  Config
}

func New(pool *pgxpool.Pool, cfg Config) *Indexer {
	if cfg.BatchSize <= 0 {
		cfg.BatchSize = DefaultConfig().BatchSize
	}
	if cfg.Interval <= 0 {
		cfg.Interval = DefaultConfig().Interval
	}
	if cfg.MaxAttempts <= 0 {
		cfg.MaxAttempts = DefaultConfig().MaxAttempts
	}
	if len(cfg.ExtractCommand) == 0 {
		cfg.ExtractCommand = DefaultConfig().ExtractCommand
	}
	if cfg.ExtractTimeout <= 0 {
		cfg.ExtractTimeout = DefaultConfig().ExtractTimeout
	}
	// StaleAfter обязан быть больше ExtractTimeout, иначе задание будет
	// отобрано у воркера, который его ещё обрабатывает, — и файл начнёт
	// индексироваться дважды, то есть вернётся исходная ошибка.
	if cfg.StaleAfter <= 0 {
		cfg.StaleAfter = DefaultConfig().StaleAfter
	}
	if cfg.StaleAfter <= cfg.ExtractTimeout {
		cfg.StaleAfter = cfg.ExtractTimeout * 10
		log.Printf("indexer: search.stale_after должен быть больше search.extract_timeout; "+
			"использую %s", cfg.StaleAfter)
	}
	if cfg.MaxTextBytes <= 0 {
		cfg.MaxTextBytes = DefaultConfig().MaxTextBytes
	}
	return &Indexer{pool: pool, cfg: cfg}
}

// Start запускает фоновый цикл. Не блокирует.
func (ix *Indexer) Start(ctx context.Context) {
	if !ix.cfg.Enabled {
		log.Printf("indexer: индексация содержимого PDF выключена (search.enabled=false)")
		return
	}
	if err := ix.checkExtractor(); err != nil {
		// Не фатально: система работает, просто поиск по содержимому не
		// наполняется. Но сказать об этом надо прямо, иначе пустой поиск
		// выглядел бы как «поиск не работает».
		log.Printf("indexer: ВНИМАНИЕ! Извлечение текста недоступно: %v. "+
			"Поиск по содержимому PDF наполняться не будет. Установите poppler-utils "+
			"(в образе — apk add poppler-utils) либо укажите свою команду в search.extract_command.", err)
		return
	}
	go ix.loop(ctx)
	log.Printf("indexer: фоновая индексация содержимого PDF запущена (пачка %d, пауза %s)",
		ix.cfg.BatchSize, ix.cfg.Interval)
}

// checkExtractor проверяет, что команда извлечения вообще есть в системе —
// до того, как начнём брать задания и портить им attempts.
func (ix *Indexer) checkExtractor() error {
	if _, err := exec.LookPath(ix.cfg.ExtractCommand[0]); err != nil {
		return fmt.Errorf("команда %q не найдена: %w", ix.cfg.ExtractCommand[0], err)
	}
	return nil
}

func (ix *Indexer) loop(ctx context.Context) {
	for {
		n, err := ix.ProcessBatch(ctx)
		if err != nil && !errors.Is(err, context.Canceled) {
			log.Printf("indexer: ошибка обработки пачки: %v", err)
		}
		// Если пачка была полной — работаем дальше без паузы: очередь большая,
		// и ждать 15 секунд между пачками при первичной индексации бессмысленно.
		if n >= ix.cfg.BatchSize {
			select {
			case <-ctx.Done():
				return
			default:
				continue
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(ix.cfg.Interval):
		}
	}
}

type task struct {
	documentID int64
	content    []byte
}

// ProcessBatch обрабатывает одну пачку заданий и возвращает их количество.
// Экспортирована, чтобы индексацию можно было вызвать разово (отладка,
// одноразовый прогон после обновления).
func (ix *Indexer) ProcessBatch(ctx context.Context) (int, error) {
	tasks, err := ix.claim(ctx)
	if err != nil {
		return 0, err
	}
	for _, t := range tasks {
		ix.indexOne(ctx, t)
	}
	return len(tasks), nil
}

// claim забирает пачку заданий.
//
// FOR UPDATE SKIP LOCKED — ключевой момент: строки, уже захваченные другим
// экземпляром индексатора, пропускаются, а не ждут освобождения. Благодаря
// этому несколько процессов разбирают очередь параллельно и не мешают друг
// другу. Пометка 'pending' → attempts+1 делается в той же транзакции, поэтому
// одно и то же задание не достанется двум воркерам.
func (ix *Indexer) claim(ctx context.Context) ([]task, error) {
	tx, err := ix.pool.Begin(ctx)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback(ctx)

	rows, err := tx.Query(ctx, `
		SELECT t.document_id
		FROM document_file_text t
		WHERE t.attempts < $1
		  AND (t.status IN ('pending', 'failed')
		       OR (t.status = 'processing'
		           AND t.claimed_at IS NOT NULL
		           AND t.claimed_at < now() - $3::interval))
		ORDER BY t.attempts, t.document_id
		LIMIT $2
		FOR UPDATE SKIP LOCKED`,
		ix.cfg.MaxAttempts, ix.cfg.BatchSize, ix.cfg.StaleAfter.String())
	if err != nil {
		return nil, fmt.Errorf("выборка очереди: %w", err)
	}
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return nil, err
		}
		ids = append(ids, id)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(ids) == 0 {
		return nil, tx.Commit(ctx)
	}

	// Помечаем задания ВЗЯТЫМИ в той же транзакции, что и выборку.
	//
	// Это главное: текст извлекается уже ПОСЛЕ коммита (держать транзакцию
	// открытой минуту нельзя), и после коммита строки разблокируются. Если бы
	// статус остался 'pending', второй экземпляр индексатора выбрал бы ровно
	// те же документы, которые первый в этот момент обрабатывает —
	// воспроизведено на живой БД, см. миграцию 0017.
	//
	// Счётчик попыток увеличиваем здесь же: если процесс упадёт на извлечении,
	// задание вернётся в очередь по claimed_at, но не будет крутиться вечно.
	if _, err := tx.Exec(ctx, `
		UPDATE document_file_text
		   SET status = 'processing', attempts = attempts + 1,
		       claimed_at = now(), updated_at = now()
		 WHERE document_id = ANY($1::bigint[])`, ids); err != nil {
		return nil, fmt.Errorf("отметка попытки: %w", err)
	}

	// Содержимое файлов читаем здесь же. document_files не под RLS, поэтому
	// индексатору не нужен контекст пользователя — он служебный процесс.
	fileRows, err := tx.Query(ctx, `
		SELECT document_id, content FROM document_files
		WHERE document_id = ANY($1::bigint[])`, ids)
	if err != nil {
		return nil, fmt.Errorf("чтение файлов: %w", err)
	}
	byID := make(map[int64][]byte, len(ids))
	for fileRows.Next() {
		var id int64
		var content []byte
		if err := fileRows.Scan(&id, &content); err != nil {
			fileRows.Close()
			return nil, err
		}
		byID[id] = content
	}
	fileRows.Close()
	if err := fileRows.Err(); err != nil {
		return nil, err
	}

	if err := tx.Commit(ctx); err != nil {
		return nil, err
	}

	out := make([]task, 0, len(ids))
	for _, id := range ids {
		out = append(out, task{documentID: id, content: byID[id]})
	}
	return out, nil
}

func (ix *Indexer) indexOne(ctx context.Context, t task) {
	if len(t.content) == 0 {
		ix.markFailed(ctx, t.documentID, "файл документа отсутствует")
		return
	}
	text, err := ix.extract(ctx, t.content)
	if err != nil {
		ix.markFailed(ctx, t.documentID, err.Error())
		return
	}

	// Свёртка регистра ЗДЕСЬ, до записи: русский стеммер PostgreSQL в локали C
	// на заглавной первой букве даёт неверную лексему («Пода» вместо «подат»),
	// и поиск заглавными буквами перестаёт работать. Сворачивая обе стороны в
	// Go, мы не зависим от локали базы (см. internal/search/fold.go).
	folded := search.FoldForFTS(text)
	if len(folded) > ix.cfg.MaxTextBytes {
		folded = safeTruncate(folded, ix.cfg.MaxTextBytes)
	}

	if strings.TrimSpace(folded) == "" {
		// PDF без текстового слоя — скан-картинка. Не ошибка, но и
		// переиндексировать нечего.
		ix.exec(ctx, `
			UPDATE document_file_text
			   SET status='empty', content_text=NULL, tsv=NULL, chars=0,
			       error=NULL, indexed_at=now(), updated_at=now()
			 WHERE document_id=$1`, t.documentID)
		return
	}

	stored := folded
	if !ix.cfg.StoreText {
		stored = ""
	}
	ix.exec(ctx, `
		UPDATE document_file_text
		   SET status='indexed',
		       content_text = NULLIF($2::text, ''),
		       tsv = to_tsvector('russian', $3::text),
		       chars = length($3::text),
		       error = NULL, indexed_at = now(), updated_at = now()
		 WHERE document_id = $1`, t.documentID, stored, folded)
}

// extract запускает внешнюю команду, подавая PDF на stdin.
//
// Через stdin, а не через временный файл: файлы лежат в БД, и писать их на
// диск ради извлечения текста означало бы и лишний ввод-вывод, и риск
// оставить содержимое документа во временном каталоге.
func (ix *Indexer) extract(ctx context.Context, pdf []byte) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, ix.cfg.ExtractTimeout)
	defer cancel()

	cmd := exec.CommandContext(ctx, ix.cfg.ExtractCommand[0], ix.cfg.ExtractCommand[1:]...)
	cmd.Stdin = bytes.NewReader(pdf)
	var out, errBuf bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errBuf
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return "", fmt.Errorf("извлечение текста прервано по таймауту (%s)", ix.cfg.ExtractTimeout)
		}
		msg := strings.TrimSpace(errBuf.String())
		if msg == "" {
			msg = err.Error()
		}
		return "", fmt.Errorf("извлечение текста не удалось: %s", msg)
	}
	return out.String(), nil
}

func (ix *Indexer) markFailed(ctx context.Context, documentID int64, msg string) {
	ix.exec(ctx, `
		UPDATE document_file_text
		   SET status='failed', error=$2, updated_at=now()
		 WHERE document_id=$1`, documentID, truncateError(msg))
}

func (ix *Indexer) exec(ctx context.Context, sql string, args ...any) {
	if _, err := ix.pool.Exec(ctx, sql, args...); err != nil && !errors.Is(err, context.Canceled) {
		log.Printf("indexer: не удалось сохранить результат индексации: %v", err)
	}
}

// safeTruncate обрезает по границе рун: обрезка по байтам порвала бы символ и
// дала бы невалидный UTF-8 в базе.
func safeTruncate(s string, maxBytes int) string {
	if len(s) <= maxBytes {
		return s
	}
	cut := maxBytes
	for cut > 0 && !isUTF8Start(s[cut]) {
		cut--
	}
	return s[:cut]
}

func isUTF8Start(b byte) bool { return b&0xC0 != 0x80 }

func truncateError(s string) string {
	const max = 500
	if len(s) <= max {
		return s
	}
	return safeTruncate(s, max)
}

// Status — сводка по индексации для прелоадера на фронте.
type Status struct {
	Total   int64 `json:"total"`
	Indexed int64 `json:"indexed"`
	Pending int64 `json:"pending"`
	// Processing — взяты в работу прямо сейчас. Считается отдельно: без этого
	// прелоадер показывал бы «готово», пока часть документов ещё в обработке.
	Processing int64 `json:"processing"`
	Empty      int64 `json:"empty"`
	Failed     int64 `json:"failed"`
	Percent    int   `json:"percent"`
	Complete   bool  `json:"complete"`
}

// QueryStatus считает сводку. Один проход по частичному индексу/таблице
// состояния, без обращения к самим файлам.
func QueryStatus(ctx context.Context, q interface {
	QueryRow(context.Context, string, ...any) pgx.Row
}) (Status, error) {
	var s Status
	err := q.QueryRow(ctx, `
		SELECT count(*),
		       count(*) FILTER (WHERE status='indexed'),
		       count(*) FILTER (WHERE status='pending'),
		       count(*) FILTER (WHERE status='processing'),
		       count(*) FILTER (WHERE status='empty'),
		       count(*) FILTER (WHERE status='failed')
		FROM document_file_text`).
		Scan(&s.Total, &s.Indexed, &s.Pending, &s.Processing, &s.Empty, &s.Failed)
	if err != nil {
		return s, err
	}
	// «Обработано» — это indexed + empty + failed: пытаться дальше по ним
	// нечего, и прогресс не должен застревать из-за сканов и ошибок.
	// 'processing' сюда НЕ входит — работа ещё идёт.
	done := s.Indexed + s.Empty + s.Failed
	if s.Total > 0 {
		s.Percent = int(done * 100 / s.Total)
	} else {
		s.Percent = 100
	}
	s.Complete = s.Pending == 0 && s.Processing == 0
	return s, nil
}
