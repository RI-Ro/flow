package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// SpecialMarksHandler — справочник ОСОБЫХ ОТМЕТОК документа (#26).
//
// Требование: поле «особая отметка» заводится и меняется из админки и
// участвует во всех фильтрах. Поэтому это именно справочник, а не свободный
// текст в документе: по свободному тексту нельзя сделать выпадающий список в
// фильтре, и у одной и той же отметки накапливаются написания («лично»,
// «Лично», «ЛИЧНО!»), которые потом не отфильтровать.
//
// Список доступен всем аутентифицированным (нужен для форм и фильтров),
// изменение — только администратору. Структура повторяет справочник категорий
// (#6/#25), включая цвет: отличия между двумя справочниками были бы здесь
// лишней неожиданностью для администратора.
type SpecialMarksHandler struct {
	pool *pgxpool.Pool
}

func NewSpecialMarksHandler(pool *pgxpool.Pool) *SpecialMarksHandler {
	return &SpecialMarksHandler{pool: pool}
}

var errSpecialMarkInUse = errors.New("special mark in use")

type specialMarkItem struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Code      string `json:"code"`
	IsActive  bool   `json:"is_active"`
	SortOrder int    `json:"sort_order"`
	Color     string `json:"color"`
}

func (h *SpecialMarksHandler) requireAdmin(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return nil
}

// List GET /api/special-marks — список отметок. Неактивные видит только админ:
// отключённую отметку нельзя предлагать на форме создания, но в фильтрах и в
// старых документах она должна оставаться видимой админу.
func (h *SpecialMarksHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	var items []specialMarkItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		where := "WHERE is_active = true"
		if isAdmin {
			where = ""
		}
		rows, err := tx.Query(c.Context(),
			`SELECT id, name, coalesce(code,''), is_active, sort_order, coalesce(color,'')
			 FROM special_marks `+where+` ORDER BY sort_order, name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it specialMarkItem
			if err := rows.Scan(&it.ID, &it.Name, &it.Code, &it.IsActive, &it.SortOrder, &it.Color); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить особые отметки")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Create POST /api/admin/special-marks (admin).
func (h *SpecialMarksHandler) Create(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	var req struct {
		Name      string `json:"name"`
		Code      string `json:"code"`
		SortOrder int    `json:"sort_order"`
		Color     string `json:"color"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название особой отметки")
	}
	if req.SortOrder == 0 {
		req.SortOrder = 100
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO special_marks (name, code, sort_order, color)
			VALUES ($1, NULLIF($2,''), $3, NULLIF($4,'')) RETURNING id`,
			req.Name, req.Code, req.SortOrder, req.Color).Scan(&id)
	})
	if txErr != nil {
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "особая отметка с таким названием/кодом уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать особую отметку")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

// Update PATCH /api/admin/special-marks/:id (admin).
func (h *SpecialMarksHandler) Update(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Name      string `json:"name"`
		Code      string `json:"code"`
		IsActive  bool   `json:"is_active"`
		SortOrder int    `json:"sort_order"`
		Color     string `json:"color"`
	}
	if err := c.BodyParser(&req); err != nil || req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название особой отметки")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE special_marks SET name=$2, code=NULLIF($3,''), is_active=$4, sort_order=$5,
			       color=NULLIF($6,'') WHERE id=$1`,
			id, req.Name, req.Code, req.IsActive, req.SortOrder, req.Color)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "особая отметка не найдена")
		}
		if isUniqueViolation(txErr) {
			return fiber.NewError(fiber.StatusConflict, "особая отметка с таким названием/кодом уже существует")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить особую отметку")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/admin/special-marks/:id (admin). Используемую отметку
// удалять нельзя — иначе из карточек документов пропала бы отметка, с которой
// они были созданы. Её деактивируют.
func (h *SpecialMarksHandler) Delete(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		var used int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM documents WHERE special_mark_id=$1`, id).Scan(&used); err != nil {
			return err
		}
		if used > 0 {
			return errSpecialMarkInUse
		}
		_, err := tx.Exec(c.Context(), `DELETE FROM special_marks WHERE id=$1`, id)
		return err
	})
	if txErr != nil {
		if errors.Is(txErr, errSpecialMarkInUse) {
			return fiber.NewError(fiber.StatusConflict,
				"особая отметка используется документами — удаление невозможно, деактивируйте её")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить особую отметку")
	}
	return c.SendStatus(fiber.StatusOK)
}
