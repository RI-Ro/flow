package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/repository"
)

// countedCategories — категории, для которых в боковом меню показывается
// счётчик (#41).
//
// Архив и журналы исключены сознательно:
//   - архив растёт неограниченно, и его «количество» ни о чём не говорит —
//     реагировать там не на что, а считать пришлось бы по всей истории;
//   - журналы — это отчётная выборка с собственными фильтрами и своим
//     «показано N из M», счётчик в меню их только запутает.
var countedCategories = []repository.Category{
	repository.CategoryAll,
	repository.CategoryAwaiting,
	repository.CategoryOutgoing,
	repository.CategoryIncoming,
	repository.CategoryOnApproval,
	repository.CategoryOnSigning,
	repository.CategoryControl,
	repository.CategoryPrintUnreg,
	repository.CategoryExecuted,
}

// CategoryCounts GET /api/documents/category-counts — количество документов в
// каждой категории бокового меню (#41).
//
// Фронт опрашивает этот эндпоинт периодически и дополнительно по приходу
// WS-уведомления, чтобы числа менялись сами, а не только при клике на раздел.
// Поэтому запрос сделан дешёвым: все категории считаются ОДНИМ обращением к
// БД, условия берутся из того же построителя, что и у самих списков
// (repository.categoryCondition) — иначе счётчик и список расходились бы.
//
// RLS действует как обычно: пользователь видит количество только тех
// документов, которые ему доступны.
func (h *DocumentsHandler) CategoryCounts(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	counts := map[string]int64{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var deptID int64
		if err := tx.QueryRow(c.Context(),
			`SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); err != nil {
			return err
		}
		res, err := h.repo.CategoryCounts(c.Context(), tx, countedCategories, userID, deptID)
		if err != nil {
			return err
		}
		for cat, n := range res {
			counts[string(cat)] = n
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось посчитать документы по категориям")
	}
	return c.JSON(fiber.Map{"counts": counts})
}
