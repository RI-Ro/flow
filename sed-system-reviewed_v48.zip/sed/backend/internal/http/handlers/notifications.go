package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
)

type NotificationsHandler struct {
	pool *pgxpool.Pool
}

func NewNotificationsHandler(pool *pgxpool.Pool) *NotificationsHandler {
	return &NotificationsHandler{pool: pool}
}

// notificationItem — одна строка центра уведомлений.
//
// #7 — поле Text собирается НА СЕРВЕРЕ (service.NotificationText), а не на
// фронте по виду события: раньше фронт знал только kind и показывал безликое
// «Новое сообщение в обсуждении» без автора, текста и названия документа.
// Теперь текст один и тот же везде, где уведомление показывается.
type notificationItem struct {
	ID         int64   `json:"id"`
	Kind       string  `json:"kind"`
	Text       string  `json:"text"`
	DocumentID *int64  `json:"document_id,omitempty"`
	DocTitle   *string `json:"document_title,omitempty"`
	ActorName  string  `json:"actor_name,omitempty"`
	IsRead     bool    `json:"is_read"`
	// #2 — требует подтверждения (показывается блокирующей модалкой).
	RequiresAck bool   `json:"requires_ack"`
	SnoozedTill string `json:"snoozed_until,omitempty"`
	CreatedAt   string `json:"created_at"`
}

// listQuery — общая выборка уведомлений пользователя. extraWhere подставляется
// как дополнительное условие (фиксированные строки из кода, не пользовательский
// ввод).
const notificationsSelect = `
	SELECT n.id, n.kind, n.document_id, d.title,
	       coalesce(u.full_name, ''), coalesce(n.detail, ''), n.is_read, n.requires_ack,
	       coalesce(to_char(n.snoozed_until AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), ''),
	       to_char(n.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
	FROM notifications n
	LEFT JOIN documents d ON d.id = n.document_id
	LEFT JOIN users u ON u.id = n.actor_id
	WHERE n.user_id = $1`

func scanNotifications(rows pgx.Rows) ([]notificationItem, error) {
	defer rows.Close()
	var items []notificationItem
	for rows.Next() {
		var it notificationItem
		var title *string
		var actor, detail string
		if err := rows.Scan(&it.ID, &it.Kind, &it.DocumentID, &title,
			&actor, &detail, &it.IsRead, &it.RequiresAck, &it.SnoozedTill, &it.CreatedAt); err != nil {
			return nil, err
		}
		it.DocTitle = title
		it.ActorName = actor
		docTitle := ""
		if title != nil {
			docTitle = *title
		}
		it.Text = service.NotificationText(it.Kind, actor, detail, docTitle)
		items = append(items, it)
	}
	return items, rows.Err()
}

// List GET /api/notifications?only_unread=false&limit=50 — центр уведомлений.
// Возвращает уведомления текущего пользователя (RLS notifications_select уже
// ограничивает выборку своими), новые сверху, с флагом is_read — так центр
// показывает и непрочитанные, и прочитанные (по требованию "с возможностью
// просмотра прочитанных").
func (h *NotificationsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	onlyUnread := c.Query("only_unread") == "true"
	limit := 50
	if v := c.Query("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 200 {
			limit = n
		}
	}

	var items []notificationItem
	var unreadCount int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM notifications WHERE user_id=$1 AND is_read=false`, userID).Scan(&unreadCount); err != nil {
			return err
		}
		q := notificationsSelect
		if onlyUnread {
			q += ` AND n.is_read = false`
		}
		q += ` ORDER BY n.created_at DESC LIMIT $2`
		rows, err := tx.Query(c.Context(), q, userID, limit)
		if err != nil {
			return err
		}
		items, err = scanNotifications(rows)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить уведомления")
	}
	return c.JSON(fiber.Map{"items": items, "unread_count": unreadCount})
}

// Alarms GET /api/notifications/alarms — уведомления, требующие подтверждения
// (#2): непрочитанные, с requires_ack, срок «отложить» которых уже истёк.
// Именно их фронт показывает блокирующей модалкой со звуком.
//
// Отдельный эндпоинт, а не фильтр в List: модалка опрашивает его часто (и по
// каждому WS-событию), а выборка под частичный индекс idx_notifications_alarms
// заведомо узкая — полный список колокола для этого тянуть незачем.
func (h *NotificationsHandler) Alarms(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var items []notificationItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), notificationsSelect+`
			  AND n.requires_ack AND NOT n.is_read
			  AND (n.snoozed_until IS NULL OR n.snoozed_until <= now())
			ORDER BY n.created_at ASC
			LIMIT 20`, userID)
		if err != nil {
			return err
		}
		items, err = scanNotifications(rows)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить уведомления")
	}
	return c.JSON(fiber.Map{
		"items":          items,
		"snooze_minutes": service.SnoozeMinutes(),
		"repeat_seconds": service.AlarmRepeatSeconds(),
	})
}

// MarkRead POST /api/notifications/:id/read — отметить одно прочитанным.
func (h *NotificationsHandler) MarkRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// RLS notifications_update гарантирует, что пометить можно только своё.
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2`, id, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить прочитанным")
	}
	return c.SendStatus(fiber.StatusOK)
}

// MarkAllRead POST /api/notifications/read-all — отметить все прочитанными.
func (h *NotificationsHandler) MarkAllRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false`, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить все прочитанными")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Snooze POST /api/notifications/:id/snooze {minutes: 5|15|30} — отложить
// уведомление-будильник (#2).
//
// Допустимые интервалы проверяются на сервере: «отложить навсегда» через
// произвольно большое значение быть не должно — уведомления этого типа
// требуют действия, а не откладывания на сутки.
func (h *NotificationsHandler) Snooze(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Minutes int `json:"minutes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный запрос")
	}
	if !service.SnoozeAllowed(req.Minutes) {
		return fiber.NewError(fiber.StatusUnprocessableEntity, "отложить можно только на 5, 15 или 30 минут")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `
			UPDATE notifications
			   SET snoozed_until = now() + make_interval(mins => $3)
			 WHERE id = $1 AND user_id = $2`, id, userID, req.Minutes)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отложить уведомление")
	}
	return c.SendStatus(fiber.StatusOK)
}
