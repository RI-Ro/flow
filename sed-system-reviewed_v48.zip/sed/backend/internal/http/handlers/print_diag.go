package handlers

import (
	"fmt"
	"os"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/marking"
)

// PrintDiagnostics GET /api/documents/:id/print-diagnostics — почему документ
// НЕ выдаётся на печать (#11).
//
// Отказ в выдаче может произойти по нескольким независимым причинам (выключено
// вжигание, не настроен/не читается шрифт, нет обязательной маркировки, ошибка
// самого рендера). Раньше наружу шла одна общая ошибка, и причину приходилось
// искать по логам сервера. Этот эндпоинт возвращает ВСЕ проверки сразу —
// достаточно открыть его и увидеть конкретный пункт.
//
// Доступ: как и у самой печати, нужен доступ к документу; данные диагностики
// не содержат самого файла.
func (h *PrintsHandler) Diagnostics(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	type check struct {
		Name string `json:"name"`
		OK   bool   `json:"ok"`
		Info string `json:"info"`
	}
	var checks []check
	add := func(name string, ok bool, format string, args ...any) {
		checks = append(checks, check{Name: name, OK: ok, Info: fmt.Sprintf(format, args...)})
	}

	// 1) Включено ли вжигание и подключён ли рендер.
	add("marking.bake_into_pdf.enabled", h.markingCfg.Bake.Enabled,
		"в конфиге: %v", h.markingCfg.Bake.Enabled)
	add("рендер штампов подключён (RenderHook)", marking.IsBaking(h.markingCfg),
		"IsBaking=%v (enabled && RenderHook!=nil)", marking.IsBaking(h.markingCfg))

	// 2) Шрифт: путь задан, файл существует и читается.
	fontFile := h.markingCfg.FontFile
	if fontFile == "" {
		add("marking.font_file", false, "не задан — кириллица в штампах невозможна")
	} else {
		st, ferr := os.Stat(fontFile)
		if ferr != nil {
			add("marking.font_file", false, "%s — не доступен: %v (путь указывается ОТНОСИТЕЛЬНО рабочей директории процесса)", fontFile, ferr)
		} else {
			f, oerr := os.Open(fontFile)
			if oerr != nil {
				add("marking.font_file", false, "%s — не читается: %v", fontFile, oerr)
			} else {
				f.Close()
				add("marking.font_file", true, "%s (%d байт)", fontFile, st.Size())
			}
		}
	}

	// 3) Плейсхолдеры и обязательная маркировка конкретного документа.
	var missing []string
	var stampCount int
	var applyErr string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, userID, ph); err != nil {
			return err
		}
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		missing = requiredMarkingsMissing(ph)
		stampCount = len(marking.ComputeSpecs(h.markingCfg, ph))

		// 4) Пробный прогон рендера на реальном файле документа — именно он
		// показывает ошибку pdfcpu, если она есть.
		var content []byte
		if e := tx.QueryRow(c.Context(), `SELECT content FROM document_files WHERE document_id=$1`, id).Scan(&content); e != nil {
			applyErr = "файл документа не найден: " + e.Error()
			return nil
		}
		if _, e := marking.Apply(content, h.markingCfg, ph); e != nil {
			applyErr = e.Error()
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "диагностика не выполнена: "+txErr.Error())
	}

	add("обязательная маркировка документа", len(missing) == 0, "отсутствует: %v", missing)
	add("штампов будет нанесено", stampCount > 0, "%d", stampCount)
	add("пробное нанесение маркировки", applyErr == "", "%s", applyErr)

	ready := true
	for _, ch := range checks {
		if !ch.OK {
			ready = false
		}
	}
	return c.JSON(fiber.Map{"ready_for_print": ready, "checks": checks})
}
