package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// Counts GET /api/documents/:id/counts — счётчики для подписей вкладок (#17).
//
// Раньше узнать, есть ли в документе обсуждение, вложения или поручения, можно
// было только открыв каждую вкладку по очереди. Теперь количества стоят прямо
// в подписях вкладок, а для этого нужен один дешёвый запрос вместо загрузки
// содержимого всех вкладок.
//
// Все счётчики считаются ОДНИМ запросом скалярными подзапросами: шесть
// отдельных round-trip'ов к БД на каждое открытие карточки — это ровно та
// мелочь, которая на 1000 пользователей превращается в заметную нагрузку.
//
// RLS: доступ к документу проверяется через repo.GetByID (как и в остальных
// обработчиках карточки), дальше дочерние таблицы ограничены своими
// политиками/условием document_id.
func (h *DocumentsHandler) Counts(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var messages, files, copies, prints, links, assignments, recipients, acquaintances int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		return tx.QueryRow(c.Context(), `
			SELECT
			  (SELECT count(*) FROM chat_messages m
			    WHERE m.document_id = $1 AND m.deleted_at IS NULL),
			  (SELECT count(*) FROM chat_attachments a
			    JOIN chat_messages m ON m.id = a.message_id
			    WHERE m.document_id = $1 AND m.deleted_at IS NULL),
			  (SELECT count(*) FROM document_copies WHERE document_id = $1),
			  (SELECT count(*) FROM document_prints WHERE document_id = $1),
			  -- Связи двусторонние: документ может быть и источником, и целью.
			  -- Вкладка «Связанные» показывает и те и другие, поэтому считаем так же.
			  (SELECT count(*) FROM document_links
			    WHERE source_document_id = $1 OR target_document_id = $1),
			  (SELECT count(*) FROM assignments WHERE document_id = $1),
			  (SELECT count(*) FROM document_recipients WHERE document_id = $1),
			  (SELECT count(*) FROM document_acquaintances WHERE document_id = $1)`, id).
			Scan(&messages, &files, &copies, &prints, &links, &assignments, &recipients, &acquaintances)
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить счётчики")
	}
	return c.JSON(fiber.Map{
		"messages":      messages,
		"files":         files,
		"copies":        copies,
		"prints":        prints,
		"links":         links,
		"assignments":   assignments,
		"recipients":    recipients,
		"acquaintances": acquaintances,
	})
}
