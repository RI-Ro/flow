package handlers

import (
	"encoding/json"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

// PreferencesHandler — настройки пользователя (#3): состояние фильтров и
// прочие личные предпочтения интерфейса.
//
// Почему на сервере, а не в localStorage браузера: требование — «сохранять
// состояние фильтров для каждого пользователя», то есть настройки должны
// следовать за ЧЕЛОВЕКОМ. В localStorage они привязаны к браузеру: не
// переносятся на другой компьютер, теряются при очистке данных сайта и
// перемешиваются, если за одним компьютером работают по очереди несколько
// сотрудников — а в этой системе так и бывает (дежурный, подменный).
//
// Ключ-значение с jsonb: набор фильтров меняется от версии к версии, и
// заводить столбец под каждый фильтр (а потом миграцию на каждое изменение
// формы) смысла нет.
type PreferencesHandler struct {
	pool *pgxpool.Pool
}

func NewPreferencesHandler(pool *pgxpool.Pool) *PreferencesHandler {
	return &PreferencesHandler{pool: pool}
}

// maxPrefBytes — предел на одну настройку. Без него клиент мог бы хранить
// в настройках произвольные данные.
const maxPrefBytes = 16 << 10 // 16 КБ

// allowedPrefKeys — белый список ключей. Произвольные ключи не принимаем,
// чтобы таблица настроек не превратилась в хранилище чего угодно.
var allowedPrefKeys = map[string]bool{
	"filters.documents": true, // состояние фильтров списков документов
	"filters.registry":  true, // состояние фильтров журнала
	"ui.columns":        true, // выбранные столбцы списков
	"ui.tabs":           true, // последняя открытая вкладка
}

// Get GET /api/preferences/:key — вернуть настройку (или пустой объект).
func (h *PreferencesHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	key := c.Params("key")
	if !allowedPrefKeys[key] {
		return fiber.NewError(fiber.StatusBadRequest, "неизвестный ключ настройки")
	}

	var raw []byte
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		err := tx.QueryRow(c.Context(),
			`SELECT value FROM user_preferences WHERE user_id=$1 AND pref_key=$2`, userID, key).Scan(&raw)
		if err == pgx.ErrNoRows {
			raw = []byte("{}")
			return nil
		}
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось прочитать настройку")
	}
	c.Set("Content-Type", "application/json")
	return c.Send(raw)
}

// Put PUT /api/preferences/:key — сохранить настройку.
//
// Тело запроса пишется как есть (после проверки, что это корректный JSON и он
// не больше предела): сервер не знает и не должен знать состав полей фильтра
// на форме — иначе любое изменение формы требовало бы правки бэкенда.
func (h *PreferencesHandler) Put(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	key := c.Params("key")
	if !allowedPrefKeys[key] {
		return fiber.NewError(fiber.StatusBadRequest, "неизвестный ключ настройки")
	}

	body := c.Body()
	if len(body) > maxPrefBytes {
		return fiber.NewError(fiber.StatusRequestEntityTooLarge, "настройка слишком большая")
	}
	if len(body) == 0 {
		body = []byte("{}")
	}
	// Проверяем, что это именно JSON-объект: иначе в jsonb попало бы число или
	// строка, и чтение на фронте падало бы на неожиданной форме данных.
	var probe map[string]any
	if err := json.Unmarshal(body, &probe); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "ожидается JSON-объект")
	}

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `
			INSERT INTO user_preferences (user_id, pref_key, value, updated_at)
			VALUES ($1, $2, $3::jsonb, now())
			ON CONFLICT (user_id, pref_key)
			DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
			userID, key, string(body))
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сохранить настройку")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/preferences/:key — сбросить настройку (кнопка «сбросить
// фильтры» должна убирать и сохранённое состояние, иначе оно вернётся при
// следующем открытии списка).
func (h *PreferencesHandler) Delete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	key := c.Params("key")
	if !allowedPrefKeys[key] {
		return fiber.NewError(fiber.StatusBadRequest, "неизвестный ключ настройки")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(),
			`DELETE FROM user_preferences WHERE user_id=$1 AND pref_key=$2`, userID, key)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сбросить настройку")
	}
	return c.SendStatus(fiber.StatusOK)
}
