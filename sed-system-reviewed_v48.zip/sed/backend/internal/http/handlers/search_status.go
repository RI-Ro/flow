package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/indexer"
)

// SearchHandler — состояние фоновой индексации содержимого PDF (#4).
type SearchHandler struct {
	pool *pgxpool.Pool
}

func NewSearchHandler(pool *pgxpool.Pool) *SearchHandler {
	return &SearchHandler{pool: pool}
}

// IndexStatus GET /api/search/index-status — сколько документов
// проиндексировано для поиска по содержимому.
//
// Нужен прелоадеру на фронте: пока индексация не завершена, поиск по
// содержимому даёт НЕПОЛНЫЙ результат, и пользователь должен это видеть, а не
// думать, что документа в системе нет. Поэтому ответ показывается рядом с
// полем поиска по содержимому.
//
// Без RLS-контекста: это агрегат по служебной таблице состояния индексации, в
// нём нет ни заголовков, ни текста документов — только счётчики. Пользователю
// он ничего не раскрывает, а делать его персональным (считать только «свои»
// документы) и дорого, и бессмысленно: прогресс индексации общий.
func (h *SearchHandler) IndexStatus(c *fiber.Ctx) error {
	st, err := indexer.QueryStatus(c.Context(), h.pool)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить состояние индексации")
	}
	return c.JSON(st)
}
