package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/search"
)

// FilterPeople GET /api/users/filter-candidates?q=&role=&limit= — люди для
// ФИЛЬТРОВ поиска документов (#28).
//
// Почему отдельный эндпоинт, а не /users/candidates.
//
// /users/candidates отвечает на вопрос «кого можно ВЫБРАТЬ исполнителем
// действия»: он ограничен ролью, иерархией подразделений и только активными
// пользователями — и это правильно для форм создания и маршрута.
//
// Для фильтра вопрос другой: «по кому можно ИСКАТЬ уже существующие
// документы». Здесь ограничения вредны и были причиной замечания:
//
//   - подписанты не должны ограничиваться иерархией: документ мог подписать
//     руководитель из другого подразделения, и его обязательно надо видеть в
//     фильтре, иначе найти документ по подписанту невозможно;
//   - в авторах должен быть и сам пользователь (в /users/candidates он
//     исключён: себя нельзя назначить согласующим, но свои документы искать
//     нужно в первую очередь);
//   - уволенные и переименованные пользователи обязаны оставаться в списке:
//     документы, которые они подписали, никуда не исчезли, и найти их иначе
//     нельзя. Такие помечаются inactive, чтобы было видно, почему человека
//     нет в других списках.
//
// role=signer|author|approver|recipient|controller сужает выборку до тех, кто
// РЕАЛЬНО встречается в этой роли хотя бы в одном документе — список людей
// получается коротким и осмысленным, без всего справочника.
//
// Регистр: сравнение идёт через fold_ru с обеих сторон, а не ILIKE. В базе с
// локалью C (а такие встречаются) ILIKE не приводит регистр кириллицы, и
// поиск «Иванов» не находил бы «иванов» — проверено на живой БД.
//
// RLS: выборка идёт по users (на них RLS нет), но список ролей строится по
// документам, ВИДИМЫМ пользователю, — поэтому через WithUserTx.
func (h *UsersHandler) FilterPeople(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	q := search.FoldRU(c.Query("q"))
	limit := 20
	if l := c.Query("limit"); l != "" {
		if n, err := strconv.Atoi(l); err == nil && n > 0 && n <= 100 {
			limit = n
		}
	}

	// Подзапрос «встречается в роли». Строки фиксированные, из кода.
	var roleExists string
	switch c.Query("role") {
	case "author":
		roleExists = `EXISTS (SELECT 1 FROM documents d WHERE d.author_id = u.id)`
	case "signer":
		roleExists = `EXISTS (SELECT 1 FROM document_signatures s WHERE s.signer_id = u.id)`
	case "approver":
		roleExists = `EXISTS (SELECT 1 FROM approval_stages a WHERE a.approver_id = u.id)`
	case "recipient":
		roleExists = `EXISTS (SELECT 1 FROM document_recipients r WHERE r.recipient_user_id = u.id)`
	case "controller":
		roleExists = `EXISTS (SELECT 1 FROM documents d WHERE d.controller_id = u.id)`
	default:
		roleExists = "TRUE"
	}

	type person struct {
		ID         int64  `json:"id"`
		FullName   string `json:"full_name"`
		Position   string `json:"position"`
		Department string `json:"department_name"`
		IsActive   bool   `json:"is_active"`
	}
	var items []person
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, u.full_name, coalesce(u.position,''), coalesce(dep.name,''), u.is_active
			FROM users u
			LEFT JOIN departments dep ON dep.id = u.primary_department_id
			WHERE (`+roleExists+`)
			  AND ($1 = '' OR fold_ru(u.full_name) LIKE '%' || $1 || '%'
			                OR fold_ru(coalesce(u.position,'')) LIKE '%' || $1 || '%'
			                OR fold_ru(coalesce(dep.name,'')) LIKE '%' || $1 || '%')
			-- Активные выше уволенных, дальше по алфавиту: уволенные нужны, но
			-- не должны мешать выбору действующего сотрудника.
			ORDER BY u.is_active DESC, u.full_name
			LIMIT $2`, q, limit)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var p person
			if err := rows.Scan(&p.ID, &p.FullName, &p.Position, &p.Department, &p.IsActive); err != nil {
				return err
			}
			items = append(items, p)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить список людей для фильтра")
	}
	return c.JSON(fiber.Map{"items": items})
}
