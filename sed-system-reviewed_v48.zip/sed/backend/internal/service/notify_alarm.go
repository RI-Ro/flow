package service

import "sync"

// ============================================================================
// #2 — УВЕДОМЛЕНИЯ-«БУДИЛЬНИКИ».
//
// Часть уведомлений нельзя пропустить: пришло на согласование, дали поручение,
// направили документ, истёк срок. Они показываются блокирующей модалкой со
// звуком, пока пользователь не прочитает их или не отложит на 5/15/30 минут.
//
// Признак «требует подтверждения» определяется ОДНИМ списком видов событий, а
// не решением каждого вызывающего места: иначе одно и то же событие заводило
// бы будильник в одной ветке кода и не заводило в другой. Список настраивается
// в config.yaml (notifications.alarm_kinds).
// ============================================================================

// DefaultAlarmKinds — виды событий-будильников по умолчанию: это те, которые
// требуют ДЕЙСТВИЯ пользователя, а не просто информируют его.
var DefaultAlarmKinds = []string{
	"stage_pending", // требуется ваше решение по согласованию/подписи
	"assignment",    // вам дано поручение
	"document_sent", // вам направлен документ
	"acquaintance",  // вам направлен документ на ознакомление
	"overdue",       // истёк срок
}

// DefaultSnoozeMinutes — допустимые интервалы «отложить». По требованию ровно
// эти три; значения вне списка сервер отклоняет.
var DefaultSnoozeMinutes = []int{5, 15, 30}

// DefaultAlarmRepeatSeconds — период повторного сигнала, пока окно открыто.
const DefaultAlarmRepeatSeconds = 20

var (
	alarmMu       sync.RWMutex
	alarmKinds    = toSet(DefaultAlarmKinds)
	snoozeMinutes = DefaultSnoozeMinutes
	repeatSeconds = DefaultAlarmRepeatSeconds
)

// ConfigureAlarms задаётся один раз на старте из конфига. Пустые/нулевые
// значения означают «оставить значения по умолчанию».
func ConfigureAlarms(kinds []string, snooze []int, repeat int) {
	alarmMu.Lock()
	defer alarmMu.Unlock()
	if len(kinds) > 0 {
		alarmKinds = toSet(kinds)
	}
	if len(snooze) > 0 {
		snoozeMinutes = snooze
	}
	if repeat > 0 {
		repeatSeconds = repeat
	}
}

// AlarmRepeatSeconds — период повторного звукового сигнала для фронта.
func AlarmRepeatSeconds() int {
	alarmMu.RLock()
	defer alarmMu.RUnlock()
	return repeatSeconds
}

// RequiresAck — заводить ли будильник для этого вида события.
func RequiresAck(kind string) bool {
	alarmMu.RLock()
	defer alarmMu.RUnlock()
	return alarmKinds[kind]
}

// SnoozeAllowed проверяет интервал «отложить» (минуты).
func SnoozeAllowed(minutes int) bool {
	alarmMu.RLock()
	defer alarmMu.RUnlock()
	for _, m := range snoozeMinutes {
		if m == minutes {
			return true
		}
	}
	return false
}

// SnoozeMinutes — список допустимых интервалов (отдаётся фронту, чтобы кнопки
// в модалке не были захардкожены).
func SnoozeMinutes() []int {
	alarmMu.RLock()
	defer alarmMu.RUnlock()
	out := make([]int, len(snoozeMinutes))
	copy(out, snoozeMinutes)
	return out
}

func toSet(ss []string) map[string]bool {
	m := make(map[string]bool, len(ss))
	for _, s := range ss {
		m[s] = true
	}
	return m
}
