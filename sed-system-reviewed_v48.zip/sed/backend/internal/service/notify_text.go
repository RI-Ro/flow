package service

import "strings"

// ============================================================================
// #7 — ЕДИНЫЙ ТЕКСТ УВЕДОМЛЕНИЯ.
//
// Раньше текст собирался на фронте по одному полю `kind` (карта KIND_LABELS),
// поэтому все уведомления были безликими: «Новое сообщение в обсуждении» —
// без автора, без самого сообщения, без названия документа. Отсюда и
// замечание: нужен единый вид
//
//	Иванов Иван оставил комментарий «выполнено» в документе «Подать сведения»
//
// Текст строится на СЕРВЕРЕ и ровно в одном месте — этой функции. Так он
// одинаков в колоколе, в модалке-будильнике и в любом будущем канале (почта,
// push), и его нельзя «забыть» в одном из них.
//
// Формулировка задаётся ШАБЛОНОМ на каждый вид события, а не склейкой
// «актор + глагол + хвост»: по-русски место слова «документ» в предложении
// разное («подписал документ «…»», но «оставил комментарий «…» в документе
// «…»»), и универсальная склейка давала «подписал документ в документе «…»».
//
// Подстановки:
//
//	{A} — ФИО инициатора
//	{D} — заголовок документа
//	{X} — деталь события (текст комментария, причина отклонения, …)
//
// Фрагмент в квадратных скобках выбрасывается целиком, если подстановка
// внутри него пустая. Так один шаблон работает и когда детали нет.
// ============================================================================

type notificationTemplate struct {
	// WithActor — когда известен инициатор.
	WithActor string
	// Impersonal — системные события и строки без актора (уведомления,
	// созданные до миграции 0014).
	Impersonal string
}

var notificationTemplates = map[string]notificationTemplate{
	"chat_message": {
		WithActor:  `{A} оставил комментарий[ «{X}»][ в документе «{D}»]`,
		Impersonal: `Новый комментарий[ «{X}»][ в документе «{D}»]`,
	},
	"stage_pending": {
		// Этап активируется системой (предыдущий согласующий закрыл свой
		// этап), поэтому осмысленного актора здесь нет в принципе.
		WithActor:  `Требуется ваше решение по документу[ «{D}»]`,
		Impersonal: `Требуется ваше решение по документу[ «{D}»]`,
	},
	"stage_approved": {
		WithActor:  `{A} согласовал документ[ «{D}»][. Комментарий: «{X}»]`,
		Impersonal: `Документ[ «{D}»] согласован`,
	},
	"stage_rejected": {
		WithActor:  `{A} отклонил документ[ «{D}»][. Причина: «{X}»]`,
		Impersonal: `Документ[ «{D}»] отклонён[. Причина: «{X}»]`,
	},
	"approver_added": {
		WithActor:  `{A} добавил согласующего в маршрут документа[ «{D}»]`,
		Impersonal: `В маршрут документа[ «{D}»] добавлен согласующий`,
	},
	"document_signed": {
		WithActor:  `{A} подписал документ[ «{D}»]`,
		Impersonal: `Документ[ «{D}»] подписан`,
	},
	"document_sent": {
		WithActor:  `{A} направил вам документ[ «{D}»]`,
		Impersonal: `Вам направлен документ[ «{D}»]`,
	},
	"route_restarted": {
		WithActor:  `{A} перезапустил маршрут согласования документа[ «{D}»]`,
		Impersonal: `Маршрут согласования документа[ «{D}»] перезапущен`,
	},
	"assignment": {
		WithActor:  `{A} дал вам поручение по документу[ «{D}»][: «{X}»]`,
		Impersonal: `Вам дано поручение по документу[ «{D}»][: «{X}»]`,
	},
	"assignment_status_changed": {
		WithActor:  `{A} изменил статус поручения по документу[ «{D}»][: «{X}»]`,
		Impersonal: `Изменён статус поручения по документу[ «{D}»][: «{X}»]`,
	},
	"control_assigned": {
		WithActor:  `{A} назначил вас контролёром документа[ «{D}»]`,
		Impersonal: `Вы назначены контролёром документа[ «{D}»]`,
	},
	"acquaintance": {
		WithActor:  `{A} направил вам на ознакомление документ[ «{D}»]`,
		Impersonal: `Вам направлен на ознакомление документ[ «{D}»]`,
	},
	"acquainted": {
		WithActor:  `{A} ознакомился с документом[ «{D}»]`,
		Impersonal: `Ознакомление с документом[ «{D}»]`,
	},
	"document_updated": {
		WithActor:  `{A} изменил документ[ «{D}»]`,
		Impersonal: `Документ[ «{D}»] изменён`,
	},
	"recipient_added": {
		WithActor:  `{A} добавил получателя в рассылку документа[ «{D}»]`,
		Impersonal: `В рассылку документа[ «{D}»] добавлен получатель`,
	},
	"print_registered": {
		WithActor:  `{A} зарегистрировал экземпляр документа[ «{D}»]`,
		Impersonal: `Зарегистрирован экземпляр документа[ «{D}»]`,
	},
	"due_soon": {
		WithActor:  `Приближается срок исполнения документа[ «{D}»]`,
		Impersonal: `Приближается срок исполнения документа[ «{D}»]`,
	},
	"overdue": {
		WithActor:  `Истёк срок исполнения документа[ «{D}»]`,
		Impersonal: `Истёк срок исполнения документа[ «{D}»]`,
	},
}

// fallbackTemplate — новый вид события, для которого шаблон ещё не написан.
// Лучше нейтральная, но осмысленная фраза, чем пустое уведомление.
var fallbackTemplate = notificationTemplate{
	WithActor:  `{A} выполнил действие по документу[ «{D}»][: «{X}»]`,
	Impersonal: `Обновление по документу[ «{D}»][: «{X}»]`,
}

// maxDetailRunes — деталь в уведомлении обрезается: комментарий может быть на
// несколько абзацев, а уведомление должно читаться одной строкой.
const maxDetailRunes = 120

// NotificationText собирает текст уведомления.
//
//	kind      — вид события (notifications.kind);
//	actorName — ФИО инициатора ("" если неизвестен/системное событие);
//	detail    — деталь события: текст комментария, причина отклонения и т.п.;
//	docTitle  — заголовок документа ("" если уведомление не о документе).
func NotificationText(kind, actorName, detail, docTitle string) string {
	actorName = strings.TrimSpace(actorName)
	detail = normalizeDetail(detail)
	docTitle = normalizeDetail(docTitle)

	tpl, ok := notificationTemplates[kind]
	if !ok {
		tpl = fallbackTemplate
	}
	pattern := tpl.Impersonal
	if actorName != "" {
		pattern = tpl.WithActor
	}
	return renderTemplate(pattern, map[string]string{
		"{A}": actorName,
		"{D}": docTitle,
		"{X}": detail,
	})
}

// renderTemplate подставляет значения и выбрасывает фрагменты в квадратных
// скобках, в которых хотя бы одна подстановка пуста.
func renderTemplate(pattern string, vals map[string]string) string {
	var out strings.Builder
	for {
		open := strings.IndexByte(pattern, '[')
		if open < 0 {
			out.WriteString(substitute(pattern, vals))
			break
		}
		close := strings.IndexByte(pattern[open:], ']')
		if close < 0 {
			// Незакрытая скобка — считаем остаток обычным текстом.
			out.WriteString(substitute(pattern, vals))
			break
		}
		close += open

		out.WriteString(substitute(pattern[:open], vals))
		group := pattern[open+1 : close]
		if groupFilled(group, vals) {
			out.WriteString(substitute(group, vals))
		}
		pattern = pattern[close+1:]
	}
	return strings.TrimSpace(out.String())
}

// groupFilled — есть ли в фрагменте хоть одна подстановка и все ли они
// непустые. Фрагмент без подстановок считается заполненным.
func groupFilled(group string, vals map[string]string) bool {
	for k, v := range vals {
		if strings.Contains(group, k) && v == "" {
			return false
		}
	}
	return true
}

func substitute(s string, vals map[string]string) string {
	for k, v := range vals {
		s = strings.ReplaceAll(s, k, v)
	}
	return s
}

// normalizeDetail приводит текст к одной строке и обрезает по длине, не
// разрывая символ (режем по рунам, а не по байтам — текст русский).
func normalizeDetail(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return ""
	}
	// Переводы строк и табуляции превращаем в пробелы, кратные пробелы — в один.
	s = strings.NewReplacer("\r", " ", "\n", " ", "\t", " ").Replace(s)
	s = strings.Join(strings.Fields(s), " ")
	// Кавычки внутри заменяем на одинарные: иначе внешние «…» визуально
	// ломаются.
	s = strings.NewReplacer("«", "‹", "»", "›", `"`, "'").Replace(s)

	r := []rune(s)
	if len(r) > maxDetailRunes {
		return strings.TrimSpace(string(r[:maxDetailRunes])) + "…"
	}
	return s
}
