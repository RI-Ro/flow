package config

import (
	"os"
	"strconv"
	"time"
)

// Config собирает все настраиваемые параметры приложения из переменных
// окружения. Ничего не хардкодим, чтобы одни и те же бинарники/образы
// использовались во всех окружениях (dev/stage/prod).
type Config struct {
	HTTPAddr    string
	DatabaseURL string
	// #5 — Привилегированное подключение ТОЛЬКО для миграций, политик RLS и
	// создания прикладной роли. Рабочий пул (DatabaseURL) обязан ходить
	// обычной ролью, иначе PostgreSQL отключает RLS целиком (см.
	// internal/db/approle.go). По умолчанию равен DatabaseURL — поведение
	// прежних версий сохраняется.
	MigrateDatabaseURL string
	// Прикладная роль, которую бэкенд создаёт/обновляет на старте.
	// Пустое APP_DB_ROLE — ничего не создавать (роль заведена вручную).
	AppDBRole      string
	AppDBPassword  string
	JWTSecret      string
	JWTTTL         time.Duration
	PageSize       int // размер страницы списков документов (по ТЗ: 20, настраивается)
	PageSizeMax    int // защита от злоупотребления ?page_size=100000
	AllowedOrigins string
	MigrationsDir  string // путь к SQL-миграциям, применяются при старте
}

func Load() Config {
	dbURL := getEnv("DATABASE_URL", "postgres://sed:sed@localhost:5432/sed?sslmode=disable")
	return Config{
		HTTPAddr:           getEnv("HTTP_ADDR", ":8080"),
		DatabaseURL:        dbURL,
		MigrateDatabaseURL: getEnv("MIGRATE_DATABASE_URL", dbURL),
		AppDBRole:          getEnv("APP_DB_ROLE", ""),
		AppDBPassword:      getEnv("APP_DB_PASSWORD", ""),
		JWTSecret:          getEnv("JWT_SECRET", "CHANGE_ME_IN_PRODUCTION"),
		JWTTTL:             getEnvDuration("JWT_TTL", 12*time.Hour),
		PageSize:           getEnvInt("PAGE_SIZE", 20),
		PageSizeMax:        getEnvInt("PAGE_SIZE_MAX", 100),
		AllowedOrigins:     getEnv("ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"),
		MigrationsDir:      getEnv("MIGRATIONS_DIR", "./migrations"),
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getEnvInt(key string, fallback int) int {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return fallback
}

func getEnvDuration(key string, fallback time.Duration) time.Duration {
	if v := os.Getenv(key); v != "" {
		if d, err := time.ParseDuration(v); err == nil {
			return d
		}
	}
	return fallback
}
