package config

import (
	"log"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

// FileConfig — полная структура config.yaml. Загружается опционально: если
// файла нет, используются значения по умолчанию + переменные окружения
// (env имеет приоритет над файлом, файл — над встроенными дефолтами).
type FileConfig struct {
	HTTP struct {
		Addr           string   `yaml:"addr"`
		AllowedOrigins []string `yaml:"allowed_origins"`
		Prefork        bool     `yaml:"prefork"`
	} `yaml:"http"`
	Database struct {
		URL      string `yaml:"url"`
		MaxConns int32  `yaml:"max_conns"`
		MinConns int32  `yaml:"min_conns"`
		// #5 — привилегированное подключение для миграций/политик/создания
		// прикладной роли. См. internal/db/approle.go.
		MigrateURL  string `yaml:"migrate_url"`
		AppRole     string `yaml:"app_role"`
		AppPassword string `yaml:"app_password"`
	} `yaml:"database"`
	Auth struct {
		JWTSecret string `yaml:"jwt_secret"`
		JWTTTL    string `yaml:"jwt_ttl"`
	} `yaml:"auth"`
	Pagination struct {
		PageSize    int `yaml:"page_size"`
		PageSizeMax int `yaml:"page_size_max"`
	} `yaml:"pagination"`
	Static struct {
		// Dir — путь к каталогу собранной статики фронтенда (Vite build, папка
		// dist). Если задан, приложение само раздаёт статику и делает SPA-
		// fallback на index.html (nginx не нужен). Пусто — статика не
		// раздаётся (режим «только API», фронт обслуживается отдельно).
		Dir string `yaml:"dir"`
	} `yaml:"static"`
	AccessLog struct {
		// Dir — каталог для access-логов запросов (по аналогии с nginx/apache).
		// Если задан, каждый HTTP-запрос пишется строкой в файл access.log в
		// этом каталоге (время, ip, метод, url, статус, длительность, login).
		// Пусто — access-лог в файл не пишется (остаётся консольный logger).
		Dir string `yaml:"dir"`
	} `yaml:"access_log"`
	Realtime      RealtimeConfig      `yaml:"realtime"`
	Marking       MarkingConfig       `yaml:"marking"`
	Lifecycle     LifecycleConfig     `yaml:"lifecycle"`
	Branding      BrandingConfig      `yaml:"branding"`
	Numbering     NumberingConfig     `yaml:"numbering"`
	Notifications NotificationsConfig `yaml:"notifications"`
	Search        SearchConfig        `yaml:"search"`
}

// SearchConfig — поиск по содержимому PDF и его фоновая индексация (#4).
type SearchConfig struct {
	// Enabled — запускать ли индексатор в этом процессе. Выключение не ломает
	// поиск по уже проиндексированному, только останавливает наполнение.
	Enabled *bool `yaml:"enabled"`
	// BatchSize — сколько документов берётся за один проход очереди.
	BatchSize int `yaml:"batch_size"`
	// IntervalSeconds — пауза, когда очередь пуста.
	IntervalSeconds int `yaml:"interval_seconds"`
	// MaxAttempts — после скольких неудач документ перестаёт выбираться.
	MaxAttempts int `yaml:"max_attempts"`
	// ExtractCommand — команда извлечения текста: PDF подаётся на stdin,
	// текст ожидается в stdout. По умолчанию pdftotext (poppler-utils).
	ExtractCommand []string `yaml:"extract_command"`
	// ExtractTimeoutSeconds — предел на один файл.
	ExtractTimeoutSeconds int `yaml:"extract_timeout_seconds"`
	// StaleAfterSeconds — через сколько взятое в работу задание считается
	// зависшим (воркер умер) и возвращается в очередь. Обязано быть больше
	// extract_timeout_seconds, иначе задание отберут у работающего воркера.
	StaleAfterSeconds int `yaml:"stale_after_seconds"`
	// MaxTextBytes — сколько текста хранить и индексировать на документ.
	MaxTextBytes int `yaml:"max_text_bytes"`
	// StoreText — хранить ли сам текст (нужен для показа фрагмента).
	StoreText *bool `yaml:"store_text"`
}

// NotificationsConfig — поведение уведомлений (#2).
type NotificationsConfig struct {
	// AlarmKinds — виды событий, которые показываются блокирующей модалкой со
	// звуком, пока пользователь их не прочитает или не отложит. Пусто —
	// применяется список по умолчанию (см. service.DefaultAlarmKinds).
	AlarmKinds []string `yaml:"alarm_kinds"`
	// SnoozeMinutes — допустимые интервалы «отложить», в минутах. По
	// требованию — ровно 5/15/30, другие значения сервер не принимает.
	SnoozeMinutes []int `yaml:"snooze_minutes"`
	// RepeatSeconds — период повторного звукового сигнала, пока модалка
	// открыта. 0 — не повторять.
	RepeatSeconds int `yaml:"repeat_seconds"`
}

// NumberingConfig — параметры формирования регистрационных номеров.
type NumberingConfig struct {
	// NumberPrefixForAll — УСТАРЕЛО и больше не используется. Формат номера
	// теперь: ИСХ-{префикс_подразделения}-{номер}/{год} (напр. ИСХ-9/8/7-231/2026,
	// ИСХ-ГУ-231/2026), без общего хвоста. Поле оставлено для обратной
	// совместимости конфигов и игнорируется.
	NumberPrefixForAll string `yaml:"number_prefix_for_all"`
}

// BrandingConfig — отображаемое название системы и подзаголовок (kicker).
// Отдаётся фронту через GET /api/app-config, чтобы «SED» и «// доведение
// указаний» не были захардкожены в интерфейсе.
type BrandingConfig struct {
	AppName   string `yaml:"app_name"`
	Tagline   string `yaml:"tagline"`
	Copyright string `yaml:"copyright"` // текст после "©" под кнопкой «Выйти»
	// About — справочная информация, контакты техподдержки, автор проекта и т.д.
	// Показывается в модальном окне при клике на "©". Многострочный текст
	// (переносы сохраняются). Полностью настраивается здесь.
	About string `yaml:"about"`
}

// LoadWithFile читает config.yaml (путь из env CONFIG_FILE или ./config.yaml),
// затем накладывает переменные окружения. Возвращает основной Config (как
// раньше) плюс расширенные секции (Marking, Lifecycle, Realtime), которых в
// плоском env быть не может.
func LoadWithFile() (Config, FileConfig) {
	return LoadWithFilePath("")
}

// LoadWithFilePath — как LoadWithFile, но с явным путём к конфигу (флаг
// --config). Приоритет пути: явный аргумент > env CONFIG_FILE > ./config.yaml.
func LoadWithFilePath(explicitPath string) (Config, FileConfig) {
	var fc FileConfig
	explicit := firstNonEmpty(explicitPath, os.Getenv("CONFIG_FILE"))
	path := firstNonEmpty(explicit, "config.yaml")
	data, readErr := os.ReadFile(path)
	if readErr != nil {
		// Если путь задан ЯВНО (флаг --config или env CONFIG_FILE) и файл не
		// читается — это ошибка конфигурации, а не «нет дефолтного файла».
		// Раньше ошибка молча проглатывалась и применялись дефолты — из-за
		// этого казалось, что --config «не читается».
		if explicit != "" {
			log.Fatalf("не удалось прочитать конфиг %q: %v", path, readErr)
		}
		log.Printf("конфиг %q не найден — используются значения по умолчанию и env", path)
	} else {
		if err := yaml.Unmarshal(data, &fc); err != nil {
			log.Fatalf("ошибка разбора YAML-конфига %q: %v", path, err)
		}
		log.Printf("конфиг загружен: %s", path)
	}

	// Значения по умолчанию для брендинга (если в файле не заданы).
	if fc.Branding.AppName == "" {
		fc.Branding.AppName = "SED"
	}
	if fc.Branding.Tagline == "" {
		fc.Branding.Tagline = "// доведение указаний"
	}
	if fc.Branding.Copyright == "" {
		fc.Branding.Copyright = fc.Branding.AppName + " · Система электронного документооборота"
	}
	// Хвост номеров: если не задан явно — берём app_name (обратная совместимость).
	if fc.Numbering.NumberPrefixForAll == "" {
		fc.Numbering.NumberPrefixForAll = fc.Branding.AppName
	}
	if fc.Branding.About == "" {
		fc.Branding.About = "Система электронного документооборота «" + fc.Branding.AppName + "».\n\n" +
			"Техническая поддержка: support@example.com, тел. +7 (000) 000-00-00.\n" +
			"Режим работы: пн–пт, 9:00–18:00.\n\n" +
			"Настройте этот текст в конфиге: branding.about."
	}

	// Env-override пути шрифта штампов (различается alpine/debian).
	if v := os.Getenv("MARKING_FONT_FILE"); v != "" {
		fc.Marking.FontFile = v
	}
	if v := os.Getenv("MARKING_FONT_NAME"); v != "" {
		fc.Marking.FontName = v
	}
	// Быстрый тумблер вжигания через env (MARKING_BAKE=true|1|on).
	if v := os.Getenv("MARKING_BAKE"); v != "" {
		switch v {
		case "1", "true", "TRUE", "on", "yes":
			fc.Marking.Bake.Enabled = true
		case "0", "false", "FALSE", "off", "no":
			fc.Marking.Bake.Enabled = false
		}
	}
	// Шрифт для вжигания: если в секции bake не задан — берём общий marking.font_*.
	if fc.Marking.Bake.FontFile == "" {
		fc.Marking.Bake.FontFile = fc.Marking.FontFile
	}
	if fc.Marking.Bake.FontName == "" {
		fc.Marking.Bake.FontName = fc.Marking.FontName
	}
	// Env-override каталога статики фронтенда (одно приложение раздаёт и API, и
	// статику; nginx не нужен).
	if v := os.Getenv("STATIC_DIR"); v != "" {
		fc.Static.Dir = v
	}
	if v := os.Getenv("ACCESS_LOG_DIR"); v != "" {
		fc.AccessLog.Dir = v
	}

	dbURL := firstNonEmpty(os.Getenv("DATABASE_URL"), fc.Database.URL, "postgres://sed:sed@localhost:5432/sed?sslmode=disable")
	cfg := Config{
		HTTPAddr:    firstNonEmpty(os.Getenv("HTTP_ADDR"), fc.HTTP.Addr, ":8080"),
		DatabaseURL: dbURL,
		// Если привилегированный DSN не задан — работаем как раньше (одна роль
		// на всё). Тогда на старте в лог уйдёт предупреждение о том, что RLS
		// не действует (см. db.WarnIfRLSBypassed).
		MigrateDatabaseURL: firstNonEmpty(os.Getenv("MIGRATE_DATABASE_URL"), fc.Database.MigrateURL, dbURL),
		AppDBRole:          firstNonEmpty(os.Getenv("APP_DB_ROLE"), fc.Database.AppRole),
		AppDBPassword:      firstNonEmpty(os.Getenv("APP_DB_PASSWORD"), fc.Database.AppPassword),
		JWTSecret:          firstNonEmpty(os.Getenv("JWT_SECRET"), fc.Auth.JWTSecret, "CHANGE_ME_IN_PRODUCTION"),
		JWTTTL:             parseDurationOr(firstNonEmpty(os.Getenv("JWT_TTL"), fc.Auth.JWTTTL), 12*time.Hour),
		PageSize:           firstPositive(getEnvInt("PAGE_SIZE", 0), fc.Pagination.PageSize, 20),
		PageSizeMax:        firstPositive(getEnvInt("PAGE_SIZE_MAX", 0), fc.Pagination.PageSizeMax, 100),
		AllowedOrigins:     firstNonEmpty(os.Getenv("ALLOWED_ORIGINS"), joinOrigins(fc.HTTP.AllowedOrigins), "http://localhost:5173,http://127.0.0.1:5173"),
		MigrationsDir:      getEnv("MIGRATIONS_DIR", "./migrations"),
	}
	return cfg, fc
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}

func firstPositive(vals ...int) int {
	for _, v := range vals {
		if v > 0 {
			return v
		}
	}
	return 0
}

func parseDurationOr(s string, fallback time.Duration) time.Duration {
	if d, err := time.ParseDuration(s); err == nil {
		return d
	}
	return fallback
}

func joinOrigins(origins []string) string {
	out := ""
	for i, o := range origins {
		if i > 0 {
			out += ","
		}
		out += o
	}
	return out
}
