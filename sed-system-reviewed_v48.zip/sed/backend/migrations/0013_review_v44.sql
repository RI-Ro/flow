-- +goose Up
-- ============================================================================
-- Ревью v44 (группа A).
--   #25 цвет категории документа (для подсветки строки в списках);
--   #24 отказ от departments.outgoing_prefix.
-- ============================================================================

-- #25 — Цвет категории. Хранится как HEX "#rrggbb"; пусто = без подсветки.
ALTER TABLE document_categories ADD COLUMN IF NOT EXISTS color TEXT;

UPDATE document_categories SET color = '#2F6FEB' WHERE code = 'permanent' AND color IS NULL;
UPDATE document_categories SET color = '#B8860B' WHERE code = 'temporary' AND color IS NULL;

-- #24 — Удаление outgoing_prefix.
-- ВАЖНО: столбец НЕ был «неиспользуемым» — в numbering.go он служил запасным
-- префиксом нумерации: coalesce(NULLIF(numbering_prefix,''), outgoing_prefix).
-- Поэтому сначала переносим значение в numbering_prefix тем подразделениям, у
-- которых он пуст, и только затем удаляем столбец. Так нумерация сохраняется
-- ровно в том виде, в каком она выдавалась до удаления.
UPDATE departments
   SET numbering_prefix = outgoing_prefix
 WHERE coalesce(numbering_prefix, '') = ''
   AND coalesce(outgoing_prefix, '') <> '';

ALTER TABLE departments DROP COLUMN IF EXISTS outgoing_prefix;

-- +goose Down
ALTER TABLE departments ADD COLUMN IF NOT EXISTS outgoing_prefix TEXT;
UPDATE departments SET outgoing_prefix = coalesce(numbering_prefix, 'DEP' || id::text) WHERE outgoing_prefix IS NULL;
ALTER TABLE document_categories DROP COLUMN IF EXISTS color;
