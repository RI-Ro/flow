-- +goose Up
-- ============================================================================
-- Ревью v48 (#37) — индексы и оптимизация под высокую нагрузку.
--
-- Все решения ниже ЗАМЕРЕНЫ на 60 000 документов (EXPLAIN ANALYZE), а не
-- выбраны по наитию. Замеры — в CHANGES_v48.md.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. ДОБАВЛЯЕМ: индексы под сортировку списков.
--
-- Списки всегда отдают 20 последних записей: WHERE <условие> ORDER BY
-- created_at DESC LIMIT 20. Без индекса, содержащего created_at в нужном
-- порядке, PostgreSQL читает все подходящие строки и сортирует их, чтобы
-- отдать двадцать. Замеры:
--
--   «Все документы»: Seq Scan 52 507 строк + сортировка НА ДИСКЕ (6 МБ)
--                    25.8 мс → 0.172 мс
--   «Исходящие»:     17 502 строки + top-N heapsort
--                    487 мс → 0.195 мс
--
-- Индексы частичные: архив в этих списках не участвует, и держать его в
-- индексе незачем — он самая большая часть таблицы и растёт вечно.
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_documents_active_created
    ON documents (created_at DESC)
    WHERE status <> 'archived';

CREATE INDEX IF NOT EXISTS idx_documents_outgoing_created
    ON documents (created_at DESC)
    WHERE outgoing_number IS NOT NULL AND status <> 'archived';

-- Архив с фильтром по году: 7.7 мс → 0.088 мс.
--
-- EXTRACT(YEAR FROM coalesce(...)) = 2026 проиндексировать нельзя, поэтому в
-- коде условие заменено на диапазон по тому же выражению (проверено: набор
-- документов идентичен, 7500 = 7500).
--
-- Индекс — по created_at, а НЕ по выражению периода, хотя фильтр идёт как раз
-- по периоду. Причина замерена: список сортируется по created_at DESC, и
-- индекс в этом порядке позволяет читать ровно 20 строк и остановиться
-- (фильтр по периоду отбрасывает единицы, потому что архив за год и есть
-- почти весь архив). Индекс по выражению периода, наоборот, заставляет
-- прочитать все 7500 строк года и отсортировать их: 4.3 мс. Хуже всего, когда
-- есть ОБА — планировщик выбирает индекс по периоду, то есть более медленный
-- план. Поэтому индекс по периоду не создаётся вовсе.
CREATE INDEX IF NOT EXISTS idx_documents_archived_created
    ON documents (created_at DESC)
    WHERE status = 'archived';

-- ---------------------------------------------------------------------------
-- 2. УДАЛЯЕМ: индексы, которые больше никем не используются.
--
-- Это не уборка ради красоты. Каждый индекс замедляет КАЖДУЮ вставку и
-- обновление строки, а GIN-индексы — особенно сильно. При объёмах, о которых
-- идёт речь, четыре лишних GIN-индекса по documents — это постоянный налог на
-- все записи в системе.
--
-- Проверено поиском по всему коду: ни один запрос к этим индексам не
-- обращается.
-- ---------------------------------------------------------------------------

-- Полнотекстовый индекс по title+body_summary. Поиск по этим полям переведён
-- на fold_ru + триграммы (миграция 0015), потому что to_tsvector в базе с
-- локалью C ломается на заглавных буквах. Этот индекс остался не нужен.
DROP INDEX IF EXISTS idx_documents_search;

-- Триграммные индексы БЕЗ свёртки регистра. Их заменили idx_documents_title_fold,
-- idx_documents_body_fold и idx_documents_outnum_norm — поиск идёт только по
-- свёрнутым выражениям, поэтому эти три не выбираются планировщиком никогда.
DROP INDEX IF EXISTS idx_documents_title_trgm;
DROP INDEX IF EXISTS idx_documents_body_trgm;
DROP INDEX IF EXISTS idx_documents_outnum_trgm;

-- Срочность удалена из системы (#31): фильтра по ней больше нет.
DROP INDEX IF EXISTS idx_documents_urgency;

-- idx_documents_status_only (status) — префикс idx_documents_status_created
-- (status, created_at DESC). Второй обслуживает все запросы первого, поэтому
-- первый — чистая потеря на записи.
--
-- Исключение: count(*) ... WHERE status <> 'archived' делал по нему Index Only
-- Scan. После добавления idx_documents_active_created счётчик обслуживается им
-- (он и уже́, и подходит под то же условие), поэтому удаление безопасно.
DROP INDEX IF EXISTS idx_documents_status_only;

-- ---------------------------------------------------------------------------
-- 2a. Индекс под график «создано документов по дням» (#10).
--
-- Дашборд строит ряд за 30 дней по document_access(access_reason='author') —
-- по documents этот график построить нельзя: он под RLS и показал бы «мои
-- документы». Замерено: без индекса — Seq Scan по 60 003 строкам, 19 мс на
-- каждое открытие дашборда (а он обновляется раз в 30 секунд).
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_document_access_author_granted
    ON document_access (granted_at)
    WHERE access_reason = 'author';

-- ---------------------------------------------------------------------------
-- 3. Метрика «документов по статусам» для Prometheus (#36).
--
-- Простой агрегат SELECT status, count(*) FROM documents GROUP BY status из
-- приложения НЕ РАБОТАЕТ: рабочее подключение идёт обычной ролью (см. #5), и
-- RLS без выставленного app.user_id честно отдаёт 0 строк. Метрика врала бы
-- нулями.
--
-- Поэтому агрегат считается функцией SECURITY DEFINER: она выполняется с
-- правами владельца и потому видит все строки. Это осознанное и узкое
-- исключение из RLS:
--   * возвращает ТОЛЬКО количества по статусам — ни заголовков, ни авторов,
--     ни содержимого; по этим числам нельзя узнать ни об одном документе;
--   * не принимает параметров, поэтому ею нельзя «спросить про чужой
--     документ»;
--   * search_path зафиксирован — иначе вызывающий мог бы подменить таблицу
--     своей и заставить функцию работать с ней от имени владельца.
-- ---------------------------------------------------------------------------
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION documents_count_by_status()
RETURNS TABLE (status TEXT, cnt BIGINT)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT d.status::text, count(*) FROM documents d GROUP BY d.status;
$$;
-- +goose StatementEnd

-- Право вызова НЕ выдаётся отдельно и намеренно: в PostgreSQL EXECUTE на
-- функции по умолчанию принадлежит PUBLIC, поэтому её может вызвать любая
-- роль приложения, как бы она ни называлась (имя задаётся в APP_DB_ROLE).
-- Проверено: функция вызывается обычной ролью и возвращает полные количества,
-- тогда как прямой SELECT из documents без app.user_id отдаёт 0 строк.
--
-- Ограничивать PUBLIC здесь нечего: функция не принимает параметров и
-- возвращает только количества по статусам.

-- +goose Down
DROP FUNCTION IF EXISTS documents_count_by_status();
DROP INDEX IF EXISTS idx_document_access_author_granted;
CREATE INDEX IF NOT EXISTS idx_documents_status_only ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_urgency ON documents(urgency);
CREATE INDEX IF NOT EXISTS idx_documents_outnum_trgm ON documents USING GIN (coalesce(outgoing_number,'') gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_documents_body_trgm ON documents USING GIN (coalesce(body_summary,'') gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_documents_title_trgm ON documents USING GIN (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_documents_search ON documents USING GIN (to_tsvector('russian', title || ' ' || coalesce(body_summary,'')));
DROP INDEX IF EXISTS idx_documents_archived_created;
DROP INDEX IF EXISTS idx_documents_outgoing_created;
DROP INDEX IF EXISTS idx_documents_active_created;
