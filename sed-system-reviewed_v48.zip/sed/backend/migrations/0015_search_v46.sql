-- +goose Up
-- ============================================================================
-- Ревью v46 (группа D — поиск и фильтры).
--   #4  полнотекстовый поиск по СОДЕРЖИМОМУ PDF с фоновой индексацией;
--   #26 справочник «особых отметок» и атрибут документа;
--   #27 поиск по полному номеру Исх/Вх, устойчивый к разделителям и пробелам;
--   #3  хранение настроек пользователя (состояние фильтров) на сервере;
--   #28 фильтр по подписантам/авторам без ограничения иерархией, включая
--       изменённых и удалённых пользователей.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- #4 — Текст содержимого PDF и очередь индексации.
--
-- Почему отдельная таблица, а не столбец в documents:
--   * текст документа в десятки раз больше остальной карточки, и он не нужен
--     ни в одном списке — в documents он утяжелял бы каждое чтение строки;
--   * индексация асинхронная и со своим состоянием (ожидает/готово/ошибка),
--     и это состояние не должно вызывать UPDATE самой карточки документа;
--   * при объёмах, о которых идёт речь (миллионы и выше), эту таблицу можно
--     секционировать или вынести на отдельный tablespace, не трогая documents.
--
-- Очередь — это сама таблица: строка со status='pending' и есть задание.
-- Отдельной таблицы-очереди не нужно, а FOR UPDATE SKIP LOCKED позволяет
-- запускать несколько экземпляров индексатора параллельно (см. internal/indexer).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS document_file_text (
    document_id BIGINT PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
    -- Извлечённый текст. Нужен, чтобы показывать фрагмент с подсветкой; если
    -- хранение текста нежелательно, его можно обнулять после расчёта tsv
    -- (search.store_text=false), поиск продолжит работать.
    content_text TEXT,
    tsv TSVECTOR,
    pages INT,
    chars INT NOT NULL DEFAULT 0,
    -- pending — ждёт индексации; indexed — готово; empty — PDF без текстового
    -- слоя (скан-картинка), переиндексировать бессмысленно; failed — ошибка.
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'indexed', 'empty', 'failed')),
    error TEXT,
    attempts INT NOT NULL DEFAULT 0,
    indexed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Собственно поисковый индекс. GIN по tsvector — то, на чём держится поиск по
-- содержимому; без него запрос деградирует в полный перебор.
CREATE INDEX IF NOT EXISTS idx_dft_tsv ON document_file_text USING GIN (tsv);
-- Выборка очереди индексатором: частичный индекс, поэтому его размер зависит
-- от числа НЕпроиндексированных документов, а не от всех.
CREATE INDEX IF NOT EXISTS idx_dft_queue ON document_file_text (attempts, document_id)
    WHERE status IN ('pending', 'failed');

-- Постановка в очередь при появлении файла документа. Триггером, а не из
-- приложения: файл создаётся в нескольких местах (создание документа, замена
-- файла), и забыть добавить вызов — вопрос времени.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION enqueue_document_text_index() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO document_file_text (document_id, status, attempts, updated_at)
    VALUES (NEW.document_id, 'pending', 0, now())
    ON CONFLICT (document_id) DO UPDATE
        SET status = 'pending', attempts = 0, error = NULL, updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
-- +goose StatementEnd

DROP TRIGGER IF EXISTS trg_document_files_enqueue_text ON document_files;
CREATE TRIGGER trg_document_files_enqueue_text
    AFTER INSERT OR UPDATE OF content ON document_files
    FOR EACH ROW EXECUTE FUNCTION enqueue_document_text_index();

-- Уже загруженные документы тоже должны попасть в очередь.
INSERT INTO document_file_text (document_id, status)
SELECT f.document_id, 'pending' FROM document_files f
ON CONFLICT (document_id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- #26 — Справочник «особых отметок» и атрибут документа.
-- Управляется из админки, участвует во всех фильтрах.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS special_marks (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    code TEXT UNIQUE,
    color TEXT,
    is_active BOOL NOT NULL DEFAULT TRUE,
    sort_order INT NOT NULL DEFAULT 100,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO special_marks (name, code, sort_order) VALUES
    ('Без особой отметки', 'none', 10),
    ('Лично',             'personal', 20),
    ('Срочная доставка',  'express', 30)
ON CONFLICT (name) DO NOTHING;

-- Атрибут НЕобязательный (в отличие от категории): особая отметка есть не у
-- каждого документа, и заставлять выбирать «Без особой отметки» на форме
-- создания незачем.
ALTER TABLE documents ADD COLUMN IF NOT EXISTS special_mark_id BIGINT REFERENCES special_marks(id);
CREATE INDEX IF NOT EXISTS idx_documents_special_mark ON documents(special_mark_id)
    WHERE special_mark_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- #27 — Поиск по номеру, устойчивый к разделителям, регистру и пробелам.
-- И заодно — РЕГИСТРОНЕЗАВИСИМЫЙ поиск по-русски вообще.
--
-- Номер хранится целиком: «ИСХ-1/2-231/2026». Поиск по подстроке ILIKE уже
-- был, но ломался от того, как номер попадает в поле фильтра: при копировании
-- из карточки приходят пробелы по краям и неразрывные дефисы, а вручную номер
-- набирают то через «/», то через «-», то «исх» строчными.
--
-- Главное: ILIKE, lower() и upper() приводят регистр средствами ОС, по
-- ctype базы данных. Если база создана в локали C (а так бывает — зависит от
-- того, как поднимали postgres), для кириллицы они не делают НИЧЕГО:
--
--   upper('исх')                        → 'исх'      (не изменилось)
--   'ИСХ-1/2' ILIKE '%исх%'             → false
--   to_tsvector('russian','Подать…')    → 'Пода'     (заглавная П мешает)
--   … @@ websearch_to_tsquery('СВЕДЕНИЯ') → false
--
-- Проверено на живой БД. То есть в такой установке поиск по-русски заглавными
-- буквами не работал в принципе — и это не только про номера.
--
-- Поэтому вводим СВОЮ функцию свёртки регистра: fold_ru(). Она переводит
-- кириллицу в нижний регистр через translate() — таблицей символов, без
-- участия локали, — и работает одинаково в любой установке. Бэкенд
-- применяет к поисковой строке ту же свёртку (см. internal/search/fold.go),
-- поэтому обе стороны сравнения заведомо согласованы.
--
-- Функции IMMUTABLE, поэтому по ним можно строить индексы. Индексы —
-- триграммные (pg_trgm): обычный btree для LIKE '%…%' бесполезен.
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION fold_ru(s TEXT) RETURNS TEXT AS $$
    SELECT translate(
        lower(coalesce(s, '')),                 -- латиница и цифры: lower() достаточно
        'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ',   -- кириллица: таблицей, без локали
        'абвгдеёжзийклмнопрстуфхцчшщъыьэюя');
$$ LANGUAGE sql IMMUTABLE;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION normalize_doc_number(s TEXT) RETURNS TEXT AS $$
    -- Сначала свёртка регистра, и только потом выбрасывание разделителей.
    -- Если сделать наоборот через upper(), в локали C строчные кириллические
    -- буквы не поднимутся в верхний регистр, а будут УДАЛЕНЫ вместе с
    -- разделителями: «вх-1/2-231/2026» превратится в «122312026» и начнёт
    -- находить исходящий номер. Проверено — ложное совпадение воспроизводится.
    SELECT regexp_replace(fold_ru(s), '[^0-9a-zа-яё]', '', 'g');
$$ LANGUAGE sql IMMUTABLE;
-- +goose StatementEnd

CREATE INDEX IF NOT EXISTS idx_documents_outnum_norm
    ON documents USING GIN (normalize_doc_number(outgoing_number) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_incoming_num_norm
    ON document_incoming_instances USING GIN (normalize_doc_number(incoming_number) gin_trgm_ops);

-- Поиск по названию и краткому содержанию — та же свёртка, те же триграммы.
-- Прежний ILIKE по этим полям имел ровно ту же проблему с регистром.
CREATE INDEX IF NOT EXISTS idx_documents_title_fold
    ON documents USING GIN (fold_ru(title) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_documents_body_fold
    ON documents USING GIN (fold_ru(body_summary) gin_trgm_ops);

-- ---------------------------------------------------------------------------
-- #3 — Настройки пользователя: состояние фильтров и прочие предпочтения.
--
-- Хранение на сервере, а не в localStorage браузера: требование — «для
-- каждого пользователя», то есть настройки должны следовать за человеком,
-- а не за браузером, и не теряться при входе с другого компьютера.
-- Ключ-значение, значение jsonb: набор фильтров со временем меняется, и
-- заводить столбец под каждый фильтр (а потом миграцию на каждое изменение
-- формы) смысла нет.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_preferences (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    pref_key TEXT NOT NULL,
    value JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, pref_key)
);

-- +goose Down
DROP TABLE IF EXISTS user_preferences;
DROP INDEX IF EXISTS idx_documents_body_fold;
DROP INDEX IF EXISTS idx_documents_title_fold;
DROP INDEX IF EXISTS idx_incoming_num_norm;
DROP INDEX IF EXISTS idx_documents_outnum_norm;
DROP FUNCTION IF EXISTS normalize_doc_number(TEXT);
DROP FUNCTION IF EXISTS fold_ru(TEXT);
DROP INDEX IF EXISTS idx_documents_special_mark;
ALTER TABLE documents DROP COLUMN IF EXISTS special_mark_id;
DROP TABLE IF EXISTS special_marks;
DROP TRIGGER IF EXISTS trg_document_files_enqueue_text ON document_files;
DROP FUNCTION IF EXISTS enqueue_document_text_index();
DROP TABLE IF EXISTS document_file_text;
