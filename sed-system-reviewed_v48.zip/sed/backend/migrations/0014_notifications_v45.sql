-- +goose Up
-- ============================================================================
-- Ревью v45 (группа B — уведомления).
--   #7  единый текст уведомления: «<Актор> <действие> «<деталь>» в документе
--       «<Заголовок>»». Для этого нужно знать АКТОРА и ДЕТАЛЬ события.
--   #2  уведомления-«будильники»: блокирующая модалка со звуком и отложить
--       на 5/15/30 минут.
--   #37 индекс под выборку «колокола» (она выполняется у каждого
--       пользователя при каждом открытии страницы и по каждому WS-событию).
-- ============================================================================

-- #7 — Кто совершил действие. NULL у старых строк: для них текст строится
-- безлично («Обновление по документу «…»»), миграция данных не нужна.
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS actor_id BIGINT REFERENCES users(id);

-- #7 — «Деталь» события: текст комментария, причина отклонения, новый статус
-- поручения и т.п. Отдельный столбец, а не выковыривание из payload: выборка
-- колокола идёт по всем строкам пользователя, и разбор jsonb на каждой строке
-- там не нужен. payload остаётся как есть — он машинный.
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS detail TEXT;

-- #2 — Уведомления, требующие подтверждения: показываются блокирующей
-- модалкой со звуком, пока пользователь их не прочитает или не отложит.
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS requires_ack BOOL NOT NULL DEFAULT FALSE;
-- Отложено до указанного момента. Пока snoozed_until > now() — в модалке не
-- показываем (в обычном списке колокола остаётся видимым).
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS snoozed_until TIMESTAMPTZ;

-- #37 — Выборка колокола: WHERE user_id = ? [AND is_read = false]
-- ORDER BY created_at DESC LIMIT ?. Индекс покрывает и список, и счётчик
-- непрочитанных.
-- Список колокола без фильтра: ORDER BY created_at DESC. Индекс из 0001
-- (user_id, is_read, created_at DESC) для такой сортировки не годится — is_read
-- стоит в середине и не зафиксирован условием, поэтому нужен свой.
CREATE INDEX IF NOT EXISTS idx_notifications_user_created
    ON notifications(user_id, created_at DESC);
-- Для варианта only_unread и для счётчика непрочитанных уже есть
-- idx_notifications_user_unread из миграции 0001 — он покрывает
-- WHERE user_id=? AND is_read=false. Своего индекса с таким же именем здесь
-- НЕ создаём: CREATE INDEX IF NOT EXISTS молча оставил бы старое определение,
-- а в Down мы бы удалили чужой индекс.
-- Выборка «будильников» — узкая, частичный индекс по требующим подтверждения.
CREATE INDEX IF NOT EXISTS idx_notifications_alarms
    ON notifications(user_id, snoozed_until) WHERE requires_ack AND NOT is_read;

-- +goose Down
DROP INDEX IF EXISTS idx_notifications_alarms;
DROP INDEX IF EXISTS idx_notifications_user_created;
-- idx_notifications_user_unread принадлежит миграции 0001 — здесь не трогаем.
ALTER TABLE notifications DROP COLUMN IF EXISTS snoozed_until;
ALTER TABLE notifications DROP COLUMN IF EXISTS requires_ack;
ALTER TABLE notifications DROP COLUMN IF EXISTS detail;
ALTER TABLE notifications DROP COLUMN IF EXISTS actor_id;
