-- +goose Up
-- ============================================================================
-- Исправление захвата заданий индексатором (#4).
--
-- НАЙДЕННАЯ ОШИБКА. Индексатор заявлен как масштабируемый: «можно запускать
-- сколько угодно экземпляров, каждый берёт свои строки благодаря
-- FOR UPDATE SKIP LOCKED». В действительности это не работало.
--
-- claim() забирал строки, увеличивал attempts и КОММИТИЛ транзакцию, а сам
-- текст извлекал уже после коммита (это правильно — держать транзакцию
-- открытой минуту нельзя). Но после коммита строки разблокируются, а статус у
-- них остаётся 'pending'. Поэтому второй экземпляр индексатора выбирал РОВНО
-- ТЕ ЖЕ документы, которые первый в этот момент обрабатывал.
--
-- Воспроизведено на живой БД: два последовательных claim без обработки между
-- ними вернули один и тот же набор документов (9301,9302,9303).
--
-- Последствия при нескольких экземплярах:
--   * каждый PDF извлекался бы N раз — а извлечение текста это именно то, что
--     дорого (секунды процессорного времени на файл);
--   * attempts увеличивался бы N раз за один проход, и после max_attempts
--     документ переставал бы выбираться вообще, то есть НЕ индексировался бы
--     никогда.
--
-- ИСПРАВЛЕНИЕ. Вводится статус 'processing' и время захвата claimed_at:
--   * claim помечает строки 'processing' в той же транзакции, что и
--     attempts+1 — после коммита они уже не видны очереди;
--   * зависшие задания возвращаются в очередь по времени: если воркер умер,
--     строка осталась бы в 'processing' навсегда. Поэтому в очередь попадают
--     и строки 'processing' старше порога (его задаёт индексатор).
-- ============================================================================

-- Расширяем допустимые значения статуса.
ALTER TABLE document_file_text DROP CONSTRAINT IF EXISTS document_file_text_status_check;
ALTER TABLE document_file_text ADD CONSTRAINT document_file_text_status_check
    CHECK (status IN ('pending', 'processing', 'indexed', 'empty', 'failed'));

-- Когда задание было захвачено. По нему возвращаются зависшие.
ALTER TABLE document_file_text ADD COLUMN IF NOT EXISTS claimed_at TIMESTAMPTZ;

-- Индекс очереди теперь должен покрывать и 'processing' (для возврата
-- зависших). Прежний частичный индекс пересоздаём.
DROP INDEX IF EXISTS idx_dft_queue;
CREATE INDEX IF NOT EXISTS idx_dft_queue
    ON document_file_text (attempts, document_id)
    WHERE status IN ('pending', 'failed', 'processing');

-- Отдельный индекс под поиск зависших: выборка идёт по claimed_at.
CREATE INDEX IF NOT EXISTS idx_dft_stale
    ON document_file_text (claimed_at)
    WHERE status = 'processing';

-- Если в момент обновления какие-то строки остались захваченными прежней
-- версией кода — они и так 'pending', ничего переносить не нужно.

-- +goose Down
DROP INDEX IF EXISTS idx_dft_stale;
DROP INDEX IF EXISTS idx_dft_queue;
CREATE INDEX IF NOT EXISTS idx_dft_queue ON document_file_text (attempts, document_id)
    WHERE status IN ('pending', 'failed');
ALTER TABLE document_file_text DROP COLUMN IF EXISTS claimed_at;
ALTER TABLE document_file_text DROP CONSTRAINT IF EXISTS document_file_text_status_check;
ALTER TABLE document_file_text ADD CONSTRAINT document_file_text_status_check
    CHECK (status IN ('pending', 'indexed', 'empty', 'failed'));
UPDATE document_file_text SET status = 'pending' WHERE status = 'processing';
