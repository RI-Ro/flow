package main

import (
	"context"
	"flag"
	"log"

	"sed-system/backend/internal/config"
	"sed-system/backend/internal/db"
	apphttp "sed-system/backend/internal/http"
	"sed-system/backend/internal/indexer"
	"sed-system/backend/internal/metrics"
	"sed-system/backend/internal/scheduler"
	"sed-system/backend/internal/service"
)

func main() {
	// --config путь к YAML-конфигу. Приоритет: флаг > env CONFIG_FILE > ./config.yaml.
	configPath := flag.String("config", "", "путь к файлу конфигурации (YAML)")
	flag.Parse()

	cfg, fileCfg := config.LoadWithFilePath(*configPath)

	ctx := context.Background()

	// Миграции применяем сами, из бэкенда, до открытия пула для работы —
	// одна версия goose (из go.mod), понятные ошибки в общем логе.
	//
	// #5 — Миграции, политики RLS и создание прикладной роли идут по
	// ПРИВИЛЕГИРОВАННОМУ подключению (MIGRATE_DATABASE_URL), а рабочий пул —
	// по обычной роли (DATABASE_URL). Иначе приложение ходит в БД
	// суперпользователем, а для него PostgreSQL отключает RLS целиком.
	if err := db.Migrate(cfg.MigrateDatabaseURL, cfg.MigrationsDir); err != nil {
		log.Fatalf("migrate: %v", err)
	}

	adminPool, err := db.New(ctx, cfg.MigrateDatabaseURL)
	if err != nil {
		log.Fatalf("db connect (migrate role): %v", err)
	}
	// Страховка: приводим RLS-политики к каноническому виду на старте (на
	// случай переиспользуемой БД, где goose уже пометил версии применёнными и
	// не накатит исправленную политику). НЕ фатально.
	db.EnsureCanonicalPolicies(ctx, adminPool)
	// Прикладная роль без SUPERUSER/BYPASSRLS. Не фатально: в управляемом
	// PostgreSQL прав на CREATE ROLE может не быть — роль заводится вручную.
	if err := db.EnsureAppRole(ctx, adminPool, cfg.AppDBRole, cfg.AppDBPassword); err != nil {
		log.Printf("db: прикладная роль не настроена: %v", err)
	}
	adminPool.Close()

	pool, err := db.New(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("db connect: %v", err)
	}
	defer pool.Close()

	// #36 — пул как источник метрик соединений. Статистика снимается в момент
	// скрейпа /metrics (pool.Stat() не обращается к БД), поэтому отдельная
	// горутина с тикером не нужна.
	metrics.SetDBPool(pool)

	// Проверка, что RLS действительно действует для рабочего подключения.
	db.WarnIfRLSBypassed(ctx, pool)

	// #2 — какие события показываются блокирующей модалкой и на сколько их
	// можно отложить. Задаётся один раз на старте, дальше читается без блокировок.
	service.ConfigureAlarms(fileCfg.Notifications.AlarmKinds, fileCfg.Notifications.SnoozeMinutes,
		fileCfg.Notifications.RepeatSeconds)

	// Проверка, способна ли БД приводить регистр кириллицы: от этого зависит,
	// будет ли вообще работать поиск по-русски (см. internal/db/locale.go).
	db.WarnIfLocaleCannotFoldCyrillic(ctx, pool)

	// #4 — Фоновая индексация текста PDF для поиска по содержимому.
	// Запускается после открытия пула и не мешает старту: если команда
	// извлечения текста недоступна, индексатор только напишет об этом в лог.
	indexer.New(pool, indexer.FromConfig(indexer.ConfigInput{
		Enabled:               fileCfg.Search.Enabled,
		BatchSize:             fileCfg.Search.BatchSize,
		IntervalSeconds:       fileCfg.Search.IntervalSeconds,
		MaxAttempts:           fileCfg.Search.MaxAttempts,
		ExtractCommand:        fileCfg.Search.ExtractCommand,
		ExtractTimeoutSeconds: fileCfg.Search.ExtractTimeoutSeconds,
		StaleAfterSeconds:     fileCfg.Search.StaleAfterSeconds,
		MaxTextBytes:          fileCfg.Search.MaxTextBytes,
		StoreText:             fileCfg.Search.StoreText,
	})).Start(ctx)

	app := apphttp.NewRouter(cfg, fileCfg, pool)

	// Фоновый авто-архив исполненных документов прошлых лет (если включено).
	if fileCfg.Lifecycle.AutoArchiveExecutedNextYear {
		execSvc := service.NewExecutionService()
		sched := scheduler.New(pool, execSvc)
		sched.StartAutoArchive(ctx)
		log.Printf("auto-archive scheduler started")
	}

	log.Printf("sed-backend listening on %s", cfg.HTTPAddr)
	if err := app.Listen(cfg.HTTPAddr); err != nil {
		log.Fatalf("server error: %v", err)
	}
}
