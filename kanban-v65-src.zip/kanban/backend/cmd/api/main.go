// Модуль предназначен для запуска HTTP-сервера: загрузки конфигурации, подключения к БД, Redis и метрик,
// запуска фоновых задач и корректной остановки по сигналу.

package main

import (
	"context"
	"crypto/tls"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/database"
	"github.com/example/kanban/internal/handlers"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/metrics"
	"github.com/example/kanban/internal/realtime"
	"github.com/example/kanban/internal/storage"
)

// Функция main предназначена для запуска run и завершения процесса с кодом 1 при ошибке.
func main() {
	if err := run(); err != nil {
		slog.Error("запуск не удался", "error", err)
		os.Exit(1)
	}
}

// Функция run предназначена для сборки и запуска всех компонентов приложения и ожидания сигнала завершения.
func run() error {
	// Путь к config.yaml задаётся флагом --config или переменной CONFIG_FILE; флаг приоритетнее.
	configPath := flag.String("config", os.Getenv("CONFIG_FILE"),
		"путь к config.yaml (по умолчанию ищется ./config.yaml)")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		return err
	}

	level := slog.LevelDebug
	if cfg.IsProduction() {
		level = slog.LevelInfo
	}
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: level})))

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	db, err := database.New(ctx, cfg.DatabaseURL, cfg.DBPoolSize, cfg.DBMinIdle, cfg.StatementCache)
	if err != nil {
		return err
	}
	defer db.Close()

	files, err := storage.NewLocal(cfg.UploadDir, cfg.MaxUploadBytes)
	if err != nil {
		return err
	}

	// Вне production подробности ошибок БД возвращаются клиенту.
	httpx.SetProduction(cfg.IsProduction())

	// Число процессов prefork определяется через GOMAXPROCS; 0 означает число ядер.
	if cfg.Prefork && cfg.PreforkWorkers > 0 {
		runtime.GOMAXPROCS(cfg.PreforkWorkers)
	}

	hub := realtime.NewHub()

	// Общая шина событий создаётся только при заданном адресе Redis.
	if cfg.RedisAddr != "" {
		// Идентификатор экземпляра (хост и PID) позволяет отличать собственные сообщения шины от чужих.
		host, _ := os.Hostname()
		instance := fmt.Sprintf("%s-%d", host, os.Getpid())

		bus := realtime.NewBus(cfg.RedisAddr, cfg.RedisPassword, cfg.RedisDB,
			cfg.RedisChannel, instance)
		hub.AttachBus(bus)
		defer bus.Close()
		slog.Info("общая шина событий включена",
			"redis", cfg.RedisAddr, "channel", cfg.RedisChannel, "instance", instance)
	}
	am := auth.NewManager(cfg.JWTSecret, cfg.AccessTTL, cfg.RefreshTTL)
	srv := handlers.New(cfg, db, am, files, hub)

	// Метрики Prometheus; состояние БД опрашивается отдельной горутиной раз в 15 секунд.
	if cfg.Metrics {
		reg := metrics.New()
		pg := metrics.NewPGCollector(db.Pool, reg)
		pg.Start(ctx)
		// Сэмплер истории запускается после регистрации датчиков пула и сокетов.
		sampler := metrics.NewSampler(reg, pg)
		srv = srv.WithMetrics(reg, pg, sampler)
		sampler.Start(ctx)
		slog.Info("метрики включены", "endpoint", "/metrics",
			"история", metrics.SampleStep*metrics.SampleKeep)
	}

	// Фоновый опрос напоминаний выполняется раз в минуту.
	srv.StartReminderPoller(ctx, db.Pool)
	app := srv.App()

	errCh := make(chan error, 1)
	var redirectApp *fiber.App
	switch {
	case cfg.TLSEnabled():
		// Сертификат проверяется заранее: понятная ошибка при запуске вместо сбоя при первом подключении.
		if _, err := tls.LoadX509KeyPair(cfg.TLSCert, cfg.TLSKey); err != nil {
			return fmt.Errorf("не удалось загрузить сертификат HTTPS: %w", err)
		}
		go func() {
			slog.Info("сервер запущен (HTTPS)", "addr", cfg.TLSAddr, "env", cfg.Env, "dbPool", cfg.DBPoolSize)
			if err := app.ListenTLS(cfg.TLSAddr, cfg.TLSCert, cfg.TLSKey); err != nil {
				errCh <- err
			}
		}()
		if cfg.HTTPRedirect {
			// Обычный HTTP-порт только перенаправляет на HTTPS; приложение по нему не отдаётся.
			redirectApp = httpsRedirectApp(cfg.TLSAddr)
			go func() {
				slog.Info("редирект HTTP→HTTPS", "from", cfg.HTTPAddr, "to", cfg.TLSAddr)
				if err := redirectApp.Listen(cfg.HTTPAddr); err != nil {
					errCh <- err
				}
			}()
		} else {
			// Без http_redirect обычный порт работает как раньше (например, за прокси или для проверок состояния).
			go func() {
				slog.Info("сервер запущен (HTTP)", "addr", cfg.Addr)
				if err := httpApp(app, cfg.Addr); err != nil {
					errCh <- err
				}
			}()
		}
	default:
		go func() {
			slog.Info("сервер запущен",
				"addr", cfg.Addr, "env", cfg.Env, "dbPool", cfg.DBPoolSize)
			if err := app.Listen(cfg.Addr); err != nil {
				errCh <- err
			}
		}()
	}

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		slog.Info("получен сигнал завершения, останавливаемся")
	}

	shutdownCtx, stop := context.WithTimeout(context.Background(), 20*time.Second)
	defer stop()
	if redirectApp != nil {
		_ = redirectApp.ShutdownWithContext(shutdownCtx)
	}
	if err := app.ShutdownWithContext(shutdownCtx); err != nil && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	return nil
}

// Функция httpsRedirectApp предназначена для создания минимального приложения, которое отвечает на любой запрос HTTP
// постоянным перенаправлением (308, метод сохраняется) на тот же путь по HTTPS на порту tlsAddr. Порт 443 в адресе опускается.
func httpsRedirectApp(tlsAddr string) *fiber.App {
	port := ""
	if i := strings.LastIndex(tlsAddr, ":"); i >= 0 {
		port = tlsAddr[i+1:]
	}
	r := fiber.New(fiber.Config{DisableStartupMessage: true})
	r.All("/*", func(c *fiber.Ctx) error {
		// Из заголовка Host убирается порт HTTP (адрес IPv6 остаётся в квадратных скобках).
		host := c.Hostname()
		if h, _, err := net.SplitHostPort(host); err == nil {
			host = h
			if strings.Contains(host, ":") {
				host = "[" + host + "]"
			}
		}
		target := "https://" + host
		if port != "" && port != "443" {
			target += ":" + port
		}
		target += c.OriginalURL()
		return c.Redirect(target, fiber.StatusPermanentRedirect)
	})
	return r
}

// Функция httpApp предназначена для запуска того же приложения на обычном HTTP-порту рядом с HTTPS.
// Fiber не позволяет слушать два адреса одним приложением, поэтому используется второй слушатель на том же обработчике.
func httpApp(app *fiber.App, addr string) error {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	return app.Listener(ln)
}
