import React, { useEffect, useMemo, useState } from "react";
import { Search, Trash2, Plus, Copy, FolderKanban, KeyRound, UserCheck, ListChecks } from "lucide-react";
import { api } from "../lib/api.js";
import { ROLE_LABEL, GRANT_LABEL, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Панель «Доступы»: слева люди, справа — к чему у выбранного есть доступ.
//
// Что видно и чем можно управлять, решает сервер (0027_access_panel.sql):
// каждый видит доступ коллег только в своих проектах (где он владелец
// или редактор) и в задачах, которые может редактировать; иначе панель
// раскрывала бы названия чужих проектов. Администратор видит всё и
// дополнительно может выдать новичку доступ «как у коллеги».
//
// Изменения точечные, по одной строке: не «сохранить весь список»,
// как в настройках проекта, — так два человека, правящих доступ
// одновременно, не затирают правки друг друга.

const SECTIONS = [
  ["board", "Проекты", FolderKanban],
  ["task_grant", "Точечный доступ к задачам", KeyRound],
  ["task_assignee", "Исполнитель в задачах", ListChecks],
  ["chart", "Диаграммы", FolderKanban],
  ["whiteboard", "Совместные доски", FolderKanban],
  ["delegation_from", "Замещает", UserCheck],
  ["delegation_to", "Его замещает", UserCheck],
];

const EDITABLE_ROLES = ["editor", "reader"];

export default function Access({ theme, directory, currentUser, onClose, onError, onInfo, onOpenTask }) {
  const isAdmin = currentUser.role === "admin";
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [boards, setBoards] = useState([]);
  const [grant, setGrant] = useState({ boardId: "", role: "reader" });
  const [copyFrom, setCopyFrom] = useState("");
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);

  const people = useMemo(() => {
    const q = query.trim().toLowerCase();
    return directory
      .filter((u) => !u.deleted && u.id !== currentUser.id)
      .filter((u) => !q || `${u.fullName} ${u.position || ""} ${u.email || ""}`.toLowerCase().includes(q))
      .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));
  }, [directory, query, currentUser.id]);

  useEffect(() => {
    api.accessBoards().then(setBoards).catch((e) => onError(e.message));
  }, [onError]);

  const load = async (userId = selected) => {
    if (!userId) return;
    setLoading(true);
    try {
      setRows(await api.accessOverview(userId));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(selected); }, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

  const person = selected ? resolveUser(directory, selected) : null;

  // Любое изменение — запрос и перечитывание списка: строка может
  // измениться не только у нас (сервер сам решает, что осталось видно).
  const run = async (fn, okMessage) => {
    setBusy(true);
    try {
      await fn();
      if (okMessage) onInfo(okMessage);
      await load();
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const setRole = (r, role) => run(() => api.setBoardAccess(r.objectId, selected, role));
  const setLevel = (r, access) => run(() => api.setTaskAccess(r.objectId, selected, access));

  const revoke = (r) => setConfirm({
    title: r.kind === "board" ? "Снять с проекта?" : "Закрыть доступ к задаче?",
    message: r.kind === "board"
      ? `${person.fullName} потеряет доступ к проекту «${r.title}». Задачи, где он исполнитель, останутся ему видны.`
      : `${person.fullName} потеряет доступ к задаче «${r.title}», если не связан с ней иначе.`,
    confirmLabel: "Снять",
    onConfirm: () => {
      setConfirm(null);
      run(() => (r.kind === "board"
        ? api.revokeBoardAccess(r.objectId, selected)
        : api.revokeTaskAccess(r.objectId, selected)), "Доступ снят");
    },
  });

  const addBoard = () => {
    if (!grant.boardId) return onError("Выберите проект");
    run(() => api.setBoardAccess(grant.boardId, selected, grant.role), "Доступ выдан")
      .then(() => setGrant({ boardId: "", role: "reader" }));
  };

  const copy = () => {
    if (!copyFrom) return onError("Выберите сотрудника, чей доступ скопировать");
    const from = resolveUser(directory, copyFrom);
    setConfirm({
      title: "Скопировать доступ?",
      message: `${person.fullName} получит доступ ко всем проектам, диаграммам, доскам и задачам, `
        + `к которым он есть у ${from.fullName}. Владение не копируется — вместо него роль «Редактор». `
        + "Имеющийся доступ не понизится.",
      confirmLabel: "Скопировать",
      danger: false,
      onConfirm: () => {
        setConfirm(null);
        run(async () => {
          const res = await api.adminCopyAccess(selected, copyFrom);
          onInfo(res.boards.length
            ? `Открыт доступ к проектам: ${res.boards.length}`
            : "Новых проектов нет — доступ уже был");
        }).then(() => setCopyFrom(""));
      },
    });
  };

  const memberOf = new Set(rows.filter((r) => r.kind === "board").map((r) => r.objectId));
  const addable = boards.filter((b) => !memberOf.has(b.id));

  const select = (value, options, labels, onChange, disabled) => (
    <select value={value} disabled={disabled || busy} onChange={(e) => onChange(e.target.value)}
      style={inputStyle(theme)} className="px-2 py-1 rounded-lg text-[12px] outline-none">
      {options.map((o) => <option key={o} value={o}>{labels[o]}</option>)}
    </select>
  );

  const renderRow = (r) => {
    const place = r.boardTitle && r.kind !== "board" ? r.boardTitle : null;
    const clickable = (r.kind === "task_grant" || r.kind === "task_assignee") && onOpenTask;
    return (
      <div key={`${r.kind}:${r.objectId}`}
        style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
        className="rounded-xl px-3 py-2 mb-1.5 flex items-center gap-2.5">
        <div className="min-w-0 flex-1">
          <button disabled={!clickable} onClick={() => clickable && onOpenTask(r.objectId, r.boardId)}
            style={{ color: theme.text }} className="text-[13px] font-medium truncate block max-w-full text-left">
            {r.title}
          </button>
          {place && <div style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{place}</div>}
        </div>

        {r.kind === "board" && (r.manageable && r.level !== "owner"
          ? select(r.level, EDITABLE_ROLES, ROLE_LABEL, (v) => setRole(r, v))
          : <span style={{ color: theme.textMuted }} className="text-[12px]">{ROLE_LABEL[r.level] || r.level}</span>)}

        {r.kind === "task_grant" && (r.manageable
          ? select(r.level, ["read", "contribute"], GRANT_LABEL, (v) => setLevel(r, v))
          : <span style={{ color: theme.textMuted }} className="text-[12px]">{GRANT_LABEL[r.level]}</span>)}

        {(r.kind === "chart" || r.kind === "whiteboard") && (
          <span style={{ color: theme.textMuted }} className="text-[12px]">{ROLE_LABEL[r.level] || r.level}</span>)}
        {(r.kind === "delegation_from" || r.kind === "delegation_to") && (
          <span style={{ color: theme.textMuted }} className="text-[12px]">{r.level}</span>)}

        {(r.kind === "board" || r.kind === "task_grant") && r.manageable && r.level !== "owner" && (
          <button disabled={busy} onClick={() => revoke(r)} title="Снять доступ"
            style={{ color: theme.danger }} className="p-1 rounded-md">
            <Trash2 size={14} />
          </button>
        )}
      </div>
    );
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-4xl" padded={false} geometryKey="access">
      <div className="p-5 pb-3">
        <ModalHeader theme={theme} title="Доступы"
          subtitle={isAdmin
            ? "Доступ сотрудников к проектам и задачам — во всей системе"
            : "Доступ сотрудников к вашим проектам и задачам"}
          onClose={onClose} />
      </div>

      <div style={{ borderColor: theme.border }} className="border-t flex min-h-[420px] max-h-[65vh]">
        {/* Люди */}
        <div style={{ borderColor: theme.border }} className="w-64 shrink-0 border-r flex flex-col">
          <div className="p-2.5 relative">
            <Search size={14} style={{ color: theme.textMuted }} className="absolute left-5 top-1/2 -translate-y-1/2" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Найти сотрудника"
              style={inputStyle(theme)} className="w-full pl-8 pr-3 py-1.5 rounded-lg text-[13px] outline-none" />
          </div>
          <div className="overflow-y-auto px-1.5 pb-2">
            {people.map((u) => (
              <button key={u.id} onClick={() => setSelected(u.id)}
                style={{ background: u.id === selected ? theme.surfaceAlt : "transparent",
                         border: `1px solid ${u.id === selected ? theme.accent : "transparent"}` }}
                className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left">
                <Avatar user={u} size={26} theme={theme} />
                <div className="min-w-0">
                  <div style={{ color: theme.text }} className="text-[12.5px] truncate">{u.fullName}</div>
                  {u.position && <div style={{ color: theme.textMuted }} className="text-[11px] truncate">{u.position}</div>}
                </div>
              </button>
            ))}
            {people.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px] text-center py-6">Никого не нашли</p>
            )}
          </div>
        </div>

        {/* Доступы выбранного */}
        <div className="flex-1 min-w-0 overflow-y-auto p-4">
          {!person && (
            <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-16">
              Выберите сотрудника слева
            </p>
          )}

          {person && (
            <>
              <div className="flex items-center gap-2.5 mb-4">
                <Avatar user={person} size={36} theme={theme} />
                <div className="min-w-0">
                  <div style={{ color: theme.text }} className="text-[14px] font-semibold truncate">{person.fullName}</div>
                  <div style={{ color: theme.textMuted }} className="text-[12px] truncate">{person.position || person.email}</div>
                </div>
              </div>

              {/* Выдать доступ к проекту */}
              {addable.length > 0 && (
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <select value={grant.boardId} onChange={(e) => setGrant((g) => ({ ...g, boardId: e.target.value }))}
                    style={inputStyle(theme)} className="flex-1 min-w-[180px] px-2 py-1.5 rounded-lg text-[12.5px] outline-none">
                    <option value="">Выдать доступ к проекту…</option>
                    {addable.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}
                  </select>
                  {select(grant.role, EDITABLE_ROLES, ROLE_LABEL, (v) => setGrant((g) => ({ ...g, role: v })))}
                  <button disabled={busy || !grant.boardId} onClick={addBoard}
                    style={{ background: theme.accent, color: theme.accentText, opacity: grant.boardId ? 1 : 0.5 }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[12.5px] font-semibold">
                    <Plus size={13} /> Выдать
                  </button>
                </div>
              )}

              {/* Онбординг — только администратору */}
              {isAdmin && (
                <div className="flex items-center gap-2 mb-5 flex-wrap">
                  <select value={copyFrom} onChange={(e) => setCopyFrom(e.target.value)}
                    style={inputStyle(theme)} className="flex-1 min-w-[180px] px-2 py-1.5 rounded-lg text-[12.5px] outline-none">
                    <option value="">Доступ как у коллеги…</option>
                    {people.filter((u) => u.id !== selected).map((u) => (
                      <option key={u.id} value={u.id}>{u.fullName}</option>
                    ))}
                  </select>
                  <button disabled={busy || !copyFrom} onClick={copy}
                    style={{ border: `1px solid ${theme.border}`, color: theme.text, opacity: copyFrom ? 1 : 0.5 }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[12.5px] font-medium">
                    <Copy size={13} /> Скопировать
                  </button>
                </div>
              )}

              {loading && <p style={{ color: theme.textMuted }} className="text-[13px] py-4">Загружаем…</p>}

              {!loading && rows.length === 0 && (
                <p style={{ color: theme.textMuted }} className="text-[13px] py-4">
                  {isAdmin
                    ? "Доступа ни к чему нет."
                    : "В ваших проектах и задачах доступа у этого сотрудника нет."}
                </p>
              )}

              {!loading && SECTIONS.map(([kind, label, Icon]) => {
                const list = rows.filter((r) => r.kind === kind);
                if (list.length === 0) return null;
                return (
                  <div key={kind} className="mb-4">
                    <div style={{ color: theme.textMuted }}
                      className="flex items-center gap-1.5 text-[11.5px] font-semibold uppercase tracking-wide mb-1.5">
                      <Icon size={12} /> {label} · {list.length}
                    </div>
                    {list.map(renderRow)}
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>

      {confirm && (
        <ConfirmDialog theme={theme} title={confirm.title} message={confirm.message}
          confirmLabel={confirm.confirmLabel} danger={confirm.danger !== false}
          onConfirm={confirm.onConfirm} onCancel={() => setConfirm(null)} />
      )}
    </Modal>
  );
}
