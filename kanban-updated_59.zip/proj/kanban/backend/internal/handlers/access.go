package handlers

import (
	"errors"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/example/kanban/internal/httpx"
)

// Панель «Доступы»: к чему у человека есть доступ, точечная выдача и
// снятие, онбординг («доступ как у коллеги») и офбординг (удаление с
// передачей дел).
//
// Права проверяют SQL-функции из 0027_access_panel.sql, а не RLS:
// администратор по правилам системы не видит содержимое чужих
// проектов, но управлять доступом в них должен. Обработчики здесь
// разбирают запрос, вызывают функцию и рассылают события.

type accessRow struct {
	Kind       string     `json:"kind"`
	ObjectID   uuid.UUID  `json:"objectId"`
	Title      string     `json:"title"`
	BoardID    *uuid.UUID `json:"boardId,omitempty"`
	BoardTitle *string    `json:"boardTitle,omitempty"`
	Level      *string    `json:"level,omitempty"`
	Manageable bool       `json:"manageable"`
}

// accessFail переводит отказы функций 0027 в понятные ответы. Их тексты
// написаны для людей и ничего о структуре базы не раскрывают, поэтому
// отдаются как есть и в production — в отличие от прочих ошибок СУБД,
// которые httpx.Fail там прячет.
func accessFail(c *fiber.Ctx, err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) {
		switch pgErr.Code {
		case "42501":
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "forbidden", pgErr.Message))
		case "22023":
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "invalid_input", pgErr.Message))
		case "P0002":
			return httpx.Fail(c, httpx.ErrNotFound)
		case "P0001":
			if n, ok := strings.CutPrefix(pgErr.Message, "need_successor:"); ok {
				owned, _ := strconv.Atoi(n)
				return httpx.JSON(c, fiber.StatusConflict, fiber.Map{
					"error": pgErr.Hint, "code": "need_successor", "owned": owned,
				})
			}
		}
	}
	return httpx.Fail(c, err)
}

// actorName — имя действующего для текста уведомления.
func actorName(c *fiber.Ctx, tx pgx.Tx, uid uuid.UUID) (string, error) {
	var name string
	err := tx.QueryRow(c.Context(),
		`SELECT COALESCE((SELECT full_name FROM app.users WHERE id = $1), 'Пользователь')`, uid).Scan(&name)
	return name, err
}

// GET /access/users/:userID — к чему у человека есть доступ (в пределах
// того, чем смотрящий вправе управлять; администратору — всё).
func (s *Server) AccessOverview(c *fiber.Ctx) error {
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	rows := []accessRow{}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `
			SELECT kind, object_id, title, board_id, board_title, level, manageable
			  FROM app.access_overview($1)
			 ORDER BY kind, board_title NULLS FIRST, title`, target)
		if e != nil {
			return e
		}
		rows, e = pgx.CollectRows(r, func(row pgx.CollectableRow) (accessRow, error) {
			var a accessRow
			err := row.Scan(&a.Kind, &a.ObjectID, &a.Title, &a.BoardID, &a.BoardTitle, &a.Level, &a.Manageable)
			return a, err
		})
		return e
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, rows)
}

type idTitle struct {
	ID    uuid.UUID `json:"id"`
	Title string    `json:"title"`
}

// GET /access/boards — проекты, куда смотрящий может выдавать доступ.
func (s *Server) AccessManageableBoards(c *fiber.Ctx) error {
	out := []idTitle{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `SELECT id, title FROM app.manageable_boards()`)
		if e != nil {
			return e
		}
		out, e = pgx.CollectRows(r, pgx.RowToStructByPos[idTitle])
		return e
	})
	if err != nil {
		return accessFail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type boardAccessInput struct {
	Role string `json:"role"`
}

// PUT /access/boards/:boardID/members/:userID — выдать или сменить роль.
func (s *Server) SetBoardAccess(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in boardAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	var added bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var prev *string
		if e := tx.QueryRow(c.Context(), `SELECT app.set_board_access($1, $2, $3)`,
			boardID, target, in.Role).Scan(&prev); e != nil {
			return e
		}
		added = prev == nil
		if !added || target == uid {
			return nil
		}
		// Тот же текст, что у PUT /boards/:id/members: уведомления о
		// доступе выглядят одинаково, откуда бы доступ ни выдали.
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		var title string
		if e := tx.QueryRow(c.Context(), `SELECT app.board_title($1)`, boardID).Scan(&title); e != nil {
			return e
		}
		n, e := notifyInsert(c.Context(), tx, target,
			name+" открыл(а) вам доступ к проекту «"+title+"»", &boardID, nil)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	if added {
		go s.publishBoardMemberAdded(boardID, target)
	}
	s.publishBoardIfVisible(c, boardID)
	return httpx.NoContent(c)
}

// DELETE /access/boards/:boardID/members/:userID — снять с проекта.
func (s *Server) RevokeBoardAccess(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var removed, stillSees bool
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT app.revoke_board_access($1, $2)`,
			boardID, target).Scan(&removed); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.can_see_board($1, $2)`, boardID, target).Scan(&stillSees)
	})
	if err != nil {
		return accessFail(c, err)
	}
	if !removed {
		return httpx.NoContent(c)
	}
	// «Доступ закрыт» шлём, только если проект человеку больше не виден.
	// Исполнитель задачи в проекте видит его и без членства, и событие
	// выбросило бы у него с экрана задачи, к которым доступ остался.
	if !stillSees {
		go s.publishAccessRevoked(boardID, []uuid.UUID{target}, "Доступ к проекту закрыт")
	}
	s.publishBoardIfVisible(c, boardID)
	return httpx.NoContent(c)
}

// publishBoardIfVisible рассылает обновлённый проект наблюдателям,
// чтобы у них обновился состав участников. Модель собирается от имени
// действующего; администратор не из состава проекта её не получит —
// тогда рассылка пропускается: адресные события затронутому человеку
// уже ушли, а у остальных состав обновится при следующей загрузке.
func (s *Server) publishBoardIfVisible(c *fiber.Ctx, boardID uuid.UUID) {
	if board, err := s.fetchBoard(c, boardID); err == nil {
		go s.publishBoard(board, "updated")
	}
}

type taskAccessInput struct {
	Access string `json:"access"`
}

// PUT /access/tasks/:taskID/grants/:userID — выдать или сменить
// точечный доступ к задаче.
func (s *Server) SetTaskAccess(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var prev *string
		if e := tx.QueryRow(c.Context(), `SELECT app.set_task_access($1, $2, $3)`,
			taskID, target, in.Access).Scan(&prev); e != nil {
			return e
		}
		if prev != nil || target == uid {
			return nil
		}
		var boardID uuid.UUID
		var title string
		if e := tx.QueryRow(c.Context(), `SELECT board_id, title FROM app.task_brief($1)`,
			taskID).Scan(&boardID, &title); e != nil {
			return e
		}
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		// Текст и категория — как у PUT /tasks/:id/grants.
		msg := notifyPhrase(name, "открыл(а) вам доступ к задаче «"+title+"»", "", "")
		n, e := notifyInsertCat(c.Context(), tx, target, msg, "granted", &boardID, &taskID)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	s.publishTaskIfVisible(c, taskID)
	return httpx.NoContent(c)
}

// DELETE /access/tasks/:taskID/grants/:userID — снять точечный доступ.
func (s *Server) RevokeTaskAccess(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var removed, stillSees bool
	var boardID uuid.UUID
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT board_id FROM app.task_brief($1)`,
			taskID).Scan(&boardID); e != nil {
			if errors.Is(e, pgx.ErrNoRows) {
				return httpx.ErrNotFound
			}
			return e
		}
		if e := tx.QueryRow(c.Context(), `SELECT app.revoke_task_access($1, $2)`,
			taskID, target).Scan(&removed); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.can_see_task($1, $2)`, taskID, target).Scan(&stillSees)
	})
	if err != nil {
		return accessFail(c, err)
	}
	if !removed {
		return httpx.NoContent(c)
	}
	// Как и с проектом: задача может остаться видна через назначение или
	// роль в проекте — тогда убирать её с экрана нельзя.
	if !stillSees {
		go s.publishTaskAccessRevoked(boardID, taskID, []uuid.UUID{target})
	}
	s.publishTaskIfVisible(c, taskID)
	return httpx.NoContent(c)
}

// publishTaskIfVisible — то же, что publishBoardIfVisible, для задачи:
// новый получатель гранта входит в наблюдатели и получает её сразу.
func (s *Server) publishTaskIfVisible(c *fiber.Ctx, taskID uuid.UUID) {
	if t, err := s.loadTask(c, taskID); err == nil {
		go s.publishTask(t, "updated")
	}
}

type copyAccessInput struct {
	FromUserID uuid.UUID `json:"fromUserId"`
}

// POST /admin/users/:userID/copy-access — онбординг: выдать новичку
// доступ как у коллеги.
func (s *Server) AdminCopyAccess(c *fiber.Ctx) error {
	target, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyAccessInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	boards := []idTitle{}
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		r, e := tx.Query(c.Context(), `SELECT board_id, title FROM app.copy_access($1, $2)`,
			in.FromUserID, target)
		if e != nil {
			return e
		}
		if boards, e = pgx.CollectRows(r, pgx.RowToStructByPos[idTitle]); e != nil {
			return e
		}
		if len(boards) == 0 {
			return nil
		}
		// Одно уведомление на всё, а не по штуке на проект: новичку
		// разом открывают десяток проектов.
		name, e := actorName(c, tx, uid)
		if e != nil {
			return e
		}
		titles := make([]string, len(boards))
		for i, b := range boards {
			titles[i] = "«" + b.Title + "»"
		}
		n, e := notifyInsert(c.Context(), tx, target,
			name+" открыл(а) вам доступ к проектам: "+strings.Join(titles, ", "), nil, nil)
		if e != nil {
			return e
		}
		if n.ID != uuid.Nil {
			pending = append(pending, pendingNotif{UserID: target, Notif: n})
		}
		return nil
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.flushNotifs(pending)
	for _, b := range boards {
		go s.publishBoardMemberAdded(b.ID, target)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"boards": boards})
}

type offboardInput struct {
	SuccessorID *uuid.UUID `json:"successorId"`
}

// offboard — удаление учётной записи с полным снятием доступа и
// передачей владения (app.offboard_user). Вызывается из AdminDeleteUser.
func (s *Server) offboard(c *fiber.Ctx, target uuid.UUID) error {
	var in offboardInput
	if len(c.Body()) > 0 {
		if err := httpx.Decode(c, &in); err != nil {
			return httpx.Fail(c, err)
		}
	}
	actor := s.uid(c)

	var pending []pendingNotif
	err := s.db.AsUser(c.Context(), actor, func(tx pgx.Tx) error {
		// Последнего администратора удалять нельзя: системой стало бы
		// некому управлять.
		var targetIsAdmin bool
		var others int
		if e := tx.QueryRow(c.Context(),
			`SELECT app.is_admin($1), app.other_admins_count($1)`, target).
			Scan(&targetIsAdmin, &others); e != nil {
			return e
		}
		if targetIsAdmin && others == 0 {
			return httpx.Err(fiber.StatusConflict, "last_admin",
				"Это последний администратор — сначала назначьте другого")
		}

		r, e := tx.Query(c.Context(), `
			SELECT notify_user, notification_id, created_at, body, board_id, task_id
			  FROM app.offboard_user($1, $2)`, target, in.SuccessorID)
		if e != nil {
			return e
		}
		defer r.Close()
		for r.Next() {
			var p pendingNotif
			var createdAt time.Time
			if e := r.Scan(&p.UserID, &p.Notif.ID, &createdAt, &p.Notif.Body,
				&p.Notif.BoardID, &p.Notif.TaskID); e != nil {
				return e
			}
			p.Notif.CreatedAt = createdAt
			pending = append(pending, p)
		}
		return r.Err()
	})
	if err != nil {
		return accessFail(c, err)
	}
	s.hub.Disconnect(target)
	s.flushNotifs(pending)
	return httpx.NoContent(c)
}
