package handlers

import (
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

func (s *Server) Me(c *fiber.Ctx) error {
	u, err := s.loadUser(c.Context(), s.uid(c))
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, u)
}

type profilePatch struct {
	FullName    *string `json:"fullName"`
	Position    *string `json:"position"`
	Phone       *string `json:"phone"`
	AvatarColor *string `json:"avatarColor"`
}

func (s *Server) UpdateMe(c *fiber.Ctx) error {
	var in profilePatch
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			UPDATE app.users SET
				full_name    = COALESCE($2, full_name),
				position     = COALESCE($3, position),
				phone        = COALESCE($4, phone),
				avatar_color = COALESCE($5, avatar_color)
			WHERE id = $1`, uid, in.FullName, in.Position, in.Phone, in.AvatarColor)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.Me(c)
}

type passwordChange struct {
	Current string `json:"currentPassword"`
	New     string `json:"newPassword"`
}

// ChangePassword — смена собственного пароля.
//
// Требования к паролю (8 символов, три типа символов из четырёх) живут
// в internal/auth: интерфейс показывает те же условия, что проверяет
// сервер, и разойтись они не могут. Проверка здесь обязательна при
// любой проверке в интерфейсе: форму можно обойти прямым запросом.
func (s *Server) ChangePassword(c *fiber.Ctx) error {
	var in passwordChange
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if e := auth.ValidatePassword(in.New); e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "weak_password", e.Error()))
	}
	if in.New == in.Current {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "same_password",
			"Новый пароль совпадает с текущим"))
	}
	uid := s.uid(c)

	// Текущий пароль подтверждается обязательно: без этого чужая
	// незакрытая вкладка превращается в захват учётной записи — пароль
	// меняют, и владелец больше не входит.
	//
	// Хеш берётся функцией app.my_password_hash(): колонка
	// password_hash закрыта от рабочей роли, а эта функция отдаёт хеш
	// только того, кто выполняет запрос, и чужой вернуть не может.
	var hash string
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// COALESCE: для отключённой учётной записи функция вернёт NULL,
		// и сканирование в строку упало бы ошибкой вместо честного
		// «пароль неверен».
		return tx.QueryRow(c.Context(),
			`SELECT COALESCE(app.my_password_hash(), '')`).Scan(&hash)
	})
	// Сбой запроса и неверный пароль — разные вещи, и валить их в один
	// ответ нельзя: отсутствующая функция или отказ прав превратились
	// бы в вечное «текущий пароль указан неверно», которое уводит
	// разбор в сторону от настоящей причины.
	if err != nil {
		return httpx.Fail(c, err)
	}
	if hash == "" || !auth.CheckPassword(hash, in.Current) {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "bad_password", "Текущий пароль указан неверно"))
	}

	newHash, err := auth.HashPassword(in.New)
	if err != nil {
		return httpx.Fail(c, err)
	}
	var noteIDs []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.users SET password_hash = $2 WHERE id = $1`, uid, newHash); e != nil {
			return e
		}
		// Гасим все сессии, включая текущую: пароль сменился, и старые
		// refresh-токены больше не должны работать нигде.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.refresh_tokens SET revoked_at = now()
			  WHERE user_id = $1 AND revoked_at IS NULL`, uid); e != nil {
			return e
		}
		// Запись в уведомлениях — не вежливость, а след: если пароль
		// сменил не владелец, он увидит это у себя в колокольчике и
		// успеет обратиться к администратору. Актёр и получатель здесь
		// один и тот же, поэтому в общее правило «кто — что — где»
		// фраза не укладывается и строится прямой речью.
		if _, e := tx.Exec(c.Context(),
			`SELECT app.notify($1, $2, NULL, NULL)`, uid,
			"Пароль вашей учётной записи изменён. Остальные устройства "+
				"разлогинены. Если это были не вы — немедленно обратитесь "+
				"к администратору"); e != nil {
			return e
		}
		noteIDs = append(noteIDs, uid)
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.pingNotifications(noteIDs)

	// А текущему устройству сразу выдаём новую пару токенов.
	//
	// Иначе получалось расхождение между обещанием и поведением:
	// сообщение говорило, что выполнен выход из всех сессий, но человек
	// продолжал работать — его access-токен подписан и живёт ещё до
	// 15 минут, отозвать его нельзя. Выход происходил внезапно и позже,
	// при первой попытке обновить токен. Теперь честно: остальные
	// устройства действительно разлогинены, текущее — остаётся в строю.
	//
	// Ответ содержит новую пару токенов, клиент их сохраняет.
	return s.issue(c, uid)
}

// Directory — общий справочник сотрудников с поиском.
func (s *Server) Directory(c *fiber.Ctx) error {
	q := strings.TrimSpace(c.Query("q"))
	limit := httpx.QueryInt(c, "limit", 200, 1, 1000)

	users := []models.User{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		// Условие и порядок записаны ровно теми выражениями, на которых
		// построены индексы users_search_trgm_idx и
		// users_directory_sort_idx (0005_admin.sql). Три отдельных ILIKE
		// по разным колонкам и ORDER BY deleted_at NULLS FIRST выглядели
		// эквивалентно, но не могли задействовать ни один из них — поиск
		// по справочнику выполнялся полным проходом по таблице.
		rows, e := tx.Query(c.Context(), `
			SELECT id, email, full_name, position, phone, avatar_color, is_active, deleted_at
			  FROM app.users
			 WHERE ($1 = ''
			        OR (full_name || ' ' || position || ' ' || phone) ILIKE '%' || $1 || '%')
			 ORDER BY (deleted_at IS NOT NULL), full_name
			 LIMIT $2`, q, limit)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var u models.User
			var deletedAt *time.Time
			if e := rows.Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone,
				&u.AvatarColor, &u.IsActive, &deletedAt); e != nil {
				return e
			}
			u.Deleted = deletedAt != nil
			users = append(users, u)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, users)
}

func (s *Server) GetTeam(c *fiber.Ctx) error {
	ids := []uuid.UUID{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT member_id FROM app.team_members WHERE owner_id = $1`, s.uid(c))
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ids)
}

func (s *Server) SetTeam(c *fiber.Ctx) error {
	var ids []uuid.UUID
	if err := httpx.Decode(c, &ids); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `DELETE FROM app.team_members WHERE owner_id = $1`, uid); e != nil {
			return e
		}
		if len(ids) == 0 {
			return nil
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.team_members (owner_id, member_id)
			SELECT $1, u.id FROM unnest($2::uuid[]) AS u(id)
			ON CONFLICT DO NOTHING`, uid, ids)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ids)
}

func (s *Server) ListNotifications(c *fiber.Ctx) error {
	limit := httpx.QueryInt(c, "limit", 10, 1, 50)
	offset := httpx.QueryInt(c, "offset", 0, 0, 100000)
	includeRead := c.Query("includeRead") == "true"

	items := []models.Notification{}
	var total, unread int

	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `
			SELECT count(*) FILTER (WHERE $1 OR read_at IS NULL), count(*) FILTER (WHERE read_at IS NULL)
			  FROM app.notifications`, includeRead).Scan(&total, &unread); e != nil {
			return e
		}
		rows, e := tx.Query(c.Context(), `
			SELECT id, body, board_id, task_id, chart_id, wb_id, category, read_at, created_at
			  FROM app.notifications
			 WHERE ($1 OR read_at IS NULL)
			 ORDER BY created_at DESC
			 LIMIT $2 OFFSET $3`, includeRead, limit, offset)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var n models.Notification
			var readAt *time.Time
			if e := rows.Scan(&n.ID, &n.Body, &n.BoardID, &n.TaskID, &n.ChartID, &n.WhiteboardID,
				&n.Category, &readAt, &n.CreatedAt); e != nil {
				return e
			}
			n.Read = readAt != nil
			items = append(items, n)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"items": items, "total": total, "unread": unread,
		"limit": limit, "offset": offset,
	})
}

func (s *Server) ReadNotification(c *fiber.Ctx) error {
	id, err := param(c, "id")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.readNotifications(c, []uuid.UUID{id})
}

func (s *Server) ReadAllNotifications(c *fiber.Ctx) error {
	return s.readNotifications(c, nil)
}

// readNotifications отмечает уведомления прочитанными, а их задачи — и,
// где больше нечего смотреть, проекты — просмотренными (0025). ids ==
// nil значит «все». Поставленные отметки уходят и в ответ, и событием
// «seen» во все вкладки человека: выделение гаснет везде сразу.
func (s *Server) readNotifications(c *fiber.Ctx, ids []uuid.UUID) error {
	uid := s.uid(c)
	var ev seenEvent
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var arg any
		if ids != nil {
			arg = ids
		}
		rows, e := tx.Query(c.Context(),
			`SELECT kind, entity_id, viewed_at FROM app.read_notifications($1::uuid[])`, arg)
		if e != nil {
			return e
		}
		ev.Items, e = pgx.CollectRows(rows, func(r pgx.CollectableRow) (viewResult, error) {
			var v viewResult
			err := r.Scan(&v.Kind, &v.ID, &v.ViewedAt)
			return v, err
		})
		if e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.unread_notifications()`).Scan(&ev.Unread)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.publishSeen(uid, ev)
	return httpx.JSON(c, fiber.StatusOK, ev)
}
