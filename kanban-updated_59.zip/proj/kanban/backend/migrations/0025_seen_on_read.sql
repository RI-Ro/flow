-- =====================================================================
-- 0025_seen_on_read.sql — прочтение уведомления снимает отметку
-- «изменено», а открытие задачи — её уведомления.
--
-- Было: отметки о просмотре (view_marks) и уведомления (read_at) жили
-- независимо. «Прочитать» и «Прочитать все» гасили только колокольчик,
-- а карточка оставалась жирной; открытая напрямую задача, наоборот,
-- оставляла свои уведомления непрочитанными.
--
-- Стало: это один факт «человек узнал об изменении», и записывается он
-- в обе стороны сразу:
--
--   • прочтение уведомления о задаче отмечает задачу просмотренной;
--     проект — тоже, если в нём не осталось других непросмотренных
--     задач (иначе погасли бы изменения, которых человек не видел);
--   • отметка задачи просмотренной помечает прочитанными её
--     уведомления.
--
-- Связь сделана в базе, а не в обработчиках: mark_seen вызывается из
-- нескольких мест (POST /views, загрузка карточки после каждой
-- правки), и разнести правило по ним — значит однажды забыть одно.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0025_seen_on_read.sql
--
-- Запускать от app_owner, после 0024_system_counts.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- Под выборку непрочитанных уведомлений задачи у человека. Без него
-- каждое открытие карточки перебирало бы все уведомления пользователя.
CREATE INDEX IF NOT EXISTS notifications_user_task_unread_idx
    ON app.notifications (user_id, task_id) WHERE read_at IS NULL;

-- Есть ли в проекте задачи, которые человек видит, но не открывал после
-- последнего изменения. Правило то же, что у isUnseen на клиенте:
-- ни разу не открытая задача считается непросмотренной.
CREATE OR REPLACE FUNCTION app.board_has_unseen(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.board_id = p_board
           AND NOT t.archived
           AND app.can_see_task(t.id, p_user)
           AND COALESCE(app.seen_at('task', t.id, p_user), '-infinity')
               < app.task_activity_at(t.id, p_user))
$$;

-- mark_seen — та же функция, что в 0006, плюс одна ветка: отметка
-- задачи гасит её непрочитанные уведомления.
CREATE OR REPLACE FUNCTION app.mark_seen(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_at timestamptz;
BEGIN
    IF p_user IS NULL OR p_entity IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_kind NOT IN ('task', 'board') THEN
        RAISE EXCEPTION 'unknown_view_kind';
    END IF;

    IF p_kind = 'task' AND NOT app.can_see_task(p_entity, p_user) THEN
        RETURN NULL;
    END IF;
    IF p_kind = 'board' AND NOT app.can_see_board(p_entity, p_user) THEN
        RETURN NULL;
    END IF;

    INSERT INTO app.view_marks (user_id, kind, entity_id, viewed_at)
    VALUES (p_user, p_kind, p_entity, now())
    ON CONFLICT (user_id, kind, entity_id)
    DO UPDATE SET viewed_at = now()
    RETURNING viewed_at INTO v_at;

    IF p_kind = 'task' THEN
        UPDATE app.notifications SET read_at = now()
         WHERE user_id = p_user AND task_id = p_entity AND read_at IS NULL;
    END IF;

    RETURN v_at;
END $$;

-- Прочитать уведомления текущего пользователя: перечисленные или,
-- при p_ids = NULL, все. Возвращает отметки о просмотре, которые это
-- поставило, — клиент гасит по ним выделение без перезагрузки списков.
--
-- Пользователь берётся из app.user_id, а не параметром: функция
-- SECURITY DEFINER, и параметр позволил бы читать чужие уведомления.
CREATE OR REPLACE FUNCTION app.read_notifications(p_ids uuid[])
RETURNS TABLE (kind text, entity_id uuid, viewed_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_user   uuid := app.current_user_id();
    v_tasks  uuid[];
    v_boards uuid[];
    v_task   uuid;
    v_board  uuid;
    v_at     timestamptz;
BEGIN
    IF v_user IS NULL THEN
        RETURN;
    END IF;

    -- Проект — из самого уведомления или из его задачи: у уведомлений
    -- о задачах board_id заполнен не всегда.
    WITH upd AS (
        UPDATE app.notifications n SET read_at = now()
         WHERE n.user_id = v_user AND n.read_at IS NULL
           AND (p_ids IS NULL OR n.id = ANY (p_ids))
        RETURNING n.task_id, n.board_id
    )
    SELECT array_agg(DISTINCT u.task_id) FILTER (WHERE u.task_id IS NOT NULL),
           array_agg(DISTINCT COALESCE(u.board_id, t.board_id))
               FILTER (WHERE COALESCE(u.board_id, t.board_id) IS NOT NULL)
      INTO v_tasks, v_boards
      FROM upd u LEFT JOIN app.tasks t ON t.id = u.task_id;

    FOREACH v_task IN ARRAY COALESCE(v_tasks, '{}') LOOP
        v_at := app.mark_seen('task', v_task, v_user);
        IF v_at IS NOT NULL THEN
            kind := 'task'; entity_id := v_task; viewed_at := v_at;
            RETURN NEXT;
        END IF;
    END LOOP;

    FOREACH v_board IN ARRAY COALESCE(v_boards, '{}') LOOP
        IF NOT app.board_has_unseen(v_board, v_user) THEN
            v_at := app.mark_seen('board', v_board, v_user);
            IF v_at IS NOT NULL THEN
                kind := 'board'; entity_id := v_board; viewed_at := v_at;
                RETURN NEXT;
            END IF;
        END IF;
    END LOOP;
END $$;

-- Непрочитанные уведомления текущего пользователя — для счётчика на
-- колокольчике в событии «seen».
CREATE OR REPLACE FUNCTION app.unread_notifications()
RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)::int FROM app.notifications
     WHERE user_id = app.current_user_id() AND read_at IS NULL
$$;

GRANT EXECUTE ON FUNCTION app.board_has_unseen(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.read_notifications(uuid[])    TO app_user;
GRANT EXECUTE ON FUNCTION app.unread_notifications()        TO app_user;
