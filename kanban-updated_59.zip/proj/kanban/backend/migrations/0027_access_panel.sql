-- =====================================================================
-- 0027_access_panel.sql — панель «Доступы», офбординг и онбординг.
--
-- Задача: пришёл сотрудник — выдать ему доступ к проектам и задачам;
-- ушёл — снять всё и передать дела. Раньше для этого не было ни одного
-- места, где видно, к чему у человека есть доступ, а удаление учётной
-- записи администратором фактически ничего не снимало: чистка шла от
-- имени администратора под RLS, и политики молча пропускали чужие
-- строки (членство в проектах оставалось, «Восстановить» возвращало
-- доступ целиком).
--
-- Всё, что меняет доступ, сделано здесь функциями SECURITY DEFINER с
-- явной проверкой прав вызывающего. Причина — администратор: по
-- правилам системы он не получает доступа к содержимому проектов через
-- RLS, а панель должна давать ему управлять доступом везде. Проверки
-- повторяют политики 0007 (владелец — всё, редактор — всё, кроме
-- строки владельца) и task_grants (редактор задачи), плюс ветка
-- «администратор».
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0027_access_panel.sql
--
-- Запускать от app_owner, после 0026_board_watchers.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ЗАМЕЩЕНИЕ НЕ ПЕРЕЖИВАЕТ УДАЛЕНИЯ ЗАМЕЩАЕМОГО.
--
-- effective_users не смотрел на deleted_at: заместитель удалённого
-- сотрудника продолжал пользоваться всеми его правами, включая
-- владение проектами. Офбординг ниже удаляет замещения, но учётные
-- записи, удалённые до этой миграции, их сохранили — поэтому фильтр
-- здесь, а не только в офбординге. Заблокированных (is_active = false)
-- не отсекаем: блокировка бывает временной, и замещение на время
-- отпуска — ровно тот случай, ради которого оно существует.
-- ─────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.effective_users(p_user uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT p_user
    UNION
    SELECT d.grantor_id FROM app.delegations d
      JOIN app.users g ON g.id = d.grantor_id
     WHERE d.deputy_id = p_user
       AND g.deleted_at IS NULL
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 2. КТО ЧЕМ УПРАВЛЯЕТ.
-- ─────────────────────────────────────────────────────────────────────

-- ВНИМАНИЕ: can_edit_board / can_edit_task для постороннего возвращают
-- не false, а NULL (роль не найдена). В политиках RLS это отказ, но в
-- PL/pgSQL «IF NOT NULL» не срабатывает — проверка молча пропускалась
-- бы, и любой мог бы выдавать доступ к любому проекту. Поэтому здесь
-- COALESCE, а все проверки ниже записаны как «IS NOT TRUE».
--
-- Может ли p_actor выдавать и снимать доступ к проекту.
CREATE OR REPLACE FUNCTION app.can_manage_board_access(p_board uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_board(p_board, p_actor), false)
$$;

-- Может ли p_actor выдавать и снимать точечный доступ к задаче.
CREATE OR REPLACE FUNCTION app.can_manage_task_access(p_task uuid, p_actor uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(app.is_admin(p_actor), false)
        OR COALESCE(app.can_edit_task(p_task, p_actor), false)
$$;

-- Действующая ли учётная запись: доступ выдаётся только таким.
CREATE OR REPLACE FUNCTION app.is_live_user(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.users u
                    WHERE u.id = p_user AND u.deleted_at IS NULL AND u.is_active)
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 3. ОБЗОР: К ЧЕМУ У ЧЕЛОВЕКА ЕСТЬ ДОСТУП.
--
-- Обычный пользователь видит доступ другого только там, где сам вправе
-- им управлять: в проектах, где он владелец или редактор, и в задачах,
-- которые может редактировать. Иначе панель раскрыла бы названия чужих
-- проектов и задач. Администратор видит всё, включая диаграммы,
-- совместные доски и замещения — это нужно для офбординга.
--
-- kind:  board | task_grant | task_assignee | chart | whiteboard
--        | delegation_to | delegation_from
-- level: роль в проекте (owner/editor/reader), уровень гранта
--        (read/contribute), для остального — пусто или период.
-- ─────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.access_overview(p_target uuid)
RETURNS TABLE (kind text, object_id uuid, title text, board_id uuid,
               board_title text, level text, manageable boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me    uuid := app.current_user_id();
    v_admin boolean;
BEGIN
    IF v_me IS NULL THEN
        RETURN;
    END IF;
    v_admin := app.is_admin(v_me);

    RETURN QUERY
    SELECT 'board'::text, b.id, b.title, b.id, b.title, m.role::text,
           app.can_manage_board_access(b.id, v_me)
             AND (m.role <> 'owner' OR v_admin)
      FROM app.board_members m JOIN app.boards b ON b.id = m.board_id
     WHERE m.user_id = p_target
       AND (v_admin OR app.can_edit_board(b.id, v_me));

    RETURN QUERY
    SELECT 'task_grant'::text, t.id, t.title, b.id, b.title, g.access::text,
           app.can_manage_task_access(t.id, v_me)
      FROM app.task_grants g
      JOIN app.tasks t  ON t.id = g.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE g.user_id = p_target
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    -- Назначения меняются в карточке задачи, здесь они для полноты
    -- картины: с какими задачами человек связан.
    RETURN QUERY
    SELECT 'task_assignee'::text, t.id, t.title, b.id, b.title, NULL::text, false
      FROM app.task_assignees a
      JOIN app.tasks t  ON t.id = a.task_id
      JOIN app.boards b ON b.id = t.board_id
     WHERE a.user_id = p_target AND NOT t.archived AND t.completed_at IS NULL
       AND (v_admin OR app.can_edit_task(t.id, v_me));

    IF NOT v_admin THEN
        RETURN;
    END IF;

    RETURN QUERY
    SELECT 'chart'::text, c.id, c.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.chart_members m JOIN app.charts c ON c.id = m.chart_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'whiteboard'::text, w.id, w.title, NULL::uuid, NULL::text, m.role::text, false
      FROM app.whiteboard_members m JOIN app.whiteboards w ON w.id = m.board_id
     WHERE m.user_id = p_target;

    RETURN QUERY
    SELECT 'delegation_to'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.deputy_id
     WHERE d.grantor_id = p_target AND d.ends_at >= current_date;

    RETURN QUERY
    SELECT 'delegation_from'::text, d.id, u.full_name, NULL::uuid, NULL::text,
           to_char(d.starts_at, 'YYYY-MM-DD') || '…' || to_char(d.ends_at, 'YYYY-MM-DD'), false
      FROM app.delegations d JOIN app.users u ON u.id = d.grantor_id
     WHERE d.deputy_id = p_target AND d.ends_at >= current_date;
END $$;

-- Проекты, в которые вызывающий может добавлять людей, — список для
-- кнопки «Выдать доступ к проекту».
CREATE OR REPLACE FUNCTION app.manageable_boards()
RETURNS TABLE (id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT b.id, b.title FROM app.boards b
     WHERE NOT b.archived
       AND app.can_manage_board_access(b.id, app.current_user_id())
     ORDER BY b.title
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 4. ТОЧЕЧНЫЕ ИЗМЕНЕНИЯ.
--
-- По одной строке, а не заменой всего списка, как PUT /members: при
-- замене два одновременных редактора затирали правки друг друга, а
-- чтобы снять одного человека, нужно было знать весь состав.
-- ─────────────────────────────────────────────────────────────────────

-- Выдать или сменить роль в проекте. Возвращает прежнюю роль (NULL —
-- человек добавлен впервые), чтобы уведомлять только новых.
CREATE OR REPLACE FUNCTION app.set_board_access(p_board uuid, p_user uuid, p_role text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_role NOT IN ('editor', 'reader') THEN
        RAISE EXCEPTION 'Роль может быть только «редактор» или «исполнитель»'
            USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT role::text INTO v_prev FROM app.board_members
     WHERE board_id = p_board AND user_id = p_user;
    IF v_prev = 'owner' THEN
        RAISE EXCEPTION 'Роль владельца меняется передачей владения' USING ERRCODE = '42501';
    END IF;

    INSERT INTO app.board_members (board_id, user_id, role)
    VALUES (p_board, p_user, p_role::app.board_role)
    ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role;
    RETURN v_prev;
END $$;

-- Снять с проекта. Строку владельца не трогаем (как и политика 0007).
CREATE OR REPLACE FUNCTION app.revoke_board_access(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.can_manage_board_access(p_board, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этому проекту' USING ERRCODE = '42501';
    END IF;
    IF EXISTS (SELECT 1 FROM app.board_members
                WHERE board_id = p_board AND user_id = p_user AND role = 'owner') THEN
        RAISE EXCEPTION 'Владельца нельзя снять с проекта — сначала передайте владение'
            USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.board_members WHERE board_id = p_board AND user_id = p_user;
    RETURN FOUND;
END $$;

-- Выдать или сменить точечный доступ к задаче. Возвращает прежний
-- уровень (NULL — выдан впервые).
CREATE OR REPLACE FUNCTION app.set_task_access(p_task uuid, p_user uuid, p_access text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_me   uuid := app.current_user_id();
    v_prev text;
BEGIN
    IF p_access NOT IN ('read', 'contribute') THEN
        RAISE EXCEPTION 'Уровень может быть только «просмотр» или «участие»' USING ERRCODE = '22023';
    END IF;
    IF app.can_manage_task_access(p_task, v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    IF app.is_live_user(p_user) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    SELECT access::text INTO v_prev FROM app.task_grants
     WHERE task_id = p_task AND user_id = p_user;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    VALUES (p_task, p_user, p_access::app.grant_access, v_me)
    ON CONFLICT (task_id, user_id) DO UPDATE SET access = EXCLUDED.access;
    -- История — здесь, а не в обработчике: администратор не из состава
    -- проекта писать в неё под RLS не может.
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, v_me, 'Изменён доступ к задаче');
    RETURN v_prev;
END $$;

CREATE OR REPLACE FUNCTION app.revoke_task_access(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF app.can_manage_task_access(p_task, app.current_user_id()) IS NOT TRUE THEN
        RAISE EXCEPTION 'Нет права управлять доступом к этой задаче' USING ERRCODE = '42501';
    END IF;
    DELETE FROM app.task_grants WHERE task_id = p_task AND user_id = p_user;
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (p_task, app.current_user_id(), 'Изменён доступ к задаче');
    RETURN true;
END $$;

-- Проект и название задачи — для уведомления и событий. Только тому,
-- кто управляет доступом к задаче: иначе это был бы способ узнать
-- название чужой задачи по идентификатору.
CREATE OR REPLACE FUNCTION app.task_brief(p_task uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.board_id, t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_manage_task_access(p_task, app.current_user_id())
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 5. ОНБОРДИНГ: ДОСТУП КАК У КОЛЛЕГИ.
--
-- Только администратор. Копируются членства в проектах, диаграммах и
-- совместных досках и точечные гранты. Владение не копируется —
-- владелец у проекта один; на его месте новичок получает «редактора».
-- Уже имеющийся доступ не понижается (ON CONFLICT DO NOTHING).
-- Назначения исполнителем не копируются: это работа, а не доступ.
-- ─────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.copy_access(p_from uuid, p_to uuid)
RETURNS TABLE (board_id uuid, title text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me uuid := app.current_user_id();
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Копировать доступ может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_from = p_to THEN
        RAISE EXCEPTION 'Нужны два разных сотрудника' USING ERRCODE = '22023';
    END IF;
    IF app.is_live_user(p_to) IS NOT TRUE THEN
        RAISE EXCEPTION 'Учётная запись удалена или заблокирована' USING ERRCODE = '22023';
    END IF;

    INSERT INTO app.chart_members (chart_id, user_id, role)
    SELECT m.chart_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.chart_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    SELECT m.board_id, p_to, CASE WHEN m.role = 'owner' THEN 'editor' ELSE m.role END
      FROM app.whiteboard_members m WHERE m.user_id = p_from
    ON CONFLICT DO NOTHING;

    INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
    SELECT g.task_id, p_to, g.access, v_me
      FROM app.task_grants g WHERE g.user_id = p_from
    ON CONFLICT DO NOTHING;

    -- Проекты — последними и с возвратом: по ним уходят уведомления и
    -- события «вас добавили в проект».
    RETURN QUERY
    WITH ins AS (
        INSERT INTO app.board_members (board_id, user_id, role)
        SELECT m.board_id, p_to,
               CASE WHEN m.role = 'owner' THEN 'editor'::app.board_role ELSE m.role END
          FROM app.board_members m WHERE m.user_id = p_from
        ON CONFLICT DO NOTHING
        RETURNING board_members.board_id
    )
    SELECT b.id, b.title FROM ins JOIN app.boards b ON b.id = ins.board_id;
END $$;

-- ─────────────────────────────────────────────────────────────────────
-- 6. ОФБОРДИНГ.
--
-- Удаление учётной записи с полным снятием доступа, одной транзакцией.
--
--   • Владение проектами, диаграммами, совместными досками и групповыми
--     чатами переходит преемнику. Если владеть нечем, преемник не
--     нужен; если есть чем, а преемник не указан — отказ: проект без
--     живого владельца нельзя ни удалить, ни передать.
--   • Снимается всё остальное: членства, гранты, назначения
--     исполнителем, исполнитель пунктов чек-листа, замещения, команды.
--   • Задачи, оставшиеся без исполнителя, никому автоматически не
--     переназначаются — это решает редактор проекта. Владелец и
--     редакторы получают уведомление по каждой такой задаче.
--   • Авторство (created_by) не трогается: это история, а не доступ;
--     войти удалённый не может, а через замещение (effective_users
--     выше) его права больше никому не достаются.
--
-- Возвращает уведомления, которые нужно разослать по WebSocket, и
-- проекты, где сменился состав (для события board/updated).
-- ─────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION app.offboard_user(p_target uuid, p_successor uuid)
RETURNS TABLE (notify_user uuid, notification_id uuid, created_at timestamptz,
               body text, board_id uuid, task_id uuid)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
#variable_conflict use_column
DECLARE
    v_me      uuid := app.current_user_id();
    v_name    text;
    v_owned   int;
    v_tasks   uuid[];
    r         record;
BEGIN
    IF app.is_admin(v_me) IS NOT TRUE THEN
        RAISE EXCEPTION 'Удалять сотрудников может только администратор' USING ERRCODE = '42501';
    END IF;
    IF p_target = v_me THEN
        RAISE EXCEPTION 'Нельзя удалить собственную учётную запись' USING ERRCODE = '42501';
    END IF;

    SELECT u.full_name INTO v_name FROM app.users u
     WHERE u.id = p_target AND u.deleted_at IS NULL
       FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Учётная запись не найдена или уже удалена' USING ERRCODE = 'P0002';
    END IF;

    SELECT (SELECT count(*) FROM app.board_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chart_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.whiteboard_members m WHERE m.user_id = p_target AND m.role = 'owner')
         + (SELECT count(*) FROM app.chats c WHERE c.owner_id = p_target AND c.kind = 'group')
      INTO v_owned;

    IF v_owned > 0 THEN
        IF p_successor IS NULL THEN
            RAISE EXCEPTION 'need_successor:%', v_owned USING ERRCODE = 'P0001',
                HINT = 'Сотрудник владеет проектами — выберите, кому их передать';
        END IF;
        IF p_successor = p_target OR app.is_live_user(p_successor) IS NOT TRUE THEN
            RAISE EXCEPTION 'Преемником может быть только действующий сотрудник'
                USING ERRCODE = '22023';
        END IF;

        -- Передача владения: сначала уходит строка прежнего владельца,
        -- потом преемник становится владельцем — уникальный индекс
        -- «один владелец на проект» не даёт сделать это в другом
        -- порядке.
        FOR r IN DELETE FROM app.board_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.board_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT board_members_pkey DO UPDATE SET role = 'owner';
            body := 'Вам передан проект сотрудника ' || v_name || ': «'
                 || (SELECT b.title FROM app.boards b WHERE b.id = r.board_id) || '»';
            notification_id := NULL;
            SELECT n.id, n.created_at INTO notification_id, created_at
              FROM app.notify_cat(p_successor, body, 'other', r.board_id, NULL) n;
            IF notification_id IS NOT NULL THEN
                notify_user := p_successor; board_id := r.board_id; task_id := NULL;
                RETURN NEXT;
            END IF;
        END LOOP;

        FOR r IN DELETE FROM app.chart_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.chart_id LOOP
            INSERT INTO app.chart_members (chart_id, user_id, role)
            VALUES (r.chart_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT chart_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN DELETE FROM app.whiteboard_members m
                  WHERE m.user_id = p_target AND m.role = 'owner'
              RETURNING m.board_id LOOP
            INSERT INTO app.whiteboard_members (board_id, user_id, role)
            VALUES (r.board_id, p_successor, 'owner')
            ON CONFLICT ON CONSTRAINT whiteboard_members_pkey DO UPDATE SET role = 'owner';
        END LOOP;

        FOR r IN UPDATE app.chats c SET owner_id = p_successor
                  WHERE c.owner_id = p_target AND c.kind = 'group'
              RETURNING c.id LOOP
            INSERT INTO app.chat_members (chat_id, user_id)
            VALUES (r.id, p_successor) ON CONFLICT DO NOTHING;
        END LOOP;
    END IF;

    -- Назначения: запоминаем задачи, чтобы найти оставшиеся без
    -- исполнителя.
    WITH del AS (
        DELETE FROM app.task_assignees a WHERE a.user_id = p_target RETURNING a.task_id
    )
    SELECT array_agg(DISTINCT del.task_id) INTO v_tasks FROM del;

    UPDATE app.task_steps s SET assignee_id = NULL WHERE s.assignee_id = p_target;
    DELETE FROM app.task_grants        g WHERE g.user_id = p_target;
    DELETE FROM app.board_members      m WHERE m.user_id = p_target;
    DELETE FROM app.chart_members      m WHERE m.user_id = p_target;
    DELETE FROM app.whiteboard_members m WHERE m.user_id = p_target;
    -- Из групповых чатов выводим; личная переписка остаётся у
    -- собеседника как история.
    DELETE FROM app.chat_members cm
     USING app.chats c
     WHERE c.id = cm.chat_id AND c.kind = 'group' AND cm.user_id = p_target;
    DELETE FROM app.delegations d WHERE d.grantor_id = p_target OR d.deputy_id = p_target;
    DELETE FROM app.team_groups tg WHERE tg.owner_id = p_target;
    DELETE FROM app.team_members tm WHERE tm.member_id = p_target OR tm.owner_id = p_target;

    UPDATE app.users u SET deleted_at = now(), is_active = false, role = 'member'
     WHERE u.id = p_target;
    PERFORM app.revoke_user_sessions(p_target);

    -- Задачи без исполнителя — владельцу и редакторам их проекта.
    FOR r IN
        SELECT t.id AS tid, t.title, t.board_id AS bid, m.user_id AS uid
          FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id AND m.role IN ('owner', 'editor')
         WHERE t.id = ANY (COALESCE(v_tasks, '{}'))
           AND NOT t.archived AND t.completed_at IS NULL
           AND NOT EXISTS (SELECT 1 FROM app.task_assignees a WHERE a.task_id = t.id)
    LOOP
        body := 'После ухода сотрудника ' || v_name || ' задача «' || r.title
             || '» осталась без исполнителя';
        notification_id := NULL;
        SELECT n.id, n.created_at INTO notification_id, created_at
          FROM app.notify_cat(r.uid, body, 'task', r.bid, r.tid) n;
        IF notification_id IS NOT NULL THEN
            notify_user := r.uid; board_id := r.bid; task_id := r.tid;
            RETURN NEXT;
        END IF;
    END LOOP;
END $$;

GRANT EXECUTE ON FUNCTION app.can_manage_board_access(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.can_manage_task_access(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.is_live_user(uuid)                  TO app_user;
GRANT EXECUTE ON FUNCTION app.access_overview(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.manageable_boards()                 TO app_user;
GRANT EXECUTE ON FUNCTION app.set_board_access(uuid, uuid, text)  TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_board_access(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.set_task_access(uuid, uuid, text)   TO app_user;
GRANT EXECUTE ON FUNCTION app.revoke_task_access(uuid, uuid)      TO app_user;
GRANT EXECUTE ON FUNCTION app.task_brief(uuid)                    TO app_user;
GRANT EXECUTE ON FUNCTION app.copy_access(uuid, uuid)             TO app_user;
GRANT EXECUTE ON FUNCTION app.offboard_user(uuid, uuid)           TO app_user;
