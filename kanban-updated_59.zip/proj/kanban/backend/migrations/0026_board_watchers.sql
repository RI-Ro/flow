-- =====================================================================
-- 0026_board_watchers.sql — события проекта доходят до всех, кому он
-- виден.
--
-- С 0005 проект виден не только участникам, но и тем, у кого в нём
-- есть видимая задача: автору, исполнителю, исполнителю пункта
-- чек-листа, получателю точечного доступа (app.can_see_board). Список
-- получателей событий проекта (board_watchers) остался прежним —
-- участники и их заместители. Исполнитель задачи, не состоящий в
-- проекте, видел колонки, но не получал событий об их изменении и
-- смотрел на устаревшую доску до перезагрузки страницы.
--
-- Здесь board_watchers повторяет условия can_see_board по тем же
-- связям, включая замещение в обе стороны (effective_users). Сверка
-- двух функций — раздел 9 в scripts/rls_test.sql.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0026_board_watchers.sql
--
-- Запускать от app_owner, после 0025_seen_on_read.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE OR REPLACE FUNCTION app.board_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH direct AS (
        SELECT m.user_id FROM app.board_members m WHERE m.board_id = p_board
        UNION
        SELECT t.created_by FROM app.tasks t WHERE t.board_id = p_board
        UNION
        SELECT a.user_id FROM app.task_assignees a
          JOIN app.tasks t ON t.id = a.task_id WHERE t.board_id = p_board
        UNION
        SELECT g.user_id FROM app.task_grants g
          JOIN app.tasks t ON t.id = g.task_id WHERE t.board_id = p_board
        UNION
        SELECT s.assignee_id FROM app.task_steps s
          JOIN app.tasks t ON t.id = s.task_id
         WHERE t.board_id = p_board AND s.assignee_id IS NOT NULL
    )
    SELECT d.user_id FROM direct d
    UNION
    -- Заместитель видит всё, что видит замещаемый (effective_users).
    SELECT dl.deputy_id FROM app.delegations dl
      JOIN direct d ON d.user_id = dl.grantor_id
     WHERE current_date BETWEEN dl.starts_at AND dl.ends_at
$$;
