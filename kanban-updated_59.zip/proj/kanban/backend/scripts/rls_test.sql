-- =====================================================================
-- rls_test.sql — проверка политик доступа и наблюдателей WebSocket.
--
-- Запускать РОЛЬЮ app_user (не владельцем и не суперпользователем):
--   psql "postgres://app_user:...@localhost/kanban" -f scripts/rls_test.sql
--
-- Всё в транзакции, которая откатывается — данные не меняются.
-- =====================================================================

\set ON_ERROR_STOP on
BEGIN;
SET search_path = app, public;

DO $$
BEGIN
    IF current_setting('is_superuser') = 'on' THEN
        RAISE EXCEPTION 'Тест запущен суперпользователем — RLS не применяется';
    END IF;
    IF (SELECT rolbypassrls FROM pg_roles WHERE rolname = current_user) THEN
        RAISE EXCEPTION 'У роли % есть BYPASSRLS — политики не проверяются', current_user;
    END IF;
END $$;

\echo '--- 1. Без app.user_id не видно ничего ---'
SELECT set_config('app.user_id', '', true);
DO $$
DECLARE n int;
BEGIN
    SELECT count(*) INTO n FROM app.boards;
    IF n <> 0 THEN RAISE EXCEPTION 'Анонимный запрос увидел % досок', n; END IF;
    SELECT count(*) INTO n FROM app.tasks;
    IF n <> 0 THEN RAISE EXCEPTION 'Анонимный запрос увидел % задач', n; END IF;
END $$;
\echo '    ок'

\echo '--- 2. Участник видит свой проект и не видит чужой ---'
SELECT set_config('app.user_id', '11111111-1111-4111-8111-111111111111', true);
DO $$
DECLARE n int;
BEGIN
    SELECT count(*) INTO n FROM app.columns WHERE board_id = 'a0000000-0000-4000-8000-000000000001';
    IF n = 0 THEN RAISE EXCEPTION 'Владелец не видит колонки собственного проекта'; END IF;

    -- Колонки чужого проекта здесь видны: у этого пользователя в нём
    -- есть задачи по точечному доступу, а с 0005 проект с видимой
    -- задачей виден целиком (can_see_board). Постороннему — нет, это
    -- проверяется в разделе 5.

    SELECT count(*) INTO n FROM app.board_members WHERE board_id = 'a0000000-0000-4000-8000-000000000002';
    IF n <> 0 THEN RAISE EXCEPTION 'Виден состав участников чужого проекта'; END IF;
END $$;
\echo '    ок'

\echo '--- 3. Точечный грант открывает ровно нужные задачи ---'
DO $$
DECLARE granted int;
BEGIN
    SELECT count(*) INTO granted FROM app.tasks WHERE board_id = 'a0000000-0000-4000-8000-000000000002';
    IF granted = 0 THEN RAISE EXCEPTION 'Гранты не работают: ни одной чужой задачи не видно'; END IF;
    IF granted > 2 THEN RAISE EXCEPTION 'Грант протёк: видно % задач вместо 2', granted; END IF;
END $$;
\echo '    ок'

\echo '--- 4. Уровни доступа различаются ---'
DO $$
DECLARE lvl text;
BEGIN
    SELECT app.task_access(t.id, '11111111-1111-4111-8111-111111111111')
      INTO lvl FROM app.tasks t WHERE t.title = 'Резервное копирование';
    IF lvl <> 'read' THEN RAISE EXCEPTION 'Грант «просмотр» дал уровень %', lvl; END IF;

    SELECT app.task_access(t.id, '11111111-1111-4111-8111-111111111111')
      INTO lvl FROM app.tasks t WHERE t.title = 'Схема таблиц комментариев';
    IF lvl <> 'contribute' THEN RAISE EXCEPTION 'Грант «участие» дал уровень %', lvl; END IF;
END $$;
\echo '    ок'

\echo '--- 5. Исполнитель проекта не видит и не правит чужие задачи, посторонний не видит проект ---'
-- С 0011 роль «исполнитель» (reader) открывает проект, но не его
-- задачи: видны только те, где человек автор, исполнитель или
-- получатель точечного доступа.
SELECT set_config('app.user_id', '66666666-6666-4666-8666-666666666666', true);
DO $$
DECLARE n int; affected int;
BEGIN
    SELECT count(*) INTO n FROM app.columns WHERE board_id = 'a0000000-0000-4000-8000-000000000001';
    IF n = 0 THEN RAISE EXCEPTION 'Исполнитель не видит колонки своего проекта'; END IF;

    SELECT count(*) INTO n FROM app.tasks WHERE board_id = 'a0000000-0000-4000-8000-000000000001';
    IF n <> 0 THEN RAISE EXCEPTION 'Исполнитель видит % чужих задач проекта', n; END IF;

    UPDATE app.tasks SET title = 'Взлом' WHERE board_id = 'a0000000-0000-4000-8000-000000000001';
    GET DIAGNOSTICS affected = ROW_COUNT;
    IF affected <> 0 THEN RAISE EXCEPTION 'Исполнитель изменил чужую задачу — tasks_update дырявая'; END IF;

    DELETE FROM app.tasks WHERE board_id = 'a0000000-0000-4000-8000-000000000001';
    GET DIAGNOSTICS affected = ROW_COUNT;
    IF affected <> 0 THEN RAISE EXCEPTION 'Исполнитель удалил чужую задачу — tasks_delete дырявая'; END IF;

    SELECT count(*) INTO n FROM app.columns WHERE board_id = 'a0000000-0000-4000-8000-000000000002';
    IF n <> 0 THEN RAISE EXCEPTION 'Видны % колонок проекта, к которому нет никакого доступа', n; END IF;
END $$;
\echo '    ок'

\echo '--- 6. Нельзя писать от чужого имени ---'
DO $$
DECLARE task_id uuid;
BEGIN
    SELECT id INTO task_id FROM app.tasks LIMIT 1;
    BEGIN
        INSERT INTO app.comments (task_id, author_id, body)
        VALUES (task_id, '11111111-1111-4111-8111-111111111111', 'Подделка авторства');
        RAISE EXCEPTION 'Удалось подписать комментарий чужим именем';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END $$;
\echo '    ок'

\echo '--- 7. Чужие уведомления недоступны ---'
DO $$
DECLARE n int;
BEGIN
    SELECT count(*) INTO n FROM app.notifications WHERE user_id <> '66666666-6666-4666-8666-666666666666';
    IF n <> 0 THEN RAISE EXCEPTION 'Видно % чужих уведомлений', n; END IF;
END $$;
\echo '    ок'

\echo '--- 8. Хеш пароля недоступен на чтение ---'
DO $$
BEGIN
    BEGIN
        PERFORM password_hash FROM app.users LIMIT 1;
        RAISE EXCEPTION 'Хеш пароля читается напрямую';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END $$;
\echo '    ок'

\echo '--- 9. Наблюдатели WebSocket совпадают с теми, кому виден проект ---'
-- Не с составом участников: с 0005 проект виден и тем, у кого в нём
-- есть видимая задача, и события проекта должны доходить до них же.
SELECT set_config('app.user_id', '11111111-1111-4111-8111-111111111111', true);
DO $$
DECLARE extra int; missing int;
BEGIN
    SELECT count(*) INTO extra FROM (
        SELECT w FROM app.board_watchers('a0000000-0000-4000-8000-000000000001') w
        EXCEPT
        SELECT u.id FROM app.users u WHERE app.can_see_board('a0000000-0000-4000-8000-000000000001', u.id)) x;
    SELECT count(*) INTO missing FROM (
        SELECT u.id FROM app.users u WHERE app.can_see_board('a0000000-0000-4000-8000-000000000001', u.id)
        EXCEPT
        SELECT w FROM app.board_watchers('a0000000-0000-4000-8000-000000000001') w) y;
    IF extra <> 0 OR missing <> 0 THEN
        RAISE EXCEPTION 'board_watchers расходится с can_see_board: лишних %, недостающих %', extra, missing;
    END IF;
END $$;
\echo '    ок'

\echo '--- 10. Прочтение уведомлений касается только своих и гасит отметку (0025) ---'
-- Чужие уведомления под RLS не видны, поэтому «не задело ли чужие»
-- проверяется переключением: каждый считает только свои.
SELECT set_config('app.user_id', '11111111-1111-4111-8111-111111111111', true);
CREATE TEMP TABLE rls10 AS SELECT app.unread_notifications() AS anna_before;
SELECT set_config('app.user_id', '66666666-6666-4666-8666-666666666666', true);
DO $$
BEGIN
    PERFORM * FROM app.read_notifications(NULL);
    IF app.unread_notifications() <> 0 THEN
        RAISE EXCEPTION 'После «прочитать все» осталось % своих непрочитанных', app.unread_notifications();
    END IF;
END $$;
SELECT set_config('app.user_id', '11111111-1111-4111-8111-111111111111', true);
DO $$
DECLARE t uuid;
BEGIN
    IF app.unread_notifications() <> (SELECT anna_before FROM rls10) THEN
        RAISE EXCEPTION 'read_notifications одного пользователя прочитал уведомления другого';
    END IF;

    -- Открытие задачи гасит её уведомления.
    SELECT n.task_id INTO t FROM app.notifications n
     WHERE n.read_at IS NULL AND n.task_id IS NOT NULL
       AND app.can_see_task(n.task_id, app.current_user_id()) LIMIT 1;
    IF t IS NOT NULL THEN
        PERFORM app.mark_seen('task', t, app.current_user_id());
        IF EXISTS (SELECT 1 FROM app.notifications WHERE task_id = t AND read_at IS NULL) THEN
            RAISE EXCEPTION 'Открытие задачи не погасило её уведомления';
        END IF;
    END IF;
END $$;
\echo '    ок'

\echo '--- 11. Панель «Доступы»: посторонний не выдаёт доступ, редактор не трогает владельца (0027) ---'
-- Регресс: can_edit_board для постороннего возвращает NULL, и проверка
-- вида «IF NOT ...» в PL/pgSQL молча пропускала его.
-- Идентификатор чужой задачи берём от имени того, кому она видна:
-- посторонний её не видит и сам найти не может.
SELECT set_config('app.user_id', '11111111-1111-4111-8111-111111111111', true);
CREATE TEMP TABLE rls11 AS SELECT id FROM app.tasks WHERE title = 'Резервное копирование';
SELECT set_config('app.user_id', '66666666-6666-4666-8666-666666666666', true);
DO $$
BEGIN
    IF (SELECT count(*) FROM rls11) <> 1 THEN
        RAISE EXCEPTION 'Подготовка: задача «Резервное копирование» не найдена';
    END IF;
    BEGIN
        PERFORM app.set_board_access('a0000000-0000-4000-8000-000000000002',
                                     '66666666-6666-4666-8666-666666666666', 'editor');
        RAISE EXCEPTION 'Посторонний выдал себе доступ к чужому проекту';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM app.revoke_board_access('a0000000-0000-4000-8000-000000000002',
                                        '22222222-2222-4222-8222-222222222222');
        RAISE EXCEPTION 'Посторонний снял участника чужого проекта';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM app.set_task_access((SELECT id FROM rls11),
                                    '66666666-6666-4666-8666-666666666666', 'contribute');
        RAISE EXCEPTION 'Посторонний выдал себе доступ к чужой задаче';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    IF EXISTS (SELECT 1 FROM app.access_overview('22222222-2222-4222-8222-222222222222')) THEN
        RAISE EXCEPTION 'Посторонний видит доступы участника чужого проекта';
    END IF;
END $$;
SELECT set_config('app.user_id', '44444444-4444-4444-8444-444444444444', true);
DO $$
BEGIN
    BEGIN
        PERFORM app.revoke_board_access('a0000000-0000-4000-8000-000000000002',
                                        '22222222-2222-4222-8222-222222222222');
        RAISE EXCEPTION 'Редактор снял владельца проекта';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM app.copy_access('88888888-8888-4888-8888-888888888888',
                                '66666666-6666-4666-8666-666666666666');
        RAISE EXCEPTION 'Не-администратор скопировал доступ';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM * FROM app.offboard_user('66666666-6666-4666-8666-666666666666', NULL);
        RAISE EXCEPTION 'Не-администратор удалил сотрудника';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END $$;
\echo '    ок'

ROLLBACK;
\echo ''
\echo 'Все проверки пройдены.'
