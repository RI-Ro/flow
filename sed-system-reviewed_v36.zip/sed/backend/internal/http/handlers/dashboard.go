package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
)

type DashboardHandler struct {
	pool *pgxpool.Pool
}

func NewDashboardHandler(pool *pgxpool.Pool) *DashboardHandler {
	return &DashboardHandler{pool: pool}
}

// Stats GET /api/dashboard — сводная статистика для дашборда. Все счётчики
// считаются под RLS текущего пользователя (видит только доступные документы),
// поэтому цифры персональные: "мои документы в разрезе статусов" и т.п.
// Один поход в БД: агрегаты собираются несколькими запросами в одной
// транзакции; ключевые — GROUP BY по индексируемым столбцам.
func (h *DashboardHandler) Stats(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	type kv struct {
		Key   string `json:"key"`
		Count int64  `json:"count"`
	}
	result := fiber.Map{}

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// По статусам (использует idx_documents_status_only).
		byStatus, err := groupCount(c, tx, `SELECT status::text, count(*) FROM documents WHERE status <> 'archived' GROUP BY status`)
		if err != nil {
			return err
		}
		result["by_status"] = byStatus

		// По срочности (idx_documents_urgency_only).
		byUrgency, err := groupCount(c, tx, `SELECT urgency::text, count(*) FROM documents WHERE status <> 'archived' GROUP BY urgency`)
		if err != nil {
			return err
		}
		result["by_urgency"] = byUrgency

		// Роль-центричные счётчики для карточек «требует моего действия».
		var onMyApproval, onMySigning, onMyExecution, overdue int64

		// Этапы, ожидающие моего решения (pending, я согласующий/подписант).
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM approval_stages
			WHERE approver_id = $1 AND status = 'pending'`, userID).Scan(&onMyApproval); err != nil {
			return err
		}
		// Из них подпись — отдельно.
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM approval_stages
			WHERE approver_id = $1 AND status = 'pending' AND stage_type = 'signing'`, userID).Scan(&onMySigning); err != nil {
			return err
		}
		// Документы, где я получатель и ещё не отметил исполнение.
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM document_recipients
			WHERE recipient_user_id = $1 AND completed_at IS NULL`, userID).Scan(&onMyExecution); err != nil {
			return err
		}
		// Просроченные по сроку среди видимых.
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM documents
			WHERE due_date IS NOT NULL AND due_date < current_date
			  AND status NOT IN ('executed','archived','rejected')`).Scan(&overdue); err != nil {
			return err
		}

		// Документы на контроле (всего видимых под RLS) + где я контролёр.
		var onControlTotal, onControlMine int64
		if err := tx.QueryRow(c.Context(), `SELECT count(*) FROM documents WHERE on_control = true AND status <> 'archived'`).Scan(&onControlTotal); err != nil {
			return err
		}
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM documents d
			WHERE d.on_control = true
			  AND (d.controller_id = $1
			       OR EXISTS (SELECT 1 FROM document_controllers dc WHERE dc.document_id = d.id AND dc.user_id = $1))`,
			userID).Scan(&onControlMine); err != nil {
			return err
		}
		result["on_control"] = fiber.Map{"total": onControlTotal, "mine": onControlMine}

		// Входящие (где пользователь — получатель) для карточки раздела.
		var incomingTotal int64
		if err := tx.QueryRow(c.Context(), `
			SELECT count(DISTINCT document_id) FROM document_recipients
			WHERE recipient_user_id = $1 AND is_planned = false`, userID).Scan(&incomingTotal); err != nil {
			return err
		}
		result["incoming_total"] = incomingTotal

		// Исходящие (для карточки раздела): документы МОЕГО подразделения,
		// получившие исходящий номер (т.е. реально исходящие). Считаем именно
		// так, а не «любой видимый sent-документ», иначе у чисто-входящего
		// пользователя (напр. дежурного) карточка «Исходящие» ошибочно
		// ненулевая за счёт его входящих экземпляров.
		// Исходящие (для карточки раздела): считаем по той же логике, что и
		// список категории «исходящие» (#3) — автор / согласующий по иерархии /
		// подписант / видимость подразделения-автора. RLS ограничивает выборку.
		var outgoingTotal int64
		if err := tx.QueryRow(c.Context(), `
			SELECT count(*) FROM documents d
			WHERE d.outgoing_number IS NOT NULL AND d.status <> 'archived' AND (
			     d.author_id = $1
			  OR EXISTS (SELECT 1 FROM approval_stages s WHERE s.document_id=d.id AND s.approver_id=$1 AND s.stage_type='hierarchy')
			  OR EXISTS (SELECT 1 FROM approval_stages s WHERE s.document_id=d.id AND s.approver_id=$1 AND s.stage_type='signing')
			  OR d.author_department_id = (SELECT primary_department_id FROM users WHERE id=$1)
			  OR d.author_department_id IN (SELECT department_id FROM user_visible_departments WHERE user_id=$1)
			)`, userID).Scan(&outgoingTotal); err != nil {
			return err
		}
		result["outgoing_total"] = outgoingTotal

		result["my_actions"] = fiber.Map{
			"on_approval":  onMyApproval - onMySigning,
			"on_signing":   onMySigning,
			"on_execution": onMyExecution,
			"on_control":   onControlMine,
			"overdue":      overdue,
		}
		_ = kv{}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить статистику")
	}
	return c.JSON(result)
}

func groupCount(c *fiber.Ctx, tx pgx.Tx, query string) ([]fiber.Map, error) {
	rows, err := tx.Query(c.Context(), query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []fiber.Map
	for rows.Next() {
		var key string
		var count int64
		if err := rows.Scan(&key, &count); err != nil {
			return nil, err
		}
		out = append(out, fiber.Map{"key": key, "count": count})
	}
	return out, rows.Err()
}
