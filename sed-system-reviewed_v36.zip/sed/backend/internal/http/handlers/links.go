package handlers

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
)

var errForbiddenLink = errors.New("forbidden link")

// LinksHandler — связанные документы (EnDocs-подобно): «в ответ на»,
// «во исполнение», «приложение» и т.п.
type LinksHandler struct {
	pool *pgxpool.Pool
}

func NewLinksHandler(pool *pgxpool.Pool) *LinksHandler {
	return &LinksHandler{pool: pool}
}

var linkTypeLabels = map[string]bool{
	"related": true, "reply_to": true, "annuls": true, "appendix": true, "in_addition": true,
	// legacy: принимаем для обратной совместимости при отображении старых связей
	"in_pursuance_of": true,
}

// List GET /api/documents/:id/links — связи документа (в обе стороны).
func (h *LinksHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type link struct {
		LinkID     int64   `json:"link_id"`
		DocumentID *int64  `json:"document_id,omitempty"`
		Title      string  `json:"title"`
		Number     string  `json:"number"`
		TextNote   *string `json:"text_note,omitempty"`
		LinkType   string  `json:"link_type"`
		Direction  string  `json:"direction"`
	}
	var items []link
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT l.id, t.id, t.title, coalesce(t.outgoing_number, '#'||t.id::text), l.text_note, l.link_type, 'outgoing'
			FROM document_links l LEFT JOIN documents t ON t.id = l.target_document_id
			WHERE l.source_document_id = $1
			UNION ALL
			SELECT l.id, s.id, s.title, coalesce(s.outgoing_number, '#'||s.id::text), l.text_note, l.link_type, 'incoming'
			FROM document_links l JOIN documents s ON s.id = l.source_document_id
			WHERE l.target_document_id = $1`, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it link
			var tID *int64
			var title, number *string
			if err := rows.Scan(&it.LinkID, &tID, &title, &number, &it.TextNote, &it.LinkType, &it.Direction); err != nil {
				return err
			}
			it.DocumentID = tID
			if title != nil {
				it.Title = *title
			}
			if number != nil {
				it.Number = *number
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load links")
	}
	return c.JSON(fiber.Map{"items": items})
}

type createLinkRequest struct {
	TargetDocumentID int64  `json:"target_document_id"`
	TextNote         string `json:"text_note"`
	LinkType         string `json:"link_type"`
}

// Create POST /api/documents/:id/links — добавить связь.
func (h *LinksHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	var req createLinkRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid body")
	}
	if req.LinkType == "" {
		req.LinkType = "related"
	}
	if !linkTypeLabels[req.LinkType] {
		return fiber.NewError(fiber.StatusBadRequest, "неизвестный тип связи")
	}
	// Ровно один вид связи: либо на документ, либо текстовая заметка.
	hasTarget := req.TargetDocumentID != 0
	hasText := req.TextNote != ""
	if hasTarget == hasText {
		return fiber.NewError(fiber.StatusBadRequest, "укажите либо документ, либо текстовую заметку (одно из двух)")
	}
	if req.TargetDocumentID == docID {
		return fiber.NewError(fiber.StatusBadRequest, "нельзя связать документ с самим собой")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Право добавлять связи — только у автора и подписанта (остальные видят
		// связи только на просмотр).
		allowed, err := service.IsAuthorOrSigner(c.Context(), tx, docID, userID)
		if err != nil {
			return err
		}
		if !allowed && !isAdmin {
			return errForbiddenLink
		}
		if hasTarget {
			var ok bool
			if err := tx.QueryRow(c.Context(), `SELECT EXISTS(SELECT 1 FROM documents WHERE id=$1)`, req.TargetDocumentID).Scan(&ok); err != nil {
				return err
			}
			if !ok {
				return pgx.ErrNoRows
			}
			_, err := tx.Exec(c.Context(), `
				INSERT INTO document_links (source_document_id, target_document_id, link_type, created_by)
				VALUES ($1, $2, $3, $4)
				ON CONFLICT DO NOTHING`, docID, req.TargetDocumentID, req.LinkType, userID)
			return err
		}
		// Текстовая связь.
		_, err = tx.Exec(c.Context(), `
			INSERT INTO document_links (source_document_id, text_note, link_type, created_by)
			VALUES ($1, $2, $3, $4)`, docID, req.TextNote, req.LinkType, userID)
		return err
	})
	if txErr != nil {
		if txErr == errForbiddenLink {
			return fiber.NewError(fiber.StatusForbidden, "связывать документы может только автор или подписант")
		}
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "документ для связи не найден или недоступен")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to create link")
	}
	return c.SendStatus(fiber.StatusCreated)
}

// Delete DELETE /api/documents/:id/links/:linkId — удалить связь документа.
// Разрешено автору документа, подписанту или тому, кто создал связь (или admin).
func (h *LinksHandler) Delete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	linkID, err := strconv.ParseInt(c.Params("linkId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid link id")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if !isAdmin {
			var createdBy, authorID int64
			if err := tx.QueryRow(c.Context(), `
				SELECT l.created_by, d.author_id
				FROM document_links l JOIN documents d ON d.id = l.source_document_id
				WHERE l.id = $1 AND l.source_document_id = $2`, linkID, docID).Scan(&createdBy, &authorID); err != nil {
				return err
			}
			isSigner, err := service.IsAuthorOrSigner(c.Context(), tx, docID, userID)
			if err != nil {
				return err
			}
			if userID != createdBy && userID != authorID && !isSigner {
				return errForbiddenLink
			}
		}
		ct, err := tx.Exec(c.Context(), `DELETE FROM document_links WHERE id=$1 AND source_document_id=$2`, linkID, docID)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		if txErr == errForbiddenLink {
			return fiber.NewError(fiber.StatusForbidden, "удалять связь может автор, подписант или её создатель")
		}
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "связь не найдена")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить связь")
	}
	return c.SendStatus(fiber.StatusOK)
}
