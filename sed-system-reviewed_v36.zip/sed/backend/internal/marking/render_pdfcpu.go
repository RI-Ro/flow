package marking

import (
	"bytes"
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"sync"

	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"

	"sed-system/backend/internal/config"
)

// Реальное нанесение штампов на PDF через pdfcpu (чистый Go, без cgo).
//
// КИРИЛЛИЦА: core-шрифты PDF (Helvetica и пр.) кириллицу не отображают,
// поэтому для русскоязычных штампов НУЖЕН TTF-шрифт с кириллицей. Путь к нему
// задаётся в config.yaml (marking.font_file); шрифт one-time устанавливается в
// pdfcpu и используется по имени (marking.font_name). Если шрифт не задан/не
// установился — падать нельзя (документ должен открываться), поэтому в этом
// случае используется Helvetica (латиница/цифры отрисуются, кириллица — нет),
// а в лог пишется предупреждение.

var (
	fontOnce sync.Once
	fontName string // имя установленного шрифта; "" => Helvetica
)

// Configure подключает реальный рендер штампов. Вызывается один раз из main
// после загрузки конфигурации. Устанавливает кириллический шрифт (если задан)
// и присваивает marking.RenderHook.
func Configure(cfg config.MarkingConfig) {
	fontOnce.Do(func() {
		if cfg.FontName != "" {
			fontName = cfg.FontName
		} else if cfg.FontFile != "" {
			base := filepath.Base(cfg.FontFile)
			fontName = strings.TrimSuffix(base, filepath.Ext(base))
		}
		// Если задан файл — пробуем установить (Linux/Docker). Установка пишет
		// шрифт в пользовательский каталог pdfcpu И обновляет метрики в памяти.
		if cfg.FontFile != "" {
			if err := api.InstallFonts([]string{cfg.FontFile}); err != nil {
				log.Printf("marking: авто-установка шрифта %s не удалась: %v. "+
					"Установите один раз командой `pdfcpu fonts install <path>` и укажите "+
					"marking.font_name в config.yaml.", cfg.FontFile, err)
			} else {
				log.Printf("marking: шрифт %q установлен", fontName)
			}
		}
		if fontName == "" {
			log.Printf("marking: кириллический шрифт не задан — кириллица в штампах не отобразится "+
				"(укажите marking.font_file/font_name)")
		}
	})

	RenderHook = renderWithPDFCPU
}

func renderWithPDFCPU(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 {
		return original, nil
	}
	buf := make([]byte, len(original))
	copy(buf, original)

	applied := 0
	for _, s := range specs {
		// Пытаемся нанести штамп с настроенным шрифтом; при ошибке (напр. шрифт
		// не найден) — повторяем без fontname (Helvetica), чтобы НЕ ломать всю
		// маркировку из-за одного проблемного шрифта. Если и это не удалось —
		// пропускаем конкретный штамп, но не роняем весь документ (#3: включение
		// bake не должно ломать нанесение в принципе).
		next, err := applyOneWatermark(buf, s, true)
		if err != nil {
			log.Printf("marking: штамп %q со шрифтом %q не нанесён (%v) — пробуем без шрифта", s.Text, fontName, err)
			next, err = applyOneWatermark(buf, s, false)
		}
		if err != nil {
			log.Printf("marking: штамп %q пропущен: %v", s.Text, err)
			continue
		}
		buf = next
		applied++
	}
	if applied == 0 {
		// Ни один штамп не удалось нанести — возвращаем оригинал (без ошибки),
		// чтобы вызывающий код мог отдать документ; экранную маркировку покажет
		// overlay вьювера.
		return original, nil
	}
	return buf, nil
}

// applyOneWatermark наносит один штамп. withFont=false принудительно убирает
// fontname (fallback на Helvetica).
func applyOneWatermark(src []byte, s Spec, withFont bool) ([]byte, error) {
	desc := buildWatermarkDesc(s, withFont)
	wm, err := api.TextWatermark(s.Text, desc, true /*onTop*/, false /*update*/, types.POINTS)
	if err != nil {
		return nil, fmt.Errorf("build watermark: %w", err)
	}
	var out bytes.Buffer
	if err := api.AddWatermarks(bytes.NewReader(src), &out, []string{"1"}, wm, nil); err != nil {
		return nil, fmt.Errorf("apply watermark: %w", err)
	}
	return out.Bytes(), nil
}

// buildWatermarkDesc собирает строку-описание watermark на мини-языке pdfcpu.
func buildWatermarkDesc(s Spec, withFont bool) string {
	parts := []string{
		fmt.Sprintf("pos:%s", s.Position),
		fmt.Sprintf("offset:%d %d", int(s.OffsetX), int(s.OffsetY)),
		fmt.Sprintf("points:%d", s.FontSize),
		fmt.Sprintf("fillcolor:%s", s.Color),
		"scalefactor:1 abs",
		"rotation:0",
		"opacity:1",
	}
	if withFont && fontName != "" {
		parts = append(parts, fmt.Sprintf("fontname:%s", fontName))
	}
	if s.Border {
		// pdfcpu ждёт ЧИСЛОВУЮ ширину рамки; "border:on" приводит к падению.
		parts = append(parts, "border:1")
	}
	return strings.Join(parts, ", ")
}
