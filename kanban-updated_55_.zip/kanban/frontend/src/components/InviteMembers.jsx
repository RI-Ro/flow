import React, { useState } from "react";
import { Video, Mail } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, ConfirmDialog } from "../lib/ui.jsx";
import { conferenceLink, conferenceNames, resolveUser } from "../lib/theme.js";

// Сбор участников диаграммы или совместной доски.
//
// Устроено так же, как в карточке задачи, и по тем же причинам:
//
//   • письмо — обычная ссылка mailto: в почтовую программу человека;
//   • видеоконференция — ссылка callto:, которую понимают корпоративные
//     клиенты связи. Кнопка появляется только при двух и более
//     участниках с телефонами: звать на «конференцию» одного человека
//     смысла нет;
//   • вызов уходит ТОЛЬКО после подтверждения — случайное нажатие
//     мгновенно поднимает трубку у нескольких человек сразу.
//
// Вдобавок к этому уведомление внутри приложения — оно уходит вместе с
// вызовом и вместе с письмом, отдельной кнопки для него нет: вызов и
// письмо уходят на машину человека, проверить их доставку нельзя, а
// приглашение не должно потеряться, если телефон не под рукой. Оно же
// остаётся в колокольчике и открывает саму доску (диаграмму) нажатием.
export default function InviteMembers({ theme, kind, object, directory, currentUser, onClose, onError }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState("");
  const [pendingCall, setPendingCall] = useState(null);

  const isBoard = kind === "whiteboard";
  const what = isBoard ? "доске" : "диаграмме";

  // Участники — все, кто допущен к объекту. Для конференции нужны те,
  // у кого указан телефон: остальных набирать нечем.
  const members = (object.members || [])
    .map((m) => resolveUser(directory, m.userId))
    .filter((u) => u && !u.deleted);
  const confParticipants = members.filter((u) => u.phone);

  const confLink = confParticipants.length >= 2
    ? conferenceLink(confParticipants, currentUser?.id) : null;
  const confNames = conferenceNames(confParticipants, currentUser?.id);

  const mails = members
    .filter((u) => u.email && u.id !== currentUser?.id)
    .map((u) => u.email);
  const mailNames = conferenceNames(members.filter((u) => u.email), currentUser?.id);

  const subject = isBoard
    ? `Совместное обсуждение на доске "${object.title}"`
    : `Диаграмма "${object.title}"`;
  const letter = isBoard
    ? `Уважаемые коллеги!\n\nПрошу принять участие в совместном обсуждении на доске "${object.title}".`
    : `Уважаемые коллеги!\n\nПрошу ознакомиться с диаграммой "${object.title}".`;
  const mailLink = mails.length
    ? `mailto:${mails.join(",")}?subject=${encodeURIComponent(subject)}`
      + `&body=${encodeURIComponent(letter)}`
    : null;

  // Уведомление внутри приложения. Отправляется и само по себе, и
  // вместе с вызовом или письмом.
  const notify = async (inviteKind) => {
    setBusy(true);
    try {
      if (isBoard) await api.inviteWhiteboard(object.id, inviteKind);
      else await api.inviteChart(object.id, inviteKind);
      setDone("Уведомление отправлено участникам");
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="invite-members">
      <ModalHeader theme={theme} title="Собрать участников"
        subtitle={`«${object.title}»`} onClose={onClose} />

      <p style={{ color: theme.textMuted }} className="text-[12.5px] leading-relaxed mb-3">
        {members.length <= 1
          ? `Кроме вас, в ${what} пока никого нет — добавьте участников.`
          : `Участники: ${conferenceNames(members, currentUser?.id)}.`}
      </p>

      {done && (
        <p style={{ color: theme.success }} className="text-[12.5px] mb-1">{done}</p>
      )}

      {mailLink && (
        <a href={mailLink} onClick={() => notify("review")}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="w-full mt-3 rounded-lg py-2.5 text-[12.5px] font-semibold flex items-center justify-center gap-2"
          title={`Написать: ${mailNames}`}>
          <Mail size={15} style={{ color: theme.accent }} />
          <span className="flex flex-col items-start leading-tight">
            <span>Написать участникам</span>
            <span style={{ color: theme.textMuted }} className="text-[10.5px] font-normal">
              {mailNames}
            </span>
          </span>
        </a>
      )}

      {confLink && (
        <button onClick={() => setPendingCall({ href: confLink, names: confNames })}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="w-full mt-3 rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-2"
          title={`Собрать участников: ${confNames}`}>
          <Video size={15} style={{ color: theme.accent }} />
          <span className="flex flex-col items-start leading-tight">
            <span>Видеоконференция</span>
            <span style={{ color: theme.textMuted }} className="text-[11px] font-normal">
              {confNames}
            </span>
          </span>
        </button>
      )}

      {!confLink && members.length > 1 && (
        <p style={{ color: theme.textMuted }} className="text-[11.5px] mt-2">
          Для конференции нужно, чтобы телефон был указан хотя бы у двух участников.
        </p>
      )}

      <button onClick={onClose} style={{ color: theme.textMuted }}
        className="w-full rounded-lg py-2 mt-3 text-[12.5px]">Закрыть</button>

      {pendingCall && (
        <ConfirmDialog theme={theme}
          title="Начать видеоконференцию?"
          message={`Вызов будет отправлен участникам: ${pendingCall.names}. Убедитесь, что это не случайное нажатие.`}
          confirmLabel="Позвонить" danger={false}
          onCancel={() => setPendingCall(null)}
          onConfirm={() => {
            const href = pendingCall.href;
            setPendingCall(null);
            // Уведомление уходит вместе с вызовом: у кого телефон не
            // под рукой, тот увидит приглашение в колокольчике.
            notify("call");
            window.location.href = href;
          }} />
      )}
    </Modal>
  );
}
