import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Plus, Trash2, Pencil, LayoutDashboard, Users as UsersIcon, MousePointer2,
  StickyNote, Square, Circle, Diamond, Triangle, Type, Minus, ArrowRight,
  Pen, Hand, Eraser, ZoomIn, ZoomOut, Maximize2, Undo2, Redo2, Shapes,
  Link as LinkIcon, Image as ImageIcon, FileText, Upload,
  ChevronsUp, ChevronsDown, ChevronUp, ChevronDown, Bold, Italic, Paintbrush,
  RotateCw, Check, Crosshair, Copy, ClipboardPaste, Group, Ungroup, Video,
} from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage, realtimeSend } from "../lib/realtime.js";
import { copyText, resolveUser } from "../lib/theme.js";
import { Modal, ModalHeader, Field, Spinner, inputStyle } from "../lib/ui.jsx";
import { NameModal, MembersModal } from "./Charts.jsx";
import InviteMembers from "./InviteMembers.jsx";
import { ICON_GROUPS, ICON_TITLES, ANIMATED_ICONS, ICON_COUNT, iconBody, hasIcon } from "../lib/boardIcons.js";
import { exportPng, exportPdf, linePath } from "../lib/wbExport.js";

// =====================================================================
// Совместные доски — бесконечный холст, который несколько человек
// правят одновременно.
//
// Как устроена одновременность:
//
//   • каждая фигура — отдельная строка в базе и отдельное событие.
//     Единый документ на доску означал бы, что двое, двигающие разные
//     стикеры, затирают работу друг друга;
//   • пока фигуру тянут, кадры движения идут прямо по WebSocket и
//     нигде не сохраняются. В базу уходит только итог, когда кнопку
//     мыши отпустили. Иначе одно перетаскивание — это сотня записей;
//   • своё эхо клиент игнорирует по полю «by»: фигура под собственным
//     курсором не должна дёргаться от собственных же событий.
//
// Размер полотна задаётся доской, а не экраном: доска, собранная на
// большом мониторе, должна на ноутбуке выглядеть так же, только с
// прокруткой.
// =====================================================================

const TOOLS = [
  ["select", MousePointer2, "Выбрать (V)"],
  ["pan",    Hand,          "Двигать холст (H)"],
  ["note",   StickyNote,    "Стикер (N)"],
  ["rect",   Square,        "Прямоугольник (R)"],
  ["ellipse", Circle,       "Овал (O)"],
  ["diamond", Diamond,      "Ромб"],
  ["triangle", Triangle,    "Треугольник"],
  ["text",   Type,          "Текст (T)"],
  ["line",   Minus,         "Линия (L)"],
  ["arrow",  ArrowRight,    "Стрелка (A)"],
  ["draw",   Pen,           "Перо (P)"],
  ["frame",  Maximize2,     "Рамка области"],
  ["icon",   Shapes,        "Значок (I)"],
  ["eraser", Eraser,        "Ластик (E)"],
];

// Предопределённые цвета — как у задач: свободная палитра на доске
// быстро превращается в двадцать оттенков одного и того же, и схемы
// перестают читаться. Значения подобраны так, чтобы тёмный текст
// оставался различимым на любой заливке.
// Палитра заливки фигур. Шире прежней: десяти цветов хватало на
// стикеры, но не на схему, где цветом различают среды, зоны и
// назначение оборудования. Порядок — по тону, чтобы соседние оттенки
// лежали рядом и выбирались на глаз.
const PALETTE = [
  ["#FFF3B0", "Светло-жёлтый"],
  ["#FFD966", "Жёлтый"],
  ["#F6B26B", "Песочный"],
  ["#F4A259", "Оранжевый"],
  ["#E8865A", "Терракотовый"],
  ["#E36A6A", "Красный"],
  ["#C1666B", "Приглушённый красный"],
  ["#F4B6C2", "Розовый"],
  ["#D5A6BD", "Пыльная роза"],
  ["#B4A7D6", "Сиреневый"],
  ["#9B8AC4", "Фиолетовый"],
  ["#7768AE", "Тёмно-фиолетовый"],
  ["#A2C4C9", "Пыльная бирюза"],
  ["#8AC6A9", "Мятный"],
  ["#5B8C5A", "Зелёный"],
  ["#2A9D8F", "Бирюзовый"],
  ["#9FC5E8", "Голубой"],
  ["#6FA8DC", "Синий"],
  ["#3D5A80", "Тёмно-синий"],
  ["#2F4858", "Графитовый"],
  ["#D9D2C5", "Бежевый"],
  ["#C7CBD1", "Серый"],
  ["#8E9AAF", "Стальной"],
  ["#5A6472", "Тёмно-серый"],
  ["#FFFFFF", "Белый"],
  ["#1B1B1B", "Чёрный"],
];

// Цвета текста. Отдельный ряд: надпись должна читаться на любой
// заливке, поэтому здесь и очень тёмные, и очень светлые тона.
const TEXT_COLORS = [
  ["#1B1B1B", "Чёрный"],
  ["#3F3F46", "Тёмно-серый"],
  ["#6B7280", "Серый"],
  ["#FFFFFF", "Белый"],
  ["#F3F4F6", "Светло-серый"],
  ["#B3261E", "Красный"],
  ["#B45309", "Коричневый"],
  ["#946200", "Охра"],
  ["#1B5E20", "Зелёный"],
  ["#00695C", "Бирюзовый"],
  ["#0B3D91", "Синий"],
  ["#4527A0", "Фиолетовый"],
  ["#AD1457", "Малиновый"],
];

// Заливка полотна. Светлые тона для схем и печати, тёмные — для
// работы вечером и для досок, которые смотрят на проекторе.
const BOARD_BG = [
  ["#FFFFFF", "Белый"],
  ["#FAFAF7", "Молочный"],
  ["#F5F2EA", "Бумага"],
  ["#F3F6F4", "Светло-зелёный"],
  ["#EAF0F6", "Светло-голубой"],
  ["#F4EFF7", "Светло-сиреневый"],
  ["#FBF0EC", "Персиковый"],
  ["#EDEEF0", "Светло-серый"],
  ["#DDE3E8", "Серо-голубой"],
  ["#C9D3D8", "Стальной"],
  ["#2B3440", "Тёмно-синий"],
  ["#1E2430", "Ночной"],
  ["#11161F", "Почти чёрный"],
  ["#1B2018", "Тёмно-зелёный"],
];

const FONT_SIZES = [11, 13, 16, 20, 26, 34, 48];

// Размеры полотна. Одинаковые у всех участников; экран меньше — будет
// прокрутка, больше — поля по краям.
const BOARD_SIZES = [
  ["Стандартный (Full HD)", 1920, 1080],
  ["Средний (4K)", 3840, 2160],
  ["Большой (8K)", 7680, 4320],
];

// Ступени масштаба. 25% и 50% — чтобы увидеть большое полотно целиком.
const ZOOM_STEPS = [0.1, 0.25, 0.5, 0.75, 1, 1.5, 2, 3];
const clampZoom = (k) => Math.min(3, Math.max(0.1, k));
const nextZoom = (k) => ZOOM_STEPS.find((z) => z > k + 0.001) || 3;
const prevZoom = (k) => [...ZOOM_STEPS].reverse().find((z) => z < k - 0.001) || 0.1;

const DEFAULT_SIZE = {
  note: [180, 140], rect: [180, 120], ellipse: [160, 120], diamond: [150, 120],
  triangle: [150, 120], text: [220, 40], line: [180, 0], arrow: [180, 0],
  draw: [0, 0], frame: [420, 300], image: [200, 150], icon: [80, 80],
};

export default function Whiteboards({ theme, directory, team, currentUser, onError, openId, onOpened }) {
  const [boards, setBoards] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const list = await api.whiteboards();
      setBoards(list);
      setActiveId((prev) => (prev && list.some((b) => b.id === prev) ? prev : list[0]?.id || null));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [onError]);

  useEffect(() => { load(); }, [load]);

  // Доска, открытая по ссылке. Приходит из адреса — выбираем её, как
  // только список загрузился.
  useEffect(() => {
    if (!openId) return;
    if (boards.some((b) => b.id === openId)) {
      setActiveId(openId);
      onOpened?.();
    }
  }, [openId, boards, onOpened]);

  // Изменения самой доски и состава участников приходят событием:
  // права должны меняться на лету, без перезагрузки страницы.
  useEffect(() => onRealtimeMessage("whiteboard", () => { load(); }), [load]);

  const active = boards.find((b) => b.id === activeId) || null;

  if (loading) return <Spinner theme={theme} label="Загружаем доски…" />;

  return (
    <div className="pb-6">
      <div className="flex items-center gap-2 flex-wrap mb-3">
        <h2 style={{ color: theme.text }} className="text-[15px] font-semibold flex items-center gap-2">
          <LayoutDashboard size={16} /> Совместные доски
        </h2>
        <button onClick={() => setCreating(true)}
          style={{ background: theme.accent, color: theme.accentText }}
          className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-semibold">
          <Plus size={14} /> Новая доска
        </button>
      </div>

      {boards.length > 0 && (
        <div className="flex items-center gap-1.5 flex-wrap mb-3">
          {boards.map((b) => (
            <button key={b.id} onClick={() => setActiveId(b.id)}
              style={{
                background: b.id === activeId ? theme.accent : theme.surfaceAlt,
                color: b.id === activeId ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-3 py-1.5 rounded-lg text-[12.5px] font-medium">
              {b.title}
            </button>
          ))}
        </div>
      )}

      {boards.length === 0 ? (
        <p style={{ color: theme.textMuted }} className="text-[13px]">
          Досок пока нет. Создайте первую — это общий холст: стикеры, фигуры, значки,
          стрелки и надписи, которые все участники видят и правят одновременно.
        </p>
      ) : active ? (
        <BoardCanvas key={active.id} theme={theme} board={active} directory={directory}
          team={team} currentUser={currentUser} onError={onError} onChanged={load}
          onDeleted={() => { setActiveId(null); load(); }} />
      ) : null}

      {creating && (
        <BoardSettingsModal theme={theme} title="Новая доска"
          onClose={() => setCreating(false)}
          onSave={async (form) => {
            try {
              const b = await api.createWhiteboard(form);
              setBoards((prev) => [...prev, b]);
              setActiveId(b.id);
              setCreating(false);
            } catch (e) { onError(e.message); }
          }} />
      )}
    </div>
  );
}

/* ------------------------------------------------- свойства доски */

function BoardSettingsModal({ theme, title, board, onClose, onSave }) {
  const [form, setForm] = useState({
    title: board?.title || "",
    width: board?.width || 3840,
    height: board?.height || 2160,
    bgColor: board?.bgColor || "",
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="wb-settings">
      <ModalHeader theme={theme} title={title} onClose={onClose} />

      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} autoFocus
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <Field label="Размер полотна" theme={theme}
        hint="Одинаков у всех участников. Если экран меньше — появится прокрутка.">
        <div className="flex flex-col gap-1.5">
          {BOARD_SIZES.map(([label, w, h]) => (
            <button key={label} onClick={() => setForm((f) => ({ ...f, width: w, height: h }))}
              style={{
                background: form.width === w && form.height === h ? theme.accent : theme.surfaceAlt,
                color: form.width === w && form.height === h ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-3 py-2 rounded-lg text-[12.5px] text-left">
              {label} <span className="opacity-70">· {w}×{h}</span>
            </button>
          ))}
        </div>
      </Field>

      <Field label="Заливка доски" theme={theme}
        hint="Без заливки доска берёт цвет приложения, а в выгруженном файле останется прозрачной.">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button onClick={() => set("bgColor", "")}
            style={{
              background: theme.surfaceAlt, color: theme.text,
              border: `1px solid ${form.bgColor ? theme.border : theme.accent}`,
            }}
            className="px-2.5 py-1 rounded-lg text-[11.5px]">Как в приложении</button>
          {BOARD_BG.map(([c, name]) => (
            <button key={c} onClick={() => set("bgColor", c)}
              style={{ background: c, outline: form.bgColor === c ? `2px solid ${theme.accent}` : "none",
                border: `1px solid ${theme.border}` }}
              className="w-7 h-7 rounded-lg" title={name} />
          ))}
        </div>
      </Field>

      <div className="flex gap-2 mt-4">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={() => form.title.trim() && onSave({ ...form, title: form.title.trim() })}
          disabled={!form.title.trim()}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">Сохранить</button>
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------- сам холст */

function BoardCanvas({ theme, board, directory, team, currentUser, onError, onChanged, onDeleted }) {
  const [shapes, setShapes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tool, setTool] = useState("select");
  const [color, setColor] = useState(PALETTE[0][0]);
  // Выделение — список: фигуры двигают и оформляют пачками, и
  // одиночное выделение заставляло бы повторять одно и то же действие
  // столько раз, сколько фигур на схеме.
  const [selection, setSelection] = useState([]);
  const [marquee, setMarquee] = useState(null);   // рамка выделения
  const clipboard = useRef([]);
  const [editingText, setEditingText] = useState(null);
  const [membersOpen, setMembersOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [iconsOpen, setIconsOpen] = useState(false);
  const [pickedIcon, setPickedIcon] = useState({ icon: "router" });
  const [linkCopied, setLinkCopied] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);

  // Положение холста и масштаб переживают перезагрузку: человек
  // подобрал их под свою работу, и возвращаться каждый раз в центр со
  // 100% — это заново искать то место, где он остановился. Хранится
  // отдельно для каждой доски и только у этого человека: вид — личное
  // дело смотрящего, а не свойство доски.
  const viewKey = `kanban.wb.view.${board.id}`;
  const [view, setView] = useState(() => {
    try {
      const raw = JSON.parse(localStorage.getItem(viewKey) || "null");
      if (raw && Number.isFinite(raw.x) && Number.isFinite(raw.y) && raw.k > 0) return raw;
    } catch { /* испорченная запись — начнём с центра */ }
    return null;   // null означает «ещё не считали, встанем в центр»
  });
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!view) return;
    try { localStorage.setItem(viewKey, JSON.stringify(view)); }
    catch { /* приватный режим — просто не запомним */ }
  }, [view, viewKey]);

  const [peers, setPeers] = useState({});
  const [ghosts, setGhosts] = useState({});

  const canEdit = ["owner", "editor"].includes(board.myRole);
  const isOwner = board.myRole === "owner";
  const bg = board.bgColor || theme.surface;

  const load = useCallback(async () => {
    try { setShapes(await api.shapes(board.id)); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  }, [board.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Положение, при котором середина полотна совпадает с серединой
  // окна при заданном масштабе.
  const centeredView = useCallback((k) => {
    const r = wrapRef.current?.getBoundingClientRect();
    const w = r?.width || 0;
    const h = r?.height || 0;
    return { x: w / 2 - (board.width * k) / 2, y: h / 2 - (board.height * k) / 2 };
  }, [board.width, board.height]);

  const centerBoard = useCallback(() => {
    setView((v) => ({ ...v, ...centeredView(v.k) }));
  }, [centeredView]);

  // Первое открытие доски (сохранённого вида нет) — встаём в середину
  // полотна: угол пустой доски ничего не говорит, а содержимое люди
  // кладут от центра.
  useEffect(() => {
    setView((v) => v || { ...centeredView(1), k: 1 });
  }, [board.id, centeredView]);

  useEffect(() => {
    const join = () => realtimeSend({ type: "wbJoin", boardId: board.id });
    join();
    const t = setInterval(join, 20000);
    return () => {
      clearInterval(t);
      realtimeSend({ type: "wbLeave", boardId: board.id });
    };
  }, [board.id]);

  useEffect(() => onRealtimeMessage("shape", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id) return;
    if (p.by === currentUser?.id) return;
    if (e.action === "cleared") { setShapes([]); return; }
    if (e.action === "deleted") {
      setShapes((prev) => prev.filter((s) => s.id !== p.id));
      setGhosts((g) => { const n = { ...g }; delete n[p.id]; return n; });
      return;
    }
    if (!p.shape) return;
    setShapes((prev) => {
      const i = prev.findIndex((s) => s.id === p.shape.id);
      if (i === -1) return [...prev, p.shape];
      const next = [...prev];
      next[i] = p.shape;
      return next;
    });
    setGhosts((g) => { const n = { ...g }; delete n[p.shape.id]; return n; });
  }), [board.id, currentUser?.id]);

  useEffect(() => onRealtimeMessage("wbCursor", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id || p.userId === currentUser?.id) return;
    setPeers((prev) => ({ ...prev, [p.userId]: { ...p.data, at: Date.now() } }));
  }), [board.id, currentUser?.id]);

  useEffect(() => onRealtimeMessage("wbDrag", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id || p.userId === currentUser?.id) return;
    if (!p.data?.id) return;
    setGhosts((prev) => ({ ...prev, [p.data.id]: p.data }));
  }), [board.id, currentUser?.id]);

  useEffect(() => {
    const t = setInterval(() => {
      setPeers((prev) => {
        const now = Date.now();
        const next = {};
        for (const [k, v] of Object.entries(prev)) if (now - v.at < 8000) next[k] = v;
        return next;
      });
    }, 4000);
    return () => clearInterval(t);
  }, []);

  /* ---- отмена и возврат ----
     Стопка шагов, каждый со своим способом откатиться и повториться.
     Глубина не ограничена: «отменить до самого начала» — обычное
     ожидание от такого инструмента, а шаги весят единицы байт.

     Шаги хранят состояние фигуры, а не ссылку на неё: после отката
     создания и повторного создания у фигуры новый идентификатор, и
     последующие шаги должны знать, к чему теперь применяться. Для
     этого есть карта подстановки idMap. */
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const idMap = useRef(new Map());
  const [histVersion, setHistVersion] = useState(0);
  const bumpHistory = () => setHistVersion((v) => v + 1);

  const realId = useCallback((id) => {
    let cur = id;
    // Цепочка подстановок: фигуру могли пересоздать несколько раз.
    for (let i = 0; i < 20 && idMap.current.has(cur); i++) cur = idMap.current.get(cur);
    return cur;
  }, []);

  const pushHistory = (step) => {
    undoStack.current.push(step);
    redoStack.current = [];
    bumpHistory();
  };

  /* ---- координаты ---- */
  const toCanvas = useCallback((clientX, clientY) => {
    const r = wrapRef.current?.getBoundingClientRect();
    if (!r) return { x: 0, y: 0 };
    const v = view || { x: 0, y: 0, k: 1 };
    return { x: (clientX - r.left - v.x) / v.k, y: (clientY - r.top - v.y) / v.k };
  }, [view]);

  /* ---- операции с фигурами ---- */
  const createShape = async (kind, at, extra = {}, { history = true } = {}) => {
    const [w, h] = DEFAULT_SIZE[kind] || [160, 120];
    const payload = {
      kind, x: at.x, y: at.y, w, h, opacity: 1,
      data: { fill: color, stroke: color, text: "", strokeWidth: 2, fontSize: 13, ...extra },
    };
    const tempId = `temp-${Math.random().toString(36).slice(2)}`;
    setShapes((prev) => [...prev, { ...payload, id: tempId, boardId: board.id, z: prev.length, angle: 0 }]);
    try {
      const created = await api.createShape(board.id, payload);
      setShapes((prev) => prev.map((s) => (s.id === tempId ? created : s)));
      if (kind === "note" || kind === "text") setEditingText(created.id);
      setSelection([created.id]);
      if (history) {
        pushHistory({
          kind: "create", id: created.id, payload,
          undo: async (id) => { await api.deleteShape(board.id, id); },
          redo: async () => api.createShape(board.id, payload),
        });
      }
      return created;
    } catch (e) {
      setShapes((prev) => prev.filter((s) => s.id !== tempId));
      onError(e.message);
      return null;
    }
  };

  const patchShape = async (id, patch, { history = true, before = null, silent = false } = {}) => {
    const prevState = before || shapes.find((s) => s.id === id);
    setShapes((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
    try {
      await api.updateShape(board.id, realId(id), patch);
      if (history && prevState) {
        const old = {};
        for (const k of Object.keys(patch)) old[k] = prevState[k];
        pushHistory({
          kind: "patch", id,
          undo: async (rid) => { await api.updateShape(board.id, rid, old); },
          redo: async (rid) => { await api.updateShape(board.id, rid, patch); },
        });
      }
    } catch (e) {
      if (!silent) onError(e.message);
    }
  };

  const removeShape = async (id) => {
    const gone = shapes.find((s) => s.id === id);
    setShapes((prev) => prev.filter((s) => s.id !== id));
    setSelection((prev) => prev.filter((x) => x !== id));
    try {
      await api.deleteShape(board.id, realId(id));
      if (gone) {
        const payload = {
          kind: gone.kind, x: gone.x, y: gone.y, w: gone.w, h: gone.h,
          angle: gone.angle, opacity: gone.opacity, data: gone.data,
        };
        pushHistory({
          kind: "delete", id,
          undo: async () => api.createShape(board.id, payload),
          redo: async (rid) => { await api.deleteShape(board.id, rid); },
        });
      }
    } catch (e) { onError(e.message); }
  };

  // Откат и повтор. Созданная заново фигура получает новый
  // идентификатор — он запоминается в карте подстановки, чтобы
  // следующие шаги нашли её.
  const applyStep = async (step, direction) => {
    const rid = realId(step.id);
    const fn = direction === "undo" ? step.undo : step.redo;
    const res = await fn(rid);
    if (res?.id && res.id !== rid) idMap.current.set(rid, res.id);
    await load();
  };

  const undo = async () => {
    const step = undoStack.current.pop();
    if (!step) return;
    try { await applyStep(step, "undo"); redoStack.current.push(step); }
    catch (e) { onError(e.message); }
    bumpHistory();
  };

  const redo = async () => {
    const step = redoStack.current.pop();
    if (!step) return;
    try { await applyStep(step, "redo"); undoStack.current.push(step); }
    catch (e) { onError(e.message); }
    bumpHistory();
  };

  const reorder = async (id, move) => {
    try {
      await api.reorderShape(board.id, realId(id), move);
      await load();
      // Обратный шаг для порядка слоёв не хранится: «вернуть ровно на
      // тот же уровень» после чужих правок бессмысленно, а неточная
      // отмена хуже её отсутствия. Порядок правится одним нажатием.
      redoStack.current = [];
      bumpHistory();
    } catch (e) { onError(e.message); }
  };

  /* ---- мышь ---- */
  const drag = useRef(null);
  const [drawing, setDrawing] = useState(null);

  const onPointerDown = (e) => {
    if (e.button !== 0) return;
    const at = toCanvas(e.clientX, e.clientY);

    if (tool === "pan" || e.altKey) {
      drag.current = { mode: "pan", x: e.clientX, y: e.clientY, view: view || { x: 0, y: 0, k: 1 } };
      return;
    }
    if (tool === "select") {
      // Нажатие по пустому месту начинает рамку выделения. Прежнее
      // поведение — просто снять выделение — осталось: рамка нулевого
      // размера именно это и делает.
      if (!e.shiftKey) setSelection([]);
      setMarquee({ x0: at.x, y0: at.y, x1: at.x, y1: at.y, additive: e.shiftKey });
      return;
    }
    if (!canEdit || tool === "eraser") return;

    if (tool === "draw") { setDrawing({ points: [[at.x, at.y]] }); return; }
    if (tool === "line" || tool === "arrow") { setDrawing({ line: true, from: at, to: at }); return; }
    if (tool === "icon") { createShape("icon", at, { ...pickedIcon, fill: color }); return; }
    createShape(tool, at);
    // Инструмент НЕ сбрасывается: обычно ставят несколько фигур подряд,
    // и возврат к «выбрать» после каждой заставлял бы выбирать его
    // заново на каждую фигуру.
  };

  const onPointerMove = (e) => {
    realtimeSend({
      type: "wbCursor", boardId: board.id,
      payload: { ...toCanvas(e.clientX, e.clientY) },
    });

    const d = drag.current;
    if (d?.mode === "pan") {
      setView({ ...d.view, x: d.view.x + (e.clientX - d.x), y: d.view.y + (e.clientY - d.y) });
      return;
    }
    if (d?.mode === "move") {
      const at = toCanvas(e.clientX, e.clientY);
      setShapes((prev) => prev.map((s) => {
        const m = d.moving.find((x) => x.id === s.id);
        return m ? { ...s, x: at.x - m.dx, y: at.y - m.dy } : s;
      }));
      for (const m of d.moving) {
        realtimeSend({ type: "wbDrag", boardId: board.id,
          payload: { id: m.id, x: at.x - m.dx, y: at.y - m.dy, w: m.before.w, h: m.before.h } });
      }
      return;
    }
    if (d?.mode === "resize") {
      const at = toCanvas(e.clientX, e.clientY);
      const w = Math.max(20, at.x - d.x0);
      const h = Math.max(20, at.y - d.y0);
      setShapes((prev) => prev.map((s) => (s.id === d.id ? { ...s, w, h } : s)));
      realtimeSend({ type: "wbDrag", boardId: board.id, payload: { id: d.id, x: d.x0, y: d.y0, w, h } });
      return;
    }
    if (d?.mode === "rotate") {
      const at = toCanvas(e.clientX, e.clientY);
      const angle = Math.round(Math.atan2(at.y - d.cy, at.x - d.cx) * 180 / Math.PI + 90);
      setShapes((prev) => prev.map((s) => (s.id === d.id ? { ...s, angle } : s)));
      return;
    }
    if (d?.mode === "endpoint") {
      // Тянем конец линии: меняются и направление, и длина.
      const at = toCanvas(e.clientX, e.clientY);
      setShapes((prev) => prev.map((s) => {
        if (s.id !== d.id) return s;
        if (d.end === "to") return { ...s, data: { ...s.data, dx: at.x - s.x, dy: at.y - s.y } };
        const dx = (s.data.dx ?? s.w) + (s.x - at.x);
        const dy = (s.data.dy ?? 0) + (s.y - at.y);
        return { ...s, x: at.x, y: at.y, data: { ...s.data, dx, dy } };
      }));
      return;
    }
    if (marquee) {
      const at = toCanvas(e.clientX, e.clientY);
      setMarquee((m) => ({ ...m, x1: at.x, y1: at.y }));
      return;
    }
    if (drawing?.points) {
      const at = toCanvas(e.clientX, e.clientY);
      setDrawing((p) => ({ ...p, points: [...p.points, [at.x, at.y]] }));
      return;
    }
    if (drawing?.line) setDrawing((p) => ({ ...p, to: toCanvas(e.clientX, e.clientY) }));
  };

  const onPointerUp = async () => {
    const d = drag.current;
    drag.current = null;

    if (marquee) {
      const x0 = Math.min(marquee.x0, marquee.x1);
      const x1 = Math.max(marquee.x0, marquee.x1);
      const y0 = Math.min(marquee.y0, marquee.y1);
      const y1 = Math.max(marquee.y0, marquee.y1);
      setMarquee(null);
      // Попадает всё, что рамка задела: требовать полного накрытия
      // неудобно — длинную стрелку почти никогда не охватить целиком.
      const hit = shapes.filter((sh) => {
        const sx1 = sh.x + (sh.kind === "line" || sh.kind === "arrow" ? (sh.data?.dx ?? sh.w) : sh.w);
        const sy1 = sh.y + (sh.kind === "line" || sh.kind === "arrow" ? (sh.data?.dy ?? 0) : sh.h);
        const left = Math.min(sh.x, sx1);
        const right = Math.max(sh.x, sx1);
        const top = Math.min(sh.y, sy1);
        const bottom = Math.max(sh.y, sy1);
        return right >= x0 && left <= x1 && bottom >= y0 && top <= y1;
      }).flatMap((sh) => expandSelection(sh.id));
      if (hit.length > 0) {
        setSelection((prev) => (marquee.additive ? [...new Set([...prev, ...hit])] : [...new Set(hit)]));
      }
      return;
    }

    if (d?.mode === "move") {
      // В базу уходит итог по каждой сдвинутой фигуре.
      for (const m of d.moving) {
        const s = shapes.find((x) => x.id === m.id);
        if (s) patchShape(m.id, { x: s.x, y: s.y }, { before: m.before, silent: true });
      }
      return;
    }
    if (d?.mode === "resize" || d?.mode === "rotate" || d?.mode === "endpoint") {
      const s = shapes.find((x) => x.id === d.id);
      if (s) {
        const patch = d.mode === "rotate" ? { angle: s.angle }
          : d.mode === "endpoint" ? { x: s.x, y: s.y, data: s.data }
          : { x: s.x, y: s.y, w: s.w, h: s.h };
        patchShape(d.id, patch, { before: d.before, silent: true });
      }
      return;
    }

    if (drawing?.points && drawing.points.length > 1) {
      const xs = drawing.points.map((p) => p[0]);
      const ys = drawing.points.map((p) => p[1]);
      const minX = Math.min(...xs);
      const minY = Math.min(...ys);
      const created = await createShape("draw", { x: minX, y: minY }, {
        points: drawing.points.map(([x, y]) => [x - minX, y - minY]), stroke: color,
      });
      if (created) {
        await api.updateShape(board.id, created.id, {
          w: Math.max(1, Math.max(...xs) - minX), h: Math.max(1, Math.max(...ys) - minY),
        });
        load();
      }
      setDrawing(null);
      return;
    }
    if (drawing?.line) {
      const { from, to } = drawing;
      await createShape(tool === "arrow" ? "arrow" : "line", from, {
        dx: to.x - from.x, dy: to.y - from.y, stroke: color, curve: 0,
      });
      setDrawing(null);
      return;
    }
    setDrawing(null);
  };

  // Масштабирование сохраняет точку в середине окна: иначе при
  // изменении масштаба содержимое уезжает из вида, и его приходится
  // искать заново.
  const zoomTo = useCallback((k) => {
    setView((v) => {
      const cur = v || { x: 0, y: 0, k: 1 };
      const r = wrapRef.current?.getBoundingClientRect();
      const cx = (r?.width || 0) / 2;
      const cy = (r?.height || 0) / 2;
      // Точка холста под серединой окна до и после смены масштаба —
      // одна и та же.
      const px = (cx - cur.x) / cur.k;
      const py = (cy - cur.y) / cur.k;
      return { k, x: cx - px * k, y: cy - py * k };
    });
  }, []);

  const onWheel = (e) => {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    zoomTo(clampZoom((view?.k ?? 1) * (e.deltaY < 0 ? 1.1 : 0.9)));
  };

  const selectedShapes = shapes.filter((s) => selection.includes(s.id));
  const selectedShape = selectedShapes.length === 1 ? selectedShapes[0] : null;

  // Группа — общая пометка в свойствах фигур. Отдельной таблицы не
  // нужно: группировка это признак «двигаемся вместе», и хранить его
  // проще там же, где остальные свойства фигуры.
  const groupOf = (sh) => sh?.data?.group || null;

  // Нажатие на фигуру. С Shift — добавляем к выделению и убираем из
  // него, без Shift — выделяем только её (вместе с её группой).
  const pickShape = (id, additive) => {
    const ids = expandSelection(id);
    setSelection((prev) => {
      if (!additive) return ids;
      const has = ids.every((x) => prev.includes(x));
      return has ? prev.filter((x) => !ids.includes(x)) : [...new Set([...prev, ...ids])];
    });
  };

  // Группировка: всем выделенным ставится общая пометка. Потом они
  // выделяются и двигаются как одно целое, но остаются отдельными
  // фигурами — их по-прежнему можно оформить и разгруппировать.
  const groupSelected = async () => {
    if (selection.length < 2) return;
    const gid = `g-${Math.random().toString(36).slice(2, 10)}`;
    for (const sh of selectedShapes) {
      await patchShape(sh.id, { data: { ...sh.data, group: gid } }, { history: false });
    }
  };

  const ungroupSelected = async () => {
    for (const sh of selectedShapes) {
      if (!groupOf(sh)) continue;
      const data = { ...sh.data };
      delete data.group;
      await patchShape(sh.id, { data }, { history: false });
    }
  };

  // Копирование и вставка. Буфер свой, а не системный: в системный
  // попадает только текст, а нам нужны фигуры со всеми свойствами.
  // Вставленное смещается, иначе копия ложится точно на оригинал и
  // выглядит как «ничего не произошло».
  const copySelected = () => {
    if (selectedShapes.length === 0) return;
    clipboard.current = selectedShapes.map((sh) => ({
      kind: sh.kind, x: sh.x, y: sh.y, w: sh.w, h: sh.h,
      angle: sh.angle, opacity: sh.opacity, data: { ...sh.data },
    }));
  };

  const pasteClipboard = async () => {
    if (!canEdit || clipboard.current.length === 0) return;
    // Группа в копии — своя: иначе вставленные фигуры двигались бы
    // вместе с оригиналами.
    const remap = new Map();
    const created = [];
    for (const item of clipboard.current) {
      const data = { ...item.data };
      if (data.group) {
        if (!remap.has(data.group)) remap.set(data.group, `g-${Math.random().toString(36).slice(2, 10)}`);
        data.group = remap.get(data.group);
      }
      try {
        const sh = await api.createShape(board.id, { ...item, x: item.x + 24, y: item.y + 24, data });
        created.push(sh);
      } catch (e) { onError(e.message); return; }
    }
    setShapes((prev) => [...prev, ...created]);
    setSelection(created.map((c) => c.id));
    pushHistory({
      kind: "paste", id: created[0]?.id,
      undo: async () => {
        for (const c of created) await api.deleteShape(board.id, c.id).catch(() => {});
      },
      redo: async () => {
        for (const c of created) await api.createShape(board.id, c).catch(() => {});
      },
    });
  };

  const deleteSelected = async () => {
    for (const id of [...selection]) await removeShape(id);
    setSelection([]);
  };
  const expandSelection = (id) => {
    const sh = shapes.find((x) => x.id === id);
    const g = groupOf(sh);
    if (!g) return [id];
    return shapes.filter((x) => groupOf(x) === g).map((x) => x.id);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (editingText) return;
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo(); else undo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c") { e.preventDefault(); copySelected(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") { e.preventDefault(); pasteClipboard(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
        // Выделить всё — привычное сочетание; иначе для этого пришлось
        // бы обводить рамкой всю доску, а она бывает 8K.
        e.preventDefault();
        setSelection(shapes.map((x) => x.id));
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "g") {
        e.preventDefault();
        if (e.shiftKey) ungroupSelected(); else groupSelected();
        return;
      }
      const map = { v: "select", n: "note", r: "rect", o: "ellipse", t: "text",
        l: "line", a: "arrow", p: "draw", e: "eraser", h: "pan", i: "icon" };
      const k = e.key.toLowerCase();
      if (map[k]) setTool(map[k]);
      if ((e.key === "Delete" || e.key === "Backspace") && selection.length && canEdit) deleteSelected();
      if (e.key === "Escape") { setSelection([]); setTool("select"); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const ordered = useMemo(() => [...shapes].sort((a, b) => a.z - b.z), [shapes]);

  // До первого расчёта вида (сохранённого нет, окно ещё не измерено)
  // рисуем от нуля со 100%: иначе пришлось бы писать проверку на null
  // в каждом месте, где вид участвует в разметке.
  const vx = view?.x ?? 0;
  const vy = view?.y ?? 0;
  const vk = view?.k ?? 1;

  const copyLink = async () => {
    const url = `${window.location.origin}/whiteboards/${board.id}`;
    if (await copyText(url)) {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } else {
      onError("Не удалось скопировать. Ссылка на доску: " + url);
    }
  };

  // Свои значки нужны выгрузке картинкой: ссылка на /api в отдельном
  // файле не откроется, там нужен токен.
  const collectIconData = async () => {
    const ids = [...new Set(shapes.filter((s) => s.kind === "icon" && s.data?.iconId)
      .map((s) => s.data.iconId))];
    const out = {};
    for (const id of ids) {
      try {
        const blob = await api.fileBlob(api.boardIconUrl(id));
        out[id] = await new Promise((res) => {
          const r = new FileReader();
          r.onload = () => res(r.result);
          r.readAsDataURL(blob);
        });
      } catch { /* значок не забрался — выгрузим без него */ }
    }
    return out;
  };

  const doExport = async (kind) => {
    setExporting(true);
    try {
      const iconData = await collectIconData();
      const opts = {
        shapes, width: board.width, height: board.height,
        // Заливка обязательна: без неё PNG выходит прозрачным, а в
        // PDF — чёрным. Поэтому берётся цвет доски, а если он не
        // задан — белый, как у листа бумаги.
        bg: board.bgColor || "#FFFFFF",
        theme, iconData,
      };
      const name = board.title.replace(/[^\p{L}\p{N}\-_ ]/gu, "").trim() || "доска";
      if (kind === "png") await exportPng(opts, `${name}.png`);
      else await exportPdf(opts, `${name}.pdf`);
    } catch (e) {
      onError(e.message || "Не удалось выгрузить доску");
    } finally {
      setExporting(false);
    }
  };

  const btn = { background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` };

  return (
    <div>
      <div className="flex items-center gap-2 flex-wrap mb-2">
        <span style={{ color: theme.textMuted }} className="text-[11.5px]">
          {board.myRole === "owner" ? "Владелец" : board.myRole === "editor" ? "Редактор" : "Исполнитель"}
          {!canEdit && " · только просмотр"} · {board.width}×{board.height}
        </span>

        <div className="ml-auto flex items-center gap-1.5 flex-wrap">
          {canEdit && (
            <>
              <button onClick={undo} disabled={undoStack.current.length === 0} style={btn}
                className="px-2 py-1.5 rounded-lg disabled:opacity-40" title="Отменить (Ctrl+Z)">
                <Undo2 size={14} />
              </button>
              <button onClick={redo} disabled={redoStack.current.length === 0} style={btn}
                className="px-2 py-1.5 rounded-lg disabled:opacity-40" title="Вернуть (Ctrl+Shift+Z)">
                <Redo2 size={14} />
              </button>
            </>
          )}
          {/* Вернуть доску в поле зрения. Масштаб не трогаем: человек
              его подбирал, и сбрасывать заодно с положением — значит
              отменять чужую настройку ради своей. */}
          <button onClick={centerBoard} style={btn}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]"
            title="Показать доску целиком по центру, не меняя масштаб">
            <Crosshair size={13} /> По центру
          </button>
          <button onClick={() => setView({ ...centeredView(1), k: 1 })} style={btn}
            className="px-2 py-1.5 rounded-lg text-[12px]" title="Масштаб 100% и в центр">
            {Math.round(vk * 100)}%
          </button>
          <button onClick={() => zoomTo(prevZoom(vk))}
            style={{ color: theme.textMuted }} className="p-1.5" title="Уменьшить">
            <ZoomOut size={15} />
          </button>
          <button onClick={() => zoomTo(nextZoom(vk))}
            style={{ color: theme.textMuted }} className="p-1.5" title="Увеличить">
            <ZoomIn size={15} />
          </button>
          {/* Ходовые масштабы отдельными кнопками: 25% и 50% нужны,
              чтобы увидеть 4K или 8K полотно целиком, а щёлкать до них
              шагами по 10% — десяток нажатий. */}
          {ZOOM_STEPS.filter((z) => z <= 1).map((z) => (
            <button key={z} onClick={() => zoomTo(z)}
              style={{
                background: Math.abs(vk - z) < 0.01 ? theme.accent : theme.surfaceAlt,
                color: Math.abs(vk - z) < 0.01 ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-1.5 py-1 rounded-lg text-[11px]">{Math.round(z * 100)}%</button>
          ))}

          <button onClick={copyLink} style={btn}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]"
            title="Скопировать ссылку на доску">
            {linkCopied ? <Check size={13} /> : <LinkIcon size={13} />} {linkCopied ? "Скопировано" : "Ссылка"}
          </button>
          <button onClick={() => doExport("png")} disabled={exporting} style={btn}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px] disabled:opacity-50"
            title="Сохранить картинкой">
            <ImageIcon size={13} /> PNG
          </button>
          <button onClick={() => doExport("pdf")} disabled={exporting} style={btn}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px] disabled:opacity-50"
            title="Сохранить документом">
            <FileText size={13} /> PDF
          </button>

          {canEdit && (
            <>
              <button onClick={() => setInviteOpen(true)} style={btn}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]"
                title="Позвать участников: созвон, письмо, уведомление">
                <Video size={13} /> Собрать
              </button>
              <button onClick={() => setMembersOpen(true)} style={btn}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]">
                <UsersIcon size={13} /> Участники
              </button>
              <button onClick={() => setSettingsOpen(true)} style={{ color: theme.textMuted }}
                className="p-1.5" title="Свойства доски"><Pencil size={14} /></button>
              <button onClick={() => setConfirmClear(true)} style={{ color: theme.textMuted }}
                className="p-1.5" title="Очистить доску"><Eraser size={14} /></button>
            </>
          )}
          {isOwner && (
            <button onClick={() => setConfirmDelete(true)} style={{ color: theme.danger }}
              className="p-1.5" title="Удалить доску"><Trash2 size={14} /></button>
          )}
        </div>
      </div>

      {canEdit && (
        <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
          className="rounded-xl p-1.5 mb-2 flex items-center gap-1 flex-wrap">
          {TOOLS.map(([id, Icon, title]) => (
            <button key={id}
              onClick={() => { setTool(id); if (id === "icon") setIconsOpen(true); }}
              title={title}
              style={{
                background: tool === id ? theme.accent : "transparent",
                color: tool === id ? theme.accentText : theme.text,
              }}
              className="p-2 rounded-lg"><Icon size={15} /></button>
          ))}
          <span style={{ background: theme.border }} className="w-px h-6 mx-1" />
          {PALETTE.map(([c, name]) => (
            <button key={c} onClick={() => {
              setColor(c);
              for (const sh of selectedShapes) {
                patchShape(sh.id, { data: { ...sh.data, fill: c, stroke: c } });
              }
            }}
              style={{ background: c, outline: color === c ? `2px solid ${theme.text}` : "none",
                border: `1px solid ${theme.border}` }}
              className="w-5 h-5 rounded-full shrink-0" title={name} />
          ))}
        </div>
      )}

      {/* Свойства выбранной фигуры. Появляются только когда есть что
          настраивать: постоянная панель занимала бы место и на пустой
          доске показывала бы недоступные кнопки. */}
      {canEdit && selectedShapes.length > 0 && (
        <ShapeToolbar theme={theme} shape={selectedShape || selectedShapes[0]}
          count={selectedShapes.length}
          grouped={selectedShapes.some((sh) => groupOf(sh))}
          // Свойства применяются ко всему выделению: это и есть смысл
          // выделять несколько фигур. Толщина, прозрачность, цвет
          // текста — одинаково полезны и одной, и десяти.
          onPatch={(patch) => {
            for (const sh of selectedShapes) {
              const p = patch.data ? { ...patch, data: { ...sh.data, ...patch.data } } : patch;
              patchShape(sh.id, p);
            }
          }}
          onReorder={(move) => { for (const sh of selectedShapes) reorder(sh.id, move); }}
          onGroup={groupSelected} onUngroup={ungroupSelected}
          onCopy={copySelected} onPaste={pasteClipboard}
          onDelete={deleteSelected} />
      )}

      {loading ? (
        <Spinner theme={theme} label="Загружаем доску…" />
      ) : (
        <div ref={wrapRef}
          onMouseDown={onPointerDown} onMouseMove={onPointerMove} onMouseUp={onPointerUp}
          onWheel={onWheel}
          style={{
            background: theme.surfaceAlt, border: `1px solid ${theme.border}`,
            height: "calc(100vh - 300px)", minHeight: 420,
            cursor: tool === "pan" ? "grab" : tool === "select" ? "default" : "crosshair",
          }}
          className="rounded-2xl relative overflow-hidden select-none">

          <div style={{
            position: "absolute", left: 0, top: 0,
            width: board.width, height: board.height,
            transform: `translate(${vx}px, ${vy}px) scale(${vk})`,
            transformOrigin: "0 0",
            background: bg,
            boxShadow: "0 0 0 1px rgba(0,0,0,0.12)",
          }}>
            {/* Клетка — чтобы чувствовался масштаб и было к чему
                выравнивать на глаз. */}
            <div aria-hidden style={{
              position: "absolute", inset: 0,
              backgroundImage: `radial-gradient(${theme.border} 1px, transparent 1px)`,
              backgroundSize: "24px 24px",
              opacity: 0.55,
            }} />

            {ordered.map((s) => (
              <Shape key={s.id} theme={theme} shape={ghosts[s.id] ? { ...s, ...ghosts[s.id] } : s}
                selected={selection.includes(s.id)} canEdit={canEdit} tool={tool}
                editing={editingText === s.id}
                onSelect={(e) => {
                  if (tool === "eraser" && canEdit) { removeShape(s.id); return; }
                  pickShape(s.id, e?.shiftKey);
                }}
                onStartMove={(e, sh) => {
                  if (!canEdit || tool !== "select") return;
                  // С Shift идёт добор в выделение, а не перенос.
                  if (e.shiftKey) return;
                  const ids = selection.includes(sh.id) ? selection : expandSelection(sh.id);
                  if (!selection.includes(sh.id)) setSelection(ids);
                  const at = toCanvas(e.clientX, e.clientY);
                  // Двигаем всё выделенное разом: у каждой фигуры свой
                  // сдвиг относительно курсора, иначе они схлопнулись
                  // бы в одну точку.
                  const moving = shapes.filter((x) => ids.includes(x.id))
                    .map((x) => ({ id: x.id, dx: at.x - x.x, dy: at.y - x.y, before: x }));
                  drag.current = { mode: "move", id: sh.id, moving, before: sh, w: sh.w, h: sh.h,
                    dx: at.x - sh.x, dy: at.y - sh.y };
                }}
                onStartResize={(e, sh) => {
                  if (!canEdit) return;
                  drag.current = { mode: "resize", id: sh.id, x0: sh.x, y0: sh.y, before: sh };
                }}
                onStartRotate={(e, sh) => {
                  if (!canEdit) return;
                  drag.current = { mode: "rotate", id: sh.id, before: sh,
                    cx: sh.x + sh.w / 2, cy: sh.y + sh.h / 2 };
                }}
                onStartEndpoint={(e, sh, end) => {
                  if (!canEdit) return;
                  drag.current = { mode: "endpoint", id: sh.id, end, before: sh };
                }}
                onEditText={() => canEdit && setEditingText(s.id)}
                onText={(text) => { patchShape(s.id, { data: { ...s.data, text } }); }}
                onDoneText={() => setEditingText(null)} />
            ))}

            {marquee && (
              <div style={{
                position: "absolute",
                left: Math.min(marquee.x0, marquee.x1),
                top: Math.min(marquee.y0, marquee.y1),
                width: Math.abs(marquee.x1 - marquee.x0),
                height: Math.abs(marquee.y1 - marquee.y0),
                border: `1px dashed ${theme.accent}`,
                background: `${theme.accent}18`,
                pointerEvents: "none",
              }} />
            )}

            {drawing?.points && (
              <svg style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }}>
                <polyline fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
                  points={drawing.points.map(([x, y]) => `${x},${y}`).join(" ")} />
              </svg>
            )}
            {drawing?.line && (
              <svg style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }}>
                <line x1={drawing.from.x} y1={drawing.from.y} x2={drawing.to.x} y2={drawing.to.y}
                  stroke={color} strokeWidth="2.5" />
              </svg>
            )}

            {Object.entries(peers).map(([uid, p]) => {
              const u = resolveUser(directory, uid);
              return (
                <div key={uid} style={{ left: p.x, top: p.y, position: "absolute", pointerEvents: "none" }}>
                  <MousePointer2 size={16} style={{ color: u.avatarColor || theme.accent }} />
                  <span style={{
                    background: u.avatarColor || theme.accent, color: "#fff",
                    transform: `scale(${1 / vk})`, transformOrigin: "0 0",
                  }} className="text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap block mt-0.5">
                    {u.fullName}
                  </span>
                </div>
              );
            })}
          </div>

          {!canEdit && (
            <div style={{ background: theme.surface, color: theme.textMuted, border: `1px solid ${theme.border}` }}
              className="absolute bottom-3 left-3 px-2.5 py-1.5 rounded-lg text-[11.5px]">
              Доступ только на просмотр
            </div>
          )}
        </div>
      )}

      {iconsOpen && (
        <IconPicker theme={theme} onError={onError}
          onClose={() => setIconsOpen(false)}
          onPick={(pick) => { setPickedIcon(pick); setTool("icon"); setIconsOpen(false); }} />
      )}

      {inviteOpen && (
        <InviteMembers theme={theme} kind="whiteboard" object={board} directory={directory}
          currentUser={currentUser} onClose={() => setInviteOpen(false)} onError={onError} />
      )}

      {membersOpen && (
        <MembersModal theme={theme} directory={directory} team={team} currentUser={currentUser}
          members={board.members || []} isOwner={isOwner}
          title={`Участники доски «${board.title}»`}
          onClose={() => setMembersOpen(false)}
          onSave={async (list) => {
            try { await api.setWhiteboardMembers(board.id, list); setMembersOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {settingsOpen && (
        <BoardSettingsModal theme={theme} title="Свойства доски" board={board}
          onClose={() => setSettingsOpen(false)}
          onSave={async (form) => {
            try { await api.updateWhiteboard(board.id, form); setSettingsOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {confirmClear && (
        <ConfirmModal theme={theme} title="Очистить доску?"
          message="С доски исчезнет всё, у всех участников. Отменить это нельзя."
          confirmLabel="Очистить" onClose={() => setConfirmClear(false)}
          onConfirm={async () => {
            try { await api.clearWhiteboard(board.id); setShapes([]); setConfirmClear(false); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {confirmDelete && (
        <ConfirmModal theme={theme} title="Удалить доску?"
          message={`Доска «${board.title}» и всё её содержимое исчезнут у всех участников. Отменить это нельзя.`}
          confirmLabel="Удалить" onClose={() => setConfirmDelete(false)}
          onConfirm={async () => {
            try { await api.deleteWhiteboard(board.id); onDeleted(); }
            catch (e) { onError(e.message); }
          }} />
      )}
    </div>
  );
}

function ConfirmModal({ theme, title, message, confirmLabel, onClose, onConfirm }) {
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm">
      <ModalHeader theme={theme} title={title} onClose={onClose} />
      <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed mb-4">{message}</p>
      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={onConfirm} style={{ background: theme.danger, color: "#fff" }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold">{confirmLabel}</button>
      </div>
    </Modal>
  );
}

/* --------------------------------------------- свойства выбранной фигуры */

function ShapeToolbar({ theme, shape: s, count = 1, grouped, onPatch, onReorder,
  onGroup, onUngroup, onCopy, onPaste, onDelete }) {
  const d = s.data || {};
  const btn = { background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` };
  // Настройки текста и линий показываем по виду первой выбранной
  // фигуры: смешанное выделение всё равно правится одинаково, а
  // прятать всё, что не совпало, значит оставить пустую панель.
  const isLine = s.kind === "line" || s.kind === "arrow";
  const isText = ["note", "text", "rect", "ellipse", "diamond", "triangle", "frame"].includes(s.kind);

  return (
    <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
      className="rounded-xl p-1.5 mb-2 flex items-center gap-2 flex-wrap">

      {count > 1 && (
        <span style={{ color: theme.textMuted }} className="text-[11.5px] px-1">
          выбрано: {count}
        </span>
      )}

      <div className="flex items-center gap-1">
        <button onClick={onCopy} style={btn} className="p-1.5 rounded-lg"
          title="Копировать (Ctrl+C)"><Copy size={13} /></button>
        <button onClick={onPaste} style={btn} className="p-1.5 rounded-lg"
          title="Вставить (Ctrl+V)"><ClipboardPaste size={13} /></button>
        {count > 1 && (
          <button onClick={onGroup} style={btn} className="p-1.5 rounded-lg"
            title="Сгруппировать (Ctrl+G)"><Group size={13} /></button>
        )}
        {grouped && (
          <button onClick={onUngroup} style={btn} className="p-1.5 rounded-lg"
            title="Разгруппировать (Ctrl+Shift+G)"><Ungroup size={13} /></button>
        )}
      </div>
      <span style={{ background: theme.border }} className="w-px h-6" />

      {isText && (
        <>
          <select value={d.fontSize || 13}
            onChange={(e) => onPatch({ data: { ...d, fontSize: Number(e.target.value) } })}
            style={inputStyle(theme)} className="rounded-lg px-2 py-1 text-[12px] outline-none"
            title="Размер шрифта">
            {FONT_SIZES.map((n) => <option key={n} value={n}>{n} pt</option>)}
          </select>
          <button onClick={() => onPatch({ data: { ...d, bold: !d.bold } })}
            style={{ ...btn, background: d.bold ? theme.accent : theme.surfaceAlt,
              color: d.bold ? theme.accentText : theme.text }}
            className="p-1.5 rounded-lg" title="Полужирный"><Bold size={13} /></button>
          <button onClick={() => onPatch({ data: { ...d, italic: !d.italic } })}
            style={{ ...btn, background: d.italic ? theme.accent : theme.surfaceAlt,
              color: d.italic ? theme.accentText : theme.text }}
            className="p-1.5 rounded-lg" title="Курсив"><Italic size={13} /></button>
          {/* Цвет текста отдельно от заливки: тёмная надпись на тёмном
              стикере — самая частая жалоба на такие доски. */}
          <div className="flex items-center gap-1" title="Цвет текста">
            <Paintbrush size={13} style={{ color: theme.textMuted }} />
            {TEXT_COLORS.map(([c, name]) => (
              <button key={c} onClick={() => onPatch({ data: { ...d, color: c } })}
                title={name}
                style={{ background: c, border: `1px solid ${theme.border}`,
                  outline: d.color === c ? `2px solid ${theme.accent}` : "none" }}
                className="w-4 h-4 rounded-full" />
            ))}
          </div>
          <span style={{ background: theme.border }} className="w-px h-6" />
        </>
      )}

      {isLine && (
        <>
          <label className="flex items-center gap-1.5 text-[11.5px]" style={{ color: theme.textMuted }}>
            Прогиб
            <input type="range" min="-200" max="200" value={d.curve || 0}
              onChange={(e) => onPatch({ data: { ...d, curve: Number(e.target.value) } })}
              className="w-24" title="Выпуклость линии" />
          </label>
          <button onClick={() => onPatch({ data: { ...d, dx: -(d.dx ?? s.w), dy: -(d.dy ?? 0) },
            x: s.x + (d.dx ?? s.w), y: s.y + (d.dy ?? 0) })}
            style={btn} className="px-2 py-1.5 rounded-lg text-[11.5px]" title="Развернуть в другую сторону">
            Развернуть
          </button>
          <span style={{ background: theme.border }} className="w-px h-6" />
        </>
      )}

      <label className="flex items-center gap-1.5 text-[11.5px]" style={{ color: theme.textMuted }}>
        Толщина
        <input type="range" min="1" max="12" value={d.strokeWidth || 2}
          onChange={(e) => onPatch({ data: { ...d, strokeWidth: Number(e.target.value) } })}
          className="w-20" />
      </label>

      <label className="flex items-center gap-1.5 text-[11.5px]" style={{ color: theme.textMuted }}>
        Прозрачность
        <input type="range" min="10" max="100" value={Math.round((s.opacity ?? 1) * 100)}
          onChange={(e) => onPatch({ opacity: Number(e.target.value) / 100 })}
          className="w-20" />
      </label>

      <label className="flex items-center gap-1.5 text-[11.5px]" style={{ color: theme.textMuted }}
        title="Поворот. Тот же угол задаётся ручкой над фигурой.">
        <RotateCw size={13} />
        <input type="range" min="0" max="359" value={Math.round(s.angle || 0)}
          onChange={(e) => onPatch({ angle: Number(e.target.value) })} className="w-20" />
      </label>

      <span style={{ background: theme.border }} className="w-px h-6" />

      <div className="flex items-center gap-1">
        <button onClick={() => onReorder("front")} style={btn} className="p-1.5 rounded-lg"
          title="На самый верх"><ChevronsUp size={13} /></button>
        <button onClick={() => onReorder("forward")} style={btn} className="p-1.5 rounded-lg"
          title="На уровень выше"><ChevronUp size={13} /></button>
        <button onClick={() => onReorder("backward")} style={btn} className="p-1.5 rounded-lg"
          title="На уровень ниже"><ChevronDown size={13} /></button>
        <button onClick={() => onReorder("back")} style={btn} className="p-1.5 rounded-lg"
          title="В самый низ"><ChevronsDown size={13} /></button>
      </div>

      <button onClick={onDelete} style={{ color: theme.danger }} className="p-1.5 ml-auto"
        title="Удалить фигуру"><Trash2 size={14} /></button>
    </div>
  );
}

/* --------------------------------------------------------- выбор значка */

function IconPicker({ theme, onClose, onPick, onError }) {
  const [custom, setCustom] = useState([]);
  const [busy, setBusy] = useState({ done: 0, total: 0 });
  const [q, setQ] = useState("");
  const [onlyAnimated, setOnlyAnimated] = useState(false);
  const fileRef = useRef(null);
  const dirRef = useRef(null);

  const load = useCallback(async () => {
    try { setCustom(await api.boardIcons()); }
    catch { /* свои значки не загрузились — встроенные всё равно есть */ }
  }, []);
  useEffect(() => { load(); }, [load]);

  // Загрузка нескольких файлов сразу, в том числе папкой.
  //
  // По одному значку за раз набор из сотни файлов не залить, а именно
  // так их и скачивают — целыми наборами. Файлы идут последовательно, а
  // не все разом: сотня одновременных запросов упрётся в ограничение
  // частоты и половина отвалится.
  const uploadMany = async (files) => {
    const list = [...files].filter((f) => f.type.startsWith("image/"));
    if (list.length === 0) {
      onError("Значком может быть только изображение: SVG, PNG, APNG или GIF");
      return;
    }
    setBusy({ done: 0, total: list.length });
    let failed = 0;
    for (let i = 0; i < list.length; i++) {
      try {
        // Имя файла без расширения — готовая подпись значка.
        const title = list[i].name.replace(/\.[^.]+$/, "");
        await api.uploadBoardIcon(list[i], title);
      } catch {
        failed++;
      }
      setBusy({ done: i + 1, total: list.length });
    }
    setBusy({ done: 0, total: 0 });
    await load();
    if (failed > 0) onError(`Не удалось загрузить: ${failed} из ${list.length}`);
  };

  const needle = q.trim().toLowerCase();
  const matches = (title, id) =>
    !needle || title.toLowerCase().includes(needle) || id.toLowerCase().includes(needle);

  // Разделы после отбора. Пустые не показываем: иначе при поиске экран
  // занимают одни заголовки.
  const groups = useMemo(() => ICON_GROUPS
    .map((g) => ({
      title: g.title,
      icons: g.icons.filter(([id, title]) =>
        matches(title, id) && (!onlyAnimated || ANIMATED_ICONS.has(id))),
    }))
    .filter((g) => g.icons.length > 0), [needle, onlyAnimated]);

  const shownCustom = custom.filter((ic) => matches(ic.title || "", ic.title || ""));
  const found = groups.reduce((n, g) => n + g.icons.length, 0);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="wb-icons">
      <ModalHeader theme={theme} title="Значки"
        subtitle={`${ICON_COUNT} встроенных, из них ${ANIMATED_ICONS.size} анимированных`}
        onClose={onClose} />

      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <input value={q} onChange={(e) => setQ(e.target.value)} autoFocus
          placeholder="Поиск: маршрутизатор, сервер, документ…"
          style={inputStyle(theme)}
          className="flex-1 min-w-[200px] rounded-lg px-3 py-2 text-[13px] outline-none" />
        <button onClick={() => setOnlyAnimated((v) => !v)}
          style={{
            background: onlyAnimated ? theme.accent : theme.surfaceAlt,
            color: onlyAnimated ? theme.accentText : theme.text,
            border: `1px solid ${theme.border}`,
          }}
          className="px-2.5 py-2 rounded-lg text-[12px]"
          title="Показать только анимированные">Анимированные</button>
      </div>

      <div className="max-h-[52vh] overflow-y-auto pr-1">
        {needle && found === 0 && shownCustom.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-4">
            Ничего не найдено. Попробуйте другое слово — или загрузите свой значок.
          </p>
        )}

        {groups.map((g) => (
          <div key={g.title} className="mb-3">
            <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1.5">
              {g.title} · {g.icons.length}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {g.icons.map(([id, title]) => (
                <button key={id} onClick={() => onPick({ icon: id })} title={title}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="w-14 h-14 rounded-xl flex items-center justify-center relative">
                  <svg viewBox="0 0 64 64" width="34" height="34"
                    dangerouslySetInnerHTML={{ __html: iconBody(id) }} />
                  {/* Анимированные помечены точкой: на схеме для печати
                      анимация не нужна, и выбор должен быть осознанным. */}
                  {ANIMATED_ICONS.has(id) && (
                    <span style={{ background: theme.accent }}
                      className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full" />
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="mb-2">
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1.5">
            Свои значки{custom.length ? ` · ${custom.length}` : ""}
          </div>
          {custom.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[12px] mb-2 leading-relaxed">
              Пока пусто. Загрузите свои наборы — целой папкой: SVG, PNG, APNG и GIF,
              анимация в них сохраняется. Значки появятся у всех и будут доступны на
              любой доске.
            </p>
          )}
          <div className="flex flex-wrap gap-1.5">
            {shownCustom.map((ic) => (
              <div key={ic.id} className="relative group">
                <button onClick={() => onPick({ iconId: ic.id })} title={ic.title}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="w-14 h-14 rounded-xl flex items-center justify-center overflow-hidden">
                  <CustomIcon id={ic.id} size={36} />
                </button>
                {ic.canDelete && (
                  <button onClick={async () => {
                    try { await api.deleteBoardIcon(ic.id); load(); }
                    catch (e) { onError(e.message); }
                  }}
                    style={{ background: theme.danger, color: "#fff" }}
                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-[9px] opacity-0 group-hover:opacity-100"
                    title="Убрать из набора">×</button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* multiple и webkitdirectory: можно выбрать и отдельные файлы, и
          папку целиком — наборы значков скачивают именно папками. */}
      <input ref={fileRef} type="file" accept="image/*" multiple className="hidden"
        onChange={(e) => { uploadMany(e.target.files || []); e.target.value = ""; }} />
      <input ref={dirRef} type="file" accept="image/*" multiple className="hidden"
        webkitdirectory="" directory=""
        onChange={(e) => { uploadMany(e.target.files || []); e.target.value = ""; }} />

      <div className="flex gap-2 mt-3 flex-wrap">
        <button onClick={() => fileRef.current?.click()} disabled={busy.total > 0}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center justify-center gap-1.5 flex-1 rounded-lg py-2.5 text-[13px] font-medium disabled:opacity-50">
          <Upload size={14} />
          {busy.total > 0 ? `Загружаем ${busy.done} из ${busy.total}…` : "Загрузить значки"}
        </button>
        <button onClick={() => dirRef.current?.click()} disabled={busy.total > 0}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center justify-center gap-1.5 flex-1 rounded-lg py-2.5 text-[13px] font-medium disabled:opacity-50">
          <Upload size={14} /> Загрузить папку
        </button>
        <button onClick={onClose}
          style={{ background: theme.accent, color: theme.accentText }}
          className="rounded-lg px-4 py-2.5 text-[13px] font-semibold">Готово</button>
      </div>
    </Modal>
  );
}

// Свой значок: файл закрыт токеном, поэтому забираем его запросом и
// показываем через blob-ссылку — как остальные вложения.
const iconCache = new Map();
function CustomIcon({ id, size = 32 }) {
  const [url, setUrl] = useState(() => iconCache.get(id) || null);
  useEffect(() => {
    if (iconCache.has(id)) { setUrl(iconCache.get(id)); return undefined; }
    let dead = false;
    api.fileBlob(api.boardIconUrl(id)).then((blob) => {
      if (dead) return;
      const made = URL.createObjectURL(blob);
      iconCache.set(id, made);
      setUrl(made);
    }).catch(() => {});
    return () => { dead = true; };
  }, [id]);
  if (!url) return <span style={{ width: size, height: size }} className="block animate-pulse" />;
  return <img src={url} alt="" width={size} height={size} style={{ objectFit: "contain" }} />;
}

/* ------------------------------------------------------------- фигура */

function Shape({ theme, shape: s, selected, canEdit, tool, editing, onSelect, onStartMove,
  onStartResize, onStartRotate, onStartEndpoint, onEditText, onText, onDoneText }) {
  const d = s.data || {};
  const fill = d.fill || theme.accent;
  const stroke = d.stroke || fill;
  const sw = d.strokeWidth || 2;

  const common = {
    onMouseDown: (e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); },
    style: {
      position: "absolute", left: s.x, top: s.y, width: s.w, height: s.h,
      transform: s.angle ? `rotate(${s.angle}deg)` : undefined,
      opacity: s.opacity ?? 1,
      outline: selected ? `2px solid ${theme.accent}` : "none",
      cursor: canEdit && tool === "select" ? "move" : "default",
    },
  };

  const textStyle = (fallback) => ({
    color: d.color || fallback,
    fontSize: d.fontSize || 13,
    fontWeight: d.bold ? 700 : 400,
    fontStyle: d.italic ? "italic" : "normal",
  });

  const textBox = (fallback) => (
    editing ? (
      <textarea autoFocus defaultValue={d.text || ""}
        onBlur={(e) => { onText(e.target.value); onDoneText(); }}
        onMouseDown={(e) => e.stopPropagation()}
        style={{ ...textStyle(fallback), background: "transparent", border: "none", outline: "none", resize: "none" }}
        className="w-full h-full p-2" />
    ) : (
      <div onDoubleClick={onEditText}
        style={{ ...textStyle(fallback), whiteSpace: "pre-wrap", overflow: "hidden" }}
        className="w-full h-full p-2 leading-snug">
        {d.text || ""}
      </div>
    )
  );

  // Ручки: изменение размера — в правом нижнем углу, поворот — над
  // фигурой. Так они не спорят друг с другом и повторяют привычные
  // редакторы.
  const handles = selected && canEdit ? (
    <>
      <div onMouseDown={(e) => { e.stopPropagation(); onStartResize(e, s); }}
        style={{ background: theme.accent, right: -5, bottom: -5, position: "absolute" }}
        className="w-2.5 h-2.5 rounded-sm cursor-nwse-resize" title="Размер" />
      <div onMouseDown={(e) => { e.stopPropagation(); onStartRotate(e, s); }}
        style={{ background: theme.accent, left: "50%", top: -22, marginLeft: -6, position: "absolute" }}
        className="w-3 h-3 rounded-full cursor-grab" title="Повернуть" />
    </>
  ) : null;

  switch (s.kind) {
    case "note":
      return (
        <div {...common}>
          <div style={{ background: fill, boxShadow: "0 1px 4px rgba(0,0,0,0.2)" }}
            className="w-full h-full rounded-sm">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "text":
      return <div {...common}>{textBox(theme.text)}{handles}</div>;
    case "rect":
    case "frame":
      return (
        <div {...common}>
          <div style={{
            background: s.kind === "frame" ? "transparent" : fill,
            border: `${sw}px ${s.kind === "frame" ? "dashed" : "solid"} ${stroke}`,
          }} className="w-full h-full rounded-md">
            {textBox(s.kind === "frame" ? theme.text : "#1b1b1b")}
          </div>
          {handles}
        </div>
      );
    case "ellipse":
      return (
        <div {...common}>
          <div style={{ background: fill, border: `${sw}px solid ${stroke}`, borderRadius: "50%" }}
            className="w-full h-full flex items-center justify-center">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "diamond":
    case "triangle":
      return (
        <div {...common}>
          <div style={{
            background: fill,
            clipPath: s.kind === "diamond"
              ? "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)"
              : "polygon(50% 0%, 100% 100%, 0% 100%)",
          }} className="w-full h-full flex items-center justify-center">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "icon": {
      const body = d.iconId ? null : iconBody(d.icon);
      return (
        <div {...common} title={d.icon ? ICON_TITLES[d.icon] : undefined}>
          {d.iconId ? (
            <CustomIcon id={d.iconId} size={Math.min(s.w, s.h)} />
          ) : hasIcon(d.icon) ? (
            <svg viewBox="0 0 64 64" width={s.w} height={s.h} style={{ color: fill }}
              dangerouslySetInnerHTML={{ __html: body }} />
          ) : (
            <div style={{ color: theme.textMuted }} className="text-[11px]">значок недоступен</div>
          )}
          {handles}
        </div>
      );
    }
    case "line":
    case "arrow": {
      const dx = d.dx ?? s.w;
      const dy = d.dy ?? 0;
      const pad = 12;
      const minX = Math.min(0, dx) - pad;
      const minY = Math.min(0, dy) - pad;
      const w = Math.abs(dx) + pad * 2;
      const h = Math.abs(dy) + pad * 2;
      // Путь считается той же функцией, что и при выгрузке: иначе
      // сохранённая картинка отличалась бы от экрана.
      const path = linePath({ ...s, x: 0, y: 0, data: d, w: s.w });
      return (
        <div onMouseDown={(e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); }}
          style={{ position: "absolute", left: s.x + minX, top: s.y + minY,
            opacity: s.opacity ?? 1, cursor: canEdit ? "move" : "default" }}>
          <svg width={w} height={h} viewBox={`${minX} ${minY} ${w} ${h}`} style={{ overflow: "visible" }}>
            <defs>
              <marker id={`ah-${s.id}`} markerWidth="9" markerHeight="9" refX="7" refY="3"
                orient="auto" markerUnits="strokeWidth">
                <path d="M0,0 L0,6 L8,3 z" fill={stroke} />
              </marker>
            </defs>
            <path d={path} fill="none" stroke={stroke} strokeWidth={selected ? sw + 1 : sw}
              strokeLinecap="round" markerEnd={s.kind === "arrow" ? `url(#ah-${s.id})` : undefined} />
          </svg>
          {/* Концы линии тянутся по отдельности: так меняются и длина,
              и направление, без окна свойств. */}
          {selected && canEdit && (
            <>
              <div onMouseDown={(e) => { e.stopPropagation(); onStartEndpoint(e, s, "from"); }}
                style={{ background: theme.accent, position: "absolute",
                  left: -minX - 4, top: -minY - 4 }}
                className="w-2 h-2 rounded-full cursor-crosshair" title="Начало" />
              <div onMouseDown={(e) => { e.stopPropagation(); onStartEndpoint(e, s, "to"); }}
                style={{ background: theme.accent, position: "absolute",
                  left: (dx - minX) - 4, top: (dy - minY) - 4 }}
                className="w-2 h-2 rounded-full cursor-crosshair" title="Конец" />
            </>
          )}
        </div>
      );
    }
    case "draw": {
      const pts = d.points || [];
      return (
        <div onMouseDown={(e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); }}
          style={{ position: "absolute", left: s.x, top: s.y, opacity: s.opacity ?? 1,
            transform: s.angle ? `rotate(${s.angle}deg)` : undefined,
            cursor: canEdit ? "move" : "default" }}>
          <svg style={{ overflow: "visible" }} width={Math.max(1, s.w)} height={Math.max(1, s.h)}>
            <polyline fill="none" stroke={stroke} strokeWidth={selected ? sw + 1 : sw}
              strokeLinecap="round" strokeLinejoin="round"
              points={pts.map(([x, y]) => `${x},${y}`).join(" ")} />
          </svg>
          {handles}
        </div>
      );
    }
    default:
      return null;
  }
}
