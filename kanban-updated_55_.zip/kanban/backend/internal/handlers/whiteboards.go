package handlers

import (
	"encoding/json"
	"errors"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/realtime"
)

// =====================================================================
// Совместные доски — бесконечный холст, который несколько человек
// правят одновременно.
//
// Про одновременность. Каждая фигура — отдельная строка, и события по
// WebSocket идут по одной фигуре. Это важно: если бы состояние доски
// хранилось единым документом, два человека, двигающие соседние
// стикеры, постоянно затирали бы работу друг друга. Пофигурная запись
// оставляет конфликт только там, где он настоящий — двое тянут ОДИН
// стикер, — и разрешает его «последний выиграл», что для доски
// естественно: люди видят курсоры друг друга и так не делают.
//
// Промежуточные кадры перетаскивания через базу не гоняются: клиент
// шлёт их по WebSocket как эфемерное событие, а в базу уходит только
// итог. Иначе одно перетаскивание стикера — это сотня UPDATE.
// =====================================================================

type whiteboard struct {
	ID        uuid.UUID     `json:"id"`
	Title     string        `json:"title"`
	Position  int           `json:"position"`
	Archived  bool          `json:"archived"`
	CreatedBy uuid.UUID     `json:"createdBy"`
	MyRole    string        `json:"myRole"`
	// Размер полотна одинаков у всех участников и задаётся в точках
	// холста, а не в пикселях экрана: иначе доска, собранная на
	// большом мониторе, на ноутбуке выглядела бы иначе.
	Width   int    `json:"width"`
	Height  int    `json:"height"`
	BgColor string `json:"bgColor"`
	// Состав приходит и в списке: окно «Участники» открывается из
	// списка, и без него оно показывало пустой состав.
	Members []chartMember `json:"members"`
}

type wbShape struct {
	ID        uuid.UUID       `json:"id"`
	BoardID   uuid.UUID       `json:"boardId"`
	Kind      string          `json:"kind"`
	X         float64         `json:"x"`
	Y         float64         `json:"y"`
	W         float64         `json:"w"`
	H         float64         `json:"h"`
	Angle     float64         `json:"angle"`
	Z         int             `json:"z"`
	Opacity   float64         `json:"opacity"`
	Data      json.RawMessage `json:"data"`
	CreatedBy uuid.UUID       `json:"createdBy"`
	UpdatedBy *uuid.UUID      `json:"updatedBy"`
}

const wbCols = `w.id, w.title, w.position, w.archived, w.created_by,
	       COALESCE(app.wb_role(w.id, $1), ''), w.width, w.height, w.bg_color`

const wbShapeCols = `s.id, s.board_id, s.kind, s.x, s.y, s.w, s.h, s.angle, s.z,
	       s.opacity, s.data, s.created_by, s.updated_by`

func scanWhiteboard(row pgx.Row) (whiteboard, error) {
	var b whiteboard
	err := row.Scan(&b.ID, &b.Title, &b.Position, &b.Archived, &b.CreatedBy, &b.MyRole,
		&b.Width, &b.Height, &b.BgColor)
	b.Members = []chartMember{}
	return b, err
}

func scanShape(row pgx.Row) (wbShape, error) {
	var sh wbShape
	err := row.Scan(&sh.ID, &sh.BoardID, &sh.Kind, &sh.X, &sh.Y, &sh.W, &sh.H,
		&sh.Angle, &sh.Z, &sh.Opacity, &sh.Data, &sh.CreatedBy, &sh.UpdatedBy)
	return sh, err
}

func (s *Server) ListWhiteboards(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []whiteboard{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT `+wbCols+` FROM app.whiteboards w ORDER BY w.position, w.title`, uid)
		if e != nil {
			return e
		}
		byID := map[uuid.UUID]int{}
		for rows.Next() {
			b, e := scanWhiteboard(rows)
			if e != nil {
				rows.Close()
				return e
			}
			byID[b.ID] = len(out)
			out = append(out, b)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}
		if len(out) == 0 {
			return nil
		}
		mrows, e := tx.Query(c.Context(),
			`SELECT board_id, user_id, role::text FROM app.whiteboard_members`)
		if e != nil {
			return e
		}
		defer mrows.Close()
		for mrows.Next() {
			var boardID uuid.UUID
			var m chartMember
			if e := mrows.Scan(&boardID, &m.UserID, &m.Role); e != nil {
				return e
			}
			if i, ok := byID[boardID]; ok {
				out[i].Members = append(out[i].Members, m)
			}
		}
		return mrows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type whiteboardInput struct {
	Title   string  `json:"title"`
	Width   *int    `json:"width"`
	Height  *int    `json:"height"`
	BgColor *string `json:"bgColor"`
}

func (s *Server) CreateWhiteboard(c *fiber.Ctx) error {
	var in whiteboardInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Укажите название доски"))
	}
	uid := s.uid(c)
	var b whiteboard
	// Идентификатор задаётся здесь, вставка без RETURNING: при
	// RETURNING новая строка проверяется ещё и политикой SELECT, а
	// владельца в app.whiteboard_members добавляет триггер AFTER
	// INSERT — то есть уже после этой проверки. Подробности в
	// CreateChart и CreateBoard.
	boardID := uuid.New()
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.whiteboards (id, title, created_by, position, width, height, bg_color)
			VALUES ($3, $2, $1, COALESCE((SELECT max(position) + 1 FROM app.whiteboards), 0),
			        COALESCE($4, 3840), COALESCE($5, 2160), COALESCE($6, ''))`,
			uid, in.Title, boardID, in.Width, in.Height, in.BgColor); e != nil {
			return e
		}
		var e error
		b, e = scanWhiteboard(tx.QueryRow(c.Context(),
			`SELECT `+wbCols+` FROM app.whiteboards w WHERE w.id = $2`, uid, boardID))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusCreated, b)
}

func (s *Server) GetWhiteboard(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var b whiteboard
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var e error
		b, e = scanWhiteboard(tx.QueryRow(c.Context(),
			`SELECT `+wbCols+` FROM app.whiteboards w WHERE w.id = $2`, uid, boardID))
		if e != nil {
			return e
		}
		if b.MyRole == "" {
			return httpx.Err(fiber.StatusForbidden, "not_member", "Вы не допущены к этой доске")
		}
		rows, e := tx.Query(c.Context(),
			`SELECT user_id, role::text FROM app.whiteboard_members WHERE board_id = $1`, boardID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var m chartMember
			if e := rows.Scan(&m.UserID, &m.Role); e != nil {
				return e
			}
			b.Members = append(b.Members, m)
		}
		return rows.Err()
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, b)
}

func (s *Server) UpdateWhiteboard(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in whiteboardInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var b whiteboard
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `
			UPDATE app.whiteboards
			   SET title    = COALESCE(NULLIF($2, ''), title),
			       width    = COALESCE($3, width),
			       height   = COALESCE($4, height),
			       -- Пустая строка — это осмысленное значение «фон как
			       -- у приложения», поэтому цвет передаётся указателем:
			       -- отсутствие поля и пустой цвет — разные вещи.
			       bg_color = COALESCE($5, bg_color),
			       updated_at = now()
			 WHERE id = $1`, boardID, in.Title, in.Width, in.Height, in.BgColor)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		b, e = scanWhiteboard(tx.QueryRow(c.Context(),
			`SELECT `+wbCols+` FROM app.whiteboards w WHERE w.id = $2`, uid, boardID))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishWB(b, "updated")
	return httpx.JSON(c, fiber.StatusOK, b)
}

func (s *Server) DeleteWhiteboard(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	watchers := s.wbWatchers(boardID)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `DELETE FROM app.whiteboards WHERE id = $1`, boardID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.hub.SendTo(watchers, realtime.Event{
		Type: "whiteboard", Action: "deleted", Payload: fiber.Map{"id": boardID},
	})
	return httpx.NoContent(c)
}

func (s *Server) SetWhiteboardMembers(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in []memberInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var before, after []uuid.UUID
	var title string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var role string
		if e := tx.QueryRow(c.Context(),
			`SELECT COALESCE(app.wb_role($1, $2), '')`, boardID, uid).Scan(&role); e != nil {
			return e
		}
		if role != "owner" && role != "editor" {
			return httpx.ErrForbidden
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT title FROM app.whiteboards WHERE id = $1`, boardID).Scan(&title); e != nil {
			return e
		}
		rows, e := tx.Query(c.Context(),
			`SELECT user_id FROM app.whiteboard_members WHERE board_id = $1 AND role <> 'owner'`, boardID)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				rows.Close()
				return e
			}
			before = append(before, id)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`DELETE FROM app.whiteboard_members WHERE board_id = $1 AND role <> 'owner'`, boardID); e != nil {
			return e
		}
		for _, m := range in {
			if m.Role != "editor" && m.Role != "reader" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.whiteboard_members (board_id, user_id, role)
				VALUES ($1, $2, $3::app.board_role)
				ON CONFLICT (board_id, user_id) DO UPDATE SET role = EXCLUDED.role`,
				boardID, m.UserID, m.Role); e != nil {
				return e
			}
			after = append(after, m.UserID)
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.announceMembership(membershipChange{
		kind: "whiteboard", id: boardID, title: title,
		before: before, after: after, actor: uid,
	})
	return s.GetWhiteboard(c)
}

// ── фигуры ──────────────────────────────────────────────────────────

func (s *Server) ListShapes(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	out := []wbShape{}
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT `+wbShapeCols+` FROM app.whiteboard_shapes s
			  WHERE s.board_id = $1 ORDER BY s.z, s.created_at`, boardID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			sh, e := scanShape(rows)
			if e != nil {
				return e
			}
			out = append(out, sh)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type shapeInput struct {
	Kind    string          `json:"kind"`
	X       *float64        `json:"x"`
	Y       *float64        `json:"y"`
	W       *float64        `json:"w"`
	H       *float64        `json:"h"`
	Angle   *float64        `json:"angle"`
	Z       *int            `json:"z"`
	Opacity *float64        `json:"opacity"`
	Data    json.RawMessage `json:"data"`
}

func (s *Server) CreateShape(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in shapeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Kind == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Не указан вид фигуры"))
	}
	uid := s.uid(c)
	var sh wbShape
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var e error
		sh, e = scanShape(tx.QueryRow(c.Context(), `
			INSERT INTO app.whiteboard_shapes
			       (board_id, kind, x, y, w, h, angle, z, opacity, data, created_by, updated_by)
			VALUES ($1, $2, COALESCE($3, 0), COALESCE($4, 0), COALESCE($5, 160),
			        COALESCE($6, 120), COALESCE($7, 0),
			        COALESCE($8, (SELECT COALESCE(max(z) + 1, 0)
			                        FROM app.whiteboard_shapes WHERE board_id = $1)),
			        COALESCE($9, 1),
			        COALESCE($10::jsonb, '{}'::jsonb), $11, $11)
			RETURNING `+wbShapeReturning,
			boardID, in.Kind, in.X, in.Y, in.W, in.H, in.Angle, in.Z, in.Opacity,
			jsonOrNil(in.Data), uid))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishShape(boardID, sh, "created", uid)
	return httpx.JSON(c, fiber.StatusCreated, sh)
}

// wbShapeReturning — тот же набор колонок, что wbShapeCols, но без
// префикса таблицы: в RETURNING псевдонима «s» не существует.
const wbShapeReturning = `id, board_id, kind, x, y, w, h, angle, z, opacity, data, created_by, updated_by`

func (s *Server) UpdateShape(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	shapeID, err := param(c, "shapeID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in shapeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var sh wbShape
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var e error
		sh, e = scanShape(tx.QueryRow(c.Context(), `
			UPDATE app.whiteboard_shapes
			   SET x = COALESCE($3, x), y = COALESCE($4, y),
			       w = COALESCE($5, w), h = COALESCE($6, h),
			       angle = COALESCE($7, angle), z = COALESCE($8, z),
			       opacity = COALESCE($11, opacity),
			       -- data приходит целиком: свойства фигуры меняются
			       -- набором (цвет и текст стикера правятся вместе), а
			       -- слияние по ключам пришлось бы поддерживать на
			       -- каждый новый вид фигуры.
			       data = COALESCE($9::jsonb, data),
			       updated_by = $10, updated_at = now()
			 WHERE id = $1 AND board_id = $2
			 RETURNING `+wbShapeReturning,
			shapeID, boardID, in.X, in.Y, in.W, in.H, in.Angle, in.Z,
			jsonOrNil(in.Data), uid, in.Opacity))
		return e
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishShape(boardID, sh, "updated", uid)
	return httpx.JSON(c, fiber.StatusOK, sh)
}

func (s *Server) DeleteShape(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	shapeID, err := param(c, "shapeID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.whiteboard_shapes WHERE id = $1 AND board_id = $2`, shapeID, boardID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.hub.SendTo(s.wbWatchers(boardID), realtime.Event{
		Type: "shape", Action: "deleted",
		Payload: fiber.Map{"id": shapeID, "boardId": boardID, "by": uid},
	})
	return httpx.NoContent(c)
}

// ClearWhiteboard убирает с доски всё. Отдельный маршрут, а не удаление
// фигур по одной: очистка доски на сотню фигур иначе превращается в
// сотню запросов и столько же событий.
func (s *Server) ClearWhiteboard(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canEdit bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_edit_wb($1, $2)`, boardID, uid).Scan(&canEdit); e != nil {
			return e
		}
		if !canEdit {
			return httpx.ErrForbidden
		}
		_, e := tx.Exec(c.Context(),
			`DELETE FROM app.whiteboard_shapes WHERE board_id = $1`, boardID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.hub.SendTo(s.wbWatchers(boardID), realtime.Event{
		Type: "shape", Action: "cleared", Payload: fiber.Map{"boardId": boardID, "by": uid},
	})
	return httpx.NoContent(c)
}

// ── события ─────────────────────────────────────────────────────────

func (s *Server) wbWatchers(boardID uuid.UUID) []uuid.UUID {
	ctx, cancel := bgContext()
	defer cancel()
	var ids []uuid.UUID
	_ = s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.wb_watchers($1)`, boardID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	return ids
}

func (s *Server) publishWB(b whiteboard, action string) {
	s.hub.SendTo(s.wbWatchers(b.ID), realtime.Event{
		Type: "whiteboard", Action: action, Payload: b,
	})
}

// publishShape рассылает изменение одной фигуры. Автор изменения
// указан в payload: его собственный клиент уже нарисовал правку у себя
// и по этому признаку пропускает эхо, не перерисовывая фигуру под
// курсором, который её тянет.
func (s *Server) publishShape(boardID uuid.UUID, sh wbShape, action string, by uuid.UUID) {
	s.hub.SendTo(s.wbWatchers(boardID), realtime.Event{
		Type: "shape", Action: action,
		Payload: fiber.Map{"shape": sh, "boardId": boardID, "by": by},
	})
}

// ── порядок слоёв ───────────────────────────────────────────────────

type orderInput struct {
	// front | back | forward | backward
	Move string `json:"move"`
}

// ReorderShape переносит фигуру по слоям.
//
// Считается на сервере, а не клиентом: «на самый верх» — это max(z)+1
// по всей доске, и вычисленный из устаревшего у клиента списка он
// уехал бы под фигуру, которую только что положил другой участник.
func (s *Server) ReorderShape(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	shapeID, err := param(c, "shapeID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in orderInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var sql string
	switch in.Move {
	case "front":
		sql = `UPDATE app.whiteboard_shapes SET z = COALESCE(
		           (SELECT max(z) + 1 FROM app.whiteboard_shapes WHERE board_id = $2), 0),
		           updated_by = $3, updated_at = now()
		        WHERE id = $1 AND board_id = $2`
	case "back":
		sql = `UPDATE app.whiteboard_shapes SET z = COALESCE(
		           (SELECT min(z) - 1 FROM app.whiteboard_shapes WHERE board_id = $2), 0),
		           updated_by = $3, updated_at = now()
		        WHERE id = $1 AND board_id = $2`
	case "forward":
		// Меняемся местами с ближайшей фигурой выше: сдвиг на единицу
		// ничего не дал бы, если соседний уровень занят.
		sql = `UPDATE app.whiteboard_shapes SET z = COALESCE((
		           SELECT min(z) + 1 FROM app.whiteboard_shapes
		            WHERE board_id = $2 AND z > (SELECT z FROM app.whiteboard_shapes WHERE id = $1)
		       ), z), updated_by = $3, updated_at = now()
		        WHERE id = $1 AND board_id = $2`
	case "backward":
		sql = `UPDATE app.whiteboard_shapes SET z = COALESCE((
		           SELECT max(z) - 1 FROM app.whiteboard_shapes
		            WHERE board_id = $2 AND z < (SELECT z FROM app.whiteboard_shapes WHERE id = $1)
		       ), z), updated_by = $3, updated_at = now()
		        WHERE id = $1 AND board_id = $2`
	default:
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_move", "Неизвестное перемещение по слоям"))
	}

	var sh wbShape
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), sql, shapeID, boardID, uid)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		sh, e = scanShape(tx.QueryRow(c.Context(),
			`SELECT `+wbShapeCols+` FROM app.whiteboard_shapes s WHERE s.id = $1`, shapeID))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishShape(boardID, sh, "updated", uid)
	return httpx.JSON(c, fiber.StatusOK, sh)
}

// ── свои значки ─────────────────────────────────────────────────────
//
// Встроенный набор (сетевое оборудование, рабочие места, серверы)
// нарисован в коде клиента: это простые SVG, они не меняются, и возить
// их из базы незачем. Здесь — только загруженные людьми.
//
// Набор общий для всей установки: организация рисует свои условные
// обозначения один раз, а не в каждую новую доску отдельно.

type boardIcon struct {
	ID        uuid.UUID `json:"id"`
	Title     string    `json:"title"`
	CreatedBy uuid.UUID `json:"createdBy"`
	CanDelete bool      `json:"canDelete"`
}

func (s *Server) ListBoardIcons(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []boardIcon{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT id, title, created_by FROM app.board_icons ORDER BY created_at DESC`)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var i boardIcon
			if e := rows.Scan(&i.ID, &i.Title, &i.CreatedBy); e != nil {
				return e
			}
			i.CanDelete = i.CreatedBy == uid
			out = append(out, i)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

func (s *Server) UploadBoardIcon(c *fiber.Ctx) error {
	uid := s.uid(c)
	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	f, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer f.Close()

	stored, err := s.files.Save(f, header.Filename)
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", err.Error()))
	}
	// Значок — это картинка. Принять сюда документ значит получить
	// фигуру, которую нечем нарисовать.
	if !strings.HasPrefix(stored.MIME, "image/") {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "not_image",
			"Значком может быть только изображение (SVG, PNG и подобные)"))
	}

	title := strings.TrimSpace(c.FormValue("title"))
	if title == "" {
		title = stored.Filename
	}

	var icon boardIcon
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var fileID uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
			VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
			uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).Scan(&fileID); e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `
			INSERT INTO app.board_icons (title, file_id, created_by)
			VALUES ($1, $2, $3) RETURNING id, title, created_by`,
			title, fileID, uid).Scan(&icon.ID, &icon.Title, &icon.CreatedBy)
	})
	if err != nil {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, err)
	}
	icon.CanDelete = true
	return httpx.JSON(c, fiber.StatusCreated, icon)
}

func (s *Server) DownloadBoardIcon(c *fiber.Ctx) error {
	id, err := param(c, "iconID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var key, mimeType, filename string
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.mime_type, f.filename
			  FROM app.board_icons i JOIN app.files f ON f.id = i.file_id
			 WHERE i.id = $1`, id).Scan(&key, &mimeType, &filename)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mimeType, filename, false)
}

func (s *Server) DeleteBoardIcon(c *fiber.Ctx) error {
	id, err := param(c, "iconID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `DELETE FROM app.board_icons WHERE id = $1`, id)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.NoContent(c)
}
