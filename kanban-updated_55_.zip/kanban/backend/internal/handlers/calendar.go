package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// calendarTask — задача в календарном представлении.
//
// Отдаём только то, что рисуется в клетке дня: полная задача со
// списками шагов и грантов на месяц вперёд — это сотни лишних записей,
// которые всё равно не показываются, пока карточку не откроют.
type calendarTask struct {
	ID          uuid.UUID   `json:"id"`
	Title       string      `json:"title"`
	BoardID     uuid.UUID   `json:"boardId"`
	BoardTitle  string      `json:"boardTitle"`
	ColumnID    uuid.UUID   `json:"columnId"`
	ColumnTitle string      `json:"columnTitle"`
	Priority    string      `json:"priority"`
	Color       string      `json:"color"`
	DueDate     string      `json:"dueDate"`
	Completed   bool        `json:"completed"`
	// Момент завершения — для фильтра по дате завершения, общего со
	// всеми вкладками. Completed оставлен: его читает отрисовка клетки.
	CompletedAt *time.Time  `json:"completedAt"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Теги нужны панели отбора: она общая для всех вкладок, и без них
	// фильтр по тегам в календаре ничего бы не находил.
	Tags         []string `json:"tags"`
	// Комментарии, файлы и готовность к сдаче — те же приметы, что на
	// карточке в проекте: по ним видно, есть ли обсуждение и ждёт ли
	// задача приёмки, не открывая её.
	CommentCnt int        `json:"commentCount"`
	AttachCnt  int        `json:"attachmentCount"`
	ReadyAt    *time.Time `json:"readyAt"`
	IncomingNum  string  `json:"incomingNumber"`
	IncomingDate *string `json:"incomingDate"`
	// Автор задачи и уровень доступа зрителя. Без них календарь не мог
	// объяснить, почему задача не редактируется, и не показывал, кто
	// её поставил, — в отличие от «Входящих».
	CreatedBy   uuid.UUID   `json:"createdBy"`
	Access      string      `json:"access"`
}

// Calendar возвращает задачи со сроком в заданном диапазоне.
//
// Диапазон обязателен и ограничен: без верхнего предела запрос
// «покажи всё» на большой установке вернул бы десятки тысяч строк, а
// календарь всё равно рисует максимум пару месяцев за раз.
func (s *Server) Calendar(c *fiber.Ctx) error {
	uid := s.uid(c)

	from := c.Query("from")
	to := c.Query("to")
	if from == "" || to == "" {
		// По умолчанию — текущий месяц с запасом на соседние недели,
		// которые видны в сетке месяца.
		now := time.Now()
		first := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.UTC)
		from = first.AddDate(0, 0, -7).Format("2006-01-02")
		to = first.AddDate(0, 1, 7).Format("2006-01-02")
	}

	fromDate, err1 := time.Parse("2006-01-02", from)
	toDate, err2 := time.Parse("2006-01-02", to)
	if err1 != nil || err2 != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_range",
			"Некорректный диапазон дат"))
	}
	if toDate.Sub(fromDate) > 400*24*time.Hour {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "range_too_wide",
			"Диапазон не может превышать год"))
	}

	// mine=1 — только мои задачи: на общей установке календарь всех
	// проектов сразу превращается в кашу, и чаще нужен личный срез.
	onlyMine := c.Query("mine") == "1"
	var boardFilter *uuid.UUID
	if v := c.Query("boardId"); v != "" {
		if id, e := uuid.Parse(v); e == nil {
			boardFilter = &id
		}
	}
	// assignee=<uuid> — фильтр по конкретному исполнителю (п.6). Пусто —
	// без ограничения по исполнителю.
	var assigneeFilter *uuid.UUID
	if v := c.Query("assignee"); v != "" {
		if id, e := uuid.Parse(v); e == nil {
			assigneeFilter = &id
		}
	}

	items := []calendarTask{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT t.id, t.title, t.board_id, app.board_title(t.board_id), t.column_id, app.column_title(t.column_id),
			       t.priority::text, t.color,
			       to_char(t.due_date, 'YYYY-MM-DD'),
			       t.completed_at,
			       COALESCE(array_agg(DISTINCT a.user_id)
			                FILTER (WHERE a.user_id IS NOT NULL), '{}'),
			       t.tags,
			       (SELECT count(*) FROM app.comments cm WHERE cm.task_id = t.id),
			       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
			       t.ready_at,
			       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.created_by,
			       COALESCE(app.task_access(t.id, $5), 'read')
			  FROM app.tasks t
			  LEFT JOIN app.task_assignees a ON a.task_id = t.id
			 WHERE NOT t.archived
			   AND t.due_date BETWEEN $1::date AND $2::date
			   AND ($3::uuid IS NULL OR t.board_id = $3::uuid)
			   AND (NOT $4::boolean OR (
			         t.created_by IN (SELECT app.effective_users($5))
			         OR EXISTS (SELECT 1 FROM app.task_assignees ta
			                     WHERE ta.task_id = t.id
			                       AND ta.user_id IN (SELECT app.effective_users($5)))
			         OR EXISTS (SELECT 1 FROM app.task_grants g
			                     WHERE g.task_id = t.id
			                       AND g.user_id IN (SELECT app.effective_users($5)))
			         OR EXISTS (SELECT 1 FROM app.task_steps x
			                     WHERE x.task_id = t.id
			                       AND x.assignee_id IN (SELECT app.effective_users($5)))))
			   AND ($6::uuid IS NULL OR EXISTS (
			         SELECT 1 FROM app.task_assignees ta2
			          WHERE ta2.task_id = t.id AND ta2.user_id = $6::uuid))
			 GROUP BY t.id
			 ORDER BY t.due_date, t.priority DESC`,
			from, to, boardFilter, onlyMine, uid, assigneeFilter)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var ct calendarTask
			if e := rows.Scan(&ct.ID, &ct.Title, &ct.BoardID, &ct.BoardTitle, &ct.ColumnID, &ct.ColumnTitle,
				&ct.Priority, &ct.Color, &ct.DueDate, &ct.CompletedAt,
				&ct.Assignees, &ct.Tags, &ct.CommentCnt, &ct.AttachCnt, &ct.ReadyAt,
				&ct.IncomingNum, &ct.IncomingDate, &ct.CreatedBy, &ct.Access); e != nil {
				return e
			}
			ct.Completed = ct.CompletedAt != nil
			items = append(items, ct)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"items": items, "from": from, "to": to,
	})
}
