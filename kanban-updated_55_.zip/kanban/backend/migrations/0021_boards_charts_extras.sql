-- =====================================================================
-- 0021_boards_charts_extras.sql — развитие досок и диаграмм.
--
-- Что добавляется:
--
--   1. Совместные доски: размер полотна и цвет фона; свои значки,
--      загруженные участниками; прозрачность фигур.
--   2. Диаграммы: обсуждение и файлы на этапе; защита от замкнутых
--      цепочек «следующих» записей.
--   3. Уведомления умеют ссылаться на диаграмму и на доску.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0021_boards_charts_extras.sql
--
-- Запускать от app_owner, после 0020. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. РАЗМЕР И ФОН ДОСКИ.
--
-- Полотно у всех участников одинаковое, в точках холста, а не в
-- пикселях экрана. Иначе доска, собранная на большом мониторе,
-- выглядела бы на ноутбуке другой: фигуры, разложенные «по углам»,
-- оказывались бы за краем или сбивались в кучу.
--
-- Экран меньше полотна — появляется прокрутка; больше — поля вокруг.
-- ─────────────────────────────────────────────────────────────────────

ALTER TABLE app.whiteboards
    ADD COLUMN IF NOT EXISTS width    integer NOT NULL DEFAULT 3840,
    ADD COLUMN IF NOT EXISTS height   integer NOT NULL DEFAULT 2160,
    -- Пустой цвет означает «как фон приложения»: доска подстраивается
    -- под светлую и тёмную тему. Заданный цвет используется как есть,
    -- в том числе при выгрузке в PNG и PDF — прозрачный фон там
    -- выглядит как испорченный файл.
    ADD COLUMN IF NOT EXISTS bg_color text NOT NULL DEFAULT '';

-- Разумные пределы: меньше — не доска, больше — браузер не выдержит
-- (8K с запасом).
ALTER TABLE app.whiteboards DROP CONSTRAINT IF EXISTS whiteboards_size_ck;
ALTER TABLE app.whiteboards ADD CONSTRAINT whiteboards_size_ck
    CHECK (width BETWEEN 640 AND 16384 AND height BETWEEN 480 AND 16384);

-- Прозрачность фигуры. Отдельной колонкой, а не ключом в data: её
-- задают почти всем видам фигур, и выносить её в общий ряд с
-- геометрией правильнее, чем повторять в каждом наборе свойств.
ALTER TABLE app.whiteboard_shapes
    ADD COLUMN IF NOT EXISTS opacity double precision NOT NULL DEFAULT 1;

ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_opacity_ck;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_opacity_ck
    CHECK (opacity BETWEEN 0 AND 1);

-- Вид «значок»: картинка из набора или своя, загруженная участником.
ALTER TABLE app.whiteboard_shapes DROP CONSTRAINT IF EXISTS whiteboard_shapes_kind_check;
ALTER TABLE app.whiteboard_shapes ADD CONSTRAINT whiteboard_shapes_kind_check
    CHECK (kind IN ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                    'line', 'arrow', 'draw', 'image', 'frame', 'icon'));

-- ─────────────────────────────────────────────────────────────────────
-- 2. СВОИ ЗНАЧКИ.
--
-- Встроенный набор (сетевое оборудование, рабочие места, серверы)
-- нарисован в коде клиента: это простые SVG, они не меняются и
-- незачем возить их из базы. Здесь хранятся только загруженные
-- людьми — те, которых во встроенном наборе нет.
--
-- Значки общие для всей установки, а не для одной доски: организация
-- рисует свой набор один раз, и заставлять загружать его в каждую
-- новую доску значит гарантировать, что этого никто делать не станет.
-- ─────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app.board_icons (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS board_icons_created_idx ON app.board_icons (created_at DESC);

ALTER TABLE app.board_icons ENABLE ROW LEVEL SECURITY;

-- Видят все, кто вошёл: набор значков — общий инструмент, как палитра.
DROP POLICY IF EXISTS board_icons_select ON app.board_icons;
CREATE POLICY board_icons_select ON app.board_icons FOR SELECT
    USING (app.current_user_id() IS NOT NULL);

DROP POLICY IF EXISTS board_icons_insert ON app.board_icons;
CREATE POLICY board_icons_insert ON app.board_icons FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Убрать значок может тот, кто его загрузил, либо администратор:
-- иначе случайно загруженный файл остаётся в наборе навсегда.
DROP POLICY IF EXISTS board_icons_delete ON app.board_icons;
CREATE POLICY board_icons_delete ON app.board_icons FOR DELETE
    USING (created_by = app.current_user_id() OR app.is_admin(app.current_user_id()));

-- Файл значка виден всем вошедшим — иначе значок, загруженный
-- коллегой, не нарисуется.
DROP POLICY IF EXISTS files_select_board_icons ON app.files;
CREATE POLICY files_select_board_icons ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.board_icons i WHERE i.file_id = files.id)
           AND app.current_user_id() IS NOT NULL);

-- ─────────────────────────────────────────────────────────────────────
-- 3. ОБСУЖДЕНИЕ И ФАЙЛЫ НА ЭТАПЕ ДИАГРАММЫ.
--
-- Своя пара таблиц, а не переиспользование comments/attachments: те
-- жёстко привязаны к задаче (task_id NOT NULL) и участвуют в счётчиках,
-- уведомлениях и активности задач. Подмешивать туда этапы диаграмм
-- значит ломать эти счётчики ради экономии двух таблиц.
-- ─────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app.chart_comments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    body       text NOT NULL CHECK (length(btrim(body)) > 0),
    edited_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_comments_item_idx ON app.chart_comments (item_id, created_at);

CREATE TABLE IF NOT EXISTS app.chart_attachments (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    file_id    uuid NOT NULL REFERENCES app.files(id) ON DELETE RESTRICT,
    author_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    title      text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_attachments_item_idx ON app.chart_attachments (item_id, created_at);

ALTER TABLE app.chart_comments    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_attachments ENABLE ROW LEVEL SECURITY;

-- Комментировать может любой участник диаграммы, включая исполнителя:
-- обсуждение — это не правка, запрещать его смысла нет. Править и
-- удалять — только свой комментарий.
DROP POLICY IF EXISTS chart_comments_select ON app.chart_comments;
CREATE POLICY chart_comments_select ON app.chart_comments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_comments_insert ON app.chart_comments;
CREATE POLICY chart_comments_insert ON app.chart_comments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_update ON app.chart_comments;
CREATE POLICY chart_comments_update ON app.chart_comments FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_comments_delete ON app.chart_comments;
CREATE POLICY chart_comments_delete ON app.chart_comments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_select ON app.chart_attachments;
CREATE POLICY chart_attachments_select ON app.chart_attachments FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS chart_attachments_insert ON app.chart_attachments;
CREATE POLICY chart_attachments_insert ON app.chart_attachments FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chart_attachments_delete ON app.chart_attachments;
CREATE POLICY chart_attachments_delete ON app.chart_attachments FOR DELETE
    USING (author_id = app.current_user_id()
           OR app.is_chart_owner(app.chart_of_item(item_id), app.current_user_id()));

DROP POLICY IF EXISTS files_select_chart_attachments ON app.files;
CREATE POLICY files_select_chart_attachments ON app.files FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM app.chart_attachments a
         WHERE a.file_id = files.id
           AND app.can_see_chart(app.chart_of_item(a.item_id), app.current_user_id())));

-- ─────────────────────────────────────────────────────────────────────
-- 4. ЗАМКНУТЫЕ ЦЕПОЧКИ СВЯЗЕЙ.
--
-- «Этап 1 → этап 2 → этап 1» — не сложный план, а ошибка: такую
-- последовательность нельзя выполнить, и рисовать её бессмысленно.
-- Проверка стоит в базе, а не только в форме: связи приходят и из
-- формы этапа, и списком при сохранении, и запрет должен быть один.
-- ─────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION app.chart_link_would_cycle(p_from uuid, p_to uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    -- Цепочка замкнётся, если из предполагаемого следующего этапа уже
    -- есть путь обратно в текущий. Обход в ширину по существующим
    -- связям; UNION (без ALL) сам гасит повторные посещения, поэтому
    -- обход конечен даже на уже испорченных данных.
    WITH RECURSIVE reach(id) AS (
        SELECT p_to
        UNION
        SELECT l.to_item FROM app.chart_links l JOIN reach r ON l.from_item = r.id
    )
    SELECT p_from = p_to OR EXISTS (SELECT 1 FROM reach WHERE id = p_from)
$$;

CREATE OR REPLACE FUNCTION app.chart_links_no_cycle() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    IF app.chart_link_would_cycle(NEW.from_item, NEW.to_item) THEN
        RAISE EXCEPTION 'Связь замкнула бы цепочку этапов'
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS chart_links_no_cycle ON app.chart_links;
CREATE TRIGGER chart_links_no_cycle BEFORE INSERT OR UPDATE ON app.chart_links
    FOR EACH ROW EXECUTE FUNCTION app.chart_links_no_cycle();

-- ─────────────────────────────────────────────────────────────────────
-- 5. УВЕДОМЛЕНИЯ О ДИАГРАММАХ И ДОСКАХ.
--
-- Нажатие на уведомление должно открывать то, о чём оно: без ссылки
-- уведомление «вас добавили в диаграмму» заставляет искать её руками.
-- ─────────────────────────────────────────────────────────────────────

ALTER TABLE app.notifications
    ADD COLUMN IF NOT EXISTS chart_id uuid REFERENCES app.charts(id)      ON DELETE CASCADE,
    ADD COLUMN IF NOT EXISTS wb_id    uuid REFERENCES app.whiteboards(id) ON DELETE CASCADE;

-- Отдельная функция, а не ещё два аргумента у notify_cat: у той уже
-- пять параметров, и вызовы про задачи не должны обрастать пустыми
-- местами ради двух новых полей.
CREATE OR REPLACE FUNCTION app.notify_obj(
    p_user uuid, p_body text, p_category text,
    p_chart uuid DEFAULT NULL, p_wb uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_enabled boolean;
BEGIN
    SELECT enabled INTO v_enabled
      FROM app.notification_prefs
     WHERE user_id = p_user AND category = p_category;
    IF v_enabled IS NOT NULL AND v_enabled = false THEN
        RETURN;
    END IF;
    RETURN QUERY
        INSERT INTO app.notifications (user_id, body, category, chart_id, wb_id)
        VALUES (p_user, p_body, p_category, p_chart, p_wb)
        RETURNING notifications.id, notifications.created_at;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON app.board_icons       TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_comments    TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_attachments TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_link_would_cycle(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.notify_obj(uuid, text, text, uuid, uuid) TO app_user;

-- Готово.
