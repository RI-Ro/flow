import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

// Шрифты подключаются пакетами и попадают в сборку: файлы раздаются с
// того же адреса, что и приложение. Никаких обращений к
// fonts.googleapis.com — система должна работать в контуре без выхода
// в интернет, а внешняя ссылка это и отказ без сети, и утечка наружу
// самого факта, что человек сейчас работает.
//
// Подключены только используемые начертания: каждое лишнее — лишний
// файл в раздаче.
import "@fontsource/manrope/400.css";
import "@fontsource/manrope/500.css";
import "@fontsource/manrope/600.css";
import "@fontsource/manrope/700.css";
import "@fontsource/manrope/800.css";
import "@fontsource/jetbrains-mono/400.css";
import "@fontsource/jetbrains-mono/500.css";
import "@fontsource/jetbrains-mono/600.css";

import "./styles.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
