-- Скрипт предназначен для создания отметок о просмотре задач и проектов: таблица, индекс, политика, триггеры уборки,
-- функции записи и чтения отметок и расчёта времени последнего изменения. Позволяет показывать, что изменилось
-- с момента последнего просмотра конкретным пользователем.


SET search_path = app, public;

-- Таблица app.view_marks предназначена для хранения отметок о просмотре. entity_id не имеет внешнего ключа:
-- таблица хранит отметки и по задачам, и по проектам; записи удаляются триггерами.
CREATE TABLE IF NOT EXISTS app.view_marks (
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    kind      text NOT NULL CHECK (kind IN ('task', 'board')),
    entity_id uuid NOT NULL,
    viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, kind, entity_id)
);

-- Индекс view_marks_entity_idx предназначен для запроса «кто смотрел задачу».
CREATE INDEX IF NOT EXISTS view_marks_entity_idx
    ON app.view_marks (kind, entity_id);

ALTER TABLE app.view_marks ENABLE ROW LEVEL SECURITY;

-- Политика view_marks_own: прямой доступ только к собственным строкам; отметки других выдаются SECURITY DEFINER-функциями.
DROP POLICY IF EXISTS view_marks_own ON app.view_marks;
CREATE POLICY view_marks_own ON app.view_marks FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.view_marks TO app_user;

-- Функция app.drop_view_marks предназначена для удаления отметок вместе с сущностью; SECURITY DEFINER, так как удаляются строки всех пользователей.
CREATE OR REPLACE FUNCTION app.drop_view_marks() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    DELETE FROM app.view_marks
     WHERE kind = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN OLD;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_view_marks ON app.tasks;
-- Триггер tasks_drop_view_marks предназначен для удаления отметок при удалении задачи.
CREATE TRIGGER tasks_drop_view_marks AFTER DELETE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('task');

DROP TRIGGER IF EXISTS boards_drop_view_marks ON app.boards;
-- Триггер boards_drop_view_marks предназначен для удаления отметок при удалении проекта.
CREATE TRIGGER boards_drop_view_marks AFTER DELETE ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('board');


-- Функция app.mark_seen предназначена для отметки сущности просмотренной; видимость проверяется внутри функции (SECURITY DEFINER).
CREATE OR REPLACE FUNCTION app.mark_seen(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_at timestamptz;
BEGIN
    IF p_user IS NULL OR p_entity IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_kind NOT IN ('task', 'board') THEN
        RAISE EXCEPTION 'unknown_view_kind';
    END IF;

    IF p_kind = 'task' AND NOT app.can_see_task(p_entity, p_user) THEN
        RETURN NULL;
    END IF;
    IF p_kind = 'board' AND NOT app.can_see_board(p_entity, p_user) THEN
        RETURN NULL;
    END IF;

    INSERT INTO app.view_marks (user_id, kind, entity_id, viewed_at)
    VALUES (p_user, p_kind, p_entity, now())
    ON CONFLICT (user_id, kind, entity_id)
    DO UPDATE SET viewed_at = now()
    RETURNING viewed_at INTO v_at;

    RETURN v_at;
END $$;

-- Функция app.seen_at предназначена для получения времени последнего просмотра сущности пользователем.
CREATE OR REPLACE FUNCTION app.seen_at(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.viewed_at FROM app.view_marks v
     WHERE v.user_id = p_user AND v.kind = p_kind AND v.entity_id = p_entity
$$;

-- Функция app.assignees_seen предназначена для получения исполнителей задачи, открывавших её.
CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- Функция app.task_activity_at предназначена для получения времени последнего изменения задачи: максимум из tasks.updated_at
-- и последней записи журнала, исключая действия указанного пользователя.
CREATE OR REPLACE FUNCTION app.task_activity_at(p_task uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               t.updated_at,
               COALESCE((SELECT max(a.created_at) FROM app.activity a
                          WHERE a.task_id = t.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        t.updated_at))
      FROM app.tasks t WHERE t.id = p_task
$$;

-- Функция app.board_activity_at предназначена для получения времени последнего изменения проекта или любой его задачи
-- (SECURITY DEFINER), исключая действия указанного пользователя.
CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(t.updated_at) FROM app.tasks t
                          WHERE t.board_id = b.id AND NOT t.archived),
                        b.updated_at),
               COALESCE((SELECT max(a.created_at)
                           FROM app.activity a
                           JOIN app.tasks t ON t.id = a.task_id
                          WHERE t.board_id = b.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;

GRANT EXECUTE ON FUNCTION app.mark_seen(text, uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.seen_at(text, uuid, uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.task_activity_at(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.board_activity_at(uuid, uuid)      TO app_user;


