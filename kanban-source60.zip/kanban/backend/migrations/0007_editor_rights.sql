-- Скрипт предназначен для передачи редактору проекта права управлять участниками и настройками проекта.
-- Удаление проекта остаётся за владельцем; роль владельца изменить нельзя.


SET search_path = app, public;

-- Политика boards_update: настройки проекта (название, описание, фон, положение в дереве) изменяет владелец или редактор.
DROP POLICY IF EXISTS boards_update ON app.boards;
CREATE POLICY boards_update ON app.boards FOR UPDATE
    USING (app.can_edit_board(id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(id, app.current_user_id()));

-- Политики board_members: состав участников изменяют владелец и редактор; условие role <> 'owner' проверяется
-- в USING и в WITH CHECK.
DROP POLICY IF EXISTS board_members_write ON app.board_members;
CREATE POLICY board_members_write ON app.board_members FOR INSERT
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

DROP POLICY IF EXISTS board_members_update ON app.board_members;
CREATE POLICY board_members_update ON app.board_members FOR UPDATE
    USING (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    )
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

-- Политика board_members_delete: владелец и редактор убирают любого, кроме владельца; участник может выйти сам.
DROP POLICY IF EXISTS board_members_delete ON app.board_members;
CREATE POLICY board_members_delete ON app.board_members FOR DELETE
    USING (
        (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

