-- Скрипт предназначен для переноса отметки «готова к сдаче» в отчёт при завершении задачи: перед снятием отметки
-- триггер дописывает в отчёт строку с ФИО сдавшего и временем сдачи.
--
-- Перенос выполняется в триггере, а не в обработчике: задача завершается двумя путями (кнопка «Пометить завершённой»
-- и перенос карточки в колонку «Готово» через app.move_task), триггер срабатывает при любом из них.
--
-- Время указывается в часовом поясе клиента: сервер передаёт заголовок X-Timezone в транзакционную настройку app.tz.
-- Если настройка не задана или имя пояса неверно, используется пояс сессии.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0019_ready_into_report.sql
--
-- Выполняется от app_owner после 0018_team_groups.sql, идемпотентен.


SET search_path = app, public;

-- Функция app.drop_ready_on_complete предназначена для снятия отметки готовности при завершении задачи с записью
-- отметки в отчёт. Режим SECURITY DEFINER: имя сдавшего читается из app.users в обход политики на users.
-- Функция ничего не возвращает наружу и изменяет только обновляемую строку.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_tz    text;
    v_local timestamp;
    v_name  text;
    v_line  text;
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        IF OLD.ready_at IS NOT NULL THEN
            v_tz := nullif(current_setting('app.tz', true), '');
            BEGIN
                v_local := OLD.ready_at AT TIME ZONE COALESCE(v_tz, current_setting('TimeZone'));
            EXCEPTION WHEN invalid_parameter_value THEN
                v_local := OLD.ready_at AT TIME ZONE current_setting('TimeZone');
            END;

            SELECT u.full_name INTO v_name FROM app.users u WHERE u.id = OLD.ready_by;

            v_line := 'Отметка о готовности к сдаче: '
                   || COALESCE(nullif(btrim(v_name), ''), 'исполнитель')
                   || ' ' || to_char(v_local, 'DD.MM.YYYY, HH24:MI');

            -- Отчёт берётся из NEW: при изменении отчёта в том же UPDATE строка дописывается к новому тексту.
            -- Завершающие переводы строк удаляются, чтобы не возникало пустых строк между отчётом и отметкой.
            -- Одинаковая строка повторно не добавляется.
            IF position(v_line IN COALESCE(NEW.report, '')) = 0 THEN
                NEW.report := CASE
                    WHEN btrim(COALESCE(NEW.report, '')) = '' THEN v_line
                    ELSE rtrim(NEW.report, E' \n\r\t') || E'\n' || v_line
                END;
            END IF;
        END IF;

        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
-- Триггер tasks_drop_ready предназначен для вызова app.drop_ready_on_complete перед изменением задачи.
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();

