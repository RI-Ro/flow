-- Скрипт предназначен для применения доработок поверх базовой схемы (0002) и RLS (0003): столбцы, напоминания,
-- настройки уведомлений, функции доступа, перемещение задач, периодичность и политики RLS.
-- Выполняется от app_owner, идемпотентен: psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0005_features.sql


SET search_path = app, public;

-- Раздел 1: новые столбцы.

-- Столбцы task_steps: исполнитель, срок и автор пункта (объединённый чек-лист).
ALTER TABLE app.task_steps
    ADD COLUMN IF NOT EXISTS assignee_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS due_date    date,
    ADD COLUMN IF NOT EXISTS created_by  uuid REFERENCES app.users(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS task_steps_assignee_idx ON app.task_steps (assignee_id);

-- Столбцы tasks: периодичность задачи.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS recur_freq     text NOT NULL DEFAULT 'none'
        CHECK (recur_freq IN ('none','daily','weekly','monthly')),
    ADD COLUMN IF NOT EXISTS recur_interval integer NOT NULL DEFAULT 1
        CHECK (recur_interval >= 1),
    ADD COLUMN IF NOT EXISTS recur_weekdays integer[] NOT NULL DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS recur_monthday integer,
    ADD COLUMN IF NOT EXISTS recur_until    date;

-- Столбец tasks.report: отчёт о выполнении (свободный текст).
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS report text NOT NULL DEFAULT '';

-- Таблица app.reminders предназначена для хранения личных напоминаний: заголовок, время срабатывания, повторение.
-- Сработавшие напоминания обрабатывает фоновый опрос приложения.
CREATE TABLE IF NOT EXISTS app.reminders (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    remind_at   timestamptz NOT NULL,
    recur_freq  text NOT NULL DEFAULT 'none'
        CHECK (recur_freq IN ('none','daily','weekly','monthly')),
    recur_interval integer NOT NULL DEFAULT 1 CHECK (recur_interval >= 1),
    recur_weekdays integer[] NOT NULL DEFAULT '{}',
    active      boolean NOT NULL DEFAULT true,
    last_fired  timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS reminders_user_idx ON app.reminders (user_id);
CREATE INDEX IF NOT EXISTS reminders_due_idx  ON app.reminders (remind_at) WHERE active;

ALTER TABLE app.reminders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS reminders_own ON app.reminders;
CREATE POLICY reminders_own ON app.reminders FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.reminders TO app_user;

-- Таблица app.notification_prefs предназначена для хранения настроек категорий уведомлений пользователя.
CREATE TABLE IF NOT EXISTS app.notification_prefs (
    user_id  uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    category text NOT NULL,
    enabled  boolean NOT NULL DEFAULT true,
    PRIMARY KEY (user_id, category)
);
ALTER TABLE app.notification_prefs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS notif_prefs_own ON app.notification_prefs;
CREATE POLICY notif_prefs_own ON app.notification_prefs FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON app.notification_prefs TO app_user;

-- Функция app.next_reminder_at предназначена для вычисления следующего времени срабатывания повторяющегося напоминания;
-- для weekly с выбранными днями определяется ближайший выбранный день недели, иначе добавляется интервал.
CREATE OR REPLACE FUNCTION app.next_reminder_at(
    p_from timestamptz, p_freq text, p_interval int, p_weekdays int[])
RETURNS timestamptz
LANGUAGE plpgsql IMMUTABLE
AS $$
DECLARE v_next timestamptz := p_from; v_guard int := 0; v_dow int;
BEGIN
    IF p_freq = 'daily' THEN
        RETURN p_from + (p_interval || ' days')::interval;
    ELSIF p_freq = 'monthly' THEN
        RETURN p_from + (p_interval || ' months')::interval;
    ELSIF p_freq = 'weekly' THEN
        IF array_length(p_weekdays, 1) IS NULL THEN
            RETURN p_from + (p_interval * 7 || ' days')::interval;
        END IF;
        LOOP
            v_next := v_next + interval '1 day';
            v_guard := v_guard + 1;
            v_dow := EXTRACT(dow FROM v_next)::int;
            EXIT WHEN v_dow = ANY (p_weekdays) OR v_guard > 370;
        END LOOP;
        RETURN v_next;
    END IF;
    RETURN p_from;
END $$;

-- Функция app.due_reminders предназначена для получения сработавших напоминаний.
CREATE OR REPLACE FUNCTION app.due_reminders()
RETURNS TABLE (id uuid, user_id uuid, title text, recur_freq text,
               recur_interval int, recur_weekdays int[])
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT id, user_id, title, recur_freq, recur_interval, recur_weekdays
      FROM app.reminders
     WHERE active AND remind_at <= now()
       AND (last_fired IS NULL OR last_fired < remind_at)
$$;

-- Функция app.advance_reminder предназначена для сдвига повторяющегося напоминания или отключения разового.
CREATE OR REPLACE FUNCTION app.advance_reminder(p_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE r app.reminders%ROWTYPE;
BEGIN
    SELECT * INTO r FROM app.reminders WHERE id = p_id;
    IF NOT FOUND THEN RETURN; END IF;
    IF r.recur_freq = 'none' THEN
        UPDATE app.reminders SET active = false, last_fired = now() WHERE id = p_id;
    ELSE
        UPDATE app.reminders
           SET last_fired = now(),
               remind_at = app.next_reminder_at(remind_at, recur_freq, recur_interval, recur_weekdays)
         WHERE id = p_id;
    END IF;
END $$;

GRANT EXECUTE ON FUNCTION app.next_reminder_at(timestamptz, text, int, int[]) TO app_user;
GRANT EXECUTE ON FUNCTION app.due_reminders() TO app_user;
GRANT EXECUTE ON FUNCTION app.advance_reminder(uuid) TO app_user;

-- Столбец notifications.category: категория уведомления.
ALTER TABLE app.notifications
    ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'other';

-- Функция app.notify_cat предназначена для создания уведомления с категорией и проверкой настроек: при отключённой
-- категории уведомление не создаётся. Категории: assigned (назначение исполнителем), granted (доступ к задаче),
-- comment (комментарий), step (чек-лист), task (изменения задачи), reminder (напоминания), other (прочее).
CREATE OR REPLACE FUNCTION app.notify_cat(
    p_user uuid, p_body text, p_category text,
    p_board uuid DEFAULT NULL, p_task uuid DEFAULT NULL)
RETURNS TABLE (id uuid, created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_enabled boolean;
BEGIN
    SELECT enabled INTO v_enabled
      FROM app.notification_prefs
     WHERE user_id = p_user AND category = p_category;
    -- Отсутствие строки настроек означает, что категория включена.
    IF v_enabled IS NOT NULL AND v_enabled = false THEN
        RETURN; -- категория отключена пользователем
    END IF;
    RETURN QUERY
        INSERT INTO app.notifications (user_id, body, board_id, task_id, category)
        VALUES (p_user, p_body, p_board, p_task, p_category)
        RETURNING notifications.id, notifications.created_at;
END $$;


-- Функция app.task_access предназначена для определения уровня доступа к задаче по порядку убывания силы права:
-- владелец или редактор проекта — edit; автор задачи — edit; исполнитель — contribute; исполнитель пункта чек-листа —
-- contribute; точечное право — по праву; читатель проекта — read; иначе NULL.
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Автор задачи имеет полный доступ.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'edit';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    IF v_role = 'reader' THEN
        RETURN 'read';
    END IF;

    RETURN NULL;
END $$;

-- Функция app.can_see_board предназначена для проверки видимости проекта: участник либо обладатель видимой задачи.
CREATE OR REPLACE FUNCTION app.can_see_board(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_role(p_board, p_user) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
             WHERE t.board_id = p_board
               AND (t.created_by IN (SELECT app.effective_users(p_user))
                    OR EXISTS (SELECT 1 FROM app.task_assignees a
                                WHERE a.task_id = t.id
                                  AND a.user_id IN (SELECT app.effective_users(p_user)))
                    OR EXISTS (SELECT 1 FROM app.task_grants g
                                WHERE g.task_id = t.id
                                  AND g.user_id IN (SELECT app.effective_users(p_user)))
                    OR EXISTS (SELECT 1 FROM app.task_steps s
                                WHERE s.task_id = t.id
                                  AND s.assignee_id IN (SELECT app.effective_users(p_user)))))
$$;

-- Функция app.can_contribute_task предназначена для проверки права участия в задаче.
CREATE OR REPLACE FUNCTION app.can_contribute_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.task_access(p_task, p_user) IN ('edit', 'contribute')
        OR EXISTS (SELECT 1 FROM app.tasks t
                    WHERE t.id = p_task
                      AND t.created_by IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_edit_task предназначена для проверки права редактирования задачи.
CREATE OR REPLACE FUNCTION app.can_edit_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.task_access(p_task, p_user) = 'edit'
        OR EXISTS (SELECT 1 FROM app.tasks t
                    WHERE t.id = p_task
                      AND t.created_by IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_close_task предназначена для проверки права завершения: автор, редактор или владелец проекта.
CREATE OR REPLACE FUNCTION app.can_close_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner','editor')))
$$;

-- Функция app.can_move_task предназначена для проверки права перемещения задачи: автор, редактор или владелец.
CREATE OR REPLACE FUNCTION app.can_move_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

-- Функция app.is_task_assignee предназначена для проверки, что пользователь — исполнитель задачи.
CREATE OR REPLACE FUNCTION app.is_task_assignee(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.task_assignees a
                    WHERE a.task_id = p_task
                      AND a.user_id IN (SELECT app.effective_users(p_user)))
$$;

-- Функция app.can_assign_task предназначена для проверки права назначения исполнителей.
CREATE OR REPLACE FUNCTION app.can_assign_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (app.can_edit_task(p_task, p_user)
                OR t.created_by IN (SELECT app.effective_users(p_user))))
$$;

-- Функция app.board_title предназначена для получения названия проекта без учёта RLS.
CREATE OR REPLACE FUNCTION app.board_title(p_board uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT title FROM app.boards WHERE id = p_board $$;

-- Функция app.column_title предназначена для получения названия колонки без учёта RLS.
CREATE OR REPLACE FUNCTION app.column_title(p_column uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT title FROM app.columns WHERE id = p_column $$;

-- Функция app.ensure_assignee предназначена для добавления исполнителя при назначении в чек-листе.
CREATE OR REPLACE FUNCTION app.ensure_assignee(p_task uuid, p_assignee uuid, p_actor uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF p_assignee IS NULL THEN RETURN; END IF;
    INSERT INTO app.task_assignees (task_id, user_id)
    VALUES (p_task, p_assignee) ON CONFLICT DO NOTHING;
END $$;

-- Функция app.set_task_report предназначена для сохранения отчёта о выполнении; SECURITY DEFINER позволяет
-- участнику с уровнем contribute писать отчёт в обход политики tasks_update. Право проверяет обработчик.
CREATE OR REPLACE FUNCTION app.set_task_report(p_task uuid, p_report text, p_actor uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_old text;
BEGIN
    SELECT report INTO v_old FROM app.tasks WHERE id = p_task;
    UPDATE app.tasks SET report = COALESCE(p_report, '') WHERE id = p_task;
    IF COALESCE(v_old,'') IS DISTINCT FROM COALESCE(p_report,'') THEN
        INSERT INTO app.activity (task_id, actor_id, body)
        VALUES (p_task, p_actor,
                CASE WHEN COALESCE(p_report,'') = '' THEN 'Отчёт о выполнении очищен'
                     ELSE 'Обновлён отчёт о выполнении' END);
    END IF;
END $$;

-- Функция app.can_manage_steps предназначена для проверки права управлять составом чек-листа: автор, редактор или владелец.
CREATE OR REPLACE FUNCTION app.can_manage_steps(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

-- Функция app.can_check_step предназначена для проверки права отметки пункта: исполнитель пункта или менеджер чек-листа;
-- при отсутствии исполнителя — любой участник задачи.
CREATE OR REPLACE FUNCTION app.can_check_step(p_step uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE v_task uuid; v_assignee uuid;
BEGIN
    SELECT task_id, assignee_id INTO v_task, v_assignee FROM app.task_steps WHERE id = p_step;
    IF v_task IS NULL THEN RETURN false; END IF;
    IF app.can_manage_steps(v_task, p_user) THEN RETURN true; END IF;
    IF v_assignee IS NOT NULL THEN
        RETURN v_assignee IN (SELECT app.effective_users(p_user));
    END IF;
    RETURN app.can_contribute_task(v_task, p_user);
END $$;

-- Функция app.move_task (SECURITY DEFINER) предназначена для перемещения задачи: полные права — в любую колонку,
-- исполнитель — в любую, кроме колонки завершения. В журнал записываются исходная и целевая колонки.
CREATE OR REPLACE FUNCTION app.move_task(
    p_task uuid, p_user uuid, p_column uuid, p_position int)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_old_column uuid;
    v_is_done    boolean;
    v_col_title  text;
    v_old_title  text;
    v_pos        int := GREATEST(p_position, 0);
    v_can_full   boolean;
    v_is_assignee boolean;
    v_target_done boolean;
BEGIN
    v_can_full    := app.can_move_task(p_task, p_user);
    v_is_assignee := app.is_task_assignee(p_task, p_user);
    IF NOT v_can_full AND NOT v_is_assignee THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    SELECT t.column_id INTO v_old_column
      FROM app.tasks t
     WHERE t.id = p_task
       AND EXISTS (SELECT 1 FROM app.columns c WHERE c.id = p_column AND c.board_id = t.board_id)
     FOR UPDATE;
    IF v_old_column IS NULL THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    SELECT is_done INTO v_target_done FROM app.columns WHERE id = p_column;
    IF NOT v_can_full AND v_is_assignee AND v_target_done THEN
        RAISE EXCEPTION 'move_to_done_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    UPDATE app.tasks SET position = position + 1
     WHERE column_id = p_column AND position >= v_pos AND id <> p_task;
    UPDATE app.tasks SET column_id = p_column, position = v_pos WHERE id = p_task;

    WITH ordered AS (
        SELECT id, row_number() OVER (PARTITION BY column_id ORDER BY position, updated_at) - 1 AS pos
          FROM app.tasks WHERE column_id = ANY (ARRAY[v_old_column, p_column]))
    UPDATE app.tasks t SET position = o.pos FROM ordered o
     WHERE t.id = o.id AND t.position <> o.pos;

    IF v_old_column <> p_column THEN
        SELECT title, is_done INTO v_col_title, v_is_done FROM app.columns WHERE id = p_column;
        SELECT title INTO v_old_title FROM app.columns WHERE id = v_old_column;
        UPDATE app.tasks SET completed_at = CASE WHEN v_is_done THEN now() ELSE NULL END WHERE id = p_task;
        INSERT INTO app.activity (task_id, actor_id, body)
        VALUES (p_task, p_user, 'Перемещена из «' || COALESCE(v_old_title,'—') || '» в «' || v_col_title || '»');
    END IF;
    RETURN v_old_column;
END $$;

-- Функция app.spawn_recurrence предназначена для создания следующего экземпляра периодической задачи при завершении;
-- еженедельно без выбранных дней — следующий понедельник.
CREATE OR REPLACE FUNCTION app.spawn_recurrence(p_task uuid, p_actor uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    r       app.tasks%ROWTYPE;
    v_base  date;
    v_next  date;
    v_col   uuid;
    v_new   uuid := gen_random_uuid();
    v_guard int := 0;
    v_dow   int;
BEGIN
    SELECT * INTO r FROM app.tasks WHERE id = p_task;
    IF NOT FOUND OR r.recur_freq = 'none' THEN RETURN NULL; END IF;

    v_base := COALESCE(r.due_date, current_date);

    IF r.recur_freq = 'daily' THEN
        v_next := v_base + (r.recur_interval || ' days')::interval;
    ELSIF r.recur_freq = 'monthly' THEN
        v_next := (v_base + (r.recur_interval || ' months')::interval)::date;
        IF r.recur_monthday IS NOT NULL THEN
            v_next := LEAST(
                date_trunc('month', v_next)::date + (r.recur_monthday - 1),
                (date_trunc('month', v_next) + interval '1 month - 1 day')::date);
        END IF;
    ELSIF r.recur_freq = 'weekly' THEN
        IF array_length(r.recur_weekdays, 1) IS NULL THEN
            -- Дни не выбраны: отсчёт от понедельника через (interval-1) полных недель; ISODOW: 1 — понедельник, 7 — воскресенье.
            v_next := (v_base + ((r.recur_interval - 1) * 7 || ' days')::interval)::date;
            v_next := v_next + ((8 - EXTRACT(isodow FROM v_next)::int) % 7);
            IF v_next <= v_base THEN
                v_next := v_next + 7;
            END IF;
        ELSE
            v_next := v_base;
            LOOP
                v_next := v_next + 1;
                v_guard := v_guard + 1;
                v_dow := EXTRACT(dow FROM v_next)::int; -- 0=Вс..6=Сб
                EXIT WHEN v_dow = ANY (r.recur_weekdays) OR v_guard > 370;
            END LOOP;
        END IF;
    END IF;

    IF v_next IS NULL THEN RETURN NULL; END IF;
    IF r.recur_until IS NOT NULL AND v_next > r.recur_until THEN RETURN NULL; END IF;

    SELECT id INTO v_col FROM app.columns
     WHERE board_id = r.board_id AND NOT is_done ORDER BY position LIMIT 1;
    IF v_col IS NULL THEN RETURN NULL; END IF;

    INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
                           due_date, tags, incoming_number, incoming_date, position, created_by,
                           recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
    VALUES (v_new, r.board_id, v_col, r.title, r.description, r.priority, r.color,
            v_next, r.tags, r.incoming_number, r.incoming_date,
            COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = v_col), 0), r.created_by,
            r.recur_freq, r.recur_interval, r.recur_weekdays, r.recur_monthday, r.recur_until);

    INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
    SELECT v_new, body, false, position, assignee_id, due_date, created_by
      FROM app.task_steps WHERE task_id = p_task;

    INSERT INTO app.task_assignees (task_id, user_id)
    SELECT v_new, user_id FROM app.task_assignees WHERE task_id = p_task
    ON CONFLICT DO NOTHING;

    INSERT INTO app.activity (task_id, actor_id, body)
    VALUES (v_new, p_actor, 'Создана по расписанию (повторение задачи)');
    RETURN v_new;
END $$;


-- Политика tasks_insert: создавать задачу может любой участник проекта.
DROP POLICY IF EXISTS tasks_insert ON app.tasks;
CREATE POLICY tasks_insert ON app.tasks FOR INSERT
    WITH CHECK (
        app.board_role(board_id, app.current_user_id()) IS NOT NULL
        AND created_by = app.current_user_id());

-- Политика tasks_update: USING и WITH CHECK используют can_edit_task (владелец, редактор проекта или автор задачи).
DROP POLICY IF EXISTS tasks_update ON app.tasks;
CREATE POLICY tasks_update ON app.tasks FOR UPDATE
    USING (app.can_edit_task(id, app.current_user_id()))
    WITH CHECK (app.can_edit_task(id, app.current_user_id()));

DROP POLICY IF EXISTS tasks_delete ON app.tasks;
CREATE POLICY tasks_delete ON app.tasks FOR DELETE
    USING (app.can_edit_task(id, app.current_user_id()));

-- Политика columns_select: колонки видит любой, кто видит проект.
DROP POLICY IF EXISTS columns_select ON app.columns;
CREATE POLICY columns_select ON app.columns FOR SELECT
    USING (app.can_see_board(board_id, app.current_user_id()));

-- Политика task_assignees_write: назначать и снимать исполнителей может редактирующий задачу или её автор.
DROP POLICY IF EXISTS task_assignees_write ON app.task_assignees;
CREATE POLICY task_assignees_write ON app.task_assignees FOR INSERT
    WITH CHECK (app.can_assign_task(task_id, app.current_user_id()));
DROP POLICY IF EXISTS task_assignees_delete ON app.task_assignees;
CREATE POLICY task_assignees_delete ON app.task_assignees FOR DELETE
    USING (app.can_assign_task(task_id, app.current_user_id()));

-- Политики task_steps: состав правит менеджер чек-листа, отметка проверяется по can_check_step в обработчике.
DROP POLICY IF EXISTS task_steps_insert ON app.task_steps;
CREATE POLICY task_steps_insert ON app.task_steps FOR INSERT
    WITH CHECK (app.can_manage_steps(task_id, app.current_user_id()));
DROP POLICY IF EXISTS task_steps_update ON app.task_steps;
CREATE POLICY task_steps_update ON app.task_steps FOR UPDATE
    USING (
        app.can_manage_steps(task_id, app.current_user_id())
        OR app.can_contribute_task(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id())))
    WITH CHECK (
        app.can_manage_steps(task_id, app.current_user_id())
        OR app.can_contribute_task(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id())));
DROP POLICY IF EXISTS task_steps_delete ON app.task_steps;
CREATE POLICY task_steps_delete ON app.task_steps FOR DELETE
    USING (app.can_manage_steps(task_id, app.current_user_id()));

-- Функция app.task_watchers предназначена для получения наблюдателей задачи для событий и уведомлений: участники проекта,
-- исполнители, обладатели точечных прав, исполнители пунктов и их заместители.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
        UNION SELECT s.assignee_id FROM app.task_steps s
               WHERE s.task_id = p_task AND s.assignee_id IS NOT NULL
    )
    SELECT user_id FROM base
    UNION
    SELECT d.deputy_id FROM base b
      JOIN app.delegations d ON d.grantor_id = b.user_id
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

