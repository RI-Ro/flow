-- Скрипт предназначен для удаления и очистки чата только у одного участника: личные отметки участника,
-- очистка у себя, удаление у себя, подсчёт непрочитанных с учётом личной границы и время голоса в опросе.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: личные отметки участника чата (граница видимости, скрытие чата).

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS cleared_at timestamptz NOT NULL DEFAULT to_timestamp(0);

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS hidden_at timestamptz;

-- Функция app.clear_chat_for_me предназначена для очистки переписки у одного участника: граница видимости и отметка прочтения сдвигаются к текущему моменту.
CREATE OR REPLACE FUNCTION app.clear_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;
    UPDATE app.chat_members
       SET cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

-- Функция app.delete_chat_for_me предназначена для удаления чата у одного участника: граница видимости и скрытие чата;
-- групповой чат при этом покидается.
CREATE OR REPLACE FUNCTION app.delete_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;

    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;

    IF v_kind = 'group' AND v_owner IS DISTINCT FROM p_user THEN
        DELETE FROM app.chat_members WHERE chat_id = p_chat AND user_id = p_user;
        RETURN true;
    END IF;

    -- Владелец группы и участники личного чата остаются в составе, чат скрывается из списка.
    UPDATE app.chat_members
       SET hidden_at = now(), cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.clear_chat_for_me(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_chat_for_me(uuid, uuid) TO app_user;

-- Функция app.chat_unread_total предназначена для подсчёта непрочитанных с учётом личной границы видимости.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > GREATEST(m.last_read_at, m.cleared_at)
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

-- Раздел 2: время голоса в опросе. Функция app.poll_option_votes предназначена для получения голосов варианта со временем голосования.
CREATE OR REPLACE FUNCTION app.poll_option_votes(p_option uuid)
RETURNS TABLE (user_id uuid, voted_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.user_id, v.voted_at
      FROM app.chat_poll_votes v
     WHERE v.option_id = p_option
     ORDER BY v.voted_at
$$;

GRANT EXECUTE ON FUNCTION app.poll_option_votes(uuid) TO app_user;

