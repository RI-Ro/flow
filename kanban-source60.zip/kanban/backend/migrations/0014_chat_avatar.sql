-- Скрипт предназначен для хранения картинки группового чата: политика доступа к файлу и функция установки и снятия картинки.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

ALTER TABLE app.chats
    ADD COLUMN IF NOT EXISTS avatar_file_id uuid REFERENCES app.files(id) ON DELETE SET NULL;

-- Политика files_select_chat_avatar: картинка чата видна его участникам; дополняет существующие политики app.files (объединение по ИЛИ).
DROP POLICY IF EXISTS files_select_chat_avatar ON app.files;
CREATE POLICY files_select_chat_avatar ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chats c
                    WHERE c.avatar_file_id = app.files.id
                      AND app.in_chat(c.id, app.current_user_id())));

-- Функция app.set_chat_avatar предназначена для установки и снятия картинки с проверкой прав владельца группового чата.
CREATE OR REPLACE FUNCTION app.set_chat_avatar(p_chat uuid, p_user uuid, p_file uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;
    IF v_kind IS DISTINCT FROM 'group' OR v_owner IS DISTINCT FROM p_user THEN
        RETURN false;
    END IF;
    UPDATE app.chats SET avatar_file_id = p_file, updated_at = now() WHERE id = p_chat;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_chat_avatar(uuid, uuid, uuid) TO app_user;

