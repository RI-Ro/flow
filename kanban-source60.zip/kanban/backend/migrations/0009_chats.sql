-- Скрипт предназначен для создания переписки между сотрудниками (личные и групповые чаты, файлы, правка и удаление
-- сообщений, владелец группы) и для пересчёта отметок просмотра задачи (три состояния).


SET search_path = app, public;

-- Таблица app.chats предназначена для хранения чатов.

CREATE TABLE IF NOT EXISTS app.chats (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    kind       text NOT NULL CHECK (kind IN ('direct', 'group')),
    -- У личного чата названия нет: он называется именем собеседника.
    title      text NOT NULL DEFAULT '',
    owner_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.chat_members предназначена для хранения участников чатов.
CREATE TABLE IF NOT EXISTS app.chat_members (
    chat_id      uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    user_id      uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    added_at     timestamptz NOT NULL DEFAULT now(),
    -- Момент, до которого прочитана переписка; число непрочитанных считается по created_at сообщений.
    last_read_at timestamptz NOT NULL DEFAULT to_timestamp(0),
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS chat_members_user_idx ON app.chat_members (user_id);

-- Таблица app.chat_messages предназначена для хранения сообщений чатов.
CREATE TABLE IF NOT EXISTS app.chat_messages (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id    uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    author_id  uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL DEFAULT '',
    -- Файл — необязательное приложение; одно на сообщение.
    file_id    uuid REFERENCES app.files(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    -- Мягкое удаление: тело очищается, сообщение остаётся в ленте.
    deleted_at timestamptz,
    CHECK (body <> '' OR file_id IS NOT NULL OR deleted_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS chat_messages_chat_idx
    ON app.chat_messages (chat_id, created_at DESC);

-- Функция app.in_chat предназначена для проверки участия в чате (SECURITY DEFINER; исключает рекурсию политик).
CREATE OR REPLACE FUNCTION app.in_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.chat_members m
                    WHERE m.chat_id = p_chat AND m.user_id = p_user)
$$;

-- Функция app.chat_owner предназначена для получения владельца чата.
CREATE OR REPLACE FUNCTION app.chat_owner(p_chat uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT owner_id FROM app.chats WHERE id = p_chat
$$;

ALTER TABLE app.chats         ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_members  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_messages ENABLE ROW LEVEL SECURITY;

-- Политика chats_select: чат виден участникам; состав задаётся отдельно в той же транзакции, что и создание.
DROP POLICY IF EXISTS chats_select ON app.chats;
CREATE POLICY chats_select ON app.chats FOR SELECT
    USING (app.in_chat(id, app.current_user_id()));

DROP POLICY IF EXISTS chats_insert ON app.chats;
CREATE POLICY chats_insert ON app.chats FOR INSERT
    WITH CHECK (app.current_user_id() IS NOT NULL);

-- Политика chats_update: групповой чат переименовывает владелец; личный не переименовывается.
DROP POLICY IF EXISTS chats_update ON app.chats;
CREATE POLICY chats_update ON app.chats FOR UPDATE
    USING (kind = 'group' AND owner_id = app.current_user_id())
    WITH CHECK (kind = 'group' AND owner_id = app.current_user_id());

DROP POLICY IF EXISTS chats_delete ON app.chats;
CREATE POLICY chats_delete ON app.chats FOR DELETE
    USING (owner_id = app.current_user_id());

-- Политики chat_members: состав виден участникам; менять его может владелец группового чата, выйти можно всегда.
DROP POLICY IF EXISTS chat_members_select ON app.chat_members;
CREATE POLICY chat_members_select ON app.chat_members FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_members_insert ON app.chat_members;
CREATE POLICY chat_members_insert ON app.chat_members FOR INSERT
    WITH CHECK (
        app.chat_owner(chat_id) = app.current_user_id()
        -- Первый участник добавляется в момент создания чата.
        OR user_id = app.current_user_id()
        OR app.chat_owner(chat_id) IS NULL
    );

-- Политика chat_members_update: участник изменяет только собственную строку (отметка прочтения).
DROP POLICY IF EXISTS chat_members_update ON app.chat_members;
CREATE POLICY chat_members_update ON app.chat_members FOR UPDATE
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

DROP POLICY IF EXISTS chat_members_delete ON app.chat_members;
CREATE POLICY chat_members_delete ON app.chat_members FOR DELETE
    USING (
        app.chat_owner(chat_id) = app.current_user_id()
        OR user_id = app.current_user_id()
    );

-- Политики chat_messages: читают участники, пишет участник от своего имени, правит и удаляет автор.
DROP POLICY IF EXISTS chat_messages_select ON app.chat_messages;
CREATE POLICY chat_messages_select ON app.chat_messages FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_messages_insert ON app.chat_messages;
CREATE POLICY chat_messages_insert ON app.chat_messages FOR INSERT
    WITH CHECK (app.in_chat(chat_id, app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.chats         TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_members  TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_messages TO app_user;
GRANT EXECUTE ON FUNCTION app.in_chat(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.chat_owner(uuid)    TO app_user;

-- Политика files_select_chat: файл переписки виден участникам чата.
DROP POLICY IF EXISTS files_select_chat ON app.files;
CREATE POLICY files_select_chat ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chat_messages m
                    WHERE m.file_id = app.files.id
                      AND app.in_chat(m.chat_id, app.current_user_id())));

-- Функция app.ensure_direct_chat предназначена для получения или создания личного чата пары пользователей без дублей.
CREATE OR REPLACE FUNCTION app.ensure_direct_chat(p_a uuid, p_b uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
BEGIN
    IF p_a IS NULL OR p_b IS NULL OR p_a = p_b THEN
        RAISE EXCEPTION 'bad_direct_chat';
    END IF;

    SELECT c.id INTO v_id
      FROM app.chats c
      JOIN app.chat_members m1 ON m1.chat_id = c.id AND m1.user_id = p_a
      JOIN app.chat_members m2 ON m2.chat_id = c.id AND m2.user_id = p_b
     WHERE c.kind = 'direct'
     LIMIT 1;

    IF v_id IS NOT NULL THEN
        RETURN v_id;
    END IF;

    INSERT INTO app.chats (kind, owner_id) VALUES ('direct', p_a) RETURNING id INTO v_id;
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_a), (v_id, p_b);
    RETURN v_id;
END $$;

GRANT EXECUTE ON FUNCTION app.ensure_direct_chat(uuid, uuid) TO app_user;

-- Функция app.chat_watchers предназначена для получения состава чата для рассылки событий (SECURITY DEFINER:
-- рассылка выполняется без пользовательского контекста).
CREATE OR REPLACE FUNCTION app.chat_watchers(p_chat uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT user_id FROM app.chat_members WHERE chat_id = p_chat
$$;

GRANT EXECUTE ON FUNCTION app.chat_watchers(uuid) TO app_user;

-- Функция app.chat_unread_total предназначена для подсчёта непрочитанных по всем чатам.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > m.last_read_at
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_unread_total(uuid) TO app_user;

-- Раздел 2: отметки просмотра задачи. Состояния: серая галочка — исполнитель открывал задачу; зелёная — открывал после
-- последнего изменения; две зелёные — отметил свою часть выполненной. Последнее изменение — максимум из tasks.updated_at
-- и последней записи журнала, исключая действия самого исполнителя.
-- Функция app.assignees_seen предназначена для получения исполнителей, открывавших задачу.

CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- Функция app.assignees_fresh предназначена для получения исполнителей, чей просмотр новее последнего изменения задачи.
CREATE OR REPLACE FUNCTION app.assignees_fresh(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task'
       AND v.entity_id = p_task
       AND v.viewed_at >= app.task_activity_at(p_task, v.user_id)
$$;

GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_fresh(uuid) TO app_user;

