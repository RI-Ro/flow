-- Скрипт предназначен для создания двух областей: диаграмм Ганта (этапы работ со сроками, связи «следующий за»,
-- ссылки на задачи проектов) и совместных досок (холст с фигурами, стикерами, линиями и текстом).
--
-- Модель прав обеих областей совпадает с моделью проектов (app.board_role, app.can_edit_board): владелец, редактор,
-- исполнитель; для каждой области используется отдельная таблица участников. Замещение учитывается через app.effective_users.
--
-- Записи диаграмм не являются задачами: они не попадают в календарь, список «Все задачи» и уведомления по задачам.
-- Связь с задачей проекта выполняется необязательной ссылкой.
--
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0020_charts_whiteboards.sql
--
-- Выполняется от app_owner после 0019_ready_into_report.sql, идемпотентен.


SET search_path = app, public;

-- Раздел 1: диаграммы. Таблица app.charts предназначена для хранения диаграмм.

CREATE TABLE IF NOT EXISTS app.charts (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    -- Параметры вида диаграммы: масштаб (день, неделя, месяц), показ выходных, цвет по умолчанию и другие.
    settings    jsonb NOT NULL DEFAULT '{}'::jsonb,
    position    integer NOT NULL DEFAULT 0,
    archived    boolean NOT NULL DEFAULT false,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.chart_members предназначена для хранения участников диаграмм и их ролей.
CREATE TABLE IF NOT EXISTS app.chart_members (
    chart_id uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)  ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (chart_id, user_id)
);

CREATE INDEX IF NOT EXISTS chart_members_user_idx ON app.chart_members (user_id);

-- Таблица app.chart_items предназначена для хранения записей (этапов) диаграммы. Запись самостоятельна: свои название, даты
-- и прогресс; с задачами связана только ссылками из app.chart_item_tasks.
CREATE TABLE IF NOT EXISTS app.chart_items (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chart_id    uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    starts_on   date NOT NULL,
    ends_on     date NOT NULL,
    -- Процент готовности отображается заливкой полосы; диапазон 0–100 проверяется на уровне БД.
    progress    smallint NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    color       text NOT NULL DEFAULT '',
    -- Признак вехи: событие без длительности, ends_on равен starts_on.
    milestone   boolean NOT NULL DEFAULT false,
    position    integer NOT NULL DEFAULT 0,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    -- Ограничение: конец не раньше начала.
    CHECK (ends_on >= starts_on)
);

CREATE INDEX IF NOT EXISTS chart_items_chart_idx ON app.chart_items (chart_id, position);

-- Таблица app.chart_links предназначена для хранения связей «следующий за»: направленных, без петель на себя; дубли исключены первичным ключом.
CREATE TABLE IF NOT EXISTS app.chart_links (
    from_item uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    to_item   uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    PRIMARY KEY (from_item, to_item),
    CHECK (from_item <> to_item)
);

CREATE INDEX IF NOT EXISTS chart_links_to_idx ON app.chart_links (to_item);

-- Таблица app.chart_item_tasks предназначена для хранения ссылок записей на задачи. При удалении задачи ссылка удаляется каскадно.
CREATE TABLE IF NOT EXISTS app.chart_item_tasks (
    item_id uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    task_id uuid NOT NULL REFERENCES app.tasks(id)       ON DELETE CASCADE,
    PRIMARY KEY (item_id, task_id)
);

CREATE INDEX IF NOT EXISTS chart_item_tasks_task_idx ON app.chart_item_tasks (task_id);

-- Функция app.chart_role предназначена для определения роли пользователя в диаграмме с учётом замещения (аналог app.board_role).
CREATE OR REPLACE FUNCTION app.chart_role(p_chart uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.chart_members m
     WHERE m.chart_id = p_chart
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_see_chart предназначена для проверки права просмотра диаграммы.
CREATE OR REPLACE FUNCTION app.can_see_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IS NOT NULL $$;

-- Функция app.can_edit_chart предназначена для проверки права редактирования диаграммы.
CREATE OR REPLACE FUNCTION app.can_edit_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_chart_owner предназначена для проверки, что пользователь является владельцем диаграммы.
CREATE OR REPLACE FUNCTION app.is_chart_owner(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) = 'owner' $$;

-- Функция app.chart_watchers предназначена для получения получателей событий диаграммы: участников и их заместителей.
CREATE OR REPLACE FUNCTION app.chart_watchers(p_chart uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.chart_members m WHERE m.chart_id = p_chart
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.chart_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.chart_id = p_chart
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.chart_owner_bootstrap предназначена для записи владельца в участники сразу после создания диаграммы:
-- до этого владелец не проходит политику chart_members.
CREATE OR REPLACE FUNCTION app.chart_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.chart_members (chart_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS charts_owner_bootstrap ON app.charts;
-- Триггер charts_owner_bootstrap предназначен для вызова app.chart_owner_bootstrap после вставки в app.charts.
CREATE TRIGGER charts_owner_bootstrap AFTER INSERT ON app.charts
    FOR EACH ROW EXECUTE FUNCTION app.chart_owner_bootstrap();

-- Функция app.chart_task_brief предназначена для получения названия задачи, если она видна пользователю, иначе NULL:
-- ссылка на чужую задачу не раскрывает заголовок (аналог app.task_title_visible).
CREATE OR REPLACE FUNCTION app.chart_task_brief(p_task uuid, p_user uuid)
RETURNS TABLE (task_id uuid, title text, board_title text, completed boolean, visible boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.id,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.title ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN app.board_title(t.board_id) ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.completed_at IS NOT NULL ELSE false END,
           app.can_see_task(t.id, p_user)
      FROM app.tasks t
     WHERE t.id = p_task
$$;

ALTER TABLE app.charts           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_items      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_item_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS charts_select ON app.charts;
CREATE POLICY charts_select ON app.charts FOR SELECT
    USING (app.can_see_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_insert ON app.charts;
CREATE POLICY charts_insert ON app.charts FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Политики изменения диаграммы: название и параметры вида правят владелец и редактор.
DROP POLICY IF EXISTS charts_update ON app.charts;
CREATE POLICY charts_update ON app.charts FOR UPDATE
    USING (app.can_edit_chart(id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_delete ON app.charts;
CREATE POLICY charts_delete ON app.charts FOR DELETE
    USING (app.is_chart_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_select ON app.chart_members;
CREATE POLICY chart_members_select ON app.chart_members FOR SELECT
    USING (app.chart_role(chart_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS chart_members_write ON app.chart_members;
CREATE POLICY chart_members_write ON app.chart_members FOR INSERT
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_update ON app.chart_members;
CREATE POLICY chart_members_update ON app.chart_members FOR UPDATE
    USING (app.is_chart_owner(chart_id, app.current_user_id()))
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_delete ON app.chart_members;
CREATE POLICY chart_members_delete ON app.chart_members FOR DELETE
    USING (
        (app.is_chart_owner(chart_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS chart_items_select ON app.chart_items;
CREATE POLICY chart_items_select ON app.chart_items FOR SELECT
    USING (app.can_see_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_write ON app.chart_items;
CREATE POLICY chart_items_write ON app.chart_items FOR INSERT
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id())
                AND created_by = app.current_user_id());

DROP POLICY IF EXISTS chart_items_update ON app.chart_items;
CREATE POLICY chart_items_update ON app.chart_items FOR UPDATE
    USING (app.can_edit_chart(chart_id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_delete ON app.chart_items;
CREATE POLICY chart_items_delete ON app.chart_items FOR DELETE
    USING (app.can_edit_chart(chart_id, app.current_user_id()));

-- Функция app.chart_of_item предназначена для определения диаграммы по записи: права связей и ссылок на задачи наследуются от записи.
CREATE OR REPLACE FUNCTION app.chart_of_item(p_item uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT chart_id FROM app.chart_items WHERE id = p_item $$;

DROP POLICY IF EXISTS chart_links_select ON app.chart_links;
CREATE POLICY chart_links_select ON app.chart_links FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_links_write ON app.chart_links;
CREATE POLICY chart_links_write ON app.chart_links FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id())
        -- Связывать можно только записи одной диаграммы.
        AND app.chart_of_item(from_item) = app.chart_of_item(to_item));

DROP POLICY IF EXISTS chart_links_delete ON app.chart_links;
CREATE POLICY chart_links_delete ON app.chart_links FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_select ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_select ON app.chart_item_tasks FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Привязывать можно только видимую пользователю задачу: это исключает привязку к чужой задаче по подобранному идентификатору.
DROP POLICY IF EXISTS chart_item_tasks_write ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_write ON app.chart_item_tasks FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id())
        AND app.can_see_task(task_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_delete ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_delete ON app.chart_item_tasks FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Раздел 2: совместные доски. Таблица app.whiteboards предназначена для хранения досок.

CREATE TABLE IF NOT EXISTS app.whiteboards (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    position   integer NOT NULL DEFAULT 0,
    archived   boolean NOT NULL DEFAULT false,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Таблица app.whiteboard_members предназначена для хранения участников досок и их ролей.
CREATE TABLE IF NOT EXISTS app.whiteboard_members (
    board_id uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)       ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (board_id, user_id)
);

CREATE INDEX IF NOT EXISTS whiteboard_members_user_idx ON app.whiteboard_members (user_id);

-- Таблица app.whiteboard_shapes предназначена для хранения фигур на холсте. Геометрия (x, y, w, h, angle, z) хранится
-- в колонках для быстрой выборки и перетаскивания, прочие свойства — в JSON.
CREATE TABLE IF NOT EXISTS app.whiteboard_shapes (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id   uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    kind       text NOT NULL CHECK (kind IN
                 ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                  'line', 'arrow', 'draw', 'image', 'frame')),
    x          double precision NOT NULL DEFAULT 0,
    y          double precision NOT NULL DEFAULT 0,
    w          double precision NOT NULL DEFAULT 160,
    h          double precision NOT NULL DEFAULT 120,
    angle      double precision NOT NULL DEFAULT 0,
    z          integer NOT NULL DEFAULT 0,
    data       jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    updated_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS whiteboard_shapes_board_idx ON app.whiteboard_shapes (board_id, z);

-- Функция app.wb_role предназначена для определения роли пользователя в доске.
CREATE OR REPLACE FUNCTION app.wb_role(p_board uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.whiteboard_members m
     WHERE m.board_id = p_board
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

-- Функция app.can_see_wb предназначена для проверки права просмотра доски.
CREATE OR REPLACE FUNCTION app.can_see_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IS NOT NULL $$;

-- Функция app.can_edit_wb предназначена для проверки права редактирования доски.
CREATE OR REPLACE FUNCTION app.can_edit_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IN ('owner', 'editor') $$;

-- Функция app.is_wb_owner предназначена для проверки, что пользователь является владельцем доски.
CREATE OR REPLACE FUNCTION app.is_wb_owner(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) = 'owner' $$;

-- Функция app.wb_watchers предназначена для получения получателей событий доски.
CREATE OR REPLACE FUNCTION app.wb_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.whiteboard_members m WHERE m.board_id = p_board
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.whiteboard_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.board_id = p_board
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Функция app.wb_owner_bootstrap предназначена для записи владельца в участники сразу после создания доски.
CREATE OR REPLACE FUNCTION app.wb_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS whiteboards_owner_bootstrap ON app.whiteboards;
-- Триггер whiteboards_owner_bootstrap предназначен для вызова app.wb_owner_bootstrap после вставки в app.whiteboards.
CREATE TRIGGER whiteboards_owner_bootstrap AFTER INSERT ON app.whiteboards
    FOR EACH ROW EXECUTE FUNCTION app.wb_owner_bootstrap();

ALTER TABLE app.whiteboards        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_shapes  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS whiteboards_select ON app.whiteboards;
CREATE POLICY whiteboards_select ON app.whiteboards FOR SELECT
    USING (app.can_see_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_insert ON app.whiteboards;
CREATE POLICY whiteboards_insert ON app.whiteboards FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

DROP POLICY IF EXISTS whiteboards_update ON app.whiteboards;
CREATE POLICY whiteboards_update ON app.whiteboards FOR UPDATE
    USING (app.can_edit_wb(id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_delete ON app.whiteboards;
CREATE POLICY whiteboards_delete ON app.whiteboards FOR DELETE
    USING (app.is_wb_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_select ON app.whiteboard_members;
CREATE POLICY whiteboard_members_select ON app.whiteboard_members FOR SELECT
    USING (app.wb_role(board_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS whiteboard_members_write ON app.whiteboard_members;
CREATE POLICY whiteboard_members_write ON app.whiteboard_members FOR INSERT
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_update ON app.whiteboard_members;
CREATE POLICY whiteboard_members_update ON app.whiteboard_members FOR UPDATE
    USING (app.is_wb_owner(board_id, app.current_user_id()))
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_delete ON app.whiteboard_members;
CREATE POLICY whiteboard_members_delete ON app.whiteboard_members FOR DELETE
    USING (
        (app.is_wb_owner(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS whiteboard_shapes_select ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_select ON app.whiteboard_shapes FOR SELECT
    USING (app.can_see_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_write ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_write ON app.whiteboard_shapes FOR INSERT
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id())
                AND created_by = app.current_user_id());

-- Политика whiteboard_shapes_update: фигуры правит любой редактор доски, не только автор фигуры.
DROP POLICY IF EXISTS whiteboard_shapes_update ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_update ON app.whiteboard_shapes FOR UPDATE
    USING (app.can_edit_wb(board_id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_delete ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_delete ON app.whiteboard_shapes FOR DELETE
    USING (app.can_edit_wb(board_id, app.current_user_id()));

-- Раздел 3: привилегии роли app_user на таблицы диаграмм и досок.
GRANT SELECT, INSERT, UPDATE, DELETE ON app.charts             TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_members      TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_items        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_links        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_item_tasks   TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboards        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_members TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_shapes  TO app_user;

GRANT EXECUTE ON FUNCTION app.chart_role(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_chart(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_chart(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.is_chart_owner(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_watchers(uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_of_item(uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_task_brief(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_role(uuid, uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_wb(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_wb(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.is_wb_owner(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_watchers(uuid)             TO app_user;

