-- Скрипт предназначен для отметки «задача готова к сдаче», окна правки сообщений в переписке (как у комментариев)
-- и исправления настройки уведомлений по чужим задачам в функции app.notify_task_watchers.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Раздел 1: готовность к сдаче. Состояние между «в работе» и «завершено»: исполнитель закончил работу и ожидает приёмки.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS ready_at timestamptz,
    ADD COLUMN IF NOT EXISTS ready_by uuid REFERENCES app.users(id) ON DELETE SET NULL;

-- Функция app.set_task_ready предназначена для установки и снятия отметки готовности: ставит исполнитель, снимает исполнитель, автор или редактор проекта.
CREATE OR REPLACE FUNCTION app.set_task_ready(p_task uuid, p_user uuid, p_ready boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_assignee boolean;
    v_manage boolean;
BEGIN
    SELECT EXISTS (SELECT 1 FROM app.task_assignees a
                    WHERE a.task_id = p_task
                      AND a.user_id IN (SELECT app.effective_users(p_user)))
      INTO v_assignee;
    SELECT app.task_access(p_task, p_user) = 'edit' INTO v_manage;

    IF p_ready AND NOT v_assignee THEN
        RETURN false;
    END IF;
    IF NOT p_ready AND NOT (v_assignee OR v_manage) THEN
        RETURN false;
    END IF;

    UPDATE app.tasks
       SET ready_at = CASE WHEN p_ready THEN now() ELSE NULL END,
           ready_by = CASE WHEN p_ready THEN p_user ELSE NULL END
     WHERE id = p_task;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.set_task_ready(uuid, uuid, boolean) TO app_user;

-- Функция app.drop_ready_on_complete предназначена для снятия отметки готовности при завершении задачи; при возврате в работу отметка не восстанавливается.
CREATE OR REPLACE FUNCTION app.drop_ready_on_complete() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.completed_at IS NOT NULL AND OLD.completed_at IS NULL THEN
        NEW.ready_at := NULL;
        NEW.ready_by := NULL;
    END IF;
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_ready ON app.tasks;
-- Триггер tasks_drop_ready предназначен для вызова app.drop_ready_on_complete при изменении задачи.
CREATE TRIGGER tasks_drop_ready BEFORE UPDATE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_ready_on_complete();

CREATE INDEX IF NOT EXISTS tasks_ready_idx ON app.tasks (ready_at)
    WHERE ready_at IS NOT NULL;

-- Раздел 2: окно правки сообщений. Политики chat_messages_update и chat_messages_delete: автор изменяет и удаляет сообщение в течение часа, как у комментариев.
DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    )
    WITH CHECK (
        author_id = app.current_user_id()
        AND created_at > now() - interval '1 hour'
    );

-- Раздел 3: уведомления по чужим задачам. Функция app.notify_task_watchers применяет настройку во всех путях рассылки (комментарии, чек-лист, вложения).
CREATE OR REPLACE FUNCTION app.notify_task_watchers(
    p_task uuid, p_actor uuid, p_body text)
RETURNS SETOF uuid
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    INSERT INTO app.notifications (user_id, body, board_id, task_id)
    SELECT DISTINCT w.user_id, p_body, t.board_id, t.id
      FROM app.tasks t
      CROSS JOIN LATERAL app.task_watchers(t.id) AS w(user_id)
      JOIN app.users u ON u.id = w.user_id
     WHERE t.id = p_task
       -- Инициатор не уведомляется; проверка выполняется по всем его действующим личностям.
       AND w.user_id <> ALL (SELECT app.effective_users(p_actor))
       -- Отключённым и удалённым пользователям уведомления не создаются.
       AND u.deleted_at IS NULL AND u.is_active
       -- Настройка «уведомления по задачам, где я не исполнитель»; собственные задачи пользователя уведомляются всегда.
       AND (
         EXISTS (SELECT 1 FROM app.task_assignees a
                  WHERE a.task_id = t.id AND a.user_id = w.user_id)
         OR EXISTS (SELECT 1 FROM app.task_grants g
                     WHERE g.task_id = t.id AND g.user_id = w.user_id)
         OR t.created_by = w.user_id
         OR app.wants_foreign_task_notifs(w.user_id)
       )
    RETURNING notifications.user_id
$$;

GRANT EXECUTE ON FUNCTION app.notify_task_watchers(uuid, uuid, text) TO app_user;

