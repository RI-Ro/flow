-- Скрипт предназначен для единых правил изменения вложений задач независимо от формата файла:
-- переименовать и удалить вложение может его автор или тот, кто вправе править задачу (политики attachments_update
-- и attachments_delete). Ограничение в один час отменено.
-- Выполняется от app_owner после 0014_chat_avatar.sql, идемпотентен:
-- psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0015_attachment_rules.sql


SET search_path = app, public;

DROP POLICY IF EXISTS attachments_update ON app.attachments;
CREATE POLICY attachments_update ON app.attachments FOR UPDATE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    )
    WITH CHECK (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

DROP POLICY IF EXISTS attachments_delete ON app.attachments;
CREATE POLICY attachments_delete ON app.attachments FOR DELETE
    USING (
        author_id = app.current_user_id()
        OR app.can_edit_task(task_id, app.current_user_id())
    );

