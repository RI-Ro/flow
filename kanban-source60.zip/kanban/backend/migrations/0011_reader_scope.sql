-- Скрипт предназначен для ограничения видимости: участник проекта с ролью «исполнитель» видит только свои задачи.
-- Функция app.task_access пересоздаётся: членство в проекте само по себе не открывает все задачи.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Функция app.task_access предназначена для определения уровня доступа к задаче с ограничением видимости для роли «исполнитель».
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Автор задачи имеет полный доступ независимо от роли в проекте.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'edit';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    -- Исполнитель пункта чек-листа видит задачу целиком.
    IF EXISTS (SELECT 1 FROM app.task_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    -- Условие «читатель проекта видит все задачи» удалено: доступ определяется назначением, авторством или точечным правом.
    RETURN NULL;
END $$;

