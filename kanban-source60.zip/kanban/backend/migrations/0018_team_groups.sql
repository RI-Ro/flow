-- Скрипт предназначен для создания групп внутри личной команды: таблицы групп и их участников, политика доступа.
-- Выполняется от app_owner, идемпотентен.


SET search_path = app, public;

-- Таблица app.team_groups предназначена для хранения групп личной команды.
CREATE TABLE IF NOT EXISTS app.team_groups (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    title      text NOT NULL CHECK (btrim(title) <> ''),
    -- Порядок групп задаёт владелец.
    position   int  NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS team_groups_owner_idx ON app.team_groups (owner_id, position);

-- Таблица app.team_group_members предназначена для хранения участников групп.
CREATE TABLE IF NOT EXISTS app.team_group_members (
    group_id  uuid NOT NULL REFERENCES app.team_groups(id) ON DELETE CASCADE,
    -- Поле owner_id дублируется: оно необходимо для составного внешнего ключа на team_members.
    owner_id  uuid NOT NULL,
    member_id uuid NOT NULL,
    PRIMARY KEY (group_id, member_id),
    FOREIGN KEY (owner_id, member_id)
        REFERENCES app.team_members (owner_id, member_id) ON DELETE CASCADE
);

ALTER TABLE app.team_groups        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.team_group_members ENABLE ROW LEVEL SECURITY;

-- Политика team_groups_own: группы видит и изменяет только их владелец.
DROP POLICY IF EXISTS team_groups_own ON app.team_groups;
CREATE POLICY team_groups_own ON app.team_groups FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

DROP POLICY IF EXISTS team_group_members_own ON app.team_group_members;
CREATE POLICY team_group_members_own ON app.team_group_members FOR ALL
    USING (owner_id = app.current_user_id())
    WITH CHECK (owner_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_groups        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.team_group_members TO app_user;

