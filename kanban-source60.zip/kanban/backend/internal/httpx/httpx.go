// Модуль предназначен для единообразных JSON-ответов, преобразования ошибок в HTTP-ответы
// и строгого разбора параметров запроса.

package httpx

import (
	"bytes"
	"encoding/json"
	"errors"
	"log/slog"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgconn"
)

// Тип ErrorBody предназначен для тела ответа с ошибкой.
type ErrorBody struct {
	Error string `json:"error"`
	Code  string `json:"code,omitempty"`
	// Подробности ошибки БД; заполняются только вне production.
	Details map[string]string `json:"details,omitempty"`
}

// Тип APIError предназначен для ошибки с HTTP-статусом и кодом.
type APIError struct {
	Status  int
	Code    string
	Message string
}

// Метод Error предназначен для получения текста ошибки.
func (e APIError) Error() string { return e.Message }

// Функция Err предназначена для создания APIError.
func Err(status int, code, msg string) APIError {
	return APIError{Status: status, Code: code, Message: msg}
}

var (
	ErrUnauthorized = Err(fiber.StatusUnauthorized, "unauthorized", "Требуется вход в систему")
	ErrForbidden    = Err(fiber.StatusForbidden, "forbidden", "Недостаточно прав")
	ErrNotFound     = Err(fiber.StatusNotFound, "not_found", "Объект не найден или недоступен")
	ErrBadRequest   = Err(fiber.StatusBadRequest, "bad_request", "Некорректный запрос")
)

// Функция JSON предназначена для отправки JSON-ответа с заданным статусом.
func JSON(c *fiber.Ctx, status int, body any) error {
	return c.Status(status).JSON(body)
}

// Функция NoContent предназначена для отправки ответа 204.
func NoContent(c *fiber.Ctx) error { return c.SendStatus(fiber.StatusNoContent) }

// Функция Fail предназначена для преобразования ошибки в ответ; возвращает nil, так как ответ уже записан.
// Отсутствие строки под RLS возвращается как 404, чтобы не раскрывать существование идентификаторов.
func Fail(c *fiber.Ctx, err error) error {
	// Вызов с nil-ошибкой обрабатывается без паники.
	if err == nil {
		slog.Error("Fail вызван без ошибки", "path", c.Path(), "method", c.Method())
		return JSON(c, fiber.StatusInternalServerError,
			ErrorBody{Error: "Внутренняя ошибка сервера", Code: "internal"})
	}

	var apiErr APIError
	if errors.As(err, &apiErr) {
		return JSON(c, apiErr.Status, ErrorBody{Error: apiErr.Message, Code: apiErr.Code})
	}

	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) {
		switch pgErr.Code {
		case "23505":
			return JSON(c, fiber.StatusConflict, ErrorBody{Error: "Такая запись уже существует", Code: "conflict"})
		case "23503":
			return JSON(c, fiber.StatusBadRequest, ErrorBody{Error: "Ссылка на несуществующий объект", Code: "bad_reference"})
		case "23514":
			return JSON(c, fiber.StatusBadRequest, ErrorBody{Error: "Значение не прошло проверку", Code: "check_failed"})
		case "42501":
			// Отказ RLS: вне production в ответ добавляются таблица и текст ошибки СУБД.
			slog.Warn("отказ политики доступа",
				"table", pgErr.TableName, "message", pgErr.Message,
				"detail", pgErr.Detail, "path", c.Path(), "method", c.Method())
			if !isProduction() {
				return JSON(c, fiber.StatusForbidden, ErrorBody{
					Error: "Недостаточно прав: " + pgErr.Message,
					Code:  "forbidden",
					Details: map[string]string{
						"table":  pgErr.TableName,
						"detail": pgErr.Detail,
						"hint":   pgErr.Hint,
					},
				})
			}
			return JSON(c, fiber.StatusForbidden, ErrorBody{Error: "Недостаточно прав", Code: "forbidden"})
		}
	}

	// Подробности ошибки PostgreSQL записываются в журнал и вне production добавляются в ответ.
	if pgErr != nil {
		slog.Error("ошибка базы данных",
			"code", pgErr.Code, "message", pgErr.Message, "detail", pgErr.Detail,
			"table", pgErr.TableName, "column", pgErr.ColumnName,
			"constraint", pgErr.ConstraintName,
			"path", c.Path(), "method", c.Method())

		if !isProduction() {
			return JSON(c, fiber.StatusInternalServerError, ErrorBody{
				Error: "Ошибка базы данных: " + pgErr.Message,
				Code:  "db_" + pgErr.Code,
				Details: map[string]string{
					"detail":     pgErr.Detail,
					"table":      pgErr.TableName,
					"column":     pgErr.ColumnName,
					"constraint": pgErr.ConstraintName,
					"hint":       pgErr.Hint,
				},
			})
		}
	} else {
		slog.Error("внутренняя ошибка", "error", err, "path", c.Path(), "method", c.Method())
		if !isProduction() {
			return JSON(c, fiber.StatusInternalServerError, ErrorBody{
				Error: "Внутренняя ошибка: " + err.Error(),
				Code:  "internal",
			})
		}
	}

	return JSON(c, fiber.StatusInternalServerError, ErrorBody{Error: "Внутренняя ошибка сервера", Code: "internal"})
}

// Флаг production задаётся при запуске; пакет не зависит от config.
var production bool

// Функция SetProduction предназначена для установки режима production.
func SetProduction(v bool) { production = v }
// Функция isProduction предназначена для чтения режима production.
func isProduction() bool   { return production }

// Функция Decode предназначена для строгого разбора JSON тела запроса: неизвестные поля являются ошибкой.
func Decode(c *fiber.Ctx, dst any) error {
	body := c.Body()
	if len(body) == 0 {
		return nil
	}
	dec := json.NewDecoder(bytes.NewReader(body))
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		return Err(fiber.StatusBadRequest, "malformed_json", "Не удалось разобрать тело запроса: "+err.Error())
	}
	return nil
}

// Функция UUIDParam предназначена для разбора UUID из параметра маршрута.
func UUIDParam(c *fiber.Ctx, name string) (uuid.UUID, error) {
	id, err := uuid.Parse(c.Params(name))
	if err != nil {
		return uuid.Nil, Err(fiber.StatusBadRequest, "bad_uuid", "Некорректный идентификатор «"+name+"»")
	}
	return id, nil
}

// Функция QueryInt предназначена для чтения целочисленного параметра запроса с границами и значением по умолчанию.
func QueryInt(c *fiber.Ctx, name string, def, min, max int) int {
	v, err := strconv.Atoi(c.Query(name))
	if err != nil {
		return def
	}
	if v < min {
		return min
	}
	if v > max {
		return max
	}
	return v
}
