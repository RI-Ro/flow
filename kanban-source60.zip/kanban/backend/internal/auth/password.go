// Модуль предназначен для проверки пароля по единому правилу: длина и разнообразие символов.

package auth

import (
	"fmt"
	"strings"
	"unicode"
	"unicode/utf8"
)

// Константы правила пароля, общего для регистрации, смены пароля и создания пользователя администратором.
const (
	// PasswordMinLen — минимальная длина в символах.
	PasswordMinLen = 8
	// PasswordMinClasses — минимальное число типов символов из четырёх.
	PasswordMinClasses = 3
	// PasswordMaxBytes — предел bcrypt в 72 байта; более длинные пароли отклоняются.
	PasswordMaxBytes = 72
)

// Константа PasswordRule задаёт текст требований к паролю для интерфейса и сообщений об ошибках.
const PasswordRule = "Пароль должен быть не короче 8 символов и содержать символы минимум трёх типов из четырёх: строчные буквы, заглавные буквы, цифры, знаки."

// Функция PasswordClasses предназначена для определения типов символов пароля (строчные, заглавные, цифры, прочие) по таблицам Unicode.
func PasswordClasses(p string) (lower, upper, digit, special bool) {
	for _, r := range p {
		switch {
		case unicode.IsLower(r):
			lower = true
		case unicode.IsUpper(r) || unicode.IsTitle(r):
			upper = true
		case unicode.IsDigit(r):
			digit = true
		default:
			// Прочие символы: знаки препинания, пробел и всё, что не буква и не цифра.
			special = true
		}
	}
	return
}

// Функция PasswordClassCount предназначена для подсчёта задействованных типов символов.
func PasswordClassCount(p string) int {
	lower, upper, digit, special := PasswordClasses(p)
	n := 0
	for _, ok := range []bool{lower, upper, digit, special} {
		if ok {
			n++
		}
	}
	return n
}

// Функция ValidatePassword предназначена для проверки пароля по правилу и формирования описания нарушения.
func ValidatePassword(p string) error {
	if n := utf8.RuneCountInString(p); n < PasswordMinLen {
		return fmt.Errorf("Пароль короче %d символов (сейчас %d). %s",
			PasswordMinLen, n, PasswordRule)
	}
	if len(p) > PasswordMaxBytes {
		return fmt.Errorf("Пароль слишком длинный: допустимо до %d байт",
			PasswordMaxBytes)
	}
	if strings.TrimSpace(p) == "" {
		return fmt.Errorf("Пароль не может состоять из одних пробелов")
	}

	lower, upper, digit, special := PasswordClasses(p)
	if n := PasswordClassCount(p); n < PasswordMinClasses {
		var missing []string
		if !lower {
			missing = append(missing, "строчных букв")
		}
		if !upper {
			missing = append(missing, "заглавных букв")
		}
		if !digit {
			missing = append(missing, "цифр")
		}
		if !special {
			missing = append(missing, "знаков (!, ?, -, _ и подобных)")
		}
		// Формулировка не склоняет слово «типов».
		return fmt.Errorf("В пароле задействовано типов символов: %d из четырёх, "+
			"нужно %d. Не хватает: %s", n, PasswordMinClasses, strings.Join(missing, ", "))
	}
	return nil
}
