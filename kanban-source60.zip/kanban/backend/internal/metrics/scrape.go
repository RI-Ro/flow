// Модуль предназначен для разбора текстовой выдачи метрик в формате Prometheus и выборки значений.

package metrics

import (
	"math"
	"strconv"
	"strings"
	"time"
)


// Тип LabeledValue предназначен для описания значения серии вместе с метками.
type LabeledValue struct {
	Labels map[string]string
	Value  float64
}

// Тип Scrape предназначен для хранения разобранного снимка метрик.
type Scrape struct {
	At     time.Time
	Series map[string][]LabeledValue
}

// Функция ParseScrape предназначена для разбора текста в формате Prometheus.
func ParseScrape(text string, at time.Time) *Scrape {
	s := &Scrape{At: at, Series: map[string][]LabeledValue{}}
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || line[0] == '#' {
			continue
		}
		name, lbl, val, ok := parseLine(line)
		if !ok || !isFinite(val) {
			// Значения NaN и ±Inf отбрасываются: encoding/json их не кодирует.
			continue
		}
		s.Series[name] = append(s.Series[name], LabeledValue{Labels: lbl, Value: val})
	}
	return s
}

// Функция isFinite предназначена для проверки, что число конечное.
func isFinite(v float64) bool {
	return !math.IsNaN(v) && !math.IsInf(v, 0)
}

// Функция parseLine предназначена для разбора строки метрики на имя, метки и значение.
func parseLine(line string) (name string, lbl map[string]string, val float64, ok bool) {
	// Значение отделяется последним пробелом.
	sp := strings.LastIndexByte(line, ' ')
	if sp < 0 {
		return "", nil, 0, false
	}
	v, err := strconv.ParseFloat(strings.TrimSpace(line[sp+1:]), 64)
	if err != nil {
		return "", nil, 0, false
	}
	head := strings.TrimSpace(line[:sp])

	if br := strings.IndexByte(head, '{'); br >= 0 {
		if !strings.HasSuffix(head, "}") {
			return "", nil, 0, false
		}
		return head[:br], parseLabels(head[br+1 : len(head)-1]), v, true
	}
	return head, nil, v, true
}

// Функция parseLabels предназначена для разбора меток вида a="1",b="2" с разэкранированием значений.
func parseLabels(s string) map[string]string {
	out := map[string]string{}
	for len(s) > 0 {
		eq := strings.IndexByte(s, '=')
		if eq < 0 {
			break
		}
		key := strings.TrimSpace(s[:eq])
		rest := s[eq+1:]
		if len(rest) == 0 || rest[0] != '"' {
			break
		}
		var b strings.Builder
		i := 1
		for i < len(rest) {
			if rest[i] == '\\' && i+1 < len(rest) {
				switch rest[i+1] {
				case 'n':
					b.WriteByte('\n')
				default:
					b.WriteByte(rest[i+1])
				}
				i += 2
				continue
			}
			if rest[i] == '"' {
				break
			}
			b.WriteByte(rest[i])
			i++
		}
		out[key] = b.String()
		s = strings.TrimPrefix(strings.TrimSpace(rest[min(i+1, len(rest)):]), ",")
	}
	return out
}


// Метод Sum предназначен для суммирования всех серий метрики.
func (s *Scrape) Sum(name string, match ...string) float64 {
	var total float64
	for _, lv := range s.Series[name] {
		if lv.matches(match) {
			total += lv.Value
		}
	}
	return total
}

// Метод One предназначен для получения единственного значения метрики без меток.
func (s *Scrape) One(name string) float64 {
	if v := s.Series[name]; len(v) > 0 {
		return v[0].Value
	}
	return 0
}

// Метод By предназначен для группировки метрики по значению одной метки.
func (s *Scrape) By(name, label string) map[string]float64 {
	out := map[string]float64{}
	for _, lv := range s.Series[name] {
		out[lv.Labels[label]] += lv.Value
	}
	return out
}

// Метод Buckets предназначен для суммирования ступеней гистограммы по границам; «+Inf» отбрасывается.
func (s *Scrape) Buckets(name string, match ...string) map[float64]float64 {
	out := map[float64]float64{}
	for _, lv := range s.Series[name] {
		if !lv.matches(match) {
			continue
		}
		le := lv.Labels["le"]
		if le == "" || le == "+Inf" {
			continue
		}
		b, err := strconv.ParseFloat(le, 64)
		if err != nil {
			continue
		}
		out[b] += lv.Value
	}
	return out
}

// Метод matches предназначен для проверки пар «метка, значение»; значения через запятую означают «любое из»,
// префикс «~» — сравнение по первому символу кода ответа.
func (lv LabeledValue) matches(match []string) bool {
	for i := 0; i+1 < len(match); i += 2 {
		have := lv.Labels[match[i]]
		want := match[i+1]
		if strings.HasPrefix(want, "~") {
			if !strings.HasPrefix(have, want[1:]) {
				return false
			}
			continue
		}
		if have != want {
			return false
		}
	}
	return true
}
