// Модуль предназначен для построения сводки для встроенного дашборда: скорости, перцентили и доли ошибок
// рассчитываются по накопленным показаниям за выбранный период.

package metrics

import (
	"sort"
	"strings"
	"time"
)


// Тип Point предназначен для описания одной точки всех графиков на общей временной оси.
type Point struct {
	T int64 `json:"t"` // unix-время в миллисекундах

	RPS    float64 `json:"rps"`
	RPS2xx float64 `json:"rps2xx"`
	RPS3xx float64 `json:"rps3xx"`
	RPS4xx float64 `json:"rps4xx"`
	RPS5xx float64 `json:"rps5xx"`

	Avg         float64 `json:"avg"`
	P50         float64 `json:"p50"`
	P95         float64 `json:"p95"`
	P99         float64 `json:"p99"`
	InFlight    float64 `json:"inFlight"`
	BytesPerSec float64 `json:"bytesPerSec"`

	WSEvents float64 `json:"wsEvents"`
	WSConns  float64 `json:"wsConns"`
	WSUsers  float64 `json:"wsUsers"`

	DBTxPerSec float64 `json:"dbTxPerSec"`
	DBAvg      float64 `json:"dbAvg"`
	DBP95      float64 `json:"dbP95"`
	DBErrors   float64 `json:"dbErrors"`

	PoolTotal    float64 `json:"poolTotal"`
	PoolAcquired float64 `json:"poolAcquired"`
	PoolIdle     float64 `json:"poolIdle"`
	PoolMax      float64 `json:"poolMax"`
	PoolWaits    float64 `json:"poolWaits"`

	Commits     float64 `json:"commits"`
	Rollbacks   float64 `json:"rollbacks"`
	BlksHit     float64 `json:"blksHit"`
	BlksRead    float64 `json:"blksRead"`
	CacheHit    float64 `json:"cacheHit"`
	TupReturned float64 `json:"tupReturned"`
	TupFetched  float64 `json:"tupFetched"`
	Deadlocks   float64 `json:"deadlocks"`

	ConnsActive  float64 `json:"connsActive"`
	ConnsIdle    float64 `json:"connsIdle"`
	ConnsIdleTx  float64 `json:"connsIdleTx"`
	LongestQuery float64 `json:"longestQuery"`
	LongestTx    float64 `json:"longestTx"`
	IdleInTx     float64 `json:"idleInTx"`
	LocksWaiting float64 `json:"locksWaiting"`
}

// Тип RouteStat предназначен для описания строки таблицы маршрутов за период.
type RouteStat struct {
	Method   string  `json:"method"`
	Route    string  `json:"route"`
	Requests float64 `json:"requests"`
	RPS      float64 `json:"rps"`
	Avg      float64 `json:"avg"`
	P95      float64 `json:"p95"`
	P99      float64 `json:"p99"`
	Errors   float64 `json:"errors"`
	ErrShare float64 `json:"errShare"` // доля ошибок в запросах маршрута
}

// Тип TableStat предназначен для описания строки таблицы по таблицам БД.
type TableStat struct {
	Table     string  `json:"table"`
	SizeBytes float64 `json:"sizeBytes"`
	LiveRows  float64 `json:"liveRows"`
	DeadRows  float64 `json:"deadRows"`
	DeadShare float64 `json:"deadShare"`
	VacuumAge float64 `json:"vacuumAge"`
	SeqScans  float64 `json:"seqScans"`
	IdxScans  float64 `json:"idxScans"`
}

// Тип Summary предназначен для описания мгновенных значений верхнего ряда плиток.
type Summary struct {
	RPS float64 `json:"rps"`
	// Доли ошибок 5xx и 4xx вычисляются отдельно: 5xx — сбои сервера, 4xx — штатные отказы.
	ErrShare       float64 `json:"errShare"`
	ClientErrShare float64 `json:"clientErrShare"`
	Avg            float64 `json:"avg"`
	P50            float64 `json:"p50"`
	P95            float64 `json:"p95"`
	P99            float64 `json:"p99"`
	InFlight       float64 `json:"inFlight"`
	SlowPerMin     float64 `json:"slowPerMin"`
	BytesPerSec    float64 `json:"bytesPerSec"`

	WSConns float64 `json:"wsConns"`
	WSUsers float64 `json:"wsUsers"`

	DBTxPerSec   float64 `json:"dbTxPerSec"`
	DBAvg        float64 `json:"dbAvg"`
	DBP95        float64 `json:"dbP95"`
	DBErrors     float64 `json:"dbErrors"`
	PoolAcquired float64 `json:"poolAcquired"`
	PoolMax      float64 `json:"poolMax"`
	PoolUsage    float64 `json:"poolUsage"`
	PoolWaits    float64 `json:"poolWaits"`

	DBSizeBytes    float64 `json:"dbSizeBytes"`
	CacheHit       float64 `json:"cacheHit"`
	Connections    float64 `json:"connections"`
	MaxConnections float64 `json:"maxConnections"`
	RollbackShare  float64 `json:"rollbackShare"`
	LongestQuery   float64 `json:"longestQuery"`
	LongestTx      float64 `json:"longestTx"`
	IdleInTx       float64 `json:"idleInTx"`
	LocksWaiting   float64 `json:"locksWaiting"`
	Deadlocks      float64 `json:"deadlocks"`
}

// Тип Report предназначен для описания всех данных дашборда одним ответом на один момент времени.
type Report struct {
	At            time.Time `json:"at"`
	UptimeSeconds float64   `json:"uptimeSeconds"`
	WindowSeconds float64   `json:"windowSeconds"`
	StepSeconds   float64   `json:"stepSeconds"`
	// Объём накопленной истории в секундах.
	HistorySeconds float64 `json:"historySeconds"`
	SampleStep     float64 `json:"sampleStep"`

	Summary  Summary            `json:"summary"`
	Points   []Point            `json:"points"`
	Routes   []RouteStat        `json:"routes"`
	Slow     []SlowRequest      `json:"slow"`
	Tables   []TableStat        `json:"tables"`
	Entities map[string]float64 `json:"entities"`
	Statuses map[string]float64 `json:"statuses"`
	WSKinds  map[string]float64 `json:"wsKinds"`
	Events   map[string]float64 `json:"events"`
}

// Метод Report предназначен для построения сводки за период с ограничением числа точек.
func (s *Sampler) Report(window time.Duration, maxPoints int) Report {
	if window <= 0 {
		window = time.Hour
	}
	if maxPoints <= 0 {
		maxPoints = 180
	}

	s.mu.RLock()
	fs := s.framesLocked(window)
	last := s.last
	oldest := s.oldestLocked()
	s.mu.RUnlock()

	rep := Report{
		At:            time.Now(),
		WindowSeconds: window.Seconds(),
		SampleStep:    SampleStep.Seconds(),
		Entities:      map[string]float64{},
		Statuses:      map[string]float64{},
		WSKinds:       map[string]float64{},
		Events:        map[string]float64{},
		Points:        []Point{},
		Routes:        []RouteStat{},
		Tables:        []TableStat{},
		Slow:          []SlowRequest{},
	}
	if last != nil {
		rep.UptimeSeconds = last.One("kanban_uptime_seconds")
		rep.Entities = last.By("kanban_entities", "kind")
		rep.Statuses = last.By("kanban_http_requests_total", "status")
		rep.WSKinds = last.By("kanban_ws_events_total", "type")
		rep.Events = last.By("kanban_app_events_total", "event")
		rep.Tables = tablesOf(last)
	}
	// История считается от первой сохранённой точки до последней.
	if !oldest.IsZero() && len(fs) > 0 {
		rep.HistorySeconds = fs[len(fs)-1].at.Sub(oldest).Seconds()
	}

	// Шаг графика: период, делённый на число точек, но не меньше шага снятия показаний.
	stride := 1
	if len(fs) > maxPoints {
		stride = (len(fs) + maxPoints - 1) / maxPoints
	}
	rep.StepSeconds = SampleStep.Seconds() * float64(stride)

	// Выбор точек идёт от конца к началу, чтобы последняя точка была самой свежей.
	var idx []int
	for i := len(fs) - 1; i-stride >= 0; i -= stride {
		idx = append(idx, i)
	}
	for i := len(idx) - 1; i >= 0; i-- {
		j := idx[i]
		p, pgFresh := pointBetween(fs[j-stride], fs[j])
		// Если метрики БД не обновились, в точку переносится предыдущее значение.
		if !pgFresh && len(rep.Points) > 0 {
			carryPG(&p, rep.Points[len(rep.Points)-1])
		}
		rep.Points = append(rep.Points, p)
	}

	if len(fs) >= 2 {
		rep.Summary = summaryOf(fs, last, s.reg)
	} else if len(fs) == 1 {
		// При одной точке скорости не рассчитываются, мгновенные значения выводятся.
		f := fs[0]
		rep.Summary = Summary{
			InFlight: f.inFlight, WSConns: f.wsConns, WSUsers: f.wsUsers,
			PoolAcquired: f.poolAcquired, PoolMax: f.poolMax,
			PoolUsage:   safeDiv(f.poolAcquired, f.poolMax) * 100,
			DBSizeBytes: f.pgSize, Connections: f.pgConnsActive + f.pgConnsIdle + f.pgConnsIdleTx,
			LongestQuery: f.pgLongestQuery, LongestTx: f.pgLongestTx,
			IdleInTx: f.pgIdleInTx, LocksWaiting: f.pgLocksWaiting,
		}
	}
	if last != nil {
		rep.Summary.MaxConnections = last.One("pg_max_connections")
	}

	// Таблица маршрутов строится по последнему снимку целиком, а не по последней точке с разбивкой.
	if last != nil {
		cur, capped := routesOf(last)
		rep.Routes = routesBetween(fs, cur, capped, last.At)
	}
	// Журнал медленных запросов ограничивается выбранным периодом.
	cut := time.Now().Add(-window)
	for _, r := range s.reg.Slow() {
		if r.At.After(cut) {
			rep.Slow = append(rep.Slow, r)
		}
	}
	return rep
}

// реже, чем строятся точки графика.
func carryPG(p *Point, prev Point) {
	p.Commits = prev.Commits
	p.Rollbacks = prev.Rollbacks
	p.BlksHit = prev.BlksHit
	p.BlksRead = prev.BlksRead
	p.CacheHit = prev.CacheHit
	p.TupReturned = prev.TupReturned
	p.TupFetched = prev.TupFetched
	p.Deadlocks = prev.Deadlocks
}

// Метод oldestLocked предназначен для получения времени самой старой точки; вызывается при взятом s.mu.
func (s *Sampler) oldestLocked() time.Time {
	var out time.Time
	for _, f := range s.ring {
		if f.at.IsZero() {
			continue
		}
		if out.IsZero() || f.at.Before(out) {
			out = f.at
		}
	}
	return out
}

// Функция pointBetween предназначена для расчёта скоростей и перцентилей между двумя снимками;
// второй результат показывает, обновились ли метрики БД.
func pointBetween(a, b frame) (Point, bool) {
	dt := b.at.Sub(a.at).Seconds()
	// Прирост по БД считается между разными опросами за их собственный интервал.
	pgDt := b.pgAt.Sub(a.pgAt).Seconds()
	pgFresh := pgDt > 0
	p := Point{
		T:      b.at.UnixMilli(),
		RPS:    rate(b.reqTotal, a.reqTotal, dt),
		RPS2xx: rate(b.req2xx, a.req2xx, dt),
		RPS3xx: rate(b.req3xx, a.req3xx, dt),
		RPS4xx: rate(b.req4xx, a.req4xx, dt),
		RPS5xx: rate(b.req5xx, a.req5xx, dt),

		InFlight:    b.inFlight,
		BytesPerSec: rate(b.sizeSum, a.sizeSum, dt),

		WSEvents: rate(b.wsEvents, a.wsEvents, dt),
		WSConns:  b.wsConns,
		WSUsers:  b.wsUsers,

		DBTxPerSec: rate(b.dbTx, a.dbTx, dt),
		DBErrors:   rate(b.dbErrors, a.dbErrors, dt),

		PoolTotal:    b.poolTotal,
		PoolAcquired: b.poolAcquired,
		PoolIdle:     b.poolIdle,
		PoolMax:      b.poolMax,
		PoolWaits:    rate(b.poolEmpty, a.poolEmpty, dt),

		Commits:     rate(b.pgCommits, a.pgCommits, pgDt),
		Rollbacks:   rate(b.pgRollbacks, a.pgRollbacks, pgDt),
		BlksHit:     rate(b.pgHit, a.pgHit, pgDt),
		BlksRead:    rate(b.pgRead, a.pgRead, pgDt),
		TupReturned: rate(b.pgTupReturned, a.pgTupReturned, pgDt),
		TupFetched:  rate(b.pgTupFetched, a.pgTupFetched, pgDt),
		Deadlocks:   rate(b.pgDeadlocks, a.pgDeadlocks, pgDt),

		ConnsActive:  b.pgConnsActive,
		ConnsIdle:    b.pgConnsIdle,
		ConnsIdleTx:  b.pgConnsIdleTx,
		LongestQuery: b.pgLongestQuery,
		LongestTx:    b.pgLongestTx,
		IdleInTx:     b.pgIdleInTx,
		LocksWaiting: b.pgLocksWaiting,
	}
	// Доля попаданий в кэш считается при наличии обращений к блокам.
	if p.BlksHit+p.BlksRead > 0 {
		p.CacheHit = p.BlksHit / (p.BlksHit + p.BlksRead) * 100
	}

	// Время ответа: среднее по приросту суммы и числа, перцентили по приросту ступеней.
	if n := b.durCount - a.durCount; n > 0 {
		p.Avg = (b.durSum - a.durSum) / n
		db, _ := diffBuckets(b.durBuckets, a.durBuckets)
		p.P50 = quantile(db, n, 0.5)
		p.P95 = quantile(db, n, 0.95)
		p.P99 = quantile(db, n, 0.99)
	}
	if n := b.dbTx - a.dbTx; n > 0 {
		p.DBAvg = (b.dbTxSum - a.dbTxSum) / n
		db, _ := diffBuckets(b.dbTxBuckets, a.dbTxBuckets)
		p.DBP95 = quantile(db, n, 0.95)
	}
	return p, pgFresh
}

// Функция summaryOf предназначена для расчёта мгновенных значений за последнюю минуту.
func summaryOf(fs []frame, last *Scrape, reg *Registry) Summary {
	cur := fs[len(fs)-1]
	// Опорная точка: минуту назад или самая старая.
	ref := fs[0]
	for i := len(fs) - 1; i >= 0; i-- {
		if cur.at.Sub(fs[i].at) >= time.Minute {
			ref = fs[i]
			break
		}
	}
	inst, pgFresh := pointBetween(ref, cur)

	s := Summary{
		RPS: inst.RPS, Avg: inst.Avg, P50: inst.P50, P95: inst.P95, P99: inst.P99,
		InFlight: cur.inFlight, BytesPerSec: inst.BytesPerSec,
		WSConns: cur.wsConns, WSUsers: cur.wsUsers,
		DBTxPerSec: inst.DBTxPerSec, DBAvg: inst.DBAvg, DBP95: inst.DBP95,
		DBErrors:     inst.DBErrors,
		PoolAcquired: cur.poolAcquired, PoolMax: cur.poolMax,
		PoolUsage:    safeDiv(cur.poolAcquired, cur.poolMax) * 100,
		PoolWaits:    inst.PoolWaits,
		DBSizeBytes:  cur.pgSize,
		Connections:  cur.pgConnsActive + cur.pgConnsIdle + cur.pgConnsIdleTx,
		LongestQuery: cur.pgLongestQuery, LongestTx: cur.pgLongestTx,
		IdleInTx: cur.pgIdleInTx, LocksWaiting: cur.pgLocksWaiting,
		Deadlocks: inst.Deadlocks,
	}
	s.ErrShare = safeDiv(inst.RPS5xx, inst.RPS) * 100
	s.ClientErrShare = safeDiv(inst.RPS4xx, inst.RPS) * 100

	// Доли по БД за минуту считаются при наличии работы и свежего опроса; иначе берутся накопленные значения.
	s.CacheHit = inst.CacheHit
	s.RollbackShare = safeDiv(inst.Rollbacks, inst.Commits+inst.Rollbacks) * 100
	if last != nil {
		if !pgFresh || inst.BlksHit+inst.BlksRead == 0 {
			hit := last.Sum("pg_blks_hit_total")
			read := last.Sum("pg_blks_read_total")
			s.CacheHit = safeDiv(hit, hit+read) * 100
		}
		if !pgFresh || inst.Commits+inst.Rollbacks == 0 {
			com := last.Sum("pg_xact_commit_total")
			roll := last.Sum("pg_xact_rollback_total")
			s.RollbackShare = safeDiv(roll, com+roll) * 100
		}
	}

	// Число медленных запросов в минуту считается приростом счётчика, а не по кольцевому журналу.
	s.SlowPerMin = rate(cur.slowTotal, ref.slowTotal, cur.at.Sub(ref.at).Seconds()) * 60
	return s
}

// Функция routesBetween предназначена для построения таблицы маршрутов за период по разнице двух снимков с разбивкой.
func routesBetween(fs []frame, cur map[string]routeFrame, capped bool,
	at time.Time) []RouteStat {

	// Нижняя граница — самый старый снимок периода с разбивкой.
	var first *frame
	for i := range fs {
		if fs[i].routes != nil {
			first = &fs[i]
			break
		}
	}
	if first == nil || len(cur) == 0 {
		return []RouteStat{}
	}
	dt := at.Sub(first.at).Seconds()
	if dt <= 0 {
		return []RouteStat{}
	}

	out := make([]RouteStat, 0, len(cur))
	for key, cur := range cur {
		prev, known := first.routes[key]
		if !known && (first.routesCapped || capped) {
			// Маршрут без базового значения пропускается, если список был подрезан.
			continue
		}
		n := cur.count - prev.count
		if n <= 0 {
			continue
		}
		method, route := key, ""
		if sp := strings.IndexByte(key, ' '); sp >= 0 {
			method, route = key[:sp], key[sp+1:]
		}
		st := RouteStat{
			Method: method, Route: route,
			Requests: n,
			RPS:      n / dt,
			Avg:      safeDiv(cur.sumSec-prev.sumSec, n),
			Errors:   maxZero(cur.errors - prev.errors),
		}
		st.ErrShare = safeDiv(st.Errors, n) * 100
		if cur.buckets != nil {
			db := map[float64]float64{}
			for i, bound := range durationBuckets {
				var p float64
				if prev.buckets != nil {
					p = prev.buckets[i]
				}
				db[bound] = maxZero(cur.buckets[i] - p)
			}
			st.P95 = quantile(db, n, 0.95)
			st.P99 = quantile(db, n, 0.99)
		}
		out = append(out, st)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Requests > out[j].Requests })
	return out
}

// Функция tablesOf предназначена для получения строк по таблицам БД из последнего снимка (текущие значения).
func tablesOf(sc *Scrape) []TableStat {
	byName := map[string]*TableStat{}
	get := func(name string) *TableStat {
		if t, ok := byName[name]; ok {
			return t
		}
		t := &TableStat{Table: name}
		byName[name] = t
		return t
	}
	for _, lv := range sc.Series["pg_table_size_bytes"] {
		get(lv.Labels["table"]).SizeBytes = lv.Value
	}
	for _, lv := range sc.Series["pg_table_live_rows"] {
		get(lv.Labels["table"]).LiveRows = lv.Value
	}
	for _, lv := range sc.Series["pg_table_dead_rows"] {
		get(lv.Labels["table"]).DeadRows = lv.Value
	}
	for _, lv := range sc.Series["pg_table_vacuum_age_seconds"] {
		get(lv.Labels["table"]).VacuumAge = lv.Value
	}
	for _, lv := range sc.Series["pg_table_seq_scan_total"] {
		get(lv.Labels["table"]).SeqScans = lv.Value
	}
	for _, lv := range sc.Series["pg_table_idx_scan_total"] {
		get(lv.Labels["table"]).IdxScans = lv.Value
	}

	out := make([]TableStat, 0, len(byName))
	for _, t := range byName {
		t.DeadShare = safeDiv(t.DeadRows, t.LiveRows+t.DeadRows) * 100
		out = append(out, *t)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].SizeBytes > out[j].SizeBytes })
	return out
}

// Функция maxZero предназначена для ограничения значения снизу нулём.
func maxZero(v float64) float64 {
	if v < 0 {
		return 0
	}
	return v
}
