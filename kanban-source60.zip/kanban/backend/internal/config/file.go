// Модуль предназначен для чтения config.yaml и переноса его значений в Config с учётом
// приоритета переменных окружения.

package config

import (
	"fmt"
	"log/slog"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

// Тип fileConfig предназначен для разбора config.yaml. Поля — указатели, чтобы отличать
// отсутствующий параметр от нулевого значения.
type fileConfig struct {
	Server *struct {
		Addr      *string `yaml:"addr"`
		Env       *string `yaml:"env"`
		StaticDir *string `yaml:"static_dir"`
		// Адреса обратных прокси, которым доверяется X-Forwarded-For.
		TrustedProxies []string `yaml:"trusted_proxies"`
		AllowedOrigins []string `yaml:"allowed_origins"`
		RateLimit      *int     `yaml:"rate_limit_per_min"`
		ReadTimeout    *string  `yaml:"read_timeout"`
		WriteTimeout   *string  `yaml:"write_timeout"`
		IdleTimeout    *string  `yaml:"idle_timeout"`
	} `yaml:"server"`

	Database *struct {
		// Строка подключения целиком либо отдельные поля.
		URL      *string `yaml:"url"`
		Host     *string `yaml:"host"`
		Port     *int    `yaml:"port"`
		Name     *string `yaml:"name"`
		User     *string `yaml:"user"`
		Password *string `yaml:"password"`
		SSLMode  *string `yaml:"sslmode"`
		PoolSize *int    `yaml:"pool_size"`
		MinIdle  *int    `yaml:"min_idle"`
		// Кэш подготовленных запросов pgx; отключается за pgbouncer в режиме transaction.
		StatementCache *bool `yaml:"statement_cache"`
	} `yaml:"database"`

	Auth *struct {
		JWTSecret             *string `yaml:"jwt_secret"`
		AccessTTL             *string `yaml:"access_ttl"`
		RefreshTTL            *string `yaml:"refresh_ttl"`
		AllowSelfRegistration *bool   `yaml:"allow_self_registration"`
	} `yaml:"auth"`

	Uploads *struct {
		Dir      *string `yaml:"dir"`
		MaxSizeM *int    `yaml:"max_size_mb"`
	} `yaml:"uploads"`

	// Конвертация офисных документов в PDF.
	Convert *struct {
		Dir *string `yaml:"dir"`
	} `yaml:"convert"`

	Features *struct {
		// Включение видеовызовов в интерфейсе и при формировании ссылок вызова.
		VideoCalls *bool `yaml:"video_calls"`
		// Массовая почтовая рассылка участникам задачи.
		GroupEmail *bool `yaml:"group_email"`
	} `yaml:"features"`

	// Масштабирование: prefork и число процессов.
	Scaling *struct {
		Prefork *bool `yaml:"prefork"`
		Workers *int  `yaml:"workers"`
	} `yaml:"scaling"`

	// Метрики Prometheus.
	Metrics *struct {
		Enabled *bool `yaml:"enabled"`
	} `yaml:"metrics"`

	Redis *struct {
		Addr     *string `yaml:"addr"`
		Password *string `yaml:"password"`
		DB       *int    `yaml:"db"`
		Channel  *string `yaml:"channel"`
	} `yaml:"redis"`

	Branding *struct {
		AppName *string `yaml:"app_name"`
	} `yaml:"branding"`
}

// Функция loadFile предназначена для чтения YAML-файла; отсутствие файла допустимо, если путь не задан явно.
func loadFile(path string, explicit bool) (*fileConfig, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) && !explicit {
			return nil, nil
		}
		return nil, fmt.Errorf("не удалось прочитать %s: %w", path, err)
	}

	var fc fileConfig
	if err := yaml.Unmarshal(data, &fc); err != nil {
		return nil, fmt.Errorf("ошибка разбора %s: %w", path, err)
	}
	slog.Info("конфигурация загружена", "file", path)
	return &fc, nil
}

// Метод applyFile предназначен для переноса значений файла в конфигурацию.
// Приоритет: переменные окружения, config.yaml, значения по умолчанию.
func (c *Config) applyFile(fc *fileConfig) {
	if fc == nil {
		return
	}

	if s := fc.Server; s != nil {
		setStr(&c.Addr, s.Addr, "APP_ADDR")
		setStr(&c.Env, s.Env, "APP_ENV")
		setStr(&c.StaticDir, s.StaticDir, "STATIC_DIR")
		setInt(&c.RateLimitPerMin, s.RateLimit, "RATE_LIMIT_PER_MIN")
		setDuration(&c.ReadTimeout, s.ReadTimeout, "READ_TIMEOUT")
		setDuration(&c.WriteTimeout, s.WriteTimeout, "WRITE_TIMEOUT")
		setDuration(&c.IdleTimeout, s.IdleTimeout, "IDLE_TIMEOUT")
		if len(s.TrustedProxies) > 0 && os.Getenv("TRUSTED_PROXIES") == "" {
			c.TrustedProxies = s.TrustedProxies
		}
		if len(s.AllowedOrigins) > 0 && os.Getenv("ALLOWED_ORIGINS") == "" {
			c.AllowedOrigins = s.AllowedOrigins
		}
	}

	if d := fc.Database; d != nil {
		if os.Getenv("DATABASE_URL") == "" {
			if d.URL != nil && *d.URL != "" {
				c.DatabaseURL = *d.URL
			} else if d.Host != nil || d.Name != nil {
				c.DatabaseURL = buildDSN(d.Host, d.Port, d.Name, d.User, d.Password, d.SSLMode)
			}
		}
		setInt(&c.DBPoolSize, d.PoolSize, "DB_POOL_SIZE")
		setInt(&c.DBMinIdle, d.MinIdle, "DB_MIN_IDLE")
		setBool(&c.StatementCache, d.StatementCache, "DB_STATEMENT_CACHE")
	}

	if sc := fc.Scaling; sc != nil {
		setBool(&c.Prefork, sc.Prefork, "PREFORK")
		setInt(&c.PreforkWorkers, sc.Workers, "PREFORK_WORKERS")
	}

	if m := fc.Metrics; m != nil {
		setBool(&c.Metrics, m.Enabled, "METRICS_ENABLED")
	}

	if r := fc.Redis; r != nil {
		setStr(&c.RedisAddr, r.Addr, "REDIS_ADDR")
		setStr(&c.RedisPassword, r.Password, "REDIS_PASSWORD")
		setInt(&c.RedisDB, r.DB, "REDIS_DB")
		setStr(&c.RedisChannel, r.Channel, "REDIS_CHANNEL")
	}

	if a := fc.Auth; a != nil {
		if a.JWTSecret != nil && *a.JWTSecret != "" && os.Getenv("JWT_SECRET") == "" {
			c.JWTSecret = []byte(*a.JWTSecret)
		}
		setDuration(&c.AccessTTL, a.AccessTTL, "ACCESS_TTL")
		setDuration(&c.RefreshTTL, a.RefreshTTL, "REFRESH_TTL")
		setBool(&c.AllowSelfRegistration, a.AllowSelfRegistration, "ALLOW_SELF_REGISTRATION")
	}

	if u := fc.Uploads; u != nil {
		setStr(&c.UploadDir, u.Dir, "UPLOAD_DIR")
		if u.MaxSizeM != nil && os.Getenv("MAX_UPLOAD_MB") == "" {
			c.MaxUploadBytes = int64(*u.MaxSizeM) << 20
		}
	}

	if cv := fc.Convert; cv != nil {
		setStr(&c.ConvertDir, cv.Dir, "CONVERT_DIR")
	}

	if f := fc.Features; f != nil {
		setBool(&c.VideoCalls, f.VideoCalls, "FEATURE_VIDEO_CALLS")
		setBool(&c.GroupEmail, f.GroupEmail, "FEATURE_GROUP_EMAIL")
	}

	if b := fc.Branding; b != nil {
		setStr(&c.AppName, b.AppName, "APP_NAME")
	}
}

// Функции setStr, setInt, setBool и setDuration применяют значение из файла, если переменная окружения не задана.

func setStr(dst *string, v *string, envKey string) {
	if v != nil && os.Getenv(envKey) == "" {
		*dst = *v
	}
}

// Функция setInt предназначена для применения целочисленного значения из файла.
func setInt(dst *int, v *int, envKey string) {
	if v != nil && os.Getenv(envKey) == "" {
		*dst = *v
	}
}

// Функция setBool предназначена для применения логического значения из файла.
func setBool(dst *bool, v *bool, envKey string) {
	if v != nil && os.Getenv(envKey) == "" {
		*dst = *v
	}
}

// Функция setDuration предназначена для применения длительности из файла.
func setDuration(dst *time.Duration, v *string, envKey string) {
	if v == nil || os.Getenv(envKey) != "" {
		return
	}
	if d, err := time.ParseDuration(*v); err == nil {
		*dst = d
	} else {
		slog.Warn("не удалось разобрать длительность из конфигурации",
			"key", envKey, "value", *v, "error", err)
	}
}

// Функция buildDSN предназначена для сборки строки подключения к PostgreSQL из отдельных полей.
func buildDSN(host *string, port *int, name, user, password, sslmode *string) string {
	h := "localhost"
	if host != nil {
		h = *host
	}
	p := 5432
	if port != nil {
		p = *port
	}
	n := "kanban"
	if name != nil {
		n = *name
	}
	u := "app_user"
	if user != nil {
		u = *user
	}
	pw := ""
	if password != nil {
		pw = *password
	}
	ssl := "disable"
	if sslmode != nil {
		ssl = *sslmode
	}
	return fmt.Sprintf("postgres://%s:%s@%s:%d/%s?sslmode=%s", u, pw, h, p, n, ssl)
}
