// Модуль предназначен для работы WebSocket: проверка токена при подключении, обработка сообщений клиента
// (присутствие на досках, курсоры), определение получателей и публикация событий о задачах, проектах, чатах,
// напоминаниях и уведомлениях.

package handlers

import (
	"context"
	"encoding/json"
	"log/slog"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/websocket/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/models"
	"github.com/example/kanban/internal/realtime"
)

// Метод wsAuth предназначен для проверки access-токена из параметра запроса до апгрейда соединения
// и сохранения userID в Locals.
func (s *Server) wsAuth(c *fiber.Ctx) error {
	if !websocket.IsWebSocketUpgrade(c) {
		return fiber.NewError(fiber.StatusUpgradeRequired, "Требуется WebSocket-подключение")
	}
	token := c.Query("access_token")
	userID, err := s.auth.ParseAccess(token)
	if err != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Требуется вход в систему")
	}

	// Состояние учётной записи проверяется при подключении; уже открытые соединения разрывает Hub.Disconnect.
	var (
		active  bool
		deleted bool
		role    string
	)
	if e := s.db.AsService(c.Context(), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT is_active, deleted, role FROM app.account_state($1)`, userID).
			Scan(&active, &deleted, &role)
	}); e != nil {
		return fiber.NewError(fiber.StatusUnauthorized, "Требуется вход в систему")
	}
	if deleted || !active {
		return fiber.NewError(fiber.StatusForbidden, "Учётная запись отключена")
	}

	c.Locals(wsUserIDKey, userID)
	return c.Next()
}

const wsUserIDKey = "wsUserID"

// Метод wsHandler предназначен для удержания соединения: чтение сообщений клиента, обнаружение разрыва
// и снятие регистрации. Рассылка событий выполняется через hub.SendTo.
func (s *Server) wsHandler(c *websocket.Conn) {
	userID, ok := c.Locals(wsUserIDKey).(uuid.UUID)
	if !ok || userID == uuid.Nil {
		_ = c.Close()
		return
	}

	conn := s.hub.Register(userID, c)
	defer s.hub.Unregister(userID, conn)

	// Доски, к которым соединение получило доступ; права проверяются при входе в доску.
	joined := map[uuid.UUID]bool{}

	for {
		_, raw, err := c.ReadMessage()
		if err != nil {
			return
		}
		s.handleClientMessage(userID, raw, joined)
	}
}

// Тип clientMessage предназначен для описания сообщения клиента: через сокет передаются только эфемерные данные (курсоры, перемещения).
type clientMessage struct {
	Type    string          `json:"type"`
	BoardID uuid.UUID       `json:"boardId"`
	Payload json.RawMessage `json:"payload"`
}

// Метод handleClientMessage предназначен для обработки сообщения клиента: вход в доску, эфемерные события.
func (s *Server) handleClientMessage(userID uuid.UUID, raw []byte, joined map[uuid.UUID]bool) {
	var m clientMessage
	if err := json.Unmarshal(raw, &m); err != nil {
		return
	}
	if m.BoardID == uuid.Nil {
		return
	}

	switch m.Type {
	case "wbJoin":
		// Вход в доску — единственное место проверки прав на живые события.
		ctx, cancel := bgContext()
		defer cancel()
		var ok bool
		if e := s.db.AsService(ctx, func(tx pgx.Tx) error {
			return tx.QueryRow(ctx, `SELECT app.can_see_wb($1, $2)`, m.BoardID, userID).Scan(&ok)
		}); e != nil || !ok {
			return
		}
		joined[m.BoardID] = true

	case "wbLeave":
		delete(joined, m.BoardID)

	case "wbCursor", "wbDrag":
		if !joined[m.BoardID] {
			return
		}
		// Эфемерное событие не сохраняется и не отправляется отправителю.
		watchers := s.wbWatchers(m.BoardID)
		targets := watchers[:0:0]
		for _, w := range watchers {
			if w != userID {
				targets = append(targets, w)
			}
		}
		s.hub.SendTo(targets, realtime.Event{
			Type: m.Type, Action: "live",
			Payload: fiber.Map{"boardId": m.BoardID, "userId": userID, "data": m.Payload},
		})
	}
}

// Функция bgContext предназначена для создания контекста фоновой публикации: контекст запроса fasthttp недоступен после возврата обработчика.
func bgContext() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 5*time.Second)
}

// Метод watchersOfBoard предназначен для получения получателей событий проекта. Функции board_watchers и task_watchers
// возвращают SETOF uuid; обращаться к ним нужно как SELECT w FROM app.board_watchers($1) AS w.
func (s *Server) watchersOfBoard(ctx context.Context, boardID uuid.UUID) []uuid.UUID {
	var ids []uuid.UUID
	err := s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.board_watchers($1)`, boardID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		slog.Error("не удалось получить наблюдателей доски", "error", err, "board", boardID)
		return nil
	}
	return ids
}

// Метод watchersOfTask предназначен для получения получателей событий задачи.
func (s *Server) watchersOfTask(ctx context.Context, taskID uuid.UUID) []uuid.UUID {
	var ids []uuid.UUID
	err := s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.task_watchers($1)`, taskID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		slog.Error("не удалось получить наблюдателей задачи", "error", err, "task", taskID)
		return nil
	}
	return ids
}

// Метод watchersOfTaskForBoard предназначен для получения получателей событий задачи в контексте проекта.
func (s *Server) watchersOfTaskForBoard(ctx context.Context, boardID, taskID uuid.UUID) []uuid.UUID {
	var ids []uuid.UUID
	err := s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.task_watchers_for_board($1, $2)`, boardID, taskID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		slog.Error("не удалось получить наблюдателей удалённой задачи", "error", err, "board", boardID, "task", taskID)
		return nil
	}
	return ids
}

// Метод publishTask предназначен для рассылки актуального состояния задачи всем, кому она видна.
func (s *Server) publishTask(task models.Task, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfTask(ctx, task.ID)
	s.hub.SendTo(watchers, realtime.Event{Type: "task", Action: action, Payload: task})
}

// Метод publishTaskDeletedTo предназначен для рассылки события об удалении задачи заранее определённым получателям.
func (s *Server) publishTaskDeletedTo(watchers []uuid.UUID, boardID, taskID uuid.UUID) {
	s.hub.SendTo(watchers, realtime.Event{
		Type: "task", Action: "deleted",
		Payload: fiber.Map{"id": taskID, "boardId": boardID},
	})
}

// Метод publishColumns предназначен для рассылки событий об изменении колонок проекта.
// Получателей определяет вызывающий код до удаления: каскад удаляет связи наблюдателей.

func (s *Server) publishColumns(boardID uuid.UUID, columns []models.Column) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfBoard(ctx, boardID)
	s.hub.SendTo(watchers, realtime.Event{
		Type: "columns", Action: "updated",
		Payload: fiber.Map{"boardId": boardID, "columns": columns},
	})
}

// Метод publishBoard предназначен для рассылки события об изменении проекта.
func (s *Server) publishBoard(board models.Board, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfBoard(ctx, board.ID)
	s.hub.SendTo(watchers, realtime.Event{Type: "board", Action: action, Payload: board})
}

// Метод publishBoardDeleted предназначен для рассылки события об удалении проекта заранее определённым получателям.
func (s *Server) publishBoardDeleted(boardID uuid.UUID, watchers []uuid.UUID) {
	s.hub.SendTo(watchers, realtime.Event{Type: "board", Action: "deleted", Payload: fiber.Map{"id": boardID}})
}

// Метод publishAccessRevoked предназначен для рассылки адресного события о закрытии доступа к проекту.
func (s *Server) publishAccessRevoked(boardID uuid.UUID, userIDs []uuid.UUID, reason string) {
	if len(userIDs) == 0 {
		return
	}
	s.hub.SendTo(userIDs, realtime.Event{
		Type:    "access",
		Action:  "revoked",
		Payload: map[string]any{"boardId": boardID, "reason": reason},
	})
}

// Метод publishTaskAccessRevoked предназначен для рассылки события о снятии точечного доступа к задаче.
func (s *Server) publishTaskAccessRevoked(boardID, taskID uuid.UUID, userIDs []uuid.UUID) {
	if len(userIDs) == 0 {
		return
	}
	s.hub.SendTo(userIDs, realtime.Event{
		Type:   "access",
		Action: "task_revoked",
		Payload: map[string]any{
			"boardId": boardID,
			"taskId":  taskID,
			"reason":  "Доступ к задаче отозван",
		},
	})
}

// Метод publishBoardMemberAdded предназначен для рассылки события новому участнику проекта.
func (s *Server) publishBoardMemberAdded(boardID, userID uuid.UUID) {
	s.hub.SendTo([]uuid.UUID{userID}, realtime.Event{
		Type: "board", Action: "member_added",
		Payload: fiber.Map{"boardId": boardID},
	})
}

// Метод publishComment предназначен для рассылки события о комментарии.
func (s *Server) publishComment(taskID uuid.UUID, c models.Comment, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfTask(ctx, taskID)
	s.hub.SendTo(watchers, realtime.Event{Type: "comment", Action: action, Payload: c})
}

// Метод publishAttachment предназначен для рассылки события о вложении.
func (s *Server) publishAttachment(taskID uuid.UUID, a models.Attachment, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfTask(ctx, taskID)
	s.hub.SendTo(watchers, realtime.Event{Type: "attachment", Action: action, Payload: a})
}

// Метод publishStep предназначен для рассылки события об изменении пункта чек-листа, чтобы у других вкладок отметка обновлялась.
func (s *Server) publishStep(taskID uuid.UUID, step models.Step, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	watchers := s.watchersOfTask(ctx, taskID)
	s.hub.SendTo(watchers, realtime.Event{
		Type: "step", Action: action,
		Payload: fiber.Map{"taskId": taskID, "step": step},
	})
}

// Метод publishChat предназначен для рассылки событий чата участникам; счётчик непрочитанных клиент считает сам.
func (s *Server) publishChat(members []uuid.UUID, chatID uuid.UUID, action string) {
	if len(members) == 0 {
		return
	}
	s.hub.SendTo(members, realtime.Event{
		Type: "chat", Action: action,
		Payload: fiber.Map{"id": chatID},
	})
}

// Метод publishMessage предназначен для рассылки события сообщения участникам чата.
func (s *Server) publishMessage(members []uuid.UUID, m any, action string) {
	if len(members) == 0 {
		return
	}
	s.hub.SendTo(members, realtime.Event{
		Type: "message", Action: action, Payload: m,
	})
}

// Метод publishReminder предназначен для рассылки события сработавшего напоминания с идентификатором для переноса.
func (s *Server) publishReminder(userID, reminderID uuid.UUID, title string, taskID *uuid.UUID) {
	s.hub.SendTo([]uuid.UUID{userID}, realtime.Event{
		Type: "reminder", Action: "fired",
		Payload: fiber.Map{"id": reminderID, "title": title, "taskId": taskID},
	})
}

// Метод publishSeen предназначен для рассылки отметок о просмотре самому пользователю во все его вкладки.
func (s *Server) publishSeen(userID uuid.UUID, ev seenEvent) {
	s.hub.SendTo([]uuid.UUID{userID}, realtime.Event{Type: "seen", Action: "updated", Payload: ev})
}

// Метод publishNotification предназначен для рассылки события нового уведомления.
func (s *Server) publishNotification(userID uuid.UUID, n models.Notification) {
	s.hub.SendTo([]uuid.UUID{userID}, realtime.Event{Type: "notification", Action: "created", Payload: n})
}

// Тип pendingNotif предназначен для накопления уведомлений внутри транзакции; рассылаются после успешного коммита.
type pendingNotif struct {
	UserID uuid.UUID
	Notif  models.Notification
}

// Метод notifyTaskWatchers предназначен для создания и рассылки уведомлений об изменении задачи ответственным за неё.
func (s *Server) notifyTaskWatchers(ctx context.Context, tx pgx.Tx,
	taskID, boardID, actor uuid.UUID, body string) ([]pendingNotif, error) {

	// Получатели: исполнители, обладатели точечного доступа и участники проекта с правом редактирования.
	rows, err := tx.Query(ctx, `
		SELECT u FROM (
			SELECT ta.user_id AS u FROM app.task_assignees ta WHERE ta.task_id = $1
			UNION
			SELECT g.user_id FROM app.task_grants g WHERE g.task_id = $1
			UNION
			SELECT t.created_by FROM app.tasks t WHERE t.id = $1
			UNION
			SELECT m.user_id
			  FROM app.board_members m
			  JOIN app.tasks t ON t.id = $1
			 WHERE m.board_id = t.board_id AND m.role::text IN ('owner', 'editor')
		) src
		WHERE u IS NOT NULL
		  -- Владелец и редактор проекта могут отключить уведомления по
		  -- задачам, где они не исполнители: на большом проекте это
		  -- непрерывный поток о чужой работе. Настройка не трогает
		  -- уведомления по своим задачам — исполнителей и тех, кому
		  -- задачу открыли, она не касается.
		  AND (u IN (SELECT ta.user_id FROM app.task_assignees ta WHERE ta.task_id = $1)
		       OR u IN (SELECT g.user_id FROM app.task_grants g WHERE g.task_id = $1)
		       OR u IN (SELECT t.created_by FROM app.tasks t WHERE t.id = $1)
		       OR app.wants_foreign_task_notifs(u))`, taskID)
	if err != nil {
		return nil, err
	}
	var targets []uuid.UUID
	for rows.Next() {
		var id uuid.UUID
		if e := rows.Scan(&id); e != nil {
			rows.Close()
			return nil, e
		}
		if id != actor {
			targets = append(targets, id)
		}
	}
	rows.Close()
	if e := rows.Err(); e != nil {
		return nil, e
	}

	var out []pendingNotif
	for _, id := range targets {
		n, e := notifyInsert(ctx, tx, id, body, &boardID, &taskID)
		if e != nil {
			return nil, e
		}
		out = append(out, pendingNotif{UserID: id, Notif: n})
	}
	return out, nil
}

// Функция notifyInsert предназначена для создания уведомления через app.notify (SECURITY DEFINER).
func notifyInsert(ctx context.Context, tx pgx.Tx, userID uuid.UUID, body string, boardID, taskID *uuid.UUID) (models.Notification, error) {
	return notifyInsertCat(ctx, tx, userID, body, "other", boardID, taskID)
}

// Функция notifyInsertCat предназначена для создания уведомления заданной категории через app.notify_cat;
// при отключённой категории возвращается пустая модель (ID равен uuid.Nil).
func notifyInsertCat(ctx context.Context, tx pgx.Tx, userID uuid.UUID, body, category string, boardID, taskID *uuid.UUID) (models.Notification, error) {
	n := models.Notification{Body: body, BoardID: boardID, TaskID: taskID}
	err := tx.QueryRow(ctx, `SELECT id, created_at FROM app.notify_cat($1, $2, $3, $4, $5)`,
		userID, body, category, boardID, taskID).Scan(&n.ID, &n.CreatedAt)
	if err == pgx.ErrNoRows {
		return models.Notification{}, nil // категория отключена — тихо пропускаем
	}
	return n, err
}

// Метод flushNotifs предназначен для рассылки накопленных уведомлений после коммита.
func (s *Server) flushNotifs(pending []pendingNotif) {
	for _, p := range pending {
		go s.publishNotification(p.UserID, p.Notif)
	}
}

// Метод notifyWatchersAbout предназначен для создания уведомления всем, кому доступна задача, кроме инициатора;
// получатели определяются функцией app.notify_task_watchers.
func (s *Server) notifyWatchersAbout(ctx context.Context, tx pgx.Tx,
	taskID, actor uuid.UUID, what string) ([]uuid.UUID, error) {

	var title, name string
	if e := tx.QueryRow(ctx, `
		SELECT t.title, COALESCE(u.full_name, 'Пользователь')
		  FROM app.tasks t LEFT JOIN app.users u ON u.id = $2
		 WHERE t.id = $1`, taskID, actor).Scan(&title, &name); e != nil {
		return nil, e
	}
	return s.notifyWatchers(ctx, tx, taskID, actor, notifyPhrase(name, what, "задаче", title))
}

// Функция notifyPhrase предназначена для формирования текста уведомления по правилу «кто, что, где»;
// место (в предложном падеже) и его название необязательны.
func notifyPhrase(actor, what, place, placeTitle string) string {
	out := actor + " " + what
	if place != "" && placeTitle != "" {
		out += " в " + place + " «" + placeTitle + "»"
	}
	return out
}

// Метод notifyWatchers предназначен для создания уведомления наблюдателям задачи и возврата списка получателей.
func (s *Server) notifyWatchers(ctx context.Context, tx pgx.Tx, taskID, actor uuid.UUID, body string) ([]uuid.UUID, error) {
	rows, err := tx.Query(ctx,
		`SELECT * FROM app.notify_task_watchers($1, $2, $3)`, taskID, actor, body)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var ids []uuid.UUID
	for rows.Next() {
		var id uuid.UUID
		if e := rows.Scan(&id); e != nil {
			return nil, e
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// Метод pingNotifications предназначен для отправки события «есть новое уведомление» без содержимого.
func (s *Server) pingNotifications(userIDs []uuid.UUID) {
	if len(userIDs) == 0 {
		return
	}
	s.hub.SendTo(userIDs, realtime.Event{
		Type: "notification", Action: "created",
	})
}
