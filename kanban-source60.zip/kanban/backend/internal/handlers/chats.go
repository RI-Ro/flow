// Модуль предназначен для переписки сотрудников: личные и групповые чаты, сообщения, файлы, опросы,
// отметки прочтения и рассылка событий участникам. Чаты видны только участникам и не связаны с проектами.

package handlers

import (
	"context"
	"errors"
	"log/slog"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/storage"
)

// Тип chatMessage предназначен для описания сообщения чата.

type chatMessage struct {
	ID        uuid.UUID  `json:"id"`
	ChatID    uuid.UUID  `json:"chatId"`
	AuthorID  *uuid.UUID `json:"authorId"`
	Body      string     `json:"body"`
	CreatedAt time.Time  `json:"createdAt"`
	EditedAt  *time.Time `json:"editedAt"`
	Deleted   bool       `json:"deleted"`
	// Описание файла включено в сообщение, чтобы не запрашивать каждое вложение отдельно.
	FileID      *uuid.UUID `json:"fileId"`
	Filename    string     `json:"filename"`
	MIME        string     `json:"mime"`
	Size        int64      `json:"size"`
	Previewable bool       `json:"previewable"`
}

// Тип chatInfo предназначен для описания чата в списке.
type chatInfo struct {
	ID          uuid.UUID   `json:"id"`
	Kind        string      `json:"kind"`
	Title       string      `json:"title"`
	OwnerID     *uuid.UUID  `json:"ownerId"`
	Members     []uuid.UUID `json:"members"`
	Unread      int         `json:"unread"`
	LastBody    string      `json:"lastBody"`
	LastAt      *time.Time  `json:"lastAt"`
	LastAuthor  *uuid.UUID  `json:"lastAuthorId"`
	// Момент, до которого переписку прочитали все остальные участники (для отметок прочтения).
	ReadThrough *time.Time  `json:"readThrough"`
	// Идентификатор файла картинки группового чата.
	AvatarID *uuid.UUID `json:"avatarId"`
	UpdatedAt   time.Time   `json:"updatedAt"`
}

const chatMessageCols = `
	m.id, m.chat_id, m.author_id,
	CASE WHEN m.deleted_at IS NULL THEN m.body ELSE '' END,
	m.created_at, m.edited_at, (m.deleted_at IS NOT NULL),
	m.file_id, COALESCE(f.filename, ''), COALESCE(f.mime_type, ''), COALESCE(f.size_bytes, 0)`

// Функция scanChatMessage предназначена для чтения строки запроса в структуру chatMessage.
func scanChatMessage(row pgx.Row) (chatMessage, error) {
	var m chatMessage
	err := row.Scan(&m.ID, &m.ChatID, &m.AuthorID, &m.Body, &m.CreatedAt,
		&m.EditedAt, &m.Deleted, &m.FileID, &m.Filename, &m.MIME, &m.Size)
	m.Previewable = previewable[m.MIME]
	return m, err
}

// Метод ListChats предназначен для получения чатов пользователя с последним сообщением и числом непрочитанных одним запросом.
func (s *Server) ListChats(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []chatInfo{}

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT c.id, c.kind, c.title, c.owner_id, c.updated_at, c.avatar_file_id,
			       COALESCE(array_agg(DISTINCT mem.user_id)
			                FILTER (WHERE mem.user_id IS NOT NULL), '{}'),
			       (SELECT count(*) FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id
			           AND msg.deleted_at IS NULL
			           AND msg.author_id IS DISTINCT FROM $1
			           AND msg.created_at > GREATEST(me.last_read_at, me.cleared_at)),
			       (SELECT CASE WHEN msg.deleted_at IS NOT NULL THEN 'сообщение удалено'
			                    WHEN msg.body <> '' THEN msg.body
			                    ELSE 'файл' END
			          FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id AND msg.created_at > me.cleared_at
			         ORDER BY msg.created_at DESC LIMIT 1),
			       (SELECT msg.created_at FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id AND msg.created_at > me.cleared_at
			         ORDER BY msg.created_at DESC LIMIT 1),
			       (SELECT msg.author_id FROM app.chat_messages msg
			         WHERE msg.chat_id = c.id AND msg.created_at > me.cleared_at
			         ORDER BY msg.created_at DESC LIMIT 1),
			       app.chat_read_through(c.id, $1)
			  FROM app.chats c
			  JOIN app.chat_members me  ON me.chat_id = c.id AND me.user_id = $1
			  LEFT JOIN app.chat_members mem ON mem.chat_id = c.id
			 -- Скрытый чат не показываем, пока в нём не появится новое
			 -- сообщение: убрал у себя — значит убрал, но написавшему
			 -- собеседнику ответить всё же нужно.
			 WHERE me.hidden_at IS NULL
			    OR EXISTS (SELECT 1 FROM app.chat_messages msg
			                WHERE msg.chat_id = c.id AND msg.created_at > me.hidden_at)
			 GROUP BY c.id, c.kind, c.title, c.owner_id, c.updated_at, c.avatar_file_id,
			          me.last_read_at, me.cleared_at
			 ORDER BY 10 DESC NULLS LAST, c.updated_at DESC`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var ci chatInfo
			var lastBody *string
			if e := rows.Scan(&ci.ID, &ci.Kind, &ci.Title, &ci.OwnerID, &ci.UpdatedAt,
				&ci.AvatarID, &ci.Members, &ci.Unread, &lastBody, &ci.LastAt,
				&ci.LastAuthor, &ci.ReadThrough); e != nil {
				return e
			}
			if lastBody != nil {
				ci.LastBody = *lastBody
			}
			out = append(out, ci)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Тип newChatInput предназначен для разбора тела запроса создания чата.
type newChatInput struct {
	Kind    string      `json:"kind"`    // direct | group
	Title   string      `json:"title"`   // только для группового
	UserID  *uuid.UUID  `json:"userId"`  // только для личного
	Members []uuid.UUID `json:"members"` // только для группового
}

// Метод CreateChat предназначен для создания личного или группового чата. Личный чат создаётся через
// app.ensure_direct_chat, которая исключает дубли при одновременных запросах.
func (s *Server) CreateChat(c *fiber.Ctx) error {
	var in newChatInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var chatID uuid.UUID
	var members []uuid.UUID

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		switch in.Kind {
		case "direct":
			if in.UserID == nil || *in.UserID == uid {
				return httpx.Err(fiber.StatusBadRequest, "bad_user",
					"Выберите собеседника")
			}
			if e := tx.QueryRow(c.Context(),
				`SELECT app.ensure_direct_chat($1, $2)`, uid, *in.UserID).Scan(&chatID); e != nil {
				return e
			}
			members = []uuid.UUID{uid, *in.UserID}

		case "group":
			title := strings.TrimSpace(in.Title)
			if title == "" {
				return httpx.Err(fiber.StatusBadRequest, "no_title",
					"У группового чата должно быть название")
			}
			// Чат создаётся функцией БД: INSERT ... RETURNING требует права чтения строки, которых у создателя ещё нет.
			seen := map[uuid.UUID]bool{uid: true}
			members = []uuid.UUID{uid}
			for _, m := range in.Members {
				if m == uuid.Nil || seen[m] {
					continue
				}
				seen[m] = true
				members = append(members, m)
			}
			if e := tx.QueryRow(c.Context(),
				`SELECT app.create_group_chat($1, $2, $3)`,
				uid, title, members[1:]).Scan(&chatID); e != nil {
				return e
			}

		default:
			return httpx.Err(fiber.StatusBadRequest, "bad_kind",
				"Чат бывает личным или групповым")
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	go s.publishChat(members, chatID, "created")
	return httpx.JSON(c, fiber.StatusCreated, fiber.Map{"id": chatID})
}

// Тип chatTitleInput предназначен для разбора тела запроса переименования чата.
type chatTitleInput struct {
	Title string `json:"title"`
}

// Метод RenameChat предназначен для переименования группового чата.
func (s *Server) RenameChat(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chatTitleInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	title := strings.TrimSpace(in.Title)
	if title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_title",
			"Название не может быть пустым"))
	}
	uid := s.uid(c)

	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET title = $2, updated_at = now() WHERE id = $1`, chatID, title)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			// Политика chats_update допускает изменение только владельцем группового чата.
			return httpx.Err(fiber.StatusForbidden, "not_owner",
				"Переименовать чат может только его владелец")
		}
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(members, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID, "title": title})
}

// Тип chatMemberInput предназначен для разбора тела запроса добавления участника.
type chatMemberInput struct {
	UserID uuid.UUID `json:"userId"`
}

// Метод AddChatMember предназначен для добавления участника в групповой чат.
func (s *Server) AddChatMember(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chatMemberInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var kind string
		if e := tx.QueryRow(c.Context(),
			`SELECT kind FROM app.chats WHERE id = $1`, chatID).Scan(&kind); e != nil {
			return e
		}
		if kind != "group" {
			return httpx.Err(fiber.StatusBadRequest, "not_group",
				"Участников можно добавлять только в групповой чат")
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.chat_members (chat_id, user_id) VALUES ($1, $2)
			 ON CONFLICT DO NOTHING`, chatID, in.UserID); e != nil {
			return e
		}
		var e error
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(members, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// Метод RemoveChatMember предназначен для удаления участника из группового чата.
func (s *Server) RemoveChatMember(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	userID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	// Состав до удаления нужен для отправки события удалённому участнику.
	before := s.chatMembers(c.Context(), chatID)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var owner *uuid.UUID
		if e := tx.QueryRow(c.Context(),
			`SELECT owner_id FROM app.chats WHERE id = $1`, chatID).Scan(&owner); e != nil {
			return e
		}
		if owner != nil && *owner == userID {
			return httpx.Err(fiber.StatusBadRequest, "owner_stays",
				"Владельца нельзя убрать из чата")
		}
		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.chat_members WHERE chat_id = $1 AND user_id = $2`, chatID, userID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChat(before, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// Метод ListMessages предназначен для получения переписки; параметр q выполняет поиск по тексту и именам файлов.
func (s *Server) ListMessages(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	q := strings.TrimSpace(c.Query("q"))

	out := []chatMessage{}
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.chat_id = $1
			   -- Сообщения, убранные этим человеком у себя, ему не
			   -- показываются; у остальных они на месте.
			   AND m.created_at > (SELECT cleared_at FROM app.chat_members
			                        WHERE chat_id = $1 AND user_id = $3)
			   AND ($2 = '' OR m.body ILIKE '%' || $2 || '%'
			                OR COALESCE(f.filename, '') ILIKE '%' || $2 || '%')
			 ORDER BY m.created_at DESC
			 LIMIT 300`, chatID, q, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			m, e := scanChatMessage(rows)
			if e != nil {
				return e
			}
			out = append(out, m)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	// Сообщения выбираются с конца и возвращаются по возрастанию времени.
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Тип messageInput предназначен для разбора тела запроса отправки сообщения.
type messageInput struct {
	Body   string     `json:"body"`
	FileID *uuid.UUID `json:"fileId"`
}

// Метод SendMessage предназначен для отправки сообщения в чат.
func (s *Server) SendMessage(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in messageInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" && in.FileID == nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty",
			"Пустое сообщение отправить нельзя"))
	}
	uid := s.uid(c)

	var m chatMessage
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var id uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chat_messages (chat_id, author_id, body, file_id)
			VALUES ($1, $2, $3, $4) RETURNING id`, chatID, uid, body, in.FileID).Scan(&id); e != nil {
			return e
		}
		// Время чата обновляется вместе с сообщением: по нему сортируется список чатов.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET updated_at = now() WHERE id = $1`, chatID); e != nil {
			return e
		}
		// Собственное сообщение считается прочитанным.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		row := tx.QueryRow(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, id)
		var e error
		if m, e = scanChatMessage(row); e != nil {
			return e
		}
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishMessage(members, m, "created")
	return httpx.JSON(c, fiber.StatusCreated, m)
}

// Метод UploadChatFile предназначен для приёма файла и немедленной отправки его сообщением.
func (s *Server) UploadChatFile(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	file, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer file.Close()

	stored, err := s.files.Save(file, header.Filename)
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", err.Error()))
	}

	caption := strings.TrimSpace(c.FormValue("body"))

	var m chatMessage
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var fileID uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
			VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
			uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).
			Scan(&fileID); e != nil {
			return e
		}
		var id uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chat_messages (chat_id, author_id, body, file_id)
			VALUES ($1, $2, $3, $4) RETURNING id`,
			chatID, uid, caption, fileID).Scan(&id); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chats SET updated_at = now() WHERE id = $1`, chatID); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		row := tx.QueryRow(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, id)
		var e error
		if m, e = scanChatMessage(row); e != nil {
			return e
		}
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, err)
	}
	go s.publishMessage(members, m, "created")
	return httpx.JSON(c, fiber.StatusCreated, m)
}

// Метод DownloadChatFile предназначен для выдачи файла из переписки; доступ определяет политика files_select_chat.
func (s *Server) DownloadChatFile(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var key, filename, mime string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.filename, f.mime_type
			  FROM app.chat_messages m
			  JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, msgID).Scan(&key, &filename, &mime)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mime, filename, c.Query("download") == "1")
}

// Метод EditMessage предназначен для изменения сообщения автором.
func (s *Server) EditMessage(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in messageInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty",
			"Текст сообщения не может быть пустым. Чтобы убрать его, удалите сообщение"))
	}
	uid := s.uid(c)

	var m chatMessage
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			WITH upd AS (
				UPDATE app.chat_messages
				   SET body = $2, edited_at = now()
				 WHERE id = $1 AND deleted_at IS NULL
				 RETURNING id
			)
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  JOIN upd ON upd.id = m.id
			  LEFT JOIN app.files f ON f.id = m.file_id`, msgID, body)
		var e error
		if m, e = scanChatMessage(row); e != nil {
			return e
		}
		members, e = chatMembersTx(c.Context(), tx, m.ChatID)
		return e
	})
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_author",
				"Править сообщение может только его автор"))
		}
		return httpx.Fail(c, err)
	}
	go s.publishMessage(members, m, "updated")
	return httpx.JSON(c, fiber.StatusOK, m)
}

// Метод DeleteMessage предназначен для мягкого удаления сообщения: тело очищается, сообщение остаётся в ленте.
func (s *Server) DeleteMessage(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var m chatMessage
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		row := tx.QueryRow(c.Context(), `
			WITH upd AS (
				UPDATE app.chat_messages
				   SET deleted_at = now(), body = '', file_id = NULL
				 WHERE id = $1
				 RETURNING id
			)
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  JOIN upd ON upd.id = m.id
			  LEFT JOIN app.files f ON f.id = m.file_id`, msgID)
		var e error
		if m, e = scanChatMessage(row); e != nil {
			return e
		}
		members, e = chatMembersTx(c.Context(), tx, m.ChatID)
		return e
	})
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_author",
				"Удалить сообщение может только его автор"))
		}
		return httpx.Fail(c, err)
	}
	go s.publishMessage(members, m, "deleted")
	return httpx.JSON(c, fiber.StatusOK, m)
}

// Метод MarkChatRead предназначен для сдвига отметки прочтения при входе пользователя в чат.
func (s *Server) MarkChatRead(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var total int
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.chat_members SET last_read_at = now()
			  WHERE chat_id = $1 AND user_id = $2`, chatID, uid); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT app.chat_unread_total($1)`, uid).Scan(&total); e != nil {
			return e
		}
		var e error
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	// Событие отправляется остальным участникам для обновления отметок прочтения.
	go s.publishChat(members, chatID, "read")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"chatId": chatID, "unreadTotal": total})
}

// Функция chatMembersTx предназначена для получения состава чата в транзакции через app.chat_watchers
// (прямой запрос под AsService не видит строк из-за RLS).
func chatMembersTx(ctx context.Context, tx pgx.Tx, chatID uuid.UUID) ([]uuid.UUID, error) {
	rows, err := tx.Query(ctx,
		`SELECT user_id FROM app.chat_members WHERE chat_id = $1`, chatID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []uuid.UUID
	for rows.Next() {
		var id uuid.UUID
		if e := rows.Scan(&id); e != nil {
			return nil, e
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// Метод chatMembers предназначен для получения состава чата отдельным запросом; ошибка записывается в журнал.
func (s *Server) chatMembers(ctx context.Context, chatID uuid.UUID) []uuid.UUID {
	var ids []uuid.UUID
	err := s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.chat_watchers($1)`, chatID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		slog.Error("не удалось получить состав чата для рассылки",
			"error", err, "chat", chatID)
	}
	return ids
}

// Метод DeleteChat предназначен для удаления чата: группового — владельцем, личного — любым из двух участников.
func (s *Server) DeleteChat(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	// Состав до удаления нужен для отправки события.
	before := s.chatMembers(c.Context(), chatID)

	var ok bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT app.delete_chat_for_me($1, $2)`, chatID, uid).Scan(&ok)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_member",
			"Удалить можно только тот чат, в котором вы состоите"))
	}
	// Событие отправляется всем бывшим участникам.
	go s.publishChat(before, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID})
}

// Метод ClearChat предназначен для очистки переписки с сохранением чата.
func (s *Server) ClearChat(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var ok bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT app.clear_chat_for_me($1, $2)`, chatID, uid).Scan(&ok)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_member",
			"Очистить можно только тот чат, в котором вы состоите"))
	}
	// Событие остальным не отправляется.
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID})
}

// Тип pollInput предназначен для разбора тела запроса создания опроса.

type pollInput struct {
	Question string   `json:"question"`
	Options  []string `json:"options"`
	Multiple bool     `json:"multiple"`
}

// Метод CreatePoll предназначен для создания опроса сообщением особого вида в ленте чата.
func (s *Server) CreatePoll(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in pollInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	opts := make([]string, 0, len(in.Options))
	for _, o := range in.Options {
		if v := strings.TrimSpace(o); v != "" {
			opts = append(opts, v)
		}
	}
	if strings.TrimSpace(in.Question) == "" || len(opts) < 2 {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_poll",
			"Нужен вопрос и хотя бы два варианта ответа"))
	}
	uid := s.uid(c)

	var m chatMessage
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var msgID uuid.UUID
		if e := tx.QueryRow(c.Context(),
			`SELECT app.create_poll($1, $2, $3, $4, $5)`,
			chatID, uid, in.Question, opts, in.Multiple).Scan(&msgID); e != nil {
			return e
		}
		row := tx.QueryRow(c.Context(), `
			SELECT `+chatMessageCols+`
			  FROM app.chat_messages m
			  LEFT JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, msgID)
		var e error
		if m, e = scanChatMessage(row); e != nil {
			return e
		}
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishMessage(members, m, "created")
	return httpx.JSON(c, fiber.StatusCreated, m)
}

// Тип pollVote предназначен для описания голоса с временем голосования.
type pollVote struct {
	UserID  uuid.UUID `json:"userId"`
	VotedAt time.Time `json:"votedAt"`
}

// Тип pollOption предназначен для описания варианта опроса с голосами.
type pollOption struct {
	ID    uuid.UUID  `json:"id"`
	Body  string     `json:"body"`
	Votes []pollVote `json:"votes"`
}

// Тип pollView предназначен для описания опроса с вариантами.
type pollView struct {
	ID        uuid.UUID    `json:"id"`
	MessageID uuid.UUID    `json:"messageId"`
	Question  string       `json:"question"`
	Multiple  bool         `json:"multiple"`
	Closed    bool         `json:"closed"`
	Options   []pollOption `json:"options"`
}

// Метод ListPolls предназначен для получения опросов чата с голосами одним запросом.
func (s *Server) ListPolls(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	out := []pollView{}
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT p.id, p.message_id, p.question, p.multiple, (p.closed_at IS NOT NULL),
			       o.id, o.body,
			       COALESCE(array_agg(v.user_id ORDER BY v.voted_at)
			                FILTER (WHERE v.user_id IS NOT NULL), '{}'),
			       COALESCE(array_agg(v.voted_at ORDER BY v.voted_at)
			                FILTER (WHERE v.user_id IS NOT NULL), '{}')
			  FROM app.chat_polls p
			  JOIN app.chat_messages m ON m.id = p.message_id
			  JOIN app.chat_poll_options o ON o.poll_id = p.id
			  LEFT JOIN app.chat_poll_votes v ON v.option_id = o.id
			 WHERE m.chat_id = $1
			 GROUP BY p.id, p.message_id, p.question, p.multiple, p.closed_at, o.id, o.body, o.position
			 ORDER BY p.created_at, o.position`, chatID)
		if e != nil {
			return e
		}
		defer rows.Close()
		byID := map[uuid.UUID]int{}
		for rows.Next() {
			var pv pollView
			var opt pollOption
			var voters []uuid.UUID
			var times []time.Time
			if e := rows.Scan(&pv.ID, &pv.MessageID, &pv.Question, &pv.Multiple, &pv.Closed,
				&opt.ID, &opt.Body, &voters, &times); e != nil {
				return e
			}
			// Массивы идентификаторов и времени объединяются в пары в коде.
			opt.Votes = make([]pollVote, 0, len(voters))
			for i, v := range voters {
				at := time.Time{}
				if i < len(times) {
					at = times[i]
				}
				opt.Votes = append(opt.Votes, pollVote{UserID: v, VotedAt: at})
			}
			idx, ok := byID[pv.ID]
			if !ok {
				pv.Options = []pollOption{}
				out = append(out, pv)
				idx = len(out) - 1
				byID[pv.ID] = idx
			}
			out[idx].Options = append(out[idx].Options, opt)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

// Метод Vote предназначен для подачи или снятия голоса за вариант; повторное нажатие снимает голос.
func (s *Server) Vote(c *fiber.Ctx) error {
	optionID, err := param(c, "optionID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var ok bool
	var chatID uuid.UUID
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT app.cast_vote($1, $2)`, optionID, uid).Scan(&ok); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(), `
			SELECT m.chat_id FROM app.chat_poll_options o
			  JOIN app.chat_polls p ON p.id = o.poll_id
			  JOIN app.chat_messages m ON m.id = p.message_id
			 WHERE o.id = $1`, optionID).Scan(&chatID); e != nil {
			return e
		}
		// Состав участников определяется в той же транзакции.
		var e error
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusConflict, "vote_rejected",
			"Голос не принят: опрос закрыт или недоступен"))
	}
	go s.publishChat(members, chatID, "poll")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// Метод ClosePoll предназначен для закрытия опроса.
func (s *Server) ClosePoll(c *fiber.Ctx) error {
	pollID, err := param(c, "pollID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var ok bool
	var chatID uuid.UUID
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `SELECT app.close_poll($1, $2)`, pollID, uid).Scan(&ok); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT app.poll_chat($1)`, pollID).Scan(&chatID); e != nil {
			return e
		}
		var e error
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_author",
			"Закрыть опрос может только тот, кто его создал"))
	}
	go s.publishChat(members, chatID, "poll")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"ok": true})
}

// Метод SetChatAvatar предназначен для установки и снятия картинки группового чата; файл хранится в app.files.
func (s *Server) SetChatAvatar(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var fileID *uuid.UUID
	var stored *storage.Stored

	// Отсутствие файла означает снятие картинки.
	if header, e := c.FormFile("file"); e == nil && header != nil {
		if !strings.HasPrefix(header.Header.Get("Content-Type"), "image/") {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "not_image",
				"Картинкой чата может быть только изображение"))
		}
		file, e := header.Open()
		if e != nil {
			return httpx.Fail(c, e)
		}
		defer file.Close()
		st, e := s.files.Save(file, header.Filename)
		if e != nil {
			return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", e.Error()))
		}
		// Save возвращает указатель.
		stored = st
	}

	var ok bool
	var members []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if stored != nil {
			var id uuid.UUID
			if e := tx.QueryRow(c.Context(), `
				INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
				VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
				uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).
				Scan(&id); e != nil {
				return e
			}
			fileID = &id
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT app.set_chat_avatar($1, $2, $3)`, chatID, uid, fileID).Scan(&ok); e != nil {
			return e
		}
		var e error
		members, e = chatMembersTx(c.Context(), tx, chatID)
		return e
	})
	if err != nil {
		if stored != nil {
			_ = s.files.Delete(stored.Key)
		}
		return httpx.Fail(c, err)
	}
	if !ok {
		if stored != nil {
			_ = s.files.Delete(stored.Key)
		}
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_owner",
			"Менять картинку чата может только его владелец"))
	}

	go s.publishChat(members, chatID, "updated")
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"id": chatID, "avatarId": fileID})
}

// Метод DownloadChatAvatar предназначен для выдачи картинки чата; доступ определяет политика files_select_chat_avatar.
func (s *Server) DownloadChatAvatar(c *fiber.Ctx) error {
	chatID, err := param(c, "chatID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var key, filename, mime string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.filename, f.mime_type
			  FROM app.chats c JOIN app.files f ON f.id = c.avatar_file_id
			 WHERE c.id = $1`, chatID).Scan(&key, &filename, &mime)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mime, filename, false)
}

// Метод PreviewChatFile предназначен для выдачи PDF-версии файла переписки.
func (s *Server) PreviewChatFile(c *fiber.Ctx) error {
	msgID, err := param(c, "messageID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var key, filename string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.filename
			  FROM app.chat_messages m JOIN app.files f ON f.id = m.file_id
			 WHERE m.id = $1`, msgID).Scan(&key, &filename)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}

	data, e := s.convertToPDF(c.Context(), key, filename)
	if e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusUnprocessableEntity, "convert_failed", e.Error()))
	}
	return sendConvertedPDF(c, data, filename)
}
