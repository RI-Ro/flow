// Модуль предназначен для работы с текущим пользователем: профиль, смена пароля, справочник сотрудников,
// личная команда и уведомления.

package handlers

import (
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// Метод Me предназначен для получения профиля текущего пользователя.
func (s *Server) Me(c *fiber.Ctx) error {
	u, err := s.loadUser(c.Context(), s.uid(c))
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, u)
}

// Тип profilePatch предназначен для разбора тела запроса изменения профиля.
type profilePatch struct {
	FullName    *string `json:"fullName"`
	Position    *string `json:"position"`
	Phone       *string `json:"phone"`
	AvatarColor *string `json:"avatarColor"`
}

// Метод UpdateMe предназначен для изменения профиля текущего пользователя.
func (s *Server) UpdateMe(c *fiber.Ctx) error {
	var in profilePatch
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		_, e := tx.Exec(c.Context(), `
			UPDATE app.users SET
				full_name    = COALESCE($2, full_name),
				position     = COALESCE($3, position),
				phone        = COALESCE($4, phone),
				avatar_color = COALESCE($5, avatar_color)
			WHERE id = $1`, uid, in.FullName, in.Position, in.Phone, in.AvatarColor)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.Me(c)
}

// Тип passwordChange предназначен для разбора тела запроса смены пароля.
type passwordChange struct {
	Current string `json:"currentPassword"`
	New     string `json:"newPassword"`
}

// Метод ChangePassword предназначен для смены собственного пароля. Требования к паролю определены в internal/auth
// и совпадают с проверкой интерфейса.
func (s *Server) ChangePassword(c *fiber.Ctx) error {
	var in passwordChange
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if e := auth.ValidatePassword(in.New); e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "weak_password", e.Error()))
	}
	if in.New == in.Current {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "same_password",
			"Новый пароль совпадает с текущим"))
	}
	uid := s.uid(c)

	// Текущий пароль подтверждается обязательно.
	var hash string
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// COALESCE: для отключённой учётной записи функция возвращает NULL.
		return tx.QueryRow(c.Context(),
			`SELECT COALESCE(app.my_password_hash(), '')`).Scan(&hash)
	})
	// Сбой запроса и неверный пароль обрабатываются раздельно.
	if err != nil {
		return httpx.Fail(c, err)
	}
	if hash == "" || !auth.CheckPassword(hash, in.Current) {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "bad_password", "Текущий пароль указан неверно"))
	}

	newHash, err := auth.HashPassword(in.New)
	if err != nil {
		return httpx.Fail(c, err)
	}
	var noteIDs []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.users SET password_hash = $2 WHERE id = $1`, uid, newHash); e != nil {
			return e
		}
		// Все сессии, включая текущую, завершаются.
		if _, e := tx.Exec(c.Context(),
			`UPDATE app.refresh_tokens SET revoked_at = now()
			  WHERE user_id = $1 AND revoked_at IS NULL`, uid); e != nil {
			return e
		}
		// Запись в уведомлениях позволяет владельцу заметить смену пароля третьим лицом.
		if _, e := tx.Exec(c.Context(),
			`SELECT app.notify($1, $2, NULL, NULL)`, uid,
			"Пароль вашей учётной записи изменён. Остальные устройства "+
				"разлогинены. Если это были не вы — немедленно обратитесь "+
				"к администратору"); e != nil {
			return e
		}
		noteIDs = append(noteIDs, uid)
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.pingNotifications(noteIDs)

	// Текущему устройству выдаётся новая пара токенов.
	return s.issue(c, uid)
}

// Метод Directory предназначен для получения справочника сотрудников с поиском.
func (s *Server) Directory(c *fiber.Ctx) error {
	q := strings.TrimSpace(c.Query("q"))
	limit := httpx.QueryInt(c, "limit", 200, 1, 1000)

	users := []models.User{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		// Условие и порядок соответствуют индексам users_search_trgm_idx и users_directory_sort_idx.
		rows, e := tx.Query(c.Context(), `
			SELECT id, email, full_name, position, phone, avatar_color, is_active, deleted_at
			  FROM app.users
			 WHERE ($1 = ''
			        OR (full_name || ' ' || position || ' ' || phone) ILIKE '%' || $1 || '%')
			 ORDER BY (deleted_at IS NOT NULL), full_name
			 LIMIT $2`, q, limit)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var u models.User
			var deletedAt *time.Time
			if e := rows.Scan(&u.ID, &u.Email, &u.FullName, &u.Position, &u.Phone,
				&u.AvatarColor, &u.IsActive, &deletedAt); e != nil {
				return e
			}
			u.Deleted = deletedAt != nil
			users = append(users, u)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, users)
}

// Метод GetTeam предназначен для получения личной команды пользователя.
func (s *Server) GetTeam(c *fiber.Ctx) error {
	ids := []uuid.UUID{}
	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT member_id FROM app.team_members WHERE owner_id = $1`, s.uid(c))
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ids)
}

// Метод SetTeam предназначен для замены состава личной команды.
func (s *Server) SetTeam(c *fiber.Ctx) error {
	var ids []uuid.UUID
	if err := httpx.Decode(c, &ids); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `DELETE FROM app.team_members WHERE owner_id = $1`, uid); e != nil {
			return e
		}
		if len(ids) == 0 {
			return nil
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.team_members (owner_id, member_id)
			SELECT $1, u.id FROM unnest($2::uuid[]) AS u(id)
			ON CONFLICT DO NOTHING`, uid, ids)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ids)
}

// Метод ListNotifications предназначен для получения уведомлений пользователя.
func (s *Server) ListNotifications(c *fiber.Ctx) error {
	limit := httpx.QueryInt(c, "limit", 10, 1, 50)
	offset := httpx.QueryInt(c, "offset", 0, 0, 100000)
	includeRead := c.Query("includeRead") == "true"

	items := []models.Notification{}
	var total, unread int

	err := s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `
			SELECT count(*) FILTER (WHERE $1 OR read_at IS NULL), count(*) FILTER (WHERE read_at IS NULL)
			  FROM app.notifications`, includeRead).Scan(&total, &unread); e != nil {
			return e
		}
		rows, e := tx.Query(c.Context(), `
			SELECT id, body, board_id, task_id, chart_id, wb_id, category, read_at, created_at
			  FROM app.notifications
			 WHERE ($1 OR read_at IS NULL)
			 ORDER BY created_at DESC
			 LIMIT $2 OFFSET $3`, includeRead, limit, offset)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var n models.Notification
			var readAt *time.Time
			if e := rows.Scan(&n.ID, &n.Body, &n.BoardID, &n.TaskID, &n.ChartID, &n.WhiteboardID,
				&n.Category, &readAt, &n.CreatedAt); e != nil {
				return e
			}
			n.Read = readAt != nil
			items = append(items, n)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"items": items, "total": total, "unread": unread,
		"limit": limit, "offset": offset,
	})
}

// Метод ReadNotification предназначен для отметки одного уведомления прочитанным.
func (s *Server) ReadNotification(c *fiber.Ctx) error {
	id, err := param(c, "id")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.readNotifications(c, []uuid.UUID{id})
}

// Метод ReadAllNotifications предназначен для отметки всех уведомлений прочитанными.
func (s *Server) ReadAllNotifications(c *fiber.Ctx) error {
	return s.readNotifications(c, nil)
}

// Метод readNotifications предназначен для отметки уведомлений прочитанными и связанных задач (и проектов) просмотренными;
// nil означает все уведомления. Результат передаётся в ответ и событием seen во все вкладки пользователя.
func (s *Server) readNotifications(c *fiber.Ctx, ids []uuid.UUID) error {
	uid := s.uid(c)
	var ev seenEvent
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var arg any
		if ids != nil {
			arg = ids
		}
		rows, e := tx.Query(c.Context(),
			`SELECT kind, entity_id, viewed_at FROM app.read_notifications($1::uuid[])`, arg)
		if e != nil {
			return e
		}
		ev.Items, e = pgx.CollectRows(rows, func(r pgx.CollectableRow) (viewResult, error) {
			var v viewResult
			err := r.Scan(&v.Kind, &v.ID, &v.ViewedAt)
			return v, err
		})
		if e != nil {
			return e
		}
		return tx.QueryRow(c.Context(), `SELECT app.unread_notifications()`).Scan(&ev.Unread)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.publishSeen(uid, ev)
	return httpx.JSON(c, fiber.StatusOK, ev)
}
