// Модуль предназначен для выдачи администратору состояния системы по истории метрик, накопленной приложением.

package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/example/kanban/internal/httpx"
)


// Переменная systemWindows задаёт допустимые периоды отчёта; история в памяти ограничена шестью часами.
var systemWindows = map[string]time.Duration{
	"5m":  5 * time.Minute,
	"15m": 15 * time.Minute,
	"1h":  time.Hour,
	"6h":  6 * time.Hour,
}

// Метод AdminSystem предназначен для выдачи сводки состояния системы за период.
func (s *Server) AdminSystem(c *fiber.Ctx) error {
	if s.samples == nil {
		// При METRICS_ENABLED=false возвращается ответ 503 metrics_disabled.
		return httpx.Fail(c, httpx.Err(fiber.StatusServiceUnavailable, "metrics_disabled",
			"Сбор метрик отключён настройкой METRICS_ENABLED — состояние системы недоступно"))
	}

	window, ok := systemWindows[c.Query("range", "1h")]
	if !ok {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_range",
			"Период может быть 5m, 15m, 1h или 6h"))
	}

	return httpx.JSON(c, fiber.StatusOK, s.samples.Report(window, 180))
}
