// Модуль предназначен для обмена событиями между экземплярами приложения через Redis (PUBLISH/SUBSCRIBE).

package realtime

import (
	"bufio"
	"fmt"
	"log/slog"
	"net"
	"strconv"
	"sync"
	"time"
)

// Тип Bus предназначен для публикации и приёма событий через общий канал Redis. Нужен при нескольких
// процессах (prefork) или серверах, так как список соединений WebSocket хранится в памяти процесса.
// Клиент протокола RESP реализован в модуле без внешней библиотеки: используются команды PUBLISH,
// SUBSCRIBE, AUTH и SELECT. Без адреса Redis шина не создаётся.

type Bus struct {
	addr     string
	password string
	db       int
	channel  string

	// Идентификатор экземпляра; собственные сообщения, вернувшиеся из канала, отбрасываются.
	instance string

	mu      sync.Mutex
	pubConn net.Conn
	pubW    *bufio.Writer
	pubR    *bufio.Reader

	onMessage func(instance string, payload []byte)
	closed    chan struct{}
}

// Функция NewBus предназначена для создания шины.
func NewBus(addr, password string, db int, channel, instance string) *Bus {
	if channel == "" {
		channel = "kanban:events"
	}
	return &Bus{
		addr: addr, password: password, db: db,
		channel: channel, instance: instance,
		closed: make(chan struct{}),
	}
}

// Метод Start предназначен для запуска слушателя подписки. Публикация использует отдельное соединение.
// При обрыве соединение восстанавливается бесконечно с паузой.
func (b *Bus) Start(onMessage func(instance string, payload []byte)) {
	b.onMessage = onMessage
	go func() {
		for {
			select {
			case <-b.closed:
				return
			default:
			}
			if err := b.listen(); err != nil {
				slog.Warn("шина событий: подписка оборвалась", "error", err)
			}
			select {
			case <-b.closed:
				return
			case <-time.After(2 * time.Second):
			}
		}
	}()
}

// Метод Close предназначен для остановки шины.
func (b *Bus) Close() {
	close(b.closed)
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.pubConn != nil {
		_ = b.pubConn.Close()
		b.pubConn = nil
	}
}

// Метод Publish предназначен для отправки события в канал: идентификатор экземпляра, перевод строки и тело.
// Ошибка публикации не прерывает запрос: событие уже доставлено локальным соединениям.
func (b *Bus) Publish(payload []byte) {
	b.mu.Lock()
	defer b.mu.Unlock()

	if err := b.ensurePub(); err != nil {
		slog.Warn("шина событий: нет соединения для публикации", "error", err)
		return
	}
	msg := append([]byte(b.instance+"\n"), payload...)
	if err := writeCommand(b.pubW, "PUBLISH", b.channel, string(msg)); err != nil {
		// Испорченное соединение закрывается; следующая попытка создаёт новое.
		_ = b.pubConn.Close()
		b.pubConn = nil
		slog.Warn("шина событий: не удалось опубликовать", "error", err)
		return
	}
	// Ответ вычитывается из буфера, чтобы не нарушить следующий обмен.
	_ = b.drainReply()
}

// Метод ensurePub предназначен для установки соединения публикации при его отсутствии.
func (b *Bus) ensurePub() error {
	if b.pubConn != nil {
		return nil
	}
	conn, r, err := b.dial()
	if err != nil {
		return err
	}
	b.pubConn = conn
	b.pubW = bufio.NewWriter(conn)
	b.pubR = r
	return nil
}

// Метод drainReply предназначен для вычитывания ответа на PUBLISH.
func (b *Bus) drainReply() error {
	if b.pubR == nil {
		return nil
	}
	_ = b.pubConn.SetReadDeadline(time.Now().Add(2 * time.Second))
	defer b.pubConn.SetReadDeadline(time.Time{})
	_, err := readReply(b.pubR)
	return err
}

// Метод listen предназначен для подписки на канал и чтения сообщений до ошибки.
func (b *Bus) listen() error {
	conn, r, err := b.dial()
	if err != nil {
		return err
	}
	defer conn.Close()

	w := bufio.NewWriter(conn)
	if err := writeCommand(w, "SUBSCRIBE", b.channel); err != nil {
		return err
	}

	for {
		select {
		case <-b.closed:
			return nil
		default:
		}
		// Без ограничения времени ожидания: подписка может быть долго неактивна.
		parts, err := readMessage(r)
		if err != nil {
			return err
		}
		if len(parts) != 3 || parts[0] != "message" {
			continue // подтверждение подписки и прочая служебная переписка
		}
		raw := parts[2]
		nl := indexByte(raw, '\n')
		if nl < 0 {
			continue
		}
		from, payload := raw[:nl], raw[nl+1:]
		if from == b.instance {
			continue // своё уже доставлено
		}
		if b.onMessage != nil {
			b.onMessage(from, []byte(payload))
		}
	}
}

// Метод dial предназначен для подключения к Redis с выполнением AUTH и SELECT.
func (b *Bus) dial() (net.Conn, *bufio.Reader, error) {
	conn, err := net.DialTimeout("tcp", b.addr, 5*time.Second)
	if err != nil {
		return nil, nil, err
	}
	r := bufio.NewReader(conn)
	w := bufio.NewWriter(conn)

	if b.password != "" {
		if err := writeCommand(w, "AUTH", b.password); err != nil {
			conn.Close()
			return nil, nil, err
		}
		if _, err := readReply(r); err != nil {
			conn.Close()
			return nil, nil, fmt.Errorf("AUTH: %w", err)
		}
	}
	if b.db != 0 {
		if err := writeCommand(w, "SELECT", strconv.Itoa(b.db)); err != nil {
			conn.Close()
			return nil, nil, err
		}
		if _, err := readReply(r); err != nil {
			conn.Close()
			return nil, nil, fmt.Errorf("SELECT: %w", err)
		}
	}
	return conn, r, nil
}

// Функция writeCommand предназначена для отправки команды Redis в виде массива строк (RESP).

func writeCommand(w *bufio.Writer, args ...string) error {
	fmt.Fprintf(w, "*%d\r\n", len(args))
	for _, a := range args {
		fmt.Fprintf(w, "$%d\r\n%s\r\n", len(a), a)
	}
	return w.Flush()
}

// Функция readReply предназначена для чтения простого ответа Redis.
func readReply(r *bufio.Reader) (string, error) {
	line, err := r.ReadString('\n')
	if err != nil {
		return "", err
	}
	if len(line) < 1 {
		return "", fmt.Errorf("пустой ответ")
	}
	switch line[0] {
	case '+', ':', '-':
		return trimCRLF(line[1:]), nil
	case '$':
		n, err := strconv.Atoi(trimCRLF(line[1:]))
		if err != nil {
			return "", err
		}
		if n < 0 {
			return "", nil
		}
		buf := make([]byte, n+2) // тело плюс \r\n
		if _, err := ioReadFull(r, buf); err != nil {
			return "", err
		}
		return string(buf[:n]), nil
	case '*':
		// Массив читается функцией readMessage.
		return "", fmt.Errorf("неожиданный массив")
	}
	return "", fmt.Errorf("неизвестный тип ответа: %q", line[0])
}

// Функция readMessage предназначена для чтения сообщения подписки: массив из трёх строк (тип, канал, тело).
func readMessage(r *bufio.Reader) ([]string, error) {
	line, err := r.ReadString('\n')
	if err != nil {
		return nil, err
	}
	if line[0] != '*' {
		return nil, fmt.Errorf("ожидался массив, получено %q", line[0])
	}
	n, err := strconv.Atoi(trimCRLF(line[1:]))
	if err != nil {
		return nil, err
	}
	out := make([]string, 0, n)
	for i := 0; i < n; i++ {
		v, err := readReply(r)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}

// Функция trimCRLF предназначена для удаления завершающего перевода строки.
func trimCRLF(s string) string {
	for len(s) > 0 && (s[len(s)-1] == '\n' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}

// Функция indexByte предназначена для поиска байта в строке.
func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}

// Функция ioReadFull предназначена для чтения точного числа байт из буфера.
func ioReadFull(r *bufio.Reader, buf []byte) (int, error) {
	total := 0
	for total < len(buf) {
		n, err := r.Read(buf[total:])
		total += n
		if err != nil {
			return total, err
		}
	}
	return total, nil
}
