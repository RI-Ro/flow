// Модуль предназначен для запуска HTTP-сервера: загрузки конфигурации, подключения к БД, Redis и метрик,
// запуска фоновых задач и корректной остановки по сигналу.

package main

import (
	"fmt"
	"runtime"
	"context"
	"flag"
	"errors"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/database"
	"github.com/example/kanban/internal/handlers"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/metrics"
	"github.com/example/kanban/internal/realtime"
	"github.com/example/kanban/internal/storage"
)

// Функция main предназначена для запуска run и завершения процесса с кодом 1 при ошибке.
func main() {
	if err := run(); err != nil {
		slog.Error("запуск не удался", "error", err)
		os.Exit(1)
	}
}

// Функция run предназначена для сборки и запуска всех компонентов приложения и ожидания сигнала завершения.
func run() error {
	// Путь к config.yaml задаётся флагом --config или переменной CONFIG_FILE; флаг приоритетнее.
	configPath := flag.String("config", os.Getenv("CONFIG_FILE"),
		"путь к config.yaml (по умолчанию ищется ./config.yaml)")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		return err
	}

	level := slog.LevelDebug
	if cfg.IsProduction() {
		level = slog.LevelInfo
	}
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: level})))

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	db, err := database.New(ctx, cfg.DatabaseURL, cfg.DBPoolSize, cfg.DBMinIdle, cfg.StatementCache)
	if err != nil {
		return err
	}
	defer db.Close()

	files, err := storage.NewLocal(cfg.UploadDir, cfg.MaxUploadBytes)
	if err != nil {
		return err
	}

	// Вне production подробности ошибок БД возвращаются клиенту.
	httpx.SetProduction(cfg.IsProduction())

	// Число процессов prefork определяется через GOMAXPROCS; 0 означает число ядер.
	if cfg.Prefork && cfg.PreforkWorkers > 0 {
		runtime.GOMAXPROCS(cfg.PreforkWorkers)
	}

	hub := realtime.NewHub()

	// Общая шина событий создаётся только при заданном адресе Redis.
	if cfg.RedisAddr != "" {
		// Идентификатор экземпляра (хост и PID) позволяет отличать собственные сообщения шины от чужих.
		host, _ := os.Hostname()
		instance := fmt.Sprintf("%s-%d", host, os.Getpid())

		bus := realtime.NewBus(cfg.RedisAddr, cfg.RedisPassword, cfg.RedisDB,
			cfg.RedisChannel, instance)
		hub.AttachBus(bus)
		defer bus.Close()
		slog.Info("общая шина событий включена",
			"redis", cfg.RedisAddr, "channel", cfg.RedisChannel, "instance", instance)
	}
	am := auth.NewManager(cfg.JWTSecret, cfg.AccessTTL, cfg.RefreshTTL)
	srv := handlers.New(cfg, db, am, files, hub)

	// Метрики Prometheus; состояние БД опрашивается отдельной горутиной раз в 15 секунд.
	if cfg.Metrics {
		reg := metrics.New()
		pg := metrics.NewPGCollector(db.Pool, reg)
		pg.Start(ctx)
		// Сэмплер истории запускается после регистрации датчиков пула и сокетов.
		sampler := metrics.NewSampler(reg, pg)
		srv = srv.WithMetrics(reg, pg, sampler)
		sampler.Start(ctx)
		slog.Info("метрики включены", "endpoint", "/metrics",
			"история", metrics.SampleStep*metrics.SampleKeep)
	}

	// Фоновый опрос напоминаний выполняется раз в минуту.
	srv.StartReminderPoller(ctx, db.Pool)
	app := srv.App()

	errCh := make(chan error, 1)
	go func() {
		slog.Info("сервер запущен",
			"addr", cfg.Addr, "env", cfg.Env, "dbPool", cfg.DBPoolSize)
		if err := app.Listen(cfg.Addr); err != nil {
			errCh <- err
		}
	}()

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		slog.Info("получен сигнал завершения, останавливаемся")
	}

	shutdownCtx, stop := context.WithTimeout(context.Background(), 20*time.Second)
	defer stop()
	if err := app.ShutdownWithContext(shutdownCtx); err != nil && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	return nil
}
