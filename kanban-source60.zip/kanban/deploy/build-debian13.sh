#!/usr/bin/env bash
# Скрипт предназначен для сборки приложения под Debian 13 (trixie), по умолчанию linux/amd64.
# Для ARM64: GOARCH=arm64 ./deploy/build-debian13.sh
#
# Пакеты на сборочной машине:
#   sudo apt-get install -y golang-go nodejs npm   # Go >= 1.22, Node >= 18
# Результат: dist-debian13/{api,web,config.yaml,kanban.service,migrations,kanban_deploy.sql,LICENSE}
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${OUT:-$ROOT/dist-debian13}"
export GOOS=linux GOARCH="${GOARCH:-amd64}" CGO_ENABLED=0

rm -rf "$OUT"; mkdir -p "$OUT"

echo "→ backend ($GOOS/$GOARCH)"
( cd "$ROOT/backend" && go build -trimpath -ldflags="-s -w" -o "$OUT/api" ./cmd/api )

echo "→ frontend"
( cd "$ROOT/frontend" && npm ci --no-audit --no-fund && npm run build )
cp -r "$ROOT/frontend/dist" "$OUT/web"

cp -r "$ROOT/backend/migrations" "$OUT/migrations"
"$ROOT/deploy/migrations/build.sh" >/dev/null
cp "$ROOT/deploy/migrations/kanban_deploy.sql" "$OUT/kanban_deploy.sql"
cp "$ROOT/LICENSE" "$OUT/LICENSE"
cp "$ROOT/deploy/config.debian13.yaml" "$OUT/config.yaml"
cp "$ROOT/deploy/kanban.service" "$OUT/kanban.service"
sed -i "s|__JWT_SECRET__|$(openssl rand -base64 48 | tr -d '\n')|" "$OUT/config.yaml"
chmod 600 "$OUT/config.yaml"

echo "Готово: $OUT"
file "$OUT/api" 2>/dev/null || true
