// Модуль предназначен для настройки сборщика Vite: плагин React, порт dev-сервера, прокси к API и каталог сборки.

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Маршрут /api/ws указан первым: Vite выбирает первое совпадение по префиксу, а правило "/api" перехватывало бы
      // и WebSocket-соединение, передавая его в http-прокси без апгрейда протокола.
      "/api/ws": { target: "ws://localhost:8080", ws: true, changeOrigin: true },
      "/api": { target: "http://localhost:8080", changeOrigin: true },
    },
  },
  build: { outDir: "dist", sourcemap: true },
});
