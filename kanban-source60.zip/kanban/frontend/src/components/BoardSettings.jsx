// Модуль предназначен для окна настроек проекта: участники и роли, колонки, фон, удаление проекта.

import React, { useRef, useState } from "react";
import { Trash2, Plus, ChevronLeft, ChevronRight, GripVertical, Upload, X, ImageOff } from "lucide-react";
import { api } from "../lib/api.js";
import { ALL_BACKGROUNDS, bgById, bgThumbUrl, ROLE_LABEL, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, Toggle, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Компонент BoardSettings предназначен для настроек проекта; удаление проекта доступно владельцу (isOwner).
export default function BoardSettings({ theme, board, columns, tasks, directory, team = [], currentUser, isOwner = false, onClose, onSaved, onRequestDeleteBoard, onError }) {
  const [tab, setTab] = useState("general");
  const [title, setTitle] = useState(board.title);
  const [description, setDescription] = useState(board.description || "");
  const [bgPreset, setBgPreset] = useState(board.bgPreset || "none");
  const [bgBlur, setBgBlur] = useState(board.bgBlur || false);
  const [bgFileId, setBgFileId] = useState(board.bgFileId || null);
  const [bgStamp, setBgStamp] = useState(Date.now());
  const [cols, setCols] = useState(columns.map((c) => ({ ...c })));
  const [members, setMembers] = useState(board.members.map((m) => ({ ...m })));
  const [memberSearch, setMemberSearch] = useState("");
  const [columnWarning, setColumnWarning] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  const save = async () => {
    setSaving(true);
    try {
      await api.updateBoard(board.id, { title: title.trim() || board.title, description, bgPreset, bgBlur });
      await api.saveColumns(board.id, cols.map((c) => ({
        id: c.id?.startsWith("new-") ? null : c.id,
        title: c.title, color: c.color, wipLimit: Number(c.wipLimit) || 0, isDone: Boolean(c.isDone),
      })));
      await api.setMembers(board.id, members.filter((m) => m.role !== "owner").map((m) => ({ userId: m.userId, role: m.role })));
      onSaved();
      onClose();
    } catch (e) {
      onError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const uploadBg = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const res = await api.uploadBackground(board.id, file);
      setBgFileId(res.fileId);
      setBgPreset("custom");
      setBgStamp(Date.now());
    } catch (e) {
      onError(e.message);
    } finally {
      setUploading(false);
    }
  };

  const dropBg = async () => {
    try {
      await api.deleteBackground(board.id);
      setBgFileId(null);
      setBgPreset("none");
    } catch (e) {
      onError(e.message);
    }
  };

  const patchCol = (id, p) => setCols((cs) => cs.map((c) => (c.id === id ? { ...c, ...p } : c)));
  const addColumn = () => setCols((cs) => [...cs, { id: `new-${Date.now()}`, title: "Новая колонка", color: "#8892A8", wipLimit: 0, isDone: false }]);

  const moveCol = (index, dir) =>
    setCols((cs) => {
      const next = [...cs];
      const target = index + dir;
      if (target < 0 || target >= next.length) return cs;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });

  const removeColumn = (col) => {
    if (cols.length === 1) return onError("На доске должна остаться хотя бы одна колонка");
    const count = tasks.filter((t) => t.columnId === col.id).length;
    if (count > 0) return setColumnWarning({ col, count });
    setCols((cs) => cs.filter((c) => c.id !== col.id));
  };

  // Доступ к проекту выдаётся только пользователям из своей команды и не выдаётся самому себе (владелец уже состоит в проекте).
  const teamSet = new Set(team);
  const candidates = directory
    .filter((u) => teamSet.has(u.id))
    .filter((u) => u.id !== currentUser?.id)
    .filter((u) => !members.some((m) => m.userId === u.id))
    .filter((u) => `${u.fullName} ${u.position}`.toLowerCase().includes(memberSearch.toLowerCase()))
    .slice(0, 8);

  const activePreset = bgById(bgPreset);

  return (
    // Окно той же ширины, что карточка задачи: участники, колонки и фон размещаются в одном окне.
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" padded={false} geometryKey="board-settings">
      <div className="px-6 pt-2 pb-1"><ModalHeader theme={theme} title="Настройки проекта" onClose={onClose} /></div>

      <nav className="px-6 pb-1" aria-label="Разделы настроек">
        <div className="segmented">
          {[["general", "Общее"], ["columns", "Колонки"], ["access", "Доступ"]].map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)} aria-pressed={tab === key}>
              {label}
            </button>
          ))}
        </div>
      </nav>

      <div className="px-6 py-5">
        {tab === "general" && (
          <div>
            <Field label="Название проекта" theme={theme}>
              <input value={title} onChange={(e) => setTitle(e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-10 text-[14px] outline-none" />
            </Field>
            <Field label="Описание" theme={theme}>
              <input value={description} onChange={(e) => setDescription(e.target.value)} style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-10 text-[14px] outline-none" />
            </Field>

            <Field label="Фон доски" theme={theme}>
              <div className="grid grid-cols-4 gap-2">
                {ALL_BACKGROUNDS.map((p) => {
                  // Для фотографий показывается уменьшенная копия вместо полноразмерного файла.
                  const thumb = bgThumbUrl(p.id);
                  return (
                  <button key={p.id} onClick={() => setBgPreset(p.id)}
                    style={{
                      background: thumb ? `url(${thumb}) center/cover` : p.css || theme.surfaceAlt,
                      backgroundSize: thumb ? "cover" : p.size || "cover",
                      border: `2px solid ${bgPreset === p.id ? theme.accent : theme.border}`,
                    }}
                    className="h-12 rounded-xl flex items-end p-1.5 transition-transform duration-150 hover:scale-[1.03]" title={p.label} aria-pressed={bgPreset === p.id}>
                    <span
                      style={{
                        color: p.css || thumb ? "#fff" : theme.textMuted,
                        textShadow: p.css || thumb ? "0 1px 3px rgba(0,0,0,.7)" : "none",
                      }}
                      className="text-[9.5px] font-medium leading-none">
                      {p.label}
                    </span>
                  </button>
                  );
                })}
              </div>

              <div className="mt-3">
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { uploadBg(e.target.files?.[0]); e.target.value = ""; }} />
                {bgFileId ? (
                  <div className="flex items-center gap-2">
                    <img src={api.backgroundUrl(board.id, bgStamp)} alt="Фон проекта" className="w-20 h-12 rounded-xl object-cover" style={{ border: `2px solid ${bgPreset === "custom" ? theme.accent : theme.border}` }} />
                    <button onClick={() => setBgPreset("custom")} className="btn-pill" style={{ padding: "6px 14px", fontSize: 13 }}>Использовать</button>
                    <button onClick={() => fileRef.current?.click()} className="btn-pill" style={{ padding: "6px 14px", fontSize: 13, color: theme.accent }}>Заменить</button>
                    <button onClick={dropBg} className="btn-icon" style={{ color: theme.danger }} title="Убрать изображение" aria-label="Убрать изображение"><ImageOff size={16} /></button>
                  </div>
                ) : (
                  <button onClick={() => fileRef.current?.click()} disabled={uploading} style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
                    className="w-full flex items-center justify-center gap-1.5 text-[13px] font-medium rounded-2xl py-3 transition-colors hover:bg-[var(--t-surfaceAlt)] disabled:opacity-50">
                    <Upload size={14} /> {uploading ? "Загружаем…" : "Загрузить своё изображение"}
                  </button>
                )}
              </div>

              <div className="mt-3">
                <Toggle theme={theme} checked={bgBlur} onChange={setBgBlur} label="Размыть фон" />
                <p style={{ color: theme.textMuted }} className="text-[12px] mt-1.5">Размытие приглушает фон, чтобы он не спорил с карточками.</p>
              </div>

              <div style={{ border: `1px solid ${theme.border}`, background: theme.bg }} className="mt-3 h-24 rounded-2xl overflow-hidden relative">
                <div style={{
                  backgroundImage:
                    bgPreset === "custom" && bgFileId
                      ? `url(${api.backgroundUrl(board.id, bgStamp)})`
                      : bgThumbUrl(bgPreset)
                      ? `url(${bgThumbUrl(bgPreset)})`
                      : activePreset?.css || "none",
                  backgroundSize: bgPreset === "custom" ? "cover" : activePreset?.size || "cover",
                  backgroundPosition: "center",
                  filter: bgBlur ? "blur(14px)" : "none", transform: bgBlur ? "scale(1.15)" : "none",
                }} className="absolute inset-0" />
                {/* Ровная вуаль цвета темы, как на доске. */}
                <div style={{ background: theme.bg, opacity: theme.dark ? 0.72 : 0.62 }} className="absolute inset-0" />
                <div className="relative h-full flex items-center justify-center">
                  <span style={{ color: theme.text }} className="glass px-4 py-2 text-[13px]">Так будет выглядеть карточка</span>
                </div>
              </div>
            </Field>

            {/* Удаление проекта доступно только владельцу; редактор управляет содержимым и составом участников. */}
            {isOwner && (
              <button onClick={onRequestDeleteBoard} style={{ color: theme.danger }} className="flex items-center gap-1.5 text-[13px] font-medium mt-4 px-3 h-9 -ml-3 rounded-full transition-colors hover:bg-[var(--t-surfaceAlt)]">
                <Trash2 size={13} /> Удалить проект
              </button>
            )}
          </div>
        )}

        {tab === "columns" && (
          <div>
            {cols.map((c, i) => (
              <div key={c.id} className="glass p-3 mb-2">
                <div className="flex items-center gap-2 mb-2">
                  <GripVertical size={14} style={{ color: theme.textMuted }} />
                  <input value={c.title} onChange={(e) => patchCol(c.id, { title: e.target.value })} style={{ background: theme.surface, color: theme.text, border: `1px solid ${theme.border}` }} className="flex-1 min-w-0 rounded-xl px-3 h-9 text-[14px] outline-none" />
                  <input type="color" value={c.color} onChange={(e) => patchCol(c.id, { color: e.target.value })} className="w-9 h-9 rounded-full cursor-pointer bg-transparent border-0" title="Цвет колонки" aria-label="Цвет колонки" />
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  <label style={{ color: theme.textMuted }} className="flex items-center gap-1.5 text-[12px]">
                    Не больше
                    <input type="number" min={0} value={c.wipLimit} onChange={(e) => patchCol(c.id, { wipLimit: e.target.value })} style={{ background: theme.surface, color: theme.text, border: `1px solid ${theme.border}` }} className="w-16 rounded-xl px-2 h-8 text-[13px] tabular-nums outline-none" />
                    задач
                  </label>
                  <label style={{ color: theme.textMuted }} className="flex items-center gap-1.5 text-[12px] cursor-pointer">
                    <input type="checkbox" checked={c.isDone} onChange={(e) => patchCol(c.id, { isDone: e.target.checked })} />
                    Колонка завершения
                  </label>
                  <div className="ml-auto flex items-center gap-1">
                    <button onClick={() => moveCol(i, -1)} className="btn-icon" style={{ width: 32, height: 32 }} title="Левее" aria-label="Левее"><ChevronLeft size={16} /></button>
                    <button onClick={() => moveCol(i, 1)} className="btn-icon" style={{ width: 32, height: 32 }} title="Правее" aria-label="Правее"><ChevronRight size={16} /></button>
                    <button onClick={() => removeColumn(c)} className="btn-icon" style={{ width: 32, height: 32, color: theme.danger }} title="Удалить" aria-label="Удалить колонку"><Trash2 size={15} /></button>
                  </div>
                </div>
              </div>
            ))}

            <button onClick={addColumn} style={{ color: theme.accent, border: `1px dashed ${theme.border}` }} className="w-full flex items-center justify-center gap-1.5 rounded-2xl py-3 text-[13px] font-medium transition-colors hover:bg-[var(--t-surfaceAlt)]">
              <Plus size={14} /> Добавить колонку
            </button>

            <p style={{ color: theme.textMuted }} className="text-[12.5px] mt-3 leading-relaxed">
              Ноль в поле «не больше» означает, что предел не задан.
            </p>

            {columnWarning && (
              <ConfirmDialog theme={theme} title="Колонка не пуста"
                message={`В колонке «${columnWarning.col.title}» ${columnWarning.count} задач. Они переедут в первую колонку доски. Продолжить?`}
                confirmLabel="Перенести и удалить" danger={false} onCancel={() => setColumnWarning(null)}
                onConfirm={() => { setCols((cs) => cs.filter((c) => c.id !== columnWarning.col.id)); setColumnWarning(null); }} />
            )}
          </div>
        )}

        {tab === "access" && (
          <div>
            <div style={{ color: theme.text }} className="text-[15px] font-semibold mb-2">Участники проекта</div>
            {!isOwner && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-3 leading-relaxed">
                Вы редактор проекта: можете добавлять и убирать участников, менять их роли.
                Владельца изменить нельзя — это может сделать только он сам.
              </p>
            )}
            {members.map((m) => {
              const u = resolveUser(directory, m.userId);
              return (
                <div key={m.userId} className="flex items-center gap-2 mb-2">
                  <Avatar user={u} size={26} theme={theme} />
                  <div className="flex-1 min-w-0">
                    <div style={{ color: u.deleted ? theme.textMuted : theme.text, textDecoration: u.deleted ? "line-through" : "none" }} className="text-[13px] truncate">{u.fullName}</div>
                    <div style={{ color: theme.textMuted }} className="text-[11px] truncate">{u.deleted ? "Учётная запись отключена" : u.position || "Должность не указана"}</div>
                  </div>
                  <select value={m.role} disabled={m.role === "owner"}
                    onChange={(e) => setMembers((ms) => ms.map((x) => (x.userId === m.userId ? { ...x, role: e.target.value } : x)))}
                    style={inputStyle(theme)} className="rounded-xl px-2.5 h-8 text-[13px] outline-none">
                    {Object.entries(ROLE_LABEL).map(([k, l]) => <option key={k} value={k} disabled={k === "owner"}>{l}</option>)}
                  </select>
                  {m.role !== "owner" && (
                    <button onClick={() => setMembers((ms) => ms.filter((x) => x.userId !== m.userId))} className="btn-icon" style={{ width: 32, height: 32, color: theme.danger }} title="Убрать из проекта" aria-label="Убрать из проекта"><X size={15} /></button>
                  )}
                </div>
              );
            })}

            <div style={{ color: theme.text }} className="text-[15px] font-semibold mt-5 mb-2">Добавить из моей команды</div>
            <input value={memberSearch} onChange={(e) => setMemberSearch(e.target.value)} placeholder="Имя или должность" style={inputStyle(theme)} className="w-full rounded-xl px-3.5 h-10 text-[14px] outline-none mb-2" />

            {team.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-2 leading-relaxed">
                Ваша команда пуста. Добавьте сотрудников в разделе «Моя команда» — только их можно приглашать в проект.
              </p>
            )}
            {team.length > 0 && candidates.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-2 leading-relaxed">
                Все сотрудники вашей команды уже добавлены в проект.
              </p>
            )}

            {candidates.map((u) => (
              <div key={u.id} className="flex items-center gap-2 mb-1.5">
                <Avatar user={u} size={24} theme={theme} />
                <div className="flex-1 min-w-0">
                  <div style={{ color: theme.text }} className="text-[12.5px] truncate">{u.fullName}</div>
                  <div style={{ color: theme.textMuted }} className="text-[11px] truncate">{u.position}</div>
                </div>
                <button onClick={() => setMembers((ms) => [...ms, { userId: u.id, role: "reader" }])} className="btn-pill" style={{ padding: "4px 12px", fontSize: 12.5, color: theme.accent }}>Исполнитель</button>
                <button onClick={() => setMembers((ms) => [...ms, { userId: u.id, role: "editor" }])} className="btn-pill" style={{ padding: "4px 12px", fontSize: 12.5, color: theme.accent }}>Редактор</button>
              </div>
            ))}

            <p style={{ color: theme.textMuted }} className="text-[12.5px] mt-3 leading-relaxed">
              Исполнитель видит всю доску, комментирует, загружает файлы и может создавать задачи. Свои задачи он может перемещать; чужие задачи перемещают и редактируют автор задачи, редактор или владелец проекта.
            </p>
          </div>
        )}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t px-6 py-4 flex justify-end gap-2">
        <button onClick={onClose} className="btn-pill h-10 min-w-[120px]">Отмена</button>
        <button onClick={save} disabled={saving} className="btn-primary h-10 min-w-[140px] disabled:opacity-50">
          {saving ? "Сохраняем…" : "Сохранить"}
        </button>
      </div>
    </Modal>
  );
}
