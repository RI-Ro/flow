// Модуль предназначен для окна замещения на время отсутствия: назначение заместителя, список своих замещений
// и замещений, где пользователь заместитель.

import React, { useEffect, useState } from "react";
import { UserCheck, Trash2, Plus, ArrowRight } from "lucide-react";
import { api } from "../lib/api.js";
import { fmtDate, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Функция today предназначена для получения сегодняшней даты в формате YYYY-MM-DD.
const today = () => new Date().toISOString().slice(0, 10);
// Функция plusDays предназначена для получения даты через n дней в формате YYYY-MM-DD.
const plusDays = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);

// Компонент Delegation предназначен для управления замещениями текущего пользователя.
export default function Delegation({ theme, directory, currentUser, onClose, onError, onInfo }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [form, setForm] = useState({
    deputyId: "", startsAt: today(), endsAt: plusDays(14), note: "",
  });

  const load = async () => {
    setLoading(true);
    try {
      setItems(await api.delegations());
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Замещения делятся на две стороны: кого замещает пользователь и кто замещает его. Отменить можно только свои.
  const iDelegate = items.filter((d) => d.grantorId === currentUser.id);
  const iSubstitute = items.filter((d) => d.deputyId === currentUser.id);

  const submit = async () => {
    if (!form.deputyId) return onError("Выберите заместителя");
    if (form.endsAt < form.startsAt) return onError("Дата окончания раньше начала");
    try {
      await api.createDelegation(form);
      onInfo("Заместитель назначен");
      setAdding(false);
      setForm({ deputyId: "", startsAt: today(), endsAt: plusDays(14), note: "" });
      load();
    } catch (e) {
      onError(e.message);
    }
  };

  const remove = (d) => setConfirm({
    title: "Отменить замещение?",
    message: `${resolveUser(directory, d.deputyId).fullName} потеряет доступ к вашим проектам немедленно.`,
    confirmLabel: "Отменить",
    onConfirm: async () => {
      setConfirm(null);
      try {
        await api.deleteDelegation(d.id);
        onInfo("Замещение отменено");
        load();
      } catch (e) {
        onError(e.message);
      }
    },
  });

  const row = (d, mine) => {
    const other = resolveUser(directory, mine ? d.deputyId : d.grantorId);
    return (
      <div key={d.id}
        className="glass p-3 mb-2 flex items-center gap-3">
        <Avatar user={other} size={36} theme={theme} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span style={{ color: theme.text }} className="text-[14px] font-semibold truncate">
              {other.fullName}
            </span>
            {d.active && (
              <span style={{ background: `${theme.success}1f`, color: theme.success }} className="pill !px-2 !leading-[18px]">
                действует
              </span>
            )}
          </div>
          <div style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">
            {fmtDate(d.startsAt)} — {fmtDate(d.endsAt)}
          </div>
          {d.note && (
            <div style={{ color: theme.textMuted }} className="text-[12px] truncate mt-0.5">{d.note}</div>
          )}
        </div>
        {mine && (
          <button onClick={() => remove(d)} className="btn-icon hover:!text-[var(--t-danger)]"
            aria-label={`Отменить замещение: ${other.fullName}`} title="Отменить">
            <Trash2 size={16} />
          </button>
        )}
      </div>
    );
  };

  const candidates = directory.filter((u) => !u.deleted && u.id !== currentUser.id);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="delegation">
      <ModalHeader theme={theme} title="Замещение"
        subtitle="Передача прав на время отпуска или командировки" onClose={onClose} />

      {loading && <p style={{ color: theme.textMuted }} className="text-[13px] py-6 text-center">Загружаем…</p>}

      {!loading && (
        <>
          <div className="text-[12px] font-medium mb-2" style={{ color: theme.textMuted }}>
            Меня замещают
          </div>
          {iDelegate.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[13px] mb-3">
              Заместители не назначены.
            </p>
          )}
          {iDelegate.map((d) => row(d, true))}

          {adding ? (
            <div className="glass p-4 mt-2">
              <Field label="Заместитель" theme={theme}>
                <select value={form.deputyId} onChange={(e) => setForm((f) => ({ ...f, deputyId: e.target.value }))}
                  style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none">
                  <option value="">— выберите —</option>
                  {candidates.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName}{u.position ? ` · ${u.position}` : ""}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="С" theme={theme}>
                  <input type="date" value={form.startsAt}
                    onChange={(e) => setForm((f) => ({ ...f, startsAt: e.target.value }))}
                    style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
                </Field>
                <Field label="По" theme={theme}>
                  <input type="date" value={form.endsAt}
                    onChange={(e) => setForm((f) => ({ ...f, endsAt: e.target.value }))}
                    style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
                </Field>
              </div>
              <Field label="Примечание" theme={theme}
                hint="Заместитель получит все ваши права на проекты в этот период">
                <input value={form.note} onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))}
                  placeholder="например, отпуск" style={inputStyle(theme)}
                  className="w-full rounded-xl px-3 py-2 text-[14px] outline-none" />
              </Field>
              <div className="flex gap-2 mt-1">
                <button onClick={() => setAdding(false)} className="btn-pill flex-1">Отмена</button>
                <button onClick={submit} className="btn-primary flex-1">Назначить</button>
              </div>
            </div>
          ) : (
            <button onClick={() => setAdding(true)} className="btn-pill w-full mt-1"
              style={{ color: theme.accent }}>
              <Plus size={15} /> Назначить заместителя
            </button>
          )}

          {iSubstitute.length > 0 && (
            <>
              <div className="text-[12px] font-medium mt-5 mb-2"
                style={{ color: theme.textMuted }}>
                Я замещаю
              </div>
              {iSubstitute.map((d) => row(d, false))}
              <p style={{ color: theme.textMuted }} className="text-[12px] mt-2 leading-relaxed">
                <ArrowRight size={11} className="inline" /> В период замещения вам доступны проекты
                этих коллег наравне с вашими собственными.
              </p>
            </>
          )}
        </>
      )}

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
    </Modal>
  );
}
