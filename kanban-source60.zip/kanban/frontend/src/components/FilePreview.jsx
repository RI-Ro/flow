import React, { useEffect, useState } from "react";
import { Download, FileText, AlertTriangle, Maximize2, Minimize2, ZoomIn, ZoomOut } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, Spinner } from "../lib/ui.jsx";

// Модуль предназначен для предпросмотра файла в модальном окне без скачивания: изображения — как есть; PDF — встроенным
// просмотрщиком браузера; офисные документы и таблицы — через PDF-копию, которую создаёт сервер; прочие форматы — только скачивание.

const IMAGE = /^image\//;

// Офисные форматы отображаются в виде PDF, преобразованного на сервере (клиентский разбор давал текст без вёрстки,
// а форматы .doc, .odt, .rtf не открывались).
const OFFICE = [
  "doc", "docx", "odt", "rtf",
  "xls", "xlsx", "xlsm", "xltx", "ods", "csv", "tsv",
  "ppt", "pptx", "odp",
];

// Функция kindOf предназначена для определения способа просмотра файла по имени и типу MIME.
function kindOf(filename, mime) {
  const ext = (filename || "").toLowerCase().split(".").pop();
  if (IMAGE.test(mime || "")) return "image";
  if (mime === "application/pdf" || ext === "pdf") return "pdf";
  if (OFFICE.includes(ext)) return "office";
  return "none";
}

// Функция downloadOriginal предназначена для скачивания оригинала с токеном (прямая ссылка вернула бы 401).
async function downloadOriginal(path, filename) {
  try {
    const blob = await api.fileBlob(path);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || "файл";
    a.click();
    URL.revokeObjectURL(url);
  } catch {
    /* причина ошибки видна в окне предпросмотра */
  }
}

// Компонент FilePreview предназначен для окна предпросмотра файла.
export default function FilePreview({ theme, title, filename, mime, path, pdfPath, downloadPath, onClose }) {
  const [state, setState] = useState({ loading: true });
  // Режим «во весь экран» — для чертежей, таблиц и многостраничных документов.
  const [full, setFull] = useState(false);
  // Масштаб задаётся собственным элементом управления: панель просмотрщика скрыта (см. pdfSrc).
  const [zoom, setZoom] = useState(100);
  const ZOOM_STEPS = [50, 67, 80, 100, 125, 150, 175, 200, 250, 300];
  const zoomIn = () => setZoom((z) => ZOOM_STEPS.find((v) => v > z) || z);
  const zoomOut = () => setZoom((z) => [...ZOOM_STEPS].reverse().find((v) => v < z) || z);
  const kind = kindOf(filename, mime);

  useEffect(() => {
    let url = null;
    let cancelled = false;

    (async () => {
      if (kind === "none") {
        setState({ loading: false });
        return;
      }
      try {
        // Офисные форматы запрашиваются в виде PDF: сервер конвертирует и кэширует результат.
        const blob = await api.fileBlob(kind === "office" ? pdfPath : path);
        if (cancelled) return;
        url = URL.createObjectURL(blob);
        setState({ loading: false, url, converted: kind === "office" });
      } catch (e) {
        if (!cancelled) setState({ loading: false, error: e.message || "Не удалось открыть файл" });
      }
    })();

    return () => {
      cancelled = true;
      // blob-ссылка освобождается вручную, иначе файл остаётся в памяти до перезагрузки страницы.
      if (url) URL.revokeObjectURL(url);
    };
  }, [kind, path, pdfPath]);

  return (
    <Modal theme={theme} onClose={onClose} padded={false}
      width={full ? "max-w-[98vw]" : "max-w-5xl"}
      geometryKey={full ? null : "file-preview"}>
      <div className="px-5 pt-4 pb-1">
        <ModalHeader theme={theme} title={title || filename} onClose={onClose}
          subtitle={filename}
          extra={(
            <span className="flex items-center gap-1">
              {(kind === "pdf" || kind === "office" || kind === "image") && state.url && (
                // Масштаб: капсула «− 100% +».
                <span style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="flex items-center rounded-full p-0.5 mr-1">
                  <button onClick={zoomOut} disabled={zoom <= ZOOM_STEPS[0]}
                    className="btn-icon disabled:opacity-40 disabled:pointer-events-none" style={{ width: 30, height: 30 }}
                    title="Уменьшить" aria-label="Уменьшить"><ZoomOut size={16} /></button>
                  <span style={{ color: theme.text }} className="text-[12px] font-medium w-10 text-center tabular-nums">
                    {zoom}%
                  </span>
                  <button onClick={zoomIn} disabled={zoom >= ZOOM_STEPS[ZOOM_STEPS.length - 1]}
                    className="btn-icon disabled:opacity-40 disabled:pointer-events-none" style={{ width: 30, height: 30 }}
                    title="Увеличить" aria-label="Увеличить"><ZoomIn size={16} /></button>
                </span>
              )}
              <button onClick={() => setFull((v) => !v)} className="btn-icon"
                title={full ? "Вернуть обычный размер" : "Во весь экран"}
                aria-label={full ? "Вернуть обычный размер" : "Во весь экран"}>
                {full ? <Minimize2 size={17} /> : <Maximize2 size={17} />}
              </button>
            </span>
          )} />
      </div>

      <div className="px-5 pb-5 overflow-auto">
        {state.loading && <Spinner theme={theme} label="Открываем файл…" />}

        {state.error && (
          <p style={{ color: theme.danger }} className="text-[13px] py-6 text-center">
            {state.error}
          </p>
        )}

        {!state.loading && kind === "none" && (
          <div className="py-8 text-center">
            <AlertTriangle size={22} style={{ color: theme.textMuted }} className="mx-auto mb-2" />
            <p style={{ color: theme.text }} className="text-[13px] font-medium mb-1">
              Этот формат в окне не открывается
            </p>
            <p style={{ color: theme.textMuted }} className="text-[12px] leading-relaxed max-w-md mx-auto">
              Старый .doc и .odt — двоичные и упакованные форматы, для которых нет надёжного
              браузерного разбора. Показывать их наполовину хуже, чем не показывать: по документам
              принимают решения. Скачайте и откройте в своей программе.
            </p>
          </div>
        )}

        {state.url && kind === "image" && (
          <img src={state.url} alt={filename}
            className="mx-auto rounded-xl"
            style={{
              // При масштабе 100 % изображение вписывается в окно; при большем масштабе включается прокрутка контейнера.
              maxWidth: zoom === 100 ? "100%" : "none",
              maxHeight: zoom === 100 ? (full ? "82vh" : "70vh") : "none",
              width: zoom === 100 ? undefined : `${zoom}%`,
              border: `1px solid ${theme.border}`,
            }} />
        )}

        {state.url && (kind === "pdf" || kind === "office") && (
          <>
            {/* Предупреждение: отображается копия файла; расположение страниц и шрифты могут отличаться от оригинала. */}
            {state.converted && (
              <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}`, color: theme.text }}
                className="rounded-xl px-3 py-2 mb-2 flex items-start gap-2 text-[12px] leading-relaxed">
                <AlertTriangle size={14} style={{ color: theme.warning || theme.accent2 }} className="mt-0.5 shrink-0" />
                <span>
                  Показана версия файла, переконвертированная в PDF. Разметка может слегка
                  отличаться от оригинала.{" "}
                  <button onClick={() => downloadOriginal(downloadPath || path, filename)}
                    style={{ color: theme.accent }} className="font-medium underline">
                    Скачать оригинал
                  </button>
                </span>
              </div>
            )}
            {/* Панель встроенного просмотрщика скрыта параметрами фрагмента: toolbar=0 убирает кнопки, navpanes=0 — боковую панель. */}
            <iframe key={`${state.url}-${zoom}`}
              src={`${state.url}#toolbar=0&navpanes=0&statusbar=0&view=FitH&zoom=${zoom}`}
              title={filename}
              style={{ width: "100%", height: full ? "82vh" : "68vh", border: `1px solid ${theme.border}` }}
              className="rounded-xl" />
          </>
        )}
      </div>

      {/* Подвал с кнопкой «Скачать» только для форматов, которые не открываются в окне. */}
      {kind === "none" && (
      <div style={{ borderColor: theme.border }} className="border-t px-5 py-3 flex items-center gap-2">
        <FileText size={14} style={{ color: theme.textMuted }} />
        <span style={{ color: theme.textMuted }} className="text-[12px] truncate flex-1">
          {filename}
        </span>
        <a href={downloadPath ? `/api${downloadPath}` : undefined}
          onClick={async (e) => {
            // Скачивание выполняется запросом с токеном, файл сохраняется программно.
            e.preventDefault();
            try {
              const blob = await api.fileBlob(downloadPath || path);
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = filename || "файл";
              a.click();
              URL.revokeObjectURL(url);
            } catch {
              /* ошибка отображается выше */
            }
          }}
          className="btn-pill" style={{ padding: "6px 14px", fontSize: 13, gap: 6 }}>
          <Download size={14} /> Скачать
        </a>
      </div>
      )}
    </Modal>
  );
}
