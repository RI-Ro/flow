import React, { useMemo, useState } from "react";
import { Eye, EyeOff, KeyRound } from "lucide-react";

import { api } from "../lib/api.js";
import { Modal, ModalHeader, PasswordRules, inputStyle } from "../lib/ui.jsx";
import { checkPassword } from "../lib/password.js";

// Компонент PasswordModal предназначен для смены собственного пароля. Требования отображаются списком и отмечаются
// по мере ввода.
export default function PasswordModal({ theme, onClose, onDone, onError }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [repeat, setRepeat] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [touched, setTouched] = useState(false);

  const check = useMemo(() => checkPassword(next), [next]);
  const sameAsCurrent = Boolean(next) && next === current;
  const mismatch = Boolean(repeat) && repeat !== next;
  const canSave = Boolean(current) && check.valid && !mismatch
    && Boolean(repeat) && !sameAsCurrent && !busy;

  const save = async () => {
    if (!canSave) { setTouched(true); return; }
    setBusy(true);
    try {
      // Сервер завершает все сессии и выдаёт этому устройству новую пару токенов; api.changePassword сохраняет её, работа не прерывается.
      await api.changePassword(current, next);
      onDone("Пароль изменён. На остальных устройствах выполнен выход");
      onClose();
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const field = (label, value, setValue, props = {}) => (
    <div className="mb-3">
      <label style={{ color: theme.textMuted }}
        className="block text-[12.5px] font-medium">{label}</label>
      <input type={show ? "text" : "password"} value={value} autoComplete="off"
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && save()}
        style={inputStyle(theme)}
        className="w-full mt-1.5 rounded-xl px-3.5 h-10 text-[14px] outline-none"
        {...props} />
    </div>
  );

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="password">
      <ModalHeader theme={theme} title="Смена пароля" onClose={onClose}
        subtitle="Остальные устройства после смены разлогинятся" />

      {field("Текущий пароль", current, setCurrent, { autoFocus: true })}
      {field("Новый пароль", next, setNext)}
      {field("Новый пароль ещё раз", repeat, setRepeat)}

      <button onClick={() => setShow((v) => !v)} style={{ color: theme.textMuted }}
        className="flex items-center gap-1.5 text-[13px] mb-3 rounded-full transition-colors hover:text-[var(--t-text)]">
        {show ? <EyeOff size={13} /> : <Eye size={13} />}
        {show ? "Скрыть пароли" : "Показать пароли"}
      </button>

      <div className="mb-3">
        <PasswordRules theme={theme} value={next} />
      </div>

      {/* Ошибка отображается по ходу ввода, а не после нажатия кнопки. */}
      {(check.error || mismatch || sameAsCurrent || (touched && !current)) && (
        <p style={{ color: theme.danger }} className="text-[13px] mb-3" role="alert">
          {!current && touched ? "Укажите текущий пароль"
            : sameAsCurrent ? "Новый пароль совпадает с текущим"
            : mismatch ? "Повтор не совпадает с новым паролем"
            : check.error}
        </p>
      )}

      <div className="flex gap-2">
        <button onClick={onClose} className="btn-pill flex-1 h-10">Отмена</button>
        {/* Если сохранять нечего, кнопка выглядит вторичной, но активна: нажатие подсвечивает незаполненное поле. */}
        <button onClick={save} disabled={busy}
          style={canSave ? undefined : { color: theme.textMuted }}
          className={`${canSave ? "btn-primary" : "btn-pill"} flex-1 h-10 font-semibold`}>
          <KeyRound size={14} /> {busy ? "Сохраняем…" : "Сменить пароль"}
        </button>
      </div>

      <p style={{ color: theme.textMuted }} className="text-[12px] mt-3 leading-relaxed">
        Русские буквы подходят: «Пароль12» — восемь символов и три типа.
      </p>
    </Modal>
  );
}
