// Модуль предназначен для бокового меню: разделы приложения, дерево проектов с перетаскиванием, диаграммы и доски.

import React, { useMemo, useState } from "react";
import { ChevronRight, ChevronDown, Plus, Eye, GripVertical, Inbox, LayoutGrid, CalendarDays, ListChecks, BellRing, MessageSquare, PackageCheck, GanttChartSquare, LayoutDashboard } from "lucide-react";
import { ROLE_LABEL, bgById, bgThumbUrl, isUnseen, resolveUser } from "../lib/theme.js";

const OPEN_KEY = "kanban.treeOpen";

// Функция buildTree предназначена для построения дерева проектов из плоского списка: если родитель недоступен
// пользователю, узел поднимается на верхний уровень.
function buildTree(boards) {
  const byId = new Map(boards.map((b) => [b.id, b]));
  const children = new Map();

  for (const b of boards) {
    const parentVisible = b.parentId && byId.has(b.parentId);
    const key = parentVisible ? b.parentId : "__root__";
    if (!children.has(key)) children.set(key, []);
    children.get(key).push(b);
  }

  for (const list of children.values()) {
    list.sort((a, b) => (a.position - b.position) || a.title.localeCompare(b.title, "ru"));
  }

  const walk = (key, depth) =>
    (children.get(key) || []).flatMap((b) => [
      { ...b, depth, hasChildren: (children.get(b.id) || []).length > 0 },
      ...walk(b.id, depth + 1),
    ]);

  return walk("__root__", 0);
}

// Компонент ProjectTree предназначен для бокового меню с деревом проектов.
export default function ProjectTree({
  theme, boards, directory, activeId, isInbox, isDashboard, isCalendar, isAllTasks, isReminders,
  onSelect, onSelectInbox, onSelectDashboard, onSelectCalendar, onSelectAllTasks, onSelectReminders,
  onSelectChats, isChats, chatUnread = 0, onSelectReady, isReady, readyCount = 0, onCreate, onMove, canReorder,
  isCharts, onSelectCharts, isWhiteboards, onSelectWhiteboards,
}) {
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return new Set(JSON.parse(localStorage.getItem(OPEN_KEY) || "[]"));
    } catch {
      return new Set();
    }
  });
  const [dragId, setDragId] = useState(null);
  const [dropTarget, setDropTarget] = useState(null); // { id, mode: "into" | "before" }

  const flat = useMemo(() => buildTree(boards), [boards]);

  // Свёрнутый узел скрывает всё поддерево.
  const hiddenIds = useMemo(() => {
    const hidden = new Set();
    for (const node of flat) {
      if (hidden.has(node.parentId) || collapsed.has(node.parentId)) {
        hidden.add(node.id);
      }
    }
    return hidden;
  }, [flat, collapsed]);

  const toggle = (id) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      localStorage.setItem(OPEN_KEY, JSON.stringify([...next]));
      return next;
    });
  };

  // Функция handleDragOver предназначена для определения зоны сброса по высоте строки: перед узлом, внутрь узла или после узла.
  // Три зоны позволяют менять местами подпроект и родителя.
  const handleDragOver = (e, node) => {
    if (!canReorder || !dragId || dragId === node.id) return;
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    const offset = e.clientY - rect.top;
    let mode;
    if (offset < rect.height * 0.28) mode = "before";
    else if (offset > rect.height * 0.72) mode = "after";
    else mode = "into";
    setDropTarget({ id: node.id, mode });
  };

  const handleDrop = (e, node) => {
    e.preventDefault();
    const source = dragId;
    const target = dropTarget;
    setDragId(null);
    setDropTarget(null);
    if (!source || !target || source === node.id) return;

    if (target.mode === "into") {
      onMove(source, { parentId: node.id });
    } else if (target.mode === "after") {
      // Размещение на уровне цели, сразу после неё (вынос подпроекта наверх рядом с прежним родителем).
      onMove(source, { parentId: node.parentId || null, position: node.position + 1 });
    } else {
      onMove(source, { parentId: node.parentId || null, position: node.position });
    }
  };

  // Функция handleRootDrop предназначена для перемещения проекта в корень дерева (отдельная зона сброса).
  const handleRootDrop = (e) => {
    e.preventDefault();
    const source = dragId;
    setDragId(null);
    setDropTarget(null);
    if (source) onMove(source, { parentId: null });
  };

  // Функция ic предназначена для отрисовки монохромной иконки раздела: цветом выделяются только активный пункт и счётчики.
  const ic = (Icon) => <Icon size={17} strokeWidth={1.9} />;

  return (
    <div className="px-2.5 pb-2">
      {/* Порядок разделов: от общего к частному и от частого к редкому (сводка и календарь, затем списки задач). */}
      <NavItem theme={theme} href="/dashboard" active={isDashboard} onSelect={onSelectDashboard}
        icon={ic(LayoutGrid)} label="Сводка" />

      <NavItem theme={theme} href="/calendar" active={isCalendar} onSelect={onSelectCalendar}
        icon={ic(CalendarDays)} label="Календарь" />

      <NavItem theme={theme} href="/all-tasks" active={isAllTasks} onSelect={onSelectAllTasks}
        icon={ic(ListChecks)} label="Все задачи" />

      <NavItem theme={theme} href="/ready" active={isReady} onSelect={onSelectReady}
        icon={ic(PackageCheck)} label="Готовы к сдаче"
        badge={readyCount} />

      <NavItem theme={theme} href="/inbox" active={isInbox} onSelect={onSelectInbox}
        icon={ic(Inbox)} label="Входящие" />

      <NavItem theme={theme} href="/reminders" active={isReminders} onSelect={onSelectReminders}
        icon={ic(BellRing)} label="Напоминания" />

      <NavItem theme={theme} href="/chats" active={isChats} onSelect={onSelectChats}
        icon={ic(MessageSquare)} label="Сообщения"
        badge={chatUnread} />

      <div className="text-[11px] font-semibold uppercase tracking-[0.08em] px-3 pt-5 pb-1.5"
        style={{ color: theme.textMuted }}
        title={canReorder ? "Проекты можно перетаскивать: порядок и вложенность" : undefined}>
        Проекты
      </div>

      {flat.filter((n) => !hiddenIds.has(n.id)).map((node) => {
        const isTarget = dropTarget?.id === node.id;
        const author = resolveUser(directory, node.createdBy);
        // Непросмотренные изменения проекта (кроме открытого сейчас проекта).
        const unseen = node.id !== activeId && isUnseen(node);
        const active = node.id === activeId;
        // Цветная точка проекта строится из его фона (градиент или миниатюра); без фона — нейтральная.
        const preset = bgById(node.bgPreset);
        const thumb = bgThumbUrl(node.bgPreset);
        const dot = thumb ? `center/cover url(${thumb})` : preset?.css || null;
        const meta = `${ROLE_LABEL[node.myRole] || ""}${node.viaDelegation ? " (замещение)" : ""}`
          + `${author && !author.deleted ? ` · ${author.fullName}` : ""}`;
        return (
          <div key={node.id}>
            {isTarget && dropTarget.mode === "before" && (
              <div style={{ background: theme.accent, marginLeft: 12 + node.depth * 14 }}
                className="h-[2px] rounded-full my-0.5" />
            )}
            <div
              draggable={canReorder}
              onDragStart={() => setDragId(node.id)}
              onDragEnd={() => { setDragId(null); setDropTarget(null); }}
              onDragOver={(e) => handleDragOver(e, node)}
              onDrop={(e) => handleDrop(e, node)}
              style={{
                background: isTarget && dropTarget.mode === "into" ? theme.surfaceAlt : undefined,
                border: `1px solid ${isTarget && dropTarget.mode === "into" ? theme.accent : "transparent"}`,
                opacity: dragId === node.id ? 0.4 : 1,
                paddingLeft: 4 + node.depth * 14,
                borderRadius: 999,
              }}
              className={`w-full flex items-center gap-0.5 pr-2 min-h-[38px] group transition-colors duration-150 ${active ? "glass" : "hover:bg-[var(--t-surfaceAlt)]"}`}>
              {node.hasChildren ? (
                <button onClick={() => toggle(node.id)} style={{ color: theme.textMuted }}
                  className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 hover:bg-[var(--t-surfaceAlt)]"
                  title={collapsed.has(node.id) ? "Развернуть" : "Свернуть"}
                  aria-label={collapsed.has(node.id) ? "Развернуть" : "Свернуть"}>
                  {collapsed.has(node.id) ? <ChevronRight size={13} /> : <ChevronDown size={13} />}
                </button>
              ) : (
                <span className="w-5 shrink-0" />
              )}

              <a href={`/b/${node.id}`}
                onClick={(e) => {
                  // Обычный левый клик выполняет SPA-переход; Ctrl, ⌘, Shift и средняя кнопка обрабатываются браузером (новая вкладка или окно).
                  if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;
                  e.preventDefault();
                  onSelect(node.id);
                }}
                draggable={false}
                title={unseen ? `${meta}\nВ проекте есть изменения с вашего последнего просмотра` : meta}
                className="flex-1 min-w-0 flex items-center gap-2.5 text-left no-underline py-1.5 rounded-full">
                <span style={{ background: dot || theme.textMuted, opacity: dot ? 1 : 0.55 }}
                  className="w-2 h-2 rounded-full shrink-0" />
                <span style={{ color: theme.text, fontWeight: unseen || active ? 600 : 500 }}
                  className="flex-1 min-w-0 text-[14px] truncate">
                  {node.title}
                </span>
                {unseen && (
                  <span style={{ background: theme.accent }} className="w-1.5 h-1.5 rounded-full shrink-0"
                    title="Есть изменения с вашего последнего просмотра" />
                )}
                {node.myRole === "reader" && (
                  <Eye size={13} style={{ color: theme.textMuted }} className="shrink-0" aria-label="Исполнитель" />
                )}
              </a>

              {canReorder && (
                <GripVertical size={12} style={{ color: theme.textMuted }}
                  className="opacity-0 group-hover:opacity-60 shrink-0 cursor-grab" />
              )}
            </div>
            {isTarget && dropTarget.mode === "after" && (
              <div style={{ background: theme.accent, marginLeft: 12 + node.depth * 14 }}
                className="h-[2px] rounded-full my-0.5" />
            )}
          </div>
        );
      })}

      {canReorder && dragId && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDropTarget({ id: "__root__", mode: "root" }); }}
          onDrop={handleRootDrop}
          style={{
            border: `1px dashed ${dropTarget?.mode === "root" ? theme.accent : theme.border}`,
            color: dropTarget?.mode === "root" ? theme.accent : theme.textMuted,
            background: dropTarget?.mode === "root" ? theme.surfaceAlt : "transparent",
          }}
          className="rounded-2xl py-2.5 text-center text-[12px] my-1.5 mx-1">
          Отпустите здесь — вынести в корень
        </div>
      )}

      {boards.length === 0 && (
        <p style={{ color: theme.textMuted }} className="text-[13px] px-3 py-2">
          Проектов пока нет.
        </p>
      )}

      <button onClick={onCreate} style={{ color: theme.textMuted }}
        className="w-full flex items-center gap-3 px-3 min-h-[38px] rounded-full text-[14px] font-medium transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)] hover:text-[var(--t-text)]">
        <Plus size={17} strokeWidth={1.9} /> Новый проект
      </button>

      {/* Диаграммы и совместные доски выделены отдельной группой ниже проектов: они не относятся к проектам. */}
      <div className="text-[11px] font-semibold uppercase tracking-[0.08em] px-3 pt-5 pb-1.5"
        style={{ color: theme.textMuted }}>
        Совместная работа
      </div>
      <NavItem theme={theme} href="/charts" active={isCharts} onSelect={onSelectCharts}
        icon={ic(GanttChartSquare)} label="Диаграммы" />
      <NavItem theme={theme} href="/whiteboards" active={isWhiteboards} onSelect={onSelectWhiteboards}
        icon={ic(LayoutDashboard)} label="Совместные доски" />
    </div>
  );
}

// Компонент NavItem предназначен для пункта бокового меню: отрисовывается ссылкой, чтобы работало открытие в новой вкладке.
function NavItem({ theme, href, active, onSelect, icon, label, badge = 0, className = "" }) {
  return (
    <a href={href}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;
        e.preventDefault();
        onSelect();
      }}
      aria-current={active ? "page" : undefined}
      style={{ color: active ? theme.text : theme.textMuted, borderRadius: 999 }}
      className={`w-full flex items-center gap-3 px-3 min-h-[40px] text-[14px] mb-0.5 no-underline transition-colors duration-150 ${active ? "glass" : "border border-transparent hover:bg-[var(--t-surfaceAlt)] hover:text-[var(--t-text)]"} ${className}`}>
      {icon}
      <span style={{ color: theme.text }} className={`flex-1 text-left truncate ${active ? "font-semibold" : "font-medium"}`}>{label}</span>
      {/* Счётчик непрочитанного рядом с разделом. */}
      {badge > 0 && (
        <span style={{ background: theme.dark ? "rgba(255,255,255,.09)" : "rgba(0,0,0,.06)", color: theme.textMuted }}
          className="text-[11.5px] font-semibold tabular-nums min-w-[22px] h-[20px] px-1.5 rounded-full inline-flex items-center justify-center">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </a>
  );
}
