// Модуль предназначен для вкладки «Напоминания»: личные напоминания с необязательным повторением и привязкой к задаче.

import React, { useEffect, useState } from "react";
import { Plus, Trash2, Pencil, BellRing, BellOff, Repeat, Link2 as LinkIcon } from "lucide-react";
import { api } from "../lib/api.js";
import { fmtDateTime } from "../lib/theme.js";
import { inputStyle } from "../lib/ui.jsx";

const FREQ_LABEL = { none: "Однократно", daily: "Ежедневно", weekly: "Еженедельно", monthly: "Ежемесячно" };
// Функция tint предназначена для получения мягкого тона цвета для подложек капсул и значков.
const tint = (c, pct = 16) => `color-mix(in srgb, ${c} ${pct}%, transparent)`;

const WEEKDAYS = [["1", "Пн"], ["2", "Вт"], ["3", "Ср"], ["4", "Чт"], ["5", "Пт"], ["6", "Сб"], ["0", "Вс"]];

// Компонент Reminders предназначен для списка и редактирования напоминаний. Напоминания срабатывают на сервере (фоновый опрос)
// и приходят уведомлениями.
export default function Reminders({ theme, onError, onOpenTask }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // "new" | id | null
  const [draft, setDraft] = useState(blank());

  // Функция toLocalInput предназначена для преобразования ISO-времени с зоной в значение поля datetime-local (локальное время без зоны):
  // сервер возвращает момент в UTC.
  function toLocalInput(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  // Список задач для привязки загружается один раз при открытии формы.
  const [taskOptions, setTaskOptions] = useState(null);
  const loadTaskOptions = async () => {
    if (taskOptions) return;
    try {
      // Ответ api.allTasks — объект {items, total}, а не массив.
      const res = await api.allTasks("scope=mine&status=active&sort=due&dir=asc&limit=200");
      setTaskOptions((res?.items || [])
        .slice()
        .sort((a, b) => a.title.localeCompare(b.title, "ru")));
    } catch {
      // При ошибке загрузки привязка к задаче не предлагается, напоминание сохраняется без неё.
      setTaskOptions([]);
    }
  };

  function blank() {
    // По умолчанию время напоминания — через час от текущего момента (локальное время).
    const d = new Date(Date.now() + 60 * 60 * 1000);
    const iso = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
    return { title: "", remindAt: iso, recurFreq: "none", recurInterval: 1, recurWeekdays: [], taskId: "" };
  }
  function p(n) { return String(n).padStart(2, "0"); }

  const load = async () => {
    setLoading(true);
    try { setItems(await api.reminders()); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const startNew = () => { setDraft(blank()); setEditing("new"); loadTaskOptions(); };
  const startEdit = (r) => {
    setDraft({
      title: r.title, remindAt: toLocalInput(r.remindAt),
      recurFreq: r.recurFreq, recurInterval: r.recurInterval || 1,
      recurWeekdays: r.recurWeekdays || [],
      taskId: r.taskId || "",
      taskTitle: r.taskTitle || "",
    });
    setEditing(r.id);
    loadTaskOptions();
  };

  const save = async () => {
    if (!draft.title.trim()) return onError("Укажите название напоминания");
    if (!draft.remindAt) return onError("Укажите дату и время");
    // Значение поля — локальное время без зоны; toISOString переводит его в UTC, поэтому в базу передаётся тот же момент.
    const payload = {
      title: draft.title.trim(),
      remindAt: new Date(draft.remindAt).toISOString(),
      recurFreq: draft.recurFreq,
      recurInterval: Number(draft.recurInterval) || 1,
      recurWeekdays: draft.recurFreq === "weekly" ? draft.recurWeekdays.map(Number) : [],
      // Привязка необязательна: пустое значение означает «без задачи».
      taskId: draft.taskId || null,
    };
    try {
      if (editing === "new") await api.createReminder(payload);
      else await api.updateReminder(editing, payload);
      setEditing(null);
      load();
    } catch (e) { onError(e.message); }
  };

  const toggleActive = async (r) => {
    try { await api.updateReminder(r.id, { title: r.title, remindAt: "", recurFreq: r.recurFreq, recurInterval: r.recurInterval, recurWeekdays: r.recurWeekdays, active: !r.active, taskId: r.taskId || null }); load(); }
    catch (e) { onError(e.message); }
  };

  const remove = async (r) => {
    try { await api.deleteReminder(r.id); setItems((x) => x.filter((i) => i.id !== r.id)); }
    catch (e) { onError(e.message); }
  };

  const toggleWeekday = (d) =>
    setDraft((v) => ({
      ...v,
      recurWeekdays: v.recurWeekdays.includes(d)
        ? v.recurWeekdays.filter((x) => x !== d)
        : [...v.recurWeekdays, d],
    }));

  // Форма напоминания: создание — отдельная панель над списком, правка — на месте строки; оболочка задаётся снаружи.
  const label = (text) => (
    <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-1.5">{text}</div>
  );
  const field = "w-full rounded-[12px] px-3 h-9 text-[14px] outline-none";
  const fieldStyle = { ...inputStyle(theme), colorScheme: theme.dark ? "dark" : "light" };
  const renderEditor = (shell) => (
    <div className={shell}>
      <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })}
        placeholder="О чём напомнить" autoFocus style={fieldStyle}
        className={`${field} mb-3`} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
        <div>
          {label("Когда")}
          <input type="datetime-local" value={draft.remindAt} onChange={(e) => setDraft({ ...draft, remindAt: e.target.value })}
            style={fieldStyle} className={`${field} tabular-nums`} />
        </div>
        <div>
          {label("Повтор")}
          <select value={draft.recurFreq} onChange={(e) => setDraft({ ...draft, recurFreq: e.target.value })}
            style={fieldStyle} className={field}>
            {Object.entries(FREQ_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
      </div>

      <div className="mb-3">
        {label("Задача (необязательно)")}
        <select value={draft.taskId || ""} onChange={(e) => setDraft({ ...draft, taskId: e.target.value })}
          style={fieldStyle} className={field}>
          <option value="">Без задачи</option>
          {taskOptions === null && <option disabled>Загружаем список задач…</option>}
          {taskOptions?.length === 0 && <option disabled>Незавершённых задач не найдено</option>}
          {/* Привязанная задача может отсутствовать в списке (завершена или за пределом 200 записей): строка сохраняет выбор при правке. */}
          {draft.taskId && !(taskOptions || []).some((t) => t.id === draft.taskId) && (
            <option value={draft.taskId}>{draft.taskTitle || "Привязанная задача"}</option>
          )}
          {(taskOptions || []).map((t) => (
            <option key={t.id} value={t.id}>
              {t.title}{t.boardTitle ? ` · ${t.boardTitle}` : ""}
            </option>
          ))}
        </select>
      </div>

      {draft.recurFreq !== "none" && (
        <div className="flex items-center gap-2 mb-3">
          <span style={{ color: theme.textMuted }} className="text-[13px]">Каждые</span>
          <input type="number" min="1" value={draft.recurInterval}
            onChange={(e) => setDraft({ ...draft, recurInterval: e.target.value })}
            style={fieldStyle} className="w-20 rounded-[12px] px-3 h-9 text-[14px] tabular-nums outline-none" />
          <span style={{ color: theme.textMuted }} className="text-[13px]">
            {draft.recurFreq === "daily" ? "дн." : draft.recurFreq === "weekly" ? "нед." : "мес."}
          </span>
        </div>
      )}

      {draft.recurFreq === "weekly" && (
        <div className="flex flex-wrap gap-1.5 mb-3" role="group" aria-label="Дни недели">
          {WEEKDAYS.map(([d, text]) => {
            const on = draft.recurWeekdays.includes(d);
            return (
              <button key={d} onClick={() => toggleWeekday(d)} aria-pressed={on}
                style={{
                  background: on ? tint(theme.accent, 16) : theme.surfaceAlt,
                  color: on ? theme.accent : theme.text,
                  border: `1px solid ${on ? tint(theme.accent, 45) : theme.border}`,
                }}
                className="min-w-[44px] px-3 py-1.5 rounded-full text-[13px] font-medium transition-colors duration-150">{text}</button>
            );
          })}
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <button onClick={save} className="btn-primary">Сохранить</button>
        <button onClick={() => setEditing(null)} className="btn-pill">Отмена</button>
      </div>
    </div>
  );

  return (
    // Ширина контейнера совпадает с остальными разделами.
    <div className="max-w-[1500px] mx-auto pb-6">
      {/* Заголовок раздела отображает оболочка приложения; здесь — сводка и основное действие. */}
      <div className="flex items-center justify-between gap-3 mb-4">
        <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">
          {loading ? "Загрузка…" : items.length
            ? `Всего: ${items.length}, включено: ${items.filter((r) => r.active).length}`
            : ""}
        </span>
        {editing !== "new" && (
          <button onClick={startNew} className="btn-primary">
            <Plus size={16} /> Новое напоминание
          </button>
        )}
      </div>

      {editing === "new" && renderEditor("glass-pane p-5 mb-4")}

      {loading ? null : items.length === 0 && editing !== "new" ? (
        <div className="glass-pane px-6 py-12 text-center">
          <BellRing size={22} style={{ color: theme.textMuted }} className="mx-auto mb-3" />
          <p style={{ color: theme.textMuted }} className="text-[14px] max-w-md mx-auto">Напоминаний пока нет. Создайте первое — оно придёт в колокольчик в заданное время.</p>
        </div>
      ) : items.length > 0 && (
        <div className="glass-pane p-2">
          {items.map((r, i) => (
            editing === r.id ? (
              <div key={r.id} className="p-1">{renderEditor("glass p-4")}</div>
            ) : (
              <div key={r.id} style={{ borderColor: theme.border }}
                className={`flex items-center gap-3 px-3 py-3 ${i < items.length - 1 ? "border-b" : ""}`}>
                <span style={{
                    background: r.active ? tint(theme.accent, 14) : theme.surfaceAlt,
                    color: r.active ? theme.accent : theme.textMuted,
                  }}
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0">
                  {r.active ? <BellRing size={16} /> : <BellOff size={16} />}
                </span>
                <div className="flex-1 min-w-0" style={{ opacity: r.active ? 1 : 0.6 }}>
                  <div style={{ color: theme.text }} className="text-[14px] font-medium leading-5 truncate">{r.title}</div>
                  <div style={{ color: theme.textMuted }} className="text-[12px] mt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                    <span className="tabular-nums">{fmtDateTime(r.remindAt)}</span>
                    {r.recurFreq !== "none" && (
                      <span className="flex items-center gap-1"><Repeat size={12} />{FREQ_LABEL[r.recurFreq]}</span>
                    )}
                    {!r.active && (
                      <span className="pill" style={{ background: theme.surfaceAlt, padding: "0 8px", lineHeight: "18px" }}>отключено</span>
                    )}
                    {/* Привязанная задача: название выводится, если задача доступна пользователю, иначе сервер возвращает пустую строку. */}
                    {r.taskId && (
                      r.taskTitle ? (
                        <button onClick={() => onOpenTask?.(r.taskId)}
                          style={{ background: tint(theme.accent, 12), color: theme.accent, padding: "0 8px", lineHeight: "20px" }}
                          className="pill max-w-[320px] transition-[filter] duration-150 hover:brightness-110"
                          title="Открыть задачу">
                          <LinkIcon size={12} className="shrink-0" /> <span className="truncate">{r.taskTitle}</span>
                        </button>
                      ) : (
                        <span>Задача больше недоступна</span>
                      )
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-0.5 shrink-0">
                  <button onClick={() => toggleActive(r)} className="btn-icon"
                    title={r.active ? "Отключить" : "Включить"} aria-label={r.active ? "Отключить" : "Включить"}>
                    {r.active ? <BellOff size={16} /> : <BellRing size={16} />}
                  </button>
                  <button onClick={() => startEdit(r)} className="btn-icon" title="Изменить" aria-label="Изменить">
                    <Pencil size={15} />
                  </button>
                  <button onClick={() => remove(r)} className="btn-icon hover:!text-[var(--t-danger)]" title="Удалить" aria-label="Удалить">
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            )
          ))}
        </div>
      )}
    </div>
  );
}
