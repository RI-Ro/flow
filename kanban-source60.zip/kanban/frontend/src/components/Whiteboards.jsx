// Модуль предназначен для совместных досок: список досок, бесконечный холст с фигурами, стикерами, линиями и текстом,
// одновременная правка несколькими пользователями, отмена и возврат действий, группировка, копирование, значки, выгрузка в PNG и PDF.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Plus, Trash2, Pencil, LayoutDashboard, Users as UsersIcon, MousePointer2,
  StickyNote, Square, Circle, Diamond, Triangle, Type, Minus, ArrowRight,
  Pen, Hand, Eraser, ZoomIn, ZoomOut, Maximize2, Undo2, Redo2, Shapes,
  Link as LinkIcon, Image as ImageIcon, FileText, Upload,
  ChevronsUp, ChevronsDown, ChevronUp, ChevronDown, Bold, Italic, Paintbrush,
  RotateCw, Check, Crosshair, Copy, ClipboardPaste, Group, Ungroup, Video, ChevronLeft,
} from "lucide-react";

// Стиль кнопки-иконки внутри плавающих капсул холста (компактнее общего .btn-icon).
const CAP_BTN = "w-8 h-8 shrink-0 rounded-full inline-flex items-center justify-center transition-colors duration-150 ease-out hover:bg-[color-mix(in_srgb,var(--t-text)_9%,transparent)] disabled:opacity-35 disabled:hover:bg-transparent";
// Функция stop предназначена для остановки всплытия событий: нажатия по капсулам не должны доходить до холста.
const stop = (e) => e.stopPropagation();
import { api } from "../lib/api.js";
import { onRealtimeMessage, realtimeSend } from "../lib/realtime.js";
import { copyText, resolveUser } from "../lib/theme.js";
import { Modal, ModalHeader, Field, Spinner, inputStyle } from "../lib/ui.jsx";
import { NameModal, MembersModal, EmptyPanel, AvatarStack, ROLE_LABEL, DANGER_ICON, tint, ruPlural } from "./Charts.jsx";
import InviteMembers from "./InviteMembers.jsx";
import { ICON_GROUPS, ICON_TITLES, ANIMATED_ICONS, ICON_COUNT, iconBody, hasIcon } from "../lib/boardIcons.js";
import { exportPng, exportPdf, linePath } from "../lib/wbExport.js";

// Описание работы совместной правки: изменения фигур сохраняются через REST и рассылаются остальным участникам по WebSocket;
// промежуточные кадры перетаскивания и положение курсоров передаются только через сокет.
// Набор инструментов TOOLS.

const TOOLS = [
  ["select", MousePointer2, "Выбрать (V)"],
  ["pan",    Hand,          "Двигать холст (H)"],
  ["note",   StickyNote,    "Стикер (N)"],
  ["rect",   Square,        "Прямоугольник (R)"],
  ["ellipse", Circle,       "Овал (O)"],
  ["diamond", Diamond,      "Ромб"],
  ["triangle", Triangle,    "Треугольник"],
  ["text",   Type,          "Текст (T)"],
  ["line",   Minus,         "Линия (L)"],
  ["arrow",  ArrowRight,    "Стрелка (A)"],
  ["draw",   Pen,           "Перо (P)"],
  ["frame",  Maximize2,     "Рамка области"],
  ["icon",   Shapes,        "Значок (I)"],
  ["eraser", Eraser,        "Ластик (E)"],
];

// Предопределённые цвета фигур (как у задач).
const PALETTE = [
  ["#FFF3B0", "Светло-жёлтый"],
  ["#FFD966", "Жёлтый"],
  ["#F6B26B", "Песочный"],
  ["#F4A259", "Оранжевый"],
  ["#E8865A", "Терракотовый"],
  ["#E36A6A", "Красный"],
  ["#C1666B", "Приглушённый красный"],
  ["#F4B6C2", "Розовый"],
  ["#D5A6BD", "Пыльная роза"],
  ["#B4A7D6", "Сиреневый"],
  ["#9B8AC4", "Фиолетовый"],
  ["#7768AE", "Тёмно-фиолетовый"],
  ["#A2C4C9", "Пыльная бирюза"],
  ["#8AC6A9", "Мятный"],
  ["#5B8C5A", "Зелёный"],
  ["#2A9D8F", "Бирюзовый"],
  ["#9FC5E8", "Голубой"],
  ["#6FA8DC", "Синий"],
  ["#3D5A80", "Тёмно-синий"],
  ["#2F4858", "Графитовый"],
  ["#D9D2C5", "Бежевый"],
  ["#C7CBD1", "Серый"],
  ["#8E9AAF", "Стальной"],
  ["#5A6472", "Тёмно-серый"],
  ["#FFFFFF", "Белый"],
  ["#1B1B1B", "Чёрный"],
];

// Цвета текста: отдельный ряд, обеспечивающий читаемость на любой заливке.
const TEXT_COLORS = [
  ["#1B1B1B", "Чёрный"],
  ["#3F3F46", "Тёмно-серый"],
  ["#6B7280", "Серый"],
  ["#FFFFFF", "Белый"],
  ["#F3F4F6", "Светло-серый"],
  ["#B3261E", "Красный"],
  ["#B45309", "Коричневый"],
  ["#946200", "Охра"],
  ["#1B5E20", "Зелёный"],
  ["#00695C", "Бирюзовый"],
  ["#0B3D91", "Синий"],
  ["#4527A0", "Фиолетовый"],
  ["#AD1457", "Малиновый"],
];

// Заливка полотна: светлые тона для схем и печати, тёмные для работы вечером и для проектора.
const BOARD_BG = [
  ["#FFFFFF", "Белый"],
  ["#FAFAF7", "Молочный"],
  ["#F5F2EA", "Бумага"],
  ["#F3F6F4", "Светло-зелёный"],
  ["#EAF0F6", "Светло-голубой"],
  ["#F4EFF7", "Светло-сиреневый"],
  ["#FBF0EC", "Персиковый"],
  ["#EDEEF0", "Светло-серый"],
  ["#DDE3E8", "Серо-голубой"],
  ["#C9D3D8", "Стальной"],
  ["#2B3440", "Тёмно-синий"],
  ["#1E2430", "Ночной"],
  ["#11161F", "Почти чёрный"],
  ["#1B2018", "Тёмно-зелёный"],
];

const FONT_SIZES = [11, 13, 16, 20, 26, 34, 48];

// Размеры полотна: одинаковые у всех участников.
const BOARD_SIZES = [
  ["Стандартный (Full HD)", 1920, 1080],
  ["Средний (4K)", 3840, 2160],
  ["Большой (8K)", 7680, 4320],
];

// Ступени масштаба.
const ZOOM_STEPS = [0.1, 0.25, 0.5, 0.75, 1, 1.5, 2, 3];
// Функция clampZoom предназначена для ограничения масштаба допустимым диапазоном.
const clampZoom = (k) => Math.min(3, Math.max(0.1, k));
// Функция nextZoom предназначена для получения следующей ступени масштаба.
const nextZoom = (k) => ZOOM_STEPS.find((z) => z > k + 0.001) || 3;
// Функция prevZoom предназначена для получения предыдущей ступени масштаба.
const prevZoom = (k) => [...ZOOM_STEPS].reverse().find((z) => z < k - 0.001) || 0.1;

const DEFAULT_SIZE = {
  note: [180, 140], rect: [180, 120], ellipse: [160, 120], diamond: [150, 120],
  triangle: [150, 120], text: [220, 40], line: [180, 0], arrow: [180, 0],
  draw: [0, 0], frame: [420, 300], image: [200, 150], icon: [80, 80],
};

// Компонент Whiteboards предназначен для списка досок и открытия выбранной доски.
export default function Whiteboards({ theme, directory, team, currentUser, onError, openId, onOpened }) {
  const [boards, setBoards] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const list = await api.whiteboards();
      setBoards(list);
      // Без выбранной доски отображается список плиток.
      setActiveId((prev) => (prev && list.some((b) => b.id === prev) ? prev : null));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [onError]);

  useEffect(() => { load(); }, [load]);

  // Доска, открытая по ссылке: выбирается после загрузки списка.
  useEffect(() => {
    if (!openId) return;
    if (boards.some((b) => b.id === openId)) {
      setActiveId(openId);
      onOpened?.();
    }
  }, [openId, boards, onOpened]);

  // Изменения доски и состава участников применяются по событию без перезагрузки.
  useEffect(() => onRealtimeMessage("whiteboard", () => { load(); }), [load]);

  const active = boards.find((b) => b.id === activeId) || null;

  if (loading) return <Spinner theme={theme} label="Загружаем доски…" />;

  return (
    <div className="pb-6">
      {boards.length === 0 ? (
        <EmptyPanel theme={theme} icon={LayoutDashboard} title="Досок пока нет"
          text="Создайте первую — это общий холст: стикеры, фигуры, значки, стрелки и надписи, которые все участники видят и правят одновременно."
          action="Новая доска" onAction={() => setCreating(true)} />
      ) : active ? (
        <BoardCanvas key={active.id} theme={theme} board={active} directory={directory}
          team={team} currentUser={currentUser} onError={onError} onChanged={load}
          onBack={() => setActiveId(null)}
          onDeleted={() => { setActiveId(null); load(); }} />
      ) : (
        <>
          <div className="flex items-center gap-3 flex-wrap mb-4">
            <span style={{ color: theme.textMuted }} className="text-[14px] tabular-nums">
              {boards.length} {ruPlural(boards.length, "доска", "доски", "досок")}
            </span>
            <button onClick={() => setCreating(true)} className="btn-primary ml-auto">
              <Plus size={16} /> Новая доска
            </button>
          </div>
          <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))" }}>
            {boards.map((b) => (
              <BoardTile key={b.id} theme={theme} board={b} directory={directory}
                onOpen={() => setActiveId(b.id)} />
            ))}
          </div>
        </>
      )}

      {creating && (
        <BoardSettingsModal theme={theme} title="Новая доска"
          onClose={() => setCreating(false)}
          onSave={async (form) => {
            try {
              const b = await api.createWhiteboard(form);
              setBoards((prev) => [...prev, b]);
              setActiveId(b.id);
              setCreating(false);
            } catch (e) { onError(e.message); }
          }} />
      )}
    </div>
  );
}

/* Раздел: плитка доски. */

// Компонент BoardTile предназначен для плитки доски в списке: миниатюра полотна, название, роль и участники.
function BoardTile({ theme, board, directory, onOpen }) {
  const members = board.members || [];
  const owner = members.find((m) => m.role === "owner");
  const ownerUser = owner ? resolveUser(directory, owner.userId) : null;
  return (
    <button data-wb-tile onClick={onOpen}
      className="glass p-3 text-left flex flex-col gap-3 min-w-0 transition-transform duration-150 ease-out hover:-translate-y-0.5">
      <div style={{
        background: board.bgColor || theme.surface,
        backgroundImage: `radial-gradient(${theme.border} 1px, transparent 1px)`,
        backgroundSize: "14px 14px",
        border: `1px solid ${theme.border}`,
        aspectRatio: `${board.width || 16} / ${board.height || 9}`,
      }} className="w-full rounded-xl flex items-center justify-center">
        <LayoutDashboard size={26} style={{ color: theme.textMuted, opacity: 0.6 }} />
      </div>
      <div className="px-1 min-w-0 w-full">
        <div className="flex items-center gap-2 min-w-0">
          <span style={{ color: theme.text }} className="text-[16px] font-semibold leading-snug truncate flex-1">
            {board.title}
          </span>
          <ArrowRight size={16} style={{ color: theme.textMuted }} className="shrink-0" />
        </div>
        <div className="flex items-center gap-2 mt-2 min-w-0">
          <span style={{ background: theme.surface, color: theme.textMuted }} className="pill">
            {ROLE_LABEL[board.myRole] || "Участник"}
          </span>
          <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums">
            {board.width}×{board.height}
          </span>
          <span className="ml-auto flex items-center gap-1.5 min-w-0">
            <AvatarStack theme={theme} directory={directory} members={members} max={3} />
          </span>
        </div>
        {ownerUser && (
          <div style={{ color: theme.textMuted }} className="text-[12px] mt-1.5 truncate">
            Владелец · {ownerUser.fullName}
          </div>
        )}
      </div>
    </button>
  );
}

/* Раздел: свойства доски. */
/* Компонент BoardSettingsModal предназначен для окна свойств доски (название, размер, фон). */

function BoardSettingsModal({ theme, title, board, onClose, onSave }) {
  const [form, setForm] = useState({
    title: board?.title || "",
    width: board?.width || 3840,
    height: board?.height || 2160,
    bgColor: board?.bgColor || "",
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="wb-settings">
      <ModalHeader theme={theme} title={title} onClose={onClose} />

      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} autoFocus
          style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[13px] outline-none" />
      </Field>

      <Field label="Размер полотна" theme={theme}
        hint="Одинаков у всех участников. Если экран меньше — появится прокрутка.">
        <div className="flex flex-col gap-1.5">
          {BOARD_SIZES.map(([label, w, h]) => (
            <button key={label} onClick={() => setForm((f) => ({ ...f, width: w, height: h }))}
              aria-pressed={form.width === w && form.height === h}
              style={{
                background: form.width === w && form.height === h ? tint(theme.accent, 0.14) : theme.surfaceAlt,
                color: theme.text,
                border: `1px solid ${form.width === w && form.height === h ? theme.accent : theme.border}`,
              }}
              className="px-3.5 py-2.5 rounded-xl text-[14px] text-left flex items-center gap-2 transition-colors duration-150">
              <span className="flex-1">{label}</span>
              <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums">{w}×{h}</span>
              {form.width === w && form.height === h && <Check size={15} style={{ color: theme.accent }} />}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Заливка доски" theme={theme}
        hint="Без заливки доска берёт цвет приложения, а в выгруженном файле останется прозрачной.">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button onClick={() => set("bgColor", "")}
            style={{
              background: theme.surfaceAlt, color: theme.text,
              border: `1px solid ${form.bgColor ? theme.border : theme.accent}`,
            }}
            className="px-3 h-7 rounded-full text-[12px]">Как в приложении</button>
          {BOARD_BG.map(([c, name]) => (
            <button key={c} onClick={() => set("bgColor", c)}
              style={{ background: c, outline: form.bgColor === c ? `2px solid ${theme.accent}` : "none",
                border: `1px solid ${theme.border}` }}
              className="w-7 h-7 rounded-full" title={name} aria-label={name} />
          ))}
        </div>
      </Field>

      <div className="flex gap-2 mt-4">
        <button onClick={onClose}
          className="btn-pill flex-1">Отмена</button>
        <button onClick={() => form.title.trim() && onSave({ ...form, title: form.title.trim() })}
          disabled={!form.title.trim()}
          className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed">Сохранить</button>
      </div>
    </Modal>
  );
}

/* Раздел: холст. */
/* Компонент BoardCanvas предназначен для отображения и правки доски. */

function BoardCanvas({ theme, board, directory, team, currentUser, onError, onBack, onChanged, onDeleted }) {
  const [shapes, setShapes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tool, setTool] = useState("select");
  const [color, setColor] = useState(PALETTE[0][0]);
  // Выделение — список: фигуры двигают и оформляют группами.
  const [selection, setSelection] = useState([]);
  const [marquee, setMarquee] = useState(null);   // рамка выделения
  const clipboard = useRef([]);
  const [editingText, setEditingText] = useState(null);
  const [membersOpen, setMembersOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [iconsOpen, setIconsOpen] = useState(false);
  const [pickedIcon, setPickedIcon] = useState({ icon: "router" });
  const [linkCopied, setLinkCopied] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);

  // Положение и масштаб холста сохраняются между перезагрузками.
  const viewKey = `kanban.wb.view.${board.id}`;
  const [view, setView] = useState(() => {
    try {
      const raw = JSON.parse(localStorage.getItem(viewKey) || "null");
      if (raw && Number.isFinite(raw.x) && Number.isFinite(raw.y) && raw.k > 0) return raw;
    } catch { /* испорченная запись — начнём с центра */ }
    return null;   // null означает «ещё не считали, встанем в центр»
  });
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!view) return;
    try { localStorage.setItem(viewKey, JSON.stringify(view)); }
    catch { /* приватный режим — просто не запомним */ }
  }, [view, viewKey]);

  const [peers, setPeers] = useState({});
  const [ghosts, setGhosts] = useState({});

  const canEdit = ["owner", "editor"].includes(board.myRole);
  const isOwner = board.myRole === "owner";
  const bg = board.bgColor || theme.surface;

  const load = useCallback(async () => {
    try { setShapes(await api.shapes(board.id)); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  }, [board.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Функция centeredView предназначена для получения положения, при котором середина полотна совпадает с серединой окна.
  const centeredView = useCallback((k) => {
    const r = wrapRef.current?.getBoundingClientRect();
    const w = r?.width || 0;
    const h = r?.height || 0;
    return { x: w / 2 - (board.width * k) / 2, y: h / 2 - (board.height * k) / 2 };
  }, [board.width, board.height]);

  const centerBoard = useCallback(() => {
    setView((v) => ({ ...v, ...centeredView(v.k) }));
  }, [centeredView]);

  // При первом открытии доски (сохранённого вида нет) полотно центрируется.
  useEffect(() => {
    setView((v) => v || { ...centeredView(1), k: 1 });
  }, [board.id, centeredView]);

  useEffect(() => {
    const join = () => realtimeSend({ type: "wbJoin", boardId: board.id });
    join();
    const t = setInterval(join, 20000);
    return () => {
      clearInterval(t);
      realtimeSend({ type: "wbLeave", boardId: board.id });
    };
  }, [board.id]);

  useEffect(() => onRealtimeMessage("shape", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id) return;
    if (p.by === currentUser?.id) return;
    if (e.action === "cleared") { setShapes([]); return; }
    if (e.action === "deleted") {
      setShapes((prev) => prev.filter((s) => s.id !== p.id));
      setGhosts((g) => { const n = { ...g }; delete n[p.id]; return n; });
      return;
    }
    if (!p.shape) return;
    setShapes((prev) => {
      const i = prev.findIndex((s) => s.id === p.shape.id);
      if (i === -1) return [...prev, p.shape];
      const next = [...prev];
      next[i] = p.shape;
      return next;
    });
    setGhosts((g) => { const n = { ...g }; delete n[p.shape.id]; return n; });
  }), [board.id, currentUser?.id]);

  useEffect(() => onRealtimeMessage("wbCursor", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id || p.userId === currentUser?.id) return;
    setPeers((prev) => ({ ...prev, [p.userId]: { ...p.data, at: Date.now() } }));
  }), [board.id, currentUser?.id]);

  useEffect(() => onRealtimeMessage("wbDrag", (e) => {
    const p = e.payload || {};
    if (p.boardId !== board.id || p.userId === currentUser?.id) return;
    if (!p.data?.id) return;
    setGhosts((prev) => ({ ...prev, [p.data.id]: p.data }));
  }), [board.id, currentUser?.id]);

  useEffect(() => {
    const t = setInterval(() => {
      setPeers((prev) => {
        const now = Date.now();
        const next = {};
        for (const [k, v] of Object.entries(prev)) if (now - v.at < 8000) next[k] = v;
        return next;
      });
    }, 4000);
    return () => clearInterval(t);
  }, []);

  /* Раздел: отмена и возврат. Стопка шагов, каждый шаг содержит способ отката и повтора; глубина не ограничена. */
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const idMap = useRef(new Map());
  const [histVersion, setHistVersion] = useState(0);
  const bumpHistory = () => setHistVersion((v) => v + 1);

  const realId = useCallback((id) => {
    let cur = id;
    // Цепочка подстановок идентификаторов: фигуру могли пересоздавать несколько раз.
    for (let i = 0; i < 20 && idMap.current.has(cur); i++) cur = idMap.current.get(cur);
    return cur;
  }, []);

  const pushHistory = (step) => {
    undoStack.current.push(step);
    redoStack.current = [];
    bumpHistory();
  };

  /* Раздел: координаты. */
  const toCanvas = useCallback((clientX, clientY) => {
    const r = wrapRef.current?.getBoundingClientRect();
    if (!r) return { x: 0, y: 0 };
    const v = view || { x: 0, y: 0, k: 1 };
    return { x: (clientX - r.left - v.x) / v.k, y: (clientY - r.top - v.y) / v.k };
  }, [view]);

  /* Раздел: операции с фигурами. */
  const createShape = async (kind, at, extra = {}, { history = true } = {}) => {
    const [w, h] = DEFAULT_SIZE[kind] || [160, 120];
    const payload = {
      kind, x: at.x, y: at.y, w, h, opacity: 1,
      data: { fill: color, stroke: color, text: "", strokeWidth: 2, fontSize: 13, ...extra },
    };
    const tempId = `temp-${Math.random().toString(36).slice(2)}`;
    setShapes((prev) => [...prev, { ...payload, id: tempId, boardId: board.id, z: prev.length, angle: 0 }]);
    try {
      const created = await api.createShape(board.id, payload);
      setShapes((prev) => prev.map((s) => (s.id === tempId ? created : s)));
      if (kind === "note" || kind === "text") setEditingText(created.id);
      setSelection([created.id]);
      if (history) {
        pushHistory({
          kind: "create", id: created.id, payload,
          undo: async (id) => { await api.deleteShape(board.id, id); },
          redo: async () => api.createShape(board.id, payload),
        });
      }
      return created;
    } catch (e) {
      setShapes((prev) => prev.filter((s) => s.id !== tempId));
      onError(e.message);
      return null;
    }
  };

  const patchShape = async (id, patch, { history = true, before = null, silent = false } = {}) => {
    const prevState = before || shapes.find((s) => s.id === id);
    setShapes((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
    try {
      await api.updateShape(board.id, realId(id), patch);
      if (history && prevState) {
        const old = {};
        for (const k of Object.keys(patch)) old[k] = prevState[k];
        pushHistory({
          kind: "patch", id,
          undo: async (rid) => { await api.updateShape(board.id, rid, old); },
          redo: async (rid) => { await api.updateShape(board.id, rid, patch); },
        });
      }
    } catch (e) {
      if (!silent) onError(e.message);
    }
  };

  const removeShape = async (id) => {
    const gone = shapes.find((s) => s.id === id);
    setShapes((prev) => prev.filter((s) => s.id !== id));
    setSelection((prev) => prev.filter((x) => x !== id));
    try {
      await api.deleteShape(board.id, realId(id));
      if (gone) {
        const payload = {
          kind: gone.kind, x: gone.x, y: gone.y, w: gone.w, h: gone.h,
          angle: gone.angle, opacity: gone.opacity, data: gone.data,
        };
        pushHistory({
          kind: "delete", id,
          undo: async () => api.createShape(board.id, payload),
          redo: async (rid) => { await api.deleteShape(board.id, rid); },
        });
      }
    } catch (e) { onError(e.message); }
  };

  // Функция applyStep предназначена для отката и повтора шага. Пересозданная фигура получает новый идентификатор,
  // который запоминается в карте подстановки.
  const applyStep = async (step, direction) => {
    const rid = realId(step.id);
    const fn = direction === "undo" ? step.undo : step.redo;
    const res = await fn(rid);
    if (res?.id && res.id !== rid) idMap.current.set(rid, res.id);
    await load();
  };

  const undo = async () => {
    const step = undoStack.current.pop();
    if (!step) return;
    try { await applyStep(step, "undo"); redoStack.current.push(step); }
    catch (e) { onError(e.message); }
    bumpHistory();
  };

  const redo = async () => {
    const step = redoStack.current.pop();
    if (!step) return;
    try { await applyStep(step, "redo"); undoStack.current.push(step); }
    catch (e) { onError(e.message); }
    bumpHistory();
  };

  const reorder = async (id, move) => {
    try {
      await api.reorderShape(board.id, realId(id), move);
      await load();
      // Обратный шаг для порядка слоёв не хранится.
      redoStack.current = [];
      bumpHistory();
    } catch (e) { onError(e.message); }
  };

  /* Раздел: мышь. */
  const drag = useRef(null);
  const [drawing, setDrawing] = useState(null);

  const onPointerDown = (e) => {
    if (e.button !== 0) return;
    const at = toCanvas(e.clientX, e.clientY);

    if (tool === "pan" || e.altKey) {
      drag.current = { mode: "pan", x: e.clientX, y: e.clientY, view: view || { x: 0, y: 0, k: 1 } };
      return;
    }
    if (tool === "select") {
      // Нажатие по пустому месту начинает рамку выделения; без Shift выделение снимается.
      if (!e.shiftKey) setSelection([]);
      setMarquee({ x0: at.x, y0: at.y, x1: at.x, y1: at.y, additive: e.shiftKey });
      return;
    }
    if (!canEdit || tool === "eraser") return;

    if (tool === "draw") { setDrawing({ points: [[at.x, at.y]] }); return; }
    if (tool === "line" || tool === "arrow") { setDrawing({ line: true, from: at, to: at }); return; }
    if (tool === "icon") { createShape("icon", at, { ...pickedIcon, fill: color }); return; }
    createShape(tool, at);
    // Инструмент не сбрасывается: фигуры обычно ставят подряд.
  };

  const onPointerMove = (e) => {
    realtimeSend({
      type: "wbCursor", boardId: board.id,
      payload: { ...toCanvas(e.clientX, e.clientY) },
    });

    const d = drag.current;
    if (d?.mode === "pan") {
      setView({ ...d.view, x: d.view.x + (e.clientX - d.x), y: d.view.y + (e.clientY - d.y) });
      return;
    }
    if (d?.mode === "move") {
      const at = toCanvas(e.clientX, e.clientY);
      setShapes((prev) => prev.map((s) => {
        const m = d.moving.find((x) => x.id === s.id);
        return m ? { ...s, x: at.x - m.dx, y: at.y - m.dy } : s;
      }));
      for (const m of d.moving) {
        realtimeSend({ type: "wbDrag", boardId: board.id,
          payload: { id: m.id, x: at.x - m.dx, y: at.y - m.dy, w: m.before.w, h: m.before.h } });
      }
      return;
    }
    if (d?.mode === "resize") {
      const at = toCanvas(e.clientX, e.clientY);
      const w = Math.max(20, at.x - d.x0);
      const h = Math.max(20, at.y - d.y0);
      setShapes((prev) => prev.map((s) => (s.id === d.id ? { ...s, w, h } : s)));
      realtimeSend({ type: "wbDrag", boardId: board.id, payload: { id: d.id, x: d.x0, y: d.y0, w, h } });
      return;
    }
    if (d?.mode === "rotate") {
      const at = toCanvas(e.clientX, e.clientY);
      const angle = Math.round(Math.atan2(at.y - d.cy, at.x - d.cx) * 180 / Math.PI + 90);
      setShapes((prev) => prev.map((s) => (s.id === d.id ? { ...s, angle } : s)));
      return;
    }
    if (d?.mode === "endpoint") {
      // Перетаскивание конца линии: изменяются направление и длина.
      const at = toCanvas(e.clientX, e.clientY);
      setShapes((prev) => prev.map((s) => {
        if (s.id !== d.id) return s;
        if (d.end === "to") return { ...s, data: { ...s.data, dx: at.x - s.x, dy: at.y - s.y } };
        const dx = (s.data.dx ?? s.w) + (s.x - at.x);
        const dy = (s.data.dy ?? 0) + (s.y - at.y);
        return { ...s, x: at.x, y: at.y, data: { ...s.data, dx, dy } };
      }));
      return;
    }
    if (marquee) {
      const at = toCanvas(e.clientX, e.clientY);
      setMarquee((m) => ({ ...m, x1: at.x, y1: at.y }));
      return;
    }
    if (drawing?.points) {
      const at = toCanvas(e.clientX, e.clientY);
      setDrawing((p) => ({ ...p, points: [...p.points, [at.x, at.y]] }));
      return;
    }
    if (drawing?.line) setDrawing((p) => ({ ...p, to: toCanvas(e.clientX, e.clientY) }));
  };

  const onPointerUp = async () => {
    const d = drag.current;
    drag.current = null;

    if (marquee) {
      const x0 = Math.min(marquee.x0, marquee.x1);
      const x1 = Math.max(marquee.x0, marquee.x1);
      const y0 = Math.min(marquee.y0, marquee.y1);
      const y1 = Math.max(marquee.y0, marquee.y1);
      setMarquee(null);
      // В выделение попадает всё, что задела рамка (полное накрытие не требуется).
      const hit = shapes.filter((sh) => {
        const sx1 = sh.x + (sh.kind === "line" || sh.kind === "arrow" ? (sh.data?.dx ?? sh.w) : sh.w);
        const sy1 = sh.y + (sh.kind === "line" || sh.kind === "arrow" ? (sh.data?.dy ?? 0) : sh.h);
        const left = Math.min(sh.x, sx1);
        const right = Math.max(sh.x, sx1);
        const top = Math.min(sh.y, sy1);
        const bottom = Math.max(sh.y, sy1);
        return right >= x0 && left <= x1 && bottom >= y0 && top <= y1;
      }).flatMap((sh) => expandSelection(sh.id));
      if (hit.length > 0) {
        setSelection((prev) => (marquee.additive ? [...new Set([...prev, ...hit])] : [...new Set(hit)]));
      }
      return;
    }

    if (d?.mode === "move") {
      // В базу передаётся итог по каждой сдвинутой фигуре.
      for (const m of d.moving) {
        const s = shapes.find((x) => x.id === m.id);
        if (s) patchShape(m.id, { x: s.x, y: s.y }, { before: m.before, silent: true });
      }
      return;
    }
    if (d?.mode === "resize" || d?.mode === "rotate" || d?.mode === "endpoint") {
      const s = shapes.find((x) => x.id === d.id);
      if (s) {
        const patch = d.mode === "rotate" ? { angle: s.angle }
          : d.mode === "endpoint" ? { x: s.x, y: s.y, data: s.data }
          : { x: s.x, y: s.y, w: s.w, h: s.h };
        patchShape(d.id, patch, { before: d.before, silent: true });
      }
      return;
    }

    if (drawing?.points && drawing.points.length > 1) {
      const xs = drawing.points.map((p) => p[0]);
      const ys = drawing.points.map((p) => p[1]);
      const minX = Math.min(...xs);
      const minY = Math.min(...ys);
      const created = await createShape("draw", { x: minX, y: minY }, {
        points: drawing.points.map(([x, y]) => [x - minX, y - minY]), stroke: color,
      });
      if (created) {
        await api.updateShape(board.id, created.id, {
          w: Math.max(1, Math.max(...xs) - minX), h: Math.max(1, Math.max(...ys) - minY),
        });
        load();
      }
      setDrawing(null);
      return;
    }
    if (drawing?.line) {
      const { from, to } = drawing;
      await createShape(tool === "arrow" ? "arrow" : "line", from, {
        dx: to.x - from.x, dy: to.y - from.y, stroke: color, curve: 0,
      });
      setDrawing(null);
      return;
    }
    setDrawing(null);
  };

  // Функция zoomTo предназначена для изменения масштаба с сохранением точки в середине окна.
  const zoomTo = useCallback((k) => {
    setView((v) => {
      const cur = v || { x: 0, y: 0, k: 1 };
      const r = wrapRef.current?.getBoundingClientRect();
      const cx = (r?.width || 0) / 2;
      const cy = (r?.height || 0) / 2;
      // Точка холста под серединой окна до и после смены масштаба одна и та же.
      const px = (cx - cur.x) / cur.k;
      const py = (cy - cur.y) / cur.k;
      return { k, x: cx - px * k, y: cy - py * k };
    });
  }, []);

  const onWheel = (e) => {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    zoomTo(clampZoom((view?.k ?? 1) * (e.deltaY < 0 ? 1.1 : 0.9)));
  };

  const selectedShapes = shapes.filter((s) => selection.includes(s.id));
  const selectedShape = selectedShapes.length === 1 ? selectedShapes[0] : null;

  // Группа — общая пометка в свойствах фигур; отдельной таблицы нет.
  const groupOf = (sh) => sh?.data?.group || null;

  // Функция pickShape предназначена для выбора фигуры: с Shift — добавление в выделение и снятие, без Shift — выбор фигуры вместе с её группой.
  const pickShape = (id, additive) => {
    const ids = expandSelection(id);
    setSelection((prev) => {
      if (!additive) return ids;
      const has = ids.every((x) => prev.includes(x));
      return has ? prev.filter((x) => !ids.includes(x)) : [...new Set([...prev, ...ids])];
    });
  };

  // Функция groupSelected предназначена для группировки: выделенным фигурам присваивается общая пометка, они выделяются и двигаются вместе.
  const groupSelected = async () => {
    if (selection.length < 2) return;
    const gid = `g-${Math.random().toString(36).slice(2, 10)}`;
    for (const sh of selectedShapes) {
      await patchShape(sh.id, { data: { ...sh.data, group: gid } }, { history: false });
    }
  };

  const ungroupSelected = async () => {
    for (const sh of selectedShapes) {
      if (!groupOf(sh)) continue;
      const data = { ...sh.data };
      delete data.group;
      await patchShape(sh.id, { data }, { history: false });
    }
  };

  // Функция copySelected предназначена для копирования выделенных фигур во внутренний буфер (системный буфер хранит только текст).
  const copySelected = () => {
    if (selectedShapes.length === 0) return;
    clipboard.current = selectedShapes.map((sh) => ({
      kind: sh.kind, x: sh.x, y: sh.y, w: sh.w, h: sh.h,
      angle: sh.angle, opacity: sh.opacity, data: { ...sh.data },
    }));
  };

  const pasteClipboard = async () => {
    if (!canEdit || clipboard.current.length === 0) return;
    // При вставке группе назначается новый идентификатор, чтобы копии не двигались вместе с оригиналами.
    const remap = new Map();
    const created = [];
    for (const item of clipboard.current) {
      const data = { ...item.data };
      if (data.group) {
        if (!remap.has(data.group)) remap.set(data.group, `g-${Math.random().toString(36).slice(2, 10)}`);
        data.group = remap.get(data.group);
      }
      try {
        const sh = await api.createShape(board.id, { ...item, x: item.x + 24, y: item.y + 24, data });
        created.push(sh);
      } catch (e) { onError(e.message); return; }
    }
    setShapes((prev) => [...prev, ...created]);
    setSelection(created.map((c) => c.id));
    pushHistory({
      kind: "paste", id: created[0]?.id,
      undo: async () => {
        for (const c of created) await api.deleteShape(board.id, c.id).catch(() => {});
      },
      redo: async () => {
        for (const c of created) await api.createShape(board.id, c).catch(() => {});
      },
    });
  };

  const deleteSelected = async () => {
    for (const id of [...selection]) await removeShape(id);
    setSelection([]);
  };
  const expandSelection = (id) => {
    const sh = shapes.find((x) => x.id === id);
    const g = groupOf(sh);
    if (!g) return [id];
    return shapes.filter((x) => groupOf(x) === g).map((x) => x.id);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (editingText) return;
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo(); else undo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c") { e.preventDefault(); copySelected(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") { e.preventDefault(); pasteClipboard(); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
        // Сочетание «выделить всё».
        e.preventDefault();
        setSelection(shapes.map((x) => x.id));
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "g") {
        e.preventDefault();
        if (e.shiftKey) ungroupSelected(); else groupSelected();
        return;
      }
      const map = { v: "select", n: "note", r: "rect", o: "ellipse", t: "text",
        l: "line", a: "arrow", p: "draw", e: "eraser", h: "pan", i: "icon" };
      const k = e.key.toLowerCase();
      if (map[k]) setTool(map[k]);
      if ((e.key === "Delete" || e.key === "Backspace") && selection.length && canEdit) deleteSelected();
      if (e.key === "Escape") { setSelection([]); setTool("select"); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const ordered = useMemo(() => [...shapes].sort((a, b) => a.z - b.z), [shapes]);

  // До первого расчёта вида полотно отображается от нуля со 100 %.
  const vx = view?.x ?? 0;
  const vy = view?.y ?? 0;
  const vk = view?.k ?? 1;

  const copyLink = async () => {
    const url = `${window.location.origin}/whiteboards/${board.id}`;
    if (await copyText(url)) {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } else {
      onError("Не удалось скопировать. Ссылка на доску: " + url);
    }
  };

  // Функция collectIconData предназначена для получения данных собственных значков для выгрузки картинкой
  // (ссылка на /api в отдельном файле требует токен).
  const collectIconData = async () => {
    const ids = [...new Set(shapes.filter((s) => s.kind === "icon" && s.data?.iconId)
      .map((s) => s.data.iconId))];
    const out = {};
    for (const id of ids) {
      try {
        const blob = await api.fileBlob(api.boardIconUrl(id));
        out[id] = await new Promise((res) => {
          const r = new FileReader();
          r.onload = () => res(r.result);
          r.readAsDataURL(blob);
        });
      } catch { /* значок не забрался — выгрузим без него */ }
    }
    return out;
  };

  const doExport = async (kind) => {
    setExporting(true);
    try {
      const iconData = await collectIconData();
      const opts = {
        shapes, width: board.width, height: board.height,
        // Заливка обязательна: без неё PNG прозрачен, а PDF чёрный; берётся цвет доски или белый.
        bg: board.bgColor || "#FFFFFF",
        theme, iconData,
      };
      const name = board.title.replace(/[^\p{L}\p{N}\-_ ]/gu, "").trim() || "доска";
      if (kind === "png") await exportPng(opts, `${name}.png`);
      else await exportPdf(opts, `${name}.pdf`);
    } catch (e) {
      onError(e.message || "Не удалось выгрузить доску");
    } finally {
      setExporting(false);
    }
  };

  const toolStyle = (on) => ({
    background: on ? tint(theme.accent, theme.dark ? 0.22 : 0.14) : undefined,
    color: on ? theme.accent : theme.text,
  });

  return (
    <div>
      <div className="flex items-center gap-3 flex-wrap mb-4">
        <div className="flex items-center gap-2 min-w-0">
          <button onClick={onBack} className="btn-icon shrink-0"
            title="Все доски" aria-label="Все доски"><ChevronLeft size={20} /></button>
          <div className="min-w-0">
            <h2 style={{ color: theme.text }} className="text-[20px] font-semibold leading-tight truncate">
              {board.title}
            </h2>
            <div style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">
              {ROLE_LABEL[board.myRole] || "Исполнитель"}
              {!canEdit && " · только просмотр"} · {board.width}×{board.height}
            </div>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2 flex-wrap">
          <button onClick={copyLink} className="btn-pill" title="Скопировать ссылку на доску">
            {linkCopied ? <Check size={15} /> : <LinkIcon size={15} />} {linkCopied ? "Скопировано" : "Ссылка"}
          </button>
          <button onClick={() => doExport("png")} disabled={exporting}
            className="btn-pill disabled:opacity-50" title="Сохранить картинкой">
            <ImageIcon size={15} /> PNG
          </button>
          <button onClick={() => doExport("pdf")} disabled={exporting}
            className="btn-pill disabled:opacity-50" title="Сохранить документом">
            <FileText size={15} /> PDF
          </button>

          {canEdit && (
            <>
              <button onClick={() => setInviteOpen(true)} className="btn-pill"
                title="Позвать участников: созвон, письмо, уведомление">
                <Video size={15} /> Собрать
              </button>
              <button onClick={() => setMembersOpen(true)} className="btn-pill">
                <UsersIcon size={15} /> Участники
              </button>
              <button onClick={() => setSettingsOpen(true)} className="btn-icon"
                title="Свойства доски" aria-label="Свойства доски"><Pencil size={16} /></button>
              <button onClick={() => setConfirmClear(true)} className="btn-icon"
                title="Очистить доску" aria-label="Очистить доску"><Eraser size={16} /></button>
            </>
          )}
          {isOwner && (
            <button onClick={() => setConfirmDelete(true)} className={DANGER_ICON}
              title="Удалить доску" aria-label="Удалить доску"><Trash2 size={16} /></button>
          )}
        </div>
      </div>

      {loading ? (
        <Spinner theme={theme} label="Загружаем доску…" />
      ) : (
        <div ref={wrapRef}
          onMouseDown={onPointerDown} onMouseMove={onPointerMove} onMouseUp={onPointerUp}
          onWheel={onWheel}
          style={{
            background: theme.surfaceAlt, border: `1px solid ${theme.border}`,
            height: "calc(100vh - 250px)", minHeight: 460,
            cursor: tool === "pan" ? "grab" : tool === "select" ? "default" : "crosshair",
          }}
          className="rounded-3xl relative overflow-hidden select-none">

          <div style={{
            position: "absolute", left: 0, top: 0,
            width: board.width, height: board.height,
            transform: `translate(${vx}px, ${vy}px) scale(${vk})`,
            transformOrigin: "0 0",
            background: bg,
            boxShadow: "0 0 0 1px rgba(0,0,0,0.12)",
          }}>
            {/* Клетка полотна для ощущения масштаба и выравнивания. */}
            <div aria-hidden style={{
              position: "absolute", inset: 0,
              backgroundImage: `radial-gradient(${theme.border} 1px, transparent 1px)`,
              backgroundSize: "24px 24px",
              opacity: 0.55,
            }} />

            {ordered.map((s) => (
              <Shape key={s.id} theme={theme} shape={ghosts[s.id] ? { ...s, ...ghosts[s.id] } : s}
                selected={selection.includes(s.id)} canEdit={canEdit} tool={tool}
                editing={editingText === s.id}
                onSelect={(e) => {
                  if (tool === "eraser" && canEdit) { removeShape(s.id); return; }
                  pickShape(s.id, e?.shiftKey);
                }}
                onStartMove={(e, sh) => {
                  if (!canEdit || tool !== "select") return;
                  // С Shift фигура добавляется в выделение, перенос не выполняется.
                  if (e.shiftKey) return;
                  const ids = selection.includes(sh.id) ? selection : expandSelection(sh.id);
                  if (!selection.includes(sh.id)) setSelection(ids);
                  const at = toCanvas(e.clientX, e.clientY);
                  // Всё выделенное двигается одновременно, у каждой фигуры свой сдвиг относительно курсора.
                  const moving = shapes.filter((x) => ids.includes(x.id))
                    .map((x) => ({ id: x.id, dx: at.x - x.x, dy: at.y - x.y, before: x }));
                  drag.current = { mode: "move", id: sh.id, moving, before: sh, w: sh.w, h: sh.h,
                    dx: at.x - sh.x, dy: at.y - sh.y };
                }}
                onStartResize={(e, sh) => {
                  if (!canEdit) return;
                  drag.current = { mode: "resize", id: sh.id, x0: sh.x, y0: sh.y, before: sh };
                }}
                onStartRotate={(e, sh) => {
                  if (!canEdit) return;
                  drag.current = { mode: "rotate", id: sh.id, before: sh,
                    cx: sh.x + sh.w / 2, cy: sh.y + sh.h / 2 };
                }}
                onStartEndpoint={(e, sh, end) => {
                  if (!canEdit) return;
                  drag.current = { mode: "endpoint", id: sh.id, end, before: sh };
                }}
                onEditText={() => canEdit && setEditingText(s.id)}
                onText={(text) => { patchShape(s.id, { data: { ...s.data, text } }); }}
                onDoneText={() => setEditingText(null)} />
            ))}

            {marquee && (
              <div style={{
                position: "absolute",
                left: Math.min(marquee.x0, marquee.x1),
                top: Math.min(marquee.y0, marquee.y1),
                width: Math.abs(marquee.x1 - marquee.x0),
                height: Math.abs(marquee.y1 - marquee.y0),
                border: `1px dashed ${theme.accent}`,
                background: `${theme.accent}18`,
                pointerEvents: "none",
              }} />
            )}

            {drawing?.points && (
              <svg style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }}>
                <polyline fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
                  points={drawing.points.map(([x, y]) => `${x},${y}`).join(" ")} />
              </svg>
            )}
            {drawing?.line && (
              <svg style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }}>
                <line x1={drawing.from.x} y1={drawing.from.y} x2={drawing.to.x} y2={drawing.to.y}
                  stroke={color} strokeWidth="2.5" />
              </svg>
            )}

            {Object.entries(peers).map(([uid, p]) => {
              const u = resolveUser(directory, uid);
              return (
                <div key={uid} style={{ left: p.x, top: p.y, position: "absolute", pointerEvents: "none" }}>
                  <MousePointer2 size={16} style={{ color: u.avatarColor || theme.accent }} />
                  <span style={{
                    background: u.avatarColor || theme.accent, color: "#fff",
                    transform: `scale(${1 / vk})`, transformOrigin: "0 0",
                  }} className="text-[10px] px-1.5 py-0.5 rounded whitespace-nowrap block mt-0.5">
                    {u.fullName}
                  </span>
                </div>
              );
            })}
          </div>

          {!canEdit && (
            <div className="glass pill absolute bottom-3 left-3 !text-[12px] !px-3 !py-1"
              style={{ color: theme.textMuted, borderRadius: 999 }}>
              Доступ только на просмотр
            </div>
          )}

          {/* Инструменты — плавающая капсула над холстом. */}
          {canEdit && (
            <div className="absolute top-3 inset-x-3 z-30 flex flex-col items-center gap-2 pointer-events-none [&>*]:pointer-events-auto">
              <div onMouseDown={stop} className="glass flex items-center gap-0.5 p-1 flex-wrap justify-center" style={{ borderRadius: 999 }}
                role="toolbar" aria-label="Инструменты холста">
                {TOOLS.map(([id, Icon, title]) => (
                  <button key={id}
                    onClick={() => { setTool(id); if (id === "icon") setIconsOpen(true); }}
                    title={title} aria-label={title} aria-pressed={tool === id}
                    style={toolStyle(tool === id)}
                    className={CAP_BTN}><Icon size={16} /></button>
                ))}
                <span style={{ background: theme.border }} className="w-px h-5 mx-1 shrink-0" />
                {/* Палитра открывается по нажатию на текущий цвет. */}
                <button onClick={() => setPaletteOpen((v) => !v)} className={CAP_BTN}
                  title="Цвет заливки" aria-label="Цвет заливки" aria-expanded={paletteOpen}>
                  <span style={{ background: color, boxShadow: `0 0 0 1px ${theme.border}, 0 0 0 3px ${paletteOpen ? theme.accent : "transparent"}` }}
                    className="w-[18px] h-[18px] rounded-full block" />
                </button>
                <span style={{ background: theme.border }} className="w-px h-5 mx-1 shrink-0" />
                <button onClick={undo} disabled={undoStack.current.length === 0} style={{ color: theme.text }}
                  className={CAP_BTN} title="Отменить (Ctrl+Z)" aria-label="Отменить"><Undo2 size={16} /></button>
                <button onClick={redo} disabled={redoStack.current.length === 0} style={{ color: theme.text }}
                  className={CAP_BTN} title="Вернуть (Ctrl+Shift+Z)" aria-label="Вернуть"><Redo2 size={16} /></button>
              </div>

              {paletteOpen && (
                <div onMouseDown={stop} className="glass p-2.5 grid gap-1.5" style={{ gridTemplateColumns: "repeat(13, 22px)", borderRadius: 18 }}>
                  {PALETTE.map(([c, name]) => (
                    <button key={c} onClick={() => {
                      setColor(c);
                      for (const sh of selectedShapes) {
                        patchShape(sh.id, { data: { ...sh.data, fill: c, stroke: c } });
                      }
                      setPaletteOpen(false);
                    }}
                      style={{ background: c, boxShadow: color === c ? `0 0 0 2px ${theme.surface}, 0 0 0 4px ${theme.accent}` : `inset 0 0 0 1px ${theme.border}` }}
                      className="w-[22px] h-[22px] rounded-full transition-transform duration-150 hover:scale-110" title={name} aria-label={name} />
                  ))}
                </div>
              )}

              {/* Свойства выбранной фигуры отображаются только при наличии выделения. */}
              {!paletteOpen && selectedShapes.length > 0 && (
                <div onMouseDown={stop}><ShapeToolbar theme={theme} shape={selectedShape || selectedShapes[0]}
                  count={selectedShapes.length}
                  grouped={selectedShapes.some((sh) => groupOf(sh))}
                  // Свойства применяются ко всему выделению.
                  onPatch={(patch) => {
                    for (const sh of selectedShapes) {
                      const p = patch.data ? { ...patch, data: { ...sh.data, ...patch.data } } : patch;
                      patchShape(sh.id, p);
                    }
                  }}
                  onReorder={(move) => { for (const sh of selectedShapes) reorder(sh.id, move); }}
                  onGroup={groupSelected} onUngroup={ungroupSelected}
                  onCopy={copySelected} onPaste={pasteClipboard}
                  onDelete={deleteSelected} /></div>
              )}
            </div>
          )}

          {/* Масштаб и положение — капсула в правом нижнем углу. */}
          <div onMouseDown={stop}
            className="glass absolute bottom-3 right-3 z-30 flex items-center gap-0.5 p-1" style={{ borderRadius: 999 }}>
            <button onClick={() => zoomTo(prevZoom(vk))} style={{ color: theme.text }} className={CAP_BTN}
              title="Уменьшить" aria-label="Уменьшить"><ZoomOut size={16} /></button>
            <button onClick={() => setView({ ...centeredView(1), k: 1 })} style={{ color: theme.text }}
              className="h-8 min-w-[52px] px-2 rounded-full text-[13px] font-medium tabular-nums transition-colors duration-150 hover:bg-[color-mix(in_srgb,var(--t-text)_9%,transparent)]"
              title="Масштаб 100% и в центр">{Math.round(vk * 100)}%</button>
            <button onClick={() => zoomTo(nextZoom(vk))} style={{ color: theme.text }} className={CAP_BTN}
              title="Увеличить" aria-label="Увеличить"><ZoomIn size={16} /></button>
            <span style={{ background: theme.border }} className="w-px h-5 mx-1 shrink-0 max-md:hidden" />
            {/* Ходовые масштабы (до 100 %) отдельными кнопками. */}
            {ZOOM_STEPS.filter((z) => z <= 1).map((z) => (
              <button key={z} onClick={() => zoomTo(z)} aria-pressed={Math.abs(vk - z) < 0.01}
                style={toolStyle(Math.abs(vk - z) < 0.01)}
                className="h-8 px-2 rounded-full text-[12px] font-medium tabular-nums transition-colors duration-150 hover:bg-[color-mix(in_srgb,var(--t-text)_9%,transparent)] max-md:hidden">
                {Math.round(z * 100)}%
              </button>
            ))}
            <span style={{ background: theme.border }} className="w-px h-5 mx-1 shrink-0" />
            {/* Возврат доски в поле зрения без изменения масштаба. */}
            <button onClick={centerBoard} style={{ color: theme.text }} className={CAP_BTN}
              title="Показать доску целиком по центру, не меняя масштаб" aria-label="По центру">
              <Crosshair size={16} />
            </button>
          </div>
        </div>
      )}

      {iconsOpen && (
        <IconPicker theme={theme} onError={onError}
          onClose={() => setIconsOpen(false)}
          onPick={(pick) => { setPickedIcon(pick); setTool("icon"); setIconsOpen(false); }} />
      )}

      {inviteOpen && (
        <InviteMembers theme={theme} kind="whiteboard" object={board} directory={directory}
          currentUser={currentUser} onClose={() => setInviteOpen(false)} onError={onError} />
      )}

      {membersOpen && (
        <MembersModal theme={theme} directory={directory} team={team} currentUser={currentUser}
          members={board.members || []} isOwner={isOwner}
          title={`Участники доски «${board.title}»`}
          onClose={() => setMembersOpen(false)}
          onSave={async (list) => {
            try { await api.setWhiteboardMembers(board.id, list); setMembersOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {settingsOpen && (
        <BoardSettingsModal theme={theme} title="Свойства доски" board={board}
          onClose={() => setSettingsOpen(false)}
          onSave={async (form) => {
            try { await api.updateWhiteboard(board.id, form); setSettingsOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {confirmClear && (
        <ConfirmModal theme={theme} title="Очистить доску?"
          message="С доски исчезнет всё, у всех участников. Отменить это нельзя."
          confirmLabel="Очистить" onClose={() => setConfirmClear(false)}
          onConfirm={async () => {
            try { await api.clearWhiteboard(board.id); setShapes([]); setConfirmClear(false); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {confirmDelete && (
        <ConfirmModal theme={theme} title="Удалить доску?"
          message={`Доска «${board.title}» и всё её содержимое исчезнут у всех участников. Отменить это нельзя.`}
          confirmLabel="Удалить" onClose={() => setConfirmDelete(false)}
          onConfirm={async () => {
            try { await api.deleteWhiteboard(board.id); onDeleted(); }
            catch (e) { onError(e.message); }
          }} />
      )}
    </div>
  );
}

// Компонент ConfirmModal предназначен для окна подтверждения действия.
function ConfirmModal({ theme, title, message, confirmLabel, onClose, onConfirm }) {
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm">
      <ModalHeader theme={theme} title={title} onClose={onClose} />
      <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed mb-4">{message}</p>
      <div className="flex gap-2">
        <button onClick={onClose}
          className="btn-pill flex-1">Отмена</button>
        <button onClick={onConfirm} style={{ background: theme.danger, color: "#fff" }}
              className="flex-1 rounded-full py-2 text-[14px] font-semibold transition-[filter] duration-150 hover:brightness-110">{confirmLabel}</button>
      </div>
    </Modal>
  );
}

/* Раздел: свойства выбранной фигуры. */
/* Компонент ShapeToolbar предназначен для панели свойств выделенных фигур. */

function ShapeToolbar({ theme, shape: s, count = 1, grouped, onPatch, onReorder,
  onGroup, onUngroup, onCopy, onPaste, onDelete }) {
  const d = s.data || {};
  const btn = { color: theme.text };
  const on = (v) => ({
    color: v ? theme.accent : theme.text,
    background: v ? tint(theme.accent, theme.dark ? 0.22 : 0.14) : undefined,
  });
  // Настройки текста и линий определяются по виду первой выбранной фигуры.
  const isLine = s.kind === "line" || s.kind === "arrow";
  const isText = ["note", "text", "rect", "ellipse", "diamond", "triangle", "frame"].includes(s.kind);

  return (
    <div className="glass px-2 py-1 flex items-center gap-2 flex-wrap justify-center" style={{ borderRadius: 20 }}
      role="toolbar" aria-label="Свойства фигуры">

      {count > 1 && (
        <span style={{ color: theme.textMuted }} className="text-[12px] px-1">
          выбрано: {count}
        </span>
      )}

      <div className="flex items-center gap-1">
        <button onClick={onCopy} style={btn} className={CAP_BTN}
          title="Копировать (Ctrl+C)"><Copy size={15} /></button>
        <button onClick={onPaste} style={btn} className={CAP_BTN}
          title="Вставить (Ctrl+V)"><ClipboardPaste size={15} /></button>
        {count > 1 && (
          <button onClick={onGroup} style={btn} className={CAP_BTN}
            title="Сгруппировать (Ctrl+G)"><Group size={15} /></button>
        )}
        {grouped && (
          <button onClick={onUngroup} style={btn} className={CAP_BTN}
            title="Разгруппировать (Ctrl+Shift+G)"><Ungroup size={15} /></button>
        )}
      </div>
      <span style={{ background: theme.border }} className="w-px h-6" />

      {isText && (
        <>
          <select value={d.fontSize || 13}
            onChange={(e) => onPatch({ data: { ...d, fontSize: Number(e.target.value) } })}
            style={inputStyle(theme)} className="rounded-xl px-2 py-1 text-[12px] outline-none"
            title="Размер шрифта" aria-label="Размер шрифта">
            {FONT_SIZES.map((n) => <option key={n} value={n}>{n} pt</option>)}
          </select>
          <button onClick={() => onPatch({ data: { ...d, bold: !d.bold } })}
            style={on(d.bold)} aria-pressed={Boolean(d.bold)}
            className={CAP_BTN} title="Полужирный" aria-label="Полужирный"><Bold size={15} /></button>
          <button onClick={() => onPatch({ data: { ...d, italic: !d.italic } })}
            style={on(d.italic)} aria-pressed={Boolean(d.italic)}
            className={CAP_BTN} title="Курсив" aria-label="Курсив"><Italic size={15} /></button>
          {/* Цвет текста задаётся отдельно от заливки. */}
          <div className="flex items-center gap-1" title="Цвет текста">
            <Paintbrush size={13} style={{ color: theme.textMuted }} />
            {TEXT_COLORS.map(([c, name]) => (
              <button key={c} onClick={() => onPatch({ data: { ...d, color: c } })}
                title={name}
                style={{ background: c, border: `1px solid ${theme.border}`,
                  outline: d.color === c ? `2px solid ${theme.accent}` : "none" }}
                className="w-4 h-4 rounded-full transition-transform duration-150 hover:scale-110" aria-label={name} />
            ))}
          </div>
          <span style={{ background: theme.border }} className="w-px h-6" />
        </>
      )}

      {isLine && (
        <>
          <label className="flex items-center gap-1.5 text-[12px]" style={{ color: theme.textMuted }}>
            Прогиб
            <input type="range" min="-200" max="200" value={d.curve || 0}
              onChange={(e) => onPatch({ data: { ...d, curve: Number(e.target.value) } })}
              className="w-24" title="Выпуклость линии" />
          </label>
          <button onClick={() => onPatch({ data: { ...d, dx: -(d.dx ?? s.w), dy: -(d.dy ?? 0) },
            x: s.x + (d.dx ?? s.w), y: s.y + (d.dy ?? 0) })}
            style={btn} className="h-8 px-3 rounded-full text-[12px] font-medium transition-colors duration-150 hover:bg-[color-mix(in_srgb,var(--t-text)_9%,transparent)]" title="Развернуть в другую сторону">
            Развернуть
          </button>
          <span style={{ background: theme.border }} className="w-px h-6" />
        </>
      )}

      <label className="flex items-center gap-1.5 text-[12px]" style={{ color: theme.textMuted }}>
        Толщина
        <input type="range" min="1" max="12" value={d.strokeWidth || 2}
          onChange={(e) => onPatch({ data: { ...d, strokeWidth: Number(e.target.value) } })}
          className="w-20" />
      </label>

      <label className="flex items-center gap-1.5 text-[12px]" style={{ color: theme.textMuted }}>
        Прозрачность
        <input type="range" min="10" max="100" value={Math.round((s.opacity ?? 1) * 100)}
          onChange={(e) => onPatch({ opacity: Number(e.target.value) / 100 })}
          className="w-20" />
      </label>

      <label className="flex items-center gap-1.5 text-[12px]" style={{ color: theme.textMuted }}
        title="Поворот. Тот же угол задаётся ручкой над фигурой.">
        <RotateCw size={13} />
        <input type="range" min="0" max="359" value={Math.round(s.angle || 0)}
          onChange={(e) => onPatch({ angle: Number(e.target.value) })} className="w-20" />
      </label>

      <span style={{ background: theme.border }} className="w-px h-6" />

      <div className="flex items-center gap-1">
        <button onClick={() => onReorder("front")} style={btn} className={CAP_BTN}
          title="На самый верх"><ChevronsUp size={15} /></button>
        <button onClick={() => onReorder("forward")} style={btn} className={CAP_BTN}
          title="На уровень выше"><ChevronUp size={15} /></button>
        <button onClick={() => onReorder("backward")} style={btn} className={CAP_BTN}
          title="На уровень ниже"><ChevronDown size={15} /></button>
        <button onClick={() => onReorder("back")} style={btn} className={CAP_BTN}
          title="В самый низ"><ChevronsDown size={15} /></button>
      </div>

      <button onClick={onDelete} className={`${DANGER_ICON} !w-8 !h-8`}
        title="Удалить фигуру" aria-label="Удалить фигуру"><Trash2 size={15} /></button>
    </div>
  );
}

/* Раздел: выбор значка. */
/* Компонент IconPicker предназначен для выбора значка из набора и загрузки своих. */

function IconPicker({ theme, onClose, onPick, onError }) {
  const [custom, setCustom] = useState([]);
  const [busy, setBusy] = useState({ done: 0, total: 0 });
  const [q, setQ] = useState("");
  const [onlyAnimated, setOnlyAnimated] = useState(false);
  const fileRef = useRef(null);
  const dirRef = useRef(null);

  const load = useCallback(async () => {
    try { setCustom(await api.boardIcons()); }
    catch { /* свои значки не загрузились — встроенные всё равно есть */ }
  }, []);
  useEffect(() => { load(); }, [load]);

  // Функция uploadMany предназначена для загрузки нескольких файлов значков за раз, в том числе папкой.
  const uploadMany = async (files) => {
    const list = [...files].filter((f) => f.type.startsWith("image/"));
    if (list.length === 0) {
      onError("Значком может быть только изображение: SVG, PNG, APNG или GIF");
      return;
    }
    setBusy({ done: 0, total: list.length });
    let failed = 0;
    for (let i = 0; i < list.length; i++) {
      try {
        // Имя файла без расширения используется как подпись значка.
        const title = list[i].name.replace(/\.[^.]+$/, "");
        await api.uploadBoardIcon(list[i], title);
      } catch {
        failed++;
      }
      setBusy({ done: i + 1, total: list.length });
    }
    setBusy({ done: 0, total: 0 });
    await load();
    if (failed > 0) onError(`Не удалось загрузить: ${failed} из ${list.length}`);
  };

  const needle = q.trim().toLowerCase();
  const matches = (title, id) =>
    !needle || title.toLowerCase().includes(needle) || id.toLowerCase().includes(needle);

  // Разделы после отбора; пустые не отображаются.
  const groups = useMemo(() => ICON_GROUPS
    .map((g) => ({
      title: g.title,
      icons: g.icons.filter(([id, title]) =>
        matches(title, id) && (!onlyAnimated || ANIMATED_ICONS.has(id))),
    }))
    .filter((g) => g.icons.length > 0), [needle, onlyAnimated]);

  const shownCustom = custom.filter((ic) => matches(ic.title || "", ic.title || ""));
  const found = groups.reduce((n, g) => n + g.icons.length, 0);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-3xl" geometryKey="wb-icons">
      <ModalHeader theme={theme} title="Значки"
        subtitle={`${ICON_COUNT} встроенных, из них ${ANIMATED_ICONS.size} анимированных`}
        onClose={onClose} />

      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <input value={q} onChange={(e) => setQ(e.target.value)} autoFocus
          placeholder="Поиск: маршрутизатор, сервер, документ…"
          style={inputStyle(theme)}
          className="flex-1 min-w-[200px] rounded-xl px-3 py-2 text-[13px] outline-none" />
        <button onClick={() => setOnlyAnimated((v) => !v)} aria-pressed={onlyAnimated}
          style={onlyAnimated ? { background: tint(theme.accent, 0.14), color: theme.accent, borderColor: theme.accent } : undefined}
          className="btn-pill"
          title="Показать только анимированные">Анимированные</button>
      </div>

      <div className="max-h-[52vh] overflow-y-auto pr-1">
        {needle && found === 0 && shownCustom.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] py-4">
            Ничего не найдено. Попробуйте другое слово — или загрузите свой значок.
          </p>
        )}

        {groups.map((g) => (
          <div key={g.title} className="mb-3">
            <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-2">
              {g.title} · {g.icons.length}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {g.icons.map(([id, title]) => (
                <button key={id} onClick={() => onPick({ icon: id })} title={title}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="w-14 h-14 rounded-2xl flex items-center justify-center relative transition-colors duration-150 hover:!border-[var(--t-accent)]">
                  <svg viewBox="0 0 64 64" width="34" height="34"
                    dangerouslySetInnerHTML={{ __html: iconBody(id) }} />
                  {/* Анимированные значки помечены точкой. */}
                  {ANIMATED_ICONS.has(id) && (
                    <span style={{ background: theme.accent }}
                      className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full" />
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="mb-2">
          <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-2">
            Свои значки{custom.length ? ` · ${custom.length}` : ""}
          </div>
          {custom.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[12px] mb-2 leading-relaxed">
              Пока пусто. Загрузите свои наборы — целой папкой: SVG, PNG, APNG и GIF,
              анимация в них сохраняется. Значки появятся у всех и будут доступны на
              любой доске.
            </p>
          )}
          <div className="flex flex-wrap gap-1.5">
            {shownCustom.map((ic) => (
              <div key={ic.id} className="relative group">
                <button onClick={() => onPick({ iconId: ic.id })} title={ic.title}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="w-14 h-14 rounded-2xl flex items-center justify-center overflow-hidden transition-colors duration-150 hover:!border-[var(--t-accent)]">
                  <CustomIcon id={ic.id} size={36} />
                </button>
                {ic.canDelete && (
                  <button onClick={async () => {
                    try { await api.deleteBoardIcon(ic.id); load(); }
                    catch (e) { onError(e.message); }
                  }}
                    style={{ background: theme.danger, color: "#fff" }}
                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-[9px] opacity-0 group-hover:opacity-100"
                    title="Убрать из набора">×</button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Атрибуты multiple и webkitdirectory позволяют выбрать файлы или папку целиком. */}
      <input ref={fileRef} type="file" accept="image/*" multiple className="hidden"
        onChange={(e) => { uploadMany(e.target.files || []); e.target.value = ""; }} />
      <input ref={dirRef} type="file" accept="image/*" multiple className="hidden"
        webkitdirectory="" directory=""
        onChange={(e) => { uploadMany(e.target.files || []); e.target.value = ""; }} />

      <div className="flex gap-2 mt-3 flex-wrap">
        <button onClick={() => fileRef.current?.click()} disabled={busy.total > 0}
          className="btn-pill flex-1 disabled:opacity-50">
          <Upload size={14} />
          {busy.total > 0 ? `Загружаем ${busy.done} из ${busy.total}…` : "Загрузить значки"}
        </button>
        <button onClick={() => dirRef.current?.click()} disabled={busy.total > 0}
          className="btn-pill flex-1 disabled:opacity-50">
          <Upload size={14} /> Загрузить папку
        </button>
        <button onClick={onClose}
          className="btn-primary">Готово</button>
      </div>
    </Modal>
  );
}

// Кэш собственных значков: файл закрыт токеном, поэтому загружается запросом и отображается через blob-ссылку.
const iconCache = new Map();
// Компонент CustomIcon предназначен для отображения собственного значка.
function CustomIcon({ id, size = 32 }) {
  const [url, setUrl] = useState(() => iconCache.get(id) || null);
  useEffect(() => {
    if (iconCache.has(id)) { setUrl(iconCache.get(id)); return undefined; }
    let dead = false;
    api.fileBlob(api.boardIconUrl(id)).then((blob) => {
      if (dead) return;
      const made = URL.createObjectURL(blob);
      iconCache.set(id, made);
      setUrl(made);
    }).catch(() => {});
    return () => { dead = true; };
  }, [id]);
  if (!url) return <span style={{ width: size, height: size }} className="block animate-pulse" />;
  return <img src={url} alt="" width={size} height={size} style={{ objectFit: "contain" }} />;
}

/* Раздел: фигура. */
/* Компонент Shape предназначен для отображения фигуры на холсте. */

function Shape({ theme, shape: s, selected, canEdit, tool, editing, onSelect, onStartMove,
  onStartResize, onStartRotate, onStartEndpoint, onEditText, onText, onDoneText }) {
  const d = s.data || {};
  const fill = d.fill || theme.accent;
  const stroke = d.stroke || fill;
  const sw = d.strokeWidth || 2;

  const common = {
    onMouseDown: (e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); },
    style: {
      position: "absolute", left: s.x, top: s.y, width: s.w, height: s.h,
      transform: s.angle ? `rotate(${s.angle}deg)` : undefined,
      opacity: s.opacity ?? 1,
      outline: selected ? `2px solid ${theme.accent}` : "none",
      cursor: canEdit && tool === "select" ? "move" : "default",
    },
  };

  const textStyle = (fallback) => ({
    color: d.color || fallback,
    fontSize: d.fontSize || 13,
    fontWeight: d.bold ? 700 : 400,
    fontStyle: d.italic ? "italic" : "normal",
  });

  const textBox = (fallback) => (
    editing ? (
      <textarea autoFocus defaultValue={d.text || ""}
        onBlur={(e) => { onText(e.target.value); onDoneText(); }}
        onMouseDown={(e) => e.stopPropagation()}
        style={{ ...textStyle(fallback), background: "transparent", border: "none", outline: "none", resize: "none" }}
        className="w-full h-full p-2" />
    ) : (
      <div onDoubleClick={onEditText}
        style={{ ...textStyle(fallback), whiteSpace: "pre-wrap", overflow: "hidden" }}
        className="w-full h-full p-2 leading-snug">
        {d.text || ""}
      </div>
    )
  );

  // Ручки: изменение размера — в правом нижнем углу, поворот — над фигурой.
  const handles = selected && canEdit ? (
    <>
      <div onMouseDown={(e) => { e.stopPropagation(); onStartResize(e, s); }}
        style={{ background: theme.accent, right: -5, bottom: -5, position: "absolute" }}
        className="w-2.5 h-2.5 rounded-sm cursor-nwse-resize" title="Размер" />
      <div onMouseDown={(e) => { e.stopPropagation(); onStartRotate(e, s); }}
        style={{ background: theme.accent, left: "50%", top: -22, marginLeft: -6, position: "absolute" }}
        className="w-3 h-3 rounded-full cursor-grab" title="Повернуть" />
    </>
  ) : null;

  switch (s.kind) {
    case "note":
      return (
        <div {...common}>
          <div style={{ background: fill, boxShadow: "0 1px 4px rgba(0,0,0,0.2)" }}
            className="w-full h-full rounded-sm">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "text":
      return <div {...common}>{textBox(theme.text)}{handles}</div>;
    case "rect":
    case "frame":
      return (
        <div {...common}>
          <div style={{
            background: s.kind === "frame" ? "transparent" : fill,
            border: `${sw}px ${s.kind === "frame" ? "dashed" : "solid"} ${stroke}`,
          }} className="w-full h-full rounded-md">
            {textBox(s.kind === "frame" ? theme.text : "#1b1b1b")}
          </div>
          {handles}
        </div>
      );
    case "ellipse":
      return (
        <div {...common}>
          <div style={{ background: fill, border: `${sw}px solid ${stroke}`, borderRadius: "50%" }}
            className="w-full h-full flex items-center justify-center">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "diamond":
    case "triangle":
      return (
        <div {...common}>
          <div style={{
            background: fill,
            clipPath: s.kind === "diamond"
              ? "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)"
              : "polygon(50% 0%, 100% 100%, 0% 100%)",
          }} className="w-full h-full flex items-center justify-center">{textBox("#1b1b1b")}</div>
          {handles}
        </div>
      );
    case "icon": {
      const body = d.iconId ? null : iconBody(d.icon);
      return (
        <div {...common} title={d.icon ? ICON_TITLES[d.icon] : undefined}>
          {d.iconId ? (
            <CustomIcon id={d.iconId} size={Math.min(s.w, s.h)} />
          ) : hasIcon(d.icon) ? (
            <svg viewBox="0 0 64 64" width={s.w} height={s.h} style={{ color: fill }}
              dangerouslySetInnerHTML={{ __html: body }} />
          ) : (
            <div style={{ color: theme.textMuted }} className="text-[11px]">значок недоступен</div>
          )}
          {handles}
        </div>
      );
    }
    case "line":
    case "arrow": {
      const dx = d.dx ?? s.w;
      const dy = d.dy ?? 0;
      const pad = 12;
      const minX = Math.min(0, dx) - pad;
      const minY = Math.min(0, dy) - pad;
      const w = Math.abs(dx) + pad * 2;
      const h = Math.abs(dy) + pad * 2;
      // Путь линии вычисляется той же функцией (linePath), что при выгрузке.
      const path = linePath({ ...s, x: 0, y: 0, data: d, w: s.w });
      return (
        <div onMouseDown={(e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); }}
          style={{ position: "absolute", left: s.x + minX, top: s.y + minY,
            opacity: s.opacity ?? 1, cursor: canEdit ? "move" : "default" }}>
          <svg width={w} height={h} viewBox={`${minX} ${minY} ${w} ${h}`} style={{ overflow: "visible" }}>
            <defs>
              <marker id={`ah-${s.id}`} markerWidth="9" markerHeight="9" refX="7" refY="3"
                orient="auto" markerUnits="strokeWidth">
                <path d="M0,0 L0,6 L8,3 z" fill={stroke} />
              </marker>
            </defs>
            <path d={path} fill="none" stroke={stroke} strokeWidth={selected ? sw + 1 : sw}
              strokeLinecap="round" markerEnd={s.kind === "arrow" ? `url(#ah-${s.id})` : undefined} />
          </svg>
          {/* Концы линии перетаскиваются по отдельности. */}
          {selected && canEdit && (
            <>
              <div onMouseDown={(e) => { e.stopPropagation(); onStartEndpoint(e, s, "from"); }}
                style={{ background: theme.accent, position: "absolute",
                  left: -minX - 4, top: -minY - 4 }}
                className="w-2 h-2 rounded-full cursor-crosshair" title="Начало" />
              <div onMouseDown={(e) => { e.stopPropagation(); onStartEndpoint(e, s, "to"); }}
                style={{ background: theme.accent, position: "absolute",
                  left: (dx - minX) - 4, top: (dy - minY) - 4 }}
                className="w-2 h-2 rounded-full cursor-crosshair" title="Конец" />
            </>
          )}
        </div>
      );
    }
    case "draw": {
      const pts = d.points || [];
      return (
        <div onMouseDown={(e) => { e.stopPropagation(); onSelect(e); onStartMove(e, s); }}
          style={{ position: "absolute", left: s.x, top: s.y, opacity: s.opacity ?? 1,
            transform: s.angle ? `rotate(${s.angle}deg)` : undefined,
            cursor: canEdit ? "move" : "default" }}>
          <svg style={{ overflow: "visible" }} width={Math.max(1, s.w)} height={Math.max(1, s.h)}>
            <polyline fill="none" stroke={stroke} strokeWidth={selected ? sw + 1 : sw}
              strokeLinecap="round" strokeLinejoin="round"
              points={pts.map(([x, y]) => `${x},${y}`).join(" ")} />
          </svg>
          {handles}
        </div>
      );
    }
    default:
      return null;
  }
}
