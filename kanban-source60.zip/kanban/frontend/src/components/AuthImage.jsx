import React, { useEffect, useState } from "react";
import { api } from "../lib/api.js";

// Модуль предназначен для загрузки изображений и файлов с авторизацией: браузер не добавляет заголовок Authorization
// к <img src>, <a href> и <iframe src>, поэтому файл запрашивается с токеном и отображается через blob-ссылку.
// Компонент AuthImage предназначен для отображения изображения по пути на сервере.

export default function AuthImage({ path, alt, className, style, theme }) {
  const [url, setUrl] = useState(null);

  useEffect(() => {
    let dead = false;
    let made = null;
    api.fileBlob(path)
      .then((blob) => {
        if (dead) return;
        made = URL.createObjectURL(blob);
        setUrl(made);
      })
      .catch(() => {
        /* при ошибке загрузки отображается заглушка (миниатюра в списке) */
      });
    return () => {
      dead = true;
      if (made) URL.revokeObjectURL(made);
    };
  }, [path]);

  if (!url) {
    return (
      <span
        style={{ background: theme?.surface, border: `1px solid ${theme?.border || "transparent"}`, ...style }}
        className={`${className || ""} animate-pulse block`} />
    );
  }
  return <img src={url} alt={alt} className={className}
    style={{ border: `1px solid ${theme?.border || "transparent"}`, ...style }} />;
}

// Функция downloadFile предназначена для скачивания файла с токеном и сохранения через временную ссылку.
export async function downloadFile(path, filename) {
  try {
    const blob = await api.fileBlob(path);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || "файл";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch {
    /* причина ошибки видна пользователю в окне файла */
  }
}
