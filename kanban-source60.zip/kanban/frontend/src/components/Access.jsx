import React, { useEffect, useMemo, useState } from "react";
import { Search, Trash2, Plus, Copy, FolderKanban, KeyRound, UserCheck, ListChecks } from "lucide-react";
import { api } from "../lib/api.js";
import { ROLE_LABEL, GRANT_LABEL, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, ConfirmDialog, inputStyle } from "../lib/ui.jsx";

// Модуль предназначен для панели «Доступы»: слева список людей, справа — доступы выбранного пользователя (проекты, задачи,
// диаграммы, доски, замещения). Видимость и права управления определяет сервер (0027_access_panel.sql): обычный пользователь
// видит доступ коллег только в своих проектах, где он владелец или редактор; администратор видит всё и может копировать доступ коллеги.

const SECTIONS = [
  ["board", "Проекты", FolderKanban],
  ["task_grant", "Точечный доступ к задачам", KeyRound],
  ["task_assignee", "Исполнитель в задачах", ListChecks],
  ["chart", "Диаграммы", FolderKanban],
  ["whiteboard", "Совместные доски", FolderKanban],
  ["delegation_from", "Замещает", UserCheck],
  ["delegation_to", "Его замещает", UserCheck],
];

const EDITABLE_ROLES = ["editor", "reader"];

// Компонент Access предназначен для просмотра и изменения доступов пользователей.
export default function Access({ theme, directory, currentUser, onClose, onError, onInfo, onOpenTask }) {
  const isAdmin = currentUser.role === "admin";
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [boards, setBoards] = useState([]);
  const [grant, setGrant] = useState({ boardId: "", role: "reader" });
  const [copyFrom, setCopyFrom] = useState("");
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);

  const people = useMemo(() => {
    const q = query.trim().toLowerCase();
    return directory
      .filter((u) => !u.deleted && u.id !== currentUser.id)
      .filter((u) => !q || `${u.fullName} ${u.position || ""} ${u.email || ""}`.toLowerCase().includes(q))
      .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));
  }, [directory, query, currentUser.id]);

  useEffect(() => {
    api.accessBoards().then(setBoards).catch((e) => onError(e.message));
  }, [onError]);

  const load = async (userId = selected) => {
    if (!userId) return;
    setLoading(true);
    try {
      setRows(await api.accessOverview(userId));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(selected); }, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

  const person = selected ? resolveUser(directory, selected) : null;

  // Функция run предназначена для выполнения изменения с последующим перечитыванием списка: итоговую видимость определяет сервер.
  const run = async (fn, okMessage) => {
    setBusy(true);
    try {
      await fn();
      if (okMessage) onInfo(okMessage);
      await load();
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const setRole = (r, role) => run(() => api.setBoardAccess(r.objectId, selected, role));
  const setLevel = (r, access) => run(() => api.setTaskAccess(r.objectId, selected, access));

  const revoke = (r) => setConfirm({
    title: r.kind === "board" ? "Снять с проекта?" : "Закрыть доступ к задаче?",
    message: r.kind === "board"
      ? `${person.fullName} потеряет доступ к проекту «${r.title}». Задачи, где он исполнитель, останутся ему видны.`
      : `${person.fullName} потеряет доступ к задаче «${r.title}», если не связан с ней иначе.`,
    confirmLabel: "Снять",
    onConfirm: () => {
      setConfirm(null);
      run(() => (r.kind === "board"
        ? api.revokeBoardAccess(r.objectId, selected)
        : api.revokeTaskAccess(r.objectId, selected)), "Доступ снят");
    },
  });

  const addBoard = () => {
    if (!grant.boardId) return onError("Выберите проект");
    run(() => api.setBoardAccess(grant.boardId, selected, grant.role), "Доступ выдан")
      .then(() => setGrant({ boardId: "", role: "reader" }));
  };

  const copy = () => {
    if (!copyFrom) return onError("Выберите сотрудника, чей доступ скопировать");
    const from = resolveUser(directory, copyFrom);
    setConfirm({
      title: "Скопировать доступ?",
      message: `${person.fullName} получит доступ ко всем проектам, диаграммам, доскам и задачам, `
        + `к которым он есть у ${from.fullName}. Владение не копируется — вместо него роль «Редактор». `
        + "Имеющийся доступ не понизится.",
      confirmLabel: "Скопировать",
      danger: false,
      onConfirm: () => {
        setConfirm(null);
        run(async () => {
          const res = await api.adminCopyAccess(selected, copyFrom);
          onInfo(res.boards.length
            ? `Открыт доступ к проектам: ${res.boards.length}`
            : "Новых проектов нет — доступ уже был");
        }).then(() => setCopyFrom(""));
      },
    });
  };

  const memberOf = new Set(rows.filter((r) => r.kind === "board").map((r) => r.objectId));
  const addable = boards.filter((b) => !memberOf.has(b.id));

  // Функция levelTone предназначена для выбора тона капсулы уровня доступа: владелец — акцент, правка — второй акцент, чтение — нейтральный.
  const levelTone = (level) => {
    const c = level === "owner" ? theme.accent
      : level === "editor" || level === "contribute" ? theme.accent2
      : null;
    return c ? { background: `${c}1f`, color: c } : { background: theme.surfaceAlt, color: theme.textMuted };
  };

  const select = (value, options, labels, onChange, disabled) => (
    <select value={value} disabled={disabled || busy} onChange={(e) => onChange(e.target.value)}
      style={inputStyle(theme)} className="pl-3 pr-2 py-1.5 rounded-xl text-[13px] outline-none disabled:opacity-60">
      {options.map((o) => <option key={o} value={o}>{labels[o]}</option>)}
    </select>
  );

  const renderRow = (r) => {
    const place = r.boardTitle && r.kind !== "board" ? r.boardTitle : null;
    const clickable = (r.kind === "task_grant" || r.kind === "task_assignee") && onOpenTask;
    return (
      <div key={`${r.kind}:${r.objectId}`}
        style={{ borderColor: theme.border }}
        className="px-3 py-2 flex items-center gap-3 border-t first:border-t-0 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)]">
        <div className="min-w-0 flex-1">
          <button disabled={!clickable} onClick={() => clickable && onOpenTask(r.objectId, r.boardId)}
            style={{ color: theme.text }}
            className={`text-[14px] font-medium truncate block max-w-full text-left ${clickable ? "hover:underline underline-offset-2" : "cursor-default"}`}>
            {r.title}
          </button>
          {place && <div style={{ color: theme.textMuted }} className="text-[12px] truncate">{place}</div>}
        </div>

        {r.kind === "board" && (r.manageable && r.level !== "owner"
          ? select(r.level, EDITABLE_ROLES, ROLE_LABEL, (v) => setRole(r, v))
          : <span style={levelTone(r.level)} className="pill">{ROLE_LABEL[r.level] || r.level}</span>)}

        {r.kind === "task_grant" && (r.manageable
          ? select(r.level, ["read", "contribute"], GRANT_LABEL, (v) => setLevel(r, v))
          : <span style={levelTone(r.level)} className="pill">{GRANT_LABEL[r.level]}</span>)}

        {(r.kind === "chart" || r.kind === "whiteboard") && (
          <span style={levelTone(r.level)} className="pill">{ROLE_LABEL[r.level] || r.level}</span>)}
        {(r.kind === "delegation_from" || r.kind === "delegation_to") && (
          <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">{r.level}</span>)}

        {(r.kind === "board" || r.kind === "task_grant") && r.manageable && r.level !== "owner" && (
          <button disabled={busy} onClick={() => revoke(r)} title="Снять доступ"
            aria-label={`Снять доступ: ${r.title}`}
            className="btn-icon hover:!text-[var(--t-danger)] disabled:opacity-40">
            <Trash2 size={16} />
          </button>
        )}
      </div>
    );
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-4xl" padded={false} geometryKey="access">
      <div className="px-6 pt-5 pb-4">
        <ModalHeader theme={theme} title="Доступы"
          subtitle={isAdmin
            ? "Доступ сотрудников к проектам и задачам — во всей системе"
            : "Доступ сотрудников к вашим проектам и задачам"}
          onClose={onClose} />
      </div>

      <div style={{ borderColor: theme.border }} className="border-t flex min-h-[420px] max-h-[65vh]">
        {/* Блок: список людей */}
        <div style={{ borderColor: theme.border }} className="w-[272px] shrink-0 border-r flex flex-col">
          <div className="p-3 relative">
            <Search size={15} style={{ color: theme.textMuted }} className="absolute left-6 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Найти сотрудника"
              aria-label="Найти сотрудника"
              style={inputStyle(theme)} className="w-full pl-9 pr-3 py-2 rounded-full text-[14px] outline-none" />
          </div>
          <div className="overflow-y-auto px-2 pb-2">
            {people.map((u) => {
              const on = u.id === selected;
              return (
              <button key={u.id} onClick={() => setSelected(u.id)} aria-current={on ? "true" : undefined}
                style={on ? { background: theme.surfaceAlt, boxShadow: `0 0 0 1px ${theme.border}` } : undefined}
                className={`w-full flex items-center gap-2.5 px-2.5 py-2 mb-0.5 rounded-2xl text-left transition-colors duration-150 ${on ? "" : "hover:bg-[var(--t-surfaceAlt)]"}`}>
                <Avatar user={u} size={30} theme={theme} />
                <div className="min-w-0">
                  <div style={{ color: theme.text, fontWeight: on ? 600 : 500 }} className="text-[14px] leading-5 truncate">{u.fullName}</div>
                  {u.position && <div style={{ color: theme.textMuted }} className="text-[12px] truncate">{u.position}</div>}
                </div>
              </button>
              );
            })}
            {people.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-6">Никого не нашли</p>
            )}
          </div>
        </div>

        {/* Блок: доступы выбранного пользователя */}
        <div className="flex-1 min-w-0 overflow-y-auto p-5">
          {!person && (
            <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-16">
              Выберите сотрудника слева
            </p>
          )}

          {person && (
            <>
              <div className="flex items-center gap-3 mb-4">
                <Avatar user={person} size={44} theme={theme} />
                <div className="min-w-0">
                  <div style={{ color: theme.text }} className="text-[18px] leading-6 font-semibold truncate">{person.fullName}</div>
                  <div style={{ color: theme.textMuted }} className="text-[13px] truncate">{person.position || person.email}</div>
                </div>
              </div>

              {/* Блок: выдача доступа к проекту */}
              {addable.length > 0 && (
                <div className="flex items-center gap-2 mb-2.5 flex-wrap">
                  <select value={grant.boardId} onChange={(e) => setGrant((g) => ({ ...g, boardId: e.target.value }))}
                    aria-label="Проект"
                    style={inputStyle(theme)} className="flex-1 min-w-[180px] pl-3 pr-2 py-1.5 rounded-xl text-[13px] outline-none">
                    <option value="">Выдать доступ к проекту…</option>
                    {addable.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}
                  </select>
                  {select(grant.role, EDITABLE_ROLES, ROLE_LABEL, (v) => setGrant((g) => ({ ...g, role: v })))}
                  <button disabled={busy || !grant.boardId} onClick={addBoard}
                    style={{ opacity: grant.boardId ? 1 : 0.5 }}
                    className="btn-primary !py-1.5 !px-4 !text-[13px] disabled:cursor-default">
                    <Plus size={14} /> Выдать
                  </button>
                </div>
              )}

              {/* Блок: онбординг (только администратор) */}
              {isAdmin && (
                <div className="flex items-center gap-2 mb-5 flex-wrap">
                  <select value={copyFrom} onChange={(e) => setCopyFrom(e.target.value)}
                    aria-label="Доступ как у коллеги"
                    style={inputStyle(theme)} className="flex-1 min-w-[180px] pl-3 pr-2 py-1.5 rounded-xl text-[13px] outline-none">
                    <option value="">Доступ как у коллеги…</option>
                    {people.filter((u) => u.id !== selected).map((u) => (
                      <option key={u.id} value={u.id}>{u.fullName}</option>
                    ))}
                  </select>
                  <button disabled={busy || !copyFrom} onClick={copy}
                    style={{ opacity: copyFrom ? 1 : 0.5 }}
                    className="btn-pill !py-1.5 !px-4 !text-[13px] disabled:cursor-default">
                    <Copy size={14} /> Скопировать
                  </button>
                </div>
              )}

              {loading && <p style={{ color: theme.textMuted }} className="text-[13px] py-4">Загружаем…</p>}

              {!loading && rows.length === 0 && (
                <p style={{ color: theme.textMuted }} className="text-[13px] py-4">
                  {isAdmin
                    ? "Доступа ни к чему нет."
                    : "В ваших проектах и задачах доступа у этого сотрудника нет."}
                </p>
              )}

              {!loading && SECTIONS.map(([kind, label, Icon]) => {
                const list = rows.filter((r) => r.kind === kind);
                if (list.length === 0) return null;
                return (
                  <div key={kind} className="mb-4">
                    <div style={{ color: theme.textMuted }}
                      className="flex items-center gap-2 text-[12px] font-medium mb-1.5 px-1">
                      <Icon size={14} /> {label}
                      <span style={{ background: theme.surfaceAlt }} className="pill !px-1.5 !text-[11px] !leading-4 tabular-nums">{list.length}</span>
                    </div>
                    <div style={{ borderColor: theme.border }} className="border rounded-2xl overflow-hidden">
                      {list.map(renderRow)}
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>

      {confirm && (
        <ConfirmDialog theme={theme} title={confirm.title} message={confirm.message}
          confirmLabel={confirm.confirmLabel} danger={confirm.danger !== false}
          onConfirm={confirm.onConfirm} onCancel={() => setConfirm(null)} />
      )}
    </Modal>
  );
}
