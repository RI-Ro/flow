// Модуль предназначен для панели уведомлений: список, прочтение, переход к объекту, настройка категорий уведомлений.

import React, { useCallback, useEffect, useState } from "react";
import { Eye, EyeOff, ChevronLeft, ChevronRight, Settings, Check } from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { fmtRelative, fmtDateTime } from "../lib/theme.js";
import { useWindowGeometry } from "../lib/ui.jsx";

const PAGE_SIZE = 10;

// Категории уведомлений для персональной настройки.
const PREF_CATEGORIES = [
  ["assigned", "Назначение исполнителем"],
  ["granted", "Открыт доступ к задаче"],
  ["comment", "Новые комментарии"],
  ["step", "Изменения чек-листа"],
  ["task", "Изменения задачи"],
  ["reminder", "Напоминания"],
  ["other", "Прочее"],
  // Категория «задачи проекта, где пользователь не исполнитель» относится только к владельцам и редакторам проектов;
  // по своим задачам уведомления приходят всегда.
  ["foreign_task", "Задачи проекта, где я не исполнитель"],
];

// Компонент Notifications предназначен для панели уведомлений.
export default function Notifications({ theme, onCountChange, onSeen, onOpenTask }) {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [includeRead, setIncludeRead] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showPrefs, setShowPrefs] = useState(false);
  const [prefs, setPrefs] = useState({});

  useEffect(() => {
    api.notificationPrefs().then(setPrefs).catch(() => {});
  }, []);

  const togglePref = async (cat, enabled) => {
    setPrefs((p) => ({ ...p, [cat]: enabled }));
    try { await api.setNotificationPref(cat, enabled); }
    catch { setPrefs((p) => ({ ...p, [cat]: !enabled })); }
  };

  const load = useCallback(async (targetPage = page, read = includeRead) => {
    setLoading(true);
    try {
      const data = await api.notifications({ limit: PAGE_SIZE, offset: (targetPage - 1) * PAGE_SIZE, includeRead: read });
      setItems(data.items);
      setTotal(data.total);
      onCountChange(data.unread);
    } finally {
      setLoading(false);
    }
  }, [page, includeRead, onCountChange]);

  useEffect(() => { load(page, includeRead); }, [page, includeRead, load]);

  // Пока открыта первая страница непрочитанных, новое уведомление добавляется в список; счётчик на колокольчике обновляется в App.
  useEffect(() => {
    return onRealtimeMessage("notification", () => {
      if (page === 1) load(1, includeRead);
    });
  }, [page, includeRead, load]);

  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const markRead = async (n) => {
    if (!n.read) {
      // Прочтение снимает отметку «изменено» с задачи (0025). Ошибка отметки не блокирует переход.
      try {
        onSeen?.(await api.readNotification(n.id));
      } catch { /* отметку поставит само открытие задачи */ }
      load(page, includeRead);
    }
    // Переход выполняется по любому уведомлению с объектом (задача, диаграмма, доска, проект).
    if (n.taskId || n.chartId || n.whiteboardId || n.boardId) onOpenTask(n);
  };

  // «Прочитать» без перехода: для уведомлений, понятных без открытия карточки.
  const [dismissing, setDismissing] = useState(() => new Set());
  const dismiss = async (n) => {
    if (n.read || dismissing.has(n.id)) return;
    setDismissing((prev) => new Set(prev).add(n.id));
    try {
      onSeen?.(await api.readNotification(n.id));
    } catch {
      /* список перечитывается ниже: при неудаче строка вернётся */
    }
    setDismissing((prev) => { const next = new Set(prev); next.delete(n.id); return next; });
    // Если прочитано последнее уведомление на странице дальше первой, выполняется переход на предыдущую страницу.
    if (!includeRead && page > 1 && items.length === 1) {
      setPage(page - 1);
    } else {
      load(page, includeRead);
    }
  };

  const { boxRef, style: geoStyle, positioned, dragBar, resizeHandles } =
    useWindowGeometry(theme, "notifications");

  const markAll = async () => {
    onSeen?.(await api.readAllNotifications());
    setPage(1);
    load(1, includeRead);
  };

  // Строка уведомления: точка непрочитанного, текст, время. Кнопка «Прочитать» появляется при наведении и фокусе (доступна с клавиатуры).
  const readBtn = "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 focus-visible:opacity-100 [@media(hover:none)]:opacity-100";

  return (
    <div ref={boxRef}
      style={{
        boxShadow: theme.dark
          ? "0 1px 0 rgba(255,255,255,.05) inset, 0 28px 70px -20px rgba(0,0,0,.7)"
          : "0 28px 70px -24px rgba(30,30,60,.35), 0 2px 6px rgba(30,30,60,.06)",
        ...geoStyle,
      }}
      role="dialog" aria-label="Уведомления"
      className={`glass-pane fixed z-50 flex flex-col overflow-hidden ${positioned ? "" : "right-[14px] top-[72px] w-[min(calc(100vw-28px),460px)] max-h-[min(80vh,720px)]"}`}>
      {/* Панель перемещается и изменяет размер как окна (useWindowGeometry), без затемнения фона; геометрия хранится под своим ключом. */}
      {dragBar}
      <div className="flex items-center justify-between gap-2 pl-5 pr-3 pt-1 pb-2.5">
        <span style={{ color: theme.text }} className="text-[17px] font-semibold">Уведомления</span>
        <div className="flex items-center gap-0.5">
          <button onClick={() => setShowPrefs((v) => !v)} className="btn-icon"
            style={showPrefs ? { color: theme.accent, background: theme.surfaceAlt } : undefined}
            title="Настройки уведомлений" aria-label="Настройки уведомлений" aria-pressed={showPrefs}>
            <Settings size={16} />
          </button>
          <button onClick={() => { setPage(1); setIncludeRead((v) => !v); }} className="btn-icon"
            title={includeRead ? "Скрыть прочитанные" : "Показать прочитанные"}
            aria-label={includeRead ? "Скрыть прочитанные" : "Показать прочитанные"}>
            {includeRead ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
          <button onClick={markAll} className="btn-pill ml-1" style={{ padding: "5px 12px", fontSize: 12.5, color: theme.accent }}>
            Прочитать все
          </button>
        </div>
      </div>

      {showPrefs && (
        <div style={{ background: theme.surfaceAlt }} className="mx-3 mb-2 px-4 py-3 rounded-2xl">
          <div style={{ color: theme.textMuted }} className="text-[12.5px] font-medium mb-1.5">Какие уведомления получать</div>
          {PREF_CATEGORIES.map(([cat, label]) => {
            const enabled = prefs[cat] !== false;
            return (
              <label key={cat} className="flex items-center justify-between gap-3 py-1.5 cursor-pointer">
                <span style={{ color: theme.text }} className="text-[13.5px]">{label}</span>
                <button onClick={() => togglePref(cat, !enabled)}
                  role="switch" aria-checked={enabled} aria-label={label}
                  style={{ background: enabled ? theme.accent : theme.border }}
                  className="relative w-[38px] h-[22px] rounded-full transition-colors duration-150 shrink-0">
                  <span style={{ transform: enabled ? "translateX(18px)" : "translateX(2px)", boxShadow: "0 1px 3px rgba(0,0,0,.25)" }}
                    className="absolute top-[2px] left-0 w-[18px] h-[18px] rounded-full bg-white transition-transform duration-150" />
                </button>
              </label>
            );
          })}
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-2 pb-2">
        {loading && <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8">Загружаем…</p>}
        {!loading && items
          // В режиме «только непрочитанные» прочитанные скрываются сразу, в режиме «все» строка остаётся без выделения.
          .filter((n) => includeRead || !dismissing.has(n.id))
          .map((n) => (
          <div key={n.id}
            className="w-full rounded-2xl flex items-center gap-1 group transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)] focus-within:bg-[var(--t-surfaceAlt)]">
            <button onClick={() => markRead(n)}
              className="flex-1 min-w-0 text-left pl-3 pr-1 py-2.5 flex items-start gap-2.5 rounded-2xl"
              title={n.chartId ? "Открыть диаграмму"
                : n.whiteboardId ? "Открыть доску"
                : n.taskId ? "Открыть задачу"
                : n.boardId ? "Открыть проект" : undefined}>
              <span style={{ background: n.read ? "transparent" : theme.accent }}
                className="w-2 h-2 rounded-full mt-[6px] shrink-0" aria-label={n.read ? undefined : "Не прочитано"} />
              <span className="flex-1 min-w-0 break-words">
                <span style={{ color: n.read ? theme.textMuted : theme.text }}
                  className={`block text-[13.5px] leading-snug ${n.read ? "" : "font-medium"}`}>{n.body}</span>
                <span style={{ color: theme.textMuted }} className="block text-[12px] mt-1 tabular-nums" title={fmtDateTime(n.createdAt)}>{fmtRelative(n.createdAt)}</span>
              </span>
            </button>
            {!n.read && (
              <button onClick={() => dismiss(n)} disabled={dismissing.has(n.id)}
                style={{ color: theme.accent, background: theme.surface, border: `1px solid ${theme.border}` }}
                className={`shrink-0 mr-2 px-2.5 h-7 rounded-full text-[12px] font-medium flex items-center gap-1 transition-opacity duration-150 disabled:opacity-50 ${readBtn}`}
                title="Отметить прочитанным, не открывая задачу">
                <Check size={13} /> Прочитать
              </button>
            )}
          </div>
        ))}
        {!loading && items.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8 px-3 leading-relaxed">
            {includeRead ? (
              "Уведомлений нет."
            ) : (
              <>
                Непрочитанных нет.
                <button onClick={() => { setPage(1); setIncludeRead(true); }}
                  style={{ color: theme.accent }} className="block mx-auto mt-1.5 font-medium rounded-full px-2">
                  Показать прочитанные
                </button>
              </>
            )}
          </p>
        )}
      </div>

      {pages > 1 && (
        <div style={{ borderColor: theme.border }} className="flex items-center justify-between px-3 py-2 border-t">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} style={{ color: theme.textMuted, opacity: page === 1 ? 0.4 : 1 }} className="flex items-center gap-1 text-[12.5px] px-2.5 h-8 rounded-full hover:bg-[var(--t-surfaceAlt)] disabled:hover:bg-transparent">
            <ChevronLeft size={14} /> Назад
          </button>
          <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums">{page} из {pages}</span>
          <button onClick={() => setPage((p) => Math.min(pages, p + 1))} disabled={page === pages} style={{ color: theme.textMuted, opacity: page === pages ? 0.4 : 1 }} className="flex items-center gap-1 text-[12.5px] px-2.5 h-8 rounded-full hover:bg-[var(--t-surfaceAlt)] disabled:hover:bg-transparent">
            Далее <ChevronRight size={14} />
          </button>
        </div>
      )}
      {/* Ручки изменения размера панели. */}
      {resizeHandles}
    </div>
  );
}
