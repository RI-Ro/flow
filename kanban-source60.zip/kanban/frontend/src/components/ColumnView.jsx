// Модуль предназначен для окна развёрнутого просмотра колонки: список задач колонки с сортировкой.

import React, { useMemo, useState } from "react";
import { ArrowUpDown, CalendarDays, MessageSquare, Paperclip, CheckCircle2 } from "lucide-react";
import { PRIORITIES, fmtDate, resolveUser, dueColor, dueLevel, plural } from "../lib/theme.js";
import { Modal, ModalHeader, RecurMark } from "../lib/ui.jsx";
import { PriorityPill, AvatarStack, taskColorSolid, cardSurface } from "./Board.jsx";

// Порядок сортировки хранится в localStorage вместе с остальными настройками вида.
const SORT_KEY = "kanban.columnSort";

const SORTS = [
  { id: "position", label: "Как на доске" },
  { id: "due",      label: "По сроку" },
  { id: "priority", label: "По приоритету" },
  { id: "created",  label: "По дате создания" },
  { id: "title",    label: "По названию" },
];

// Компонент ColumnView предназначен для отображения задач колонки списком с сортировкой и открытием карточки.
export default function ColumnView({ theme, column, tasks, directory, onClose, onOpenTask }) {
  const [sort, setSort] = useState(() => localStorage.getItem(SORT_KEY) || "position");

  const setSortMode = (id) => {
    setSort(id);
    localStorage.setItem(SORT_KEY, id);
  };

  const sorted = useMemo(() => {
    const list = [...tasks];
    switch (sort) {
      case "due":
        // Задачи без срока размещаются в конце списка.
        return list.sort((a, b) => {
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return a.dueDate.localeCompare(b.dueDate);
        });
      case "priority":
        return list.sort((a, b) =>
          (PRIORITIES[b.priority]?.order || 0) - (PRIORITIES[a.priority]?.order || 0));
      case "created":
        return list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
      case "title":
        return list.sort((a, b) => a.title.localeCompare(b.title, "ru"));
      default:
        return list.sort((a, b) => a.position - b.position);
    }
  }, [tasks, sort]);

  const done = sorted.filter((t) => t.completedAt).length;
  const overdue = sorted.filter(
    (t) => !t.completedAt && t.dueDate && new Date(t.dueDate) < new Date(new Date().toDateString())
  ).length;

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-5xl" padded={false} geometryKey="column-view">
      {/* Список занимает всю оставшуюся высоту окна (h-full и flex). */}
      <div className="flex flex-col h-full">
      <div className="p-5 pb-3">
        <ModalHeader theme={theme} onClose={onClose}
          title={
            <span className="flex items-center gap-2">
              <span style={{ background: column.color }} className="w-2.5 h-2.5 rounded-full" />
              {column.title}
            </span>
          }
          subtitle={
            `${plural(sorted.length, "задача", "задачи", "задач")}` +
            (done ? ` · выполнено ${done}` : "") +
            (overdue ? ` · просрочено ${overdue}` : "")
          } />

        <div className="flex items-center gap-2 flex-wrap">
          <ArrowUpDown size={14} style={{ color: theme.textMuted }} aria-hidden />
          <div className="segmented" role="group" aria-label="Сортировка">
            {SORTS.map((s) => (
              <button key={s.id} onClick={() => setSortMode(s.id)} aria-pressed={sort === s.id}
                style={{ padding: "5px 12px" }}>
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ borderColor: theme.border }}
        className="border-t flex-1 min-h-0 overflow-y-auto px-4 pt-3 pb-6">
        {sorted.map((task) => {
          const assignees = task.assignees.map((id) => resolveUser(directory, id));
          const doneIds = task.assigneesDone || [];
          const completed = Boolean(task.completedAt);
          // Цвет срока используется только для близкого (менее недели) или прошедшего срока.
          const level = dueLevel(task.dueDate, completed);
          const tint = level && (level.id === "overdue" || level.id === "week1")
            ? dueColor(task.dueDate, completed, theme) : null;
          const mark = taskColorSolid(task.color, theme);

          return (
            <button key={task.id} onClick={() => onOpenTask(task.id)}
              style={{ opacity: completed ? 0.78 : 1 }}
              className="glass w-full px-3.5 py-2.5 mb-2 text-left flex items-center gap-3 transition-transform hover:-translate-y-px">
              {/* В развороте колонки реквизиты и сроки выводятся в одну строку без переносов и сокращений. */}
              <span className="shrink-0 w-[124px] flex">
                <PriorityPill priority={task.priority || "normal"} theme={theme} always />
              </span>

              <div className="min-w-0 flex-1">
                <div style={{
                  color: completed ? theme.textMuted : theme.text,
                  textDecoration: completed ? "line-through" : "none",
                }} className="text-[14px] font-medium truncate flex items-center gap-2">
                  {/* Пользовательский цвет задачи отображается точкой у названия. */}
                  {mark && <span style={{ background: mark }} className="w-2 h-2 rounded-full shrink-0" title="Цвет задачи" />}
                  {completed && <CheckCircle2 size={14} style={{ color: theme.success }} className="shrink-0" aria-label="Завершена" />}
                  <span className="truncate">{task.title}</span>
                </div>
                <div style={{ color: theme.textMuted }} className="text-[12px] truncate mt-0.5 tabular-nums">
                  {task.incomingNumber && `вх. № ${task.incomingNumber}${task.incomingDate ? ` от ${fmtDate(task.incomingDate)}` : ""} · `}
                  {task.steps?.length > 0 &&
                    `чек-лист ${task.steps.filter((s) => s.done).length}/${task.steps.length} · `}
                  {task.tags?.length > 0 && task.tags.map((t) => `#${t}`).join(" ")}
                </div>
              </div>

              <div className="shrink-0">
                <AvatarStack assignees={assignees} doneIds={doneIds} theme={theme} ring={cardSurface(theme)} max={4} />
              </div>

              <div style={{ color: theme.textMuted }}
                className="flex items-center gap-2.5 text-[12px] shrink-0 w-[150px] justify-end tabular-nums">
                <RecurMark task={task} theme={theme} size={13} />
                {task.commentCount > 0 && (
                  <span className="flex items-center gap-1"><MessageSquare size={13} />{task.commentCount}</span>
                )}
                {task.attachmentCount > 0 && (
                  <span className="flex items-center gap-1"><Paperclip size={13} />{task.attachmentCount}</span>
                )}
                {task.dueDate && (
                  <span className={`flex items-center gap-1 ${tint ? "font-semibold" : "font-medium"}`}
                    style={{ color: tint || theme.textMuted }}>
                    <CalendarDays size={13} />{fmtDate(task.dueDate)}
                  </span>
                )}
              </div>
            </button>
          );
        })}

        {sorted.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[14px] text-center py-12">
            В этой колонке задач нет.
          </p>
        )}
      </div>
      </div>
    </Modal>
  );
}
