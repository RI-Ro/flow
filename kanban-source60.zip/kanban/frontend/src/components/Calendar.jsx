// Модуль предназначен для вкладки «Календарь»: сетка месяца со сроками задач, перенос срока перетаскиванием,
// панель выбранного дня, создание задачи из календаря.

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Check, Plus } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, fmtDate, resolveUser, dueColor, taskColorFill, plural, orderedBoards, recurLabel } from "../lib/theme.js";
import { matchesFilters } from "../lib/filters.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { Avatar, Spinner, Modal, ModalHeader, Field, inputStyle, RecurMark } from "../lib/ui.jsx";

const WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

// Функция iso предназначена для получения даты в формате YYYY-MM-DD.
const iso = (d) => d.toISOString().slice(0, 10);

// Функция tint предназначена для получения мягкого тона цвета для подложек капсул (14–16 % цвета поверх фона).
const tint = (c, pct = 16) => `color-mix(in srgb, ${c} ${pct}%, transparent)`;
// Функция todayIso предназначена для получения сегодняшней даты в формате YYYY-MM-DD.
const todayIso = () => iso(new Date());

// Функция monthGrid предназначена для построения сетки месяца: начинается с понедельника и содержит целые недели.
function monthGrid(year, month) {
  const first = new Date(Date.UTC(year, month, 1));
  const shift = (first.getUTCDay() + 6) % 7; // понедельник = 0
  const start = new Date(first);
  start.setUTCDate(first.getUTCDate() - shift);

  const days = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(start);
    d.setUTCDate(start.getUTCDate() + i);
    days.push(d);
  }
  // Шестая строка удаляется, если целиком относится к соседнему месяцу.
  const lastWeek = days.slice(35);
  return lastWeek.every((d) => d.getUTCMonth() !== month) ? days.slice(0, 35) : days;
}

const CAL_PANEL_KEY = "kanban.calendar.panelWidth";

// Компонент Calendar предназначен для отображения задач по дням месяца.
export default function Calendar({ theme, directory, boards, currentUser, hideCompleted, filters, search, onTags, onError, onInfo, onOpenTask, onTaskCreated }) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [onlyMine, setOnlyMine] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(todayIso());
  const [creating, setCreating] = useState(null);
  // Состояние перетаскивания: drag — переносимая задача и исходный день, dragOver — клетка под курсором.
  const [drag, setDrag] = useState(null);
  // Ширина панели выбранного дня задаётся перетаскиванием разделителя и сохраняется.
  const [wide, setWide] = useState(() => window.matchMedia("(min-width: 1024px)").matches);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const on = () => setWide(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);

  const [panelW, setPanelW] = useState(() => {
    const saved = Number(localStorage.getItem(CAL_PANEL_KEY));
    return Number.isFinite(saved) && saved >= 240 ? saved : 340;
  });
  const [dragOver, setDragOver] = useState(null);

  const grid = useMemo(() => monthGrid(year, month), [year, month]);

  const load = useCallback(async () => {
    if (grid.length === 0) return;
    setLoading(true);
    try {
      const params = new URLSearchParams({
        from: iso(grid[0]),
        to: iso(grid[grid.length - 1]),
      });
      if (onlyMine) params.set("mine", "1");
      const data = await api.calendar(params.toString());
      setTasks(data.items || []);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [grid, onlyMine, onError]);

  useEffect(() => { load(); }, [load]);

  // Задачи раскладываются по клеткам по сроку (due_date); при изменении срока из карточки, с доски или другим пользователем
  // задача переносится в другую клетку.
  useEffect(() => {
    const off = onRealtimeMessage("task", () => load());
    return off;
  }, [load]);

  // Задачи группируются по дням за один проход; список тегов передаётся в общую панель отбора.
  useEffect(() => {
    onTags?.([...new Set(tasks.flatMap((t) => t.tags || []))].sort());
  }, [tasks, onTags]);

  const byDay = useMemo(() => {
    const map = new Map();
    for (const t of tasks) {
      if (hideCompleted && t.completed) continue;
      // Отбор совпадает с доской и «Всеми задачами»: приоритет, исполнитель, теги, диапазон срока, просроченные.
      if (filters && !matchesFilters(t, filters, search)) continue;
      if (!map.has(t.dueDate)) map.set(t.dueDate, []);
      map.get(t.dueDate).push(t);
    }
    return map;
  }, [tasks, hideCompleted, filters, search]);

  // Функция moveTask предназначена для переноса срока перетаскиванием: изменение срока — обычная правка задачи через общий маршрут.
  const moveTask = useCallback(async (task, dayIso) => {
    if (!task || task.dueDate === dayIso) return;
    // Право правки проверяет и сервер; перетаскивание недоступных для правки задач блокируется заранее.
    if (task.access !== "edit") {
      onError("Срок этой задачи менять нельзя — у вас доступ только на просмотр или участие");
      return;
    }
    const prev = task.dueDate;
    // Перенос отображается сразу, не дожидаясь ответа сервера.
    setTasks((list) => list.map((t) => (t.id === task.id ? { ...t, dueDate: dayIso } : t)));
    setSelected(dayIso);
    try {
      await api.updateTask(task.id, { dueDate: dayIso });
      onInfo(`Срок задачи «${task.title}» перенесён на ${fmtDate(dayIso)}`);
    } catch (e) {
      setTasks((list) => list.map((t) => (t.id === task.id ? { ...t, dueDate: prev } : t)));
      onError(e.message);
    }
  }, [onError, onInfo]);

  const dropOn = useCallback((dayIso) => {
    setDragOver(null);
    const d = drag;
    setDrag(null);
    if (!d) return;
    const task = tasks.find((t) => t.id === d.id);
    moveTask(task, dayIso);
  }, [drag, tasks, moveTask]);

  const shift = (delta) => {
    const d = new Date(Date.UTC(year, month + delta, 1));
    setYear(d.getUTCFullYear());
    setMonth(d.getUTCMonth());
  };

  const goToday = () => {
    const d = new Date();
    setYear(d.getFullYear());
    setMonth(d.getMonth());
    setSelected(todayIso());
  };

  const selectedTasks = byDay.get(selected) || [];

  // Список исполнителей для фильтра: все исполнители задач месяца; выбранный остаётся в списке при смене месяца.


  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      {/* Блок: управление */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        {/* Навигация одной капсулой: ‹ Сегодня ›. */}
        <div className="segmented items-center" style={{ padding: 3 }}>
          <button onClick={() => shift(-1)} title="Предыдущий месяц" aria-label="Предыдущий месяц"
            className="btn-icon" style={{ width: 32, height: 32, padding: 0 }}>
            <ChevronLeft size={16} />
          </button>
          <button onClick={goToday} className="hover:text-[var(--t-text)]"
            style={{ color: theme.text }}>
            Сегодня
          </button>
          <button onClick={() => shift(1)} title="Следующий месяц" aria-label="Следующий месяц"
            className="btn-icon" style={{ width: 32, height: 32, padding: 0 }}>
            <ChevronRight size={16} />
          </button>
        </div>

        <h2 style={{ color: theme.text }}
          className="text-[20px] leading-7 font-semibold tracking-[-0.01em] min-w-[170px] tabular-nums">
          {MONTHS[month]} {year}
        </h2>

        <button onClick={() => setOnlyMine((v) => !v)} aria-pressed={onlyMine}
          className="btn-pill"
          style={onlyMine ? {
            background: tint(theme.accent, 16), color: theme.accent,
            borderColor: tint(theme.accent, 40),
          } : undefined}>
          Только мои
        </button>

        {/* Остальные условия отбора находятся в общей панели «Фильтры» в шапке. */}

        <span className="text-[13px] ml-auto tabular-nums" style={{ color: theme.textMuted }}
          title="Задачу можно перетащить на другой день — срок изменится">
          {loading ? "Загрузка…" : `${plural(tasks.length, "задача", "задачи", "задач")} со сроком`}
        </span>
      </div>

      <div className="flex gap-3 items-start flex-col lg:flex-row">
        {/* Блок: сетка месяца */}
        <div className="glass-pane p-3 flex-1 w-full min-w-0">
          <div className="grid grid-cols-7 gap-1.5 mb-1.5">
            {WEEKDAYS.map((w) => (
              <div key={w} className="text-[12px] font-medium px-2.5 py-1"
                style={{ color: theme.textMuted }}>
                {w}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {grid.map((d) => {
              const key = iso(d);
              const dayTasks = byDay.get(key) || [];
              const isCurrentMonth = d.getUTCMonth() === month;
              const isToday = key === todayIso();
              const isSelected = key === selected;
              const isWeekend = [0, 6].includes(d.getUTCDay());
              const overdue = dayTasks.filter((t) => !t.completed && key < todayIso()).length;
              const ring = dragOver === key || isSelected;

              return (
                <button key={key} onClick={() => setSelected(key)}
                  // Клетка принимает задачу: onDragOver с preventDefault необходим для разрешения сброса.
                  onDragOver={(e) => {
                    if (!drag) return;
                    e.preventDefault();
                    if (dragOver !== key) setDragOver(key);
                  }}
                  onDragLeave={() => setDragOver((v) => (v === key ? null : v))}
                  onDrop={(e) => { e.preventDefault(); dropOn(key); }}
                  aria-pressed={isSelected}
                  aria-label={`${d.getUTCDate()} ${MONTHS[d.getUTCMonth()].toLowerCase()}, задач: ${dayTasks.length}`}
                  style={{
                    background: dragOver === key ? tint(theme.accent, 14)
                      : isCurrentMonth ? theme.surfaceAlt : "transparent",
                    boxShadow: ring ? `inset 0 0 0 2px ${theme.accent}` : undefined,
                    opacity: isCurrentMonth ? 1 : 0.5,
                  }}
                  className="rounded-[12px] p-1.5 min-h-[96px] text-left flex flex-col gap-[3px] transition-[filter,box-shadow] duration-150 ease-out hover:brightness-[1.04]">
                  <div className="flex items-center justify-between gap-1 mb-0.5 pl-0.5">
                    <span style={isToday
                      ? { background: theme.accent, color: theme.accentText }
                      : { color: isWeekend ? theme.textMuted : theme.text }}
                      className={`text-[13px] tabular-nums inline-flex items-center justify-center rounded-full h-6 ${isToday ? "w-6 font-bold" : "font-semibold"}`}>
                      {d.getUTCDate()}
                    </span>
                    {dayTasks.length > 3 && (
                      <span className="text-[11px] font-medium tabular-nums pr-1"
                        style={{ color: overdue > 0 ? theme.danger : theme.textMuted }}>
                        +{dayTasks.length - 3}
                      </span>
                    )}
                  </div>

                  {/* В клетке отображаются три задачи, остальные сворачиваются в счётчик. */}
                  {dayTasks.slice(0, 3).map((t) => {
                    const fill = taskColorFill(t.color, theme);
                    const late = !t.completed && key < todayIso();
                    return (
                      <span key={t.id}
                        draggable={t.access === "edit"}
                        onDragStart={(e) => {
                          e.stopPropagation();
                          // setData необходим для начала перетаскивания в части браузеров.
                          e.dataTransfer.setData("text/plain", t.id);
                          e.dataTransfer.effectAllowed = "move";
                          setDrag({ id: t.id, from: key });
                        }}
                        onDragEnd={() => { setDrag(null); setDragOver(null); }}
                        // В клетке «↻» ставится перед названием, периодичность указана в подсказке.
                        title={[
                          t.title,
                          recurLabel(t) ? `повторяется ${recurLabel(t)}` : "",
                          t.access === "edit" ? "перетащите на другой день, чтобы перенести срок" : "",
                        ].filter(Boolean).join(" — ")}
                        style={{
                          background: fill || (theme.dark ? "rgba(255,255,255,.06)" : theme.surface),
                          color: theme.text,
                          textDecoration: t.completed ? "line-through" : "none",
                          opacity: drag?.id === t.id ? 0.35 : t.completed ? 0.6 : 1,
                          cursor: t.access === "edit" ? "grab" : "default",
                        }}
                        className="text-[11px] leading-[18px] font-medium pl-1.5 pr-1 rounded-[6px] flex items-center gap-1.5 min-w-0">
                        <span style={{ background: late ? theme.danger : theme[PRIORITIES[t.priority]?.color] || theme.textMuted }}
                          className="w-1.5 h-1.5 rounded-full shrink-0" />
                        <span className="truncate">{recurLabel(t) ? "↻ " : ""}{t.title}</span>
                      </span>
                    );
                  })}
                </button>
              );
            })}
          </div>
        </div>

        {/* Разделитель панели; отображается только на широких экранах. */}
        <div
          onPointerDown={(e) => {
            e.preventDefault();
            const startX = e.clientX;
            const base = panelW;
            const onMove = (ev) => {
              // Перетаскивание влево увеличивает панель, поэтому знак смещения обратный.
              const next = Math.min(720, Math.max(240, base - (ev.clientX - startX)));
              setPanelW(next);
            };
            const onUp = () => {
              window.removeEventListener("pointermove", onMove);
              window.removeEventListener("pointerup", onUp);
              setPanelW((w) => {
                localStorage.setItem(CAL_PANEL_KEY, String(w));
                return w;
              });
            };
            window.addEventListener("pointermove", onMove);
            window.addEventListener("pointerup", onUp);
          }}
          onDoubleClick={() => { setPanelW(340); localStorage.removeItem(CAL_PANEL_KEY); }}
          title="Потянуть, чтобы изменить ширину. Двойное нажатие — вернуть как было"
          style={{ cursor: "ew-resize" }}
          className="hidden lg:flex self-stretch w-2 shrink-0 items-center justify-center group">
          <span style={{ background: theme.border }}
            className="w-1 h-10 rounded-full transition-colors duration-150 group-hover:bg-[var(--t-textMuted)]" />
        </div>

        {/* Блок: выбранный день */}
        {/* Панель дня прокручивается самостоятельно, не смещая сетку месяца. */}
        <div style={{
            width: wide ? panelW : undefined,
            maxHeight: wide ? "calc(100vh - 190px)" : undefined }}
          className="glass-pane p-4 w-full lg:w-auto shrink-0 flex flex-col">
          <div className="flex items-start gap-3 mb-3 shrink-0">
            <div className="min-w-0 flex-1">
              <h3 style={{ color: theme.text }}
                className="text-[18px] leading-6 font-semibold tracking-[-0.01em] tabular-nums">
                {selected === todayIso() ? "Сегодня" : fmtDate(selected)}
              </h3>
              <p style={{ color: theme.textMuted }} className="text-[13px] leading-5 tabular-nums">
                {selected === todayIso() ? `${fmtDate(selected)} · ` : ""}
                {plural(selectedTasks.length, "задача", "задачи", "задач")}
              </p>
            </div>
            <button onClick={() => setCreating(selected)}
              className="btn-pill shrink-0" style={{ padding: "6px 14px", fontSize: 13 }}
              title="Задача на этот день">
              <Plus size={14} /> Задача
            </button>
          </div>

          <div className="flex-1 min-h-0 overflow-y-auto -mr-1 pr-1">
          {selectedTasks.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[13px] py-8 text-center">
              На этот день задач нет.
            </p>
          )}

          {selectedTasks.map((t) => {
            const tone = dueColor(t.dueDate, t.completed, theme);
            const assignees = t.assignees.map((id) => resolveUser(directory, id));
            const late = selected < todayIso();
            return (
              <button key={t.id} onClick={() => onOpenTask(t.id)}
                draggable={t.access === "edit"}
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/plain", t.id);
                  e.dataTransfer.effectAllowed = "move";
                  setDrag({ id: t.id, from: t.dueDate });
                }}
                onDragEnd={() => { setDrag(null); setDragOver(null); }}
                style={{
                  opacity: drag?.id === t.id ? 0.35 : 1,
                  cursor: t.access === "edit" ? "grab" : "pointer",
                }}
                className="glass w-full p-3 mb-2 text-left block transition-[filter] duration-150 ease-out hover:brightness-[1.04]">
                <div className="flex items-start gap-2 mb-1">
                  <span style={{ background: theme[PRIORITIES[t.priority]?.color] || theme.textMuted }}
                    title={PRIORITIES[t.priority]?.label}
                    className="w-2 h-2 rounded-full mt-[6px] shrink-0" />
                  <span style={{
                    color: theme.text,
                    textDecoration: t.completed ? "line-through" : "none",
                  }} className="text-[14px] font-semibold leading-5 min-w-0 flex-1">
                    {t.title}
                  </span>
                  {t.completed && <Check size={14} style={{ color: theme.success }} className="shrink-0 mt-0.5" />}
                  <RecurMark task={t} theme={theme} size={12} className="mt-1" />
                </div>

                <div style={{ color: theme.textMuted }} className="text-[12px] leading-4 truncate mb-2 pl-4">
                  {t.boardTitle}
                  {t.columnTitle ? ` · ${t.columnTitle}` : ""}
                  {t.incomingNumber ? ` · вх. № ${t.incomingNumber}${t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}` : ""}
                  {/* Счётчики обсуждения и вложений, как на карточке в проекте. */}
                  {t.commentCount ? ` · ${t.commentCount} комм.` : ""}
                  {t.attachmentCount ? ` · ${t.attachmentCount} файл.` : ""}
                  {recurLabel(t) ? ` · ${recurLabel(t)}` : ""}
                </div>

                <div className="flex items-center gap-2 pl-4">
                  {/* Автор задачи, как во «Входящих». */}
                  <span className="flex items-center gap-1.5 min-w-0 flex-1">
                    <Avatar user={resolveUser(directory, t.createdBy)} size={18} theme={theme} />
                    <span style={{ color: theme.textMuted }} className="text-[12px] truncate">
                      {resolveUser(directory, t.createdBy).fullName}
                    </span>
                  </span>
                  {/* Уровень доступа объясняет, почему задача недоступна для правки. */}
                  {t.access !== "edit" && (
                    <span className="pill shrink-0"
                      style={{ background: theme.surfaceAlt, color: theme.textMuted, padding: "0 8px", lineHeight: "18px" }}
                      title={t.access === "read"
                        ? "Доступ только на просмотр — правка недоступна"
                        : "Участие: комментарии и отметки, но не правка задачи"}>
                      {t.access === "read" ? "просмотр" : "участие"}
                    </span>
                  )}
                  {!t.completed && tone && late && (
                    <span className="pill shrink-0"
                      style={{ background: tint(tone, 16), color: tone, padding: "0 8px", lineHeight: "18px" }}>
                      просрочено
                    </span>
                  )}
                  {assignees.length > 0 && (
                    <span className="flex shrink-0">
                      {assignees.slice(0, 4).map((u, i) => (
                        <span key={`${u.id}-${i}`} className="inline-flex"
                          style={{ boxShadow: `0 0 0 2px ${theme.surfaceAlt}`, borderRadius: 999, lineHeight: 0, marginLeft: i ? -4 : 0 }}>
                          <Avatar user={u} size={22} theme={theme} />
                        </span>
                      ))}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
          </div>
        </div>
      </div>

      {creating && (
        <CalendarTaskForm theme={theme} directory={directory} boards={boards}
          dueDate={creating} onClose={() => setCreating(null)}
          onError={onError}
          onCreated={(task) => {
            setCreating(null);
            onInfo(`Задача «${task.title}» создана`);
            onTaskCreated?.(task);
            load();
          }} />
      )}
    </div>
  );
}

// Компонент CalendarTaskForm предназначен для создания задачи из календаря; проект и колонка выбираются в форме,
// так как календарь показывает все проекты.
function CalendarTaskForm({ theme, directory, boards, dueDate, onClose, onCreated, onError }) {
  const [boardId, setBoardId] = useState("");
  const [columns, setColumns] = useState([]);
  const [columnId, setColumnId] = useState("");
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("dated");
  const [busy, setBusy] = useState(false);

  // Доступны проекты с правом создания задач (владелец и редактор): для читателя сохранение отклонила бы политика RLS.
  const writable = boards.filter((b) => ["owner", "editor"].includes(b.myRole));

  useEffect(() => {
    if (!boardId) { setColumns([]); setColumnId(""); return; }
    let alive = true;
    api.columns(boardId)
      .then((cols) => {
        if (!alive) return;
        setColumns(cols);
        setColumnId(cols[0]?.id || "");
      })
      .catch((e) => onError(e.message));
    return () => { alive = false; };
  }, [boardId, onError]);

  const submit = async () => {
    if (!title.trim()) return onError("Укажите название задачи");
    if (!boardId || !columnId) return onError("Выберите проект и колонку");
    setBusy(true);
    try {
      const task = await api.createTask(boardId, {
        title: title.trim(), description: "", priority,
        color: "none", incomingNumber: "", incomingDate: null,
        columnId, dueDate, tags: [], assignees: [],
      });
      onCreated(task);
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="calendar-new-task">
      <ModalHeader theme={theme} title="Новая задача"
        subtitle={`Срок исполнения — ${fmtDate(dueDate)}`} onClose={onClose} />

      <Field label="Название" theme={theme}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} autoFocus
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="Новая задача" style={inputStyle(theme)}
          className="w-full rounded-[12px] px-3 py-2 text-[14px] outline-none" />
      </Field>

      <Field label="Проект" theme={theme}
        hint={writable.length === 0 ? "Нет проектов, где вы можете создавать задачи" : undefined}>
        <select value={boardId} onChange={(e) => setBoardId(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-[12px] px-2.5 py-2 text-[14px] outline-none">
          <option value="">— выберите —</option>
          {writable.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}
        </select>
      </Field>

      {columns.length > 0 && (
        <Field label="Колонка" theme={theme}>
          <div className="flex flex-wrap gap-1.5">
            {columns.map((c) => (
              <button key={c.id} onClick={() => setColumnId(c.id)}
                aria-pressed={columnId === c.id}
                style={{
                  background: columnId === c.id ? tint(theme.accent, 16) : theme.surfaceAlt,
                  color: columnId === c.id ? theme.accent : theme.text,
                  border: `1px solid ${columnId === c.id ? tint(theme.accent, 45) : theme.border}`,
                }}
                className="px-3 py-1.5 rounded-full text-[13px] font-medium transition-colors duration-150">
                {c.title}
              </button>
            ))}
          </div>
        </Field>
      )}

      <Field label="Приоритет" theme={theme}>
        <select value={priority} onChange={(e) => setPriority(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-[12px] px-2.5 py-2 text-[14px] outline-none">
          {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </Field>

      <button onClick={submit} disabled={busy || !boardId || !columnId}
        className="btn-primary w-full mt-1 disabled:opacity-40 disabled:pointer-events-none">
        {busy ? "Создаём…" : "Создать задачу"}
      </button>
    </Modal>
  );
}
