import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowUpDown, ArrowUp, ArrowDown, CheckCircle2, UserCheck, Globe, FileSpreadsheet, Printer, MessageSquare, Paperclip } from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { PRIORITIES, fmtDate, fmtDateTime, dueLevel, isUnseen, resolveUser } from "../lib/theme.js";
import { dayEndISO, dayStartISO, localDay } from "../lib/filters.js";
import { exportTasksToExcel } from "../lib/excel.js";
import { printTasksReport } from "../lib/taskPdf.js";
import { Avatar, RecurMark, Spinner } from "../lib/ui.jsx";

// Модуль предназначен для вкладки «Все задачи»: единый список всех доступных задач из всех проектов с фильтрами,
// сортировкой и постраничной навигацией. Строка показывает проект и колонку задачи; клик открывает карточку.
const SHOW_ALL_KEY = "kanban.allTasks.showAll";

// Функция tint предназначена для получения мягкого тона цвета для подложки капсулы.
const tint = (c, pct = 16) => `color-mix(in srgb, ${c} ${pct}%, transparent)`;

// Компонент AllTasks предназначен для списка всех доступных задач с отбором, сортировкой, выгрузкой и печатью.
export default function AllTasks({ theme, directory, boards, currentUser, hideCompleted, filters, search, onTags, readyOnly = false, onError, onInfo, onOpenTask, onOpenBoard }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState({ key: "updated", dir: "desc" });
  // По умолчанию отображаются только свои задачи (поставленные и порученные пользователю); все доступные по ролям — по кнопке,
  // состояние которой сохраняется.
  const [showAll, setShowAll] = useState(
    () => localStorage.getItem(SHOW_ALL_KEY) === "true");
  useEffect(() => { localStorage.setItem(SHOW_ALL_KEY, String(showAll)); }, [showAll]);

  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const PAGE = 50;

  // Запрос формируется из условий фильтра и передаётся на сервер: отбор, сортировка и страница вычисляются на сервере.
  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (search.trim()) p.set("q", search.trim());
    if (filters?.boardId) p.set("boardId", filters.boardId);
    if (filters?.priority?.size) p.set("priority", [...filters.priority].join(","));
    if (filters?.assignee?.size) p.set("assignee", [...filters.assignee].join(","));
    if (filters?.tag?.size) p.set("tag", [...filters.tag].join(","));
    if (filters?.dueFrom) p.set("dueFrom", filters.dueFrom);
    if (filters?.dueTo) p.set("dueTo", filters.dueTo);
    // Диапазон дат завершения передаётся моментами (местные полночи, см. dayStartISO и dayEndISO): сервер не знает часовой пояс пользователя.
    if (filters?.doneFrom) p.set("completedFrom", dayStartISO(filters.doneFrom));
    if (filters?.doneTo) p.set("completedTo", dayEndISO(filters.doneTo));
    const byDoneDate = Boolean(filters?.doneFrom || filters?.doneTo);
    // Раздел «Готовы к сдаче» использует тот же запрос с другим условием статуса.
    p.set("status", readyOnly ? "ready" : (filters?.status || "all"));
    // «Скрыть завершённые» не действует при заданном диапазоне дат завершения или явном статусе.
    if (hideCompleted && !readyOnly && !byDoneDate && (filters?.status || "all") === "all") {
      p.set("status", "active");
    }
    p.set("scope", showAll ? "all" : "mine");
    p.set("sort", sort.key);
    p.set("dir", sort.dir);
    p.set("limit", String(PAGE));
    p.set("offset", String(page * PAGE));
    return p.toString();
  }, [search, filters, showAll, sort, page, readyOnly, hideCompleted]);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.allTasks(query);
      setTasks(res.items || []);
      setTotal(res.total || 0);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [query]);

  // Смена условий возвращает на первую страницу.
  useEffect(() => { setPage(0); }, [search, filters, showAll, readyOnly, sort]);

  // Функция reload предназначена для тихого обновления списка без индикатора загрузки (вызывается по событиям).
  const reload = useCallback(async () => {
    try {
      const res = await api.allTasks(query);
      setTasks(res.items || []);
      setTotal(res.total || 0);
      return;
    } catch {
      /* при временной ошибке сети список сохраняется до следующего события */
    }
  }, [query]);

  // Кандидаты для фильтра по исполнителю — все исполнители загруженных задач. События задач слушаются в этом компоненте самостоятельно.
  useEffect(() => onRealtimeMessage("seen", (e) => {
    const seen = new Map((e.payload?.items || [])
      .filter((i) => i.kind === "task").map((i) => [i.id, i.viewedAt]));
    if (seen.size) setTasks((prev) => prev.map((t) => (seen.has(t.id) ? { ...t, seenAt: seen.get(t.id) } : t)));
  }), []);

  useEffect(() => {
    const off = onRealtimeMessage("task", (e) => {
      const id = e.payload?.id;
      if (!id) return;
      if (e.action === "deleted") {
        setTasks((prev) => prev.filter((t) => t.id !== id));
        return;
      }
      // Задача, которой нет в списке, обычно появилась из-за нового назначения: она добавляется сразу, без перезагрузки.
      const fitsView = () => {
        const t = e.payload;
        if (readyOnly) return Boolean(t.readyAt) && !t.completedAt;
        const status = filters?.status || "all";
        if (status === "active" && t.completedAt) return false;
        if (status === "done" && !t.completedAt) return false;
        const byDoneDate = Boolean(filters?.doneFrom || filters?.doneTo);
        if (hideCompleted && !byDoneDate && status === "all" && t.completedAt) return false;
        if (byDoneDate) {
          const day = localDay(t.completedAt);
          if (!day) return false;
          if (filters.doneFrom && day < filters.doneFrom) return false;
          if (filters.doneTo && day > filters.doneTo) return false;
        }
        return true;
      };

      setTasks((prev) => {
        const known = prev.some((t) => t.id === id);
        if (!fitsView()) {
          // Задача удаляется из списка сразу, затем страница перечитывается: на её место поднимается следующая задача, счётчик уменьшается.
          if (known) reload();
          return known ? prev.filter((t) => t.id !== id) : prev;
        }
        if (!known) {
          reload();
          return prev;
        }
        // Известная задача обновляется на месте без перезапроса всего списка.
        return prev.map((t) => (t.id === id ? { ...t, ...e.payload, seenAt: t.seenAt } : t));
      });
    });
    return off;
  }, [reload, readyOnly, filters, hideCompleted]);

  // Теги вкладки передаются в общую панель отбора, которая находится в App.
  useEffect(() => {
    onTags?.([...new Set(tasks.flatMap((t) => t.tags || []))].sort());
  }, [tasks, onTags]);

  // Список приходит отобранным и отсортированным сервером; сортировка по столбцам также выполняется на сервере.
  const filtered = tasks;

  const toggleSort = (key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));


  const th = (key, label) => {
    const active = sort.key === key;
    const Arrow = !active ? ArrowUpDown : sort.dir === "asc" ? ArrowUp : ArrowDown;
    return (
      <button onClick={() => toggleSort(key)}
        style={{ color: active ? theme.text : theme.textMuted }}
        aria-label={`Сортировать: ${label}`}
        className="flex items-center gap-1 text-[12px] font-medium min-w-0 rounded-md transition-colors duration-150 hover:text-[var(--t-text)]">
        <span className="truncate">{label}</span>
        <Arrow size={12} className="shrink-0" style={{ opacity: active ? 0.9 : 0.35 }} />
      </button>
    );
  };

  // Сетка столбцов общая для шапки и строк (ширины в пикселях).
  const cols = "grid grid-cols-[minmax(0,1fr)_200px_170px_120px_120px_92px_92px] gap-3";

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {/* Поиск и отбор находятся в шапке приложения; здесь — переключатель «мои / все» и счётчик показанных задач. */}
        <span className="text-[13px] tabular-nums mr-auto" style={{ color: theme.textMuted }}>
          {loading ? "Загрузка…" : `Показано ${filtered.length} из ${total}`}
        </span>

        {/* Выгрузка и печать выполняются по отфильтрованному списку, как на экране. */}
        <button
          onClick={() => {
            const n = exportTasksToExcel(filtered, {
              directory, boardTitle: showAll ? "Все задачи" : "Мои задачи",
            });
            onInfo?.(`Выгружено задач: ${n}`);
          }}
          className="btn-pill shrink-0"
          title="Выгрузить показанные задачи в Excel">
          <FileSpreadsheet size={15} /> Excel
        </button>

        <button
          onClick={() => printTasksReport(filtered, directory, {
            title: showAll ? "Все задачи" : "Мои задачи",
          })}
          className="btn-pill shrink-0"
          title="Печать отчёта по показанным задачам (сгруппирован по проектам)">
          <Printer size={15} /> Печать
        </button>

        <button onClick={() => setShowAll((v) => !v)}
          aria-pressed={showAll}
          // Ширина кнопки фиксирована, чтобы она не меняла размер при переключении подписи.
          className="btn-pill w-[148px] shrink-0"
          title={showAll
            ? "Сейчас показаны все доступные задачи. Нажмите, чтобы оставить только свои"
            : "Сейчас показаны только мои задачи (поставленные мной и порученные мне). Нажмите, чтобы показать все доступные"}>
          {showAll ? <Globe size={15} /> : <UserCheck size={15} />}
          {showAll ? "Все задачи" : "Только мои"}
        </button>
      </div>

      {loading ? (
        <Spinner theme={theme} label="Загружаем задачи…" />
      ) : (
        <div className="glass-pane overflow-hidden">
          <div className="overflow-x-auto">
          <div className="min-w-[960px]">
          {/* Ширины столбцов заданы в пикселях, а не долями, чтобы длинное название не смещало соседние столбцы. */}
          <div style={{ borderColor: theme.border }}
            className={`${cols} px-5 pt-4 pb-2.5 border-b`}>
            {th("title", "Задача")}
            {th("board", "Проект / колонка")}
            {th("author", "Автор")}
            {th("priority", "Приоритет")}
            <div className="text-[12px] font-medium" style={{ color: theme.textMuted }}>Исполнители</div>
            {th("due", "Срок")}
            {th("completed", "Завершена")}
          </div>

          {filtered.length === 0 && (
            <div style={{ color: theme.textMuted }} className="px-5 py-12 text-center text-[14px]">
              Задач по заданным условиям не найдено.
              {!showAll && (
                <>
                  {" "}
                  <button onClick={() => setShowAll(true)} style={{ color: theme.accent }}
                    className="font-medium hover:underline">
                    Показать все доступные
                  </button>
                </>
              )}
            </div>
          )}

          {filtered.map((t, idx) => {
            const pr = PRIORITIES[t.priority] || PRIORITIES.normal;
            const level = dueLevel(t.dueDate, Boolean(t.completedAt));
            // Срок окрашивается только при просрочке или остатке менее недели.
            const dueTone = level?.id === "overdue" ? theme.danger
              : level?.id === "week1" ? theme.warning : null;
            const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
            const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
            const unseen = isUnseen(t);
            // Приоритет выделяется тоном только при значении выше обычного.
            const loud = ["prompt", "urgent", "very_urgent"].includes(t.priority);
            const prColor = theme[pr.color] || theme.textMuted;
            return (
              <div key={t.id}
                onClick={() => {
                  // Выделение снимается сразу: отметка просмотра передаётся на сервер при открытии карточки, а список о ней не узнаёт.
                  setTasks((prev) => prev.map((x) =>
                    (x.id === t.id ? { ...x, seenAt: new Date().toISOString() } : x)));
                  onOpenTask(t.id);
                }}
                onKeyDown={(e) => {
                  if (e.target !== e.currentTarget) return;
                  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.currentTarget.click(); }
                }}
                role="button" tabIndex={0}
                style={{ borderColor: theme.border }}
                className={`${cols} w-full px-5 py-2.5 text-left items-center cursor-pointer transition-colors duration-150 ease-out hover:bg-[var(--t-surfaceAlt)] ${idx < filtered.length - 1 ? "border-b" : ""}`}>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {/* Непросмотренное: синяя точка и полужирное название, как на карточках доски. */}
                    {unseen && (
                      <span style={{ background: theme.accent }}
                        className="w-2 h-2 rounded-full shrink-0"
                        title="Изменилось с вашего последнего просмотра" />
                    )}
                    {t.completedAt && <CheckCircle2 size={14} style={{ color: theme.success }} className="shrink-0" />}
                    <span style={{
                        color: theme.text,
                        textDecoration: t.completedAt ? "line-through" : "none",
                        opacity: t.completedAt ? 0.7 : 1,
                        fontWeight: unseen ? 650 : 500,
                      }} className="text-[14px] leading-5 truncate"
                      title={unseen ? "Изменилось с вашего последнего просмотра" : t.title}>
                      {t.title}
                    </span>
                    {/* Отметка готовности к сдаче расположена рядом с названием. */}
                    <RecurMark task={t} theme={theme} />
                    {t.readyAt && !t.completedAt && (
                      <span style={{ background: tint(theme.success, 16), color: theme.success }}
                        className="pill shrink-0" >
                        готова к сдаче
                      </span>
                    )}
                    {/* Счётчики обсуждения и вложений, как на карточке в проекте. */}
                    {t.commentCount > 0 && (
                      <span style={{ color: theme.textMuted }}
                        className="text-[12px] tabular-nums flex items-center gap-1 shrink-0"
                        title={`Комментариев: ${t.commentCount}`}>
                        <MessageSquare size={12} />{t.commentCount}
                      </span>
                    )}
                    {t.attachmentCount > 0 && (
                      <span style={{ color: theme.textMuted }}
                        className="text-[12px] tabular-nums flex items-center gap-1 shrink-0"
                        title={`Файлов: ${t.attachmentCount}`}>
                        <Paperclip size={12} />{t.attachmentCount}
                      </span>
                    )}
                  </div>
                  {t.incomingNumber && (
                    <div style={{ color: theme.textMuted }} className="text-[12px] truncate tabular-nums mt-0.5"
                      title="Входящий номер">
                      вх. <span className="mono">{t.incomingNumber}</span>{t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}
                    </div>
                  )}
                </div>

                <div className="min-w-0" onClick={(e) => { e.stopPropagation(); onOpenBoard(t.boardId); }} title="Перейти в проект">
                  <span style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
                    className="pill max-w-full transition-colors duration-150 hover:border-[var(--t-accent)]">
                    <span style={{ background: theme.accent }} className="w-1.5 h-1.5 rounded-full shrink-0" />
                    <span className="truncate">{t.boardTitle}</span>
                  </span>
                  <div style={{ color: theme.textMuted }} className="text-[12px] truncate mt-0.5 pl-2.5">{t.columnTitle}</div>
                </div>

                <div className="flex items-center gap-2 min-w-0">
                  {author && !author.deleted ? (
                    <>
                      <Avatar user={author} size={22} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[13px] truncate">{author.fullName}</span>
                    </>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[13px]">—</span>
                  )}
                </div>

                <div className="min-w-0">
                  <span className="pill max-w-full"
                    style={loud
                      ? { background: tint(prColor, 16), color: prColor }
                      : { background: theme.surfaceAlt, color: theme.textMuted }}>
                    <span className="truncate">{pr.label}</span>
                  </span>
                </div>

                <div className="flex items-center">
                  {assignees.slice(0, 4).map((u, i) => (
                    <span key={i} className="inline-flex"
                      style={{ boxShadow: `0 0 0 2px ${theme.surface}`, borderRadius: 999, lineHeight: 0, marginLeft: i ? -5 : 0 }}>
                      <Avatar user={u} size={24} theme={theme} />
                    </span>
                  ))}
                  {assignees.length > 4 && (
                    <span style={{ color: theme.textMuted }} className="text-[12px] tabular-nums pl-1.5">+{assignees.length - 4}</span>
                  )}
                  {assignees.length === 0 && <span style={{ color: theme.textMuted }} className="text-[13px]">—</span>}
                </div>

                <div style={{ color: dueTone || theme.textMuted, fontWeight: dueTone ? 600 : 400 }}
                  className="text-[13px] tabular-nums whitespace-nowrap"
                  title={level ? level.label : undefined}>
                  {t.dueDate ? fmtDate(t.dueDate) : "—"}
                </div>

                <div style={{ color: theme.textMuted }}
                  className="text-[13px] tabular-nums whitespace-nowrap"
                  title={t.completedAt ? `Завершена ${fmtDateTime(t.completedAt)}` : "Не завершена"}>
                  {t.completedAt ? fmtDate(t.completedAt) : "—"}
                </div>
              </div>
            );
          })}
          </div>
          </div>
        </div>
      )}
      {/* Постраничная навигация кнопками: позволяет вернуться на ту же страницу и видеть остаток. */}
      {total > PAGE && (
        <div className="flex items-center justify-center gap-3 py-3">
          <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}
            className="btn-pill disabled:opacity-40 disabled:pointer-events-none">
            Назад
          </button>
          <span style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">
            {page * PAGE + 1}–{Math.min(total, (page + 1) * PAGE)} из {total}
          </span>
          <button onClick={() => setPage((p) => p + 1)}
            disabled={(page + 1) * PAGE >= total}
            className="btn-pill disabled:opacity-40 disabled:pointer-events-none">
            Вперёд
          </button>
        </div>
      )}

    </div>
  );
}
