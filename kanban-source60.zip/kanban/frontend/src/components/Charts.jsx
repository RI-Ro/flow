import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Plus, Trash2, Pencil, GanttChartSquare, Users as UsersIcon, X, Link2,
  Lock, Check, ArrowRight, Paperclip, Send, ChevronUp, ChevronDown,
  MessageSquare, Video, Mail, Download, Upload, ExternalLink, ChevronLeft, SlidersHorizontal,
} from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { copyText, fmtDate, fmtDateTime, fmtRelative, fmtSize, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, Spinner, inputStyle } from "../lib/ui.jsx";
import { downloadFile } from "./AuthImage.jsx";
import FilePreview from "./FilePreview.jsx";
import InviteMembers from "./InviteMembers.jsx";

// Модуль предназначен для диаграмм Ганта: список диаграмм, полотно с этапами (полосы, связи, вехи), окна этапа, настроек, участников.
// Записи диаграммы самостоятельны: у них своё название, даты и прогресс; с задачами приложения они связаны только необязательными ссылками.

// Масштабы: число пикселей в сутках и правила подписей шкалы.
const SCALES = {
  day:   { label: "День",   px: 34, step: 1 },
  week:  { label: "Неделя", px: 12, step: 7 },
  month: { label: "Месяц",  px: 4,  step: 30 },
};

const DAY = 24 * 60 * 60 * 1000;

// Функция ymd предназначена для получения строки YYYY-MM-DD из даты.
const ymd = (d) => {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};
// Функция parseDay предназначена для разбора строки YYYY-MM-DD как локальной полуночи: new Date("2026-05-01") трактуется как UTC.
const parseDay = (s) => {
  const [y, m, d] = String(s || "").split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
};
// Функция daysBetween предназначена для вычисления числа суток между двумя датами.
const daysBetween = (a, b) => Math.round((parseDay(b) - parseDay(a)) / DAY);
// Функция addDays предназначена для прибавления суток к дате.
const addDays = (s, n) => { const d = parseDay(s); d.setDate(d.getDate() + n); return ymd(d); };

// Предопределённые цвета полос (как у задач).
export const BAR_COLORS = [
  ["", "По умолчанию"],
  ["#2B4162", "Тёмно-синий"],
  ["#3D5A80", "Синий"],
  ["#4E7AA7", "Голубой"],
  ["#3E8EA8", "Лазурный"],
  ["#2A9D8F", "Бирюзовый"],
  ["#3F8F6B", "Изумрудный"],
  ["#5B8C5A", "Зелёный"],
  ["#7CA05A", "Оливковый"],
  ["#B5A642", "Горчичный"],
  ["#E9C46A", "Жёлтый"],
  ["#E8A33D", "Янтарный"],
  ["#E76F51", "Оранжевый"],
  ["#D0553F", "Кирпичный"],
  ["#C1666B", "Красный"],
  ["#A34A5E", "Бордовый"],
  ["#8E5572", "Сливовый"],
  ["#7768AE", "Сиреневый"],
  ["#5D5FA6", "Индиго"],
  ["#6C757D", "Серый"],
  ["#4A5259", "Графитовый"],
  ["#8C7B6B", "Коричневый"],
];

// Функция plural предназначена для склонения слова «день» в сводке над диаграммой.
function plural(n) {
  const ten = n % 10;
  const hundred = n % 100;
  if (ten === 1 && hundred !== 11) return "день";
  if (ten >= 2 && ten <= 4 && (hundred < 10 || hundred >= 20)) return "дня";
  return "дней";
}

const DEFAULT_SETTINGS = {
  scale: "week",
  showWeekends: true,
  showToday: true,
  showLinks: true,
  rowHeight: 34,
  barColor: "",
};

// Компонент Charts предназначен для списка диаграмм и открытия выбранной диаграммы.
export default function Charts({ theme, directory, team, currentUser, onError, onOpenTask, openId, onOpened }) {
  const [charts, setCharts] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.charts();
      setCharts(list);
      // Без выбранной диаграммы отображается список плиток.
      setActiveId((prev) => (prev && list.some((c) => c.id === prev) ? prev : null));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [onError]);

  useEffect(() => { load(); }, [load]);

  // Диаграмма, открытая по ссылке.
  useEffect(() => {
    if (!openId) return;
    if (charts.some((c) => c.id === openId)) {
      setActiveId(openId);
      onOpened?.();
    }
  }, [openId, charts, onOpened]);

  // Изменения самой диаграммы другими пользователями (название, настройки, состав) применяются без перезагрузки.
  useEffect(() => onRealtimeMessage("chart", () => { load(); }), [load]);

  const active = charts.find((c) => c.id === activeId) || null;

  const create = async (title) => {
    try {
      const ch = await api.createChart({ title, settings: DEFAULT_SETTINGS });
      setCharts((prev) => [...prev, ch]);
      setActiveId(ch.id);
      setCreating(false);
    } catch (e) { onError(e.message); }
  };

  if (loading) return <Spinner theme={theme} label="Загружаем диаграммы…" />;

  return (
    <div className="pb-6">
      {charts.length === 0 ? (
        <EmptyPanel theme={theme} icon={GanttChartSquare} title="Диаграмм пока нет"
          text="Создайте первую — на ней удобно показать этапы работ крупно, вместе со сроками и зависимостями."
          action="Новая диаграмма" onAction={() => setCreating(true)} />
      ) : active ? (
        <ChartView key={active.id} theme={theme} chart={active} directory={directory}
          team={team} currentUser={currentUser} onError={onError} onOpenTask={onOpenTask}
          onBack={() => setActiveId(null)}
          onChanged={load}
          onDeleted={() => { setActiveId(null); load(); }} />
      ) : (
        <>
          <div className="flex items-center gap-3 flex-wrap mb-4">
            <span style={{ color: theme.textMuted }} className="text-[14px] tabular-nums">
              {charts.length} {chartsWord(charts.length)}
            </span>
            <button onClick={() => setCreating(true)} className="btn-primary ml-auto">
              <Plus size={16} /> Новая диаграмма
            </button>
          </div>
          <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))" }}>
            {charts.map((ch) => (
              <ChartTile key={ch.id} theme={theme} chart={ch} directory={directory}
                onOpen={() => setActiveId(ch.id)} />
            ))}
          </div>
        </>
      )}

      {creating && (
        <NameModal theme={theme} title="Новая диаграмма" onClose={() => setCreating(false)} onSave={create} />
      )}
    </div>
  );
}

/* Раздел: общие элементы оформления. */

// Функция ruPlural предназначена для склонения существительного по числу («3 диаграммы», «5 диаграмм»).
export function ruPlural(n, one, few, many) {
  const ten = n % 10;
  const hundred = n % 100;
  if (ten === 1 && hundred !== 11) return one;
  if (ten >= 2 && ten <= 4 && (hundred < 10 || hundred >= 20)) return few;
  return many;
}
// Функция chartsWord предназначена для получения слова «диаграмма» в нужной форме.
const chartsWord = (n) => ruPlural(n, "диаграмма", "диаграммы", "диаграмм");

export const ROLE_LABEL = { owner: "Владелец", editor: "Редактор", reader: "Исполнитель" };

// Функция tint предназначена для получения полупрозрачного тона цвета (палитра #rrggbb или цвет темы).
export function tint(color, alpha) {
  const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(color || "").trim());
  if (!m) return `color-mix(in srgb, ${color} ${Math.round(alpha * 100)}%, transparent)`;
  let h = m[1];
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const n = parseInt(h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

// Кнопка удаления: круглая, краснеет при наведении.
export const DANGER_ICON = "btn-icon hover:!text-[var(--t-danger)] hover:!bg-[color-mix(in_srgb,var(--t-danger)_14%,transparent)]";

// Компонент EmptyPanel предназначен для отображения пустого состояния: пояснение и одна кнопка.
export function EmptyPanel({ theme, icon: Icon, title, text, action, onAction }) {
  return (
    <div className="glass-pane px-6 py-12 flex flex-col items-center text-center">
      <span style={{ background: tint(theme.accent, 0.14), color: theme.accent }}
        className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4">
        <Icon size={22} />
      </span>
      <h3 style={{ color: theme.text }} className="text-[18px] font-semibold mb-1.5">{title}</h3>
      <p style={{ color: theme.textMuted }} className="text-[14px] leading-relaxed max-w-md mb-5">{text}</p>
      {onAction && (
        <button onClick={onAction} className="btn-primary"><Plus size={16} /> {action}</button>
      )}
    </div>
  );
}

// Компонент AvatarStack предназначен для отображения участников стопкой аватаров.
export function AvatarStack({ theme, directory, members, max = 4 }) {
  const shown = members.slice(0, max);
  const rest = members.length - shown.length;
  return (
    <span className="flex items-center">
      {shown.map((m, i) => (
        <span key={m.userId} className="rounded-full" style={{
          marginLeft: i ? -6 : 0, boxShadow: `0 0 0 2px var(--t-surfaceAlt)`, display: "inline-flex",
        }}>
          <Avatar user={resolveUser(directory, m.userId)} size={24} theme={theme} />
        </span>
      ))}
      {rest > 0 && (
        <span style={{ color: theme.textMuted }} className="text-[12px] font-medium ml-1.5 tabular-nums">+{rest}</span>
      )}
    </span>
  );
}

// Компонент ChartTile предназначен для плитки диаграммы в списке (сроки и прогресс этапов в список не передаются).
function ChartTile({ theme, chart, directory, onOpen }) {
  const members = chart.members || [];
  const owner = members.find((m) => m.role === "owner");
  const ownerUser = owner ? resolveUser(directory, owner.userId) : null;
  return (
    <button data-chart-tile onClick={onOpen}
      className="glass p-4 text-left flex flex-col gap-3 min-w-0 transition-transform duration-150 ease-out hover:-translate-y-0.5">
      <div className="flex items-start gap-3 min-w-0 w-full">
        <span style={{ background: tint(theme.accent, 0.14), color: theme.accent }}
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
          <GanttChartSquare size={20} />
        </span>
        <div className="min-w-0 flex-1">
          <div style={{ color: theme.text }} className="text-[16px] font-semibold leading-snug truncate">
            {chart.title}
          </div>
          <span style={{ background: theme.surface, color: theme.textMuted }} className="pill mt-1">
            {ROLE_LABEL[chart.myRole] || "Участник"}
          </span>
        </div>
        <ArrowRight size={16} style={{ color: theme.textMuted }} className="shrink-0 mt-1" />
      </div>
      {chart.description ? (
        <p style={{ color: theme.textMuted }} className="text-[13px] leading-snug line-clamp-2">
          {chart.description}
        </p>
      ) : null}
      <div className="flex items-center gap-2 mt-auto pt-1 min-w-0 w-full">
        <AvatarStack theme={theme} directory={directory} members={members} />
        <span style={{ color: theme.textMuted }} className="text-[12px] truncate">
          {ownerUser ? ownerUser.fullName : ""}
        </span>
        <span style={{ color: theme.textMuted }} className="text-[12px] ml-auto shrink-0 tabular-nums">
          {members.length} {ruPlural(members.length, "участник", "участника", "участников")}
        </span>
      </div>
    </button>
  );
}

/* Раздел: одна диаграмма. */
/* Компонент ChartView предназначен для отображения и правки одной диаграммы. */

function ChartView({ theme, chart, directory, team, currentUser, onError, onOpenTask, onBack, onChanged, onDeleted }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);   // запись или "new"
  const [membersOpen, setMembersOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);

  const canEdit = ["owner", "editor"].includes(chart.myRole);
  const isOwner = chart.myRole === "owner";

  const settings = useMemo(
    () => ({ ...DEFAULT_SETTINGS, ...(chart.settings || {}) }), [chart.settings]);

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await api.chartItems(chart.id)); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  }, [chart.id, onError]);

  useEffect(() => { load(); }, [load]);

  // События правки записей приходят без содержимого, список перечитывается целиком.
  useEffect(() => onRealtimeMessage("chartItems", (e) => {
    if (e.payload?.chartId === chart.id) load();
  }), [chart.id, load]);

  const saveItem = async (payload, id) => {
    try {
      if (id) {
        await api.updateChartItem(chart.id, id, payload);
        // Сроки из формы подчиняются тому же правилу, что при перетаскивании: следующие этапы не начинаются раньше окончания предыдущих.
        if (payload.startsOn && payload.endsOn) {
          // Из формы заданы обе даты, поэтому сдвиг целиком не применяется.
          await applySchedule(id, payload.startsOn, payload.endsOn, { keepLength: false });
        }
      } else {
        await api.createChartItem(chart.id, payload);
      }
      setEditing(null);
      load();
    } catch (e) { onError(e.message); }
  };

  const removeItem = async (id) => {
    try { await api.deleteChartItem(chart.id, id); setItems((p) => p.filter((i) => i.id !== id)); }
    catch (e) { onError(e.message); }
  };

  // Функция cascade предназначена для пересчёта сроков с учётом связей: предшественник не может заканчиваться позже начала следующего этапа.
  const cascade = (changedId, startsOn, endsOn, { keepLength = true } = {}) => {
    const map = new Map(items.map((i) => [i.id, { ...i }]));
    const changed = new Map();

    const me = map.get(changedId);
    if (!me) return [];

    // Предшественники этапа.
    const predecessors = items.filter((i) => (i.next || []).includes(changedId));
    let earliestStart = "";
    for (const p of predecessors) {
      const limit = addDays(p.endsOn, 1);
      if (limit > earliestStart) earliestStart = limit;
    }

    let s0 = startsOn;
    let e0 = endsOn;
    if (earliestStart && s0 < earliestStart) {
      if (keepLength) {
        // Перенос целиком: обе даты сдвигаются, длительность сохраняется.
        const shift = daysBetween(s0, earliestStart);
        s0 = earliestStart;
        e0 = addDays(e0, shift);
      } else {
        // При смене начала этап укорачивается, но не заходит за окончание.
        s0 = earliestStart > e0 ? e0 : earliestStart;
      }
    }

    me.startsOn = s0;
    me.endsOn = e0;
    changed.set(changedId, me);

    const queue = [changedId];
    for (let guard = 0; queue.length && guard < 500; guard++) {
      const cur = map.get(queue.shift());
      for (const nextId of cur.next || []) {
        const nx = map.get(nextId);
        if (!nx) continue;
        const earliest = addDays(cur.endsOn, 1);
        if (nx.startsOn >= earliest) continue;
        const shift = daysBetween(nx.startsOn, earliest);
        nx.startsOn = addDays(nx.startsOn, shift);
        nx.endsOn = addDays(nx.endsOn, shift);
        changed.set(nx.id, nx);
        queue.push(nx.id);
      }
    }
    return [...changed.values()];
  };

  // Функция applySchedule предназначена для применения сроков: сначала на экране, затем отправка на сервер.
  const applySchedule = async (id, startsOn, endsOn, opts) => {
    const affected = cascade(id, startsOn, endsOn, opts);
    if (affected.length === 0) return;
    setItems((prev) => prev.map((i) => {
      const upd = affected.find((a) => a.id === i.id);
      return upd ? { ...i, startsOn: upd.startsOn, endsOn: upd.endsOn } : i;
    }));
    try {
      for (const a of affected) {
        await api.updateChartItem(chart.id, a.id, { startsOn: a.startsOn, endsOn: a.endsOn });
      }
    } catch (e) {
      onError(e.message);
    }
    load();
  };

  // Функция moveRow предназначена для изменения порядка строк: обмен местами с соседом.
  const moveRow = async (id, dir) => {
    const idx = items.findIndex((i) => i.id === id);
    const other = idx + (dir === "up" ? -1 : 1);
    if (idx === -1 || other < 0 || other >= items.length) return;
    const a = items[idx];
    const b = items[other];
    // Если позиции совпали (после массового переноса), порядок задаётся заново по списку.
    const next = [...items];
    next[idx] = b;
    next[other] = a;
    setItems(next);
    try {
      await Promise.all(next.map((it, i) =>
        (it.position === i ? null : api.updateChartItem(chart.id, it.id, { position: i }))));
    } catch (e) { onError(e.message); }
    load();
  };

  // Границы диаграммы: продолжительность считается по календарю от первого дня самого раннего этапа до последнего дня самого позднего.
  const span = useMemo(() => {
    if (items.length === 0) return null;
    let first = items[0];
    let last = items[0];
    for (const it of items) {
      if (it.startsOn < first.startsOn) first = it;
      if (it.endsOn > last.endsOn) last = it;
    }
    return { first, last, days: daysBetween(first.startsOn, last.endsOn) + 1 };
  }, [items]);

  const saveSettings = async (next) => {
    try { await api.updateChart(chart.id, { settings: next }); setSettingsOpen(false); onChanged(); }
    catch (e) { onError(e.message); }
  };

  return (
    <div>
      <div className="flex items-center gap-3 flex-wrap mb-4">
        <div className="flex items-center gap-2 min-w-0">
          <button onClick={onBack} className="btn-icon shrink-0"
            title="Все диаграммы" aria-label="Все диаграммы"><ChevronLeft size={20} /></button>
          <div className="min-w-0">
            <h2 style={{ color: theme.text }} className="text-[20px] font-semibold leading-tight truncate">
              {chart.title}
            </h2>
            <div style={{ color: theme.textMuted }} className="text-[13px] tabular-nums">
              {ROLE_LABEL[chart.myRole] || "Исполнитель"}
              {" · "}{items.length} {ruPlural(items.length, "этап", "этапа", "этапов")}
            </div>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2 flex-wrap">
          <button onClick={async () => {
            const url = `${window.location.origin}/charts/${chart.id}`;
            if (await copyText(url)) {
              setLinkCopied(true);
              setTimeout(() => setLinkCopied(false), 2000);
            } else {
              onError("Не удалось скопировать. Ссылка на диаграмму: " + url);
            }
          }}
            className="btn-pill"
            title="Скопировать ссылку на диаграмму">
            {linkCopied ? <Check size={15} /> : <Link2 size={15} />} {linkCopied ? "Скопировано" : "Ссылка"}
          </button>
          <button onClick={() => setInviteOpen(true)} className="btn-pill"
            title="Позвать участников: созвон, письмо, уведомление">
            <Video size={15} /> Собрать
          </button>
          <button onClick={() => setSettingsOpen(true)} className="btn-pill"
            title="Масштаб, выходные, связи, цвет полос">
            <SlidersHorizontal size={15} /> Вид
          </button>
          {canEdit && (
            <>
              <button onClick={() => setMembersOpen(true)} className="btn-pill">
                <UsersIcon size={15} /> Участники
              </button>
              <button onClick={() => setRenaming(true)} className="btn-icon"
                title="Переименовать" aria-label="Переименовать"><Pencil size={16} /></button>
            </>
          )}
          {isOwner && (
            <button onClick={() => setConfirmDelete(true)} className={DANGER_ICON}
              title="Удалить диаграмму" aria-label="Удалить диаграмму">
              <Trash2 size={16} />
            </button>
          )}
          {canEdit && (
            <button onClick={() => setEditing("new")} className="btn-primary">
              <Plus size={16} /> Запись
            </button>
          )}
        </div>
      </div>

      {/* Сводка по срокам: начало, окончание и общая продолжительность. */}
      {span && (
        <div className="flex flex-wrap items-stretch gap-2.5 mb-4">
          <div className="glass stat-pill max-w-[260px]">
            <span className="stat-label">Начало</span>
            <span className="stat-value">{fmtDate(span.first.startsOn)}</span>
            <span style={{ color: theme.textMuted }} className="text-[12px] truncate" title={span.first.title}>
              {span.first.title}
            </span>
          </div>
          <div className="glass stat-pill max-w-[260px]">
            <span className="stat-label">Окончание</span>
            <span className="stat-value">{fmtDate(span.last.endsOn)}</span>
            <span style={{ color: theme.textMuted }} className="text-[12px] truncate" title={span.last.title}>
              {span.last.title}
            </span>
          </div>
          <div className="glass stat-pill">
            <span className="stat-label">Продолжительность</span>
            <span className="stat-value">
              {span.days} <span style={{ color: theme.textMuted }} className="text-[14px] font-medium">{plural(span.days)}</span>
            </span>
          </div>
        </div>
      )}

      {loading ? (
        <Spinner theme={theme} label="Загружаем этапы…" />
      ) : items.length === 0 ? (
        <EmptyPanel theme={theme} icon={GanttChartSquare} title="Записей пока нет"
          text={canEdit ? "Добавьте первый этап работ — полосы, сроки и связи появятся здесь."
            : "Этапы появятся, когда их добавит владелец или редактор диаграммы."}
          action="Запись" onAction={canEdit ? () => setEditing("new") : null} />
      ) : (
        <Gantt theme={theme} items={items} settings={settings} canEdit={canEdit}
          onEdit={(it) => setEditing(it)} onOpenTask={onOpenTask}
          onSchedule={applySchedule} onMoveRow={moveRow} />
      )}

      {editing && (
        <ItemModal theme={theme} theItem={editing === "new" ? null : editing}
          items={items} chartId={chart.id} directory={directory} currentUser={currentUser}
          canEdit={canEdit} onClose={() => setEditing(null)}
          onSave={(payload) => saveItem(payload, editing === "new" ? null : editing.id)}
          onDelete={editing === "new" ? null : () => { removeItem(editing.id); setEditing(null); }}
          onError={onError} />
      )}

      {membersOpen && (
        <MembersModal theme={theme} directory={directory} team={team} currentUser={currentUser}
          members={chart.members || []} isOwner={isOwner}
          title={`Участники диаграммы «${chart.title}»`}
          onClose={() => setMembersOpen(false)}
          onSave={async (list) => {
            try { await api.setChartMembers(chart.id, list); setMembersOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {renaming && (
        <NameModal theme={theme} title="Название диаграммы" initial={chart.title}
          onClose={() => setRenaming(false)}
          onSave={async (title) => {
            try { await api.updateChart(chart.id, { title }); setRenaming(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {settingsOpen && (
        <SettingsModal theme={theme} settings={settings} canEdit={canEdit}
          onClose={() => setSettingsOpen(false)} onSave={saveSettings} />
      )}

      {inviteOpen && (
        <InviteMembers theme={theme} kind="chart" object={chart} directory={directory}
          currentUser={currentUser} onClose={() => setInviteOpen(false)} onError={onError} />
      )}

      {confirmDelete && (
        <Modal theme={theme} onClose={() => setConfirmDelete(false)} width="max-w-sm">
          <ModalHeader theme={theme} title="Удалить диаграмму?" onClose={() => setConfirmDelete(false)} />
          <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed mb-4">
            Диаграмма «{chart.title}» со всеми этапами, обсуждением и файлами исчезнет
            у всех участников. Отменить это нельзя.
          </p>
          <div className="flex gap-2">
            <button onClick={() => setConfirmDelete(false)}
              className="btn-pill flex-1">Отмена</button>
            <button onClick={async () => {
              try { await api.deleteChart(chart.id); onDeleted(); }
              catch (e) { onError(e.message); }
            }} style={{ background: theme.danger, color: "#fff" }}
              className="flex-1 rounded-full py-2 text-[14px] font-semibold transition-[filter] duration-150 hover:brightness-110">Удалить</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* Раздел: полотно. */
/* Компонент Gantt предназначен для отображения этапов полосами на временной шкале. */

function Gantt({ theme, items, settings, canEdit, onEdit, onOpenTask, onSchedule, onMoveRow }) {
  const scale = SCALES[settings.scale] || SCALES.week;
  const rowH = Number(settings.rowHeight) || 34;

  // Границы полотна: от самой ранней до самой поздней даты с полями по краям.
  const [from, to] = useMemo(() => {
    const starts = items.map((i) => i.startsOn).sort();
    const ends = items.map((i) => i.endsOn).sort();
    const a = addDays(starts[0] || ymd(new Date()), -3);
    const b = addDays(ends[ends.length - 1] || ymd(new Date()), 3);
    return [a, b];
  }, [items]);

  const totalDays = Math.max(1, daysBetween(from, to));
  const today = ymd(new Date());

  // Сетка занимает всю ширину панели.
  const paneRef = useRef(null);
  const [paneW, setPaneW] = useState(0);
  useEffect(() => {
    const el = paneRef.current;
    if (!el || typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver(([e]) => setPaneW(e.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const gridDays = Math.max(totalDays, Math.ceil(paneW / scale.px));
  const width = gridDays * scale.px;

  // Ширина подписи определяет, помещается ли она в полосу или выносится справа.
  const measure = useMemo(() => {
    let ctx = null;
    try { ctx = document.createElement("canvas").getContext("2d"); } catch { ctx = null; }
    return (text) => {
      if (!ctx) return text.length * 7;
      ctx.font = '500 12px "Inter Variable", system-ui, sans-serif';
      return ctx.measureText(text).width;
    };
  }, []);

  // Режимы перетаскивания мышью (изменяются только сроки): move — перенос полосы целиком (длительность сохраняется);
  // start — изменение начала; end — изменение окончания.
  const drag = useRef(null);
  const [dragState, setDragState] = useState(null); // { id, mode, days }

  // Функция startDrag предназначена для начала перетаскивания: обработчики мыши устанавливаются в момент нажатия.
  const startDrag = (e, item, mode) => {
    if (!canEdit) return;
    e.preventDefault();
    e.stopPropagation();

    const startX = e.clientX;
    drag.current = { id: item.id, item, x: startX, mode, days: 0 };
    setDragState({ id: item.id, mode, days: 0 });

    const move = (ev) => {
      const d = drag.current;
      if (!d) return;
      const days = Math.round((ev.clientX - d.x) / scale.px);
      if (days === d.days) return;      // тот же день — не перерисовываем
      d.days = days;
      setDragState({ id: d.id, mode: d.mode, days });
    };

    const up = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
      const d = drag.current;
      drag.current = null;
      setDragState(null);
      if (!d || d.days === 0) return;

      const it = d.item;
      if (d.mode === "move") {
        // Перенос целиком: длительность сохраняется.
        onSchedule(it.id, addDays(it.startsOn, d.days), addDays(it.endsOn, d.days),
          { keepLength: true });
      } else if (d.mode === "start") {
        // Начало не может быть позже окончания.
        const next = addDays(it.startsOn, d.days);
        onSchedule(it.id, next > it.endsOn ? it.endsOn : next, it.endsOn,
          { keepLength: false });
      } else {
        const next = addDays(it.endsOn, d.days);
        onSchedule(it.id, it.startsOn, next < it.startsOn ? it.startsOn : next,
          { keepLength: false });
      }
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  // Метки шкалы: для дневного масштаба — каждый день, недельного — понедельники, месячного — первые числа.
  const ticks = useMemo(() => {
    const out = [];
    for (let i = 0; i <= gridDays; i++) {
      const d = parseDay(addDays(from, i));
      const isMonthStart = d.getDate() === 1;
      const isWeekStart = d.getDay() === 1;
      const show = settings.scale === "day" || (settings.scale === "week" ? isWeekStart : isMonthStart);
      if (!show) continue;
      out.push({
        x: i * scale.px,
        label: settings.scale === "month"
          ? d.toLocaleDateString("ru-RU", { month: "short", year: "2-digit" })
          : d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" }),
        strong: isMonthStart,
      });
    }
    return out;
  }, [from, gridDays, scale.px, settings.scale]);

  const byId = useMemo(() => new Map(items.map((i, idx) => [i.id, idx])), [items]);
  const barColor = (it) => it.color || settings.barColor || theme.accent;

  // Функция posOf предназначена для определения положения полосы с учётом текущего перетаскивания.
  const posOf = (it, idx) => {
    const st = dragState && dragState.id === it.id ? dragState : null;
    let startDays = daysBetween(from, it.startsOn);
    let lenDays = Math.max(1, daysBetween(it.startsOn, it.endsOn) + 1);
    if (st) {
      if (st.mode === "move") startDays += st.days;
      else if (st.mode === "start") {
        const d = Math.min(st.days, lenDays - 1);
        startDays += d;
        lenDays -= d;
      } else {
        lenDays = Math.max(1, lenDays + st.days);
      }
    }
    return { left: startDays * scale.px, width: lenDays * scale.px, top: idx * rowH + 6 };
  };

  const HEAD = 36;
  const barH = rowH - 12;
  const todayX = daysBetween(from, today) * scale.px;
  const todayVisible = settings.showToday && today >= from && daysBetween(from, today) <= gridDays;
  // Тон и заливка прогресса; на светлой теме тон слабее.
  const toneA = theme.dark ? 0.26 : 0.18;
  const fillA = theme.dark ? 0.62 : 0.5;

  return (
    <div className="glass-pane overflow-hidden">
      <div className="flex">
        {/* Названия этапов — отдельная неподвижная колонка при прокрутке полотна. */}
        <div style={{ borderColor: theme.border }} className="shrink-0 border-r">
          <div style={{ height: HEAD, borderColor: theme.border }}
            className="border-b flex items-center px-4">
            <span style={{ color: theme.textMuted }} className="text-[12px] font-medium">Этап</span>
          </div>
          {items.map((it, idx) => (
            <div key={it.id} style={{ height: rowH, borderColor: theme.border, width: 280 }}
              className="border-b last:border-b-0 flex items-center pl-2 pr-3 gap-1.5 group">
              {/* Порядок строк: кнопки появляются при наведении. */}
              {canEdit && (
                <div className="flex flex-col opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity duration-150 shrink-0">
                  <button onClick={() => onMoveRow(it.id, "up")} disabled={idx === 0}
                    style={{ color: theme.textMuted }} className="disabled:opacity-25 leading-none"
                    title="Выше" aria-label="Выше"><ChevronUp size={12} /></button>
                  <button onClick={() => onMoveRow(it.id, "down")} disabled={idx === items.length - 1}
                    style={{ color: theme.textMuted }} className="disabled:opacity-25 leading-none"
                    title="Ниже" aria-label="Ниже"><ChevronDown size={12} /></button>
                </div>
              )}
              {/* Цвет этапа — точка у названия. */}
              <span style={{ background: barColor(it), borderRadius: it.milestone ? 2 : 999,
                transform: it.milestone ? "rotate(45deg)" : undefined }}
                className="w-2 h-2 shrink-0" aria-hidden />
              {/* Правка этапа открывается по названию (в области дней мышь занята изменением сроков). */}
              <button onClick={() => onEdit(it)}
                style={{ color: theme.text }}
                className="text-[13.5px] truncate flex-1 text-left hover:underline underline-offset-2"
                title={`${it.title} — открыть этап`}>
                {it.title}
              </button>
              {/* Значки обсуждения и файлов этапа. */}
              <span className="flex items-center gap-2 shrink-0 tabular-nums" style={{ color: theme.textMuted }}>
                {it.commentCount > 0 && (
                  <span className="flex items-center gap-0.5 text-[12px]"
                    title={`Замечаний: ${it.commentCount}`}>
                    <MessageSquare size={12} />{it.commentCount}
                  </span>
                )}
                {it.fileCount > 0 && (
                  <span className="flex items-center gap-0.5 text-[12px]"
                    title={`Файлов: ${it.fileCount}`}>
                    <Paperclip size={12} />{it.fileCount}
                  </span>
                )}
                {it.tasks?.length > 0 && (
                  <Link2 size={12} title={`Ссылок на задачи: ${it.tasks.length}`} />
                )}
              </span>
            </div>
          ))}
        </div>

        <div ref={paneRef} className="flex-1 min-w-0 overflow-x-auto">
          <div style={{ width, position: "relative" }}>
            {/* Шкала */}
            <div style={{ height: HEAD, borderColor: theme.border }}
              className="border-b relative">
              {ticks.map((t, i) => (
                <div key={i} style={{ left: t.x, color: t.strong ? theme.text : theme.textMuted }}
                  className={`absolute top-0 h-full flex items-center pl-1.5 text-[12px] whitespace-nowrap tabular-nums ${t.strong ? "font-medium" : ""}`}>
                  {t.label}
                </div>
              ))}
              {todayVisible && (
                <span style={{ left: todayX, background: theme.accent, color: theme.accentText }}
                  className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 rounded-full px-2 text-[11px] font-semibold leading-[18px] whitespace-nowrap"
                  title={`Сегодня, ${fmtDate(today)}`}>
                  сегодня
                </span>
              )}
            </div>

            <div style={{ height: items.length * rowH, position: "relative" }}>
              {/* Сетка и выходные */}
              {settings.showWeekends && scale.px >= 8 && Array.from({ length: gridDays + 1 }, (_, i) => {
                const d = parseDay(addDays(from, i));
                const weekend = d.getDay() === 0 || d.getDay() === 6;
                if (!weekend) return null;
                return (
                  <div key={i} style={{
                    left: i * scale.px, width: scale.px,
                    background: theme.dark ? "rgba(255,255,255,0.025)" : "rgba(0,0,0,0.025)",
                  }} className="absolute top-0 bottom-0" />
                );
              })}
              {ticks.map((t, i) => (
                <div key={`g${i}`} style={{ left: t.x, background: theme.border, opacity: t.strong ? 0.9 : 0.5 }}
                  className="absolute top-0 bottom-0 w-px" />
              ))}
              {/* Линии строк продолжают строки таблицы слева. */}
              {items.slice(0, -1).map((it, idx) => (
                <div key={`r${it.id}`} style={{ top: (idx + 1) * rowH - 1, background: theme.border, opacity: 0.5 }}
                  className="absolute left-0 right-0 h-px" />
              ))}
              {/* Прошедшее время — приглушённая заливка. */}
              {today > from && (
                <div style={{
                  left: 0,
                  width: Math.min(gridDays, Math.max(0, daysBetween(from, today))) * scale.px,
                  background: theme.dark ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.03)",
                }} className="absolute top-0 bottom-0" title="Уже прошло" />
              )}

              {todayVisible && (
                <div style={{ left: todayX - 1, width: 2, background: theme.accent, opacity: 0.85 }}
                  className="absolute top-0 bottom-0 pointer-events-none" title="Сегодня" />
              )}

              {/* Связи «за этой записью следует эта»: ломаная линия от правого края предшественника к левому краю следующего этапа. */}
              {settings.showLinks && (
                <svg width={width} height={items.length * rowH}
                  className="absolute inset-0 pointer-events-none">
                  {items.flatMap((it, idx) => (it.next || []).map((toId) => {
                    const j = byId.get(toId);
                    if (j === undefined) return null;
                    const a = posOf(it, idx);
                    const b = posOf(items[j], j);
                    const x1 = a.left + a.width;
                    const y1 = a.top + (rowH - 12) / 2;
                    const x2 = b.left;
                    const y2 = b.top + (rowH - 12) / 2;
                    const mx = Math.max(x1 + 8, x2 - 8);
                    return (
                      <g key={`${it.id}-${toId}`}>
                        <path d={`M ${x1} ${y1} H ${mx} V ${y2} H ${x2}`}
                          fill="none" stroke={theme.textMuted} strokeWidth="1.2" opacity="0.6"
                          strokeLinejoin="round" />
                        <path d={`M ${x2} ${y2} l -5 -3 v 6 z`} fill={theme.textMuted} opacity="0.85" />
                      </g>
                    );
                  }))}
                </svg>
              )}

              {/* Полосы */}
              {items.map((it, idx) => {
                const p = posOf(it, idx);
                const color = barColor(it);
                const dragging = dragState?.id === it.id;
                if (it.milestone) {
                  const size = 14;
                  const left = p.left + scale.px / 2 - size / 2;
                  const top = idx * rowH + (rowH - size) / 2;
                  return (
                    <React.Fragment key={it.id}>
                      <div
                        onMouseDown={(e) => startDrag(e, it, "move")}
                        style={{ left, top, width: size, height: size, background: color, borderRadius: 3,
                          boxShadow: `0 0 0 3px ${tint(color, 0.22)}`,
                          opacity: dragging ? 0.75 : 1, cursor: canEdit ? "grab" : "default" }}
                        className="absolute rotate-45"
                        title={`${it.title} · ${fmtDate(it.startsOn)}`} />
                      <span style={{ left: left + size + 8, top: idx * rowH, height: rowH, color: theme.text }}
                        className="absolute flex items-center gap-1.5 text-[12px] font-medium whitespace-nowrap pointer-events-none">
                        {it.title}
                        <span style={{ color: theme.textMuted }} className="font-normal tabular-nums">
                          {fmtDate(it.startsOn)}
                        </span>
                      </span>
                    </React.Fragment>
                  );
                }
                const pct = it.progress > 0 ? `${it.progress}%` : "";
                const fits = measure(`${it.title}${pct ? `  ${pct}` : ""}`) + 18 <= p.width;
                const label = (
                  <>
                    <span className="truncate">{it.title}</span>
                    {pct && (
                      <span style={{ color: theme.textMuted }} className="shrink-0 tabular-nums font-normal">{pct}</span>
                    )}
                  </>
                );
                return (
                  <div key={it.id} className="absolute"
                    style={{ left: p.left, top: p.top, width: p.width, height: barH }}>
                    <div
                      onMouseDown={(e) => startDrag(e, it, "move")}
                      style={{
                        background: tint(color, toneA),
                        boxShadow: `inset 0 0 0 1px ${tint(color, theme.dark ? 0.55 : 0.45)}`,
                        opacity: dragging ? 0.75 : 1,
                        cursor: canEdit ? "grab" : "default",
                      }}
                      className="w-full h-full rounded-lg overflow-hidden flex items-center px-2 relative"
                      title={`${it.title}: ${fmtDate(it.startsOn)} — ${fmtDate(it.endsOn)} · готово ${it.progress}%`}>
                      {it.progress > 0 && (
                        <div style={{ width: `${Math.min(100, it.progress)}%`, background: tint(color, fillA) }}
                          className="absolute inset-y-0 left-0" />
                      )}
                      {fits && (
                        <span className="relative flex items-center gap-1.5 min-w-0 text-[12px] font-medium pointer-events-none"
                          style={{ color: theme.text }}>
                          {label}
                        </span>
                      )}
                    </div>
                    {/* Подпись, не поместившаяся в полосу, выводится справа от неё. */}
                    {!fits && (
                      <span style={{ left: p.width + 10, color: theme.text }}
                        className="absolute inset-y-0 flex items-center gap-1.5 text-[12px] font-medium whitespace-nowrap pointer-events-none">
                        {label}
                      </span>
                    )}

                    {/* Кружки начала и окончания перемещаются отдельно друг от друга. */}
                    {canEdit && (
                      <>
                        <div onMouseDown={(e) => startDrag(e, it, "start")}
                          style={{ background: theme.surface, borderColor: color, left: -5,
                            top: (rowH - 12) / 2 - 5 }}
                          className="absolute w-2.5 h-2.5 rounded-full border-2 cursor-ew-resize"
                          title={`Начало: ${fmtDate(it.startsOn)}`} />
                        <div onMouseDown={(e) => startDrag(e, it, "end")}
                          style={{ background: theme.surface, borderColor: color, right: -5,
                            top: (rowH - 12) / 2 - 5 }}
                          className="absolute w-2.5 h-2.5 rounded-full border-2 cursor-ew-resize"
                          title={`Окончание: ${fmtDate(it.endsOn)}`} />
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Ссылки на задачи: список под полотном. */}
      {items.some((i) => i.tasks?.length) && (
        <div style={{ borderColor: theme.border }} className="border-t px-4 py-3.5">
          <div style={{ color: theme.textMuted }} className="text-[12px] font-medium mb-2">
            Связанные задачи
          </div>
          {items.filter((i) => i.tasks?.length).map((it) => (
            <div key={it.id} className="mb-1.5 flex items-start gap-x-3 gap-y-1 flex-wrap">
              <span style={{ color: theme.text }} className="text-[13px] font-medium">{it.title}:</span>
              {it.tasks.map((t) => (t.visible ? (
                <button key={t.taskId} onClick={() => onOpenTask?.(t.taskId)}
                  style={{ color: theme.accent }} className="text-[13px] flex items-center gap-1 hover:underline underline-offset-2">
                  <Link2 size={12} /> {t.title}
                  {t.boardTitle ? <span style={{ color: theme.textMuted }}> · {t.boardTitle}</span> : null}
                  {t.completed && <Check size={12} style={{ color: theme.success }} />}
                </button>
              ) : (
                // Задача существует, но недоступна пользователю: это указывается явно.
                <span key={t.taskId} style={{ color: theme.textMuted }}
                  className="text-[13px] flex items-center gap-1">
                  <Lock size={12} /> у вас отсутствует возможность просмотреть детальную информацию о задаче
                </span>
              )))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* Раздел: окна диаграммы. */
/* Компонент ItemModal предназначен для создания и изменения этапа диаграммы. */

function ItemModal({ theme, theItem, items, chartId, directory, currentUser, canEdit, onClose, onSave, onDelete, onError }) {
  const [form, setForm] = useState(() => ({
    title: theItem?.title || "",
    description: theItem?.description || "",
    startsOn: theItem?.startsOn || ymd(new Date()),
    endsOn: theItem?.endsOn || addDays(ymd(new Date()), 6),
    progress: theItem?.progress ?? 0,
    color: theItem?.color || "",
    milestone: theItem?.milestone || false,
    next: theItem?.next || [],
    tasks: (theItem?.tasks || []).map((t) => t.taskId),
  }));
  const [taskOptions, setTaskOptions] = useState(null);
  const [pickTask, setPickTask] = useState("");
  const [taskSearch, setTaskSearch] = useState("");
  const [tab, setTab] = useState("details");

  useEffect(() => {
    // Загружаются все доступные задачи, а не только свои.
    let dead = false;
    const params = new URLSearchParams({ scope: "all", limit: "200", sort: "updated" });
    if (taskSearch.trim()) params.set("q", taskSearch.trim());
    api.allTasks(params.toString())
      .then((res) => { if (!dead) setTaskOptions(res?.items || []); })
      .catch(() => { if (!dead) setTaskOptions([]); });
    return () => { dead = true; };
  }, [taskSearch]);

  // Записи, которые нельзя назначить следующими: из них уже есть путь в текущую запись (иначе цепочка замкнулась бы).
  const wouldCycle = useMemo(() => {
    const byId = new Map(items.map((i) => [i.id, i]));
    const reaches = (fromId, targetId, seen = new Set()) => {
      if (fromId === targetId) return true;
      if (seen.has(fromId)) return false;
      seen.add(fromId);
      const node = byId.get(fromId);
      return (node?.next || []).some((n) => reaches(n, targetId, seen));
    };
    const me = theItem?.id;
    const bad = new Set();
    if (me) {
      for (const it of items) {
        if (it.id !== me && reaches(it.id, me)) bad.add(it.id);
      }
    }
    return bad;
  }, [items, theItem?.id]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.title.trim()) return onError("Укажите название записи");
    if (form.endsOn < form.startsOn) return onError("Окончание раньше начала");
    onSave({
      title: form.title.trim(),
      description: form.description,
      startsOn: form.startsOn,
      // У вехи нет длительности.
      endsOn: form.milestone ? form.startsOn : form.endsOn,
      progress: Number(form.progress) || 0,
      color: form.color,
      milestone: form.milestone,
      next: [...new Set(form.next)],
      tasks: [...new Set(form.tasks)],
    });
  };

  const others = items.filter((i) => i.id !== theItem?.id);
  const chosenTasks = (taskOptions || []).filter((t) => form.tasks.includes(t.id));
  // Недоступные для правки поля приглушаются.
  const fieldStyle = canEdit ? inputStyle(theme)
    : { ...inputStyle(theme), opacity: 0.65, cursor: "default" };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-lg" geometryKey="chart-item">
      <ModalHeader theme={theme} title={theItem ? "Этап диаграммы" : "Новый этап"} onClose={onClose} />

      {/* Обсуждение и история отображаются только у сохранённого этапа. */}
      {theItem && (
        <div className="segmented mb-4" role="tablist">
          {[["details", "Этап"], ["talk", "Обсуждение и файлы"], ["history", "История"]].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)} role="tab"
              aria-selected={tab === id}>{label}</button>
          ))}
        </div>
      )}

      {tab === "talk" && theItem ? (
        <ItemTalk theme={theme} chartId={chartId} item={theItem} directory={directory}
          currentUser={currentUser} onError={onError} />
      ) : tab === "history" && theItem ? (
        <ItemHistory theme={theme} chartId={chartId} item={theItem}
          directory={directory} onError={onError} />
      ) : (
      <>
      {/* Исполнителю этап доступен только для чтения. */}
      {!canEdit && (
        <div style={{ background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}
          className="rounded-xl px-3 py-2 text-[13px] mb-3 flex items-center gap-2">
          <Lock size={13} /> Только просмотр: изменять этап может владелец или редактор
          диаграммы. Замечания и файлы — на вкладке «Обсуждение и файлы».
        </div>
      )}
      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} autoFocus
          disabled={!canEdit}
          style={fieldStyle} className="w-full rounded-xl px-3 py-2 text-[13px] outline-none" />
      </Field>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Начало" theme={theme}>
          <input type="date" value={form.startsOn} onChange={(e) => set("startsOn", e.target.value)}
            disabled={!canEdit}
            style={fieldStyle} className="w-full rounded-xl px-3 py-2 text-[13px] outline-none" />
        </Field>
        <Field label={form.milestone ? "Окончание (веха)" : "Окончание"} theme={theme}>
          <input type="date" value={form.milestone ? form.startsOn : form.endsOn}
            disabled={form.milestone || !canEdit}
            onChange={(e) => set("endsOn", e.target.value)}
            style={{ ...fieldStyle, opacity: (form.milestone || !canEdit) ? 0.5 : 1 }}
            className="w-full rounded-xl px-3 py-2 text-[13px] outline-none" />
        </Field>
      </div>

      <div className="flex items-center gap-4 mb-3 flex-wrap">
        <label className="flex items-center gap-2 text-[13px]" style={{ color: theme.text }}>
          <input type="checkbox" checked={form.milestone} disabled={!canEdit}
            onChange={(e) => set("milestone", e.target.checked)} />
          Веха (событие без длительности)
        </label>
        <div className="flex items-center gap-2">
          <span style={{ color: theme.textMuted }} className="text-[12px]">Готово, %</span>
          <input type="number" min="0" max="100" value={form.progress} disabled={!canEdit}
            onChange={(e) => set("progress", e.target.value)}
            style={fieldStyle} className="w-20 rounded-xl px-2 py-1 text-[13px] outline-none" />
        </div>
      </div>

      <Field label="Цвет полосы" theme={theme}>
        <div className="flex items-center gap-1.5 flex-wrap">
          {BAR_COLORS.map(([c, name]) => (
            <button key={c || "default"} onClick={() => set("color", c)} title={name} disabled={!canEdit}
              style={{
                background: c || theme.surfaceAlt,
                border: `1px solid ${theme.border}`,
                outline: form.color === c ? `2px solid ${theme.accent}` : "none",
                color: theme.text,
              }}
              className="h-7 min-w-[28px] px-2.5 rounded-full text-[12px] disabled:cursor-default">
              {c ? "" : "по умолчанию"}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Описание" theme={theme}>
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)}
          rows={2} disabled={!canEdit} style={fieldStyle}
          className="w-full rounded-xl px-3 py-2 text-[13px] outline-none resize-none" />
      </Field>

      {others.length > 0 && (
        <Field label="Следующие записи" theme={theme}
          hint="Стрелка на диаграмме: эта запись предшествует отмеченным.">
          <div className="flex flex-wrap gap-1.5">
            {others.map((o) => {
              const on = form.next.includes(o.id);
              const blocked = wouldCycle.has(o.id);
              return (
                <button key={o.id} disabled={blocked || !canEdit}
                  title={blocked ? "Эта запись уже ведёт к текущей — цепочка замкнулась бы" : undefined}
                  onClick={() => set("next", on ? form.next.filter((x) => x !== o.id) : [...form.next, o.id])}
                  style={{
                    background: on ? theme.accent : theme.surfaceAlt,
                    color: on ? theme.accentText : theme.text,
                    border: `1px solid ${theme.border}`,
                  }}
                  className="px-2.5 py-1 rounded-full text-[12px] flex items-center gap-1 disabled:opacity-40">
                  {on && <ArrowRight size={11} />} {o.title}
                </button>
              );
            })}
          </div>
        </Field>
      )}

      <Field label="Ссылки на задачи проектов" theme={theme}
        hint="Необязательно. Задача остаётся в своём проекте — диаграмма её не ведёт и сроки ей не меняет.">
        <div className="flex flex-wrap gap-1.5 mb-2">
          {form.tasks.length === 0 && (
            <span style={{ color: theme.textMuted }} className="text-[12px]">Ссылок нет</span>
          )}
          {form.tasks.map((id) => {
            const known = chosenTasks.find((t) => t.id === id)
              || (theItem?.tasks || []).find((t) => t.taskId === id);
            const label = known?.title || known?.taskId || "задача";
            return (
              <button key={id} disabled={!canEdit}
                onClick={() => set("tasks", form.tasks.filter((x) => x !== id))}
                style={{ background: theme.surfaceAlt, color: theme.text, maxWidth: "100%" }}
                className="flex items-center gap-1 px-2 py-1 rounded-full text-[12px] min-w-0"
                title={`${label} — убрать ссылку`}>
                <span className="truncate">
                  {known?.visible === false ? "задача без доступа" : label}
                </span>
                <X size={11} className="shrink-0" />
              </button>
            );
          })}
        </div>
        {canEdit && (
        <input value={taskSearch} onChange={(e) => setTaskSearch(e.target.value)}
          placeholder="Поиск задачи по названию"
          style={fieldStyle}
          className="w-full rounded-xl px-2.5 py-1.5 text-[13px] outline-none mb-1.5" />
        )}
        {/* Ширина списка задана жёстко, как у остальных полей формы. */}
        {canEdit && (
        <div className="flex gap-2 w-full">
          <select value={pickTask} onChange={(e) => setPickTask(e.target.value)}
            style={{ ...fieldStyle, maxWidth: "100%" }}
            title={(taskOptions || []).find((t) => t.id === pickTask)?.title || "Выберите задачу"}
            className="flex-1 min-w-0 rounded-xl px-2 py-1.5 text-[13px] outline-none truncate">
            <option value="">Выберите задачу…</option>
            {taskOptions === null && <option disabled>Загружаем…</option>}
            {taskOptions?.length === 0 && <option disabled>Задач не найдено</option>}
            {(taskOptions || []).filter((t) => !form.tasks.includes(t.id)).map((t) => (
              <option key={t.id} value={t.id}>{t.title}{t.boardTitle ? ` · ${t.boardTitle}` : ""}</option>
            ))}
          </select>
          <button onClick={() => {
            // Задача не добавляется повторно.
            if (!pickTask || form.tasks.includes(pickTask)) { setPickTask(""); return; }
            set("tasks", [...form.tasks, pickTask]);
            setPickTask("");
          }}
            className="btn-pill shrink-0">Добавить</button>
        </div>
        )}
      </Field>

      <div className="flex gap-2 mt-4">
        {onDelete && canEdit && (
          <button onClick={onDelete} style={{ color: theme.danger }}
            className="btn-pill">Удалить</button>
        )}
        <button onClick={onClose}
          className="btn-pill flex-1">Закрыть</button>
        {canEdit && (
          <button onClick={submit} className="btn-primary flex-1">Сохранить</button>
        )}
      </div>
      </>
      )}
    </Modal>
  );
}

// Компонент ItemHistory предназначен для обсуждения этапа и файлов к нему (устроен как у задач).
function ItemHistory({ theme, chartId, item, directory, onError }) {
  const [rows, setRows] = useState(null);

  const load = useCallback(async () => {
    try { setRows(await api.chartItemActivity(chartId, item.id)); }
    catch (e) { onError(e.message); setRows([]); }
  }, [chartId, item.id, onError]);

  useEffect(() => { load(); }, [load]);

  // История пополняется по событию списка этапов.
  useEffect(() => onRealtimeMessage("chartItems", () => { load(); }), [load]);
  useEffect(() => onRealtimeMessage("chartComment", (e) => {
    if (e.payload?.itemId === item.id) load();
  }), [item.id, load]);

  if (rows === null) {
    return <p style={{ color: theme.textMuted }} className="text-[13px]">Загружаем…</p>;
  }
  if (rows.length === 0) {
    return <p style={{ color: theme.textMuted }} className="text-[13px]">История пуста.</p>;
  }

  return (
    <div className="max-h-[46vh] overflow-y-auto">
      {rows.map((a) => {
        const u = a.actorId ? resolveUser(directory, a.actorId) : null;
        return (
          <div key={a.id} style={{ borderColor: theme.border }}
            className="flex items-start gap-2 py-2 border-b last:border-b-0">
            {u ? <Avatar user={u} size={22} theme={theme} />
              : <span style={{ background: theme.surfaceAlt }} className="w-[22px] h-[22px] rounded-full shrink-0" />}
            <div className="flex-1 min-w-0">
              <div style={{ color: theme.textMuted }} className="text-[12px]">
                {fmtDateTime(a.createdAt)}
                {u ? ` · ${u.fullName}` : ""}
              </div>
              <div style={{ color: theme.text }} className="text-[13px] leading-snug break-words">
                {a.body}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Компонент ItemTalk предназначен для комментариев и файлов этапа.
function ItemTalk({ theme, chartId, item, directory, currentUser, onError }) {
  const [tab, setTab] = useState("comments");
  const [comments, setComments] = useState([]);
  const [files, setFiles] = useState([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const fileRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const d = await api.chartItemComments(chartId, item.id);
      setComments(d.comments || []);
      setFiles(d.files || []);
    } catch (e) { onError(e.message); }
  }, [chartId, item.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Чужие замечания и файлы приходят событием.
  useEffect(() => onRealtimeMessage("chartComment", (e) => {
    if (e.payload?.itemId !== item.id) return;
    load();
  }), [item.id, load]);

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setText("");
    try { await api.addChartComment(chartId, item.id, body); load(); }
    catch (e) { onError(e.message); setText(body); }
  };

  const upload = async (file) => {
    if (!file) return;
    setBusy(true);
    try { await api.uploadChartFile(chartId, item.id, file); load(); }
    catch (e) { onError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div>
      {/* Две вкладки: разговор и файлы. */}
      <div className="segmented mb-3" role="tablist">
        {[["comments", `Обсуждение${comments.length ? ` · ${comments.length}` : ""}`],
          ["files", `Файлы${files.length ? ` · ${files.length}` : ""}`]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} role="tab"
            aria-selected={tab === id} className="tabular-nums">{label}</button>
        ))}
      </div>

      {tab === "comments" ? (
        <>
          <div className="max-h-[38vh] overflow-y-auto mb-3">
            {comments.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[13px]">
                Замечаний пока нет. Напишите первое — его увидят все участники диаграммы.
              </p>
            )}
            {comments.map((c) => {
              const u = resolveUser(directory, c.authorId);
              return (
                <div key={c.id} className="flex items-start gap-2 mb-2.5">
                  <Avatar user={u} size={24} theme={theme} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span style={{ color: theme.text }} className="text-[12px] font-medium">{u.fullName}</span>
                      <span style={{ color: theme.textMuted }} className="text-[12px]"
                        title={fmtDateTime(c.createdAt)}>{fmtRelative(c.createdAt)}</span>
                      {/* Удалять может только автор замечания; признак canEdit приходит с сервера (право определяет политика). */}
                      {c.canEdit && (
                        <button onClick={async () => {
                          try { await api.deleteChartComment(chartId, item.id, c.id); load(); }
                          catch (e) { onError(e.message); }
                        }} className={`${DANGER_ICON} !w-7 !h-7 ml-auto`} title="Удалить" aria-label="Удалить замечание">
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>
                    <p style={{ color: theme.text }}
                      className="text-[13px] leading-snug whitespace-pre-wrap break-words">
                      {c.body}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-end gap-2">
            <textarea value={text} onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send(); }}
              rows={2} placeholder="Написать замечание. Ctrl+Enter — отправить"
              style={inputStyle(theme)}
              className="flex-1 rounded-xl px-3 py-2 text-[13px] outline-none resize-none" />
            <button onClick={send} className="btn-primary !px-0 w-10 h-10 shrink-0"
              title="Отправить" aria-label="Отправить"><Send size={16} /></button>
          </div>
        </>
      ) : (
        <>
          <div className="max-h-[38vh] overflow-y-auto mb-3">
            {files.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[13px]">Файлов нет.</p>
            )}
            {files.map((f) => {
              const u = resolveUser(directory, f.authorId);
              return (
                <div key={f.id} style={{ borderColor: theme.border }}
                  className="flex items-center gap-2 py-2 border-b last:border-b-0">
                  <Paperclip size={14} style={{ color: theme.textMuted }} className="shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div style={{ color: theme.text }} className="text-[13px] font-medium truncate">
                      {f.filename}
                    </div>
                    <div style={{ color: theme.textMuted }} className="text-[12px] truncate">
                      {fmtSize(f.size)} · {u.fullName} · {fmtRelative(f.createdAt)}
                    </div>
                  </div>
                  <div className="flex items-center gap-0.5 shrink-0">
                    {/* Предпросмотр в окне, а не в новой вкладке. */}
                    <button onClick={() => setPreview(f)} className="btn-icon !w-8 !h-8"
                      title="Посмотреть в окне" aria-label="Посмотреть в окне"><ExternalLink size={15} /></button>
                    <button onClick={() => downloadFile(api.chartFileUrl(f.id, true), f.filename)}
                      className="btn-icon !w-8 !h-8" title="Скачать" aria-label="Скачать"><Download size={15} /></button>
                    {f.canEdit && (
                      <button onClick={async () => {
                        try { await api.deleteChartFile(chartId, item.id, f.id); load(); }
                        catch (e) { onError(e.message); }
                      }} className={`${DANGER_ICON} !w-8 !h-8`} title="Удалить" aria-label="Удалить файл"><Trash2 size={15} /></button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <input ref={fileRef} type="file" className="hidden"
            onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
          <button onClick={() => fileRef.current?.click()} disabled={busy}
            style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
            className="w-full flex items-center justify-center gap-1.5 text-[14px] font-medium rounded-xl py-3 transition-colors duration-150 hover:bg-[var(--t-surfaceAlt)] disabled:opacity-50">
            <Upload size={14} /> {busy ? "Загружаем…" : "Загрузить файл"}
          </button>
        </>
      )}

      {preview && (
        <FilePreview theme={theme} title={preview.filename} filename={preview.filename}
          mime={preview.mime} path={api.chartFileUrl(preview.id)}
          pdfPath={api.chartFilePdfUrl(preview.id)}
          downloadPath={api.chartFileUrl(preview.id, true)}
          onClose={() => setPreview(null)} />
      )}
    </div>
  );
}

// Компонент SettingsModal предназначен для окна настроек вида диаграммы.
function SettingsModal({ theme, settings, canEdit, onClose, onSave }) {
  const [form, setForm] = useState(settings);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="chart-settings">
      <ModalHeader theme={theme} title="Вид диаграммы" onClose={onClose} />

      <Field label="Масштаб" theme={theme}>
        <div className="segmented">
          {Object.entries(SCALES).map(([id, s]) => (
            <button key={id} onClick={() => set("scale", id)}
              aria-pressed={form.scale === id}>{s.label}</button>
          ))}
        </div>
      </Field>

      {[["showWeekends", "Выделять выходные"], ["showToday", "Линия сегодняшнего дня"],
        ["showLinks", "Показывать связи"]].map(([k, label]) => (
        <label key={k} className="flex items-center justify-between py-1.5 text-[13px]"
          style={{ color: theme.text }}>
          {label}
          <input type="checkbox" checked={Boolean(form[k])} onChange={(e) => set(k, e.target.checked)} />
        </label>
      ))}

      <Field label="Высота строки" theme={theme}>
        <input type="range" min="26" max="56" value={form.rowHeight}
          onChange={(e) => set("rowHeight", Number(e.target.value))} className="w-full" />
      </Field>

      <Field label="Цвет полос по умолчанию" theme={theme}
        hint="У записи может быть свой цвет — он важнее этого.">
        <div className="flex items-center gap-1.5 flex-wrap">
          {BAR_COLORS.map(([c, name]) => (
            <button key={c || "default"} onClick={() => set("barColor", c)} title={name}
              style={{
                background: c || theme.surfaceAlt,
                border: `1px solid ${theme.border}`,
                outline: (form.barColor || "") === c ? `2px solid ${theme.accent}` : "none",
                color: theme.text,
              }}
              className="h-7 min-w-[28px] px-2.5 rounded-full text-[12px] disabled:cursor-default">
              {c ? "" : "по умолчанию"}
            </button>
          ))}
        </div>
      </Field>

      <div className="flex gap-2 mt-4">
        <button onClick={onClose}
          className="btn-pill flex-1">Закрыть</button>
        {canEdit && (
          <button onClick={() => onSave(form)} className="btn-primary flex-1">Сохранить</button>
        )}
      </div>
    </Modal>
  );
}

/* Раздел: общие окна (и для досок). */
/* Компонент NameModal предназначен для окна ввода названия. */

export function NameModal({ theme, title, initial = "", onClose, onSave }) {
  const [value, setValue] = useState(initial);
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="name-modal">
      <ModalHeader theme={theme} title={title} onClose={onClose} />
      <input value={value} onChange={(e) => setValue(e.target.value)} autoFocus
        onKeyDown={(e) => { if (e.key === "Enter" && value.trim()) onSave(value.trim()); }}
        style={inputStyle(theme)} className="w-full rounded-xl px-3 py-2 text-[13px] outline-none mb-4" />
      <div className="flex gap-2">
        <button onClick={onClose}
          className="btn-pill flex-1">Отмена</button>
        <button onClick={() => value.trim() && onSave(value.trim())} disabled={!value.trim()}
          className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed">Сохранить</button>
      </div>
    </Modal>
  );
}

// Компонент MembersModal предназначен для состава участников: те же роли, что в проектах (редактор правит, исполнитель просматривает).
export function MembersModal({ theme, directory, team, members, isOwner, title, onClose, onSave }) {
  const [rows, setRows] = useState(
    () => members.filter((m) => m.role !== "owner").map((m) => ({ ...m })));

  const owner = members.find((m) => m.role === "owner");
  const candidates = (team || []).filter((id) => id !== owner?.userId);

  const roleOf = (id) => rows.find((r) => r.userId === id)?.role || "";
  const setRole = (id, role) => setRows((prev) => {
    const rest = prev.filter((r) => r.userId !== id);
    return role ? [...rest, { userId: id, role }] : rest;
  });

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="members-modal">
      <ModalHeader theme={theme} title={title} onClose={onClose} />

      {owner && (
        <div className="flex items-center gap-2 mb-3">
          <Avatar user={resolveUser(directory, owner.userId)} size={24} theme={theme} />
          <span style={{ color: theme.text }} className="text-[13px]">
            {resolveUser(directory, owner.userId).fullName}
          </span>
          <span style={{ color: theme.textMuted }} className="text-[12px]">владелец</span>
        </div>
      )}

      {candidates.length === 0 && (
        <p style={{ color: theme.textMuted }} className="text-[13px] mb-3">
          В вашей команде пока никого нет — добавьте людей в команду, и они появятся здесь.
        </p>
      )}

      <div className="max-h-[46vh] overflow-y-auto mb-3">
        {candidates.map((id) => {
          const u = resolveUser(directory, id);
          const role = roleOf(id);
          return (
            <div key={id} className="flex items-center gap-2 py-1.5">
              <Avatar user={u} size={24} theme={theme} />
              <span style={{ color: theme.text }} className="text-[13px] flex-1 truncate">{u.fullName}</span>
              <div className="segmented !p-0.5 shrink-0">
                {[["", "нет"], ["reader", "исполнитель"], ["editor", "редактор"]].map(([val, label]) => (
                  <button key={val || "none"} onClick={() => setRole(id, val)}
                    aria-pressed={role === val} className="!px-2.5 !py-1 !text-[12px]">{label}</button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex gap-2">
        <button onClick={onClose}
          className="btn-pill flex-1">Отмена</button>
        <button onClick={() => onSave(rows)} className="btn-primary flex-1">Сохранить</button>
      </div>
    </Modal>
  );
}
