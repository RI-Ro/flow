// Модуль предназначен для запуска клиентского приложения: загрузка публичных настроек сервера и первый рендер компонента App.

import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { loadAppConfig } from "./lib/appConfig.js";

// Шрифт Inter (OFL) подключается пакетом @fontsource-variable/inter и входит в сборку: файлы woff2 раздаёт собственный сервер,
// обращений к внешним сетям нет. Наборы символов разделены по unicode-range, браузер загружает только используемые.
// Стек запасных системных шрифтов задан в styles.css (--font-ui).
import "@fontsource-variable/inter";
import "./styles.css";

loadAppConfig().finally(() => {
  createRoot(document.getElementById("root")).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
