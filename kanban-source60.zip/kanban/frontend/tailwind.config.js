// Модуль предназначен для настройки Tailwind CSS: области поиска классов и шрифтовой стек.

/* Тип конфигурации Tailwind. */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      // Шрифтовой стек совпадает с --font-ui в styles.css: Inter из сборки (main.jsx), затем системные шрифты.
      fontFamily: {
        sans: ["Inter Variable", "system-ui", "-apple-system", "Segoe UI", "Roboto",
               "Helvetica Neue", "Noto Sans", "Liberation Sans", "Arial", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas",
               "Liberation Mono", "DejaVu Sans Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
