import React, { useEffect, useMemo, useState } from "react";
import { ArrowUpDown, CheckCircle2, UserCheck, Globe, FileSpreadsheet, Printer } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, fmtDate, isOverdue, isUnseen, resolveUser } from "../lib/theme.js";
import { matchesFilters } from "../lib/filters.js";
import { exportTasksToExcel } from "../lib/excel.js";
import { printTasksReport } from "../lib/taskPdf.js";
import { Avatar, Spinner } from "../lib/ui.jsx";

// Вкладка «Все задачи» (п.5): единый список всех доступных задач из всех
// проектов с фильтрами и сортировкой. Каждая строка показывает проект и
// колонку задачи; клик открывает подробный просмотр.
const SHOW_ALL_KEY = "kanban.allTasks.showAll";

export default function AllTasks({ theme, directory, boards, currentUser, hideCompleted, filters, search, onTags, onError, onInfo, onOpenTask, onOpenBoard }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState({ key: "updated", dir: "desc" });
  // По умолчанию показываются только свои задачи: поставленные мной и
  // порученные мне (п.4). Всё, что доступно по ролям в проектах, —
  // по отдельной кнопке, и её состояние переживает перезагрузку
  // страницы: это настройка рабочего места, а не разовый фильтр.
  const [showAll, setShowAll] = useState(
    () => localStorage.getItem(SHOW_ALL_KEY) === "true");
  useEffect(() => { localStorage.setItem(SHOW_ALL_KEY, String(showAll)); }, [showAll]);

  const load = async () => {
    setLoading(true);
    try {
      setTasks(await api.allTasks());
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  // Кандидаты для фильтра по исполнителю — все, кто встречается в
  // загруженных задачах.
  // Теги этой вкладки уходят наверх, в общую панель отбора: задачи
  // грузятся здесь, а панель живёт в App.
  useEffect(() => {
    onTags?.([...new Set(tasks.flatMap((t) => t.tags || []))].sort());
  }, [tasks, onTags]);

  const filtered = useMemo(() => {
    let list = tasks.filter((t) => {
      // «Мои» — те, где я автор или исполнитель. Именно этот набор
      // человек считает своим списком дел; остальное он видит только
      // потому, что состоит в проекте.
      if (!showAll) {
        const mine = t.createdBy === currentUser?.id
          || (t.assignees || []).includes(currentUser?.id);
        if (!mine) return false;
      }
      if (hideCompleted && t.completedAt) return false;
      // Весь отбор — общий: проект, статус, приоритет, исполнитель,
      // теги, срок и строка поиска. Своих полей у этого списка больше
      // нет: два набора с одинаковым смыслом на одном экране только
      // путали, и настройки между вкладками не переносились.
      if (filters && !matchesFilters(t, filters, search)) return false;
      return true;
    });

    const dir = sort.dir === "asc" ? 1 : -1;
    const val = (t) => {
      switch (sort.key) {
        case "title": return t.title.toLowerCase();
        case "board": return (t.boardTitle || "").toLowerCase();
        case "author": {
          const a = t.createdBy ? resolveUser(directory, t.createdBy) : null;
          return (a?.fullName || "").toLowerCase();
        }
        case "priority": return PRIORITIES[t.priority]?.order || 0;
        case "due": return t.dueDate || "9999-99-99";
        case "created": return t.createdAt || "";
        default: return t.updatedAt || "";
      }
    };
    return [...list].sort((a, b) => {
      const va = val(a), vb = val(b);
      if (va < vb) return -1 * dir;
      if (va > vb) return 1 * dir;
      return 0;
    });
  }, [tasks, search, sort, directory, hideCompleted, showAll, currentUser, filters]);

  // Сколько задач скрывает режим «только мои» — чтобы кнопка не была
  // выбором вслепую.
  const mineCount = useMemo(() => tasks.filter((t) =>
    t.createdBy === currentUser?.id || (t.assignees || []).includes(currentUser?.id)).length,
    [tasks, currentUser]);

  const toggleSort = (key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));


  const th = (key, label) => (
    <button onClick={() => toggleSort(key)}
      style={{ color: sort.key === key ? theme.text : theme.textMuted }}
      className="flex items-center gap-1 text-[11px] uppercase tracking-wide font-semibold">
      {label}
      <ArrowUpDown size={11} style={{ opacity: sort.key === key ? 1 : 0.3 }} />
    </button>
  );

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="rounded-2xl p-3 mb-3 flex flex-wrap items-center gap-2.5">
        {/* Поиск и отбор — общие, в шапке приложения. Здесь остаётся
            только то, чего нет больше нигде: переключатель «мои /
            все» и счётчик показанного. */}

        {/* Выгрузка и печать работают по отфильтрованному списку — по
            тому, что человек видит на экране. Иначе отчёт расходился
            бы с картинкой, а верят как раз отчёту. */}
        <button
          onClick={() => {
            const n = exportTasksToExcel(filtered, {
              directory, boardTitle: showAll ? "Все задачи" : "Мои задачи",
            });
            onInfo?.(`Выгружено задач: ${n}`);
          }}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium shrink-0"
          title="Выгрузить показанные задачи в Excel">
          <FileSpreadsheet size={13} /> Excel
        </button>

        <button
          onClick={() => printTasksReport(filtered, directory, {
            title: showAll ? "Все задачи" : "Мои задачи",
          })}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium shrink-0"
          title="Печать отчёта по показанным задачам (сгруппирован по проектам)">
          <Printer size={13} /> Печать
        </button>

        <button onClick={() => setShowAll((v) => !v)}
          style={{
            background: showAll ? theme.accent : theme.surfaceAlt,
            color: showAll ? theme.accentText : theme.text,
            border: `1px solid ${theme.border}`,
          }}
          // Ширина фиксирована: подписи «Только мои» и «Все задачи»
          // разной длины, и без этого кнопка при переключении меняла
          // размер, а вместе с ней разъезжалась вся строка фильтров и
          // прыгало поле поиска.
          className="flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium w-[124px] shrink-0"
          title={showAll
            ? "Сейчас показаны все доступные задачи. Нажмите, чтобы оставить только свои"
            : "Сейчас показаны только мои задачи (поставленные мной и порученные мне). Нажмите, чтобы показать все доступные"}>
          {showAll ? <Globe size={13} /> : <UserCheck size={13} />}
          {showAll ? "Все задачи" : "Только мои"}
        </button>

        <span className="mono text-[10.5px] ml-auto" style={{ color: theme.textMuted }}>
          {loading ? "// загрузка…"
            : `// показано ${filtered.length} из ${showAll ? tasks.length : mineCount}${showAll ? "" : ` · всего доступно ${tasks.length}`}`}
        </span>
      </div>

      {loading ? (
        <Spinner theme={theme} label="Загружаем задачи…" />
      ) : (
        <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }} className="rounded-2xl overflow-hidden">
          <div style={{ background: theme.surfaceAlt, borderColor: theme.border }}
            className="grid grid-cols-[minmax(0,2.6fr)_minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1fr)_minmax(0,1.2fr)_auto] gap-3 px-4 py-2.5 border-b">
            {th("title", "Задача")}
            {th("board", "Проект / колонка")}
            {th("author", "Автор")}
            {th("priority", "Приоритет")}
            <div className="text-[11px] uppercase tracking-wide font-semibold" style={{ color: theme.textMuted }}>Исполнители</div>
            {th("due", "Срок")}
          </div>

          {filtered.length === 0 && (
            <div style={{ color: theme.textMuted }} className="px-4 py-10 text-center text-[13px]">
              Задач по заданным условиям не найдено.
              {!showAll && tasks.length > mineCount && (
                <>
                  {" "}
                  <button onClick={() => setShowAll(true)} style={{ color: theme.accent }}
                    className="font-medium underline">
                    Показать все доступные
                  </button>
                </>
              )}
            </div>
          )}

          {filtered.map((t) => {
            const pr = PRIORITIES[t.priority] || PRIORITIES.medium;
            const overdue = isOverdue(t.dueDate, Boolean(t.completedAt));
            const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
            const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
            const unseen = isUnseen(t);
            return (
              <div key={t.id}
                onClick={() => {
                  // Гасим выделение сразу: сама отметка о просмотре
                  // уходит на сервер при открытии карточки, но список
                  // здесь свой и о ней не узнает.
                  setTasks((prev) => prev.map((x) =>
                    (x.id === t.id ? { ...x, seenAt: new Date().toISOString() } : x)));
                  onOpenTask(t.id);
                }}
                role="button" tabIndex={0}
                style={{
                  borderColor: theme.border,
                  background: unseen
                    ? (theme.dark ? "rgba(255,255,255,0.055)" : "rgba(0,0,0,0.045)")
                    : "transparent",
                  boxShadow: unseen ? `inset 3px 0 0 0 ${theme.accent}` : undefined,
                }}
                className="w-full grid grid-cols-[minmax(0,2.6fr)_minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1fr)_minmax(0,1.2fr)_auto] gap-3 px-4 py-2.5 border-b text-left hover:opacity-90 items-center cursor-pointer">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {t.completedAt && <CheckCircle2 size={13} style={{ color: theme.success }} className="shrink-0" />}
                    <span style={{
                        color: theme.text,
                        textDecoration: t.completedAt ? "line-through" : "none",
                        fontWeight: unseen ? 700 : 500,
                      }} className="text-[13px] truncate"
                      title={unseen ? "Изменилось с вашего последнего просмотра" : undefined}>
                      {t.title}
                    </span>
                    {unseen && (
                      <span style={{ background: theme.accent }}
                        className="w-1.5 h-1.5 rounded-full shrink-0" />
                    )}
                  </div>
                  {t.incomingNumber && (
                    <div style={{ color: theme.textMuted }} className="text-[10.5px] mono truncate"
                      title="Входящий номер">
                      вх. {t.incomingNumber}{t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}
                    </div>
                  )}
                </div>

                <div className="min-w-0" onClick={(e) => { e.stopPropagation(); onOpenBoard(t.boardId); }} title="Перейти в проект">
                  <div style={{ color: theme.accent }} className="text-[12px] truncate hover:underline">{t.boardTitle}</div>
                  <div style={{ color: theme.textMuted }} className="text-[10.5px] truncate">{t.columnTitle}</div>
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  {author && !author.deleted ? (
                    <>
                      <Avatar user={author} size={20} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{author.fullName}</span>
                    </>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  <span style={{ background: theme[pr.color] }} className="w-2 h-2 rounded-full shrink-0" />
                  <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{pr.label}</span>
                </div>

                <div className="flex items-center -space-x-1.5">
                  {assignees.slice(0, 4).map((u, i) => (
                    <Avatar key={i} user={u} size={20} theme={theme} />
                  ))}
                  {assignees.length > 4 && (
                    <span style={{ color: theme.textMuted }} className="text-[11px] pl-2.5">+{assignees.length - 4}</span>
                  )}
                  {assignees.length === 0 && <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>}
                </div>

                <div style={{ color: overdue ? theme.danger : theme.textMuted }} className="text-[11.5px] whitespace-nowrap">
                  {t.dueDate ? fmtDate(t.dueDate) : "—"}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
