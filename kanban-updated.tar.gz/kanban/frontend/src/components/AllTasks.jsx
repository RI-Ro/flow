import React, { useEffect, useMemo, useState } from "react";
import { Search, ArrowUpDown, X, CheckCircle2 } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, fmtDate, isOverdue, resolveUser } from "../lib/theme.js";
import { Avatar, Spinner, inputStyle } from "../lib/ui.jsx";

// Вкладка «Все задачи» (п.5): единый список всех доступных задач из всех
// проектов с фильтрами и сортировкой. Каждая строка показывает проект и
// колонку задачи; клик открывает подробный просмотр.
export default function AllTasks({ theme, directory, boards, currentUser, onError, onOpenTask }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [boardId, setBoardId] = useState("");
  const [priority, setPriority] = useState("");
  const [assignee, setAssignee] = useState("");
  const [status, setStatus] = useState("all"); // all | active | done | overdue
  const [sort, setSort] = useState({ key: "updated", dir: "desc" });

  const load = async () => {
    setLoading(true);
    try {
      setTasks(await api.allTasks());
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  // Кандидаты для фильтра по исполнителю — все, кто встречается в
  // загруженных задачах.
  const assigneeOptions = useMemo(() => {
    const ids = new Set();
    for (const t of tasks) for (const id of t.assignees || []) ids.add(id);
    if (assignee) ids.add(assignee);
    return [...ids].map((id) => resolveUser(directory, id))
      .filter((u) => u && !u.deleted)
      .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));
  }, [tasks, assignee, directory]);

  const filtered = useMemo(() => {
    const text = q.trim().toLowerCase();
    let list = tasks.filter((t) => {
      if (boardId && t.boardId !== boardId) return false;
      if (priority && t.priority !== priority) return false;
      if (assignee && !(t.assignees || []).includes(assignee)) return false;
      if (status === "active" && t.completedAt) return false;
      if (status === "done" && !t.completedAt) return false;
      if (status === "overdue" && !isOverdue(t.dueDate, Boolean(t.completedAt))) return false;
      if (text) {
        const hay = `${t.title} ${t.description || ""} ${t.boardTitle || ""} ${t.incomingNumber || ""} ${(t.tags || []).join(" ")}`.toLowerCase();
        if (!hay.includes(text)) return false;
      }
      return true;
    });

    const dir = sort.dir === "asc" ? 1 : -1;
    const val = (t) => {
      switch (sort.key) {
        case "title": return t.title.toLowerCase();
        case "board": return (t.boardTitle || "").toLowerCase();
        case "author": {
          const a = t.createdBy ? resolveUser(directory, t.createdBy) : null;
          return (a?.fullName || "").toLowerCase();
        }
        case "priority": return PRIORITIES[t.priority]?.order || 0;
        case "due": return t.dueDate || "9999-99-99";
        case "created": return t.createdAt || "";
        default: return t.updatedAt || "";
      }
    };
    return [...list].sort((a, b) => {
      const va = val(a), vb = val(b);
      if (va < vb) return -1 * dir;
      if (va > vb) return 1 * dir;
      return 0;
    });
  }, [tasks, q, boardId, priority, assignee, status, sort, directory]);

  const toggleSort = (key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));

  const activeFilters = (boardId ? 1 : 0) + (priority ? 1 : 0) + (assignee ? 1 : 0) + (status !== "all" ? 1 : 0) + (q ? 1 : 0);

  const th = (key, label) => (
    <button onClick={() => toggleSort(key)}
      style={{ color: sort.key === key ? theme.text : theme.textMuted }}
      className="flex items-center gap-1 text-[11px] uppercase tracking-wide font-semibold">
      {label}
      <ArrowUpDown size={11} style={{ opacity: sort.key === key ? 1 : 0.3 }} />
    </button>
  );

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="rounded-2xl p-3 mb-3 flex flex-wrap items-center gap-2.5">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={14} style={{ color: theme.textMuted }} className="absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по названию, описанию, № документа, тегам"
            style={inputStyle(theme)} className="w-full pl-8 pr-2.5 py-1.5 rounded-lg text-[13px] outline-none" />
        </div>

        <select value={boardId} onChange={(e) => setBoardId(e.target.value)}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="rounded-lg px-2 py-1.5 text-[12px] outline-none min-w-[150px]">
          <option value="">Все проекты</option>
          {boards.map((b) => <option key={b.id} value={b.id}>{b.title}</option>)}
        </select>

        <select value={priority} onChange={(e) => setPriority(e.target.value)}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="rounded-lg px-2 py-1.5 text-[12px] outline-none">
          <option value="">Любой приоритет</option>
          {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>

        <select value={assignee} onChange={(e) => setAssignee(e.target.value)}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="rounded-lg px-2 py-1.5 text-[12px] outline-none min-w-[150px]">
          <option value="">Все исполнители</option>
          {assigneeOptions.map((u) => <option key={u.id} value={u.id}>{u.fullName}</option>)}
        </select>

        <select value={status} onChange={(e) => setStatus(e.target.value)}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="rounded-lg px-2 py-1.5 text-[12px] outline-none">
          <option value="all">Любой статус</option>
          <option value="active">В работе</option>
          <option value="done">Завершённые</option>
          <option value="overdue">Просроченные</option>
        </select>

        {activeFilters > 0 && (
          <button onClick={() => { setQ(""); setBoardId(""); setPriority(""); setAssignee(""); setStatus("all"); }}
            style={{ color: theme.danger }} className="text-[12px] font-medium flex items-center gap-1">
            <X size={12} /> Сбросить
          </button>
        )}

        <span className="mono text-[10.5px] ml-auto" style={{ color: theme.textMuted }}>
          {loading ? "// загрузка…" : `// показано ${filtered.length} из ${tasks.length}`}
        </span>
      </div>

      {loading ? (
        <Spinner theme={theme} label="Загружаем задачи…" />
      ) : (
        <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }} className="rounded-2xl overflow-hidden">
          <div style={{ background: theme.surfaceAlt, borderColor: theme.border }}
            className="grid grid-cols-[minmax(0,2.6fr)_minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1fr)_minmax(0,1.2fr)_auto] gap-3 px-4 py-2.5 border-b">
            {th("title", "Задача")}
            {th("board", "Проект / колонка")}
            {th("author", "Автор")}
            {th("priority", "Приоритет")}
            <div className="text-[11px] uppercase tracking-wide font-semibold" style={{ color: theme.textMuted }}>Исполнители</div>
            {th("due", "Срок")}
          </div>

          {filtered.length === 0 && (
            <div style={{ color: theme.textMuted }} className="px-4 py-10 text-center text-[13px]">
              Задач по заданным условиям не найдено.
            </div>
          )}

          {filtered.map((t) => {
            const pr = PRIORITIES[t.priority] || PRIORITIES.medium;
            const overdue = isOverdue(t.dueDate, Boolean(t.completedAt));
            const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
            const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
            return (
              <button key={t.id} onClick={() => onOpenTask(t.id)}
                style={{ borderColor: theme.border }}
                className="w-full grid grid-cols-[minmax(0,2.6fr)_minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1fr)_minmax(0,1.2fr)_auto] gap-3 px-4 py-2.5 border-b text-left hover:opacity-90 items-center">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    {t.completedAt && <CheckCircle2 size={13} style={{ color: theme.success }} className="shrink-0" />}
                    <span style={{ color: theme.text, textDecoration: t.completedAt ? "line-through" : "none" }} className="text-[13px] font-medium truncate">{t.title}</span>
                  </div>
                  {t.incomingNumber && <div style={{ color: theme.textMuted }} className="text-[10.5px] mono truncate">вх. {t.incomingNumber}</div>}
                </div>

                <div className="min-w-0">
                  <div style={{ color: theme.text }} className="text-[12px] truncate">{t.boardTitle}</div>
                  <div style={{ color: theme.textMuted }} className="text-[10.5px] truncate">{t.columnTitle}</div>
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  {author && !author.deleted ? (
                    <>
                      <Avatar user={author} size={20} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{author.fullName}</span>
                    </>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 min-w-0">
                  <span style={{ background: theme[pr.color] }} className="w-2 h-2 rounded-full shrink-0" />
                  <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate">{pr.label}</span>
                </div>

                <div className="flex items-center -space-x-1.5">
                  {assignees.slice(0, 4).map((u, i) => (
                    <Avatar key={i} user={u} size={20} theme={theme} />
                  ))}
                  {assignees.length > 4 && (
                    <span style={{ color: theme.textMuted }} className="text-[11px] pl-2.5">+{assignees.length - 4}</span>
                  )}
                  {assignees.length === 0 && <span style={{ color: theme.textMuted }} className="text-[11px]">—</span>}
                </div>

                <div style={{ color: overdue ? theme.danger : theme.textMuted }} className="text-[11.5px] whitespace-nowrap">
                  {t.dueDate ? fmtDate(t.dueDate) : "—"}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
