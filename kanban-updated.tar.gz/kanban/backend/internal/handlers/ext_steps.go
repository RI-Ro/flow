package handlers

import (
	"errors"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// =====================================================================
// Расширенные чек-листы (п.8 ТЗ).
//
// Отдельная сущность от app.task_steps: у каждого пункта есть
// исполнитель, срок от автора и фактический срок выполнения.
//
// Права (дублируют RLS-политики task_ext_steps из 0005_updates.sql):
//   • создавать, править текст/исполнителя/срок, удалять — автор задачи,
//     редактор или владелец проекта (app.can_manage_ext);
//   • ставить/снимать отметку и фактический срок — только назначенный
//     исполнитель пункта.
// =====================================================================

const extStepSelect = `
	SELECT id, task_id, body, assignee_id,
	       to_char(due_date, 'YYYY-MM-DD'),
	       done, to_char(done_date, 'YYYY-MM-DD'), done_by, position, created_by
	  FROM app.task_ext_steps`

func scanExtStep(row pgx.Row) (models.ExtStep, error) {
	var s models.ExtStep
	err := row.Scan(&s.ID, &s.TaskID, &s.Body, &s.AssigneeID, &s.DueDate,
		&s.Done, &s.DoneDate, &s.DoneBy, &s.Position, &s.CreatedBy)
	return s, err
}

func (s *Server) ListExtSteps(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	items := []models.ExtStep{}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), extStepSelect+`
			 WHERE task_id = $1 ORDER BY position`, taskID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var st models.ExtStep
			if e := rows.Scan(&st.ID, &st.TaskID, &st.Body, &st.AssigneeID, &st.DueDate,
				&st.Done, &st.DoneDate, &st.DoneBy, &st.Position, &st.CreatedBy); e != nil {
				return e
			}
			items = append(items, st)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, items)
}

type extStepInput struct {
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
}

func (s *Server) CreateExtStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in extStepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var st models.ExtStep
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_ext($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять расширенный чек-лист может автор задачи, редактор или владелец проекта")
		}
		row := tx.QueryRow(c.Context(), `
			INSERT INTO app.task_ext_steps (task_id, body, assignee_id, due_date, position, created_by)
			VALUES ($1, $2, $3, $4::date,
			        COALESCE((SELECT max(position) + 1 FROM app.task_ext_steps WHERE task_id = $1), 0), $5)
			RETURNING id, task_id, body, assignee_id, to_char(due_date, 'YYYY-MM-DD'),
			          done, to_char(done_date, 'YYYY-MM-DD'), done_by, position, created_by`,
			taskID, in.Body, in.AssigneeID, in.DueDate, uid)
		var e error
		st, e = scanExtStep(row)
		if e != nil {
			return e
		}
		// Назначение на пункт расширенного чек-листа автоматически
		// делает человека исполнителем задачи — так у него появляется
		// доступ, а задача видна как «моя» во входящих и на дашборде.
		if st.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(),
				`SELECT app.ensure_assignee($1, $2, $3)`, taskID, *st.AssigneeID, uid); e != nil {
				return e
			}
		}
		entry := "Добавлен пункт расширенного чек-листа «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishExtStep(taskID, st, "created")
	s.republishTask(c, taskID)
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusCreated, st)
}

// UpdateExtStep правит текст, исполнителя и срок. Доступно только
// менеджеру (автор задачи / редактор / владелец). Отметка о выполнении
// здесь не меняется — для неё отдельный маршрут ToggleExtStep.
func (s *Server) UpdateExtStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in extStepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var st models.ExtStep
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_ext($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять расширенный чек-лист может автор задачи, редактор или владелец проекта")
		}
		row := tx.QueryRow(c.Context(), `
			UPDATE app.task_ext_steps
			   SET body        = COALESCE($3, body),
			       assignee_id = $4,
			       due_date    = $5::date
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, task_id, body, assignee_id, to_char(due_date, 'YYYY-MM-DD'),
			           done, to_char(done_date, 'YYYY-MM-DD'), done_by, position, created_by`,
			stepID, taskID, nullIfEmpty(in.Body), in.AssigneeID, in.DueDate)
		var e error
		st, e = scanExtStep(row)
		if e != nil {
			return e
		}
		// Смена исполнителя пункта тоже открывает доступ новому
		// исполнителю (добавляем в исполнители задачи).
		if st.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(),
				`SELECT app.ensure_assignee($1, $2, $3)`, taskID, *st.AssigneeID, uid); e != nil {
				return e
			}
		}
		return nil
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishExtStep(taskID, st, "updated")
	return httpx.JSON(c, fiber.StatusOK, st)
}

type extToggleInput struct {
	Done     bool    `json:"done"`
	DoneDate *string `json:"doneDate"`
}

// ToggleExtStep — отметка о выполнении. Ставит её только назначенный
// исполнитель пункта: RLS-политика task_ext_steps_update пускает
// строку либо менеджеру, либо исполнителю, но здесь мы дополнительно
// требуем, чтобы отметку ставил именно исполнитель — за него это делать
// нельзя (как и в обычной отметке о сдаче задачи).
func (s *Server) ToggleExtStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in extToggleInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var st models.ExtStep
	var watchers []uuid.UUID
	var notAssignee bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Отметку о выполнении может поставить исполнитель пункта, а
		// также автор задачи, редактор и владелец проекта.
		var allowed bool
		if e := tx.QueryRow(c.Context(), `
			SELECT app.can_manage_ext($2, $3)
			    OR EXISTS (SELECT 1 FROM app.task_ext_steps x
			                WHERE x.id = $1 AND x.task_id = $2
			                  AND x.assignee_id IN (SELECT app.effective_users($3)))`,
			stepID, taskID, uid).Scan(&allowed); e != nil {
			return e
		}
		if !allowed {
			notAssignee = true
			return nil
		}
		// Фактический срок: если исполнитель не указал дату явно —
		// проставляем сегодняшнюю при отметке, обнуляем при снятии.
		row := tx.QueryRow(c.Context(), `
			UPDATE app.task_ext_steps
			   SET done      = $3,
			       done_at   = CASE WHEN $3 THEN now() ELSE NULL END,
			       done_by   = CASE WHEN $3 THEN $4::uuid ELSE NULL END,
			       done_date = CASE WHEN $3 THEN COALESCE($5::date, current_date) ELSE NULL END
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, task_id, body, assignee_id, to_char(due_date, 'YYYY-MM-DD'),
			           done, to_char(done_date, 'YYYY-MM-DD'), done_by, position, created_by`,
			stepID, taskID, in.Done, uid, in.DoneDate)
		var e error
		st, e = scanExtStep(row)
		if e != nil {
			return e
		}
		verb := "Выполнен пункт расширенного чек-листа"
		if !in.Done {
			verb = "Снята отметка с пункта расширенного чек-листа"
		}
		entry := verb + " «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if notAssignee {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_allowed",
			"Отметить выполнение может исполнитель пункта, автор задачи, редактор или владелец проекта"))
	}
	go s.publishExtStep(taskID, st, "updated")
	s.republishTask(c, taskID)
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, st)
}

func (s *Server) DeleteExtStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var affected int64
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_ext($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять расширенный чек-лист может автор задачи, редактор или владелец проекта")
		}
		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.task_ext_steps WHERE id = $1 AND task_id = $2`, stepID, taskID)
		affected = tag.RowsAffected()
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	go s.publishExtStep(taskID, models.ExtStep{ID: stepID}, "deleted")
	s.republishTask(c, taskID)
	return httpx.NoContent(c)
}

// nullIfEmpty превращает пустую строку в nil, чтобы COALESCE в UPDATE
// сохранял прежний текст пункта, если клиент прислал только смену
// исполнителя или срока.
func nullIfEmpty(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

// republishTask перечитывает задачу и рассылает её как событие task —
// чтобы на карточках доски обновился счётчик расширенного чек-листа
// (он входит в агрегаты taskSelect). Ошибку намеренно глушим: это
// вторичная рассылка, и сбой перечитывания не должен ломать основной
// ответ обработчика.
func (s *Server) republishTask(c *fiber.Ctx, taskID uuid.UUID) {
	if t, err := s.loadTask(c, taskID); err == nil {
		go s.publishTask(t, "updated")
	}
}
