-- =====================================================================
-- 0005_updates.sql — доработки по замечаниям заказчика.
--
-- Применяется ПОСЛЕ 0003_rls.sql и ДО 0004_seed.sql:
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0005_updates.sql
--
-- Содержит только аддитивные изменения: новые таблицы, функции и
-- переопределение отдельных политик. Существующие данные не трогаются,
-- файл идемпотентен настолько, насколько это возможно в SQL
-- (CREATE ... IF NOT EXISTS, DROP POLICY IF EXISTS перед CREATE).
--
-- Все объекты создаются владельцем схемы (app_owner): SECURITY DEFINER
-- функции наследуют его права, как и в 0003_rls.sql.
-- =====================================================================

SET search_path = app, public;

-- ---------------------------------------------------------------------
-- П.7 — Наблюдатель (reader) может добавлять задачи; перемещать может
-- только автор задачи, редактор или владелец проекта.
--
-- Раньше политика tasks_insert требовала can_edit_board (owner/editor),
-- поэтому читатель создать задачу не мог. Ослабляем требование до
-- «любой участник проекта», сохраняя проверку авторства.
-- ---------------------------------------------------------------------

DROP POLICY IF EXISTS tasks_insert ON app.tasks;
CREATE POLICY tasks_insert ON app.tasks FOR INSERT
    WITH CHECK (
        -- Любой участник проекта (owner, editor ИЛИ reader): роль на
        -- доске просто не должна быть NULL.
        app.board_role(board_id, app.current_user_id()) IS NOT NULL
        AND created_by = app.current_user_id()
    );

-- Кто может перемещать задачу между колонками и внутри колонки:
-- автор задачи, редактор проекта, владелец проекта. Читатель, не
-- являющийся автором, — не может.
CREATE OR REPLACE FUNCTION app.can_move_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

-- Перемещение задачи вынесено в SECURITY DEFINER функцию, чтобы не
-- ослаблять общую политику tasks_update (она по-прежнему требует
-- права редактирования — edit). Функция сама проверяет can_move_task
-- и меняет ТОЛЬКО колонку и позицию, не открывая читателю-автору
-- возможность править содержание задачи.
--
-- Возвращает старую колонку (нужна вызывающему коду, чтобы разослать
-- обновления обеим затронутым колонкам) либо кидает исключение
-- move_denied, если прав нет.
CREATE OR REPLACE FUNCTION app.move_task(
    p_task uuid, p_user uuid, p_column uuid, p_position int)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_old_column uuid;
    v_is_done    boolean;
    v_col_title  text;
    v_pos        int := GREATEST(p_position, 0);
BEGIN
    IF NOT app.can_move_task(p_task, p_user) THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    -- Целевая колонка обязана принадлежать той же доске, что и задача:
    -- перенос задачи в чужой проект через move недопустим.
    SELECT t.column_id INTO v_old_column
      FROM app.tasks t
     WHERE t.id = p_task
       AND EXISTS (SELECT 1 FROM app.columns c
                    WHERE c.id = p_column AND c.board_id = t.board_id)
     FOR UPDATE;
    IF v_old_column IS NULL THEN
        RAISE EXCEPTION 'move_denied' USING ERRCODE = 'insufficient_privilege';
    END IF;

    -- Сдвигаем соседей в целевой колонке.
    UPDATE app.tasks SET position = position + 1
     WHERE column_id = p_column AND position >= v_pos AND id <> p_task;

    UPDATE app.tasks SET column_id = p_column, position = v_pos
     WHERE id = p_task;

    -- Уплотняем нумерацию в обеих затронутых колонках.
    WITH ordered AS (
        SELECT id, row_number() OVER (PARTITION BY column_id
                                      ORDER BY position, updated_at) - 1 AS pos
          FROM app.tasks WHERE column_id = ANY (ARRAY[v_old_column, p_column]))
    UPDATE app.tasks t SET position = o.pos FROM ordered o
     WHERE t.id = o.id AND t.position <> o.pos;

    -- Переезд в колонку завершения (и обратно) проставляет completed_at.
    IF v_old_column <> p_column THEN
        SELECT title, is_done INTO v_col_title, v_is_done
          FROM app.columns WHERE id = p_column;
        UPDATE app.tasks
           SET completed_at = CASE WHEN v_is_done THEN now() ELSE NULL END
         WHERE id = p_task;
        INSERT INTO app.activity (task_id, actor_id, body)
        VALUES (p_task, p_user, 'Перемещена в «' || v_col_title || '»');
    END IF;

    RETURN v_old_column;
END $$;

-- ---------------------------------------------------------------------
-- П.8 — Расширенные чек-листы.
--
-- Отдельная таблица, старый app.task_steps не трогаем. Для каждого
-- пункта: исполнитель, заданный автором срок, фактический срок и
-- отметка о выполнении.
--
-- Права:
--   • редактировать пункт (текст, исполнитель, срок, удаление) —
--     автор задачи, редактор проекта, владелец проекта;
--   • ставить/снимать отметку и фиксировать фактический срок —
--     только назначенный исполнитель пункта.
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS app.task_ext_steps (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id      uuid NOT NULL REFERENCES app.tasks(id) ON DELETE CASCADE,
    body         text NOT NULL CHECK (length(btrim(body)) > 0),
    -- Кому поручен пункт. NULL допустим: пункт может быть заведён
    -- до назначения исполнителя.
    assignee_id  uuid REFERENCES app.users(id) ON DELETE SET NULL,
    -- Срок, заданный автором задачи.
    due_date     date,
    -- Отметка о выполнении и фактический срок, проставленные
    -- исполнителем пункта.
    done         boolean NOT NULL DEFAULT false,
    done_date    date,       -- фактический срок выполнения
    done_at      timestamptz,
    done_by      uuid REFERENCES app.users(id) ON DELETE SET NULL,
    position     integer NOT NULL DEFAULT 0,
    created_by   uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS task_ext_steps_task_idx
    ON app.task_ext_steps (task_id, position);
CREATE INDEX IF NOT EXISTS task_ext_steps_assignee_idx
    ON app.task_ext_steps (assignee_id);

-- Кто может редактировать расширенный чек-лист задачи: автор задачи
-- или редактор/владелец проекта. Читатель-автор задачи тоже входит —
-- поэтому can_edit_task недостаточно (он не пускает reader).
CREATE OR REPLACE FUNCTION app.can_manage_ext(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (t.created_by IN (SELECT app.effective_users(p_user))
                OR app.board_role(t.board_id, p_user) IN ('owner', 'editor')))
$$;

ALTER TABLE app.task_ext_steps ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS task_ext_steps_select ON app.task_ext_steps;
CREATE POLICY task_ext_steps_select ON app.task_ext_steps FOR SELECT
    USING (app.can_see_task(task_id, app.current_user_id()));

DROP POLICY IF EXISTS task_ext_steps_insert ON app.task_ext_steps;
CREATE POLICY task_ext_steps_insert ON app.task_ext_steps FOR INSERT
    WITH CHECK (
        app.can_manage_ext(task_id, app.current_user_id())
        AND created_by = app.current_user_id()
    );

-- UPDATE разрешаем на уровне строки и менеджеру, и назначенному
-- исполнителю. Разграничение того, КАКИЕ колонки кому можно менять,
-- делает обработчик: менеджер правит текст/исполнителя/срок,
-- исполнитель — только отметку. RLS отвечает за то, кто вообще может
-- трогать строку.
DROP POLICY IF EXISTS task_ext_steps_update ON app.task_ext_steps;
CREATE POLICY task_ext_steps_update ON app.task_ext_steps FOR UPDATE
    USING (
        app.can_manage_ext(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id()))
    )
    WITH CHECK (
        app.can_manage_ext(task_id, app.current_user_id())
        OR assignee_id IN (SELECT app.effective_users(app.current_user_id()))
    );

DROP POLICY IF EXISTS task_ext_steps_delete ON app.task_ext_steps;
CREATE POLICY task_ext_steps_delete ON app.task_ext_steps FOR DELETE
    USING (app.can_manage_ext(task_id, app.current_user_id()));

-- Права на таблицу для рабочей роли (в 0003_rls.sql они выдаются на
-- уровне схемы GRANT ... ON ALL TABLES, но новая таблица создана
-- позже, поэтому выдаём явно).
GRANT SELECT, INSERT, UPDATE, DELETE ON app.task_ext_steps TO app_user;

-- ---------------------------------------------------------------------
-- П.5 — «Все задачи»: имя колонки нужно отдавать вместе с задачей.
-- Ничего в схеме менять не требуется — колонка уже связана внешним
-- ключом; выборка дорабатывается в коде (tasks.go). Отдельный
-- индекс для сортировки списка всех задач по сроку/дате не нужен:
-- объём на установку до нескольких тысяч задач сортируется в памяти.
-- ---------------------------------------------------------------------

-- Готово.
