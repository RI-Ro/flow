-- =====================================================================
-- 0009_updates5.sql — автор задачи (в т.ч. наблюдатель) управляет её
-- исполнителями.
--
-- Применяется ПОСЛЕ 0008_updates4.sql:
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0009_updates5.sql
--
-- Запускать от app_owner. Идемпотентно.
-- =====================================================================

SET search_path = app, public;

-- ---------------------------------------------------------------------
-- ПРИЧИНА.
--
-- Наблюдатель (reader) вправе создавать задачи в проекте (см. 0005).
-- Но при создании задачи с исполнителями обработчик пишет строки в
-- app.task_assignees, а политики task_assignees_write/_delete требуют
-- can_edit_task (уровень edit). У читателя такого уровня нет — вставка
-- исполнителя отклонялась, и вся транзакция создания падала с
-- «Недостаточно прав».
--
-- Исправление: назначать и снимать исполнителей может тот, кто может
-- редактировать задачу (owner/editor) ЛИБО автор самой задачи. Это же
-- согласуется с правом автора вести расширенный чек-лист.
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.can_assign_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (app.can_edit_task(p_task, p_user)
                OR t.created_by IN (SELECT app.effective_users(p_user))))
$$;

DROP POLICY IF EXISTS task_assignees_write ON app.task_assignees;
CREATE POLICY task_assignees_write ON app.task_assignees FOR INSERT
    WITH CHECK (app.can_assign_task(task_id, app.current_user_id()));

DROP POLICY IF EXISTS task_assignees_delete ON app.task_assignees;
CREATE POLICY task_assignees_delete ON app.task_assignees FOR DELETE
    USING (app.can_assign_task(task_id, app.current_user_id()));

-- Готово.
