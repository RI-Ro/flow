-- =====================================================================
-- 0006_updates2.sql — вторая порция доработок по замечаниям.
--
-- Применяется ПОСЛЕ 0005_updates.sql и ДО 0004_seed.sql (сид можно и
-- позже — он лишь наполняет данными):
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0006_updates2.sql
--
-- Только переопределение функций и политик + одна новая функция.
-- Идемпотентно (CREATE OR REPLACE / DROP POLICY IF EXISTS).
-- Запускать от app_owner, как и прочие миграции.
-- =====================================================================

SET search_path = app, public;

-- ---------------------------------------------------------------------
-- Читатель проекта: только просмотр содержимого.
--
-- Раньше роль reader давала уровень доступа 'contribute' на КАЖДУЮ
-- задачу проекта — из-за этого читатель мог отмечать пункты обычного
-- чек-листа и т.п. По требованию читатель, создавший задачу, может её
-- перемещать (см. app.can_move_task в 0005), но не может менять
-- содержимое, чек-лист и завершать её.
--
-- Теперь reader сам по себе даёт только 'read'. Уровень 'contribute'
-- читатель получает лишь как назначенный исполнитель или обладатель
-- точечного гранта конкретной задачи — то есть адресно, а не на весь
-- проект.
CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Исполнитель задачи (в т.ч. читатель, назначенный на эту задачу)
    -- может участвовать: отмечать свои части, свои пункты и т.п.
    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    -- Обладатель расширенного пункта чек-листа тоже должен видеть и
    -- участвовать в задаче (см. также синхронизацию доступа ниже).
    IF EXISTS (SELECT 1 FROM app.task_ext_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    -- Точечный грант на задачу.
    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    -- Читатель проекта: только просмотр.
    IF v_role = 'reader' THEN
        RETURN 'read';
    END IF;

    -- Автор задачи всегда видит её, даже если больше не состоит в
    -- проекте (создал в чужом проекте и потерял иные основания). Это
    -- только просмотр — редактирование требует роли в проекте.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'read';
    END IF;

    RETURN NULL;
END $$;

-- ---------------------------------------------------------------------
-- Завершение задачи: автор может закрыть задачу, только если он ещё и
-- редактор/владелец проекта. Читатель-автор завершать не может —
-- он лишь перемещает свою задачу (по требованию).
CREATE OR REPLACE FUNCTION app.can_close_task(p_task uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.tasks t
         WHERE t.id = p_task
           AND (app.board_role(t.board_id, p_user) = 'owner'
                OR (t.created_by IN (SELECT app.effective_users(p_user))
                    AND app.board_role(t.board_id, p_user) IN ('owner', 'editor'))))
$$;

-- ---------------------------------------------------------------------
-- Обычный чек-лист: отмечать пункты может тот, кто действительно
-- участвует в задаче как исполнитель или редактор — а не любой
-- читатель проекта. Раньше политика допускала 'contribute', который
-- читатель получал автоматически; после изменения task_access выше
-- читатель без назначения имеет только 'read', поэтому смысла у
-- прежней записи не осталось, но оставляем 'contribute' — теперь он
-- означает именно исполнителя/грантополучателя, что и требуется.
--
-- Явно переопределять политику не нужно: изменение task_access уже
-- сузило круг тех, у кого 'contribute'. Оставлено как заметка.

-- ---------------------------------------------------------------------
-- Расширенный чек-лист: отметку о выполнении может ставить исполнитель
-- пункта, а также автор задачи, редактор и владелец проекта.
-- Для этого используем can_manage_ext (автор/редактор/владелец) ИЛИ
-- совпадение исполнителя пункта. Политика обновления уже это
-- допускает (см. 0005). Разграничение «кому можно» переносим в
-- обработчик — здесь достаточно, чтобы строка была доступна.

-- ---------------------------------------------------------------------
-- Получатели realtime-событий задачи должны включать исполнителей
-- расширенных пунктов — иначе назначенный на пункт человек, не будучи
-- иначе связанным с задачей, не получит обновлений по ней.
CREATE OR REPLACE FUNCTION app.task_watchers(p_task uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    WITH base AS (
        SELECT m.user_id FROM app.tasks t
          JOIN app.board_members m ON m.board_id = t.board_id
         WHERE t.id = p_task
        UNION
        SELECT a.user_id FROM app.task_assignees a WHERE a.task_id = p_task
        UNION
        SELECT g.user_id FROM app.task_grants g WHERE g.task_id = p_task
        UNION
        SELECT x.assignee_id FROM app.task_ext_steps x
         WHERE x.task_id = p_task AND x.assignee_id IS NOT NULL
    )
    SELECT user_id FROM base
    UNION
    SELECT d.deputy_id FROM base b
      JOIN app.delegations d ON d.grantor_id = b.user_id
     WHERE current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Готово.
