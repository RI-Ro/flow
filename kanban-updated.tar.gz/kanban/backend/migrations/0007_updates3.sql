-- =====================================================================
-- 0007_updates3.sql — третья порция доработок.
--
-- Применяется ПОСЛЕ 0006_updates2.sql:
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0007_updates3.sql
--
-- Запускать от app_owner. Идемпотентно.
-- =====================================================================

SET search_path = app, public;

-- ---------------------------------------------------------------------
-- ПРИЧИНА ГЛАВНОЙ ПРАВКИ (задачи из «входящих» не попадали во «Все
-- задачи»).
--
-- Список задач формируется запросом с JOIN к app.boards и app.columns.
-- Оба JOIN — внутренние и подчиняются RLS. Если строка проекта или
-- колонки не видна пользователю, вся задача выпадает из результата,
-- даже когда сама задача ему видна (он исполнитель, есть грант или он
-- в расширенном чек-листе).
--
-- Для «входящей» задачи пользователь НЕ участник проекта, поэтому:
--   • columns_select требовал board_role IS NOT NULL — колонка была
--     невидима, и задача выпадала;
--   • can_see_board не учитывал расширенный чек-лист — проект тоже мог
--     быть невидим.
--
-- Ниже обе видимости расширяются до «вижу, если вижу хотя бы одну
-- задачу этого проекта/колонки».
-- ---------------------------------------------------------------------

-- Колонку видно, если пользователь состоит в проекте ЛИБО видит хотя бы
-- одну задачу этой колонки (входящая задача по гранту/исполнителю/
-- расширенному чек-листу).
DROP POLICY IF EXISTS columns_select ON app.columns;
CREATE POLICY columns_select ON app.columns FOR SELECT
    USING (
        app.board_role(board_id, app.current_user_id()) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
             WHERE t.column_id = columns.id
               AND app.can_see_task(t.id, app.current_user_id())));

-- Проект видно, если есть роль, грант, назначение ИЛИ участие в
-- расширенном чек-листе любой его задачи.
CREATE OR REPLACE FUNCTION app.can_see_board(p_board uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT app.board_role(p_board, p_user) IS NOT NULL
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_grants g ON g.task_id = t.id
             WHERE t.board_id = p_board
               AND g.user_id IN (SELECT app.effective_users(p_user)))
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_assignees a ON a.task_id = t.id
             WHERE t.board_id = p_board
               AND a.user_id IN (SELECT app.effective_users(p_user)))
        OR EXISTS (
            SELECT 1 FROM app.tasks t
              JOIN app.task_ext_steps x ON x.task_id = t.id
             WHERE t.board_id = p_board
               AND x.assignee_id IN (SELECT app.effective_users(p_user)))
$$;

-- ---------------------------------------------------------------------
-- Автоматическое добавление исполнителя расширенного пункта в
-- исполнители задачи.
--
-- Требование: назначение человека на пункт расширенного чек-листа
-- должно открывать ему доступ к задаче. Само по себе участие в ext-
-- чек-листе доступ уже даёт (task_access это учитывает), но чтобы
-- человек видел задачу и как «мою» на дашборде/во входящих и мог
-- отмечать свою часть, добавляем его в app.task_assignees.
--
-- Обычная политика task_assignees_write требует прав edit, а ext-чек-
-- лист может вести автор-читатель. Поэтому вставку делаем через
-- SECURITY DEFINER функцию, которая сама проверяет право вести
-- расширенный чек-лист (can_manage_ext).
CREATE OR REPLACE FUNCTION app.ensure_assignee(
    p_task uuid, p_assignee uuid, p_actor uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF p_assignee IS NULL THEN
        RETURN;
    END IF;
    IF NOT app.can_manage_ext(p_task, p_actor) THEN
        RAISE EXCEPTION 'ext_forbidden' USING ERRCODE = 'insufficient_privilege';
    END IF;
    INSERT INTO app.task_assignees (task_id, user_id)
    VALUES (p_task, p_assignee)
    ON CONFLICT (task_id, user_id) DO NOTHING;
END $$;

-- Готово.
