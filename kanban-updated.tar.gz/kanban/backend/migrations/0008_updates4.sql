-- =====================================================================
-- 0008_updates4.sql — устранение зависимости списка задач от видимости
-- строк проекта и колонки.
--
-- Применяется ПОСЛЕ 0007_updates3.sql:
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0008_updates4.sql
--
-- Запускать от app_owner. Идемпотентно.
-- =====================================================================

SET search_path = app, public;

-- ---------------------------------------------------------------------
-- ПРИЧИНА.
--
-- Список задач (taskSelect, Inbox, «Все задачи») делает INNER JOIN к
-- app.boards и app.columns ради названий проекта и колонки. Оба JOIN
-- подчиняются RLS: если пользователь не видит строку проекта или
-- колонки, задача выпадает из выборки целиком — даже если саму задачу
-- он видит (исполнитель, грант, расширенный чек-лист).
--
-- 0007 расширил видимость проектов и колонок, но это хрупко: любая
-- будущая правка политик может снова «уронить» входящие задачи. Здесь
-- мы убираем зависимость вовсе — названия берём через SECURITY DEFINER
-- функции, которые не подчиняются RLS и всегда возвращают заголовок,
-- если задача уже прошла RLS самой app.tasks.
-- ---------------------------------------------------------------------

CREATE OR REPLACE FUNCTION app.board_title(p_board uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT title FROM app.boards WHERE id = p_board
$$;

CREATE OR REPLACE FUNCTION app.column_title(p_column uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT title FROM app.columns WHERE id = p_column
$$;

GRANT EXECUTE ON FUNCTION app.board_title(uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.column_title(uuid) TO app_user;

-- Готово. Использование — в коде (tasks.go): вместо
--   JOIN app.boards b ON ...   → app.board_title(t.board_id)
--   JOIN app.columns col ON ...→ app.column_title(t.column_id)
