package config

import (
	"log"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

// FileConfig — полная структура config.yaml. Загружается опционально: если
// файла нет, используются значения по умолчанию + переменные окружения
// (env имеет приоритет над файлом, файл — над встроенными дефолтами).
type FileConfig struct {
	HTTP struct {
		Addr           string   `yaml:"addr"`
		AllowedOrigins []string `yaml:"allowed_origins"`
		Prefork        bool     `yaml:"prefork"`
	} `yaml:"http"`
	Database struct {
		URL      string `yaml:"url"`
		MaxConns int32  `yaml:"max_conns"`
		MinConns int32  `yaml:"min_conns"`
	} `yaml:"database"`
	Auth struct {
		JWTSecret string `yaml:"jwt_secret"`
		JWTTTL    string `yaml:"jwt_ttl"`
	} `yaml:"auth"`
	Pagination struct {
		PageSize    int `yaml:"page_size"`
		PageSizeMax int `yaml:"page_size_max"`
	} `yaml:"pagination"`
	Static struct {
		// Dir — путь к каталогу собранной статики фронтенда (Vite build, папка
		// dist). Если задан, приложение само раздаёт статику и делает SPA-
		// fallback на index.html (nginx не нужен). Пусто — статика не
		// раздаётся (режим «только API», фронт обслуживается отдельно).
		Dir string `yaml:"dir"`
	} `yaml:"static"`
	Realtime  RealtimeConfig  `yaml:"realtime"`
	Marking   MarkingConfig   `yaml:"marking"`
	Lifecycle LifecycleConfig `yaml:"lifecycle"`
	Branding  BrandingConfig  `yaml:"branding"`
	Numbering NumberingConfig `yaml:"numbering"`
}

// NumberingConfig — параметры формирования регистрационных номеров.
type NumberingConfig struct {
	// NumberPrefixForAll — УСТАРЕЛО и больше не используется. Формат номера
	// теперь: ИСХ-{префикс_подразделения}-{номер}/{год} (напр. ИСХ-9/8/7-231/2026,
	// ИСХ-ГУ-231/2026), без общего хвоста. Поле оставлено для обратной
	// совместимости конфигов и игнорируется.
	NumberPrefixForAll string `yaml:"number_prefix_for_all"`
}

// BrandingConfig — отображаемое название системы и подзаголовок (kicker).
// Отдаётся фронту через GET /api/app-config, чтобы «SED» и «// доведение
// указаний» не были захардкожены в интерфейсе.
type BrandingConfig struct {
	AppName   string `yaml:"app_name"`
	Tagline   string `yaml:"tagline"`
	Copyright string `yaml:"copyright"` // текст после "©" под кнопкой «Выйти»
	// About — справочная информация, контакты техподдержки, автор проекта и т.д.
	// Показывается в модальном окне при клике на "©". Многострочный текст
	// (переносы сохраняются). Полностью настраивается здесь.
	About string `yaml:"about"`
}

// LoadWithFile читает config.yaml (путь из env CONFIG_FILE или ./config.yaml),
// затем накладывает переменные окружения. Возвращает основной Config (как
// раньше) плюс расширенные секции (Marking, Lifecycle, Realtime), которых в
// плоском env быть не может.
func LoadWithFile() (Config, FileConfig) {
	return LoadWithFilePath("")
}

// LoadWithFilePath — как LoadWithFile, но с явным путём к конфигу (флаг
// --config). Приоритет пути: явный аргумент > env CONFIG_FILE > ./config.yaml.
func LoadWithFilePath(explicitPath string) (Config, FileConfig) {
	var fc FileConfig
	explicit := firstNonEmpty(explicitPath, os.Getenv("CONFIG_FILE"))
	path := firstNonEmpty(explicit, "config.yaml")
	data, readErr := os.ReadFile(path)
	if readErr != nil {
		// Если путь задан ЯВНО (флаг --config или env CONFIG_FILE) и файл не
		// читается — это ошибка конфигурации, а не «нет дефолтного файла».
		// Раньше ошибка молча проглатывалась и применялись дефолты — из-за
		// этого казалось, что --config «не читается».
		if explicit != "" {
			log.Fatalf("не удалось прочитать конфиг %q: %v", path, readErr)
		}
		log.Printf("конфиг %q не найден — используются значения по умолчанию и env", path)
	} else {
		if err := yaml.Unmarshal(data, &fc); err != nil {
			log.Fatalf("ошибка разбора YAML-конфига %q: %v", path, err)
		}
		log.Printf("конфиг загружен: %s", path)
	}

	// Значения по умолчанию для брендинга (если в файле не заданы).
	if fc.Branding.AppName == "" {
		fc.Branding.AppName = "SED"
	}
	if fc.Branding.Tagline == "" {
		fc.Branding.Tagline = "// доведение указаний"
	}
	if fc.Branding.Copyright == "" {
		fc.Branding.Copyright = fc.Branding.AppName + " · Система электронного документооборота"
	}
	// Хвост номеров: если не задан явно — берём app_name (обратная совместимость).
	if fc.Numbering.NumberPrefixForAll == "" {
		fc.Numbering.NumberPrefixForAll = fc.Branding.AppName
	}
	if fc.Branding.About == "" {
		fc.Branding.About = "Система электронного документооборота «" + fc.Branding.AppName + "».\n\n" +
			"Техническая поддержка: support@example.com, тел. +7 (000) 000-00-00.\n" +
			"Режим работы: пн–пт, 9:00–18:00.\n\n" +
			"Настройте этот текст в конфиге: branding.about."
	}

	// Env-override пути шрифта штампов (различается alpine/debian).
	if v := os.Getenv("MARKING_FONT_FILE"); v != "" {
		fc.Marking.FontFile = v
	}
	if v := os.Getenv("MARKING_FONT_NAME"); v != "" {
		fc.Marking.FontName = v
	}
	// Env-override каталога статики фронтенда (одно приложение раздаёт и API, и
	// статику; nginx не нужен).
	if v := os.Getenv("STATIC_DIR"); v != "" {
		fc.Static.Dir = v
	}

	cfg := Config{
		HTTPAddr:       firstNonEmpty(os.Getenv("HTTP_ADDR"), fc.HTTP.Addr, ":8080"),
		DatabaseURL:    firstNonEmpty(os.Getenv("DATABASE_URL"), fc.Database.URL, "postgres://sed:sed@localhost:5432/sed?sslmode=disable"),
		JWTSecret:      firstNonEmpty(os.Getenv("JWT_SECRET"), fc.Auth.JWTSecret, "CHANGE_ME_IN_PRODUCTION"),
		JWTTTL:         parseDurationOr(firstNonEmpty(os.Getenv("JWT_TTL"), fc.Auth.JWTTTL), 12*time.Hour),
		PageSize:       firstPositive(getEnvInt("PAGE_SIZE", 0), fc.Pagination.PageSize, 20),
		PageSizeMax:    firstPositive(getEnvInt("PAGE_SIZE_MAX", 0), fc.Pagination.PageSizeMax, 100),
		AllowedOrigins: firstNonEmpty(os.Getenv("ALLOWED_ORIGINS"), joinOrigins(fc.HTTP.AllowedOrigins), "http://localhost:5173,http://127.0.0.1:5173"),
		MigrationsDir:  getEnv("MIGRATIONS_DIR", "./migrations"),
	}
	return cfg, fc
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}

func firstPositive(vals ...int) int {
	for _, v := range vals {
		if v > 0 {
			return v
		}
	}
	return 0
}

func parseDurationOr(s string, fallback time.Duration) time.Duration {
	if d, err := time.ParseDuration(s); err == nil {
		return d
	}
	return fallback
}

func joinOrigins(origins []string) string {
	out := ""
	for i, o := range origins {
		if i > 0 {
			out += ","
		}
		out += o
	}
	return out
}
