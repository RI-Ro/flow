package handlers

import (
	"errors"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/config"
	"sed-system/backend/internal/marking"
	"sed-system/backend/internal/repository"
	"sed-system/backend/internal/service"
)

type DocumentsHandler struct {
	pool        *pgxpool.Pool
	repo        *repository.DocumentsRepo
	incoming    *service.IncomingService
	markingData *service.MarkingDataService
	markingCfg  config.MarkingConfig
	pageSize    int
	pageMax     int
}

func NewDocumentsHandler(pool *pgxpool.Pool, repo *repository.DocumentsRepo, incoming *service.IncomingService, markingData *service.MarkingDataService, markingCfg config.MarkingConfig, pageSize, pageMax int) *DocumentsHandler {
	return &DocumentsHandler{pool: pool, repo: repo, incoming: incoming, markingData: markingData, markingCfg: markingCfg, pageSize: pageSize, pageMax: pageMax}
}

// List GET /api/documents?category=on_approval&page=2&department_id=4
func (h *DocumentsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	category := repository.Category(c.Query("category", "all"))
	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}
	deptID, _ := strconv.ParseInt(c.Query("department_id", "0"), 10, 64)

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Если подразделение не задано явно — берём основное подразделение
		// пользователя. Иначе категория «Исходящие» (фильтр по
		// author_department_id) оказывалась пустой (deptID=0 не совпадает ни
		// с одним документом) — из-за этого у автора не отображались исходящие.
		if deptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
				return e
			}
		}
		year, _ := strconv.Atoi(c.Query("year"))
		res, err := h.repo.List(c.Context(), tx, category, userID, deptID, page, pageSize, year)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to list documents")
	}
	return c.JSON(result)
}

// GetMarking GET /api/documents/:id/marking — вычисленные штампы для overlay
// на фронте (текст с подставленными плейсхолдерами, позиция, цвет, размер,
// рамка). Поле baked=true, если бэкенд уже вжигает штампы в PDF (тогда фронт
// overlay не рисует). Данные считаются по той же логике, что и вжигание.
func (h *DocumentsHandler) GetMarking(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверяем, что документ виден текущему пользователю (RLS) — иначе
		// не отдаём его реквизиты маркировки.
		var one int
		if err := tx.QueryRow(c.Context(), `SELECT 1 FROM documents WHERE id=$1`, id).Scan(&one); err != nil {
			return err
		}
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to compute marking")
	}

	specs := marking.ComputeSpecs(h.markingCfg, placeholders)
	stamps := make([]fiber.Map, 0, len(specs))
	for _, s := range specs {
		stamps = append(stamps, fiber.Map{
			"text":         s.Text,
			"position":     s.Position, // tl/tr/bl/br/c
			"offset_x":     s.OffsetX,
			"offset_y":     s.OffsetY,
			"font_size":    s.FontSize,
			"color":        s.ColorHex,
			"border":       s.Border,
			"border_color": s.BorderColorHex,
			"fill":         s.FillColorHex,
			// Факсимиле/печать как data-URL — для двухколоночного штампа
			// (слева изображение, справа текст).
			"image": marking.ImageDataURL(s.ImageFile),
		})
	}
	return c.JSON(fiber.Map{"stamps": stamps, "baked": marking.IsBaking()})
}

// Get GET /api/documents/:id
func (h *DocumentsHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var doc any
	var marking *service.IncomingMarking
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		d, err := h.repo.GetByID(c.Context(), tx, id)
		if err != nil {
			return err
		}
		doc = d

		// Регистрация во "входящих" при отображении получателем — по ТЗ:
		// "при отображении полученного документа должна фиксироваться
		// информация об экземпляре и наноситься доп. маркировка". Не
		// критично для показа документа, поэтому ошибку здесь не считаем
		// фатальной для всего запроса — только логируем через возврат err
		// наверх было бы избыточно строго; но раз транзакция общая, пусть
		// падает вместе с остальным (согласованность важнее отказоустойчивости
		// в рамках одного запроса).
		m, err := h.incoming.RegisterView(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		marking = m

		// Журнал просмотров. Дедупликация: не создаём новую запись, если тот
		// же пользователь открывал этот документ в последние 10 секунд.
		// Это убирает дубли от повторного рендера (React StrictMode в dev
		// вызывает эффекты дважды) и быстрых повторных запросов, но сохраняет
		// историю реально разных обращений.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_views (document_id, viewer_id)
			SELECT $1, $2
			WHERE NOT EXISTS (
				SELECT 1 FROM document_views
				WHERE document_id = $1 AND viewer_id = $2
				  AND viewed_at > now() - interval '10 seconds'
			)`, id, userID); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			// 404 независимо от того, документ не существует или скрыт RLS —
			// не раскрываем факт существования документа без доступа.
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get document")
	}
	return c.JSON(fiber.Map{"document": doc, "incoming_marking": marking})
}

// Search GET /api/documents/search?q=...&page=1&page_size=20
func (h *DocumentsHandler) Search(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}

	filter := repository.SearchFilter{
		Category:       c.Query("category"),
		UserID:         userID,
		Query:          c.Query("q"),
		DueFrom:        c.Query("due_from"),
		DueTo:          c.Query("due_to"),
		CreatedFrom:    c.Query("created_from"),
		CreatedTo:      c.Query("created_to"),
		SignedFrom:     c.Query("signed_from"),
		SignedTo:       c.Query("signed_to"),
		Number:         c.Query("number"),
		IncomingNumber: c.Query("incoming_number"),
		OnControl:      c.Query("on_control"),
	}
	parseID := func(name string) int64 {
		if v := c.Query(name); v != "" {
			id, _ := strconv.ParseInt(v, 10, 64)
			return id
		}
		return 0
	}
	filter.AuthorID = parseID("author_id")
	filter.SignerID = parseID("signer_id")
	filter.ControllerID = parseID("controller_id")
	filter.ApproverID = parseID("approver_id")
	filter.RecipientID = parseID("recipient_id")
	filter.DepartmentID = parseID("department_id")
	if v := c.Query("status"); v != "" {
		filter.Statuses = splitCSV(v)
	}
	if v := c.Query("urgency"); v != "" {
		filter.Urgencies = splitCSV(v)
	}

	// Категория задаёт контекст поиска — если она есть, пустой набор фильтров
	// допустим (просто применяется ограничение категории).
	catScoped := filter.Category != "" && filter.Category != "all"
	empty := !catScoped && filter.Query == "" && filter.AuthorID == 0 && filter.SignerID == 0 &&
		filter.ControllerID == 0 && filter.ApproverID == 0 && filter.RecipientID == 0 &&
		filter.DepartmentID == 0 && len(filter.Statuses) == 0 && len(filter.Urgencies) == 0 &&
		filter.OnControl == "" && filter.DueFrom == "" && filter.DueTo == "" &&
		filter.CreatedFrom == "" && filter.CreatedTo == "" &&
		filter.SignedFrom == "" && filter.SignedTo == "" &&
		filter.Number == "" && filter.IncomingNumber == ""
	if empty {
		return fiber.NewError(fiber.StatusBadRequest, "укажите хотя бы один фильтр")
	}

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Для категории «Исходящие» нужно подразделение пользователя.
		if filter.Category == string(repository.CategoryOutgoing) && filter.DeptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&filter.DeptID); e != nil {
				return e
			}
		}
		res, err := h.repo.Search(c.Context(), tx, filter, page, pageSize)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "failed to search documents")
	}
	return c.JSON(result)
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		p := strings.TrimSpace(part)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// GetStages GET /api/documents/:id/stages
func (h *DocumentsHandler) GetStages(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var stages any
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Явно проверяем видимость документа по RLS перед выдачей маршрута —
		// approval_stages не защищена собственной RLS-политикой (см. комментарий
		// в repository.ListStages), поэтому проверка здесь обязательна.
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		s, err := h.repo.ListStages(c.Context(), tx, id)
		if err != nil {
			return err
		}
		stages = s
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get stages")
	}
	return c.JSON(fiber.Map{"items": stages})
}

// GetFile GET /api/documents/:id/file — отдаёт PDF только для просмотра
// (inline), без возможности скачивания через отдельный "download"-эндпоинт.
func (h *DocumentsHandler) GetFile(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}

	var content []byte
	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// document_files не имеет собственной RLS-политики, но JOIN на
		// documents гарантирует, что мы не отдадим файл документа, невидимого
		// по RLS текущему пользователю (documents.id IN (...) сработает как
		// фильтр даже внутри JOIN, т.к. RLS применяется к каждой строке documents).
		if err := tx.QueryRow(c.Context(), `
			SELECT f.content FROM document_files f
			JOIN documents d ON d.id = f.document_id
			WHERE f.document_id = $1`, id).Scan(&content); err != nil {
			return err
		}
		// Собираем данные для маркировки (номера, подпись, получение).
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		// Подразделение смотрящего — для отметки о получении.
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "file not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to get file")
	}

	// Накладываем штампы из конфига на КОПИЮ (оригинал в БД неизменен).
	// Если маркировка упала (напр. кривой PDF) — отдаём оригинал, чтобы не
	// ломать просмотр; ошибку логируем.
	marked, err := marking.Apply(content, h.markingCfg, placeholders)
	if err != nil {
		log.Printf("marking failed for doc %d: %v", id, err)
		marked = content
	}

	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", "inline")
	c.Set("X-Content-Type-Options", "nosniff")
	// Ограничиваем встраивание/кэширование на уровне браузера — это UX-барьер,
	// не криптографическая защита; абсолютной защиты от скриншота/печати
	// браузера не даёт ни одна веб-система.
	c.Set("Cache-Control", "no-store")
	c.Set("Content-Security-Policy", "frame-ancestors 'self'")
	return c.Send(marked)
}

// History GET /api/documents/:id/history — журнал событий документа
// (вкладка "История документа").
func (h *DocumentsHandler) History(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type event struct {
		EventType  string  `json:"event_type"`
		ActorName  *string `json:"actor_name,omitempty"`
		FromStatus *string `json:"from_status,omitempty"`
		ToStatus   *string `json:"to_status,omitempty"`
		Comment    *string `json:"comment,omitempty"`
		CreatedAt  string  `json:"created_at"`
	}
	var items []event
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT h.event_type, u.full_name, h.from_status::text, h.to_status::text, h.comment,
			       to_char(h.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_history h
			LEFT JOIN users u ON u.id = h.actor_id
			WHERE h.document_id = $1
			ORDER BY h.created_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var e event
			if err := rows.Scan(&e.EventType, &e.ActorName, &e.FromStatus, &e.ToStatus, &e.Comment, &e.CreatedAt); err != nil {
				return err
			}
			items = append(items, e)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load history")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Views GET /api/documents/:id/views — журнал просмотров (вкладка "История
// просмотров").
func (h *DocumentsHandler) Views(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	type view struct {
		ViewerName string `json:"viewer_name"`
		ViewedAt   string `json:"viewed_at"`
	}
	var items []view
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		// Первый просмотр КАЖДОГО пользователя (DISTINCT ON по viewer_id,
		// берём самую раннюю запись). ФИО с должностью.
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT ON (v.viewer_id)
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       to_char(v.viewed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_views v JOIN users u ON u.id = v.viewer_id
			WHERE v.document_id = $1
			ORDER BY v.viewer_id, v.viewed_at ASC
			LIMIT 500`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var vw view
			if err := rows.Scan(&vw.ViewerName, &vw.ViewedAt); err != nil {
				return err
			}
			items = append(items, vw)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load views")
	}
	return c.JSON(fiber.Map{"items": items})
}

// SetControl POST /api/documents/:id/control — поставить/снять документ с
// контроля и (опционально) назначить контролёра. Тело:
// { "on_control": true, "controller_id": 4 }
func (h *DocumentsHandler) SetControl(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	var req struct {
		OnControl    bool  `json:"on_control"`
		ControllerID int64 `json:"controller_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid body")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var controller *int64
		if req.ControllerID != 0 {
			controller = &req.ControllerID
			// Контролёром можно назначить ТОЛЬКО пользователя с ролью
			// controller (соответствие админке). Иначе — 422, чтобы нельзя
			// было назначить того, кому право не выдано (в т.ч. в обход UI).
			if !isAdmin {
				var hasRole bool
				if err := tx.QueryRow(c.Context(), `
					SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role='controller')`,
					req.ControllerID).Scan(&hasRole); err != nil {
					return err
				}
				if !hasRole {
					return errControllerRole
				}
			}
		}
		_, err := tx.Exec(c.Context(),
			`UPDATE documents SET on_control=$1, controller_id=$2 WHERE id=$3`,
			req.OnControl, controller, id)
		if err != nil {
			return err
		}
		// История: постановка/снятие с контроля (для отображения факта).
		evt := "removed_from_control"
		if req.OnControl {
			evt = "put_on_control"
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type)
			VALUES ($1, $2, $3)`, id, userID, evt); err != nil {
			return err
		}
		// Уведомим назначенного контролёра.
		if req.OnControl && controller != nil {
			_, _ = tx.Exec(c.Context(), `
				INSERT INTO notifications (user_id, document_id, kind, payload)
				VALUES ($1, $2, 'control_assigned', '{}')`, *controller, id)
			_, _ = tx.Exec(c.Context(), `
				INSERT INTO document_access (document_id, user_id, access_reason)
				VALUES ($1, $2, 'controller') ON CONFLICT DO NOTHING`, id, *controller)
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errControllerRole) {
			return fiber.NewError(fiber.StatusUnprocessableEntity, "контролёром можно назначить только пользователя с ролью «контролёр»")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить контроль")
	}
	return c.SendStatus(fiber.StatusOK)
}

// MyRoles GET /api/documents/:id/my-roles — в каких качествах текущий
// пользователь участвует в документе. Фронт по этому ответу показывает/скрывает
// вкладки (не участник согласования не видит вкладку маршрута и т.д.).
func (h *DocumentsHandler) MyRoles(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "invalid id")
	}
	res := fiber.Map{
		"is_author":     false,
		"is_approver":   false,
		"is_signer":     false,
		"is_controller": false,
		"is_recipient":  false,
		"is_admin":      isAdmin,
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID int64
		var controllerID *int64
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, controller_id FROM documents WHERE id=$1`, id).Scan(&authorID, &controllerID); err != nil {
			return err
		}
		res["is_author"] = authorID == userID
		res["is_controller"] = controllerID != nil && *controllerID == userID

		// Согласующий или подписант — по этапам маршрута.
		var approverCnt, signerCnt int
		if err := tx.QueryRow(c.Context(), `
			SELECT
			  count(*) FILTER (WHERE stage_type IN ('hierarchy','cross_dept')),
			  count(*) FILTER (WHERE stage_type = 'signing')
			FROM approval_stages WHERE document_id=$1 AND approver_id=$2`, id, userID).
			Scan(&approverCnt, &signerCnt); err != nil {
			return err
		}
		res["is_approver"] = approverCnt > 0
		res["is_signer"] = signerCnt > 0

		// Получатель рассылки.
		var recipCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM document_recipients WHERE document_id=$1 AND recipient_user_id=$2`, id, userID).
			Scan(&recipCnt); err != nil {
			return err
		}
		res["is_recipient"] = recipCnt > 0
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "document not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "failed to load roles")
	}
	return c.JSON(res)
}
