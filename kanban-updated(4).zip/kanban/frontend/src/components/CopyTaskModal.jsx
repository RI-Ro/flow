import React, { useEffect, useState } from "react";
import { Copy } from "lucide-react";
import { api } from "../lib/api.js";
import { orderedBoards } from "../lib/theme.js";
import { Modal, ModalHeader, Field, inputStyle } from "../lib/ui.jsx";

// Модалка копирования задачи (п.4): спрашивает, в какой проект и какую
// колонку копировать. Проекты — только те, где пользователь может
// создавать задачи (участник в любой роли: owner/editor/reader).
// Колонки подгружаются при выборе проекта.
export default function CopyTaskModal({ theme, task, boards, onClose, onCopied, onError }) {
  // По умолчанию предлагаем текущий проект задачи, если он в списке.
  const [boardId, setBoardId] = useState(
    boards.some((b) => b.id === task.boardId) ? task.boardId : (boards[0]?.id || "")
  );
  const [columns, setColumns] = useState([]);
  const [columnId, setColumnId] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!boardId) { setColumns([]); setColumnId(""); return; }
    let alive = true;
    api.columns(boardId)
      .then((cols) => {
        if (!alive) return;
        setColumns(cols);
        // Если копируем в тот же проект — предлагаем ту же колонку.
        const same = boardId === task.boardId && cols.some((c) => c.id === task.columnId);
        setColumnId(same ? task.columnId : (cols[0]?.id || ""));
      })
      .catch((e) => onError(e.message));
    return () => { alive = false; };
  }, [boardId, task.boardId, task.columnId, onError]);

  const submit = async () => {
    if (!boardId || !columnId) return onError("Выберите проект и колонку");
    setBusy(true);
    try {
      const copy = await api.copyTask(task.id, boardId, columnId);
      onCopied(copy, boardId);
    } catch (e) {
      onError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm">
      <ModalHeader theme={theme} title="Копировать задачу"
        subtitle={`«${task.title}» будет скопирована вместе с чек-листами`} onClose={onClose} />

      <Field label="Проект" theme={theme}>
        <select value={boardId} onChange={(e) => setBoardId(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-2 py-2 text-[13px] outline-none">
          {boards.length === 0 && <option value="">Нет доступных проектов</option>}
          {orderedBoards(boards).map((b) => <option key={b.id} value={b.id}>{"\u00A0\u00A0".repeat(b.depth) + b.title}</option>)}
        </select>
      </Field>

      <Field label="Колонка" theme={theme}>
        <select value={columnId} onChange={(e) => setColumnId(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-2 py-2 text-[13px] outline-none">
          {columns.length === 0 && <option value="">—</option>}
          {columns.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
        </select>
      </Field>

      <p style={{ color: theme.textMuted }} className="text-[11.5px] leading-relaxed mb-3">
        Исполнители и точечный доступ не копируются — назначьте их в новой задаче отдельно.
        После копирования откроется выбранный проект и форма новой задачи —
        дальнейшая работа идёт уже в ней.
      </p>

      <div className="flex gap-2">
        <button onClick={onClose} style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }} className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={submit} disabled={busy || !boardId || !columnId}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50">
          <Copy size={14} /> {busy ? "Копируем…" : "Копировать"}
        </button>
      </div>
    </Modal>
  );
}
