package handlers

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// Конвертация офисных документов в PDF для предпросмотра.
//
// Зачем вообще. Разбор docx на клиенте (mammoth) даёт текст, но теряет
// вёрстку: колонки, отступы, колонтитулы, подписи в таблицах. Для
// «глянуть, о чём документ» этого хватает, для «прочитать документ,
// который прислал контрагент» — нет. А .doc, .odt и .rtf браузером не
// разбираются вовсе.
//
// Поэтому документ превращает в PDF сам сервер, тем же LibreOffice,
// которым его открыли бы вручную, и в браузер уходит PDF — формат, с
// которым браузер справляется без чужой помощи.
//
// ВАЖНО: нужен установленный LibreOffice (пакет libreoffice или
// libreoffice-writer + libreoffice-calc). Если его нет, предпросмотр
// офисных форматов отвечает понятной ошибкой, всё остальное работает
// как прежде. Проверить: `soffice --version`.

// Форматы, которые отдаём на конвертацию. PDF и картинки сюда не
// попадают: они и так показываются напрямую.
var convertible = map[string]bool{
	".doc": true, ".docx": true, ".odt": true, ".rtf": true,
	".xls": true, ".xlsx": true, ".ods": true, ".csv": true,
	".ppt": true, ".pptx": true, ".odp": true,
}

func convertibleName(filename string) bool {
	return convertible[strings.ToLower(filepath.Ext(filename))]
}

// Конвертация — дело небыстрое (первый запуск LibreOffice занимает
// секунды), поэтому результат кладётся рядом с исходником и больше не
// пересчитывается: исходный файл неизменен, значит и PDF из него тоже.
//
// Замок на ключ: два человека, одновременно открывшие один документ,
// не должны запускать два конвертера на один и тот же файл.
var convertLocks sync.Map

func lockFor(key string) *sync.Mutex {
	m, _ := convertLocks.LoadOrStore(key, &sync.Mutex{})
	return m.(*sync.Mutex)
}

// pdfKeyFor — ключ кэша. Складывается из ключа исходника, поэтому
// удаление исходного файла не оставляет «висящий» PDF под чужим именем.
func pdfKeyFor(key string) string { return key + ".preview.pdf" }

// ensurePDF возвращает ключ PDF-версии файла, при необходимости
// создавая её.
func (s *Server) ensurePDF(ctx context.Context, key, filename string) (string, error) {
	if !convertibleName(filename) {
		return "", errors.New("формат не конвертируется")
	}

	pdfKey := pdfKeyFor(key)
	if s.files.Exists(pdfKey) {
		return pdfKey, nil
	}

	mu := lockFor(key)
	mu.Lock()
	defer mu.Unlock()
	// Пока ждали замок, сосед мог всё сделать за нас.
	if s.files.Exists(pdfKey) {
		return pdfKey, nil
	}

	srcPath, err := s.files.Path(key)
	if err != nil {
		return "", err
	}
	pdfPath, err := s.files.Path(pdfKey)
	if err != nil {
		return "", err
	}

	// LibreOffice умеет складывать результат только в каталог и только
	// под именем исходника, поэтому работаем во временной папке и потом
	// переносим файл под нужное имя.
	tmp, err := os.MkdirTemp("", "kanban-conv-")
	if err != nil {
		return "", err
	}
	defer os.RemoveAll(tmp)

	// Минута с запасом: первый запуск поднимает профиль LibreOffice,
	// дальше конвертация укладывается в секунды. Без предела зависший
	// процесс держал бы запрос до бесконечности.
	runCtx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()

	cmd := exec.CommandContext(runCtx, "soffice",
		"--headless", "--norestore", "--nolockcheck",
		// Свой профиль на каждый запуск: общий каталог настроек —
		// известный источник зависаний при одновременных запусках.
		"-env:UserInstallation=file://"+filepath.Join(tmp, "profile"),
		"--convert-to", "pdf", "--outdir", tmp, srcPath)

	out, err := cmd.CombinedOutput()
	if err != nil {
		slog.Error("конвертация документа не удалась",
			"error", err, "file", filename, "output", string(out))
		if errors.Is(runCtx.Err(), context.DeadlineExceeded) {
			return "", errors.New("конвертация заняла слишком много времени")
		}
		if errors.Is(err, exec.ErrNotFound) {
			return "", errors.New("на сервере не установлен LibreOffice — предпросмотр этого формата недоступен")
		}
		return "", fmt.Errorf("не удалось подготовить предпросмотр")
	}

	// Имя результата LibreOffice выбирает сам: исходное имя с
	// расширением .pdf.
	produced := filepath.Join(tmp, strings.TrimSuffix(filepath.Base(srcPath),
		filepath.Ext(srcPath))+".pdf")
	if _, err := os.Stat(produced); err != nil {
		// Бывает, когда исходник назван без расширения: ищем любой pdf
		// в каталоге.
		matches, _ := filepath.Glob(filepath.Join(tmp, "*.pdf"))
		if len(matches) == 0 {
			return "", errors.New("конвертер не создал файл")
		}
		produced = matches[0]
	}

	if err := os.MkdirAll(filepath.Dir(pdfPath), 0o750); err != nil {
		return "", err
	}
	data, err := os.ReadFile(produced)
	if err != nil {
		return "", err
	}
	if err := os.WriteFile(pdfPath, data, 0o640); err != nil {
		return "", err
	}
	return pdfKey, nil
}
