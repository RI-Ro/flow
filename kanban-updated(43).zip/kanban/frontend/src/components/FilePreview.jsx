import React, { useEffect, useState } from "react";
import { Download, FileText, AlertTriangle, Maximize2, Minimize2 } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, Spinner } from "../lib/ui.jsx";

// Предпросмотр файла в модальном окне, без скачивания.
//
// Что чем открывается:
//
//   • изображения — как есть;
//   • PDF — встроенным просмотрщиком браузера;
//   • офисные документы и таблицы (doc, docx, odt, rtf, xls, xlsx, ods,
//     ppt, pptx, csv) — сервер переконвертирует их в PDF, и показывается
//     он.
//
// Почему конвертация на сервере, а не разбор на клиенте. Клиентский
// разбор docx давал текст без вёрстки — колонки, отступы, колонтитулы
// и подписи в таблицах терялись, — а .doc, .odt и .rtf не
// разбирались вовсе. Сервер конвертирует тем же LibreOffice, которым
// документ открыли бы вручную, результат кэширует, и в браузер уходит
// PDF: формат, с которым браузер справляется сам.
//
// Показанный PDF — копия, а не оригинал, и человек об этом
// предупреждён: рядом висит ссылка на скачивание исходного файла.

const IMAGE = /^image\//;

// Офисные форматы показываются переконвертированными в PDF на сервере.
//
// Разбор на клиенте давал текст без вёрстки (mammoth), а .doc, .odt и
// .rtf не открывались вовсе. Сервер конвертирует их тем же
// LibreOffice, которым их открыли бы вручную, и в браузер уходит PDF —
// формат, с которым браузер справляется сам.
const OFFICE = [
  "doc", "docx", "odt", "rtf",
  "xls", "xlsx", "xlsm", "xltx", "ods", "csv", "tsv",
  "ppt", "pptx", "odp",
];

function kindOf(filename, mime) {
  const ext = (filename || "").toLowerCase().split(".").pop();
  if (IMAGE.test(mime || "")) return "image";
  if (mime === "application/pdf" || ext === "pdf") return "pdf";
  if (OFFICE.includes(ext)) return "office";
  return "none";
}

// Скачивание оригинала: тем же запросом с токеном, что и всё
// остальное, — прямая ссылка получила бы 401.
async function downloadOriginal(path, filename) {
  try {
    const blob = await api.fileBlob(path);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename || "файл";
    a.click();
    URL.revokeObjectURL(url);
  } catch {
    /* причина та же, что и у неудавшегося предпросмотра, и она видна
       в окне */
  }
}

export default function FilePreview({ theme, title, filename, mime, path, pdfPath, downloadPath, onClose }) {
  const [state, setState] = useState({ loading: true });
  // Во весь экран — для чертежей, таблиц и многостраничных документов:
  // в окне по центру их приходится листать по кусочку.
  const [full, setFull] = useState(false);
  const kind = kindOf(filename, mime);

  useEffect(() => {
    let url = null;
    let cancelled = false;

    (async () => {
      if (kind === "none") {
        setState({ loading: false });
        return;
      }
      try {
        // Офисные форматы забираем уже в виде PDF: конвертацию делает
        // сервер и кэширует результат, поэтому повторное открытие
        // мгновенно.
        const blob = await api.fileBlob(kind === "office" ? pdfPath : path);
        if (cancelled) return;
        url = URL.createObjectURL(blob);
        setState({ loading: false, url, converted: kind === "office" });
      } catch (e) {
        if (!cancelled) setState({ loading: false, error: e.message || "Не удалось открыть файл" });
      }
    })();

    return () => {
      cancelled = true;
      // blob-ссылку нужно освобождать руками: иначе файл висит в памяти
      // до перезагрузки страницы, а вложения бывают на десятки
      // мегабайт.
      if (url) URL.revokeObjectURL(url);
    };
  }, [kind, path, pdfPath]);

  return (
    <Modal theme={theme} onClose={onClose} padded={false}
      width={full ? "max-w-[98vw]" : "max-w-5xl"}
      geometryKey={full ? null : "file-preview"}>
      <div className="p-4 pb-2">
        <ModalHeader theme={theme} title={title || filename} onClose={onClose}
          subtitle={filename}
          extra={(
            <button onClick={() => setFull((v) => !v)} style={{ color: theme.textMuted }}
              title={full ? "Вернуть обычный размер" : "Во весь экран"}>
              {full ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>
          )} />
      </div>

      <div className="px-4 pb-4">
        {state.loading && <Spinner theme={theme} label="Открываем файл…" />}

        {state.error && (
          <p style={{ color: theme.danger }} className="text-[13px] py-6 text-center">
            {state.error}
          </p>
        )}

        {!state.loading && kind === "none" && (
          <div className="py-8 text-center">
            <AlertTriangle size={22} style={{ color: theme.textMuted }} className="mx-auto mb-2" />
            <p style={{ color: theme.text }} className="text-[13px] font-medium mb-1">
              Этот формат в окне не открывается
            </p>
            <p style={{ color: theme.textMuted }} className="text-[12px] leading-relaxed max-w-md mx-auto">
              Старый .doc и .odt — двоичные и упакованные форматы, для которых нет надёжного
              браузерного разбора. Показывать их наполовину хуже, чем не показывать: по документам
              принимают решения. Скачайте и откройте в своей программе.
            </p>
          </div>
        )}

        {state.url && kind === "image" && (
          <img src={state.url} alt={filename}
            className="max-w-full mx-auto rounded-lg"
            style={{ maxHeight: full ? "82vh" : "70vh", border: `1px solid ${theme.border}` }} />
        )}

        {state.url && (kind === "pdf" || kind === "office") && (
          <>
            {/* Предупреждение обязательно: показывается не сам файл, а
                его копия. Расстановка страниц, шрифты и мелкие детали
                вёрстки могут отличаться, и человек должен знать, что
                сверять с оригиналом — при необходимости — нужно по
                скачанному файлу. */}
            {state.converted && (
              <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}`, color: theme.text }}
                className="rounded-lg px-3 py-2 mb-2 flex items-start gap-2 text-[12px] leading-relaxed">
                <AlertTriangle size={14} style={{ color: theme.warning || theme.accent2 }} className="mt-0.5 shrink-0" />
                <span>
                  Показана версия файла, переконвертированная в PDF. Разметка может слегка
                  отличаться от оригинала.{" "}
                  <button onClick={() => downloadOriginal(downloadPath || path, filename)}
                    style={{ color: theme.accent }} className="font-medium underline">
                    Скачать оригинал
                  </button>
                </span>
              </div>
            )}
            <iframe src={state.url} title={filename}
              style={{ width: "100%", height: full ? "82vh" : "68vh", border: `1px solid ${theme.border}` }}
              className="rounded-lg" />
          </>
        )}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t px-4 py-3 flex items-center gap-2">
        <FileText size={14} style={{ color: theme.textMuted }} />
        <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate flex-1">
          {filename}
        </span>
        <a href={downloadPath ? `/api${downloadPath}` : undefined}
          onClick={async (e) => {
            // Скачивание тоже идёт через запрос с токеном: прямая
            // ссылка получила бы 401, поэтому файл берётся blob-ом и
            // сохраняется программно.
            e.preventDefault();
            try {
              const blob = await api.fileBlob(downloadPath || path);
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = filename || "файл";
              a.click();
              URL.revokeObjectURL(url);
            } catch {
              /* ошибку показывать здесь незачем: причина та же, что и
                 у неудавшегося предпросмотра, и она уже видна выше */
            }
          }}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-medium">
          <Download size={13} /> Скачать
        </a>
      </div>
    </Modal>
  );
}
