import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  MessageSquarePlus, UsersRound, Search, Send, Paperclip, Pencil, Trash2,
  Check, CheckCheck, X, UserPlus, LogOut, Smile, BarChart3, Eraser, Video,
  Image as ImageIcon,
} from "lucide-react";
import { api } from "../lib/api.js";
import { conferenceLink, fmtDateTime, resolveUser, videoCallLink } from "../lib/theme.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { Avatar, Modal, ModalHeader, Spinner, MultilineField, ConfirmDialog, inputStyle } from "../lib/ui.jsx";
import AnimatedEmoji, { ANIMATED } from "./AnimatedEmoji.jsx";
import FilePreview from "./FilePreview.jsx";
import AuthImage from "./AuthImage.jsx";

// Вкладка переписки: слева список чатов, справа выбранный разговор.
//
// Почему переписка вообще отдельно от задач. Комментарий в задаче виден
// всем, кто видит задачу, и живёт вместе с ней; разговор — только его
// участникам и независимо от проектов. Спрашивать «ты посмотрел смету?»
// в комментариях к задаче значит либо открывать задачу лишним людям,
// либо не спрашивать вовсе.
//
// Личный чат называется именем собеседника и не переименовывается —
// название ему заменяет сам собеседник. У группового есть название и
// владелец: он распоряжается составом.

export default function Chats({ theme, directory, currentUser, onError, onUnread, openChatId, onOpened }) {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState(null);
  const [chatSearch, setChatSearch] = useState("");
  const [newChat, setNewChat] = useState(null); // "direct" | "group"

  const loadChats = useCallback(async () => {
    try {
      const list = await api.chats();
      setChats(list);
      onUnread?.(list.reduce((sum, c) => sum + (c.unread || 0), 0));
      return list;
    } catch (e) {
      onError(e.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, [onError, onUnread]);

  useEffect(() => { loadChats(); }, [loadChats]);

  // Переход из всплывающего сообщения: открываем именно тот чат, о
  // котором сообщили.
  useEffect(() => {
    if (!openChatId) return;
    setActiveId(openChatId);
    onOpened?.();
  }, [openChatId, onOpened]);

  // Список чатов перезагружается на любое событие переписки: он
  // показывает последнее сообщение и счётчики, а пересобирать их на
  // клиенте по каждому событию — значит повторять на фронте логику,
  // которая уже есть в запросе.
  useEffect(() => {
    const offChat = onRealtimeMessage("chat", () => { loadChats(); });
    const offMsg = onRealtimeMessage("message", () => { loadChats(); });
    return () => { offChat(); offMsg(); };
  }, [loadChats]);

  const title = useCallback((c) => {
    if (c.kind === "group") return c.title || "Групповой чат";
    const other = (c.members || []).find((id) => id !== currentUser.id);
    return other ? resolveUser(directory, other).fullName : "Личный чат";
  }, [currentUser, directory]);

  const shown = useMemo(() => {
    const q = chatSearch.trim().toLowerCase();
    if (!q) return chats;
    // Поиск по названиям — и групповых, и личных. У личного названия
    // нет, поэтому ищем по имени собеседника: именно так человек его и
    // называет.
    return chats.filter((c) => title(c).toLowerCase().includes(q));
  }, [chats, chatSearch, title]);

  const active = chats.find((c) => c.id === activeId) || null;

  return (
    <div className="h-full flex overflow-hidden">
      {/* ── список чатов ─────────────────────────────────────────── */}
      <aside style={{ borderColor: theme.border, background: theme.surface }}
        className="w-[300px] shrink-0 border-r flex flex-col">
        <div className="p-3 flex flex-col gap-2">
          <div className="flex gap-1.5">
            <button onClick={() => setNewChat("direct")}
              style={{ background: theme.accent, color: theme.accentText }}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-lg py-2 text-[12.5px] font-semibold">
              <MessageSquarePlus size={14} /> Чат
            </button>
            <button onClick={() => setNewChat("group")}
              style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
              className="flex-1 flex items-center justify-center gap-1.5 rounded-lg py-2 text-[12.5px] font-semibold">
              <UsersRound size={14} /> Групповой
            </button>
          </div>
          <div className="relative">
            <Search size={13} style={{ color: theme.textMuted }}
              className="absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input value={chatSearch} onChange={(e) => setChatSearch(e.target.value)}
              placeholder="Поиск по чатам" style={inputStyle(theme)}
              className="w-full rounded-lg pl-7 pr-2 py-1.5 text-[12.5px] outline-none" />
          </div>
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto px-2 pb-3">
          {loading && <Spinner theme={theme} label="Загружаем переписку…" />}
          {!loading && shown.length === 0 && (
            <p style={{ color: theme.textMuted }} className="text-[12.5px] text-center py-8 px-2">
              {chatSearch ? "Ничего не нашлось." : "Переписки пока нет. Начните с кнопки «Чат»."}
            </p>
          )}
          {shown.map((c) => {
            const isActive = c.id === activeId;
            const other = c.kind === "direct"
              ? (c.members || []).find((id) => id !== currentUser.id)
              : null;
            return (
              <button key={c.id} onClick={() => setActiveId(c.id)}
                style={{ background: isActive ? theme.surfaceAlt : "transparent" }}
                className="w-full text-left rounded-xl px-2 py-2 mb-0.5 flex items-center gap-2">
                {other
                  ? <Avatar user={resolveUser(directory, other)} size={30} theme={theme} />
                  : <ChatAvatar chatId={c.id} hasAvatar={Boolean(c.avatarId)} size={30} theme={theme} />}
                <span className="flex-1 min-w-0">
                  <span className="flex items-center gap-1.5">
                    <span style={{ color: theme.text, fontWeight: c.unread ? 700 : 500 }}
                      className="text-[12.5px] truncate">{title(c)}</span>
                    {c.unread > 0 && (
                      // Счётчик на каждом чате: без него непрочитанное
                      // видно только суммой у вкладки, и непонятно, куда
                      // идти.
                      <span style={{ background: theme.accent, color: theme.accentText }}
                        className="text-[10px] font-bold px-1.5 rounded-full shrink-0">
                        {c.unread}
                      </span>
                    )}
                  </span>
                  <span style={{ color: theme.textMuted }} className="text-[11px] block truncate">
                    {c.lastBody || "нет сообщений"}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </aside>

      {/* ── разговор ─────────────────────────────────────────────── */}
      {active ? (
        <Conversation key={active.id} theme={theme} chat={active} title={title(active)}
          directory={directory} currentUser={currentUser}
          onError={onError} onChanged={loadChats}
          onLeft={() => { setActiveId(null); loadChats(); }} />
      ) : (
        <div className="flex-1 flex items-center justify-center">
          <p style={{ color: theme.textMuted }} className="text-[13px]">
            Выберите чат слева или начните новый.
          </p>
        </div>
      )}

      {newChat && (
        <NewChatModal theme={theme} kind={newChat} directory={directory} currentUser={currentUser}
          onClose={() => setNewChat(null)} onError={onError}
          onCreated={async (id) => {
            setNewChat(null);
            await loadChats();
            setActiveId(id);
          }} />
      )}
    </div>
  );
}

/* ------------------------------------------------------------ разговор */

function Conversation({ theme, chat, title, directory, currentUser, onError, onChanged, onLeft }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [q, setQ] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [editing, setEditing] = useState(null);   // { id, body }
  const [confirm, setConfirm] = useState(null);
  const [membersOpen, setMembersOpen] = useState(false);
  const [renaming, setRenaming] = useState(null);
  const [pollOpen, setPollOpen] = useState(false);
  const [preview, setPreview] = useState(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  // Опросы грузятся отдельным запросом на чат: их единицы, а тянуть
  // каждый вместе со своим сообщением значило бы делать десятки
  // запросов на открытие разговора.
  const [polls, setPolls] = useState([]);
  const fileRef = useRef(null);
  const avatarRef = useRef(null);
  const bottomRef = useRef(null);

  const isOwner = chat.ownerId === currentUser.id;

  // Кому звонить: в личном чате — собеседнику, в групповом — всем,
  // кроме себя. Ссылку собирают общие помощники, те же, что в карточке
  // задачи: формат команды клиента телефонии должен быть один на всё
  // приложение.
  const others = (chat.members || [])
    .filter((id) => id !== currentUser.id)
    .map((id) => resolveUser(directory, id));
  const callLink = chat.kind === "group"
    ? conferenceLink(others)
    : (others[0] ? videoCallLink(others[0]) : null);
  const callNames = others.filter((u) => u.phone).map((u) => u.fullName).join(", ");

  // До какого момента переписку прочитали все остальные. Значение
  // считает сервер: клиенту не видны чужие отметки прочтения.
  const readThrough = chat.readThrough ? new Date(chat.readThrough) : null;

  const load = useCallback(async () => {
    try {
      const [msgs, pl] = await Promise.all([
        api.messages(chat.id, q),
        api.polls(chat.id).catch(() => []),
      ]);
      setMessages(msgs);
      setPolls(pl);
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [chat.id, q, onError]);

  useEffect(() => { load(); }, [load]);

  // Открытый чат считается прочитанным. Отметка ставится при открытии и
  // при каждом новом сообщении, пока чат на экране: иначе счётчик
  // «непрочитано» рос бы у человека, который как раз читает.
  useEffect(() => {
    api.markChatRead(chat.id).then(onChanged).catch(() => {});
  }, [chat.id, onChanged]);

  useEffect(() => {
    const offPoll = onRealtimeMessage("chat", (e) => {
      if (e.payload?.id === chat.id) load();
    });
    const off = onRealtimeMessage("message", (e) => {
      if (e.payload?.chatId !== chat.id) return;
      load();
      if (e.payload.authorId !== currentUser.id) {
        api.markChatRead(chat.id).catch(() => {});
      }
    });
    return () => { off(); offPoll(); };
  }, [chat.id, currentUser.id, load]);

  // Прокрутка к последнему сообщению — только когда читаем переписку
  // целиком. В режиме поиска это мешало бы: там важны найденные
  // сообщения, а не конец списка.
  useEffect(() => {
    if (!q) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages, q]);

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setText("");
    try {
      await api.sendMessage(chat.id, body);
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
      setText(body);
    }
  };

  const upload = async (file) => {
    if (!file) return;
    try {
      await api.sendChatFile(chat.id, file, text.trim());
      setText("");
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  const saveEdit = async () => {
    const body = (editing?.body || "").trim();
    if (!body) return;
    try {
      await api.editMessage(editing.id, body);
      setEditing(null);
      await load();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <section className="flex-1 min-w-0 flex flex-col">
      <header style={{ borderColor: theme.border, background: theme.surface }}
        className="border-b px-4 py-2.5 flex items-center gap-2">
        {chat.kind === "group" && (
          <ChatAvatar chatId={chat.id} hasAvatar={Boolean(chat.avatarId)} size={34} theme={theme} />
        )}
        <div className="min-w-0 flex-1">
          <div style={{ color: theme.text }} className="text-[13.5px] font-semibold truncate">
            {title}
          </div>
          <div style={{ color: theme.textMuted }} className="text-[11px] truncate">
            {chat.kind === "group"
              ? `${(chat.members || []).length} участников`
              : "личная переписка"}
          </div>
        </div>

        {/* Звонок: в личном чате — вызов собеседнику, в групповом —
            конференция со всеми участниками, как в карточке задачи.
            Вызов уходит только после подтверждения: нажатие мгновенно
            поднимает вызов у людей, и случайный клик тут вполне
            реален. */}
        {callLink && (
          <button
            onClick={() => setConfirm({
              title: chat.kind === "group" ? "Собрать видеоконференцию?" : "Начать видеозвонок?",
              message: `Вызов будет отправлен: ${callNames}.`,
              confirmLabel: "Позвонить",
              onConfirm: () => { setConfirm(null); window.location.href = callLink; },
            })}
            style={{ color: theme.accent }} className="p-1.5"
            title={chat.kind === "group" ? `Позвонить всем: ${callNames}` : `Позвонить: ${callNames}`}>
            <Video size={16} />
          </button>
        )}

        <button onClick={() => { setSearchOpen((v) => !v); setQ(""); }}
          style={{ color: searchOpen ? theme.accent : theme.textMuted }} className="p-1.5"
          title="Поиск по этому чату"><Search size={16} /></button>

        {chat.kind === "group" && (
          <button onClick={() => setPollOpen(true)} style={{ color: theme.textMuted }}
            className="p-1.5" title="Создать опрос"><BarChart3 size={16} /></button>
        )}

        {/* Очистка и удаление — личные действия, поэтому доступны
            каждому участнику: они не трогают ничью переписку, кроме
            своей. */}
        <>
            <button
              onClick={() => setConfirm({
                title: "Очистить переписку у себя?",
                message: "Сообщения перестанут показываться вам. У собеседника переписка останется — удалять чужую историю нельзя. Отменить это нельзя.",
                confirmLabel: "Очистить",
                danger: true,
                onConfirm: async () => {
                  setConfirm(null);
                  try { await api.clearChat(chat.id); await load(); onChanged(); }
                  catch (e) { onError(e.message); }
                },
              })}
              style={{ color: theme.textMuted }} className="p-1.5"
              title="Очистить переписку"><Eraser size={16} /></button>

            <button
              onClick={() => setConfirm({
                title: "Удалить чат у себя?",
                message: chat.kind === "direct"
                  ? "Чат исчезнет из вашего списка. У собеседника он останется, и если он напишет — разговор вернётся."
                  : "Вы выйдете из группового чата. Остальные участники и переписка останутся.",
                confirmLabel: "Удалить",
                danger: true,
                onConfirm: async () => {
                  setConfirm(null);
                  try { await api.deleteChat(chat.id); onLeft(); }
                  catch (e) { onError(e.message); }
                },
              })}
              style={{ color: theme.danger }} className="p-1.5"
              title="Удалить чат"><Trash2 size={16} /></button>
        </>

        {chat.kind === "group" && (
          <>
            {isOwner && (
              <button onClick={() => setRenaming(chat.title || "")}
                style={{ color: theme.textMuted }} className="p-1.5"
                title="Переименовать чат"><Pencil size={15} /></button>
            )}
            {isOwner && (
              <>
                {/* Картинка чата: выбор файла ставит новую, кнопка
                    рядом снимает текущую. Оба действия у владельца —
                    там же, где название. */}
                <input ref={avatarRef} type="file" accept="image/*" className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    e.target.value = "";
                    if (!file) return;
                    try { await api.setChatAvatar(chat.id, file); onChanged(); }
                    catch (err) { onError(err.message); }
                  }} />
                <button onClick={() => avatarRef.current?.click()}
                  style={{ color: theme.textMuted }} className="p-1.5"
                  title="Картинка чата"><ImageIcon size={16} /></button>
                {chat.avatarId && (
                  <button
                    onClick={async () => {
                      try { await api.setChatAvatar(chat.id, null); onChanged(); }
                      catch (err) { onError(err.message); }
                    }}
                    style={{ color: theme.textMuted }} className="p-1.5"
                    title="Убрать картинку чата"><X size={15} /></button>
                )}
              </>
            )}
            <button onClick={() => setMembersOpen(true)} style={{ color: theme.textMuted }}
              className="p-1.5" title="Участники чата"><UsersRound size={16} /></button>
          </>
        )}
      </header>

      {searchOpen && (
        <div style={{ borderColor: theme.border, background: theme.surface }} className="border-b px-4 py-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} autoFocus
            placeholder="Искать в переписке — по тексту и по именам файлов"
            style={inputStyle(theme)}
            className="w-full rounded-lg px-3 py-1.5 text-[12.5px] outline-none" />
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-3">
        {loading && <Spinner theme={theme} label="Загружаем сообщения…" />}
        {!loading && messages.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] text-center py-10">
            {q ? "В этом чате ничего не нашлось." : "Сообщений пока нет."}
          </p>
        )}

        {messages.map((m, idx) => {
          const mine = m.authorId === currentUser.id;
          const author = m.authorId ? resolveUser(directory, m.authorId) : null;
          // Оформление как в мессенджерах: подряд идущие сообщения
          // одного человека склеиваются в группу. Имя и аватар — только
          // у первого в группе, время и галочки — внутри пузыря, справа
          // внизу. Так на экран влезает переписка, а не сетка подписей:
          // прежний вид повторял «Иванов Иван · 14.09.2026, 10:12» над
          // каждой строчкой, и трёх реплик хватало, чтобы заполнить
          // окно.
          const prev = messages[idx - 1];
          const sameSeries = prev
            && prev.authorId === m.authorId
            && new Date(m.createdAt) - new Date(prev.createdAt) < 5 * 60 * 1000;
          // Имя нужно только в групповом чате: в личном собеседник
          // один, и подписывать каждую его реплику незачем.
          const showName = !mine && chat.kind === "group" && !sameSeries;
          const time = new Date(m.createdAt)
            .toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
          const read = readThrough && new Date(m.createdAt) <= readThrough;

          return (
            <div key={m.id}
              className={`flex gap-2 ${sameSeries ? "mt-0.5" : "mt-2.5"} ${mine ? "flex-row-reverse" : ""}`}>
              {/* Место под аватар держится и у продолжения серии —
                  иначе реплики одного человека съезжают по горизонтали. */}
              <span className="w-[26px] shrink-0">
                {!mine && !sameSeries && author && (
                  <Avatar user={author} size={26} theme={theme} />
                )}
              </span>

              <div className="max-w-[72%] min-w-0">
                <div style={{
                    background: mine ? theme.accent : theme.surfaceAlt,
                    color: mine ? theme.accentText : theme.text,
                    border: `1px solid ${mine ? "transparent" : theme.border}`,
                  }}
                  className="rounded-2xl px-3 py-1.5">
                  {showName && (
                    <div style={{ color: mine ? theme.accentText : theme.accent }}
                      className="text-[12px] font-semibold mb-0.5 truncate">
                      {author.fullName}
                    </div>
                  )}

                  {m.deleted ? (
                    <span style={{ opacity: 0.7 }} className="text-[12.5px] italic">
                      сообщение удалено
                    </span>
                  ) : editing?.id === m.id ? (
                    <div className="py-1">
                      <MultilineField theme={theme} value={editing.body} autoFocus
                        onChange={(body) => setEditing({ ...editing, body })}
                        onSubmit={saveEdit}
                        className="w-full rounded-lg px-2 py-1 text-[12.5px] outline-none mb-1.5" />
                      <div className="flex gap-2">
                        <button onClick={saveEdit} className="text-[11.5px] font-semibold flex items-center gap-1">
                          <Check size={12} /> Сохранить
                        </button>
                        <button onClick={() => setEditing(null)} className="text-[11.5px] flex items-center gap-1">
                          <X size={12} /> Отмена
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {m.body && (
                        <div className="text-[12.5px] whitespace-pre-wrap break-words">
                          {withEmoji(m.body)}
                        </div>
                      )}

                      {/* Любое вложение открывается в окне предпросмотра.
                          Картинка при этом сразу видна в ленте: её
                          присылают, чтобы посмотреть. */}
                      {m.fileId && (m.mime || "").startsWith("image/") && (
                        <button onClick={() => setPreview(m)} className="block mt-1">
                          <ChatImage messageId={m.id} filename={m.filename} theme={theme} />
                        </button>
                      )}
                      {m.fileId && !(m.mime || "").startsWith("image/") && (
                        <button onClick={() => setPreview(m)}
                          style={{ color: mine ? theme.accentText : theme.accent }}
                          className="flex items-center gap-1.5 text-[12px] font-medium mt-1 underline">
                          <Paperclip size={12} /> {m.filename}
                          <span style={{ opacity: 0.7 }}>
                            ({Math.max(1, Math.round((m.size || 0) / 1024))} КБ)
                          </span>
                        </button>
                      )}

                      {polls.filter((p) => p.messageId === m.id).map((p) => (
                        <Poll key={p.id} poll={p} theme={theme} mine={mine}
                          currentUser={currentUser} directory={directory}
                          onChanged={load} onError={onError} />
                      ))}
                    </>
                  )}

                  {/* Время и галочки прижаты к правому краю пузыря и
                      набраны мельче: это служебная приписка, а не часть
                      сообщения. */}
                  {!m.deleted && (
                    <div style={{ color: mine ? theme.accentText : theme.textMuted, opacity: mine ? 0.75 : 1 }}
                      className="flex items-center justify-end gap-1 text-[10px] mt-0.5">
                      {m.editedAt && <span>изменено</span>}
                      <span>{time}</span>
                      {mine && (read
                        ? <CheckCheck size={11} title="Прочитано" />
                        : <Check size={11} title="Отправлено" />)}
                    </div>
                  )}
                </div>

                {mine && !m.deleted && editing?.id !== m.id && (
                  <div className="flex gap-2 justify-end mt-0.5">
                    {m.body && (
                      <button onClick={() => setEditing({ id: m.id, body: m.body })}
                        style={{ color: theme.textMuted }} className="text-[10.5px] flex items-center gap-1">
                        <Pencil size={10} /> изменить
                      </button>
                    )}
                    <button
                      onClick={() => setConfirm({
                        title: "Удалить сообщение?",
                        message: "Текст и файл будут убраны, на их месте останется пометка «сообщение удалено».",
                        confirmLabel: "Удалить",
                        danger: true,
                        onConfirm: async () => {
                          setConfirm(null);
                          try {
                            await api.deleteMessage(m.id);
                            await load();
                            onChanged();
                          } catch (e) { onError(e.message); }
                        },
                      })}
                      style={{ color: theme.danger }} className="text-[10.5px] flex items-center gap-1">
                      <Trash2 size={10} /> удалить
                    </button>
                  </div>
                )}

                {/* Дата — раз на серию, мелкой строкой под пузырём:
                    в ленте важнее время, а полная дата нужна, только
                    когда переписка перескакивает через день. */}
                {!sameSeries && (
                  <div style={{ color: theme.textMuted }}
                    className={`text-[10px] mt-0.5 ${mine ? "text-right" : ""}`}>
                    {fmtDateTime(m.createdAt)}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div style={{ borderColor: theme.border, background: theme.surface }}
        className="border-t px-4 py-3 flex items-end gap-2">
        <input ref={fileRef} type="file" className="hidden"
          onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
        <button onClick={() => fileRef.current?.click()} style={{ color: theme.textMuted }}
          className="p-2 shrink-0" title="Отправить файл"><Paperclip size={17} /></button>

        {/* Отдельной кнопки для картинок нет: скрепка принимает любой
            файл, включая изображения, и две кнопки рядом с одинаковым
            действием только занимали место. */}
        <div className="relative shrink-0">
          <button onClick={() => setEmojiOpen((v) => !v)} style={{ color: theme.textMuted }}
            className="p-2" title="Смайлики"><Smile size={17} /></button>
          {emojiOpen && (
            <EmojiPicker theme={theme} onPick={(ch) => { setText((t) => t + ch); setEmojiOpen(false); }}
              onClose={() => setEmojiOpen(false)} />
          )}
        </div>
        {/* В переписке отправляет Ctrl+Enter, а Enter переносит строку:
            сообщения тут чаще многострочные, и Enter, улетающий с
            недописанной мыслью, раздражает сильнее лишнего нажатия. */}
        <MultilineField theme={theme} value={text} onChange={setText} onSubmit={send}
          placeholder="Сообщение. Ctrl+Enter — отправить, Enter — новая строка"
          className="flex-1 rounded-lg px-3 py-2 text-[13px] outline-none" />
        <button onClick={send} style={{ background: theme.accent, color: theme.accentText }}
          className="rounded-lg p-2.5 shrink-0"><Send size={15} /></button>
      </div>

      {renaming !== null && (
        <RenameChatModal theme={theme} initial={renaming}
          onClose={() => setRenaming(null)} onError={onError}
          onSaved={async (t) => {
            try {
              await api.renameChat(chat.id, t);
              setRenaming(null);
              onChanged();
            } catch (e) { onError(e.message); }
          }} />
      )}

      {membersOpen && (
        <ChatMembersModal theme={theme} chat={chat} directory={directory} currentUser={currentUser}
          isOwner={isOwner} onClose={() => setMembersOpen(false)} onError={onError}
          onChanged={onChanged} onLeft={onLeft} />
      )}

      {pollOpen && (
        <PollModal theme={theme} onClose={() => setPollOpen(false)} onError={onError}
          onCreate={async (payload) => {
            try {
              await api.createPoll(chat.id, payload);
              setPollOpen(false);
              await load();
              onChanged();
            } catch (e) { onError(e.message); }
          }} />
      )}

      {preview && (
        <FilePreview theme={theme} filename={preview.filename} mime={preview.mime}
          path={`/messages/${preview.id}/file`}
          downloadPath={`/messages/${preview.id}/file?download=1`}
          onClose={() => setPreview(null)} />
      )}

      {confirm && <ConfirmDialog theme={theme} {...confirm} onCancel={() => setConfirm(null)} />}
    </section>
  );
}

/* --------------------------------------------------------- новый чат */

function NewChatModal({ theme, kind, directory, currentUser, onClose, onCreated, onError }) {
  const [q, setQ] = useState("");
  const [title, setTitle] = useState("");
  const [picked, setPicked] = useState([]);
  const [busy, setBusy] = useState(false);

  // Собеседника выбираем из всех сотрудников системы, а не из своей
  // команды: переписка не про подчинённость, писать приходится и
  // смежникам, и в другие отделы.
  const people = directory
    .filter((u) => !u.deleted && u.id !== currentUser.id)
    .filter((u) => {
      const needle = q.trim().toLowerCase();
      if (!needle) return true;
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    })
    .sort((a, b) => a.fullName.localeCompare(b.fullName, "ru"));

  const submit = async (userId) => {
    setBusy(true);
    try {
      const res = kind === "direct"
        ? await api.createChat({ kind: "direct", userId })
        : await api.createChat({ kind: "group", title: title.trim(), members: picked });
      onCreated(res.id);
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-new">
      <ModalHeader theme={theme} onClose={onClose}
        title={kind === "direct" ? "Новый чат" : "Новый групповой чат"}
        subtitle={kind === "direct"
          ? "Выберите собеседника. Если переписка с ним уже есть, откроется она"
          : "Название и участники. Вы будете владельцем чата"} />

      {kind === "group" && (
        <input value={title} onChange={(e) => setTitle(e.target.value)}
          placeholder="Название чата" style={inputStyle(theme)}
          className="w-full rounded-lg px-3 py-2 text-[13px] outline-none mb-2" />
      )}

      <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Имя или должность" style={inputStyle(theme)}
        className="w-full rounded-lg px-3 py-2 text-[13px] outline-none mb-2" />

      <div style={{ borderColor: theme.border }} className="border-t pt-2 max-h-[38vh] overflow-y-auto mb-3">
        {people.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-4 text-center">
            Никого не нашлось.
          </p>
        )}
        {people.map((u) => {
          const on = picked.includes(u.id);
          return (
            <button key={u.id} disabled={busy}
              onClick={() => {
                if (kind === "direct") return submit(u.id);
                setPicked((prev) => (on ? prev.filter((x) => x !== u.id) : [...prev, u.id]));
              }}
              style={{ background: on ? theme.surfaceAlt : "transparent" }}
              className="w-full flex items-center gap-2 rounded-lg px-2 py-1.5 text-left mb-0.5">
              <Avatar user={u} size={26} theme={theme} />
              <span className="flex-1 min-w-0">
                <span style={{ color: theme.text }} className="text-[13px] block truncate">{u.fullName}</span>
                <span style={{ color: theme.textMuted }} className="text-[11px] block truncate">
                  {u.position || "Должность не указана"}
                </span>
              </span>
              {on && <Check size={15} style={{ color: theme.success }} />}
            </button>
          );
        })}
      </div>

      {kind === "group" && (
        <button onClick={() => submit()} disabled={busy || !title.trim()}
          style={{ background: theme.accent, color: theme.accentText }}
          className="w-full rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">
          {busy ? "Создаём…" : `Создать чат${picked.length ? ` · участников: ${picked.length + 1}` : ""}`}
        </button>
      )}
    </Modal>
  );
}

function RenameChatModal({ theme, initial, onClose, onSaved }) {
  const [title, setTitle] = useState(initial);
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="chat-rename">
      <ModalHeader theme={theme} title="Название чата" onClose={onClose} />
      <input value={title} onChange={(e) => setTitle(e.target.value)} autoFocus
        onKeyDown={(e) => { if (e.key === "Enter" && title.trim()) onSaved(title.trim()); }}
        style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none mb-3" />
      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={() => onSaved(title.trim())} disabled={!title.trim()}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">
          Сохранить
        </button>
      </div>
    </Modal>
  );
}

function ChatMembersModal({ theme, chat, directory, currentUser, isOwner, onClose, onError, onChanged, onLeft }) {
  const [q, setQ] = useState("");
  const members = chat.members || [];

  const candidates = directory
    .filter((u) => !u.deleted && !members.includes(u.id))
    .filter((u) => {
      const needle = q.trim().toLowerCase();
      if (!needle) return true;
      return u.fullName.toLowerCase().includes(needle)
        || (u.position || "").toLowerCase().includes(needle);
    })
    .slice(0, 8);

  const act = async (fn) => {
    try {
      await fn();
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-members">
      <ModalHeader theme={theme} title="Участники чата" onClose={onClose}
        subtitle={isOwner
          ? "Вы владелец: можете добавлять и убирать участников"
          : "Состав меняет владелец чата"} />

      <div className="mb-3">
        {members.map((id) => {
          const u = resolveUser(directory, id);
          const owner = chat.ownerId === id;
          return (
            <div key={id} className="flex items-center gap-2 py-1">
              <Avatar user={u} size={26} theme={theme} />
              <span style={{ color: theme.text }} className="text-[12.5px] flex-1 truncate">
                {u.fullName}{owner ? " · владелец" : ""}
              </span>
              {/* Владельца убрать нельзя: чат остался бы без того, кто
                  вправе распоряжаться составом. */}
              {isOwner && !owner && (
                <button onClick={() => act(() => api.removeChatMember(chat.id, id))}
                  style={{ color: theme.danger }} className="text-[11px]">убрать</button>
              )}
            </div>
          );
        })}
      </div>

      {isOwner && (
        <>
          <input value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Добавить: имя или должность" style={inputStyle(theme)}
            className="w-full rounded-lg px-3 py-2 text-[12.5px] outline-none mb-2" />
          {candidates.map((u) => (
            <div key={u.id} className="flex items-center gap-2 py-1">
              <Avatar user={u} size={24} theme={theme} />
              <span style={{ color: theme.text }} className="text-[12.5px] flex-1 truncate">{u.fullName}</span>
              <button onClick={() => act(() => api.addChatMember(chat.id, u.id))}
                style={{ color: theme.accent }} className="text-[11.5px] flex items-center gap-1">
                <UserPlus size={12} /> добавить
              </button>
            </div>
          ))}
        </>
      )}

      {!isOwner && (
        <button
          onClick={() => act(async () => {
            await api.removeChatMember(chat.id, currentUser.id);
            onLeft();
          })}
          style={{ color: theme.danger }} className="flex items-center gap-1.5 text-[12.5px] font-medium mt-2">
          <LogOut size={13} /> Выйти из чата
        </button>
      )}
    </Modal>
  );
}

/* ---------------------------------------------------------- смайлики */

// Небольшой набор вместо полноценного справочника эмодзи.
//
// Полный список — это отдельная библиотека на сотни килобайт с поиском
// по названиям; в рабочей переписке из него используются полтора
// десятка знаков. Здесь они и собраны, сгруппированные по смыслу.
// Символы вставляются в поле как обычный текст — никакой особой
// обработки на сервере не требуется.
// Набор по разделам. Полноценный справочник эмодзи — это отдельная
// библиотека на сотни килобайт с поиском по названиям; в рабочей
// переписке из него берут десятки знаков, а не тысячи.
//
// Раздел «настроение» собран по мотивам классических смайлов ICQ: те
// были картинками с собственными номерами, и точных соответствий в
// Юникоде у них нет — подобраны ближайшие по смыслу. «Бьётся головой об
// стену» — 🤕 рядом с 🧱, «подмигивает» — 😉, «сердится» — 😠.
const EMOJI = [
  {
    title: "Реакции",
    items: ["👍", "👎", "👌", "🤝", "🙏", "👏", "💪", "🤙", "✌️", "🫡", "🤞", "✍️"],
  },
  {
    title: "Настроение",
    items: [
      "😀", "😃", "😄", "😁", "🙂", "😉", "😊", "😇",
      "😍", "😘", "😜", "😝", "🤪", "🤗", "🤔", "🤨",
      "😐", "😑", "🙄", "😏", "😒", "😞", "😔", "😟",
      "😕", "🙁", "😖", "😫", "😩", "😢", "😭", "😤",
      "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱",
      "😨", "😰", "😥", "😓", "🤗", "🤭", "🤫", "😬",
      "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢", "🤮",
      "🤧", "😷", "🤒", "🤕", "🧱", "🤦", "🤷", "🙈",
      "🙉", "🙊", "😎", "🤓", "🥳", "🥺", "😈", "👻",
    ],
  },
  {
    title: "Работа",
    items: [
      "✅", "❌", "❗", "❓", "⚠️", "📌", "📎", "📅",
      "📊", "📈", "📉", "📝", "📁", "📂", "🗓️", "⏰",
      "🕐", "💼", "💰", "🧾", "✉️", "📞", "📠", "🖨️",
      "💻", "🖥️", "🔒", "🔑", "🔧", "⚙️", "🎯", "🚀",
    ],
  },
  {
    title: "Прочее",
    items: [
      "🔥", "⚡", "💡", "🎉", "🎁", "☕", "🍪", "🍰",
      "🌚", "🌝", "☀️", "🌧️", "❄️", "🌈", "🚗", "✈️",
      "🏠", "🏢", "❤️", "💔", "💯", "🤝", "🕊️", "🍀",
    ],
  },
];
function EmojiPicker({ theme, onPick, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <>
      {/* Прозрачная подложка: нажатие мимо закрывает набор, как и
          ожидается от выпадающей панели. */}
      <div className="fixed inset-0 z-[60]" onClick={onClose} />
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="absolute bottom-full left-0 mb-2 z-[61] p-2 rounded-xl shadow-xl w-[300px] max-h-[340px] overflow-y-auto">
        {EMOJI.map((group) => (
          <div key={group.title} className="mb-2">
            <div style={{ color: theme.textMuted }}
              className="text-[10px] uppercase tracking-wide mb-1 px-1">{group.title}</div>
            <div className="grid grid-cols-8 gap-1">
              {group.items.map((ch, i) => (
                <button key={`${ch}-${i}`} onClick={() => onPick(ch)}
                  className="text-[24px] leading-none p-1 rounded hover:opacity-70">
                  {ch}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Анимированные — последним разделом: они заметные, и
            наверху перетягивали внимание с обычных знаков, которыми
            пользуются чаще. */}
        <div className="mb-2">
          <div style={{ color: theme.textMuted }}
            className="text-[10px] uppercase tracking-wide mb-1 px-1">Анимированные</div>
          <div className="grid grid-cols-5 gap-1">
            {ANIMATED.map((e) => (
              <button key={e.code} onClick={() => onPick(e.code)} title={e.title}
                className="p-1 rounded hover:opacity-70 flex items-center justify-center">
                <AnimatedEmoji code={e.code} size={30} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

/* ------------------------------------------------------------- опросы */

function PollModal({ theme, onClose, onCreate }) {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", ""]);
  const [multiple, setMultiple] = useState(false);

  const valid = question.trim() && options.filter((o) => o.trim()).length >= 2;

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="chat-poll">
      <ModalHeader theme={theme} title="Новый опрос" onClose={onClose}
        subtitle="Появится сообщением в чате. Ответы видны всем участникам" />

      <input value={question} onChange={(e) => setQuestion(e.target.value)} autoFocus
        placeholder="Вопрос" style={inputStyle(theme)}
        className="w-full rounded-lg px-3 py-2 text-[13px] outline-none mb-2" />

      {options.map((o, i) => (
        <div key={i} className="flex items-center gap-2 mb-1.5">
          <input value={o}
            onChange={(e) => setOptions((prev) => prev.map((v, idx) => (idx === i ? e.target.value : v)))}
            placeholder={`Вариант ${i + 1}`} style={inputStyle(theme)}
            className="flex-1 rounded-lg px-3 py-1.5 text-[12.5px] outline-none" />
          {options.length > 2 && (
            <button onClick={() => setOptions((prev) => prev.filter((_, idx) => idx !== i))}
              style={{ color: theme.danger }} title="Убрать вариант"><X size={14} /></button>
          )}
        </div>
      ))}

      {/* Десять вариантов — потолок: длиннее опрос перестаёт быть
          опросом и становится анкетой, в которой никто не разбирается. */}
      {options.length < 10 && (
        <button onClick={() => setOptions((prev) => [...prev, ""])}
          style={{ color: theme.accent }} className="text-[12.5px] font-medium mb-3">
          + Добавить вариант
        </button>
      )}

      <label className="flex items-center gap-2 mb-3 cursor-pointer">
        <input type="checkbox" checked={multiple} onChange={(e) => setMultiple(e.target.checked)} />
        <span style={{ color: theme.text }} className="text-[12.5px]">
          Можно выбрать несколько вариантов
        </span>
      </label>

      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button
          onClick={() => onCreate({
            question: question.trim(),
            options: options.map((o) => o.trim()).filter(Boolean),
            multiple,
          })}
          disabled={!valid}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">
          Создать опрос
        </button>
      </div>
    </Modal>
  );
}

// Опрос в ленте сообщений.
//
// Показывается и как голосование, и как результат сразу: скрывать
// результаты до голосования было бы честнее для соцопроса, но в рабочем
// чате важнее видеть, кто уже ответил и чего не хватает для решения.
function Poll({ poll, theme, mine, currentUser, directory, onChanged, onError }) {
  const total = new Set(poll.options.flatMap((o) => (o.votes || []).map((v) => v.userId))).size;

  const vote = async (optionId) => {
    try {
      await api.vote(optionId);
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  const closePoll = async () => {
    try {
      await api.closePoll(poll.id);
      onChanged();
    } catch (e) {
      onError(e.message);
    }
  };

  const text = mine ? theme.accentText : theme.text;
  const muted = mine ? theme.accentText : theme.textMuted;

  return (
    <div className="mt-1.5">
      <div style={{ color: muted }} className="text-[10.5px] uppercase tracking-wide mb-1">
        {poll.closed ? "опрос завершён" : poll.multiple ? "опрос · несколько ответов" : "опрос"}
      </div>

      {poll.options.map((o) => {
        const votes = (o.votes || []).length;
        const share = total ? Math.round((votes / total) * 100) : 0;
        const picked = (o.votes || []).some((v) => v.userId === currentUser.id);
        // Кто и когда отметился — в подсказке: выводить список прямо в
        // ленте значило бы растянуть опрос на пол-экрана.
        const who = (o.votes || [])
          .map((v) => `${resolveUser(directory, v.userId).fullName} — ${fmtDateTime(v.votedAt)}`)
          .join("\n");
        return (
          <button key={o.id} onClick={() => !poll.closed && vote(o.id)}
            disabled={poll.closed}
            title={who || "Пока никто не выбрал"}
            style={{ borderColor: mine ? "rgba(255,255,255,.35)" : theme.border }}
            className="w-full text-left border rounded-lg px-2 py-1.5 mb-1 relative overflow-hidden">
            {/* Доля голосов — заливкой позади текста: отдельная полоска
                занимала бы вдвое больше места в и без того плотной
                ленте. */}
            <span style={{
                background: mine ? "rgba(255,255,255,.22)" : theme.surfaceAlt,
                width: `${share}%`,
              }}
              className="absolute inset-y-0 left-0" />
            <span className="relative flex items-center gap-1.5">
              {picked && <Check size={12} style={{ color: mine ? theme.accentText : theme.success }} />}
              <span style={{ color: text }} className="text-[12.5px] flex-1 truncate">{o.body}</span>
              <span style={{ color: muted }} className="text-[11px]">{votes} · {share}%</span>
            </span>
          </button>
        );
      })}

      {/* Развёрнутый список с временем отметки: по нему видно, кого
          ещё ждём и когда ответили остальные. */}
      {total > 0 && (
        <div style={{ color: muted }} className="text-[10px] leading-relaxed mt-1">
          {poll.options.flatMap((o) => (o.votes || []).map((v) => (
            <div key={`${o.id}-${v.userId}`} className="truncate">
              {resolveUser(directory, v.userId).fullName} · {o.body} · {fmtDateTime(v.votedAt)}
            </div>
          )))}
        </div>
      )}

      <div className="flex items-center gap-3 mt-1">
        <span style={{ color: muted }} className="text-[10.5px]">
          проголосовали: {total}
        </span>
        {mine && !poll.closed && (
          <button onClick={closePoll} style={{ color: muted }} className="text-[10.5px] underline">
            завершить опрос
          </button>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------ смайлики в тексте */

// Эмодзи в сообщении рисуются крупнее текста.
//
// В переписке смайлик — это часть высказывания, иногда всё
// высказывание целиком; набранный тем же кеглем, что и текст, он
// превращается в неразборчивую точку. Поэтому текст разбивается на
// куски, и найденные эмодзи оборачиваются в span с увеличенным
// размером.
//
// Регулярное выражение опирается на свойство Юникода Extended_Pictographic
// и захватывает модификаторы: тон кожи, вариационный селектор и
// склейку ZWJ — иначе составной смайлик (например, 👨‍💻) распался бы
// на части и увеличилась бы только первая.
const EMOJI_RE = /(\p{Extended_Pictographic}(\uFE0F|\p{Emoji_Modifier})?(\u200D\p{Extended_Pictographic}(\uFE0F|\p{Emoji_Modifier})?)*)/gu;

export function withEmoji(text, size = 36) {
  if (!text) return text;

  // Сначала вынимаем коды анимированных смайлов, потом в оставшихся
  // куска текста ищем обычные эмодзи. Порядок важен: код — это
  // обычные символы, и при обратном порядке двоеточия из него попали
  // бы в разбор как текст.
  const codes = ANIMATED.map((e) => e.code);
  // Экранировать коды не нужно: в них только латиница и двоеточия.
  const codeRe = new RegExp("(" + codes.join("|") + ")", "g");

  const out = [];
  let last = 0;
  let key = 0;
  for (const m of text.matchAll(codeRe)) {
    if (m.index > last) out.push(...splitEmoji(text.slice(last, m.index), size, key++));
    out.push(<AnimatedEmoji key={`a${key++}`} code={m[0]} size={size} />);
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(...splitEmoji(text.slice(last), size, key++));
  return out.length ? out : text;
}

// Разбор обычных эмодзи внутри куска текста.
function splitEmoji(text, size, seed) {
  const parts = [];
  let last = 0;
  for (const m of text.matchAll(EMOJI_RE)) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(
      <span key={`e${seed}-${m.index}`}
        style={{ fontSize: size, lineHeight: 1.1, verticalAlign: "middle" }}>
        {m[0]}
      </span>
    );
    last = m.index + m[0].length;
  }
  if (last === 0) return [text];
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

/* --------------------------------------------- картинка в переписке */

// Отрисовка картинки из вложения.
//
// Отдельный компонент нужен из-за авторизации: браузер не добавляет
// заголовок с токеном к <img src>, поэтому файл забирается запросом и
// превращается в blob-ссылку. Ссылка освобождается при размонтировании,
// иначе десяток фотографий остаётся в памяти до перезагрузки.
function ChatImage({ messageId, filename, theme }) {
  return (
    <AuthImage path={`/messages/${messageId}/file`} alt={filename} theme={theme}
      className="rounded-lg max-w-full w-40" style={{ maxHeight: 280, width: "auto" }} />
  );
}

/* ------------------------------------------------- картинка чата */

// Аватар группового чата: та же история с токеном, что и у картинок в
// переписке, плюс запасной вариант — значок, когда картинки нет.
function ChatAvatar({ chatId, hasAvatar, size, theme }) {
  if (!hasAvatar) {
    return (
      <span style={{ background: theme.surfaceAlt, color: theme.textMuted, width: size, height: size }}
        className="rounded-full flex items-center justify-center shrink-0">
        <UsersRound size={Math.round(size * 0.5)} />
      </span>
    );
  }
  return (
    <AuthImage path={`/chats/${chatId}/avatar`} alt="" theme={theme}
      className="rounded-full shrink-0"
      style={{ width: size, height: size, objectFit: "cover" }} />
  );
}
