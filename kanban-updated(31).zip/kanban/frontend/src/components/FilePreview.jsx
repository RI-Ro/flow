import React, { useEffect, useState } from "react";
import { Download, FileText, AlertTriangle } from "lucide-react";
import * as XLSX from "xlsx";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, Spinner } from "../lib/ui.jsx";

// Предпросмотр файла в модальном окне, без скачивания.
//
// Раньше PDF и картинки открывались в новой вкладке, а документы и
// таблицы можно было только скачать: чтобы глянуть, что во вложении,
// приходилось тащить файл на диск, открывать сторонней программой и
// потом убирать за собой. Для рабочей переписки, где вложения смотрят
// мимоходом, это слишком дорого.
//
// Разбор идёт на клиенте, без сторонних служб: файл и так уже
// скачивается для показа, а отправлять рабочие документы во внешний
// просмотрщик нельзя.
//
// Что чем открывается:
//
//   • изображения — как есть;
//   • PDF — встроенным просмотрщиком браузера в <iframe>;
//   • xlsx / xls / csv — разбором SheetJS в таблицу;
//   • docx — mammoth, который переводит документ в HTML;
//   • doc, odt, rtf и прочее — только скачиванием, и об этом честно
//     сказано в окне.
//
// Последний пункт — не лень. Старый .doc это двоичный формат OLE,
// .odt — свой zip-контейнер со своей разметкой; надёжных
// браузерных разборщиков для них нет, а полусломанный предпросмотр
// хуже честного «откройте в своей программе»: по нему принимают
// решения.

const IMAGE = /^image\//;

function kindOf(filename, mime) {
  const ext = (filename || "").toLowerCase().split(".").pop();
  if (IMAGE.test(mime || "")) return "image";
  if (mime === "application/pdf" || ext === "pdf") return "pdf";
  if (["xlsx", "xlsm", "xltx", "xls", "csv", "tsv"].includes(ext)) return "sheet";
  if (ext === "docx") return "doc";
  return "none";
}

export default function FilePreview({ theme, title, filename, mime, path, downloadPath, onClose }) {
  const [state, setState] = useState({ loading: true });
  const kind = kindOf(filename, mime);

  useEffect(() => {
    let url = null;
    let cancelled = false;

    (async () => {
      if (kind === "none") {
        setState({ loading: false });
        return;
      }
      try {
        const blob = await api.fileBlob(path);
        if (cancelled) return;

        if (kind === "image" || kind === "pdf") {
          url = URL.createObjectURL(blob);
          setState({ loading: false, url });
          return;
        }

        if (kind === "sheet") {
          const book = XLSX.read(await blob.arrayBuffer(), { type: "array" });
          // Листы разбираем сразу все: переключаться между ними человек
          // будет в окне, а второй разбор того же файла ради второго
          // листа — лишняя работа.
          const sheets = book.SheetNames.map((name) => ({
            name,
            rows: XLSX.utils.sheet_to_json(book.Sheets[name], { header: 1, defval: "" }),
          }));
          setState({ loading: false, sheets });
          return;
        }

        if (kind === "doc") {
          // mammoth подключается по требованию: библиотека немалая, а
          // нужна только тем, кто открыл именно docx.
          const mammoth = await import("mammoth/mammoth.browser.js");
          const res = await mammoth.convertToHtml({ arrayBuffer: await blob.arrayBuffer() });
          setState({ loading: false, html: res.value });
        }
      } catch (e) {
        if (!cancelled) setState({ loading: false, error: e.message || "Не удалось открыть файл" });
      }
    })();

    return () => {
      cancelled = true;
      // blob-ссылку нужно освобождать руками: иначе файл висит в памяти
      // до перезагрузки страницы, а вложения бывают на десятки
      // мегабайт.
      if (url) URL.revokeObjectURL(url);
    };
  }, [kind, path]);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-5xl" padded={false} geometryKey="file-preview">
      <div className="p-4 pb-2">
        <ModalHeader theme={theme} title={title || filename} onClose={onClose}
          subtitle={filename} />
      </div>

      <div className="px-4 pb-4">
        {state.loading && <Spinner theme={theme} label="Открываем файл…" />}

        {state.error && (
          <p style={{ color: theme.danger }} className="text-[13px] py-6 text-center">
            {state.error}
          </p>
        )}

        {!state.loading && kind === "none" && (
          <div className="py-8 text-center">
            <AlertTriangle size={22} style={{ color: theme.textMuted }} className="mx-auto mb-2" />
            <p style={{ color: theme.text }} className="text-[13px] font-medium mb-1">
              Этот формат в окне не открывается
            </p>
            <p style={{ color: theme.textMuted }} className="text-[12px] leading-relaxed max-w-md mx-auto">
              Старый .doc и .odt — двоичные и упакованные форматы, для которых нет надёжного
              браузерного разбора. Показывать их наполовину хуже, чем не показывать: по документам
              принимают решения. Скачайте и откройте в своей программе.
            </p>
          </div>
        )}

        {state.url && kind === "image" && (
          <img src={state.url} alt={filename}
            className="max-w-full mx-auto rounded-lg"
            style={{ maxHeight: "70vh", border: `1px solid ${theme.border}` }} />
        )}

        {state.url && kind === "pdf" && (
          <iframe src={state.url} title={filename}
            style={{ width: "100%", height: "72vh", border: `1px solid ${theme.border}` }}
            className="rounded-lg" />
        )}

        {state.sheets && <SheetView theme={theme} sheets={state.sheets} />}

        {state.html && (
          // Разметка из docx выводится как есть: mammoth отдаёт
          // безопасный HTML (заголовки, абзацы, списки, таблицы) без
          // скриптов и внешних ссылок.
          <div style={{ color: theme.text, background: theme.surfaceAlt, borderColor: theme.border }}
            className="doc-preview border rounded-lg p-5 overflow-auto text-[13px] leading-relaxed"
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: state.html }}
            />
        )}
      </div>

      <div style={{ borderColor: theme.border }} className="border-t px-4 py-3 flex items-center gap-2">
        <FileText size={14} style={{ color: theme.textMuted }} />
        <span style={{ color: theme.textMuted }} className="text-[11.5px] truncate flex-1">
          {filename}
        </span>
        <a href={downloadPath ? `/api${downloadPath}` : undefined}
          onClick={async (e) => {
            // Скачивание тоже идёт через запрос с токеном: прямая
            // ссылка получила бы 401, поэтому файл берётся blob-ом и
            // сохраняется программно.
            e.preventDefault();
            try {
              const blob = await api.fileBlob(downloadPath || path);
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = filename || "файл";
              a.click();
              URL.revokeObjectURL(url);
            } catch {
              /* ошибку показывать здесь незачем: причина та же, что и
                 у неудавшегося предпросмотра, и она уже видна выше */
            }
          }}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-medium">
          <Download size={13} /> Скачать
        </a>
      </div>
    </Modal>
  );
}

function SheetView({ theme, sheets }) {
  const [active, setActive] = useState(0);
  const rows = sheets[active]?.rows || [];

  return (
    <div>
      {sheets.length > 1 && (
        <div className="flex gap-1.5 mb-2 flex-wrap">
          {sheets.map((s, i) => (
            <button key={s.name} onClick={() => setActive(i)}
              style={{
                background: i === active ? theme.accent : theme.surfaceAlt,
                color: i === active ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="rounded-lg px-2.5 py-1 text-[11.5px] font-medium">
              {s.name}
            </button>
          ))}
        </div>
      )}

      <div style={{ borderColor: theme.border, maxHeight: "62vh" }}
        className="border rounded-lg overflow-auto">
        <table className="text-[12px]" style={{ borderCollapse: "collapse", minWidth: "100%" }}>
          <tbody>
            {/* Первая строка показывается заголовком: в рабочих
                таблицах она почти всегда им и является. */}
            {rows.slice(0, 500).map((row, ri) => (
              <tr key={ri} style={{ background: ri === 0 ? theme.surfaceAlt : "transparent" }}>
                {row.map((cell, ci) => (
                  <td key={ci}
                    style={{
                      border: `1px solid ${theme.border}`,
                      color: theme.text,
                      fontWeight: ri === 0 ? 600 : 400,
                      padding: "4px 8px",
                      whiteSpace: "nowrap",
                    }}>
                    {String(cell)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {rows.length > 500 && (
        <p style={{ color: theme.textMuted }} className="text-[11px] mt-1.5">
          Показаны первые 500 строк из {rows.length}. Полную таблицу можно скачать.
        </p>
      )}
    </div>
  );
}
