package marking

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"
	xfont "golang.org/x/image/font"
	"golang.org/x/image/font/opentype"

	"sed-system/backend/internal/config"
)

// ВЖИГАНИЕ ШТАМПОВ (#5) — ВЕКТОРНЫЙ ТЕКСТ (без растровых картинок).
// Штампы наносятся pdfcpu TextWatermark нашим TTF-шрифтом (кириллица работает
// при указании ПРАВИЛЬНОГО внутреннего имени шрифта, напр. "LiberationSans").
// Ключевая проблема прежних версий — позиционирование: pdfcpu ставит ЦЕНТР
// текста в точку привязки, из-за чего штамп «уезжал влево/вверх» относительно
// overlay, который ставит УГОЛ рамки на отступе от края. Решение: измеряем
// размеры текста по самому шрифту (через x/image, БЕЗ растеризации) и сдвигаем
// центр на (margin + размер/2), чтобы КРАЙ текста совпал с overlay.

var (
	fontOnce sync.Once
	fontName string          // внутреннее имя шрифта для pdfcpu (fontname:...)
	measFont *opentype.Font  // тот же TTF — только для измерения размеров текста
)

func Configure(cfg config.MarkingConfig) {
	fontOnce.Do(func() {
		if cfg.FontName != "" {
			fontName = cfg.FontName
		} else if cfg.FontFile != "" {
			base := filepath.Base(cfg.FontFile)
			fontName = strings.TrimSuffix(base, filepath.Ext(base))
		}
		if cfg.FontFile != "" {
			if err := api.InstallFonts([]string{cfg.FontFile}); err != nil {
				log.Printf("marking: авто-установка шрифта %s не удалась: %v. "+
					"Установите один раз `pdfcpu fonts install <path>` и укажите marking.font_name "+
					"(ВНУТРЕННЕЕ имя шрифта, напр. LiberationSans).", cfg.FontFile, err)
			} else {
				log.Printf("marking: шрифт %q установлен для вжигания", fontName)
			}
			if data, err := os.ReadFile(cfg.FontFile); err == nil {
				if f, err := opentype.Parse(data); err == nil {
					measFont = f
				}
			}
		}
		if fontName == "" {
			log.Printf("marking: кириллический шрифт не задан — кириллица в штампах не отобразится")
		}
	})

	RenderHook = renderWithPDFCPU
}

func renderWithPDFCPU(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 {
		return original, nil
	}
	buf := make([]byte, len(original))
	copy(buf, original)

	applied := 0
	for _, s := range specs {
		desc := textWatermarkDesc(s)
		wm, err := api.TextWatermark(s.Text, desc, true /*onTop*/, false /*update*/, types.POINTS)
		if err != nil {
			log.Printf("marking: watermark build failed for %q: %v", s.Text, err)
			continue
		}
		var out bytes.Buffer
		if err := api.AddWatermarks(bytes.NewReader(buf), &out, []string{"1"}, wm, nil); err != nil {
			log.Printf("marking: apply watermark failed for %q: %v", s.Text, err)
			continue
		}
		buf = out.Bytes()
		applied++
	}
	if applied == 0 {
		return original, nil
	}
	return buf, nil
}

// textWatermarkDesc строит описание watermark. Позиционирование считаем так,
// чтобы КРАЙ текста совпал с overlay: overlay ставит рамку на (ax, ay) от угла
// внутрь; pdfcpu ставит ЦЕНТР текста в (угол + offset), offset: dx→вправо(+),
// dy→ВВЕРХ(+). Значит центр должен быть на (ax + w/2, ay + h/2) от угла с учётом
// инверсии Y. Размеры (w,h) измеряем по шрифту.
func textWatermarkDesc(s Spec) string {
	ax := absInt(int(s.OffsetX))
	ay := absInt(int(s.OffsetY))
	w, h := measureText(s.Text, s.FontSize)
	cx := ax + w/2
	cy := ay + h/2
	var dx, dy int
	switch s.Position {
	case "tl":
		dx, dy = cx, -cy
	case "tr":
		dx, dy = -cx, -cy
	case "bl":
		dx, dy = cx, cy
	case "br":
		dx, dy = -cx, cy
	case "c":
		dx, dy = 0, 0
	default:
		dx, dy = -cx, cy
	}
	op := s.Opacity
	if op <= 0 {
		op = 1.0
	}
	parts := []string{
		fmt.Sprintf("pos:%s", s.Position),
		fmt.Sprintf("offset:%d %d", dx, dy),
		fmt.Sprintf("points:%d", s.FontSize),
		fmt.Sprintf("fillcolor:%s", s.Color),
		"scalefactor:1 abs",
		"rotation:0",
		fmt.Sprintf("opacity:%.2f", op),
	}
	if fontName != "" {
		parts = append(parts, fmt.Sprintf("fontname:%s", fontName))
	}
	if s.Border {
		// pdfcpu ждёт ЧИСЛОВУЮ ширину рамки; "border:on" приводит к падению.
		parts = append(parts, "border:1")
	}
	return strings.Join(parts, ", ")
}

// measureText возвращает ширину (макс. строка) и высоту (все строки) текста в
// пунктах при заданном размере шрифта — по самому TTF. Если шрифт не загружен,
// используется грубая оценка.
func measureText(text string, fontSize int) (int, int) {
	fs := float64(fontSize)
	if fs <= 0 {
		fs = 9
	}
	lines := strings.Split(text, "\n")
	if measFont == nil {
		// Грубая оценка: ширина ~0.55*размер на символ, высота ~1.3*размер.
		maxLen := 0
		for _, ln := range lines {
			if l := len([]rune(ln)); l > maxLen {
				maxLen = l
			}
		}
		return int(float64(maxLen) * fs * 0.55), int(float64(len(lines)) * fs * 1.3)
	}
	face, err := opentype.NewFace(measFont, &opentype.FaceOptions{Size: fs, DPI: 72, Hinting: xfont.HintingFull})
	if err != nil {
		return int(fs * 10), int(fs * 1.3 * float64(len(lines)))
	}
	defer face.Close()
	m := face.Metrics()
	lineH := m.Ascent.Ceil() + m.Descent.Ceil() + 2
	maxW := 0
	for _, ln := range lines {
		if w := xfont.MeasureString(face, ln).Ceil(); w > maxW {
			maxW = w
		}
	}
	return maxW, lineH * len(lines)
}

func absInt(v int) int {
	if v < 0 {
		return -v
	}
	return v
}
