package handlers

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/service"
	"sed-system/backend/internal/ws"
)

var errForbiddenDelete = errors.New("forbidden delete")

type DocumentCreateHandler struct {
	pool *pgxpool.Pool
	svc  *service.DocumentsService
	hub  *ws.Hub
}

func NewDocumentCreateHandler(pool *pgxpool.Pool, svc *service.DocumentsService, hub *ws.Hub) *DocumentCreateHandler {
	return &DocumentCreateHandler{pool: pool, svc: svc, hub: hub}
}

// approverDTO — один согласующий в маршруте. stage_type: hierarchy|cross_dept.
type approverDTO struct {
	StageType  string `json:"stage_type"`
	ApproverID int64  `json:"approver_id"`
}

// routeDTO — маршрут, приходящий с фронта: список согласующих (может быть
// пустым — согласование пропускается), флаг последовательности и
// обязательный подписант (подпись всегда после всех согласований).
type routeDTO struct {
	Approvers  []approverDTO `json:"approvers"`
	Sequential bool          `json:"sequential"`
	SignerID   int64         `json:"signer_id"`  // обратная совместимость (один подписант)
	SignerIDs  []int64       `json:"signer_ids"` // #3 — мультиподпись
}

// signerIDs возвращает список подписантов из DTO, поддерживая и новый формат
// (signer_ids), и старый (signer_id). Дубли и нули отбрасываются.
func (r routeDTO) signerIDs() []int64 {
	seen := make(map[int64]bool)
	out := make([]int64, 0, len(r.SignerIDs)+1)
	appendID := func(id int64) {
		if id != 0 && !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	for _, id := range r.SignerIDs {
		appendID(id)
	}
	appendID(r.SignerID)
	return out
}

// Create POST /api/documents (multipart/form-data)
//
//	title, body_summary, urgency, due_date, due_datetime — текстовые поля
//	route      — JSON: { approvers:[{stage_type,approver_id}], sequential, signer_id }
//	file       — PDF-оригинал
func (h *DocumentCreateHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	title := c.FormValue("title")
	if title == "" {
		return fiber.NewError(fiber.StatusBadRequest, "title обязателен")
	}
	bodySummary := c.FormValue("body_summary")
	urgency := c.FormValue("urgency", "normal")

	var dueDate, dueDatetime *string
	if v := c.FormValue("due_date"); v != "" {
		dueDate = &v
	}
	if v := c.FormValue("due_datetime"); v != "" {
		dueDatetime = &v
	}

	var route routeDTO
	if v := c.FormValue("route"); v != "" {
		if err := json.Unmarshal([]byte(v), &route); err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "некорректный JSON в поле route")
		}
	}
	signerIDs := route.signerIDs()
	if len(signerIDs) == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "подписант обязателен")
	}

	approvers := make([]service.ApproverInput, len(route.Approvers))
	for i, a := range route.Approvers {
		approvers[i] = service.ApproverInput{StageType: a.StageType, ApproverID: a.ApproverID}
	}

	// Плановые получатели рассылки (выбираются на этапе создания). JSON-массив
	// [{user_id, department_id}]. Применятся после подписания документа.
	var recipients []service.Recipient
	if v := c.FormValue("recipients"); v != "" {
		var rDTO []struct {
			UserID       int64 `json:"user_id"`
			DepartmentID int64 `json:"department_id"`
		}
		if err := json.Unmarshal([]byte(v), &rDTO); err != nil {
			return fiber.NewError(fiber.StatusBadRequest, "некорректный JSON в поле recipients")
		}
		for _, r := range rDTO {
			recipients = append(recipients, service.Recipient{UserID: r.UserID, DepartmentID: r.DepartmentID})
		}
	}

	fileHeader, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "файл (PDF) обязателен")
	}
	f, err := fileHeader.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось открыть файл")
	}
	defer f.Close()
	content, err := io.ReadAll(f)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось прочитать файл")
	}

	var authorDepartmentID int64
	var docID int64
	var notify []int64

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(), `SELECT primary_department_id FROM users WHERE id = $1`, userID).
			Scan(&authorDepartmentID); err != nil {
			return err
		}
		id, activated, err := h.svc.Create(c.Context(), tx, service.CreateDocumentInput{
			AuthorID:           userID,
			AuthorDepartmentID: authorDepartmentID,
			Title:              title,
			BodySummary:        bodySummary,
			Urgency:            urgency,
			DueDate:            dueDate,
			DueDatetime:        dueDatetime,
			FileContent:        content,
			Route: service.RouteInput{
				Approvers:  approvers,
				Sequential: route.Sequential,
				SignerIDs:  signerIDs,
			},
			Recipients: recipients,
		})
		if err != nil {
			return err
		}
		docID = id
		notify = activated
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrNotPDF):
			return fiber.NewError(fiber.StatusBadRequest, "разрешена загрузка только PDF-файлов")
		case errors.Is(txErr, service.ErrSelfApproval):
			return fiber.NewError(fiber.StatusBadRequest, "нельзя назначить самого себя согласующим")
		case errors.Is(txErr, service.ErrSignerIsApprover):
			return fiber.NewError(fiber.StatusBadRequest, "один и тот же сотрудник указан и согласующим, и подписантом — уберите его из одного из списков")
		case errors.Is(txErr, service.ErrDuplicateApprover):
			return fiber.NewError(fiber.StatusBadRequest, "один и тот же согласующий добавлен несколько раз")
		case errors.Is(txErr, service.ErrApproverWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "выбранный согласующий не состоит в нужной группе согласования")
		case errors.Is(txErr, service.ErrSignerWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "выбранный подписант не имеет права подписи")
		case errors.Is(txErr, service.ErrNoSigner):
			return fiber.NewError(fiber.StatusBadRequest, "подписант обязателен")
		default:
			log.Printf("create document failed (user=%d): %v", userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось создать документ")
		}
	}

	h.hub.NotifyUsers(notify, docID, "stage_pending")
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": docID})
}

// UpdatePlannedRecipients PATCH /api/documents/:id/planned-recipients — заменить
// плановых адресатов рассылки (форма редактирования). Тело:
// { recipients: [{ user_id, department_id }] }.
func (h *DocumentCreateHandler) UpdatePlannedRecipients(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Recipients []struct {
			UserID       int64 `json:"user_id"`
			DepartmentID int64 `json:"department_id"`
		} `json:"recipients"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	recipients := make([]service.Recipient, 0, len(req.Recipients))
	for _, r := range req.Recipients {
		if r.UserID == 0 || r.DepartmentID == 0 {
			return fiber.NewError(fiber.StatusBadRequest, "у каждого получателя нужны user_id и department_id")
		}
		recipients = append(recipients, service.Recipient{UserID: r.UserID, DepartmentID: r.DepartmentID})
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.SetPlannedRecipients(c.Context(), tx, docID, userID, recipients)
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrNotEditable):
			return fiber.NewError(fiber.StatusConflict, "рассылку нельзя изменить: документ уже разослан")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		default:
			if strings.Contains(txErr.Error(), "must have role clerk") {
				return fiber.NewError(fiber.StatusBadRequest, "получателем может быть только дежурный или сотрудник канцелярии")
			}
			log.Printf("update planned recipients failed (user=%d): %v", userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить рассылку")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}

type updateRequest struct {
	Title       string  `json:"title"`
	BodySummary string  `json:"body_summary"`
	Urgency     string  `json:"urgency"`
	DueDate     *string `json:"due_date"`
	DueDatetime *string `json:"due_datetime"`
}

// Update PATCH /api/documents/:id — изменение метаданных документа с учётом
// этапа (см. DocumentsService.Update: запрещено после начала согласования).
func (h *DocumentCreateHandler) Update(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req updateRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.Title == "" {
		return fiber.NewError(fiber.StatusBadRequest, "title обязателен")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.Update(c.Context(), tx, docID, userID, service.UpdateInput{
			Title:       req.Title,
			BodySummary: req.BodySummary,
			Urgency:     req.Urgency,
			DueDate:     req.DueDate,
			DueDatetime: req.DueDatetime,
		})
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrNotEditable):
			return fiber.NewError(fiber.StatusConflict, "документ нельзя изменить на текущем этапе")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		default:
			log.Printf("update document failed (user=%d): %v", userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить документ")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}

// UpdateRoute PATCH /api/documents/:id/route — заменить маршрут согласования
// и подписанта (только до начала согласования; иначе 409). Тело — тот же
// routeDTO, что при создании.
func (h *DocumentCreateHandler) UpdateRoute(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var route routeDTO
	if err := c.BodyParser(&route); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	signerIDs := route.signerIDs()
	if len(signerIDs) == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "подписант обязателен")
	}
	approvers := make([]service.ApproverInput, len(route.Approvers))
	for i, a := range route.Approvers {
		approvers[i] = service.ApproverInput{StageType: a.StageType, ApproverID: a.ApproverID}
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.ReplaceRoute(c.Context(), tx, docID, userID, service.RouteInput{
			Approvers:  approvers,
			Sequential: route.Sequential,
			SignerIDs:  signerIDs,
		})
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrNotEditable):
			return fiber.NewError(fiber.StatusConflict, "маршрут нельзя изменить: согласование уже началось")
		case errors.Is(txErr, service.ErrSelfApproval):
			return fiber.NewError(fiber.StatusBadRequest, "нельзя назначить самого себя согласующим")
		case errors.Is(txErr, service.ErrSignerIsApprover):
			return fiber.NewError(fiber.StatusBadRequest, "один и тот же сотрудник указан и согласующим, и подписантом — уберите его из одного из списков")
		case errors.Is(txErr, service.ErrDuplicateApprover):
			return fiber.NewError(fiber.StatusBadRequest, "один и тот же согласующий добавлен несколько раз")
		case errors.Is(txErr, service.ErrApproverWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "согласующий не состоит в нужной группе")
		case errors.Is(txErr, service.ErrSignerWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "подписант не имеет права подписи")
		default:
			log.Printf("update route failed (user=%d): %v", userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить маршрут")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}

// ReplaceFile PATCH /api/documents/:id/file (multipart) — заменяет PDF-оригинал
// до подписи и сбрасывает согласование (см. service.ReplaceFile).
func (h *DocumentCreateHandler) ReplaceFile(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	fileHeader, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "файл (PDF) обязателен")
	}
	f, err := fileHeader.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось открыть файл")
	}
	defer f.Close()
	content, err := io.ReadAll(f)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось прочитать файл")
	}
	if !bytes.HasPrefix(content, []byte("%PDF-")) {
		return fiber.NewError(fiber.StatusBadRequest, "файл должен быть в формате PDF")
	}
	sum := sha256.Sum256(content)

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.ReplaceFile(c.Context(), tx, docID, userID, content, hex.EncodeToString(sum[:]))
	})
	if txErr != nil {
		if errors.Is(txErr, service.ErrNotEditable) {
			return fiber.NewError(fiber.StatusConflict, "заменить файл можно только у своего ещё не подписанного документа")
		}
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось заменить файл")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/documents/:id — удаление документа автором. Разрешено
// только для черновиков и отклонённых (когда согласование не завершилось
// подписанием). ON DELETE CASCADE убирает связанные записи.
func (h *DocumentCreateHandler) Delete(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID int64
		var hasSignature bool
		if err := tx.QueryRow(c.Context(), `
			SELECT d.author_id,
			       EXISTS(SELECT 1 FROM document_signatures s WHERE s.document_id = d.id)
			FROM documents d WHERE d.id=$1`, docID).Scan(&authorID, &hasSignature); err != nil {
			return err
		}
		if authorID != userID && !isAdmin {
			return errForbiddenDelete
		}
		// Удалять можно ЛЮБОЙ ещё не подписанный документ (черновик, на
		// согласовании, на подписи, отклонённый). Факт подписи определяем по
		// наличию записи в document_signatures — надёжнее, чем по статусу.
		if hasSignature && !isAdmin {
			return errForbiddenDelete
		}
		_, err := tx.Exec(c.Context(), `DELETE FROM documents WHERE id=$1`, docID)
		return err
	})
	if txErr != nil {
		if txErr == errForbiddenDelete {
			return fiber.NewError(fiber.StatusForbidden, "удалить можно только свой ещё не подписанный документ")
		}
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить документ")
	}
	return c.SendStatus(fiber.StatusOK)
}
