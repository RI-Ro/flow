package handlers

import (
	"errors"
	"fmt"
	"log"
	"net/url"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/config"
	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/marking"
	"sed-system/backend/internal/service"
)

// PrintsHandler — учёт скачиваний «на печать» по копиям и регистрация
// распечатанных экземпляров в бумажном журнале.
type PrintsHandler struct {
	pool        *pgxpool.Pool
	markingData *service.MarkingDataService
	markingCfg  config.MarkingConfig
}

func NewPrintsHandler(pool *pgxpool.Pool, md *service.MarkingDataService, mc config.MarkingConfig) *PrintsHandler {
	return &PrintsHandler{pool: pool, markingData: md, markingCfg: mc}
}

var (
	errNoPrintRole    = errors.New("нет роли печати")
	errNotSigned      = errors.New("документ не подписан")
	errRegisterOthers = errors.New("нельзя ставить/менять отметку о регистрации за другого пользователя")
	errPrintNotFound  = errors.New("запись о печати не найдена")
	errNoBaking       = errors.New("вжигание маркировки выключено")
	errMarkingFailed  = errors.New("маркировка не удалась")
	errMarkingIncomplete = errors.New("документ промаркирован не полностью")
)

// buildPrintFilename формирует имя файла печати по шаблону (#6b). Плейсхолдеры:
// {title} {number} {instance} {copy} {time} {downloader}. Небезопасные для имени
// символы заменяются на "_". Всегда добавляет расширение .pdf.
func buildPrintFilename(tmpl, title, number string, instance, copy int, downloader string) string {
	if strings.TrimSpace(tmpl) == "" {
		tmpl = "{title}_№{number}_экз{instance}_копия{copy}_{time}_{downloader}"
	}
	rep := strings.NewReplacer(
		"{title}", title,
		"{number}", number,
		"{instance}", fmt.Sprintf("%d", instance),
		"{copy}", fmt.Sprintf("%d", copy),
		"{time}", time.Now().Format("2006-01-02_15-04-05"),
		"{downloader}", downloader,
	)
	name := rep.Replace(tmpl)
	// Санитизация: убираем разделители путей и управляющие/недопустимые символы.
	name = strings.Map(func(r rune) rune {
		switch r {
		case '/', '\\', ':', '*', '?', '"', '<', '>', '|', '\n', '\r', '\t':
			return '_'
		}
		return r
	}, name)
	name = strings.Trim(name, " .")
	if name == "" {
		name = "document-print"
	}
	if !strings.HasSuffix(strings.ToLower(name), ".pdf") {
		name += ".pdf"
	}
	return name
}

// requiredMarkingsMissing возвращает список отсутствующих ОБЯЗАТЕЛЬНЫХ маркировок
// для выдачи на печать (#10). Проверяем: подпись (ФИО подписанта или хэш
// подписи), исходящий номер, экземпляр владельца, номер печатной копии и
// «маркировку для скачивания» (реквизит хранения — куда/как выдан документ).
// Входящий номер и архив — контекстные (есть не у каждого документа), поэтому в
// обязательные не включены, но наносятся, если присутствуют.
func requiredMarkingsMissing(ph marking.Placeholders) []string {
	var missing []string
	if ph[marking.KeySignerFIO] == "" && ph[marking.KeySignHash] == "" {
		missing = append(missing, "подпись")
	}
	if ph[marking.KeyOutgoingNumber] == "" {
		missing = append(missing, "исходящий номер")
	}
	if ph[marking.KeyInstanceLabel] == "" {
		missing = append(missing, "экземпляр")
	}
	// Отдельный «штамп для скачанного документа» (номер печатной копии/место
	// хранения) убран (#9): на печать он больше не требуется и не наносится.
	// Входящий номер и архив — контекстные: наносятся при наличии, не блокируют.
	return missing
}

// isSignedStatus — статусы, при которых документ считается подписанным и его
// можно выдавать на печать.
func isSignedStatus(s string) bool {
	switch s {
	case "signed", "sent", "in_progress", "executed", "archived":
		return true
	}
	return false
}

// Download POST /api/documents/:id/print — выдаёт МАРКИРОВАННЫЙ PDF для печати.
// Только роль printer (или admin). Только для ПОДПИСАННОГО документа. Каждое
// скачивание фиксируется как отдельная копия (copy_number += 1) и наносится на
// маркировку («Экз. № …, Копия № …»). Без маркировки документ не выдаётся.
// Опционально ?copy_id=<id> — перепечатать СУЩЕСТВУЮЩУЮ копию (с её отметкой о
// регистрации), не создавая новую.
func (h *PrintsHandler) Download(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор документа")
	}
	reprintID, _ := strconv.ParseInt(c.Query("copy_id"), 10, 64)

	var content []byte
	var marked []byte
	var printFilename string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// 1) Роль печати.
		if !isAdmin {
			var ok bool
			if err := tx.QueryRow(c.Context(),
				`SELECT EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role='printer')`, userID).Scan(&ok); err != nil {
				return err
			}
			if !ok {
				return errNoPrintRole
			}
		}
		// 2) Документ должен быть подписан, и берём файл (RLS через JOIN).
		var status string
		if err := tx.QueryRow(c.Context(),
			`SELECT status::text FROM documents WHERE id=$1`, id).Scan(&status); err != nil {
			return err
		}
		if !isSignedStatus(status) {
			return errNotSigned
		}
		if err := tx.QueryRow(c.Context(), `
			SELECT f.content FROM document_files f
			JOIN documents d ON d.id = f.document_id
			WHERE f.document_id = $1`, id).Scan(&content); err != nil {
			return err
		}
		// 3) Экземпляр пользователя (document_copies).
		var instance int
		_ = tx.QueryRow(c.Context(),
			`SELECT copy_number FROM document_copies WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&instance)

		var copyNum int
		var regJournal, regNumber, regFio *string
		var regAt *time.Time
		if reprintID > 0 {
			// Перепечатка существующей копии (с её реквизитами регистрации).
			var owner int64
			if err := tx.QueryRow(c.Context(), `
				SELECT user_id, instance_number, copy_number, reg_journal, reg_number, reg_at, registrant_fio
				FROM document_prints WHERE id=$1 AND document_id=$2`, reprintID, id).
				Scan(&owner, &instance, &copyNum, &regJournal, &regNumber, &regAt, &regFio); err != nil {
				return err
			}
			if owner != userID && !isAdmin {
				return errRegisterOthers
			}
		} else {
			// Новая копия: следующий номер в рамках (документ, пользователь).
			if err := tx.QueryRow(c.Context(), `
				INSERT INTO document_prints (document_id, instance_number, user_id, copy_number)
				SELECT $1, $2, $3, COALESCE(MAX(copy_number),0)+1
				FROM document_prints WHERE document_id=$1 AND user_id=$3
				RETURNING copy_number`, id, instance, userID).Scan(&copyNum); err != nil {
				return err
			}
		}
		// 4) Маркировка: базовые штампы + владелец + номер копии.
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, userID, ph); err != nil {
			return err
		}
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		// #6 — Рядом с номером ЭКЗЕМПЛЯРА печатаем номер КОПИИ (порядковый номер
		// данной распечатки для этого пользователя). Дописываем в тот же штамп
		// экземпляра, чтобы стиль был идентичен предпросмотру (отдельный штамп
		// «для скачивания» не используем).
		if ph[marking.KeyInstanceLabel] != "" {
			ph[marking.KeyInstanceLabel] = fmt.Sprintf("%s · Копия № %d", ph[marking.KeyInstanceLabel], copyNum)
		} else {
			ph[marking.KeyInstanceLabel] = fmt.Sprintf("Копия № %d", copyNum)
		}
		_ = regJournal
		_ = regNumber
		_ = regFio
		_ = regAt
		// #10 — Перед выдачей на печать проверяем, что документ промаркирован
		// ВСЕМИ обязательными маркировками: о подписи (ФИО подписанта или хэш),
		// исходящий номер, номер экземпляра владельца, номер печатной копии и
		// маркировка «для скачивания» (реквизиты хранения/архив). Без любой из
		// них на скачивание не выдаём и факт скачивания НЕ фиксируем (транзакция
		// откатится по возврату ошибки).
		missing := requiredMarkingsMissing(ph)
		if len(missing) > 0 {
			log.Printf("print blocked for doc %d: missing markings %v", id, missing)
			return errMarkingIncomplete
		}
		// 5) МАРКИРОВКА ВНУТРИ ТРАНЗАКЦИИ. Если вжигание выключено или маркировка
		//    не удалась — возвращаем ошибку, и транзакция ОТКАТЫВАЕТСЯ: строка
		//    document_prints НЕ сохраняется (факт скачивания не фиксируется).
		// #6b — Имя файла печати по шаблону из конфига. Собираем реквизиты.
		var docTitle, outNum, downloaderFIO string
		var ownerCopy *int
		_ = tx.QueryRow(c.Context(), `
			SELECT coalesce(d.title,''), coalesce(d.outgoing_number,''),
			       coalesce((SELECT full_name FROM users WHERE id=$2),''),
			       (SELECT copy_number FROM document_copies WHERE document_id=$1 AND user_id=$2)
			FROM documents d WHERE d.id=$1`, id, userID).Scan(&docTitle, &outNum, &downloaderFIO, &ownerCopy)
		instNum := 0
		if ownerCopy != nil {
			instNum = *ownerCopy
		}
		printFilename = buildPrintFilename(h.markingCfg.PrintFilenameTemplate, docTitle, outNum, instNum, copyNum, downloaderFIO)
		if !marking.IsBaking(h.markingCfg) {
			return errNoBaking
		}
		m, err := marking.Apply(content, h.markingCfg, ph)
		if err != nil {
			log.Printf("print marking failed for doc %d: %v", id, err)
			return errMarkingFailed
		}
		marked = m
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errNoPrintRole):
			return fiber.NewError(fiber.StatusForbidden, "скачивание на печать доступно только пользователю с ролью «Печать»")
		case errors.Is(txErr, errNotSigned):
			return fiber.NewError(fiber.StatusUnprocessableEntity, "на печать можно скачать только подписанный документ")
		case errors.Is(txErr, errRegisterOthers):
			return fiber.NewError(fiber.StatusForbidden, "нельзя перепечатывать копию другого пользователя")
		case errors.Is(txErr, errNoBaking):
			return fiber.NewError(fiber.StatusServiceUnavailable,
				"маркировка PDF не настроена (marking.bake_into_pdf) — выдача на печать без маркировки запрещена; факт скачивания не зафиксирован")
		case errors.Is(txErr, errMarkingFailed):
			return fiber.NewError(fiber.StatusInternalServerError,
				"не удалось нанести маркировку — документ на печать не выдан; факт скачивания не зафиксирован")
		case errors.Is(txErr, errMarkingIncomplete):
			return fiber.NewError(fiber.StatusUnprocessableEntity,
				"документ промаркирован не полностью (нет обязательных маркировок: подпись, исходящий номер, экземпляр) — на скачивание не выдан")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "файл документа не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выдать документ на печать")
	}

	c.Set("Content-Type", "application/pdf")
	if printFilename == "" {
		printFilename = "document-" + strconv.FormatInt(id, 10) + "-print.pdf"
	}
	// RFC 5987: filename* с UTF-8 позволяет кириллицу в имени файла; ASCII-fallback
	// для старых клиентов.
	c.Set("Content-Disposition", "attachment; filename=\"document-"+strconv.FormatInt(id, 10)+"-print.pdf\"; filename*=UTF-8''"+url.PathEscape(printFilename))
	c.Set("X-Content-Type-Options", "nosniff")
	c.Set("Cache-Control", "no-store")
	return c.Send(marked)
}

// List GET /api/documents/:id/prints — реестр печатных копий документа.
func (h *PrintsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор документа")
	}
	type item struct {
		ID          int64      `json:"id"`
		UserID      int64      `json:"user_id"`
		FullName    string     `json:"full_name"`
		Instance    int        `json:"instance_number"`
		CopyNumber  int        `json:"copy_number"`
		PrintedAt   time.Time  `json:"printed_at"`
		RegJournal  *string    `json:"reg_journal,omitempty"`
		RegNumber   *string    `json:"reg_number,omitempty"`
		RegAt       *time.Time `json:"reg_at,omitempty"`
		RegistrantF *string    `json:"registrant_fio,omitempty"`
	}
	var out []item
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT p.id, p.user_id, u.full_name, p.instance_number, p.copy_number, p.printed_at,
			       p.reg_journal, p.reg_number, p.reg_at, p.registrant_fio
			FROM document_prints p
			JOIN documents d ON d.id = p.document_id
			JOIN users u ON u.id = p.user_id
			WHERE p.document_id = $1
			ORDER BY p.printed_at DESC`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it item
			if err := rows.Scan(&it.ID, &it.UserID, &it.FullName, &it.Instance, &it.CopyNumber, &it.PrintedAt,
				&it.RegJournal, &it.RegNumber, &it.RegAt, &it.RegistrantF); err != nil {
				return err
			}
			out = append(out, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить список печати")
	}
	return c.JSON(fiber.Map{"items": out})
}

// Register PATCH /api/documents/:id/prints/:printId/register — пользователь
// ставит ИЛИ ИЗМЕНЯЕТ отметку о регистрации СВОЕЙ печатной копии в бумажном
// журнале. За других ставить/менять нельзя.
func (h *PrintsHandler) Register(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	printID, err := strconv.ParseInt(c.Params("printId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор копии")
	}
	var req struct {
		RegJournal string `json:"reg_journal"`
		RegNumber  string `json:"reg_number"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.RegJournal == "" || req.RegNumber == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите журнал и регистрационный номер")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var owner int64
		if err := tx.QueryRow(c.Context(),
			`SELECT user_id FROM document_prints WHERE id=$1`, printID).Scan(&owner); err != nil {
			return err
		}
		if owner != userID {
			return errRegisterOthers
		}
		// Разрешаем и первичную отметку, и ИЗМЕНЕНИЕ ранее внесённой.
		ct, err := tx.Exec(c.Context(), `
			UPDATE document_prints
			SET reg_journal=$2, reg_number=$3, reg_at=now(), registered_by=$4,
			    registrant_fio=(SELECT full_name FROM users WHERE id=$4)
			WHERE id=$1`, printID, req.RegJournal, req.RegNumber, userID)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return errPrintNotFound
		}
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errRegisterOthers):
			return fiber.NewError(fiber.StatusForbidden, "нельзя ставить/менять отметку о регистрации за другого пользователя")
		case errors.Is(txErr, errPrintNotFound), errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "запись о печати не найдена")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сохранить отметку о регистрации")
	}
	return c.SendStatus(fiber.StatusOK)
}
