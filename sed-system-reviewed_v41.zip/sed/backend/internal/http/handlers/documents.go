package handlers

import (
	"errors"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"sed-system/backend/internal/db"
	"sed-system/backend/internal/http/middleware"
	"sed-system/backend/internal/config"
	"sed-system/backend/internal/marking"
	"sed-system/backend/internal/repository"
	"sed-system/backend/internal/service"
)

type DocumentsHandler struct {
	pool        *pgxpool.Pool
	repo        *repository.DocumentsRepo
	incoming    *service.IncomingService
	markingData *service.MarkingDataService
	markingCfg  config.MarkingConfig
	pageSize    int
	pageMax     int
}

func NewDocumentsHandler(pool *pgxpool.Pool, repo *repository.DocumentsRepo, incoming *service.IncomingService, markingData *service.MarkingDataService, markingCfg config.MarkingConfig, pageSize, pageMax int) *DocumentsHandler {
	return &DocumentsHandler{pool: pool, repo: repo, incoming: incoming, markingData: markingData, markingCfg: markingCfg, pageSize: pageSize, pageMax: pageMax}
}

// List GET /api/documents?category=on_approval&page=2&department_id=4
func (h *DocumentsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	category := repository.Category(c.Query("category", "all"))
	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}
	deptID, _ := strconv.ParseInt(c.Query("department_id", "0"), 10, 64)

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Если подразделение не задано явно — берём основное подразделение
		// пользователя. Иначе категория «Исходящие» (фильтр по
		// author_department_id) оказывалась пустой (deptID=0 не совпадает ни
		// с одним документом) — из-за этого у автора не отображались исходящие.
		if deptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
				return e
			}
		}
		year, _ := strconv.Atoi(c.Query("year"))
		res, err := h.repo.List(c.Context(), tx, category, userID, deptID, page, pageSize, year)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить документы")
	}
	return c.JSON(result)
}

// GetMarking GET /api/documents/:id/marking — вычисленные штампы для overlay
// на фронте (текст с подставленными плейсхолдерами, позиция, цвет, размер,
// рамка). Поле baked=true, если бэкенд уже вжигает штампы в PDF (тогда фронт
// overlay не рисует). Данные считаются по той же логике, что и вжигание.
func (h *DocumentsHandler) GetMarking(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверяем, что документ виден текущему пользователю (RLS) — иначе
		// не отдаём его реквизиты маркировки.
		var one int
		if err := tx.QueryRow(c.Context(), `SELECT 1 FROM documents WHERE id=$1`, id).Scan(&one); err != nil {
			return err
		}
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, userID, ph); err != nil {
			return err
		}
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось вычислить маркировку")
	}

	specs := marking.ComputeSpecs(h.markingCfg, placeholders)
	stamps := make([]fiber.Map, 0, len(specs))
	for _, s := range specs {
		stamps = append(stamps, fiber.Map{
			"text":         s.Text,
			"position":     s.Position, // tl/tr/bl/br/c
			"offset_x":     s.OffsetX,
			"offset_y":     s.OffsetY,
			"font_size":    s.FontSize,
			"color":        s.ColorHex,
			"border":       s.Border,
			"border_color": s.BorderColorHex,
			"fill":         s.FillColorHex,
			// Факсимиле/печать как data-URL — для двухколоночного штампа
			// (слева изображение, справа текст).
			"image": marking.ImageDataURL(s.ImageFile),
		})
	}
	return c.JSON(fiber.Map{"stamps": stamps, "baked": marking.IsBaking(h.markingCfg)})
}

// Get GET /api/documents/:id
func (h *DocumentsHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var doc any
	var marking *service.IncomingMarking
	var myCopy *int

	// 1) ЧТЕНИЕ документа — единственный источник 404. Если документ не виден
	// (не существует или скрыт RLS) — 404. Иначе документ ОБЯЗАН открыться.
	readErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		d, err := h.repo.GetByID(c.Context(), tx, id)
		if err != nil {
			return err
		}
		doc = d
		return nil
	})
	if readErr != nil {
		if errors.Is(readErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить документ")
	}

	// 2) ПОБОЧНЫЕ ЭФФЕКТЫ (регистрация просмотра, входящего экземпляра, выдача
	// номера экземпляра) — BEST-EFFORT в ОТДЕЛЬНОЙ транзакции. Их сбой НЕ должен
	// мешать открытию документа (иначе первый заход мог падать 404/500, а
	// повторный открывался — как в отчётах). Ошибку логируем и продолжаем.
	sideErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		m, err := h.incoming.RegisterView(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		marking = m
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_views (document_id, viewer_id)
			SELECT $1, $2
			WHERE NOT EXISTS (
				SELECT 1 FROM document_views
				WHERE document_id = $1 AND viewer_id = $2
				  AND viewed_at > now() - interval '10 seconds'
			)`, id, userID); err != nil {
			return err
		}
		var copyReason *string
		_ = tx.QueryRow(c.Context(), `
			SELECT access_reason FROM document_access
			WHERE document_id=$1 AND user_id=$2
			ORDER BY granted_at LIMIT 1`, id, userID).Scan(&copyReason)
		reason := "view"
		if copyReason != nil && *copyReason != "" {
			reason = *copyReason
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_copies (document_id, user_id, copy_number, reason)
			SELECT $1, $2, COALESCE(MAX(copy_number),0)+1, $3
			FROM document_copies WHERE document_id = $1
			ON CONFLICT (document_id, user_id) DO NOTHING`, id, userID, reason); err != nil {
			return err
		}
		var cn int32
		if e := tx.QueryRow(c.Context(), `SELECT copy_number FROM document_copies WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&cn); e == nil {
			v := int(cn)
			myCopy = &v
		}
		return nil
	})
	if sideErr != nil {
		// Не фатально — документ уже прочитан и будет отдан. Логируем для аудита.
		log.Printf("document %d view side-effects failed for user %d: %v", id, userID, sideErr)
	}
	return c.JSON(fiber.Map{"document": doc, "incoming_marking": marking, "my_copy_number": myCopy})
}

// Copies GET /api/documents/:id/copies — реестр экземпляров документа: у кого
// какой номер экземпляра (Экз. №), за что выдан и когда. Виден всем, у кого
// есть доступ к документу (RLS на document_copies нет, но выборка идёт только
// после проверки доступа к самому документу через GetByID под RLS).
func (h *DocumentsHandler) Copies(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type copyItem struct {
		CopyNumber int    `json:"copy_number"`
		UserID     int64  `json:"user_id"`
		FullName   string `json:"full_name"`
		Reason     string `json:"reason"`
		AssignedAt string `json:"assigned_at"`
	}
	var items []copyItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверка доступа к документу (иначе RLS вернёт ErrNoRows → 404).
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT c.copy_number, c.user_id,
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       c.reason, to_char(c.assigned_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_copies c JOIN users u ON u.id = c.user_id
			WHERE c.document_id = $1
			ORDER BY c.copy_number`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it copyItem
			if err := rows.Scan(&it.CopyNumber, &it.UserID, &it.FullName, &it.Reason, &it.AssignedAt); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить экземпляры")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Search GET /api/documents/search?q=...&page=1&page_size=20
func (h *DocumentsHandler) Search(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}

	filter := repository.SearchFilter{
		Category:       c.Query("category"),
		UserID:         userID,
		Query:          c.Query("q"),
		DueFrom:        c.Query("due_from"),
		DueTo:          c.Query("due_to"),
		CreatedFrom:    c.Query("created_from"),
		CreatedTo:      c.Query("created_to"),
		SignedFrom:     c.Query("signed_from"),
		SignedTo:       c.Query("signed_to"),
		Number:         c.Query("number"),
		IncomingNumber: c.Query("incoming_number"),
		OnControl:      c.Query("on_control"),
	}
	parseID := func(name string) int64 {
		if v := c.Query(name); v != "" {
			id, _ := strconv.ParseInt(v, 10, 64)
			return id
		}
		return 0
	}
	filter.AuthorID = parseID("author_id")
	filter.SignerID = parseID("signer_id")
	filter.ControllerID = parseID("controller_id")
	filter.ApproverID = parseID("approver_id")
	filter.RecipientID = parseID("recipient_id")
	filter.DepartmentID = parseID("department_id")
	if v := c.Query("status"); v != "" {
		filter.Statuses = splitCSV(v)
	}
	if v := c.Query("urgency"); v != "" {
		filter.Urgencies = splitCSV(v)
	}

	// Категория задаёт контекст поиска — если она есть, пустой набор фильтров
	// допустим (просто применяется ограничение категории).
	catScoped := filter.Category != "" && filter.Category != "all"
	empty := !catScoped && filter.Query == "" && filter.AuthorID == 0 && filter.SignerID == 0 &&
		filter.ControllerID == 0 && filter.ApproverID == 0 && filter.RecipientID == 0 &&
		filter.DepartmentID == 0 && len(filter.Statuses) == 0 && len(filter.Urgencies) == 0 &&
		filter.OnControl == "" && filter.DueFrom == "" && filter.DueTo == "" &&
		filter.CreatedFrom == "" && filter.CreatedTo == "" &&
		filter.SignedFrom == "" && filter.SignedTo == "" &&
		filter.Number == "" && filter.IncomingNumber == ""
	if empty {
		return fiber.NewError(fiber.StatusBadRequest, "укажите хотя бы один фильтр")
	}

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Для категории «Исходящие» нужно подразделение пользователя.
		if filter.Category == string(repository.CategoryOutgoing) && filter.DeptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&filter.DeptID); e != nil {
				return e
			}
		}
		res, err := h.repo.Search(c.Context(), tx, filter, page, pageSize)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выполнить поиск документов")
	}
	return c.JSON(result)
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		p := strings.TrimSpace(part)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// GetStages GET /api/documents/:id/stages
func (h *DocumentsHandler) GetStages(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var stages any
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Явно проверяем видимость документа по RLS перед выдачей маршрута —
		// approval_stages не защищена собственной RLS-политикой (см. комментарий
		// в repository.ListStages), поэтому проверка здесь обязательна.
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		s, err := h.repo.ListStages(c.Context(), tx, id)
		if err != nil {
			return err
		}
		stages = s
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить этапы согласования")
	}
	return c.JSON(fiber.Map{"items": stages})
}

// GetFile GET /api/documents/:id/file — отдаёт PDF только для просмотра
// (inline), без возможности скачивания через отдельный "download"-эндпоинт.
func (h *DocumentsHandler) GetFile(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var content []byte
	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// document_files не имеет собственной RLS-политики, но JOIN на
		// documents гарантирует, что мы не отдадим файл документа, невидимого
		// по RLS текущему пользователю (documents.id IN (...) сработает как
		// фильтр даже внутри JOIN, т.к. RLS применяется к каждой строке documents).
		if err := tx.QueryRow(c.Context(), `
			SELECT f.content FROM document_files f
			JOIN documents d ON d.id = f.document_id
			WHERE f.document_id = $1`, id).Scan(&content); err != nil {
			return err
		}
		// Собираем данные для маркировки (номера, подпись, получение).
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		// Подразделение смотрящего — для отметки о получении.
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, userID, ph); err != nil {
			return err
		}
		// Владелец экземпляра (ФИО, подразделение) + номер экземпляра ИМЕННО
		// текущего пользователя (document_copies). Вызывается ПОСЛЕ
		// CollectIncoming, чтобы перекрыть устаревший ярлык из вх. инстанса
		// (он отставал на 1). Так номер в маркировке совпадёт с «Экз. №» сверху.
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "file not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить файл документа")
	}

	// #3/#8 — Экранная маркировка выполняется overlay-штампами вьювера
	// (canvas), а НЕ вжиганием в этот файл. Поэтому для просмотра отдаём
	// документ БЕЗ вжигания: так включение marking.bake_into_pdf не влияет на
	// предпросмотр (и его сбой не ломает просмотр), а пользователь всегда видит
	// штампы через overlay. Вжигание в файл выполняется только при выдаче на
	// ПЕЧАТЬ (см. prints.go). Немаркированного вывода при этом нет: нативный
	// просмотрщик браузера отключён, overlay рисует штампы поверх страниц.
	_ = placeholders // плейсхолдеры используются overlay-эндпоинтом /marking
	marked := content

	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", "inline")
	c.Set("X-Content-Type-Options", "nosniff")
	// Ограничиваем встраивание/кэширование на уровне браузера — это UX-барьер.
	c.Set("Cache-Control", "no-store")
	c.Set("Content-Security-Policy", "frame-ancestors 'self'")
	return c.Send(marked)
}

// History GET /api/documents/:id/history — журнал событий документа
// (вкладка "История документа").
func (h *DocumentsHandler) History(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type event struct {
		EventType  string  `json:"event_type"`
		ActorName  *string `json:"actor_name,omitempty"`
		FromStatus *string `json:"from_status,omitempty"`
		ToStatus   *string `json:"to_status,omitempty"`
		Comment    *string `json:"comment,omitempty"`
		CreatedAt  string  `json:"created_at"`
	}
	var items []event
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT h.event_type, u.full_name, h.from_status::text, h.to_status::text, h.comment,
			       to_char(h.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_history h
			LEFT JOIN users u ON u.id = h.actor_id
			WHERE h.document_id = $1
			ORDER BY h.created_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var e event
			if err := rows.Scan(&e.EventType, &e.ActorName, &e.FromStatus, &e.ToStatus, &e.Comment, &e.CreatedAt); err != nil {
				return err
			}
			items = append(items, e)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить историю")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Views GET /api/documents/:id/views — журнал просмотров (вкладка "История
// просмотров").
func (h *DocumentsHandler) Views(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type view struct {
		ViewerName string `json:"viewer_name"`
		ViewedAt   string `json:"viewed_at"`
	}
	var items []view
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		// Первый просмотр КАЖДОГО пользователя (DISTINCT ON по viewer_id,
		// берём самую раннюю запись). ФИО с должностью.
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT ON (v.viewer_id)
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       to_char(v.viewed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM document_views v JOIN users u ON u.id = v.viewer_id
			WHERE v.document_id = $1
			ORDER BY v.viewer_id, v.viewed_at ASC
			LIMIT 500`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var vw view
			if err := rows.Scan(&vw.ViewerName, &vw.ViewedAt); err != nil {
				return err
			}
			items = append(items, vw)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить просмотры")
	}
	return c.JSON(fiber.Map{"items": items})
}

// SetControl POST /api/documents/:id/control — поставить/снять документ с
// контроля и назначить контролёров. Тело:
// { "on_control": true, "controller_ids": [4,7] }  (или старое "controller_id": 4).
// #4 — контролёров может быть несколько. Все они сохраняются в
// document_controllers; documents.controller_id = первый (для дашборда/реестра).
func (h *DocumentsHandler) SetControl(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		OnControl     bool    `json:"on_control"`
		ControllerID  int64   `json:"controller_id"`  // обратная совместимость
		ControllerIDs []int64 `json:"controller_ids"` // #4
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	// Собираем итоговый набор контролёров (дедуп, без нулей).
	seen := map[int64]bool{}
	var ctlIDs []int64
	for _, cid := range append(req.ControllerIDs, req.ControllerID) {
		if cid != 0 && !seen[cid] {
			seen[cid] = true
			ctlIDs = append(ctlIDs, cid)
		}
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Контролёром можно назначить любого пользователя с ролью controller
		// или default_controller — БЕЗ ограничения по иерархии подразделений
		// (контроль может вести кто угодно из наделённых правом).
		if !isAdmin {
			for _, cid := range ctlIDs {
				var okCtl bool
				if err := tx.QueryRow(c.Context(), `
					SELECT EXISTS(
					  SELECT 1 FROM users u
					  JOIN user_roles ur ON ur.user_id = u.id AND ur.role::text IN ('controller','default_controller')
					  WHERE u.id = $1 AND u.is_active = true
					)`, cid).Scan(&okCtl); err != nil {
					return err
				}
				if !okCtl {
					return errControllerRole
				}
			}
		}
		// Основной контролёр (первый) — в documents.controller_id.
		var primary *int64
		if req.OnControl && len(ctlIDs) > 0 {
			primary = &ctlIDs[0]
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE documents SET on_control=$1, controller_id=$2 WHERE id=$3`,
			req.OnControl, primary, id); err != nil {
			return err
		}
		// Полный набор контролёров — в document_controllers (перезаписываем).
		if _, err := tx.Exec(c.Context(), `DELETE FROM document_controllers WHERE document_id=$1`, id); err != nil {
			return err
		}
		// История: постановка/снятие с контроля.
		evt := "removed_from_control"
		if req.OnControl {
			evt = "put_on_control"
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type)
			VALUES ($1, $2, $3)`, id, userID, evt); err != nil {
			return err
		}
		if req.OnControl {
			for _, cid := range ctlIDs {
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_controllers (document_id, user_id)
					VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_access (document_id, user_id, access_reason)
					VALUES ($1, $2, 'controller') ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				_, _ = tx.Exec(c.Context(), `
					INSERT INTO notifications (user_id, document_id, kind, payload)
					VALUES ($1, $2, 'control_assigned', '{}')`, cid, id)
			}
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errControllerRole) {
			return fiber.NewError(fiber.StatusUnprocessableEntity, "контролёром может быть только пользователь с ролью «контролёр» или «контролёр по умолчанию»")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить контроль")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Controllers GET /api/documents/:id/controllers — список контролёров документа
// (для префилла формы редактирования и отображения в карточке). Доступ через
// RLS: сначала проверяем доступ к документу.
func (h *DocumentsHandler) Controllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type ctl struct {
		UserID         int64  `json:"user_id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.id IN (
			   SELECT user_id FROM document_controllers WHERE document_id=$1
			   UNION
			   SELECT controller_id FROM documents WHERE id=$1 AND controller_id IS NOT NULL
			)
			ORDER BY u.full_name`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.UserID, &x.FullName, &x.Position, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров")
	}
	return c.JSON(fiber.Map{"items": items})
}

// DefaultControllers GET /api/default-controllers — активные пользователи с
// ролью default_controller. Форма создания использует их для ПРЕДВЫБОРА
// контролёров (галочка «на контроле» предустановлена, но автор может изменить
// или снять — контролёр добавляется только с санкции автора).
func (h *DocumentsHandler) DefaultControllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	type ctl struct {
		ID             int64  `json:"id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentID   int64  `json:"department_id"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(u.primary_department_id,0), coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			JOIN user_roles ur ON ur.user_id = u.id AND ur.role::text = 'default_controller'
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.is_active = true
			ORDER BY 2`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.ID, &x.FullName, &x.Position, &x.DepartmentID, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров по умолчанию")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Signatures GET /api/documents/:id/signatures — данные о факте(ах) подписания
// для аудита (63-ФЗ): ФИО/должность/логин подписанта, тип и время подписи,
// отпечаток подписи, хэш содержимого документа, фактический IP и user-agent.
// Доступ через RLS (сначала проверяем доступ к документу).
func (h *DocumentsHandler) Signatures(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type sig struct {
		SignerFIO      string  `json:"signer_fio"`
		SignerPosition string  `json:"signer_position"`
		SignatureType  string  `json:"signature_type"`
		SignedAt       string  `json:"signed_at"`
		SignatureHash  string  `json:"signature_hash"`
		DocumentHash   string  `json:"document_hash"`
	}
	var items []sig
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT coalesce(signer_fio,''), coalesce(signer_position,''),
			       signature_type,
			       to_char(signed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce(signature_hash,''), coalesce(document_hash,'')
			FROM document_signatures WHERE document_id=$1 ORDER BY signed_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var s sig
			if err := rows.Scan(&s.SignerFIO, &s.SignerPosition, &s.SignatureType,
				&s.SignedAt, &s.SignatureHash, &s.DocumentHash); err != nil {
				return err
			}
			items = append(items, s)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить данные о подписи")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Archive POST /api/documents/:id/archive — направить документ в архив.
// #8 — Право: автор или подписант (или admin). Разрешено ТОЛЬКО для
// ИСПОЛНЕННОГО документа (status='executed'). Фиксируется в истории.
func (h *DocumentsHandler) Archive(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if !isAdmin {
			ok, err := service.IsAuthorOrSigner(c.Context(), tx, id, userID)
			if err != nil {
				return err
			}
			if !ok {
				return errArchiveForbidden
			}
		}
		var status string
		if err := tx.QueryRow(c.Context(), `SELECT status FROM documents WHERE id=$1`, id).Scan(&status); err != nil {
			return err
		}
		if status == "archived" {
			return errAlreadyArchived
		}
		if status != "executed" {
			return errNotExecuted
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE documents SET status='archived', archived_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'archived', 'executed'::doc_status, 'archived', 'направлен в архив')`, id, userID); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errArchiveForbidden):
			return fiber.NewError(fiber.StatusForbidden, "направить в архив может только автор или подписант")
		case errors.Is(txErr, errNotExecuted):
			return fiber.NewError(fiber.StatusUnprocessableEntity, "в архив можно направить только исполненный документ")
		case errors.Is(txErr, errAlreadyArchived):
			return fiber.NewError(fiber.StatusConflict, "документ уже в архиве")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		default:
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось направить документ в архив")
		}
	}
	return c.SendStatus(fiber.StatusOK)
}

// MyRoles GET /api/documents/:id/my-roles — в каких качествах текущий
// пользователь участвует в документе. Фронт по этому ответу показывает/скрывает
// вкладки (не участник согласования не видит вкладку маршрута и т.д.).
func (h *DocumentsHandler) MyRoles(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	res := fiber.Map{
		"is_author":     false,
		"is_approver":   false,
		"is_signer":     false,
		"is_controller": false,
		"is_recipient":  false,
		"is_printer":    false,
		"is_admin":      isAdmin,
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID int64
		var controllerID *int64
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, controller_id FROM documents WHERE id=$1`, id).Scan(&authorID, &controllerID); err != nil {
			return err
		}
		res["is_author"] = authorID == userID
		// #4 — контролёров может быть несколько (document_controllers);
		// controller_id хранит основного. Проверяем оба источника.
		isCtl := controllerID != nil && *controllerID == userID
		if !isCtl {
			var cnt int
			if err := tx.QueryRow(c.Context(),
				`SELECT count(*) FROM document_controllers WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&cnt); err != nil {
				return err
			}
			isCtl = cnt > 0
		}
		res["is_controller"] = isCtl

		// Согласующий или подписант — по этапам маршрута.
		var approverCnt, signerCnt int
		if err := tx.QueryRow(c.Context(), `
			SELECT
			  count(*) FILTER (WHERE stage_type IN ('hierarchy','cross_dept')),
			  count(*) FILTER (WHERE stage_type = 'signing')
			FROM approval_stages WHERE document_id=$1 AND approver_id=$2`, id, userID).
			Scan(&approverCnt, &signerCnt); err != nil {
			return err
		}
		res["is_approver"] = approverCnt > 0
		res["is_signer"] = signerCnt > 0

		// Получатель рассылки.
		var recipCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM document_recipients WHERE document_id=$1 AND recipient_user_id=$2`, id, userID).
			Scan(&recipCnt); err != nil {
			return err
		}
		res["is_recipient"] = recipCnt > 0

		// Роль печати — глобально по user_roles (в любом подразделении).
		var printerCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM user_roles WHERE user_id=$1 AND role='printer'`, userID).
			Scan(&printerCnt); err != nil {
			return err
		}
		res["is_printer"] = printerCnt > 0 || isAdmin

		// #6/#7 — Права на ОЗНАКОМЛЕНИЕ и ПОРУЧЕНИЯ не зависят от статуса
		// получателя: доступны, если у пользователя есть подразделения
		// ознакомления/поручений (или он руководитель — для ознакомления).
		// Вкладки показываются по этим флагам, даже если пользователь просто
		// ознакомлен с документом.
		var canAcq bool
		if err := tx.QueryRow(c.Context(), `
			SELECT EXISTS(SELECT 1 FROM user_acquaint_departments WHERE user_id=$1)
			    OR EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role IN ('chief','clerk'))`, userID).Scan(&canAcq); err != nil {
			return err
		}
		res["can_acquaint"] = canAcq || isAdmin
		var canAsg bool
		if err := tx.QueryRow(c.Context(), `
			SELECT EXISTS(SELECT 1 FROM user_assign_departments WHERE user_id=$1)
			    OR EXISTS(SELECT 1 FROM user_roles WHERE user_id=$1 AND role IN ('chief','clerk'))`, userID).Scan(&canAsg); err != nil {
			return err
		}
		res["can_assign"] = canAsg || isAdmin
		// #1 — исполнитель поручения по этому документу должен видеть вкладку
		// «Поручения» (даже если сам поручать не вправе).
		var isAssignee bool
		if err := tx.QueryRow(c.Context(),
			`SELECT EXISTS(SELECT 1 FROM assignments WHERE document_id=$1 AND assignee_id=$2)`, id, userID).Scan(&isAssignee); err != nil {
			return err
		}
		res["is_assignee"] = isAssignee
		// #7 — дежурный/получатель может ДОНАПРАВИТЬ документ, если он получатель
		// этого документа и ему назначены подразделения донаправления.
		var canRedirect bool
		if err := tx.QueryRow(c.Context(), `
			SELECT EXISTS(SELECT 1 FROM document_recipients WHERE document_id=$1 AND recipient_user_id=$2 AND is_planned=false)
			   AND EXISTS(SELECT 1 FROM user_redirect_departments WHERE user_id=$2)`, id, userID).Scan(&canRedirect); err != nil {
			return err
		}
		res["can_redirect"] = canRedirect
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить роли")
	}
	return c.JSON(res)
}
