import React, { useEffect, useState, useCallback } from 'react'
import { api } from '../api/client'
import { fmtDateTime } from '../utils/format'

const STAGE_TYPE_LABELS = {
  hierarchy: 'Согласование по иерархии',
  cross_dept: 'Согласование между подразделениями',
  signing: 'Подпись',
}
const STATUS_LABELS = {
  waiting_deps: 'Ожидает предыдущих этапов',
  pending: 'На рассмотрении',
  approved: 'Согласовано',
  rejected: 'Отклонено',
}
const STATUS_COLOR = {
  waiting_deps: 'text-text-secondary',
  pending: 'text-warning',
  approved: 'text-success',
  rejected: 'text-danger',
}

export default function ApprovalPanel({ documentId, currentUserId, onChanged }) {
  const [stages, setStages] = useState([])
  const [error, setError] = useState('')
  const [busyStageId, setBusyStageId] = useState(null)
  const [comment, setComment] = useState('')
  const [signModal, setSignModal] = useState(false)
  const [addOpen, setAddOpen] = useState(false)
  const [addQuery, setAddQuery] = useState('')
  const [addResults, setAddResults] = useState([])
  const [addType, setAddType] = useState('hierarchy')

  const load = useCallback(async () => {
    try {
      const res = await api.getStages(documentId)
      setStages(res.items || [])
    } catch (err) {
      setError(err.message || 'Не удалось загрузить маршрут согласования')
    }
  }, [documentId])

  useEffect(() => {
    load()
  }, [load])

  // Поиск кандидатов для доп. согласования (по группе согласующих).
  useEffect(() => {
    if (!addOpen) return
    let alive = true
    const t = setTimeout(async () => {
      try {
        const res = await api.searchCandidates({ group: addType, q: addQuery, limit: 20 })
        if (alive) setAddResults(res.items || [])
      } catch { /* ignore */ }
    }, 250)
    return () => { alive = false; clearTimeout(t) }
  }, [addOpen, addQuery, addType])

  async function decide(stage, approve) {
    setBusyStageId(stage.id)
    setError('')
    try {
      await api.decideStage(documentId, stage.id, approve, comment)
      setComment('')
      await load()
      onChanged?.()
    } catch (err) {
      setError(err.message || 'Не удалось зафиксировать решение')
    } finally {
      setBusyStageId(null)
    }
  }

  async function approveAndAdd(stage, addApproverId) {
    setBusyStageId(stage.id)
    setError('')
    try {
      await api.decideStage(documentId, stage.id, true, comment, {
        add_approver_id: addApproverId,
        add_approver_stage_type: addType,
      })
      setComment(''); setAddOpen(false); setAddQuery(''); setAddResults([])
      await load()
      onChanged?.()
    } catch (err) {
      setError(err.message || 'Не удалось направить на доп. согласование')
    } finally {
      setBusyStageId(null)
    }
  }

  if (stages.length === 0) return null

  const myPendingStage = stages.find((s) => s.status === 'pending' && s.approver_id === currentUserId)

  return (
    <div className="bg-surface border border-border rounded-lg p-4">
      <h2 className="font-medium text-sm mb-3">Маршрут согласования</h2>
      <ol className="space-y-2 mb-3">
        {stages.map((stage) => (
          <li key={stage.id} className="text-sm border-b border-border last:border-0 pb-2 last:pb-0">
            <div className="flex items-center justify-between">
              <span className="font-medium">
                {STAGE_TYPE_LABELS[stage.stage_type] || stage.stage_type}
              </span>
              <span className={STATUS_COLOR[stage.status]}>
                {/* #5 — для этапа подписи «approved» означает «Подписано», а не «Согласовано». */}
                {stage.status === 'approved' && stage.stage_type === 'signing'
                  ? 'Подписано'
                  : STATUS_LABELS[stage.status] || stage.status}
              </span>
            </div>
            <div className="text-xs text-text-secondary mt-0.5">
              {stage.approver_name || `Пользователь #${stage.approver_id}`}
              {stage.approver_position && ` · ${stage.approver_position}`}
              {stage.approver_department && ` · ${stage.approver_department}`}
              {stage.approver_city && ` · ${stage.approver_city}`}
              {stage.decided_at && (
                <span> · {fmtDateTime(stage.decided_at)}</span>
              )}
            </div>
            {stage.comment && <div className="text-xs text-text-secondary italic mt-0.5">«{stage.comment}»</div>}
          </li>
        ))}
      </ol>

      {error && <div className="text-danger text-xs mb-2">{error}</div>}

      {myPendingStage && (
        <div className="border-t border-border pt-3">
          <p className="text-xs text-text-secondary mb-2">
            Этап «{STAGE_TYPE_LABELS[myPendingStage.stage_type]}» ожидает вашего решения
            {myPendingStage.stage_type === 'signing' && ' — подтверждение выпустит исходящий номер и подпишет документ'}.
          </p>
          {/* #11 — для подписи комментарий вводится в модальном окне, поэтому
              здесь поле показываем только для этапов согласования. */}
          {myPendingStage.stage_type !== 'signing' && (
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Комментарий (необязательно)"
              className="w-full mb-2 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
            />
          )}
          <div className="flex gap-2">
            <button
              onClick={() => {
                if (myPendingStage.stage_type === 'signing') setSignModal(true)
                else decide(myPendingStage, true)
              }}
              disabled={busyStageId === myPendingStage.id}
              className="flex-1 py-1.5 rounded-md bg-success text-white text-sm font-medium disabled:opacity-60"
            >
              {myPendingStage.stage_type === 'signing' ? 'Подписать' : 'Согласовать'}
            </button>
            <button
              onClick={() => decide(myPendingStage, false)}
              disabled={busyStageId === myPendingStage.id}
              className="flex-1 py-1.5 rounded-md bg-danger text-white text-sm font-medium disabled:opacity-60"
            >
              Отклонить
            </button>
          </div>

          {/* Донаправление: только для этапов согласования (не подписи) */}
          {myPendingStage.stage_type !== 'signing' && (
            <div className="mt-2">
              {!addOpen ? (
                <button
                  onClick={() => setAddOpen(true)}
                  disabled={busyStageId === myPendingStage.id}
                  className="w-full py-1.5 rounded-md border border-accent text-accent text-sm font-medium disabled:opacity-60"
                >
                  Согласовать и направить на доп. согласование
                </button>
              ) : (
                <div className="border border-border rounded-md p-2 mt-1">
                  <div className="text-xs text-text-secondary mb-1">
                    Выберите пользователя для дополнительного согласования — он встанет в очередь сразу после вас.
                  </div>
                  <div className="flex gap-2 mb-2">
                    <select
                      value={addType}
                      onChange={(e) => setAddType(e.target.value)}
                      className="px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                    >
                      <option value="hierarchy">По иерархии</option>
                      <option value="cross_dept">Между подразделениями</option>
                    </select>
                    <input
                      value={addQuery}
                      onChange={(e) => setAddQuery(e.target.value)}
                      placeholder="Поиск по ФИО…"
                      className="flex-1 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
                    />
                  </div>
                  <ul className="max-h-40 overflow-auto divide-y divide-border">
                    {addResults.map((u) => (
                      <li key={`${u.id}-${u.department_id}`}>
                        <button
                          onClick={() => approveAndAdd(myPendingStage, u.id)}
                          disabled={busyStageId === myPendingStage.id}
                          className="w-full text-left px-2 py-1.5 text-sm hover:bg-surface-alt rounded disabled:opacity-60"
                        >
                          {u.full_name}
                          {u.department_name && <span className="text-text-secondary"> · {u.department_name}</span>}
                        </button>
                      </li>
                    ))}
                    {addResults.length === 0 && (
                      <li className="px-2 py-1.5 text-xs text-text-secondary">Начните вводить ФИО…</li>
                    )}
                  </ul>
                  <button
                    onClick={() => { setAddOpen(false); setAddQuery(''); setAddResults([]) }}
                    className="mt-2 text-xs text-text-secondary hover:text-text-primary"
                  >
                    Отмена
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {signModal && myPendingStage && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSignModal(false)}>
          <div className="bg-surface border border-border rounded-lg p-5 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-base font-semibold mb-2">Подписание документа</h3>
            {/* #11 — сначала уведомление (о ПЭП), затем комментарий. */}
            <div className="text-xs text-text-secondary border border-warning/40 bg-warning/5 rounded-md px-3 py-2 mb-3">
              Использование простой электронной подписи равнозначно собственноручной подписи
              в соответствии с Федеральным законом «Об электронной подписи» от 06.04.2011 № 63-ФЗ.
              Нажимая «Подписать», вы подтверждаете подписание документа.
            </div>
            <label className="block text-xs text-text-secondary mb-1">Резолюция к подписи (необязательно)</label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              placeholder="Например: «Согласовано. К исполнению.»"
              className="w-full mb-3 px-2 py-1.5 rounded-md border border-border bg-surface-alt text-sm"
            />
            {error && <div className="text-danger text-xs mb-2">{error}</div>}
            <div className="flex justify-end gap-2">
              <button onClick={() => setSignModal(false)} className="px-3 py-1.5 rounded-md border border-border text-sm">
                Отмена
              </button>
              <button
                onClick={async () => { await decide(myPendingStage, true); setSignModal(false) }}
                disabled={busyStageId === myPendingStage.id}
                className="px-3 py-1.5 rounded-md bg-success text-white text-sm font-medium disabled:opacity-60"
              >
                Подписать
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
