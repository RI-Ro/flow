-- =====================================================================
-- 0011_reader_scope.sql — исполнитель проекта видит только свои задачи.
--
-- Было: участник проекта в роли «исполнитель» видел все задачи доски —
-- членство в проекте само по себе давало доступ на чтение ко всему его
-- содержимому.
--
-- Стало: видимость определяется отношением к конкретной задаче.
--
--   • владелец и редактор проекта   — все задачи;
--   • автор задачи                  — свою, даже если в проекте он
--                                     всего лишь исполнитель;
--   • исполнитель задачи или пункта — свою;
--   • получивший точечный доступ    — ту, которую ему открыли;
--   • остальные участники проекта   — ничего.
--
-- Правится одна функция, app.task_access. Она — единственный источник
-- ответа на вопрос «что этот человек может с этой задачей», на неё
-- опираются и политики RLS, и выборки: убрав последнюю ветку, мы
-- закрываем задачи сразу везде, а не в каждом запросе по отдельности.
--
-- Проект при этом остаётся виден: человек по-прежнему участник, видит
-- доску, колонки и свои карточки в них. Скрываются именно чужие задачи.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0011_reader_scope.sql
--
-- Запускать от app_owner, после 0010_chat_polls.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE OR REPLACE FUNCTION app.task_access(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_board uuid;
    v_role  text;
    v_grant text;
    v_created uuid;
BEGIN
    IF p_user IS NULL OR p_task IS NULL THEN
        RETURN NULL;
    END IF;

    SELECT t.board_id, t.created_by INTO v_board, v_created
      FROM app.tasks t WHERE t.id = p_task;
    IF v_board IS NULL THEN
        RETURN NULL;
    END IF;

    v_role := app.board_role(v_board, p_user);
    IF v_role IN ('owner', 'editor') THEN
        RETURN 'edit';
    END IF;

    -- Автор задачи всегда управляет ею полностью — независимо от того,
    -- какая у него роль в проекте. Поставил задачу — отвечаешь за неё.
    IF v_created IN (SELECT app.effective_users(p_user)) THEN
        RETURN 'edit';
    END IF;

    IF EXISTS (SELECT 1 FROM app.task_assignees a
                WHERE a.task_id = p_task
                  AND a.user_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    -- Исполнитель пункта чек-листа видит задачу целиком: пункт без
    -- условий задачи — это поручение вслепую.
    IF EXISTS (SELECT 1 FROM app.task_steps x
                WHERE x.task_id = p_task
                  AND x.assignee_id IN (SELECT app.effective_users(p_user))) THEN
        RETURN 'contribute';
    END IF;

    SELECT g.access::text INTO v_grant
      FROM app.task_grants g
     WHERE g.task_id = p_task
       AND g.user_id IN (SELECT app.effective_users(p_user))
     LIMIT 1;
    IF v_grant IS NOT NULL THEN
        RETURN v_grant;
    END IF;

    -- Здесь раньше стояло `IF v_role = 'reader' THEN RETURN 'read'`:
    -- членство в проекте открывало все его задачи. Ветка убрана
    -- намеренно. Исполнителю проекта нужны его собственные задачи, а
    -- не чужая переписка и чужие отчёты; доступ к конкретной чужой
    -- задаче по-прежнему выдаётся точечно и осознанно.
    RETURN NULL;
END $$;

-- Готово.
