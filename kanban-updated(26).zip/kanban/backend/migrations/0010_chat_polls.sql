-- =====================================================================
-- 0010_chat_polls.sql — доработки переписки и задач.
--
--   1. Создание группового чата одной функцией: прежний способ упирался
--      в политику RLS.
--   2. Удаление чата и очистка переписки.
--   3. Опросы в групповых чатах.
--   4. Возврат задачи в ту колонку, из которой её закрыли.
--   5. Настройка «уведомления по задачам, где я не исполнитель».
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0010_chat_polls.sql
--
-- Запускать от app_owner, после 0009_chats.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. СОЗДАНИЕ ГРУППОВОГО ЧАТА.
-- ─────────────────────────────────────────────────────────────────────
--
-- Прежний порядок — INSERT в chats, затем INSERT в chat_members —
-- падал с нарушением политики на уровне строк, и причина неочевидная:
-- `INSERT ... RETURNING id` требует права ЧИТАТЬ созданную строку, а
-- политика chats_select показывает чат только его участникам. В момент
-- вставки создатель участником ещё не был.
--
-- Лечится не ослаблением политики (тогда чаты станут видны шире, чем
-- надо), а созданием через SECURITY DEFINER функцию — ровно как у
-- личного чата. Заодно чат и его состав появляются одной операцией:
-- чата без участников не бывает даже на мгновение.
CREATE OR REPLACE FUNCTION app.create_group_chat(
    p_owner uuid, p_title text, p_members uuid[])
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
    v_member uuid;
BEGIN
    IF p_owner IS NULL OR coalesce(btrim(p_title), '') = '' THEN
        RAISE EXCEPTION 'bad_group_chat';
    END IF;

    INSERT INTO app.chats (kind, title, owner_id)
    VALUES ('group', btrim(p_title), p_owner)
    RETURNING id INTO v_id;

    -- Владелец всегда участник: чат, которым нельзя пользоваться, но
    -- можно переименовывать, — бессмыслица.
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_owner);

    FOREACH v_member IN ARRAY COALESCE(p_members, ARRAY[]::uuid[]) LOOP
        IF v_member IS NOT NULL AND v_member <> p_owner THEN
            INSERT INTO app.chat_members (chat_id, user_id)
            VALUES (v_id, v_member) ON CONFLICT DO NOTHING;
        END IF;
    END LOOP;

    RETURN v_id;
END $$;

GRANT EXECUTE ON FUNCTION app.create_group_chat(uuid, text, uuid[]) TO app_user;

-- ─────────────────────────────────────────────────────────────────────
-- 2. УДАЛЕНИЕ ЧАТА И ОЧИСТКА ПЕРЕПИСКИ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Групповой чат удаляет владелец. Личный — любой из двоих: он общий,
-- владельца в нём по смыслу нет, а тот, кто записан owner_id, просто
-- написал первым.
--
-- Обе операции затрагивают чужие строки (сообщения собеседника),
-- поэтому идут через SECURITY DEFINER с явной проверкой прав, а не
-- через политики.
CREATE OR REPLACE FUNCTION app.can_manage_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (
        SELECT 1 FROM app.chats c
         WHERE c.id = p_chat
           AND (c.owner_id = p_user
                OR (c.kind = 'direct' AND app.in_chat(p_chat, p_user)))
    )
$$;

CREATE OR REPLACE FUNCTION app.delete_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF NOT app.can_manage_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;
    -- Сообщения и состав уйдут каскадом по внешним ключам.
    DELETE FROM app.chats WHERE id = p_chat;
    RETURN true;
END $$;

-- Очистка истории: чат остаётся, переписка обнуляется. Нужна, когда
-- разговор продолжается, но всё сказанное до сих пор больше не нужно.
CREATE OR REPLACE FUNCTION app.clear_chat(p_chat uuid, p_user uuid)
RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_count bigint;
BEGIN
    IF NOT app.can_manage_chat(p_chat, p_user) THEN
        RETURN -1;
    END IF;
    WITH gone AS (DELETE FROM app.chat_messages WHERE chat_id = p_chat RETURNING 1)
    SELECT count(*) INTO v_count FROM gone;
    -- Отметки прочтения сбрасываем: непрочитанных сообщений больше нет,
    -- а старое значение оставило бы счётчики в непонятном состоянии.
    UPDATE app.chat_members SET last_read_at = now() WHERE chat_id = p_chat;
    RETURN v_count;
END $$;

GRANT EXECUTE ON FUNCTION app.can_manage_chat(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_chat(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.clear_chat(uuid, uuid)      TO app_user;

-- ─────────────────────────────────────────────────────────────────────
-- 3. ОПРОСЫ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Опрос — это сообщение особого вида, поэтому живёт рядом с
-- сообщением, а не вместо него: в ленте он занимает своё место по
-- времени, его можно удалить как обычное сообщение, а вместе с
-- сообщением уйдёт и он.
CREATE TABLE IF NOT EXISTS app.chat_polls (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid NOT NULL REFERENCES app.chat_messages(id) ON DELETE CASCADE,
    question   text NOT NULL,
    -- Несколько вариантов ответа: «что берём на выезд» — это не
    -- выбор одного, в отличие от «когда собираемся».
    multiple   boolean NOT NULL DEFAULT false,
    closed_at  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_polls_message_idx ON app.chat_polls (message_id);

CREATE TABLE IF NOT EXISTS app.chat_poll_options (
    id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    poll_id  uuid NOT NULL REFERENCES app.chat_polls(id) ON DELETE CASCADE,
    body     text NOT NULL,
    position int NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS chat_poll_options_poll_idx ON app.chat_poll_options (poll_id, position);

CREATE TABLE IF NOT EXISTS app.chat_poll_votes (
    option_id uuid NOT NULL REFERENCES app.chat_poll_options(id) ON DELETE CASCADE,
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    voted_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (option_id, user_id)
);

ALTER TABLE app.chat_polls        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_poll_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_poll_votes   ENABLE ROW LEVEL SECURITY;

-- Видимость опроса определяется чатом, в котором висит его сообщение.
CREATE OR REPLACE FUNCTION app.poll_chat(p_poll uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.chat_id FROM app.chat_polls p
      JOIN app.chat_messages m ON m.id = p.message_id
     WHERE p.id = p_poll
$$;

DROP POLICY IF EXISTS chat_polls_select ON app.chat_polls;
CREATE POLICY chat_polls_select ON app.chat_polls FOR SELECT
    USING (app.in_chat(app.poll_chat(id), app.current_user_id()));

DROP POLICY IF EXISTS chat_poll_options_select ON app.chat_poll_options;
CREATE POLICY chat_poll_options_select ON app.chat_poll_options FOR SELECT
    USING (app.in_chat(app.poll_chat(poll_id), app.current_user_id()));

-- Голоса видны всем участникам: в опросе важно не только сколько, но и
-- кто — как в мессенджерах, где список проголосовавших открыт.
DROP POLICY IF EXISTS chat_poll_votes_select ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_select ON app.chat_poll_votes FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chat_poll_options o
                    WHERE o.id = option_id
                      AND app.in_chat(app.poll_chat(o.poll_id), app.current_user_id())));

-- Голосовать можно только за себя и только в незакрытом опросе.
DROP POLICY IF EXISTS chat_poll_votes_write ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_write ON app.chat_poll_votes FOR INSERT
    WITH CHECK (
        user_id = app.current_user_id()
        AND EXISTS (
            SELECT 1 FROM app.chat_poll_options o
              JOIN app.chat_polls p ON p.id = o.poll_id
             WHERE o.id = option_id
               AND p.closed_at IS NULL
               AND app.in_chat(app.poll_chat(o.poll_id), app.current_user_id()))
    );

DROP POLICY IF EXISTS chat_poll_votes_delete ON app.chat_poll_votes;
CREATE POLICY chat_poll_votes_delete ON app.chat_poll_votes FOR DELETE
    USING (user_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_polls        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_poll_options TO app_user;
GRANT SELECT, INSERT, DELETE         ON app.chat_poll_votes   TO app_user;
GRANT EXECUTE ON FUNCTION app.poll_chat(uuid) TO app_user;

-- Создание опроса одной операцией: сообщение, сам опрос и варианты.
-- SECURITY DEFINER по той же причине, что и у группового чата —
-- RETURNING требует права читать только что созданную строку.
CREATE OR REPLACE FUNCTION app.create_poll(
    p_chat uuid, p_author uuid, p_question text, p_options text[], p_multiple boolean)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_msg uuid;
    v_poll uuid;
    v_opt text;
    v_pos int := 0;
BEGIN
    IF NOT app.in_chat(p_chat, p_author) THEN
        RAISE EXCEPTION 'not_member';
    END IF;
    IF coalesce(btrim(p_question), '') = '' OR array_length(p_options, 1) < 2 THEN
        RAISE EXCEPTION 'bad_poll';
    END IF;

    -- Тело сообщения — сам вопрос: так опрос остаётся читаемым и в
    -- списке чатов, где показывается последнее сообщение.
    INSERT INTO app.chat_messages (chat_id, author_id, body)
    VALUES (p_chat, p_author, btrim(p_question))
    RETURNING id INTO v_msg;

    INSERT INTO app.chat_polls (message_id, question, multiple)
    VALUES (v_msg, btrim(p_question), COALESCE(p_multiple, false))
    RETURNING id INTO v_poll;

    FOREACH v_opt IN ARRAY p_options LOOP
        IF coalesce(btrim(v_opt), '') <> '' THEN
            INSERT INTO app.chat_poll_options (poll_id, body, position)
            VALUES (v_poll, btrim(v_opt), v_pos);
            v_pos := v_pos + 1;
        END IF;
    END LOOP;

    UPDATE app.chats SET updated_at = now() WHERE id = p_chat;
    RETURN v_msg;
END $$;

-- Голос: одной операцией, потому что «переголосовать» в опросе с одним
-- вариантом — это снять прежний голос и поставить новый, и между этими
-- двумя действиями опрос не должен оставаться без ответа человека.
CREATE OR REPLACE FUNCTION app.cast_vote(p_option uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_poll uuid;
    v_multiple boolean;
    v_closed timestamptz;
    v_exists boolean;
BEGIN
    SELECT o.poll_id, p.multiple, p.closed_at
      INTO v_poll, v_multiple, v_closed
      FROM app.chat_poll_options o
      JOIN app.chat_polls p ON p.id = o.poll_id
     WHERE o.id = p_option;

    IF v_poll IS NULL OR NOT app.in_chat(app.poll_chat(v_poll), p_user) THEN
        RETURN false;
    END IF;
    IF v_closed IS NOT NULL THEN
        RETURN false;
    END IF;

    SELECT EXISTS (SELECT 1 FROM app.chat_poll_votes
                    WHERE option_id = p_option AND user_id = p_user)
      INTO v_exists;

    IF v_exists THEN
        -- Повторное нажатие снимает голос: так же ведут себя опросы в
        -- мессенджерах, и это единственный способ передумать.
        DELETE FROM app.chat_poll_votes WHERE option_id = p_option AND user_id = p_user;
        RETURN true;
    END IF;

    IF NOT v_multiple THEN
        DELETE FROM app.chat_poll_votes v
         USING app.chat_poll_options o
         WHERE v.option_id = o.id AND o.poll_id = v_poll AND v.user_id = p_user;
    END IF;

    INSERT INTO app.chat_poll_votes (option_id, user_id) VALUES (p_option, p_user);
    RETURN true;
END $$;

-- Закрыть опрос вправе его автор.
CREATE OR REPLACE FUNCTION app.close_poll(p_poll uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_author uuid;
BEGIN
    SELECT m.author_id INTO v_author
      FROM app.chat_polls p JOIN app.chat_messages m ON m.id = p.message_id
     WHERE p.id = p_poll;
    IF v_author IS NULL OR v_author <> p_user THEN
        RETURN false;
    END IF;
    UPDATE app.chat_polls SET closed_at = now() WHERE id = p_poll AND closed_at IS NULL;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.create_poll(uuid, uuid, text, text[], boolean) TO app_user;
GRANT EXECUTE ON FUNCTION app.cast_vote(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.close_poll(uuid, uuid) TO app_user;

-- ─────────────────────────────────────────────────────────────────────
-- 4. ВОЗВРАТ ЗАДАЧИ В ПРЕЖНЮЮ КОЛОНКУ.
-- ─────────────────────────────────────────────────────────────────────
--
-- При завершении задача уезжает в колонку «Готово», и возврат в работу
-- отправлял её в первую попавшуюся рабочую колонку — как правило, в
-- самое начало доски. Задача, закрытая из «На проверке», возвращалась в
-- «Очередь», и стадию работы приходилось восстанавливать руками.
--
-- Поэтому колонка, из которой задачу закрыли, запоминается.
ALTER TABLE app.tasks
    ADD COLUMN IF NOT EXISTS prev_column_id uuid REFERENCES app.columns(id) ON DELETE SET NULL;

-- ─────────────────────────────────────────────────────────────────────
-- 5. УВЕДОМЛЕНИЯ ПО ЧУЖИМ ЗАДАЧАМ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Владелец и редактор проекта получают уведомления обо всех задачах
-- проекта. Для небольшого проекта это полезно, для большого —
-- непрерывный поток о чужой работе. Настройка позволяет отключить
-- ровно эту часть, не трогая уведомления по своим задачам.
--
-- Хранится в той же таблице настроек, что и остальные категории, под
-- именем foreign_task. Отдельная функция нужна, потому что читать
-- настройку приходится за другого пользователя — под RLS это чужая
-- строка.
CREATE OR REPLACE FUNCTION app.wants_foreign_task_notifs(p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE((SELECT enabled FROM app.notification_prefs
                      WHERE user_id = p_user AND category = 'foreign_task'), true)
$$;

GRANT EXECUTE ON FUNCTION app.wants_foreign_task_notifs(uuid) TO app_user;

-- Готово.
