-- =====================================================================
-- 0012_chat_personal.sql — удаление и очистка чата «у себя».
--
-- Было: очистка и удаление затрагивали всех. Один человек убирал у себя
-- переписку — и она исчезала у собеседника, вместе с тем, что тот
-- рассчитывал сохранить. Это не уборка, а уничтожение общих данных.
--
-- Стало: обе операции личные. У каждого участника своя отметка:
--
--   cleared_at — переписка до этого момента ему не показывается;
--   hidden_at  — чат убран из его списка и вернётся туда, только если
--                придёт новое сообщение.
--
-- Сами сообщения остаются в базе, пока их не удалит автор. Так работают
-- мессенджеры, и так честнее: разговор двусторонний, и один его
-- участник не вправе стирать историю у другого.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0012_chat_personal.sql
--
-- Запускать от app_owner, после 0011_reader_scope.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ЛИЧНЫЕ ОТМЕТКИ УЧАСТНИКА.
-- ─────────────────────────────────────────────────────────────────────

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS cleared_at timestamptz NOT NULL DEFAULT to_timestamp(0);

ALTER TABLE app.chat_members
    ADD COLUMN IF NOT EXISTS hidden_at timestamptz;

-- Очистка у себя: сдвигаем границу видимости к текущему моменту.
-- Отметку прочтения двигаем туда же — непрочитанных сообщений за
-- границей уже не видно, и старое значение оставило бы счётчик в
-- непонятном состоянии.
CREATE OR REPLACE FUNCTION app.clear_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;
    UPDATE app.chat_members
       SET cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

-- Удаление у себя: та же граница плюс скрытие чата из списка.
--
-- Групповой чат при этом ещё и покидается: держать человека в составе
-- группы, из которой он ушёл, — значит слать ему уведомления о
-- разговоре, который он закрыл. Личный чат не покидается: собеседник
-- должен иметь возможность написать снова, и тогда разговор вернётся.
CREATE OR REPLACE FUNCTION app.delete_chat_for_me(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_kind text;
    v_owner uuid;
BEGIN
    IF NOT app.in_chat(p_chat, p_user) THEN
        RETURN false;
    END IF;

    SELECT kind, owner_id INTO v_kind, v_owner FROM app.chats WHERE id = p_chat;

    IF v_kind = 'group' AND v_owner IS DISTINCT FROM p_user THEN
        DELETE FROM app.chat_members WHERE chat_id = p_chat AND user_id = p_user;
        RETURN true;
    END IF;

    -- Владелец группы и участники личного чата остаются в составе, но
    -- чат уходит из их списка. Владелец, уйдя совсем, оставил бы группу
    -- без хозяина; личный чат без второго участника перестал бы быть
    -- личным.
    UPDATE app.chat_members
       SET hidden_at = now(), cleared_at = now(), last_read_at = now()
     WHERE chat_id = p_chat AND user_id = p_user;
    RETURN true;
END $$;

GRANT EXECUTE ON FUNCTION app.clear_chat_for_me(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.delete_chat_for_me(uuid, uuid) TO app_user;

-- Непрочитанные с учётом личной границы: сообщения, которые человек у
-- себя убрал, непрочитанными не считаются.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > GREATEST(m.last_read_at, m.cleared_at)
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 2. ВРЕМЯ ГОЛОСА В ОПРОСЕ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Столбец voted_at был с самого начала, но наружу не отдавался. В
-- рабочем опросе «когда ответил» важно не меньше, чем «что ответил»:
-- по нему видно, кто откликнулся сразу, а кого пришлось ждать.
-- Функция собирает голоса варианта вместе со временем, чтобы обойтись
-- одним запросом на опрос.
CREATE OR REPLACE FUNCTION app.poll_option_votes(p_option uuid)
RETURNS TABLE (user_id uuid, voted_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.user_id, v.voted_at
      FROM app.chat_poll_votes v
     WHERE v.option_id = p_option
     ORDER BY v.voted_at
$$;

GRANT EXECUTE ON FUNCTION app.poll_option_votes(uuid) TO app_user;

-- Готово.
