-- =====================================================================
-- 0009_chats.sql — переписка между сотрудниками и переработанные
-- отметки о просмотре задачи.
--
-- Две части, обе требуют схемы:
--
--   1. Чаты: личные и групповые, с файлами, правкой и удалением
--      сообщений, владельцем и составом участников у групповых.
--
--   2. Отметки в задаче: раньше галочка означала просто «открывал
--      когда-нибудь». Теперь их три состояния, и второе — «видел
--      задачу в её нынешнем виде» — требует сравнения времени
--      просмотра с временем последнего изменения по каждому
--      исполнителю.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0009_chats.sql
--
-- Запускать от app_owner, после 0008_reminder_task.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ЧАТЫ.
-- ─────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app.chats (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    kind       text NOT NULL CHECK (kind IN ('direct', 'group')),
    -- У личного чата названия нет: он называется именем собеседника,
    -- и хранить это имя копией значило бы держать его в двух местах.
    title      text NOT NULL DEFAULT '',
    owner_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.chat_members (
    chat_id      uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    user_id      uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    added_at     timestamptz NOT NULL DEFAULT now(),
    -- Прочитано до этого момента. Счётчик непрочитанных считается
    -- сравнением с created_at сообщений, а не отдельным столбцом:
    -- иначе его пришлось бы пересчитывать при каждом удалении
    -- сообщения и синхронизировать между устройствами.
    last_read_at timestamptz NOT NULL DEFAULT to_timestamp(0),
    PRIMARY KEY (chat_id, user_id)
);

CREATE INDEX IF NOT EXISTS chat_members_user_idx ON app.chat_members (user_id);

CREATE TABLE IF NOT EXISTS app.chat_messages (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id    uuid NOT NULL REFERENCES app.chats(id) ON DELETE CASCADE,
    author_id  uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL DEFAULT '',
    -- Файл — необязательное приложение к сообщению. Одно на сообщение:
    -- несколько файлов отправляются несколькими сообщениями, и это
    -- честнее выглядит в переписке, чем пачка вложений без подписей.
    file_id    uuid REFERENCES app.files(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    -- Удаление мягкое: в переписке важно, что сообщение было. Тело
    -- очищается, на месте остаётся «сообщение удалено».
    deleted_at timestamptz,
    CHECK (body <> '' OR file_id IS NOT NULL OR deleted_at IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS chat_messages_chat_idx
    ON app.chat_messages (chat_id, created_at DESC);

-- Участие в чате. SECURITY DEFINER, потому что на эту проверку
-- опираются политики самих таблиц чата — обычный подзапрос к
-- chat_members внутри политики chat_members привёл бы к рекурсии.
CREATE OR REPLACE FUNCTION app.in_chat(p_chat uuid, p_user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT EXISTS (SELECT 1 FROM app.chat_members m
                    WHERE m.chat_id = p_chat AND m.user_id = p_user)
$$;

CREATE OR REPLACE FUNCTION app.chat_owner(p_chat uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT owner_id FROM app.chats WHERE id = p_chat
$$;

ALTER TABLE app.chats         ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_members  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chat_messages ENABLE ROW LEVEL SECURITY;

-- Чат виден участникам. Создавать может любой сотрудник, но состав
-- участников приписывается отдельно, и без себя в составе создатель
-- свой чат сразу же перестанет видеть — это делается одной
-- транзакцией на стороне приложения.
DROP POLICY IF EXISTS chats_select ON app.chats;
CREATE POLICY chats_select ON app.chats FOR SELECT
    USING (app.in_chat(id, app.current_user_id()));

DROP POLICY IF EXISTS chats_insert ON app.chats;
CREATE POLICY chats_insert ON app.chats FOR INSERT
    WITH CHECK (app.current_user_id() IS NOT NULL);

-- Переименовать групповой чат вправе владелец. Личный переименовать
-- нельзя вовсе: он называется собеседником.
DROP POLICY IF EXISTS chats_update ON app.chats;
CREATE POLICY chats_update ON app.chats FOR UPDATE
    USING (kind = 'group' AND owner_id = app.current_user_id())
    WITH CHECK (kind = 'group' AND owner_id = app.current_user_id());

DROP POLICY IF EXISTS chats_delete ON app.chats;
CREATE POLICY chats_delete ON app.chats FOR DELETE
    USING (owner_id = app.current_user_id());

-- Состав участников виден участникам; менять его может владелец
-- группового чата, а уйти самому можно всегда.
DROP POLICY IF EXISTS chat_members_select ON app.chat_members;
CREATE POLICY chat_members_select ON app.chat_members FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_members_insert ON app.chat_members;
CREATE POLICY chat_members_insert ON app.chat_members FOR INSERT
    WITH CHECK (
        app.chat_owner(chat_id) = app.current_user_id()
        -- Первый участник вписывается в момент создания чата, когда
        -- владельца ещё может не быть в составе.
        OR user_id = app.current_user_id()
        OR app.chat_owner(chat_id) IS NULL
    );

-- Отметка о прочтении — это UPDATE своей же строки, поэтому правка
-- разрешена и участнику, но только над собой.
DROP POLICY IF EXISTS chat_members_update ON app.chat_members;
CREATE POLICY chat_members_update ON app.chat_members FOR UPDATE
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

DROP POLICY IF EXISTS chat_members_delete ON app.chat_members;
CREATE POLICY chat_members_delete ON app.chat_members FOR DELETE
    USING (
        app.chat_owner(chat_id) = app.current_user_id()
        OR user_id = app.current_user_id()
    );

-- Сообщения: читают участники, пишет участник от своего имени,
-- правит и удаляет только автор.
DROP POLICY IF EXISTS chat_messages_select ON app.chat_messages;
CREATE POLICY chat_messages_select ON app.chat_messages FOR SELECT
    USING (app.in_chat(chat_id, app.current_user_id()));

DROP POLICY IF EXISTS chat_messages_insert ON app.chat_messages;
CREATE POLICY chat_messages_insert ON app.chat_messages FOR INSERT
    WITH CHECK (app.in_chat(chat_id, app.current_user_id())
                AND author_id = app.current_user_id());

DROP POLICY IF EXISTS chat_messages_update ON app.chat_messages;
CREATE POLICY chat_messages_update ON app.chat_messages FOR UPDATE
    USING (author_id = app.current_user_id())
    WITH CHECK (author_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.chats         TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_members  TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chat_messages TO app_user;
GRANT EXECUTE ON FUNCTION app.in_chat(uuid, uuid) TO app_user;
GRANT EXECUTE ON FUNCTION app.chat_owner(uuid)    TO app_user;

-- Файл из переписки виден участникам чата. Политика files_select уже
-- существует и описывает доступ через вложения задач; здесь
-- добавляется вторая, самостоятельная: в Postgres несколько
-- разрешающих политик складываются по ИЛИ.
DROP POLICY IF EXISTS files_select_chat ON app.files;
CREATE POLICY files_select_chat ON app.files FOR SELECT
    USING (EXISTS (SELECT 1 FROM app.chat_messages m
                    WHERE m.file_id = app.files.id
                      AND app.in_chat(m.chat_id, app.current_user_id())));

-- Личный чат ровно один на пару. Создание через функцию, а не через
-- INSERT с проверкой на стороне приложения: иначе два одновременных
-- нажатия «написать» создали бы два чата с одним и тем же человеком.
CREATE OR REPLACE FUNCTION app.ensure_direct_chat(p_a uuid, p_b uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_id uuid;
BEGIN
    IF p_a IS NULL OR p_b IS NULL OR p_a = p_b THEN
        RAISE EXCEPTION 'bad_direct_chat';
    END IF;

    SELECT c.id INTO v_id
      FROM app.chats c
      JOIN app.chat_members m1 ON m1.chat_id = c.id AND m1.user_id = p_a
      JOIN app.chat_members m2 ON m2.chat_id = c.id AND m2.user_id = p_b
     WHERE c.kind = 'direct'
     LIMIT 1;

    IF v_id IS NOT NULL THEN
        RETURN v_id;
    END IF;

    INSERT INTO app.chats (kind, owner_id) VALUES ('direct', p_a) RETURNING id INTO v_id;
    INSERT INTO app.chat_members (chat_id, user_id) VALUES (v_id, p_a), (v_id, p_b);
    RETURN v_id;
END $$;

GRANT EXECUTE ON FUNCTION app.ensure_direct_chat(uuid, uuid) TO app_user;

-- Состав чата для рассылки событий по WebSocket.
--
-- Обязательно SECURITY DEFINER. Рассылка идёт из фонового кода, без
-- пользовательского контекста: app.current_user_id() там пуст, и
-- обычный SELECT из chat_members под политикой chat_members_select не
-- вернул бы ни строки. Ровно из-за этого события переписки не доходили
-- вовсе — ни звука, ни счётчика, ни всплывающего сообщения, пока
-- страницу не перезагрузишь.
--
-- Тот же приём уже используется для досок (app.board_watchers).
CREATE OR REPLACE FUNCTION app.chat_watchers(p_chat uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT user_id FROM app.chat_members WHERE chat_id = p_chat
$$;

GRANT EXECUTE ON FUNCTION app.chat_watchers(uuid) TO app_user;

-- Непрочитанные по всем чатам — для счётчика рядом с вкладкой.
CREATE OR REPLACE FUNCTION app.chat_unread_total(p_user uuid)
RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT count(*)
      FROM app.chat_messages msg
      JOIN app.chat_members m ON m.chat_id = msg.chat_id AND m.user_id = p_user
     WHERE msg.created_at > m.last_read_at
       AND msg.deleted_at IS NULL
       AND msg.author_id IS DISTINCT FROM p_user
$$;

GRANT EXECUTE ON FUNCTION app.chat_unread_total(uuid) TO app_user;

-- ─────────────────────────────────────────────────────────────────────
-- 2. ОТМЕТКИ О ПРОСМОТРЕ ЗАДАЧИ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Три состояния вместо двух:
--
--   • серая галочка  — исполнитель открывал задачу хоть раз;
--   • зелёная        — открывал ПОСЛЕ последнего изменения, то есть
--                      видел задачу в нынешнем виде;
--   • две зелёные    — отметил свою часть выполненной.
--
-- Разница между первой и второй — в сравнении времени просмотра с
-- временем последнего изменения. Изменением считается что угодно:
-- новый комментарий, правка описания, отметка в чек-листе, файл. Всё
-- это пишется в app.activity, поэтому момент изменения берётся как
-- максимум из tasks.updated_at и последней записи журнала.
--
-- Из журнала исключаются действия самого исполнителя: человек,
-- дописавший комментарий, очевидно видел задачу — гасить ему зелёную
-- галочку собственным действием было бы бессмысленно.

CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- Исполнители, чей просмотр свежее последнего изменения задачи.
CREATE OR REPLACE FUNCTION app.assignees_fresh(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task'
       AND v.entity_id = p_task
       AND v.viewed_at >= app.task_activity_at(p_task, v.user_id)
$$;

GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_fresh(uuid) TO app_user;

-- Готово.
