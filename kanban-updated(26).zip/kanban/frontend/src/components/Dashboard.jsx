import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, CheckCircle2, ListTodo, Inbox, Check, PenLine, Layers } from "lucide-react";
import { api } from "../lib/api.js";
import { PRIORITIES, fmtDate, resolveUser, dueColor, orderedBoards } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Spinner, inputStyle } from "../lib/ui.jsx";
import { emptyFilters, matchesFilters } from "../lib/filters.js";
import TaskFilters from "./TaskFilters.jsx";

const STATUSES = [
  ["all", "Все"],
  ["open", "Не выполнены"],
  ["done", "Выполнены"],
  ["overdue", "Просрочены"],
];

const monthsAgo = (n) => {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  return d.toISOString().slice(0, 10);
};
const tomorrow = () => new Date(Date.now() + 86400000).toISOString().slice(0, 10);

const FILTER_KEY = "kanban.dashboardFilter";

export default function Dashboard({ theme, directory, boards, currentUser, hideCompleted, onError, onOpenTask }) {
  // Фильтр переживает перезагрузку — как и фильтры доски: настроенный
  // срез это рабочий инструмент, а не разовый выбор.
  const [filter, setFilter] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(FILTER_KEY) || "{}");
      return {
        from: saved.from || monthsAgo(6),
        to: saved.to || tomorrow(),
        status: saved.status || "all",
        boardId: saved.boardId || "",
      };
    } catch {
      return { from: monthsAgo(6), to: tomorrow(), status: "all", boardId: "" };
    }
  });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState("");
  const [userTasks, setUserTasks] = useState(null);
  // Номер последнего отправленного запроса. Ответы приходят в
  // произвольном порядке, и без этого счётчика медленный ответ по
  // старому фильтру мог перезаписать уже показанные свежие данные.
  const reqSeq = useRef(0);

  useEffect(() => {
    localStorage.setItem(FILTER_KEY, JSON.stringify(filter));
  }, [filter]);

  const load = useCallback(async () => {
    const seq = ++reqSeq.current;
    setLoading(true);
    setFailed("");
    try {
      const params = new URLSearchParams({
        from: filter.from, to: filter.to, status: filter.status,
      });
      if (filter.boardId) params.set("boardId", filter.boardId);
      const res = await api.dashboard(params.toString());
      if (seq !== reqSeq.current) return;   // ответ устарел
      setData(res);
    } catch (e) {
      if (seq !== reqSeq.current) return;
      // Сводка не показывает ничего, пока не получены данные, поэтому
      // сорвавшийся запрос раньше оставлял пустой экран: человек видел
      // белое место и решал, что задач нет. Теперь ошибка видна, и её
      // можно повторить, не перезагружая страницу.
      setFailed(e.message || "Не удалось загрузить сводку");
      onError(e.message);
    } finally {
      if (seq === reqSeq.current) setLoading(false);
    }
  }, [filter, onError]);

  useEffect(() => { load(); }, [load]);

  // Один автоматический повтор через полторы секунды. Первый запрос
  // сводки уходит одновременно с загрузкой справочников и обновлением
  // токена — в этот момент он чаще всего и срывается, а повтор уже
  // попадает в спокойную обстановку.
  useEffect(() => {
    if (!failed || data) return;
    const t = setTimeout(() => load(), 1500);
    return () => clearTimeout(t);
  }, [failed, data, load]);

  const set = (k, v) => setFilter((f) => ({ ...f, [k]: v }));

  // override позволяет открыть срез, отличающийся от текущего фильтра:
  // например, «из них просрочено» — тот же человек, но только
  // просроченные, независимо от выбранного статуса.
  const openUser = async (userId, kind, override = {}) => {
    try {
      const params = new URLSearchParams({
        from: override.from || filter.from,
        to: override.to || filter.to,
        status: override.status || filter.status,
        kind,
      });
      if (filter.boardId) params.set("boardId", filter.boardId);
      const tasks = await api.dashboardUserTasks(userId, params.toString());
      setUserTasks({ user: resolveUser(directory, userId), kind, tasks, override });
    } catch (e) {
      onError(e.message);
    }
  };

  if (loading && !data) {
    return <Spinner theme={theme} label="Считаем статистику…" />;
  }
  if (!data) {
    return (
      <div className="max-w-md mx-auto text-center py-16">
        <p style={{ color: theme.text }} className="text-[14px] font-medium mb-1.5">
          Сводка не загрузилась
        </p>
        <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-4">
          {failed || "Данные ещё не получены."}
        </p>
        <button onClick={load} style={{ background: theme.accent, color: theme.accentText }}
          className="rounded-lg px-4 py-2.5 text-[13px] font-semibold">
          Повторить
        </button>
      </div>
    );
  }

  const my = data.myLoad || {};

  return (
    <div className="max-w-[1500px] mx-auto pb-6">
      {/* ── фильтр ───────────────────────────────────────────────── */}
      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="rounded-2xl p-3 mb-4 flex flex-wrap items-end gap-3">
        <div>
          <div className="mono text-[10px] uppercase tracking-wider mb-1"
            style={{ color: theme.textMuted }}>период с</div>
          <input type="date" value={filter.from} onChange={(e) => set("from", e.target.value)}
            style={inputStyle(theme)} className="rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none" />
        </div>
        <div>
          <div className="mono text-[10px] uppercase tracking-wider mb-1"
            style={{ color: theme.textMuted }}>по</div>
          <input type="date" value={filter.to} onChange={(e) => set("to", e.target.value)}
            style={inputStyle(theme)} className="rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none" />
        </div>

        <div>
          <div className="mono text-[10px] uppercase tracking-wider mb-1"
            style={{ color: theme.textMuted }}>статус</div>
          <div className="flex gap-1">
            {STATUSES.map(([id, label]) => (
              <button key={id} onClick={() => set("status", id)}
                style={{
                  background: filter.status === id ? theme.accent : theme.surfaceAlt,
                  color: filter.status === id ? theme.accentText : theme.text,
                  border: `1px solid ${theme.border}`,
                }}
                className="px-2.5 py-1.5 rounded-lg text-[12px] font-medium">
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="min-w-[180px]">
          <div className="mono text-[10px] uppercase tracking-wider mb-1"
            style={{ color: theme.textMuted }}>проект</div>
          <select value={filter.boardId} onChange={(e) => set("boardId", e.target.value)}
            style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none">
            <option value="">Все проекты</option>
            {orderedBoards(boards).map((b) => <option key={b.id} value={b.id}>{"\u00A0\u00A0".repeat(b.depth) + b.title}</option>)}
          </select>
        </div>

        {loading && (
          <span style={{ color: theme.textMuted }} className="text-[12px] self-center">обновляем…</span>
        )}
      </div>

      {/* ── что на мне ───────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        <Metric theme={theme} icon={ListTodo} label="Мне поручено"
          value={my.assigned || 0} accent={theme.accent}
          hint="Незавершённые задачи, где я исполнитель"
          onClick={() => openUser(currentUser.id, "assigned", { status: "open" })} />
        <Metric theme={theme} icon={AlertTriangle} label="Из них просрочено"
          value={my.assignedOverdue || 0} accent={theme.danger}
          hint="Мои задачи с истёкшим сроком"
          onClick={() => openUser(currentUser.id, "assigned", { status: "overdue" })} />
        <Metric theme={theme} icon={CheckCircle2} label="Я поручил"
          value={my.createdByMe || 0} accent={theme.accent2}
          hint="Незавершённые задачи, которые создал я"
          onClick={() => openUser(currentUser.id, "created", { status: "open" })} />
        <Metric theme={theme} icon={Inbox} label="Открыт доступ"
          value={my.grantedToMe || 0} accent={theme.info}
          hint="Задачи чужих проектов, открытые мне точечно"
          onClick={() => openUser(currentUser.id, "granted", { status: "open" })} />

        {/* Плитки «всего»: остальные показывают текущую загрузку, эти —
            объём вообще, вместе с завершёнными. «Всего моих» считается
            без двойного счёта: задача, которую я поставил сам себе,
            одна, а не две. */}
        <Metric theme={theme} icon={PenLine} label="Я автор — всего"
          value={my.createdByMeTotal || 0} accent={theme.accent2}
          hint="Все поставленные мной задачи, включая завершённые"
          onClick={() => openUser(currentUser.id, "created", { status: "all" })} />
        <Metric theme={theme} icon={Layers} label="Всего моих задач"
          value={my.myTotal || 0} accent={theme.accent}
          hint="Где я исполнитель или автор, без повторов — в пределах моей видимости"
          onClick={() => openUser(currentUser.id, "involved", { status: "all" })} />
      </div>

      {/* ── по исполнителям ──────────────────────────────────────── */}
      <Panel theme={theme} title="Нагрузка по людям"
        mono="// исполняет или поставил · нажмите на строку">
        {(data.byAssignee || []).length === 0 ? (
          <Empty theme={theme} />
        ) : (
          <div>
            {data.byAssignee.map((a) => {
              const u = resolveUser(directory, a.userId);
              const pct = a.total ? Math.round((a.done / a.total) * 100) : 0;
              return (
                <button key={a.userId} onClick={() => openUser(a.userId, "involved")}
                  style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
                  className="w-full rounded-xl p-2.5 mb-1.5 flex items-center gap-2.5 text-left hover:opacity-90">
                  <Avatar user={u} size={30} theme={theme} />
                  <div className="min-w-0 flex-1">
                    <div style={{ color: theme.text }} className="text-[13px] font-medium truncate">
                      {u.fullName}
                    </div>
                    <div style={{ background: theme.border }}
                      className="h-1.5 rounded-full overflow-hidden mt-1.5">
                      <div style={{ width: `${pct}%`, background: theme.success }} className="h-full" />
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div style={{ color: theme.text }} className="text-[13px] font-semibold">
                      {a.total}
                    </div>
                    <div className="mono text-[10px]" style={{ color: theme.textMuted }}>
                      {a.done} готово
                      {a.overdue > 0 && (
                        <span style={{ color: theme.danger }}> · {a.overdue} просроч.</span>
                      )}
                      {/* Расшифровка состава: иначе непонятно, почему у
                          человека, который ничего не исполняет, в
                          строке стоит число. */}
                      {(a.asAuthor > 0 || a.asAssignee > 0) && (
                        <span> · {a.asAssignee} исп. / {a.asAuthor} пост.</span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </Panel>

      {userTasks && (
        <UserTasksModal theme={theme} directory={directory} data={userTasks} onClose={() => setUserTasks(null)}
          onOpenTask={(id) => { setUserTasks(null); onOpenTask(id); }} />
      )}
    </div>
  );
}

function Metric({ theme, icon: Icon, label, value, accent, hint, onClick }) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag onClick={onClick} title={hint}
      style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
      className={`rounded-2xl p-3 text-left ${onClick ? "hover:opacity-90" : ""}`}>
      <div className="flex items-center gap-1.5 mb-1">
        {Icon && <Icon size={13} style={{ color: accent || theme.textMuted }} />}
        <span className="mono text-[10px] uppercase tracking-wider truncate"
          style={{ color: theme.textMuted }}>{label}</span>
      </div>
      <div style={{ color: accent || theme.text, fontFamily: "var(--font-ui)" }}
        className="text-[24px] font-extrabold leading-none">
        {value}
      </div>
    </Tag>
  );
}

function Panel({ theme, title, mono, children, className = "" }) {
  return (
    <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
      className={`rounded-2xl p-4 ${className}`}>
      <div className="flex items-baseline justify-between mb-3 gap-2">
        <h3 style={{ color: theme.text, fontFamily: "var(--font-ui)" }}
          className="font-bold text-[14px]">{title}</h3>
        {mono && (
          <span className="mono text-[10px] truncate" style={{ color: theme.textMuted }}>{mono}</span>
        )}
      </div>
      {children}
    </div>
  );
}

function Empty({ theme }) {
  return (
    <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-10">
      За выбранный период данных нет.
    </p>
  );
}

function UserTasksModal({ theme, directory, data, onClose, onOpenTask }) {
  const { user, kind, tasks } = data;

  // Тот же отбор, что в проектах, только без исполнителя: список и так
  // про одного конкретного человека, и выбирать исполнителя внутри
  // него нечего. Фильтр местный, в localStorage не сохраняется: это
  // разовый разбор конкретной выборки, а не настройка рабочего места.
  const [filters, setFilters] = useState(emptyFilters);
  const [q, setQ] = useState("");

  const shown = useMemo(
    () => tasks.filter((t) => matchesFilters(t, filters, q)),
    [tasks, filters, q]);

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-2xl" padded={false} geometryKey="dashboard-user-tasks">
      <div className="p-5 pb-3">
        <ModalHeader theme={theme} onClose={onClose}
          title={user.fullName}
          subtitle={
            (kind === "created" ? "Поручено другим" :
             kind === "granted" ? "Открыт доступ" :
             kind === "involved" ? "Исполняет или поставил" : "Назначено задач") +
            `: ${shown.length}${shown.length === tasks.length ? "" : ` из ${tasks.length}`}` +
            (data.override?.status === "overdue" ? " · только просроченные" : "")
          } />
      </div>
      <div className="px-3 pb-2">
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="Поиск: название, описание, вх. номер, тег"
          style={inputStyle(theme)}
          className="w-full rounded-lg px-3 py-1.5 text-[12.5px] outline-none" />
      </div>
      <TaskFilters theme={theme} filters={filters} setFilters={setFilters}
        directory={directory} tags={[...new Set(tasks.flatMap((t) => t.tags || []))].sort()} />

      <div style={{ borderColor: theme.border }}
        className="border-t max-h-[55vh] overflow-y-auto px-3 py-2 pb-6">
        {shown.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[12.5px] py-6 text-center">
            По заданным условиям задач нет.
          </p>
        )}
        {shown.map((t) => {
          const author = t.createdBy ? resolveUser(directory, t.createdBy) : null;
          const assignees = (t.assignees || []).map((id) => resolveUser(directory, id));
          const doneIds = t.assigneesDone || [];
          return (
            <button key={t.id} onClick={() => onOpenTask(t.id)}
              style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }}
              className="w-full rounded-xl p-2.5 mb-1.5 text-left flex items-start gap-2.5">
              <span style={{ background: theme[(PRIORITIES[t.priority] || {}).color] || theme.textMuted }}
                className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" />

              <div className="min-w-0 flex-1">
                <div style={{
                  color: theme.text,
                  textDecoration: t.completed ? "line-through" : "none",
                  opacity: t.completed ? 0.65 : 1,
                }} className="text-[12.5px] font-medium truncate">
                  {t.title}
                </div>

                {/* Проект и колонка: без колонки непонятно, на какой
                    стадии задача, а это первое, что спрашивают, глядя
                    в сводку. */}
                <div style={{ color: theme.textMuted }} className="text-[11px] truncate">
                  <span style={{ color: theme.accent }}>{t.boardTitle}</span>
                  {t.columnTitle ? ` · ${t.columnTitle}` : ""}
                  {` · ${PRIORITIES[t.priority]?.label || t.priority}`}
                  {t.incomingNumber ? ` · вх. ${t.incomingNumber}${t.incomingDate ? ` от ${fmtDate(t.incomingDate)}` : ""}` : ""}
                </div>

                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                  {author && (
                    <span className="flex items-center gap-1 min-w-0" title={`Поставил(а): ${author.fullName}`}>
                      <Avatar user={author} size={16} theme={theme} />
                      <span style={{ color: theme.textMuted }} className="text-[10.5px] truncate max-w-[140px]">
                        {author.fullName}
                      </span>
                    </span>
                  )}
                  {assignees.length > 0 ? (
                    <span className="flex items-center gap-1 min-w-0">
                      <span style={{ color: theme.textMuted }} className="text-[10.5px]">→</span>
                      <span className="flex -space-x-1.5">
                        {assignees.slice(0, 4).map((u, i) => (
                          <span key={`${u.id}-${i}`} className="inline-flex relative"
                            style={{
                              boxShadow: `0 0 0 2px ${doneIds.includes(u.id) ? theme.success : theme.surfaceAlt}`,
                              borderRadius: 999, lineHeight: 0,
                            }}
                            title={doneIds.includes(u.id)
                              ? `${u.fullName} — свою часть выполнил(а)`
                              : u.fullName}>
                            <Avatar user={u} size={16} theme={theme} />
                            {doneIds.includes(u.id) && (
                              <span style={{ background: theme.success }}
                                className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full flex items-center justify-center">
                                <Check size={6} color="#fff" strokeWidth={4} />
                              </span>
                            )}
                          </span>
                        ))}
                      </span>
                      {assignees.length > 4 && (
                        <span style={{ color: theme.textMuted }} className="text-[10.5px]">
                          +{assignees.length - 4}
                        </span>
                      )}
                    </span>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[10.5px]">без исполнителя</span>
                  )}
                </div>
              </div>

              {t.dueDate && (
                <span className="mono text-[10.5px] shrink-0 mt-0.5"
                  style={{ color: dueColor(t.dueDate, t.completed, theme) || theme.textMuted }}>
                  {fmtDate(t.dueDate)}
                </span>
              )}
            </button>
          );
        })}
        {tasks.length === 0 && (
          <p style={{ color: theme.textMuted }} className="text-[13px] text-center py-8">
            Задач нет.
          </p>
        )}
      </div>
    </Modal>
  );
}
