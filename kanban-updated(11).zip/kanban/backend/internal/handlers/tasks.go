package handlers

import (
	"context"
	"errors"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/models"
)

// taskSelect — единая выборка задачи для всех обработчиков этого файла.
// created_by отдаётся всегда: на доске это неважно (там и так видно,
// кто исполнитель), а во «Входящих» это единственный способ понять, кто
// вообще поставил задачу в чужом проекте, не открывая карточку.
const taskSelect = `
	SELECT t.id, t.board_id, t.column_id, t.title, t.description, t.priority::text, t.color,
	       to_char(t.due_date, 'YYYY-MM-DD'),
	       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.position, t.tags, t.completed_at, t.created_by,
	       COALESCE(app.task_access(t.id, $1), 'read'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.user_id IS NOT NULL), '{}'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.completed_at IS NOT NULL), '{}'),
	       (SELECT count(*) FROM app.comments cm   WHERE cm.task_id = t.id),
	       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
	       (SELECT count(*) FROM app.task_steps xs WHERE xs.task_id = t.id),
	       (SELECT count(*) FROM app.task_steps xs WHERE xs.task_id = t.id AND xs.done),
	       t.created_at, t.updated_at,
	       app.board_title(t.board_id), app.column_title(t.column_id),
	       t.recur_freq, t.recur_interval, t.recur_weekdays, t.recur_monthday,
	       to_char(t.recur_until, 'YYYY-MM-DD'), t.report,
	       app.assignees_seen(t.id),
	       app.task_activity_at(t.id, $1),
	       app.seen_at('task', t.id, $1)
	  FROM app.tasks t
	  LEFT JOIN app.task_assignees a ON a.task_id = t.id`

func scanTasks(rows pgx.Rows) ([]models.Task, error) {
	out := []models.Task{}
	for rows.Next() {
		var t models.Task
		if err := rows.Scan(&t.ID, &t.BoardID, &t.ColumnID, &t.Title, &t.Description,
			&t.Priority, &t.Color, &t.DueDate, &t.IncomingNumber, &t.IncomingDate, &t.Position, &t.Tags, &t.CompletedAt, &t.CreatedBy, &t.Access,
			&t.Assignees, &t.AssigneesDone, &t.CommentCnt, &t.AttachCnt, &t.ExtStepCnt, &t.ExtStepDone, &t.CreatedAt, &t.UpdatedAt,
			&t.BoardTitle, &t.ColumnTitle,
			&t.RecurFreq, &t.RecurInterval, &t.RecurWeekdays, &t.RecurMonthday, &t.RecurUntil, &t.Report,
			&t.AssigneesSeen, &t.LastActivityAt, &t.SeenAt); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// attachSteps и attachGrants подгружают вложенные коллекции одним
// запросом на всю выборку — иначе на доске из полусотни задач это было
// бы полсотни дополнительных обращений к базе на каждый рендер.
func attachSteps(ctx context.Context, tx pgx.Tx, tasks []models.Task) error {
	if len(tasks) == 0 {
		return nil
	}
	ids := make([]uuid.UUID, len(tasks))
	index := make(map[uuid.UUID]int, len(tasks))
	for i, t := range tasks {
		ids[i] = t.ID
		index[t.ID] = i
		tasks[i].Steps = []models.Step{}
		tasks[i].Grants = []models.Grant{}
	}

	rows, err := tx.Query(ctx, `
		SELECT task_id, id, body, done, position, assignee_id,
		       to_char(due_date, 'YYYY-MM-DD'),
		       done_by, to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
		  FROM app.task_steps WHERE task_id = ANY($1) ORDER BY position`, ids)
	if err != nil {
		return err
	}
	for rows.Next() {
		var taskID uuid.UUID
		var st models.Step
		if err := rows.Scan(&taskID, &st.ID, &st.Body, &st.Done, &st.Position,
			&st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); err != nil {
			rows.Close()
			return err
		}
		if i, ok := index[taskID]; ok {
			tasks[i].Steps = append(tasks[i].Steps, st)
		}
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}

	grantRows, err := tx.Query(ctx, `
		SELECT task_id, user_id, access::text
		  FROM app.task_grants WHERE task_id = ANY($1)`, ids)
	if err != nil {
		return err
	}
	defer grantRows.Close()
	for grantRows.Next() {
		var taskID uuid.UUID
		var g models.Grant
		if err := grantRows.Scan(&taskID, &g.UserID, &g.Access); err != nil {
			return err
		}
		if i, ok := index[taskID]; ok {
			tasks[i].Grants = append(tasks[i].Grants, g)
		}
	}
	return grantRows.Err()
}

func (s *Server) ListTasks(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var tasks []models.Task
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE t.board_id = $2 AND NOT t.archived
			 GROUP BY t.id
			 ORDER BY t.position`, uid, boardID)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// AllTasks — сводный список всех задач, доступных пользователю, из всех
// проектов сразу. Служит источником для вкладки «Все задачи»: RLS сам
// ограничивает выдачу видимыми задачами, поэтому дополнительных проверок
// доступа здесь не нужно. Фильтрацию и сортировку выполняет клиент —
// объём на установку (до нескольких тысяч задач) это позволяет, а
// перекладывать набор фильтров в query-параметры значило бы дублировать
// на сервере всё то, что уже умеет таблица на фронте.
func (s *Server) AllTasks(c *fiber.Ctx) error {
	uid := s.uid(c)

	var tasks []models.Task
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE NOT t.archived
			 GROUP BY t.id
			 ORDER BY t.updated_at DESC`, uid)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// Inbox — задачи из чужих проектов, куда открыт точечный доступ или
// назначение. Условие «не участник доски» обязательно, иначе сюда
// попали бы и собственные задачи пользователя. Автор задачи (created_by
// в taskSelect) отдаётся вместе с остальным — фронт резолвит его через
// уже загруженный справочник и показывает на карточке.
func (s *Server) Inbox(c *fiber.Ctx) error {
	uid := s.uid(c)

	var tasks []models.Task
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT t.id, t.board_id, t.column_id, t.title, t.description, t.priority::text, t.color,
			       to_char(t.due_date, 'YYYY-MM-DD'),
			       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.position, t.tags, t.completed_at, t.created_by,
			       COALESCE(app.task_access(t.id, $1), 'read'),
			       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.user_id IS NOT NULL), '{}'),
	       COALESCE(array_agg(DISTINCT a.user_id) FILTER (WHERE a.completed_at IS NOT NULL), '{}'),
			       (SELECT count(*) FROM app.comments c    WHERE c.task_id = t.id),
			       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
			       t.created_at, t.updated_at, app.board_title(t.board_id),
			       app.assignees_seen(t.id),
			       app.task_activity_at(t.id, $1),
			       app.seen_at('task', t.id, $1)
			  FROM app.tasks t
			  LEFT JOIN app.task_assignees a ON a.task_id = t.id
			 WHERE app.board_role(t.board_id, $1) IS NULL
			   AND NOT t.archived
			 GROUP BY t.id
			 ORDER BY app.board_title(t.board_id), t.created_at DESC`, uid)
		if e != nil {
			return e
		}
		defer rows.Close()
		tasks = []models.Task{}
		for rows.Next() {
			var t models.Task
			if e := rows.Scan(&t.ID, &t.BoardID, &t.ColumnID, &t.Title, &t.Description,
				&t.Priority, &t.Color, &t.DueDate, &t.IncomingNumber, &t.IncomingDate, &t.Position, &t.Tags, &t.CompletedAt, &t.CreatedBy, &t.Access,
				&t.Assignees, &t.AssigneesDone, &t.CommentCnt, &t.AttachCnt, &t.CreatedAt, &t.UpdatedAt,
				&t.BoardTitle, &t.AssigneesSeen, &t.LastActivityAt, &t.SeenAt); e != nil {
				return e
			}
			tasks = append(tasks, t)
		}
		if e := rows.Err(); e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

func (s *Server) GetTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	t, err := s.loadTask(c, taskID)
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, t)
}

func (s *Server) loadTask(c *fiber.Ctx, taskID uuid.UUID) (models.Task, error) {
	uid := s.uid(c)
	var t models.Task

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Загрузка карточки целиком означает, что человек её открыл
		// (или только что сам изменил) — отмечаем просмотр до выборки,
		// чтобы в ответ ушли уже актуальные seenAt и галочки
		// исполнителей (п.3, п.5). Ошибку отметки не считаем
		// критичной: не показать выделение хуже, чем не отдать задачу.
		if _, e := tx.Exec(c.Context(),
			`SELECT app.mark_seen('task', $1, $2)`, taskID, uid); e != nil {
			return e
		}
		rows, e := tx.Query(c.Context(), taskSelect+` WHERE t.id = $2 GROUP BY t.id`, uid, taskID)
		if e != nil {
			return e
		}
		tasks, e := scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		if len(tasks) == 0 {
			return pgx.ErrNoRows
		}
		if e := attachSteps(c.Context(), tx, tasks); e != nil {
			return e
		}
		t = tasks[0]
		return nil
	})
	return t, err
}

// loadTasksByColumns — та же выборка, что и остальные, но по набору
// колонок сразу: используется после перемещения задачи, чтобы одним
// запросом получить актуальное состояние всех строк, чья позиция могла
// сдвинуться, и разослать их по WebSocket.
func (s *Server) loadTasksByColumns(c *fiber.Ctx, columnIDs []uuid.UUID) ([]models.Task, error) {
	uid := s.uid(c)
	var tasks []models.Task
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), taskSelect+`
			 WHERE t.column_id = ANY($2::uuid[])
			 GROUP BY t.id`, uid, columnIDs)
		if e != nil {
			return e
		}
		tasks, e = scanTasks(rows)
		rows.Close()
		if e != nil {
			return e
		}
		return attachSteps(c.Context(), tx, tasks)
	})
	return tasks, err
}

type taskInput struct {
	Title       string      `json:"title"`
	Description string      `json:"description"`
	Priority    string      `json:"priority"`
	Color       string      `json:"color"`
	IncomingNumber string   `json:"incomingNumber"`
	IncomingDate   *string  `json:"incomingDate"`
	ColumnID    uuid.UUID   `json:"columnId"`
	DueDate     *string     `json:"dueDate"`
	Tags        []string    `json:"tags"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Цикличность (п.6). Пустой RecurFreq или "none" — без повторения.
	RecurFreq     string `json:"recurFreq"`
	RecurInterval int    `json:"recurInterval"`
	RecurWeekdays []int  `json:"recurWeekdays"`
	RecurMonthday *int   `json:"recurMonthday"`
	RecurUntil    *string `json:"recurUntil"`
	// ClearRecur присутствует в общем payload формы задачи; при
	// создании не используется, но поле должно приниматься, иначе
	// строгий разбор JSON (DisallowUnknownFields) отклонит запрос.
	ClearRecur bool `json:"clearRecur"`
	// Чек-лист, заполненный прямо в форме создания (п.1). Пункты
	// создаются в той же транзакции, что и сама задача: иначе при
	// обрыве связи между двумя запросами осталась бы задача с
	// наполовину заполненным чек-листом, а пользователь бы об этом
	// не узнал.
	Steps []taskStepInput `json:"steps"`
}

// taskStepInput — пункт чек-листа в форме создания задачи. Совпадает по
// смыслу со stepInput отдельного маршрута, но живёт отдельно: там это
// тело запроса, здесь — вложенный элемент.
type taskStepInput struct {
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
}

// normalizeRecurrence приводит правило повторения к согласованному виду
// и возвращает значения, готовые к записи. Некорректные комбинации
// сбрасываются в «нет повторения», чтобы в БÐ не попадал мусор.
func normalizeRecurrence(freq string, interval int, weekdays []int, monthday *int) (string, int, []int, *int) {
	switch freq {
	case "daily", "weekly", "monthly":
	default:
		return "none", 1, []int{}, nil
	}
	if interval < 1 {
		interval = 1
	}
	if weekdays == nil {
		weekdays = []int{}
	}
	if freq != "weekly" {
		weekdays = []int{}
	}
	if freq != "monthly" {
		monthday = nil
	}
	return freq, interval, weekdays, monthday
}

func (s *Server) CreateTask(c *fiber.Ctx) error {
	boardID, err := param(c, "boardID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_title", "Название задачи не может быть пустым"))
	}
	if in.Priority == "" {
		in.Priority = "medium"
	}
	if in.Color == "" {
		in.Color = "none"
	}
	if in.Tags == nil {
		in.Tags = []string{}
	}
	uid := s.uid(c)

	// Идентификатор задаём сами, а не получаем через RETURNING.
	//
	// Причина: политика tasks_select проверяет видимость через
	// app.can_see_task(), а та повторно читает app.tasks по этому же
	// идентификатору. При INSERT ... RETURNING проверка SELECT-политики
	// выполняется в рамках той же команды, и функция, объявленная
	// STABLE, работает со снимком, где вставляемой строки ещё нет, —
	// политика отвечает «не видно», и вся вставка отвергается как
	// отказ доступа. Владелец проекта при этом получал «Недостаточно
	// прав» на создание собственной задачи.
	//
	// Без RETURNING SELECT-политика не задействуется вообще, а
	// WITH CHECK политики tasks_insert проверяется по значениям новой
	// строки напрямую и отрабатывает как задумано.
	taskID := uuid.New()
	rFreq, rInt, rWeek, rMonth := normalizeRecurrence(in.RecurFreq, in.RecurInterval, in.RecurWeekdays, in.RecurMonthday)
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
			                       due_date, tags, incoming_number, incoming_date, position, created_by,
			                       recur_freq, recur_interval, recur_weekdays, recur_monthday, recur_until)
			VALUES ($1, $2, $3, $4, $5, $6::app.task_priority, $7, $8::date, $9, $10, $11::date,
			        COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0), $12,
			        $13, $14, $15, $16, $17::date)`,
			taskID, boardID, in.ColumnID, in.Title, in.Description, in.Priority, in.Color,
			in.DueDate, in.Tags, in.IncomingNumber, in.IncomingDate, uid,
			rFreq, rInt, rWeek, rMonth, in.RecurUntil); e != nil {
			return e
		}
		var e error
		pending, e = s.replaceAssignees(c.Context(), tx, taskID, in.Assignees, uid, boardID)
		if e != nil {
			return e
		}
		// Чек-лист из формы создания. Позиция — порядок в форме;
		// исполнитель пункта, как и на отдельном маршруте, попадает в
		// исполнители задачи (иначе он не увидит задачу, в которой
		// ему поручен пункт).
		pos := 0
		for _, st := range in.Steps {
			body := strings.TrimSpace(st.Body)
			if body == "" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.task_steps (task_id, body, position, assignee_id, due_date, created_by)
				VALUES ($1, $2, $3, $4, $5::date, $6)`,
				taskID, body, pos, st.AssigneeID, st.DueDate, uid); e != nil {
				return e
			}
			if st.AssigneeID != nil {
				if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
					taskID, *st.AssigneeID, uid); e != nil {
					return e
				}
			}
			pos++
		}

		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Задача создана')`,
			taskID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusCreated, t)
}

// TransferTask переносит задачу в другой проект вместе со всем, что к ней
// приросло: исполнителями, комментариями, файлами, чек-листом, отчётом
// и историей.
//
// Отдельно ничего переносить не требуется — всё это ссылается на
// задачу по task_id, а не на проект, поэтому достаточно сменить
// board_id и column_id у самой задачи. Именно этим перенос и отличается
// от копирования: там создаётся новая строка, и приросшее приходится
// либо копировать выборочно, либо оставлять.
//
// Права нужны с обеих сторон: право править задачу (иначе её мог бы
// унести кто угодно, кому её показали) и право заводить задачи в
// проекте-получателе. Второе — не просто членство, а редактирование:
// перенос приводит в проект чужую задачу целиком, вместе с
// исполнителями и перепиской.
// Имя не MoveTask: так уже называется перекладывание карточки между
// колонками внутри доски. Разные действия — разные имена, иначе
// одинаковое название на два совершенно разных смысла путает и код, и
// маршруты.
func (s *Server) TransferTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyTaskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.BoardID == uuid.Nil || in.ColumnID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_target",
			"Выберите проект и колонку, куда переносить задачу"))
	}
	uid := s.uid(c)

	var oldBoardID uuid.UUID
	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var title string
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id, title FROM app.tasks WHERE id = $1`, taskID).
			Scan(&oldBoardID, &title); e != nil {
			return e
		}
		if oldBoardID == in.BoardID {
			return httpx.Err(fiber.StatusBadRequest, "same_board",
				"Задача уже находится в этом проекте")
		}

		var canEdit bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_edit_board($1, $2)`, in.BoardID, uid).Scan(&canEdit); e != nil {
			return e
		}
		if !canEdit {
			return httpx.Err(fiber.StatusForbidden, "not_editor",
				"Переносить задачи можно только в проект, где вы владелец или редактор")
		}

		var okCol bool
		if e := tx.QueryRow(c.Context(),
			`SELECT EXISTS (SELECT 1 FROM app.columns WHERE id = $1 AND board_id = $2)`,
			in.ColumnID, in.BoardID).Scan(&okCol); e != nil {
			return e
		}
		if !okCol {
			return httpx.Err(fiber.StatusBadRequest, "bad_column",
				"Колонка не принадлежит выбранному проекту")
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks
			   SET board_id  = $2,
			       column_id = $3,
			       position  = COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0)
			 WHERE id = $1`, taskID, in.BoardID, in.ColumnID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			// Политика tasks_update не пропустила: задача чужая.
			return httpx.ErrForbidden
		}

		// Исполнители остаются те же, но в новом проекте они могут не
		// состоять участниками. Задачу они всё равно увидят — доступ
		// исполнителя точечный и от проекта не зависит, — так что
		// ничего чинить не нужно. Достаточно сказать об этом в
		// истории, чтобы перенос не выглядел бесследным.
		var boardTitle string
		if e := tx.QueryRow(c.Context(),
			`SELECT app.board_title($1)`, in.BoardID).Scan(&boardTitle); e != nil {
			return e
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, "Задача перенесена в проект «"+boardTitle+"»"); e != nil {
			return e
		}

		pending, e = s.notifyTaskWatchers(c.Context(), tx, taskID, in.BoardID, uid,
			"Задача «"+title+"» перенесена в проект «"+boardTitle+"»")
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	// Сначала убираем задачу с прежней доски у тех, кто на неё
	// смотрит, и только потом рассылаем как новую. Обратный порядок
	// оставил бы у наблюдателей обеих досок карточку-призрак: событие
	// об удалении пришло бы последним и стёрло только что добавленную.
	s.publishTaskDeletedTo(s.watchersOfBoard(c.Context(), oldBoardID), oldBoardID, taskID)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusOK, t)
}

type copyTaskInput struct {
	BoardID  uuid.UUID `json:"boardId"`
	ColumnID uuid.UUID `json:"columnId"`
}

// CopyTask создаёт копию задачи в выбранном проекте и колонке.
//
// Копируются поля задачи, чек-лист (обычный и расширенный) и теги.
// Исполнители и точечные гранты НЕ копируются: при переносе в другой
// проект они, как правило, нерелевантны, а раздача доступа — отдельное
// осознанное действие. Автором копии становится тот, кто копирует;
// completed_at сбрасывается.
//
// Права: копировать вправе тот, кто видит исходную задачу (RLS
// пропустит SELECT) и может создавать задачи в целевом проекте — то
// есть является его участником (owner, editor или reader, п.7).
// Идентификатор задаём сами по той же причине, что и в CreateTask.
func (s *Server) CopyTask(c *fiber.Ctx) error {
	srcID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in copyTaskInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.BoardID == uuid.Nil || in.ColumnID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_target",
			"Выберите проект и колонку для копии"))
	}
	uid := s.uid(c)
	newID := uuid.New()

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Право создавать в целевом проекте: участник проекта в любой
		// роли. Проверяем явно, чтобы вернуть понятную ошибку раньше,
		// чем сработает WITH CHECK политики tasks_insert.
		var role *string
		if e := tx.QueryRow(c.Context(),
			`SELECT app.board_role($1, $2)`, in.BoardID, uid).Scan(&role); e != nil {
			return e
		}
		if role == nil {
			return httpx.Err(fiber.StatusForbidden, "not_member",
				"Нет прав на создание задач в выбранном проекте")
		}

		// Целевая колонка обязана принадлежать целевому проекту.
		var okCol bool
		if e := tx.QueryRow(c.Context(),
			`SELECT EXISTS (SELECT 1 FROM app.columns WHERE id = $1 AND board_id = $2)`,
			in.ColumnID, in.BoardID).Scan(&okCol); e != nil {
			return e
		}
		if !okCol {
			return httpx.Err(fiber.StatusBadRequest, "bad_column",
				"Колонка не принадлежит выбранному проекту")
		}

		// Вставляем копию, читая исходник тем же запросом. Видимость
		// исходной задачи обеспечивает RLS: если она недоступна,
		// подзапрос вернёт 0 строк и вставки не будет.
		tag, e := tx.Exec(c.Context(), `
			INSERT INTO app.tasks (id, board_id, column_id, title, description, priority, color,
			                       due_date, tags, incoming_number, incoming_date, position, created_by)
			SELECT $1, $2, $3,
			       t.title, t.description, t.priority, t.color,
			       t.due_date, t.tags, t.incoming_number, t.incoming_date,
			       COALESCE((SELECT max(position) + 1 FROM app.tasks WHERE column_id = $3), 0), $4
			  FROM app.tasks t WHERE t.id = $5`,
			newID, in.BoardID, in.ColumnID, uid, srcID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrNotFound
		}

		// Чек-лист копируем со сбросом отметок; исполнителя и срок
		// пункта переносим (единый объединённый чек-лист, п.5).
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.task_steps (task_id, body, done, position, assignee_id, due_date, created_by)
			SELECT $1, body, false, position, assignee_id, due_date, $2
			  FROM app.task_steps WHERE task_id = $3`, newID, uid, srcID); e != nil {
			return e
		}

		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Задача создана копированием')`,
			newID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	t, err := s.loadTask(c, newID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "created")
	return httpx.JSON(c, fiber.StatusCreated, t)
}

func (s *Server) replaceAssignees(ctx context.Context, tx pgx.Tx, taskID uuid.UUID,
	assignees []uuid.UUID, actor, boardID uuid.UUID) ([]pendingNotif, error) {

	// Прежний состав нужен, чтобы записать в историю именно изменения:
	// кого добавили и кого сняли, с ФИО (п.5).
	oldRows, err := tx.Query(ctx, `SELECT user_id FROM app.task_assignees WHERE task_id = $1`, taskID)
	if err != nil {
		return nil, err
	}
	oldSet := map[uuid.UUID]bool{}
	for oldRows.Next() {
		var id uuid.UUID
		if e := oldRows.Scan(&id); e != nil {
			oldRows.Close()
			return nil, e
		}
		oldSet[id] = true
	}
	oldRows.Close()
	if e := oldRows.Err(); e != nil {
		return nil, e
	}

	newSet := map[uuid.UUID]bool{}
	for _, a := range assignees {
		newSet[a] = true
	}

	if _, err := tx.Exec(ctx, `DELETE FROM app.task_assignees WHERE task_id = $1`, taskID); err != nil {
		return nil, err
	}
	var pending []pendingNotif
	var added, removed []uuid.UUID
	for _, a := range assignees {
		if _, err := tx.Exec(ctx, `
			INSERT INTO app.task_assignees (task_id, user_id) VALUES ($1, $2)
			ON CONFLICT DO NOTHING`, taskID, a); err != nil {
			return nil, err
		}
		if !oldSet[a] {
			added = append(added, a)
			// Уведомляем ТОЛЬКО новых исполнителей: те, кто уже был в
			// задаче, повторное «Вам назначена задача» получать не должны.
			if a != actor {
				n, err := notifyInsertCat(ctx, tx, a, "Вам назначена задача", "assigned", &boardID, &taskID)
				if err != nil {
					return nil, err
				}
				if n.ID != uuid.Nil {
					pending = append(pending, pendingNotif{UserID: a, Notif: n})
				}
			}
		}
	}
	for id := range oldSet {
		if !newSet[id] {
			removed = append(removed, id)
		}
	}

	// Пишем конкретику в журнал: «Добавлены исполнители: …»,
	// «Удалены исполнители: …».
	if len(added) > 0 {
		if names, e := userNames(ctx, tx, added); e == nil && names != "" {
			_, _ = tx.Exec(ctx, `INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1,$2,$3)`,
				taskID, actor, "Добавлены исполнители: "+names)
		}
	}
	if len(removed) > 0 {
		if names, e := userNames(ctx, tx, removed); e == nil && names != "" {
			_, _ = tx.Exec(ctx, `INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1,$2,$3)`,
				taskID, actor, "Удалены исполнители: "+names)
		}
	}
	return pending, nil
}

// userNames возвращает ФИО пользователей через запятую (для журнала).
func userNames(ctx context.Context, tx pgx.Tx, ids []uuid.UUID) (string, error) {
	if len(ids) == 0 {
		return "", nil
	}
	rows, err := tx.Query(ctx,
		`SELECT full_name FROM app.users WHERE id = ANY($1) ORDER BY full_name`, ids)
	if err != nil {
		return "", err
	}
	defer rows.Close()
	var names []string
	for rows.Next() {
		var n string
		if e := rows.Scan(&n); e != nil {
			return "", e
		}
		names = append(names, n)
	}
	return strings.Join(names, ", "), rows.Err()
}

type taskPatch struct {
	Title       *string      `json:"title"`
	Description *string      `json:"description"`
	Priority    *string      `json:"priority"`
	Color       *string      `json:"color"`
	IncomingNumber *string   `json:"incomingNumber"`
	IncomingDate   *string   `json:"incomingDate"`
	ColumnID    *uuid.UUID   `json:"columnId"`
	DueDate     *string      `json:"dueDate"`
	Tags        *[]string    `json:"tags"`
	Assignees   *[]uuid.UUID `json:"assignees"`
	RecurFreq     *string `json:"recurFreq"`
	RecurInterval *int    `json:"recurInterval"`
	RecurWeekdays *[]int  `json:"recurWeekdays"`
	RecurMonthday *int    `json:"recurMonthday"`
	RecurUntil    *string `json:"recurUntil"`
	// ClearRecur — явный сброс цикличности (клиент шлёт true, чтобы
	// снять повторение, т.к. отсутствие поля означает «не менять»).
	ClearRecur bool `json:"clearRecur"`
}

func (s *Server) UpdateTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in taskPatch
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Старые значения нужны, чтобы записать в историю конкретные
		// изменения, а не просто «задача отредактирована» (п.4).
		var boardID uuid.UUID
		var old struct {
			Title, Desc, Priority, Color, IncNum string
			DueDate, IncDate                     *string
			ColumnID                             uuid.UUID
			RecurFreq                            string
		}
		if e := tx.QueryRow(c.Context(), `
			SELECT board_id, title, description, priority::text, color, incoming_number,
			       to_char(due_date, 'YYYY-MM-DD'), to_char(incoming_date, 'YYYY-MM-DD'),
			       column_id, recur_freq
			  FROM app.tasks WHERE id = $1`, taskID).
			Scan(&boardID, &old.Title, &old.Desc, &old.Priority, &old.Color, &old.IncNum,
				&old.DueDate, &old.IncDate, &old.ColumnID, &old.RecurFreq); e != nil {
			return e
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks SET
				title       = COALESCE($2, title),
				description = COALESCE($3, description),
				priority    = COALESCE($4::app.task_priority, priority),
				color       = COALESCE($5, color),
				column_id   = COALESCE($6, column_id),
				due_date    = COALESCE($7::date, due_date),
				tags        = COALESCE($8, tags),
				incoming_number = COALESCE($9, incoming_number),
				incoming_date   = COALESCE($10::date, incoming_date)
			WHERE id = $1`,
			taskID, in.Title, in.Description, in.Priority, in.Color, in.ColumnID, in.DueDate, in.Tags,
			in.IncomingNumber, in.IncomingDate)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}

		// Цикличность: сброс или установка нового правила.
		if in.ClearRecur {
			if _, e := tx.Exec(c.Context(), `
				UPDATE app.tasks SET recur_freq='none', recur_interval=1,
				       recur_weekdays='{}', recur_monthday=NULL, recur_until=NULL
				 WHERE id = $1`, taskID); e != nil {
				return e
			}
		} else if in.RecurFreq != nil {
			interval := 1
			if in.RecurInterval != nil {
				interval = *in.RecurInterval
			}
			var week []int
			if in.RecurWeekdays != nil {
				week = *in.RecurWeekdays
			}
			f, iv, wk, md := normalizeRecurrence(*in.RecurFreq, interval, week, in.RecurMonthday)
			if _, e := tx.Exec(c.Context(), `
				UPDATE app.tasks SET recur_freq=$2, recur_interval=$3, recur_weekdays=$4,
				       recur_monthday=$5, recur_until=$6::date WHERE id = $1`,
				taskID, f, iv, wk, md, in.RecurUntil); e != nil {
				return e
			}
		}

		if in.Assignees != nil {
			pending, e = s.replaceAssignees(c.Context(), tx, taskID, *in.Assignees, uid, boardID)
			if e != nil {
				return e
			}
		}

		// Перенос срока — единственная правка, о которой оповещают
		// отдельно. Причина простая: срок определяет, когда за задачу
		// садиться, и узнавать о его переносе из журнала задним
		// числом поздно. Особенно теперь, когда срок меняется
		// перетаскиванием в календаре — то есть мимоходом, без
		// открытия карточки.
		if in.DueDate != nil && (old.DueDate == nil || *old.DueDate != *in.DueDate) {
			title := old.Title
			if in.Title != nil {
				title = *in.Title
			}
			body := "Срок задачи «" + title + "» перенесён на " + humanDate(*in.DueDate)
			if old.DueDate != nil {
				body += " (было " + humanDate(*old.DueDate) + ")"
			}
			more, e := s.notifyTaskWatchers(c.Context(), tx, taskID, boardID, uid, body)
			if e != nil {
				return e
			}
			pending = append(pending, more...)
		}

		// Формируем список конкретных изменений для журнала.
		changes := describeTaskChanges(old.Title, old.Desc, old.Priority, old.Color, old.IncNum,
			old.DueDate, old.IncDate, in)
		entry := "Задача отредактирована"
		if len(changes) > 0 {
			entry = "Изменено: " + strings.Join(changes, "; ")
		}
		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

// humanDate переводит дату из формата хранения (YYYY-MM-DD) в
// привычный ДД.ММ.ГГГГ. Уведомление читают люди, а не парсеры.
func humanDate(iso string) string {
	if len(iso) != 10 {
		return iso
	}
	return iso[8:10] + "." + iso[5:7] + "." + iso[0:4]
}

// describeTaskChanges сравнивает старые значения с патчем и возвращает
// человекочитаемые описания изменений для журнала (п.4). В патче nil
// означает «поле не менялось».
func describeTaskChanges(oldTitle, oldDesc, oldPriority, oldColor, oldIncNum string,
	oldDue, oldIncDate *string, in taskPatch) []string {
	var ch []string
	deref := func(p *string) string {
		if p == nil {
			return ""
		}
		return *p
	}
	if in.Title != nil && *in.Title != oldTitle {
		ch = append(ch, "название → «"+*in.Title+"»")
	}
	if in.Description != nil && *in.Description != oldDesc {
		ch = append(ch, "описание обновлено")
	}
	if in.Priority != nil && *in.Priority != oldPriority {
		ch = append(ch, "приоритет → "+priorityLabel(*in.Priority))
	}
	if in.Color != nil && *in.Color != oldColor {
		ch = append(ch, "цвет изменён")
	}
	if in.IncomingNumber != nil && *in.IncomingNumber != oldIncNum {
		ch = append(ch, "входящий № → «"+*in.IncomingNumber+"»")
	}
	if in.DueDate != nil && deref(in.DueDate) != deref(oldDue) {
		if *in.DueDate == "" {
			ch = append(ch, "срок снят")
		} else {
			ch = append(ch, "срок → "+*in.DueDate)
		}
	}
	if in.IncomingDate != nil && deref(in.IncomingDate) != deref(oldIncDate) {
		ch = append(ch, "дата входящего → "+deref(in.IncomingDate))
	}
	if in.ColumnID != nil {
		ch = append(ch, "перемещена в другую колонку")
	}
	if in.Tags != nil {
		ch = append(ch, "теги обновлены")
	}
	// Изменения исполнителей журналирует replaceAssignees отдельными
	// записями с ФИО — здесь не дублируем.
	if in.ClearRecur {
		ch = append(ch, "повторение отключено")
	} else if in.RecurFreq != nil {
		ch = append(ch, "настроено повторение")
	}
	return ch
}

func priorityLabel(p string) string {
	switch p {
	case "low":
		return "низкий"
	case "medium":
		return "средний"
	case "high":
		return "высокий"
	case "urgent":
		return "срочный"
	}
	return p
}

type reportInput struct {
	Report string `json:"report"`
}

// SetReport сохраняет отчёт о выполнении задачи (п.3). Право — у тех,
// кто участвует в задаче: автор, редактор/владелец, назначенный
// исполнитель или обладатель гранта на участие (can_contribute_task).
func (s *Server) SetReport(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in reportInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canContribute bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_contribute_task($1, $2)`, taskID, uid).Scan(&canContribute); e != nil {
			return e
		}
		if !canContribute {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Отчёт может заполнить исполнитель, автор задачи или редактор проекта")
		}

		// У завершённой задачи отчёт не правится.
		//
		// Отчёт — это итог работы, и после закрытия задачи он
		// становится документом: по нему принимали работу, на него
		// ссылались в переписке. Тихая правка задним числом делает
		// такую ссылку недостоверной. Нужно исправить — задачу
		// возвращают в работу, и это видно в истории.
		var completed bool
		if e := tx.QueryRow(c.Context(),
			`SELECT completed_at IS NOT NULL FROM app.tasks WHERE id = $1`, taskID).
			Scan(&completed); e != nil {
			return e
		}
		if completed {
			return httpx.Err(fiber.StatusConflict, "task_completed",
				"Задача завершена — отчёт больше не редактируется. "+
					"Верните задачу в работу, если нужно его исправить")
		}
		// Отчёт правится SECURITY DEFINER-функцией, чтобы не зависеть от
		// того, какой уровень (edit/contribute) вернул task_access:
		// участник с contribute тоже должен мочь писать отчёт, а общая
		// политика tasks_update требует edit.
		if _, e := tx.Exec(c.Context(),
			`SELECT app.set_task_report($1, $2, $3)`, taskID, in.Report, uid); e != nil {
			return e
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

type moveInput struct {
	ColumnID uuid.UUID `json:"columnId"`
	Position int       `json:"position"`
}

// MoveTask сдвигает соседей и уплотняет нумерацию в обеих затронутых
// колонках в одной транзакции — при двух одновременных перетаскиваниях
// порядок иначе разъезжается. Перенос в колонку с флагом «завершения»
// сам проставляет completed_at и наоборот.
func (s *Server) MoveTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in moveInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Position < 0 {
		in.Position = 0
	}
	uid := s.uid(c)
	// Захватывается внутри транзакции ниже и используется после её
	// коммита — нужна, чтобы понять, чьи ещё позиции сдвинулись.
	var oldColumn uuid.UUID

	// Перемещение выполняет SECURITY DEFINER функция app.move_task:
	// она сама проверяет право на перенос (автор задачи, редактор или
	// владелец проекта) и меняет только колонку с позицией, не открывая
	// читателю-автору возможности править содержание задачи. Читатель,
	// не являющийся автором, получает от функции move_denied.
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT app.move_task($1, $2, $3, $4)`,
			taskID, uid, in.ColumnID, in.Position).Scan(&oldColumn)
	})
	if err != nil {
		// Отказ доступа move_task поднимает как insufficient_privilege
		// (SQLSTATE 42501). Различаем два случая по тексту исключения:
		// нет прав на перемещение вообще и запрет исполнителю ставить
		// задачу в колонку закрытия.
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == "42501" {
			if pgErr.Message == "move_to_done_denied" {
				return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "move_to_done_denied",
					"Завершить задачу может автор задачи, редактор или владелец проекта"))
			}
			return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "move_denied",
				"Вы не являетесь автором задачи или у Вас отсутствуют права на перемещение"))
		}
		return httpx.Fail(c, err)
	}

	// Уплотнение нумерации выше сдвигает position не только у самой
	// перемещённой задачи, но и у всех её соседей в обеих колонках.
	// Разослать нужно каждую из них — иначе на экране других участников
	// (и в других открытых вкладках этого же пользователя) соседние
	// карточки останутся в старом порядке до следующей полной
	// перезагрузки доски, чего мы и добиваемся избежать.
	touched, err := s.loadTasksByColumns(c, []uuid.UUID{oldColumn, in.ColumnID})
	if err != nil {
		return httpx.Fail(c, err)
	}
	var moved models.Task
	for _, t := range touched {
		action := "updated"
		if t.ID == taskID {
			action = "moved"
			moved = t
		}
		go s.publishTask(t, action)
	}
	return httpx.JSON(c, fiber.StatusOK, moved)
}

type completeInput struct {
	Completed bool `json:"completed"`
}

func (s *Server) CompleteTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in completeInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	// id порождённого экземпляра цикличной задачи (если создан).
	var spawnedID *uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Завершить задачу вправе только её автор или владелец проекта.
		// Исполнитель сообщает о готовности отметкой о сдаче
		// (POST /assignment) — принимает работу поставивший.
		var canClose bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_close_task($1, $2)`, taskID, uid).Scan(&canClose); e != nil {
			return e
		}
		if !canClose {
			return httpx.Err(fiber.StatusForbidden, "not_author",
				"Завершить задачу может только её автор. Отметьте выполнение своей части — автор примет работу")
		}

		// Связь «блокирует» должна что-то значить, иначе она просто
		// пометка. Пока блокирующая задача не закрыта, закрыть
		// заблокированную нельзя — проверка на сервере, а не только в
		// интерфейсе: иначе её обойдёт любой прямой запрос.
		if in.Completed {
			var blocker string
			e := tx.QueryRow(c.Context(), `
				SELECT b.title
				  FROM app.task_links l
				  JOIN app.tasks b ON b.id = l.from_task
				 WHERE l.to_task = $1 AND l.kind = 'blocks'
				   AND b.completed_at IS NULL
				 LIMIT 1`, taskID).Scan(&blocker)
			if e == nil {
				return httpx.Err(fiber.StatusConflict, "blocked",
					"Задача заблокирована: сначала завершите «"+blocker+"»")
			}
			if !errors.Is(e, pgx.ErrNoRows) {
				return e
			}
		}

		var boardID uuid.UUID
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID); e != nil {
			return e
		}

		query := `SELECT id FROM app.columns WHERE board_id = $1 AND is_done ORDER BY position LIMIT 1`
		if !in.Completed {
			query = `SELECT id FROM app.columns WHERE board_id = $1 AND NOT is_done ORDER BY position LIMIT 1`
		}
		var targetCol *uuid.UUID
		var col uuid.UUID
		switch e := tx.QueryRow(c.Context(), query, boardID).Scan(&col); {
		case e == nil:
			targetCol = &col
		case errors.Is(e, pgx.ErrNoRows):
			targetCol = nil
		default:
			return e
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.tasks
			   SET completed_at = CASE WHEN $2 THEN now() ELSE NULL END,
			       column_id    = COALESCE($3, column_id)
			 WHERE id = $1`, taskID, in.Completed, targetCol)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}

		body := "Задача завершена"
		if !in.Completed {
			body = "Задача возвращена в работу"
		}
		if _, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`, taskID, uid, body); e != nil {
			return e
		}

		// Цикличная задача при завершении порождает следующий экземпляр
		// (п.6). Ошибку спавна не глушим — расписание не должно молча
		// ломаться, но саму отметку о завершении это не откатывает
		// сверх транзакции (всё в одной tx: если спавн упал, откат
		// корректен и клиент увидит ошибку).
		if in.Completed {
			if e = tx.QueryRow(c.Context(),
				`SELECT app.spawn_recurrence($1, $2)`, taskID, uid).Scan(&spawnedID); e != nil {
				return e
			}
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	// Новый экземпляр цикличной задачи публикуем как created, чтобы он
	// сразу появился на доске без перезагрузки (п.1).
	if spawnedID != nil {
		if nt, e := s.loadTask(c, *spawnedID); e == nil {
			go s.publishTask(nt, "created")
		}
	}

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

func (s *Server) DeleteTask(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var boardID uuid.UUID
	if e := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `SELECT board_id FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID)
	}); e != nil {
		return httpx.Fail(c, httpx.ErrNotFound)
	}

	// Список получателей снимаем ДО удаления. task_grants и
	// task_assignees связаны с задачей через ON DELETE CASCADE, то есть
	// исчезают вместе с ней, — а именно эти строки и делают человека
	// наблюдателем. Спросив список после удаления, мы получили бы одних
	// участников доски, и у того, кому была открыта только эта задача,
	// она продолжала бы висеть на экране до перезагрузки страницы.
	watchCtx, cancelWatch := bgContext()
	watchers := s.watchersOfTaskForBoard(watchCtx, boardID, taskID)
	cancelWatch()

	var affected int64
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `DELETE FROM app.tasks WHERE id = $1`, taskID)
		affected = tag.RowsAffected()
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	go s.publishTaskDeletedTo(watchers, boardID, taskID)
	return httpx.NoContent(c)
}

// ------------------------------------------------------------- чек-лист
//
// Отметка выполнения и правка текста шага разнесены по разным
// маршрутам (POST .../toggle и PATCH .../:stepID) сознательно: раньше
// оба действия шли одним обработчиком, различавшим их по тому, какие
// поля пришли в JSON. На практике это было источником путаницы —
// пустая строка «текст не менялся» и «текст стёрт» неотличимы без
// дополнительного признака, а вместе с обновлением done той же строкой
// клиенту приходилось всякий раз собирать частично заполненный объект.
// Раздельные эндпоинты убирают саму возможность такой ошибки: у каждого
// ровно одно однозначное тело запроса и своя проверка прав.

type stepInput struct {
	Body       string     `json:"body"`
	AssigneeID *uuid.UUID `json:"assigneeId"`
	DueDate    *string    `json:"dueDate"`
}

func (s *Server) CreateStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in stepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_step", "Текст шага не может быть пустым"))
	}

	uid := s.uid(c)
	var st models.Step
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Редактировать состав чек-листа может автор задачи, редактор
		// или владелец проекта (единое правило для объединённого
		// чек-листа, п.5).
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_steps($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять чек-лист может автор задачи, редактор или владелец проекта")
		}
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.task_steps (task_id, body, position, assignee_id, due_date, created_by)
			VALUES ($1, $2, COALESCE((SELECT max(position) + 1 FROM app.task_steps WHERE task_id = $1), 0),
			        $3, $4::date, $5)
			RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			          to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			taskID, body, in.AssigneeID, in.DueDate, uid).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}
		// Назначение исполнителя в пункте открывает ему доступ к задаче
		// (как и раньше в расширенном чек-листе): добавляем в
		// исполнители задачи, если указан.
		if in.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
				taskID, *in.AssigneeID, uid); e != nil {
				return e
			}
		}
		entry := "Добавлен пункт чек-листа «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishStep(taskID, st, "created")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusCreated, st)
}

// UpdateStep меняет текст, исполнителя и срок пункта. Доступно автору
// задачи, редактору и владельцу проекта (единое правило для
// объединённого чек-листа, п.5).
func (s *Server) RenameStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in stepInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	body := strings.TrimSpace(in.Body)
	if body == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty_step", "Текст шага не может быть пустым"))
	}
	uid := s.uid(c)

	var st models.Step
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canManage bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_manage_steps($1, $2)`, taskID, uid).Scan(&canManage); e != nil {
			return e
		}
		if !canManage {
			return httpx.Err(fiber.StatusForbidden, "forbidden",
				"Изменять чек-лист может автор задачи, редактор или владелец проекта")
		}
		var before string
		if e := tx.QueryRow(c.Context(),
			`SELECT body FROM app.task_steps WHERE id = $1 AND task_id = $2`,
			stepID, taskID).Scan(&before); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(), `
			UPDATE app.task_steps
			   SET body = $3, assignee_id = $4, due_date = $5::date
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			           to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			stepID, taskID, body, in.AssigneeID, in.DueDate).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}
		if in.AssigneeID != nil {
			if _, e := tx.Exec(c.Context(), `SELECT app.ensure_assignee($1, $2, $3)`,
				taskID, *in.AssigneeID, uid); e != nil {
				return e
			}
		}
		var entry string
		if before != st.Body {
			entry = "Пункт чек-листа «" + before + "» изменён на «" + st.Body + "»"
		} else {
			entry = "Изменён пункт чек-листа «" + st.Body + "»"
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, entry)
		return e
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishStep(taskID, st, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, st)
}

type toggleInput struct {
	Done bool `json:"done"`
}

// ToggleStep — единственное, что нужно фронту для клика по чекбоксу:
// одно поле, один смысл, доступно любому участнику с правом contribute
// (читатель доски, назначенный исполнитель, точечный грант «участие»).
func (s *Server) ToggleStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in toggleInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var st models.Step
	var watchers []uuid.UUID
	var denied bool
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Право на отметку: если у пункта задан исполнитель — только он
		// (или тот, кто ведёт чек-лист). Если исполнитель не задан —
		// любой участник задачи (п.5).
		var canCheck bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_check_step($1, $2)`, stepID, uid).Scan(&canCheck); e != nil {
			return e
		}
		if !canCheck {
			denied = true
			return nil
		}
		if e := tx.QueryRow(c.Context(), `
			UPDATE app.task_steps
			   SET done    = $3,
			       done_by = CASE WHEN $3 THEN $4::uuid ELSE NULL END,
			       done_at = CASE WHEN $3 THEN now() ELSE NULL END
			 WHERE id = $1 AND task_id = $2
			 RETURNING id, body, done, position, assignee_id, to_char(due_date, 'YYYY-MM-DD'), done_by,
			           to_char(done_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			stepID, taskID, in.Done, uid).
			Scan(&st.ID, &st.Body, &st.Done, &st.Position, &st.AssigneeID, &st.DueDate, &st.DoneBy, &st.DoneAt); e != nil {
			return e
		}

		verb := "Отмечен пункт"
		if !in.Done {
			verb = "Снята отметка с пункта"
		}
		body := verb + " «" + st.Body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, body); e != nil {
			return e
		}
		var e error
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, body)
		return e
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	if denied {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_allowed",
			"Отметить этот пункт может только назначенный исполнитель"))
	}
	go s.publishStep(taskID, st, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, st)
}

func (s *Server) DeleteStep(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	stepID, err := param(c, "stepID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var affected int64
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Текст удаляемого пункта читаем до удаления: после DELETE
		// восстановить его для записи в историю уже неоткуда, а
		// «удалён пункт» без названия ничего не говорит.
		var body string
		if e := tx.QueryRow(c.Context(),
			`SELECT body FROM app.task_steps WHERE id = $1 AND task_id = $2`,
			stepID, taskID).Scan(&body); e != nil {
			if errors.Is(e, pgx.ErrNoRows) {
				return nil // строки нет — affected останется 0
			}
			return e
		}

		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.task_steps WHERE id = $1 AND task_id = $2`, stepID, taskID)
		if e != nil {
			return e
		}
		affected = tag.RowsAffected()
		if affected == 0 {
			return nil
		}

		entry := "Удалён пункт чек-листа «" + body + "»"
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, entry); e != nil {
			return e
		}
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, entry)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	go s.publishStep(taskID, models.Step{ID: stepID}, "deleted")
	go s.pingNotifications(watchers)
	return httpx.NoContent(c)
}

// --------------------------------------------------------------- гранты

type grantInput struct {
	UserID uuid.UUID `json:"userId"`
	Access string    `json:"access"`
}

func (s *Server) SetGrants(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in []grantInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var pending []pendingNotif
	var revoked []uuid.UUID
	var boardOfTask uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var canEdit bool
		if e := tx.QueryRow(c.Context(),
			`SELECT app.can_edit_task($1, $2)`, taskID, uid).Scan(&canEdit); e != nil {
			return e
		}
		if !canEdit {
			return httpx.ErrForbidden
		}

		var boardID uuid.UUID
		var taskTitle string
		if e := tx.QueryRow(c.Context(),
			`SELECT board_id, title FROM app.tasks WHERE id = $1`, taskID).Scan(&boardID, &taskTitle); e != nil {
			return e
		}
		boardOfTask = boardID
		var actorName string
		_ = tx.QueryRow(c.Context(),
			`SELECT full_name FROM app.users WHERE id = $1`, uid).Scan(&actorName)

		// Кому доступ был открыт до правки — чтобы отличить снятых от
		// оставшихся. Участники доски здесь не учитываются: у них доступ
		// к задаче идёт от членства в проекте, а не от гранта.
		beforeGrants := map[uuid.UUID]bool{}
		gr, e := tx.Query(c.Context(),
			`SELECT user_id FROM app.task_grants WHERE task_id = $1`, taskID)
		if e != nil {
			return e
		}
		for gr.Next() {
			var id uuid.UUID
			if e := gr.Scan(&id); e != nil {
				gr.Close()
				return e
			}
			beforeGrants[id] = true
		}
		gr.Close()
		if e := gr.Err(); e != nil {
			return e
		}

		staysGrant := map[uuid.UUID]bool{}
		for _, g := range in {
			if g.Access == "read" || g.Access == "contribute" {
				staysGrant[g.UserID] = true
			}
		}
		for id := range beforeGrants {
			if !staysGrant[id] {
				revoked = append(revoked, id)
			}
		}

		if _, e := tx.Exec(c.Context(), `DELETE FROM app.task_grants WHERE task_id = $1`, taskID); e != nil {
			return e
		}
		for _, g := range in {
			if g.Access != "read" && g.Access != "contribute" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.task_grants (task_id, user_id, access, granted_by)
				VALUES ($1, $2, $3::app.grant_access, $4)`, taskID, g.UserID, g.Access, uid); e != nil {
				return e
			}
			// Уведомляем ТОЛЬКО тех, кому доступ открыт впервые (не тех,
			// у кого он уже был). Сообщение — с названием задачи и тем,
			// кто открыл доступ (п.8).
			if !beforeGrants[g.UserID] {
				msg := "Открыт доступ к задаче «" + taskTitle + "»"
				if actorName != "" {
					msg += " — " + actorName
				}
				n, e := notifyInsertCat(c.Context(), tx, g.UserID, msg, "granted", &boardID, &taskID)
				if e != nil {
					return e
				}
				if n.ID != uuid.Nil {
					pending = append(pending, pendingNotif{UserID: g.UserID, Notif: n})
				}
			}
		}
		// Присваивание, а не объявление: e уже объявлена выше в этом
		// же блоке вместе с курсором по действующим грантам.
		_, e = tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, 'Изменён доступ к задаче')`,
			taskID, uid)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	s.flushNotifs(pending)
	// Тем, у кого грант отозвали, — адресное событие: обычная рассылка
	// их уже не застанет, потому что в число наблюдателей задачи они
	// после удаления гранта не входят.
	go s.publishTaskAccessRevoked(boardOfTask, taskID, revoked)

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	return httpx.JSON(c, fiber.StatusOK, t)
}

type assignmentDoneInput struct {
	Completed bool `json:"completed"`
}

// CompleteAssignment — отметка исполнителя о выполнении СВОЕЙ части.
//
// Права проверяет политика task_assignees_self_update: обновить можно
// только строку со своим user_id. Поэтому здесь нет отдельной проверки
// «а исполнитель ли он» — если человек в исполнителях не числится,
// строки для обновления просто не найдётся, и мы вернём 403.
//
// Автор задачи не может отметиться за исполнителя: это сознательно.
// Отметка означает «я сделал», и право поставить её за другого лишило
// бы её смысла. Закрыть задачу целиком автор по-прежнему может кнопкой
// «Пометить завершённой» — это другое действие.
func (s *Server) CompleteAssignment(c *fiber.Ctx) error {
	taskID, err := param(c, "taskID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in assignmentDoneInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var affected int64
	var watchers []uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `
			UPDATE app.task_assignees
			   SET completed_at = CASE WHEN $3 THEN now() ELSE NULL END
			 WHERE task_id = $1 AND user_id = $2`, taskID, uid, in.Completed)
		if e != nil {
			return e
		}
		affected = tag.RowsAffected()
		if affected == 0 {
			return nil
		}

		// Имя берём из справочника, чтобы запись в истории читалась без
		// подстановки на клиенте: история задачи должна оставаться
		// понятной и через год, когда состав исполнителей уже другой.
		var name string
		if e := tx.QueryRow(c.Context(),
			`SELECT full_name FROM app.users WHERE id = $1`, uid).Scan(&name); e != nil {
			return e
		}

		body := name + " отметил(а) свою часть выполненной"
		if !in.Completed {
			body = name + " снял(а) отметку о выполнении"
		}
		if _, e := tx.Exec(c.Context(),
			`INSERT INTO app.activity (task_id, actor_id, body) VALUES ($1, $2, $3)`,
			taskID, uid, body); e != nil {
			return e
		}
		watchers, e = s.notifyWatchers(c.Context(), tx, taskID, uid, body)
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	if affected == 0 {
		return httpx.Fail(c, httpx.Err(fiber.StatusForbidden, "not_assignee",
			"Отметить выполнение может только исполнитель этой задачи"))
	}

	t, err := s.loadTask(c, taskID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishTask(t, "updated")
	go s.pingNotifications(watchers)
	return httpx.JSON(c, fiber.StatusOK, t)
}
