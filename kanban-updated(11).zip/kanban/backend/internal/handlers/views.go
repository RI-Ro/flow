package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Отметки о просмотре (п.5).
//
// Задача помечается просмотренной и сама собой — при загрузке карточки
// целиком (loadTask). Отдельный маршрут нужен для двух случаев, где
// такой загрузки не происходит:
//
//   - карточка открывается из уже загруженного списка задач доски,
//     то есть без обращения к /tasks/:id;
//   - открывается проект — у него своей «карточки» нет вовсе.
//
// Одно тело запроса на оба вида сущностей: смысл действия один и тот
// же, а разводить два почти одинаковых маршрута ради слова в пути
// значило бы дублировать и проверку прав.

type viewInput struct {
	Kind string    `json:"kind"` // task | board
	ID   uuid.UUID `json:"id"`
}

type viewResult struct {
	Kind     string     `json:"kind"`
	ID       uuid.UUID  `json:"id"`
	ViewedAt *time.Time `json:"viewedAt"`
}

func (s *Server) MarkSeen(c *fiber.Ctx) error {
	var in viewInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Kind != "task" && in.Kind != "board" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_kind",
			"Отметка о просмотре возможна только для задачи или проекта"))
	}
	if in.ID == uuid.Nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_id",
			"Не указан объект просмотра"))
	}
	uid := s.uid(c)

	var at *time.Time
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT app.mark_seen($1, $2, $3)`, in.Kind, in.ID, uid).Scan(&at)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	// NULL от mark_seen означает «объект не виден» — отвечаем как на
	// несуществующий, чтобы по коду ответа нельзя было перебором
	// выяснять чужие идентификаторы.
	if at == nil {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	return httpx.JSON(c, fiber.StatusOK, viewResult{Kind: in.Kind, ID: in.ID, ViewedAt: at})
}
