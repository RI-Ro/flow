-- =====================================================================
-- 0007_editor_rights.sql — редактор проекта управляет составом
-- участников и настройками доски.
--
-- До этой миграции всё, кроме содержимого доски, было заперто на
-- владельце: редактор мог заводить и править задачи и колонки, но не
-- мог ни переименовать проект, ни добавить исполнителя. На практике
-- это означало, что любое кадровое движение упиралось в одного
-- человека, и роль редактора теряла смысл.
--
-- Граница проведена по владению, а не по «важности» действия: редактор
-- распоряжается всем, кроме самого владения. Он не может ни назначить
-- владельца, ни изменить или снять строку владельца, ни удалить
-- проект. Иначе редактор одним запросом повышал бы себя до владельца,
-- и разделение ролей осталось бы только на бумаге.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0007_editor_rights.sql
--
-- Запускать от app_owner, после 0006_views.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. НАСТРОЙКИ ПРОЕКТА.
-- ─────────────────────────────────────────────────────────────────────
--
-- Название, описание, фон, положение в дереве. Удаление проекта
-- (boards_delete) остаётся за владельцем и здесь не трогается.
DROP POLICY IF EXISTS boards_update ON app.boards;
CREATE POLICY boards_update ON app.boards FOR UPDATE
    USING (app.can_edit_board(id, app.current_user_id()))
    WITH CHECK (app.can_edit_board(id, app.current_user_id()));

-- ─────────────────────────────────────────────────────────────────────
-- 2. СОСТАВ УЧАСТНИКОВ.
-- ─────────────────────────────────────────────────────────────────────
--
-- Условие `role <> 'owner'` в каждой политике — это и есть та самая
-- граница. Оно проверяется и в USING (какую строку разрешено трогать),
-- и в WITH CHECK (какой она станет после записи): без второй половины
-- редактор смог бы взять строку обычного участника и переписать её в
-- владельца.
DROP POLICY IF EXISTS board_members_write ON app.board_members;
CREATE POLICY board_members_write ON app.board_members FOR INSERT
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

DROP POLICY IF EXISTS board_members_update ON app.board_members;
CREATE POLICY board_members_update ON app.board_members FOR UPDATE
    USING (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    )
    WITH CHECK (
        app.is_board_owner(board_id, app.current_user_id())
        OR (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
    );

-- Владелец и редактор убирают любого, кроме владельца; участник может
-- уйти сам. Строка владельца не удаляется никем — проект без владельца
-- остался бы без того, кто вправе его удалить.
DROP POLICY IF EXISTS board_members_delete ON app.board_members;
CREATE POLICY board_members_delete ON app.board_members FOR DELETE
    USING (
        (app.can_edit_board(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

-- Готово.
