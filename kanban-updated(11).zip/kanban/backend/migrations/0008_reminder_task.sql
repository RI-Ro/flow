-- =====================================================================
-- 0008_reminder_task.sql — напоминание можно привязать к задаче.
--
-- Привязка необязательная: напоминание «позвонить в бухгалтерию» живёт
-- само по себе, а «сдать отчёт по задаче N» без ссылки на задачу
-- заставляет искать её руками в тот самый момент, когда будильник уже
-- звонит.
--
-- ON DELETE SET NULL, а не CASCADE: удалили задачу — напоминание
-- остаётся. Оно принадлежит человеку, а не задаче, и молча исчезнуть из
-- его списка не должно.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0008_reminder_task.sql
--
-- Запускать от app_owner, после 0007_editor_rights.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

ALTER TABLE app.reminders
    ADD COLUMN IF NOT EXISTS task_id uuid REFERENCES app.tasks(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS reminders_task_idx ON app.reminders (task_id)
    WHERE task_id IS NOT NULL;

-- Сработавшее напоминание отдаёт клиенту и задачу — чтобы окно
-- будильника умело открыть её сразу.
--
-- DROP перед CREATE обязателен: у функции меняется набор возвращаемых
-- столбцов, а CREATE OR REPLACE такого не позволяет — Postgres
-- отвечает «cannot change return type of existing function». Отдельного
-- состояния у функции нет, пересоздать её безопасно.
DROP FUNCTION IF EXISTS app.due_reminders();

CREATE FUNCTION app.due_reminders()
RETURNS TABLE (id uuid, user_id uuid, title text, recur_freq text,
               recur_interval int, recur_weekdays int[], task_id uuid)
LANGUAGE sql SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT id, user_id, title, recur_freq, recur_interval, recur_weekdays, task_id
      FROM app.reminders
     WHERE active AND remind_at <= now()
       AND (last_fired IS NULL OR last_fired < remind_at)
$$;

GRANT EXECUTE ON FUNCTION app.due_reminders() TO app_user;

-- Готово.

-- Название привязанной задачи для списка напоминаний.
--
-- SECURITY DEFINER с явной проверкой видимости: задачу могли перенести
-- в другой проект или закрыть от пользователя доступ, и напоминание не
-- должно превращаться в щёлку, через которую виден чужой заголовок.
-- Возвращает NULL, если задачи нет или она недоступна.
CREATE OR REPLACE FUNCTION app.task_title_visible(p_task uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.title FROM app.tasks t
     WHERE t.id = p_task AND app.can_see_task(t.id, p_user)
$$;

GRANT EXECUTE ON FUNCTION app.task_title_visible(uuid, uuid) TO app_user;
