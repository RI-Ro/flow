-- =====================================================================
-- 0006_views.sql — отметки о просмотре задач и проектов.
--
-- Зачем нужна отдельная таблица. Требовалось показывать, что в задаче
-- или проекте что-то изменилось с момента последнего просмотра ИМЕННО
-- этим пользователем. Такое состояние нельзя хранить ни в самой задаче
-- (оно у каждого своё), ни в уведомлениях (они про события, а не про
-- «дочитал/не дочитал»), поэтому заводится отдельная таблица
-- app.view_marks: одна строка на пару «пользователь + сущность».
--
-- Здесь же лежит источник данных для двойной отметки у исполнителя в
-- карточке задачи: одна галочка — исполнитель открывал задачу (есть
-- строка в view_marks), две — отметил свою часть выполненной
-- (task_assignees.completed_at).
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0006_views.sql
--
-- Запускать от app_owner, после 0005_features.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ТАБЛИЦА ОТМЕТОК.
-- ─────────────────────────────────────────────────────────────────────
--
-- entity_id намеренно без внешнего ключа: таблица полиморфна и хранит
-- отметки и по задачам, и по проектам. Сироты после удаления сущности
-- убираются триггерами ниже, а не каскадом.
CREATE TABLE IF NOT EXISTS app.view_marks (
    user_id   uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
    kind      text NOT NULL CHECK (kind IN ('task', 'board')),
    entity_id uuid NOT NULL,
    viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, kind, entity_id)
);

-- Индекс под обратный вопрос «кто смотрел эту задачу»: он нужен для
-- галочек у исполнителей и без индекса означал бы полный проход по
-- таблице на каждую открытую карточку.
CREATE INDEX IF NOT EXISTS view_marks_entity_idx
    ON app.view_marks (kind, entity_id);

ALTER TABLE app.view_marks ENABLE ROW LEVEL SECURITY;

-- Прямой доступ — только к своим строкам. Всё, что касается чужих
-- отметок (галочки исполнителей), выдаётся через SECURITY DEFINER
-- функции ниже, где видимость самой задачи уже проверена.
DROP POLICY IF EXISTS view_marks_own ON app.view_marks;
CREATE POLICY view_marks_own ON app.view_marks FOR ALL
    USING (user_id = app.current_user_id())
    WITH CHECK (user_id = app.current_user_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON app.view_marks TO app_user;

-- Уборка отметок вместе с сущностью. SECURITY DEFINER обязателен:
-- удаляются строки всех пользователей, а не только текущего, и под
-- политикой view_marks_own обычная роль их просто не увидит.
CREATE OR REPLACE FUNCTION app.drop_view_marks() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
BEGIN
    DELETE FROM app.view_marks
     WHERE kind = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN OLD;
END $$;

DROP TRIGGER IF EXISTS tasks_drop_view_marks ON app.tasks;
CREATE TRIGGER tasks_drop_view_marks AFTER DELETE ON app.tasks
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('task');

DROP TRIGGER IF EXISTS boards_drop_view_marks ON app.boards;
CREATE TRIGGER boards_drop_view_marks AFTER DELETE ON app.boards
    FOR EACH ROW EXECUTE FUNCTION app.drop_view_marks('board');

-- ─────────────────────────────────────────────────────────────────────
-- 2. ЗАПИСЬ И ЧТЕНИЕ ОТМЕТОК.
-- ─────────────────────────────────────────────────────────────────────

-- Отметить сущность просмотренной. Видимость проверяется здесь же:
-- функция SECURITY DEFINER, и без этой проверки любой мог бы создать
-- отметку по чужому идентификатору и заодно выяснить, существует ли он.
CREATE OR REPLACE FUNCTION app.mark_seen(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public
AS $$
DECLARE
    v_at timestamptz;
BEGIN
    IF p_user IS NULL OR p_entity IS NULL THEN
        RETURN NULL;
    END IF;
    IF p_kind NOT IN ('task', 'board') THEN
        RAISE EXCEPTION 'unknown_view_kind';
    END IF;

    IF p_kind = 'task' AND NOT app.can_see_task(p_entity, p_user) THEN
        RETURN NULL;
    END IF;
    IF p_kind = 'board' AND NOT app.can_see_board(p_entity, p_user) THEN
        RETURN NULL;
    END IF;

    INSERT INTO app.view_marks (user_id, kind, entity_id, viewed_at)
    VALUES (p_user, p_kind, p_entity, now())
    ON CONFLICT (user_id, kind, entity_id)
    DO UPDATE SET viewed_at = now()
    RETURNING viewed_at INTO v_at;

    RETURN v_at;
END $$;

-- Когда текущий пользователь в последний раз открывал сущность.
CREATE OR REPLACE FUNCTION app.seen_at(p_kind text, p_entity uuid, p_user uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT v.viewed_at FROM app.view_marks v
     WHERE v.user_id = p_user AND v.kind = p_kind AND v.entity_id = p_entity
$$;

-- Исполнители задачи, которые её открывали. Возвращается пересечение
-- с составом исполнителей, а не все зрители подряд: карточке нужны
-- только галочки напротив исполнителей, а кто ещё заглядывал в задачу —
-- не её дело.
CREATE OR REPLACE FUNCTION app.assignees_seen(p_task uuid)
RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT COALESCE(array_agg(DISTINCT v.user_id), '{}')
      FROM app.view_marks v
      JOIN app.task_assignees a
        ON a.task_id = v.entity_id AND a.user_id = v.user_id
     WHERE v.kind = 'task' AND v.entity_id = p_task
$$;

-- ─────────────────────────────────────────────────────────────────────
-- 3. ВРЕМЯ ПОСЛЕДНЕГО ИЗМЕНЕНИЯ.
-- ─────────────────────────────────────────────────────────────────────
--
-- tasks.updated_at меняется только при правке самой строки задачи, а
-- «изменением» для пользователя является и новый комментарий, и файл,
-- и отметка в чек-листе. Все они пишутся в app.activity, поэтому за
-- момент последнего изменения берём максимум из двух источников.
--
-- p_except — пользователь, чьи собственные действия не считаются
-- изменением: иначе человек помечал бы задачу непрочитанной сам себе
-- каждым своим комментарием.
CREATE OR REPLACE FUNCTION app.task_activity_at(p_task uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               t.updated_at,
               COALESCE((SELECT max(a.created_at) FROM app.activity a
                          WHERE a.task_id = t.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        t.updated_at))
      FROM app.tasks t WHERE t.id = p_task
$$;

-- Для проекта изменением считается и правка самого проекта, и любое
-- движение в его задачах: в списке проектов слева человек ждёт отметку
-- «здесь что-то новое», не открывая доску.
--
-- Функция SECURITY DEFINER и потому не ограничена RLS. Это осознанно:
-- вызывается она только для проектов, которые пользователю и так
-- видны (список строится под RLS), а считать максимум по видимым
-- задачам отдельным проходом с политиками — заметно дороже.
CREATE OR REPLACE FUNCTION app.board_activity_at(p_board uuid, p_except uuid)
RETURNS timestamptz
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT GREATEST(
               b.updated_at,
               COALESCE((SELECT max(t.updated_at) FROM app.tasks t
                          WHERE t.board_id = b.id AND NOT t.archived),
                        b.updated_at),
               COALESCE((SELECT max(a.created_at)
                           FROM app.activity a
                           JOIN app.tasks t ON t.id = a.task_id
                          WHERE t.board_id = b.id
                            AND (p_except IS NULL OR a.actor_id IS DISTINCT FROM p_except)),
                        b.updated_at))
      FROM app.boards b WHERE b.id = p_board
$$;

GRANT EXECUTE ON FUNCTION app.mark_seen(text, uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.seen_at(text, uuid, uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.assignees_seen(uuid)               TO app_user;
GRANT EXECUTE ON FUNCTION app.task_activity_at(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.board_activity_at(uuid, uuid)      TO app_user;

-- Отдельный индекс под max(created_at) по задаче не нужен: он уже есть
-- в базовой схеме как activity_task_idx (task_id, created_at DESC) и
-- обслуживает оба запроса выше.

-- Готово.
