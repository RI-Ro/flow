/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      // Только системные гарнитуры. Inter и Space Grotesk здесь были
      // пожеланием, которое ни во что не превращалось: шрифты никуда
      // не подключены, браузер их не находит и молча берёт запасной.
      // Теперь стек честный и совпадает с переменными из styles.css.
      fontFamily: {
        sans: ["system-ui", "-apple-system", "Segoe UI", "Roboto",
               "Helvetica Neue", "Noto Sans", "Liberation Sans", "Arial", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas",
               "Liberation Mono", "DejaVu Sans Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
