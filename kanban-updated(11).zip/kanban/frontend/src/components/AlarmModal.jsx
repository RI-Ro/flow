import React, { useEffect, useState } from "react";
import { BellOff, Clock, ExternalLink } from "lucide-react";
import { api } from "../lib/api.js";
import { startAlarm, stopAlarm } from "../lib/sound.js";

// Окно сработавшего напоминания.
//
// Отличается от обычной модалки тремя вещами, и все три — намеренно:
//
//   • оно поверх всего (z-index выше остальных окон и подтверждений):
//     напоминание, спрятавшееся за карточкой задачи, бесполезно;
//   • его нельзя закрыть ни клавишей Escape, ни щелчком по фону —
//     только «Отключить» или «Отложить». Иначе случайный клик мимо
//     окна гасит будильник, и человек узнаёт о пропущенном деле
//     постфактум;
//   • звонок повторяется, пока окно открыто.
//
// Анимация нарисована прямо здесь, средствами SVG и CSS, а не взята
// готовой гифкой. Причина практическая: гифка — это лишний двоичный
// файл в раздаче, с фиксированным разрешением и собственным фоном,
// который не подстроится под светлую и тёмную темы. Векторный
// будильник качается, звенит и остаётся резким на любом экране.

export default function AlarmModal({ theme, alarms, onDismiss, onError, onOpenTask }) {
  // Показывается всегда самое старое из несработанных: если за время
  // отсутствия накопилось несколько, разбираем их по очереди, а не
  // вываливаем стопкой окон.
  const current = alarms[0];
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!current) return;
    startAlarm();
    return () => stopAlarm();
  }, [current?.id]);

  // Пока окно открыто, страница за ним не прокручивается.
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = ""; };
  }, []);

  if (!current) return null;

  const snooze = async () => {
    setBusy(true);
    try {
      await api.snoozeReminder(current.id, 5);
      stopAlarm();
      onDismiss(current.id, "Напоминание отложено на 5 минут");
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  const dismiss = () => {
    stopAlarm();
    onDismiss(current.id);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,.72)" }}
      role="alertdialog" aria-modal="true" aria-label="Напоминание">
      <style>{`
        @keyframes kanban-alarm-rock {
          0%, 100% { transform: rotate(-9deg); }
          50%      { transform: rotate(9deg); }
        }
        @keyframes kanban-alarm-ring {
          0%, 100% { opacity: .15; transform: scale(.9); }
          50%      { opacity: .85; transform: scale(1.12); }
        }
        @keyframes kanban-alarm-hand {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>

      <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
        className="rounded-2xl w-full max-w-md p-6 text-center shadow-2xl">

        <AlarmClock theme={theme} />

        <div className="mono text-[10.5px] uppercase tracking-[0.2em] mt-4 mb-2"
          style={{ color: theme.textMuted }}>
          // напоминание
        </div>

        <h2 style={{ color: theme.text, fontFamily: "var(--font-ui)" }}
          className="text-[26px] font-extrabold leading-tight break-words mb-1">
          {current.title}
        </h2>

        <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-6">
          Сейчас {new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}
          {alarms.length > 1 && ` · ещё напоминаний: ${alarms.length - 1}`}
        </p>

        {/* Привязанная задача открывается прямо отсюда: напоминание
            «сдать отчёт по задаче» бесполезно, если задачу после него
            приходится искать руками. Будильник при этом выключается —
            человек уже занялся делом. */}
        {current.taskId && (
          <button onClick={() => { dismiss(); onOpenTask?.(current.taskId); }}
            style={{ background: theme.surfaceAlt, color: theme.accent, border: `1px solid ${theme.border}` }}
            className="w-full rounded-xl py-2.5 text-[13px] font-semibold flex items-center justify-center gap-2 mb-2">
            <ExternalLink size={15} /> Открыть задачу
          </button>
        )}

        <div className="flex flex-col sm:flex-row gap-2">
          <button onClick={snooze} disabled={busy}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="flex-1 rounded-xl py-3 text-[14px] font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
            <Clock size={16} /> Отложить на 5 минут
          </button>
          <button onClick={dismiss} disabled={busy}
            style={{ background: theme.accent, color: theme.accentText }}
            className="flex-1 rounded-xl py-3 text-[14px] font-semibold flex items-center justify-center gap-2 disabled:opacity-50">
            <BellOff size={16} /> Отключить
          </button>
        </div>

        <p style={{ color: theme.textMuted }} className="text-[11px] mt-3 leading-relaxed">
          Окно закроется только по одной из этих кнопок — чтобы напоминание
          не пропало от случайного нажатия.
        </p>
      </div>
    </div>
  );
}

// Векторный будильник: корпус качается, звонки пульсируют, секундная
// стрелка идёт по кругу.
function AlarmClock({ theme }) {
  return (
    <svg viewBox="0 0 120 120" width="120" height="120" className="mx-auto"
      style={{ animation: "kanban-alarm-rock 0.9s ease-in-out infinite", transformOrigin: "60px 78px" }}
      aria-hidden>
      {/* звон по сторонам */}
      <g style={{ animation: "kanban-alarm-ring 0.45s ease-in-out infinite" }}>
        <path d="M14 34 C6 30, 4 20, 8 12" fill="none" stroke={theme.accent} strokeWidth="4" strokeLinecap="round" />
        <path d="M106 34 C114 30, 116 20, 112 12" fill="none" stroke={theme.accent} strokeWidth="4" strokeLinecap="round" />
      </g>

      {/* колокольчики и ножки */}
      <circle cx="27" cy="26" r="12" fill={theme.accent} />
      <circle cx="93" cy="26" r="12" fill={theme.accent} />
      <rect x="24" y="98" width="12" height="16" rx="4" fill={theme.accent} transform="rotate(-20 30 106)" />
      <rect x="84" y="98" width="12" height="16" rx="4" fill={theme.accent} transform="rotate(20 90 106)" />

      {/* корпус */}
      <circle cx="60" cy="66" r="40" fill={theme.accent} />
      <circle cx="60" cy="66" r="32" fill={theme.surface} stroke={theme.border} strokeWidth="2" />

      {/* деления */}
      {[0, 90, 180, 270].map((a) => (
        <rect key={a} x="59" y="38" width="2" height="7" rx="1" fill={theme.textMuted}
          transform={`rotate(${a} 60 66)`} />
      ))}

      {/* стрелки */}
      <rect x="59" y="46" width="2.5" height="21" rx="1.2" fill={theme.text} />
      <rect x="59" y="52" width="2.5" height="15" rx="1.2" fill={theme.text}
        transform="rotate(115 60 66)" />
      <g style={{ animation: "kanban-alarm-hand 2s linear infinite", transformOrigin: "60px 66px" }}>
        <rect x="59.4" y="44" width="1.6" height="23" rx="0.8" fill={theme.danger} />
      </g>
      <circle cx="60" cy="66" r="3.2" fill={theme.text} />
    </svg>
  );
}
