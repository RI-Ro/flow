import React, { useState } from "react";
import { BellPlus } from "lucide-react";
import { api } from "../lib/api.js";
import { Modal, ModalHeader, Field, inputStyle } from "../lib/ui.jsx";

// Напоминание по конкретной задаче.
//
// Заводится из карточки, потому что именно там человек понимает, что о
// задаче нужно вспомнить в четверг. Идти за этим в отдельный раздел,
// а потом ещё и переписывать туда название — лишняя работа, на которой
// напоминание обычно и не заводится.
//
// Название подставляется из задачи, но остаётся редактируемым: «сдать
// смету» полезнее, чем скопированный заголовок задачи.

// По умолчанию — завтра в 10:00. Не «через час»: напоминания по задачам
// почти всегда про другой день, и час — заведомо неверная догадка,
// которую пришлось бы править каждый раз.
function defaultWhen() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(10, 0, 0, 0);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

export default function TaskReminderModal({ theme, task, onClose, onSaved, onError }) {
  const [title, setTitle] = useState(task.title || "");
  const [when, setWhen] = useState(defaultWhen());
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim() || !when) return onError("Укажите название и время напоминания");
    setBusy(true);
    try {
      // Время из поля — местное; toISOString переводит его в UTC, и в
      // базу уходит именно тот момент, который человек видел на своих
      // часах.
      await api.createReminder({
        title: title.trim(),
        remindAt: new Date(when).toISOString(),
        recurFreq: "none",
        recurInterval: 1,
        recurWeekdays: [],
        taskId: task.id,
      });
      onSaved();
    } catch (e) {
      onError(e.message);
      setBusy(false);
    }
  };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="task-reminder">
      <ModalHeader theme={theme} title="Напомнить о задаче"
        subtitle={`«${task.title}»`} onClose={onClose} />

      <Field label="О чём напомнить" theme={theme}>
        <input value={title} onChange={(e) => setTitle(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <Field label="Когда" theme={theme}
        hint="Прозвонит будильником: окно поверх всего с возможностью отложить.">
        <input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)}
          style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <p style={{ color: theme.textMuted }} className="text-[11.5px] leading-relaxed mb-3">
        Напоминание видите только вы. Задача останется привязанной — из
        напоминания её можно будет открыть одним нажатием.
      </p>

      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={submit} disabled={busy}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50">
          <BellPlus size={14} /> {busy ? "Создаём…" : "Напомнить"}
        </button>
      </div>
    </Modal>
  );
}
