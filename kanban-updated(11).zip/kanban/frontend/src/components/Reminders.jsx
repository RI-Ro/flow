import React, { useEffect, useState } from "react";
import { Plus, Trash2, Pencil, BellRing, BellOff, Repeat, Link2 as LinkIcon } from "lucide-react";
import { api } from "../lib/api.js";
import { fmtDateTime } from "../lib/theme.js";
import { inputStyle } from "../lib/ui.jsx";

const FREQ_LABEL = { none: "Однократно", daily: "Ежедневно", weekly: "Еженедельно", monthly: "Ежемесячно" };
const WEEKDAYS = [["1", "Пн"], ["2", "Вт"], ["3", "Ср"], ["4", "Чт"], ["5", "Пт"], ["6", "Сб"], ["0", "Вс"]];

// Вкладка «Напоминания» — личные «будильники» с необязательным
// повторением. Срабатывают на сервере (фоновый опрос) и приходят
// как уведомления в колокольчик.
export default function Reminders({ theme, onError, onOpenTask }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // "new" | id | null
  const [draft, setDraft] = useState(blank());

  // Значение для <input type="datetime-local"> из ISO-времени с зоной.
  //
  // Сервер отдаёт момент в UTC (с суффиксом Z), а поле ввода работает
  // только с локальным временем без зоны. Прежний код просто отрезал
  // первые 16 символов ISO-строки — и подставлял в поле время по UTC,
  // из-за чего при открытии на редактирование напоминание «уезжало» на
  // величину часового пояса, а сохранение закрепляло сдвиг.
  function toLocalInput(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  // Список задач для привязки грузится один раз и только когда форму
  // открыли: на странице напоминаний он нужен далеко не всегда, а
  // задач у человека могут быть сотни.
  const [taskOptions, setTaskOptions] = useState(null);
  const loadTaskOptions = async () => {
    if (taskOptions) return;
    try {
      const list = await api.allTasks();
      setTaskOptions((list || [])
        .filter((t) => !t.completedAt)
        .sort((a, b) => a.title.localeCompare(b.title, "ru")));
    } catch {
      // Не смогли загрузить — привязку просто не предлагаем, само
      // напоминание от этого не страдает.
      setTaskOptions([]);
    }
  };

  function blank() {
    // По умолчанию — через час от текущего момента, локальное время.
    const d = new Date(Date.now() + 60 * 60 * 1000);
    const iso = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
    return { title: "", remindAt: iso, recurFreq: "none", recurInterval: 1, recurWeekdays: [], taskId: "" };
  }
  function p(n) { return String(n).padStart(2, "0"); }

  const load = async () => {
    setLoading(true);
    try { setItems(await api.reminders()); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const startNew = () => { setDraft(blank()); setEditing("new"); loadTaskOptions(); };
  const startEdit = (r) => {
    setDraft({
      title: r.title, remindAt: toLocalInput(r.remindAt),
      recurFreq: r.recurFreq, recurInterval: r.recurInterval || 1,
      recurWeekdays: r.recurWeekdays || [],
      taskId: r.taskId || "",
    });
    setEditing(r.id);
    loadTaskOptions();
  };

  const save = async () => {
    if (!draft.title.trim()) return onError("Укажите название напоминания");
    if (!draft.remindAt) return onError("Укажите дату и время");
    // В поле ввода — местное время без зоны; new Date() трактует его
    // как местное, toISOString переводит в UTC. Так момент, заданный
    // человеком на своих часах, доходит до базы без сдвига.
    const payload = {
      title: draft.title.trim(),
      remindAt: new Date(draft.remindAt).toISOString(),
      recurFreq: draft.recurFreq,
      recurInterval: Number(draft.recurInterval) || 1,
      recurWeekdays: draft.recurFreq === "weekly" ? draft.recurWeekdays.map(Number) : [],
      // Привязка необязательна: пустое значение означает «без задачи».
      taskId: draft.taskId || null,
    };
    try {
      if (editing === "new") await api.createReminder(payload);
      else await api.updateReminder(editing, payload);
      setEditing(null);
      load();
    } catch (e) { onError(e.message); }
  };

  const toggleActive = async (r) => {
    try { await api.updateReminder(r.id, { title: r.title, remindAt: "", recurFreq: r.recurFreq, recurInterval: r.recurInterval, recurWeekdays: r.recurWeekdays, active: !r.active, taskId: r.taskId || null }); load(); }
    catch (e) { onError(e.message); }
  };

  const remove = async (r) => {
    try { await api.deleteReminder(r.id); setItems((x) => x.filter((i) => i.id !== r.id)); }
    catch (e) { onError(e.message); }
  };

  const toggleWeekday = (d) =>
    setDraft((v) => ({
      ...v,
      recurWeekdays: v.recurWeekdays.includes(d)
        ? v.recurWeekdays.filter((x) => x !== d)
        : [...v.recurWeekdays, d],
    }));

  const editor = (
    <div style={{ background: theme.surfaceAlt, border: `1px solid ${theme.border}` }} className="rounded-xl p-3 mb-3">
      <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })}
        placeholder="О чём напомнить" autoFocus style={inputStyle(theme)}
        className="w-full rounded-lg px-2.5 py-1.5 text-[13px] outline-none mb-2" />
      <div className="grid grid-cols-2 gap-2 mb-2">
        <div>
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Когда</div>
          <input type="datetime-local" value={draft.remindAt} onChange={(e) => setDraft({ ...draft, remindAt: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none" />
        </div>
        <div>
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">Повтор</div>
          <select value={draft.recurFreq} onChange={(e) => setDraft({ ...draft, recurFreq: e.target.value })}
            style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none">
            {Object.entries(FREQ_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </div>
      </div>

      <div className="mb-2">
        <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-1">
          Задача (необязательно)
        </div>
        <select value={draft.taskId || ""} onChange={(e) => setDraft({ ...draft, taskId: e.target.value })}
          style={inputStyle(theme)} className="w-full rounded-lg px-2 py-1.5 text-[12.5px] outline-none">
          <option value="">Без задачи</option>
          {taskOptions === null && <option disabled>Загружаем список задач…</option>}
          {(taskOptions || []).map((t) => (
            <option key={t.id} value={t.id}>
              {t.title}{t.boardTitle ? ` · ${t.boardTitle}` : ""}
            </option>
          ))}
        </select>
      </div>

      {draft.recurFreq !== "none" && (
        <div className="flex items-center gap-2 mb-2">
          <span style={{ color: theme.textMuted }} className="text-[12px]">Каждые</span>
          <input type="number" min="1" value={draft.recurInterval}
            onChange={(e) => setDraft({ ...draft, recurInterval: e.target.value })}
            style={inputStyle(theme)} className="w-16 rounded-lg px-2 py-1 text-[12.5px] outline-none" />
          <span style={{ color: theme.textMuted }} className="text-[12px]">
            {draft.recurFreq === "daily" ? "дн." : draft.recurFreq === "weekly" ? "нед." : "мес."}
          </span>
        </div>
      )}

      {draft.recurFreq === "weekly" && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          {WEEKDAYS.map(([d, label]) => (
            <button key={d} onClick={() => toggleWeekday(d)}
              style={{
                background: draft.recurWeekdays.includes(d) ? theme.accent : theme.surface,
                color: draft.recurWeekdays.includes(d) ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-2.5 py-1 rounded-lg text-[12px]">{label}</button>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <button onClick={save} style={{ background: theme.accent, color: theme.accentText }} className="rounded-lg px-3 py-1.5 text-[12.5px] font-semibold">Сохранить</button>
        <button onClick={() => setEditing(null)} style={{ color: theme.textMuted, border: `1px solid ${theme.border}` }} className="rounded-lg px-3 py-1.5 text-[12.5px]">Отмена</button>
      </div>
    </div>
  );

  return (
    <div className="max-w-[720px] mx-auto pb-6">
      <div className="flex items-center justify-between mb-3">
        <h2 style={{ color: theme.text }} className="text-[15px] font-semibold flex items-center gap-2"><BellRing size={16} /> Напоминания</h2>
        {editing !== "new" && (
          <button onClick={startNew} style={{ background: theme.accent, color: theme.accentText }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-semibold">
            <Plus size={14} /> Новое
          </button>
        )}
      </div>

      {editing === "new" && editor}

      {loading ? (
        <p style={{ color: theme.textMuted }} className="text-[13px]">Загрузка…</p>
      ) : items.length === 0 && editing !== "new" ? (
        <p style={{ color: theme.textMuted }} className="text-[13px]">Напоминаний пока нет. Создайте первое — оно придёт в колокольчик в заданное время.</p>
      ) : (
        items.map((r) => (
          editing === r.id ? <div key={r.id}>{editor}</div> : (
            <div key={r.id} style={{ background: theme.surface, border: `1px solid ${theme.border}`, opacity: r.active ? 1 : 0.55 }}
              className="rounded-xl p-3 mb-2 flex items-start gap-3 group">
              <div className="flex-1 min-w-0">
                <div style={{ color: theme.text }} className="text-[13.5px] font-medium">{r.title}</div>
                <div style={{ color: theme.textMuted }} className="text-[11.5px] mt-0.5 flex flex-wrap items-center gap-x-3">
                  <span>{fmtDateTime(r.remindAt)}</span>
                  {r.recurFreq !== "none" && (
                    <span className="flex items-center gap-1"><Repeat size={11} />{FREQ_LABEL[r.recurFreq]}</span>
                  )}
                  {!r.active && <span>отключено</span>}
                </div>
                {/* Привязанная задача. Название показывается, только
                    если задача пользователю доступна — иначе сервер
                    отдаёт пустую строку, и мы говорим об этом прямо,
                    а не показываем пустую ссылку. */}
                {r.taskId && (
                  r.taskTitle ? (
                    <button onClick={() => onOpenTask?.(r.taskId)}
                      style={{ color: theme.accent }}
                      className="flex items-center gap-1 text-[11.5px] mt-1 font-medium"
                      title="Открыть задачу">
                      <LinkIcon size={11} /> {r.taskTitle}
                    </button>
                  ) : (
                    <span style={{ color: theme.textMuted }} className="text-[11.5px] mt-1 block">
                      Задача больше недоступна
                    </span>
                  )
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => toggleActive(r)} style={{ color: theme.textMuted }} title={r.active ? "Отключить" : "Включить"}>
                  {r.active ? <BellRing size={15} /> : <BellOff size={15} />}
                </button>
                <button onClick={() => startEdit(r)} style={{ color: theme.textMuted }} title="Изменить"><Pencil size={14} /></button>
                <button onClick={() => remove(r)} style={{ color: theme.danger }} title="Удалить"><Trash2 size={14} /></button>
              </div>
            </div>
          )
        ))
      )}
    </div>
  );
}
