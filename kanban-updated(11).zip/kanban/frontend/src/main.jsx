import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

// Шрифты не подключаются вовсе — ни из сети, ни пакетами.
//
// Используются только системные: они уже есть на машине, не добавляют
// ни одного файла в раздачу и не задерживают первую отрисовку. В
// закрытом контуре это единственный вариант, который работает
// одинаково у всех, а вид интерфейса от гарнитуры зависит слабо —
// размеры и толщины заданы вёрсткой.
//
// Стек живёт в одном месте, в styles.css (--font-ui и --font-mono).

import "./styles.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
